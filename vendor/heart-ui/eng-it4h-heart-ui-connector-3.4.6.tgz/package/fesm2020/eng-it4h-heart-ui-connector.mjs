import * as i0 from '@angular/core';
import { Injectable, InjectionToken, Optional, Inject, NgModule, SkipSelf } from '@angular/core';
import { FhirConverter, ModelToFHIRUtils, FhirCodesMapperUtils, HeartExtension, HeartValueSet, KinshipConverterUtils } from '@eng-it4h/heart-ui-converter';
import { of, lastValueFrom, map } from 'rxjs';
import { CarePlanApi, GoalApi, BundleUtilityApi, PlanDefinitionApi, Goal, CarePlan, RelatedPersonApi, PatientApi, RelatedPerson, Bundle, Patient, CareTeamApi, DocumentReferenceApi, DocumentReference, ConditionApi, ConsentApi, GenomicStudyApi, ObservationApi, OrganizationApi, Practitioner, ClinicalImpressionApi, PractitionerApi, DomainResource, ProcedureApi, QuestionnaireApi, QuestionnaireResponseApi, TerminologyValueSetApi, Reference, NamingSystem, BasicApi, EncounterApi, EpisodeOfCareApi, DiagnosticReportApi, ServiceRequestApi, AppointmentApi, PersonApi, RiskAssessmentApi, ResearchSubjectApi, ResearchStudyApi, NutritionIntakeApi } from '@eng-it4h/fhir-r5';
import { remove, uniq } from 'lodash-es';
import { ClinicalNote, GenericQuantitativeMeasure, Role, PersonRole, Organization, User, ChatSettings, CodedValue, Choice, Question, ResponseStatus, Patient as Patient$1, DocRef, EncounterStatus, GenomicVariant, DiagnosticImplication, TherapeuticImplication, MolecularConsequence, Vcf, Kinship, Trial } from '@eng-it4h/heart-ui-model';
import * as i1 from '@angular/common/http';
import { HttpHeaders, HttpParams, HttpErrorResponse, HttpResponse, HttpUrlEncodingCodec } from '@angular/common/http';
import { startOfDay, endOfDay } from 'date-fns';
import { map as map$1 } from 'rxjs/operators';
import { union } from 'lodash';

/**
 * Conversion manager providing the right converter to/from the local model
 */
class DataConverterFactory {
    constructor() { }
    initConverter(format) {
        if (format === ConvertibleFormat.FHIR) {
            this.fhir = new FhirConverter();
        }
        else {
            throw new TypeError(`Unsupported conversion format ${format}.`);
        }
    }
    // TODO: valutare se splittare in più metodi ed introdurre l'uso dei generics
    getConverter(format) {
        if (format === ConvertibleFormat.FHIR) {
            return this.fhir;
        }
        else {
            throw new TypeError(`Unsupported conversion format ${format}.`);
        }
    }
    getFhirConverter() {
        return this.fhir;
    }
}
DataConverterFactory.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DataConverterFactory, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
DataConverterFactory.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DataConverterFactory });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DataConverterFactory, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return []; } });
var ConvertibleFormat;
(function (ConvertibleFormat) {
    ConvertibleFormat[ConvertibleFormat["FHIR"] = 0] = "FHIR";
})(ConvertibleFormat || (ConvertibleFormat = {}));

class ExceptionHandlerService {
}
/**
 * This service is just a placeholder that just logs the error to the console, in case you don't need it at all
 */
class BasicExceptionHandler extends ExceptionHandlerService {
    getExceptionHandler() {
        return (operation = 'operation') => {
            // return new Observable(error as any).toPromise();
            return (error) => {
                console.error(`[ERROR] in ${operation} ${error?.statusText} ${error?.status} now you must be kicked-out`);
                return of(error);
            };
        };
    }
}
BasicExceptionHandler.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: BasicExceptionHandler, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
BasicExceptionHandler.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: BasicExceptionHandler });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: BasicExceptionHandler, decorators: [{
            type: Injectable
        }] });

class BackendCarePlanConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        // this.baseHeaders = new HttpHeaders({
        //     'Content-Type': 'application/json',
        //     'Accept': 'application/json',
        // });
        this.fhirConverter = fhirConverter;
        this.carePlanApi = new CarePlanApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.goalApi = new GoalApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.planDefApi = new PlanDefinitionApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    async searchPlanDefinitions() {
        const bundle = await lastValueFrom(this.planDefApi.search({}));
        const encounters = bundle?.entry
            ?.filter((entry) => entry.resource.resourceType == 'PlanDefinition')
            ?.map((entry) => this.fhirConverter.toDataModel(entry.resource, bundle)) || [];
        return Promise.resolve(encounters);
    }
    async searchByPatient(patient, status, limit = 1) {
        let carePlanExtras = new Map();
        if (limit > 0) {
            carePlanExtras = carePlanExtras.set('_count', limit);
            carePlanExtras = carePlanExtras.set('_sort', '-date');
        }
        const patientRef = ModelToFHIRUtils.getReference(patient);
        // 1. search for the active careplans
        return this.carePlanApi
            .search({
            patient: patientRef,
            status: status ? FhirCodesMapperUtils.PlanStatusToFHIR(status)?.toString() : undefined,
            _includes: ['CarePlan:condition' /*, 'CarePlan:goal'*/],
        }, carePlanExtras)
            .toPromise()
            .then((bundle) => {
            // 2. merge of the careplan request in case of too many 'Conditions'
            return bundle?.entry ? this.bundleUtils.mergeBundle(bundle) : undefined;
        })
            .then((bundle) => {
            const firstPlanComponent = bundle?.entry?.find((e) => e.resource.resourceType === 'CarePlan');
            // IMPORTANT ERROR: this code doens't work if there is more than one plan!!!
            if (firstPlanComponent && limit == 1) {
                const planId = firstPlanComponent.resource.id;
                // remove other plans from the bundle
                remove(bundle?.entry, (e) => e.resource.resourceType === 'CarePlan' && e.resource.id != planId);
                const macroGoalExtras = new Map();
                macroGoalExtras.set('_has:CarePlan:goal:_id', planId);
                // 3. search for macro goal referred from the plan
                return this.goalApi
                    .search({}, macroGoalExtras)
                    .toPromise()
                    .then((goalBundle) => {
                    return goalBundle?.entry ? this.bundleUtils.mergeBundle(goalBundle) : undefined;
                })
                    .then((goalBundle) => {
                    // merge of the CarePlan Bundle and of the Macro Goals plan
                    bundle.entry = [...bundle.entry, ...(goalBundle?.entry || [])];
                    return bundle;
                });
            }
            else {
                return undefined;
            }
        })
            .then((res) => {
            if (!res) {
                return [];
            }
            // 4. retrieves all the referred milestones
            return this.retrievesReferredMilestones(res.entry.filter((entry) => entry.resource instanceof Goal)).then((milestoneEntries) => {
                res.entry.push(...milestoneEntries);
                // convert the content in Plan
                const fhirCarePlans = res.entry
                    // filter the plan supported by the app
                    .filter((entry) => entry.resource instanceof CarePlan)
                    .map((entry) => {
                    // convert the whole CarePlan (including its referred milestones)
                    return this.fhirConverter.toDataModel(entry.resource, res);
                });
                return fhirCarePlans;
            });
        });
    }
    async retrievesReferredMilestones(macroGoalEntries) {
        const referredMilestones = [];
        macroGoalEntries
            .map((entry) => entry.resource)
            .forEach((mg) => {
            const milestones = mg.extension
                ? mg.extension
                    .filter((e) => e.url === HeartExtension.Goal.relationship.url)
                    .filter((mExt) => !!mExt.extension
                    ?.filter((innerExt) => innerExt.value && innerExt.url === 'type')
                    .find((innerExt) => HeartValueSet.Common.GoalRelationship.MILESTONE.equals(innerExt.value)))
                : [];
            milestones.forEach((e) => {
                const ref = e.extension.find((innerExt) => innerExt.url === 'target').value;
                referredMilestones.push(ref.reference);
            });
        });
        if (referredMilestones.length === 0) {
            return [];
        }
        // gets all the milestones (by IDs) related to the current macros from the server
        const extraIds = new Map();
        extraIds.set('_id', referredMilestones.join(','));
        let milestoneBundle = await this.goalApi.search({}, extraIds).toPromise();
        // navigate any pages
        milestoneBundle = await this.bundleUtils.mergeBundle(milestoneBundle);
        return milestoneBundle.entry;
    }
    async searchByReference(plan) {
        const reference = ModelToFHIRUtils.getReference(plan);
        const ref = reference.reference;
        return this.carePlanApi
            .getById(ref)
            .toPromise()
            .then((fhirCarePlan) => this.fhirConverter.toDataModel(fhirCarePlan));
    }
    async update(plan) {
        return this.carePlanApi
            .transaction([this.fhirConverter.fromDataModel(plan)])
            .toPromise()
            .then((res) => this.resolvePlan(res));
    }
    //TODO: to test
    async create(plan) {
        return this.carePlanApi
            .transaction([this.fhirConverter.fromDataModel(plan)])
            .toPromise()
            .then((res) => this.resolvePlan(res));
    }
    async resolvePlan(bundle) {
        if (!bundle) {
            return undefined;
        }
        const allPages = await this.bundleUtils.mergeBundle(bundle);
        allPages.entry?.forEach((entry) => {
            if (entry.resource.id.startsWith('urn') && entry.response?.location) {
                const id = this.getIdFromLocation(entry.response.location);
                // temporary saving the 'urn'. This is non-normative but is needed to solve references in the bundle
                // NOTE: it is better to hide this logic in the bundle itself
                entry.response._id = entry.resource.id;
                entry.resource.id = id;
            }
        });
        return allPages.entry
            .filter((entry) => entry.resource instanceof CarePlan)
            .map((entry) => {
            const plan = this.fhirConverter.toDataModel(entry.resource, allPages);
            return plan;
        })
            .pop();
    }
    getIdFromLocation(location) {
        const _historyIndex = location.indexOf('/_history');
        let startIndex = undefined;
        let endIndex = undefined;
        if (_historyIndex > 0) {
            endIndex = _historyIndex;
        }
        startIndex = location.indexOf('/');
        if (endIndex) {
            return location.substring(startIndex + 1, endIndex);
        }
        else {
            return location.substring(startIndex + 1);
        }
    }
}

class BackendRelatedPersonConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        this.fhirConverter = fhirConverter;
        // this.baseHeaders = new HttpHeaders({
        //     'Content-Type': 'application/json',
        //     'Accept': 'application/json',
        // });
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.relatedPersonApi = new RelatedPersonApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.patientApi = new PatientApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    async create(relatedPerson) {
        const fhirCG = this.fhirConverter.fromDataModel(relatedPerson);
        if (relatedPerson.alias) {
            const fhirP = this.fhirConverter.fromDataModel(relatedPerson.alias);
            const seeAlso = this.createSeeAlso(fhirCG);
            fhirP.link = [seeAlso];
            const b = await lastValueFrom(this.patientApi.transaction([fhirP]));
            return await this.resolveCareGiver(b)[0];
        }
        else {
            const fhirRP = this.fhirConverter.fromDataModel(relatedPerson);
            return await lastValueFrom(this.relatedPersonApi.create(fhirRP)).then((res) => {
                relatedPerson.id = res.location;
                return relatedPerson;
            });
        }
    }
    async resolveCareGiver(bundle) {
        if (!bundle) {
            return undefined;
        }
        const allPages = await this.bundleUtils.mergeBundle(bundle);
        return allPages.entry
            ?.map((entry) => {
            if (entry.resource.id.startsWith('urn')) {
                const id = this.getIdFromLocation(entry.response.location);
                // temporary saving the 'urn'. This is non-normative but is needed to solve references in the bundle
                // NOTE: it is better to hide this logic in the bundle itself
                entry.response._id = entry.resource.id;
                entry.resource.id = id;
            }
            return entry;
        })
            .filter((entry) => entry.resource instanceof RelatedPerson)
            .map((entry) => {
            const rp = this.fhirConverter.toDataModel(entry.resource, allPages);
            return rp;
        });
    }
    async createAll(familyMembers) {
        const fhirRP = familyMembers.map((fm) => this.fhirConverter.fromDataModel(fm));
        return await lastValueFrom(this.relatedPersonApi.transaction(fhirRP)).then((res) => {
            return res?.entry?.map((entry) => entry.resource).map((fhirRP) => this.fhirConverter.toDataModel(fhirRP, res)) || [];
        });
        // FIXME: this does not support contextual creation of patient
    }
    async update(relatedPerson) {
        const fhirRP = this.fhirConverter.fromDataModel(relatedPerson);
        await lastValueFrom(this.relatedPersonApi.update(+relatedPerson.fhirId, fhirRP));
    }
    async delete(relatedPerson, cascade) {
        await lastValueFrom(this.relatedPersonApi.delete(+relatedPerson.fhirId));
        if (relatedPerson.alias && cascade) {
            await lastValueFrom(this.patientApi.delete(+relatedPerson.alias.fhirId));
        }
    }
    async searchByReference(model, withSeeAlso) {
        const reference = ModelToFHIRUtils.getReference(model);
        const ref = reference.reference;
        let promise = lastValueFrom(this.relatedPersonApi.search({
            id: ref,
            _revinclude: ['Patient:link'],
        }));
        let ret = await this.resolveInternal(promise, withSeeAlso);
        return ret.length > 0 ? ret[0] : model;
    }
    searcByPatient(patient, withSeeAlso) {
        const reference = ModelToFHIRUtils.getReference(patient);
        let promise = lastValueFrom(this.relatedPersonApi.search({
            patient: reference,
            _revinclude: ['Patient:link'],
        }));
        return this.resolveInternal(promise, withSeeAlso);
    }
    searcByPatients(patients) {
        let extraParams = new Map();
        extraParams.set('patient', patients?.map((p) => p.id).join(','));
        let promise = lastValueFrom(this.relatedPersonApi.search({
            _revinclude: ['Patient:link'],
        }, extraParams));
        return this.resolveInternal(promise, false);
    }
    async resolveInternal(promise, withSeeAlso) {
        return await promise
            .then((bundle) => {
            if (bundle && bundle.entry) {
                if (withSeeAlso) {
                    return this.bundleUtils.mergeBundle(bundle);
                }
                else {
                    return Promise.resolve(
                    // bundle.entry.map((entry) => entry.resource as FhirEncounter)
                    bundle.entry.filter((i) => i.resource.resourceType == 'RelatedPerson')?.map((entry) => entry.resource) ?? []);
                }
            }
            else {
                return Promise.resolve([]);
            }
        })
            .then((res) => {
            return res instanceof Bundle
                ? res.entry?.filter((i) => i.resource.resourceType == 'RelatedPerson').map((entry) => this.fhirConverter.toDataModel(entry.resource, res))
                : res?.map((fhir) => this.fhirConverter.toDataModel(fhir));
        });
    }
    createSeeAlso(cg) {
        const seeAlso = new Patient.PatientLinkComponent();
        seeAlso.type = 'seealso';
        seeAlso.other = cg;
        return seeAlso;
    }
    getIdFromLocation(location) {
        const _historyIndex = location.indexOf('/_history');
        let startIndex = undefined;
        let endIndex = undefined;
        if (_historyIndex > 0) {
            endIndex = _historyIndex;
        }
        startIndex = location.indexOf('/');
        if (endIndex) {
            return location.substring(startIndex + 1, endIndex);
        }
        else {
            return location.substring(startIndex + 1);
        }
    }
}

class BackendCareTeamConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        this.fhirConverter = fhirConverter;
        this.careTeamApi = new CareTeamApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.relatedPersonConnector = new BackendRelatedPersonConnector(http, fhirBaseFullUrl, exceptionHandler, fhirConverter);
    }
    async create(ct) {
        if (ct.caregiver) {
            await this.relatedPersonConnector.create(ct.caregiver);
        }
        const fhirCT = this.fhirConverter.fromDataModel(ct);
        return this.careTeamApi
            .create(fhirCT)
            .toPromise()
            .then((res) => {
            ct.id = res.location;
            return ct;
        });
    }
    async searchByPatient(patient) {
        return this.careTeamApi
            .search({
            subject: this.fhirConverter.getFHIRReference(patient),
        })
            .toPromise()
            .then((bundle) => (bundle?.entry?.length > 0 ? bundle.entry.map((entry) => this.fhirConverter.toDataModel(entry.resource)) : []))
            .then((careTeams) => this.retrieveCaregivers(careTeams));
    }
    async searchByPatients(patients) {
        let extraParams = new Map();
        extraParams.set('subject', patients?.map((p) => p.id).join(','));
        return this.careTeamApi
            .search({}, extraParams)
            .toPromise()
            .then((bundle) => (bundle?.entry?.length > 0 ? bundle.entry.map((entry) => this.fhirConverter.toDataModel(entry.resource)) : []))
            .then((careTeams) => this.retrieveCaregivers(careTeams));
    }
    async retrieveCaregivers(careTeams) {
        if (careTeams?.length > 0) {
            for (const ct of careTeams) {
                if (ct.caregiver) {
                    ct.caregiver = await this.relatedPersonConnector.searchByReference(ct.caregiver);
                }
            }
        }
        return careTeams;
    }
    /**
     *
     * @param id
     * @param careTeam
     * @param caregiverChange
     * @param oldCaregiver - used to refer the caregiver in case of caregiverChange === 'deleted'
     */
    async update(careTeam, caregiverChange, oldCaregiver) {
        if (careTeam.caregiver && caregiverChange === 'created') {
            careTeam.caregiver = await this.relatedPersonConnector.create(careTeam.caregiver);
        }
        else if (caregiverChange === 'changed') {
            await this.relatedPersonConnector.update(careTeam.caregiver);
        }
        else if (caregiverChange === 'deleted') {
            await this.relatedPersonConnector.delete(careTeam.caregiver);
            careTeam.caregiver = undefined;
        }
        const fhirCT = this.fhirConverter.fromDataModel(careTeam);
        await lastValueFrom(this.careTeamApi.update(careTeam.id, fhirCT));
    }
}

class BackendClinicalNoteConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        this.fhirConverter = fhirConverter;
        this.documentReferenceApi = new DocumentReferenceApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    async searchByPatient(config) {
        const ref = ModelToFHIRUtils.getReference(config.patient);
        let extraParam = new Map();
        extraParam = extraParam.set('relatesto:missing', true);
        extraParam = extraParam.set('_sort', '-date');
        return this.documentReferenceApi
            .search({
            patient: ref,
            category: config.filters?.tag,
            _includes: ['DocumentReference:author'],
        }, extraParam)
            .toPromise()
            .then((bundle) => this.bundleUtils.mergeBundle(bundle))
            .then((bundle) => bundle?.entry?.filter((entry) => entry.resource instanceof DocumentReference).map((entry) => this.fhirConverter.toDataModel(entry.resource, bundle)))
            .then((notes) => ({
            articles: notes,
            articlesCount: notes.length,
        }));
    }
    async searchByReference(stub) {
        const reference = ModelToFHIRUtils.getReference(stub);
        const ref = reference.reference;
        return (this.documentReferenceApi
            .search({
            id: ref,
            _includes: ['DocumentReference:author'],
        })
            .toPromise()
            // .then(bundle => this.bundleUtils.mergeBundle(bundle))
            .then((bundle) => bundle?.entry
            ?.filter((entry) => entry.resource instanceof DocumentReference)
            .map((entry) => this.fhirConverter.toDataModel(entry.resource, bundle))
            .pop()));
    }
    async delete(clinicalNote) {
        return this.deleteNote(+clinicalNote.fhirId);
    }
    async save(practitioner, article, encounter) {
        article.author = practitioner;
        return this.saveNote(article, encounter);
    }
    // public async favorite(slug: string): Promise<ClinicalNote> {
    //     return this.apiService.post('/articles/' + slug + '/favorite');
    // }
    // public async unfavorite(slug: string): Promise<ClinicalNote> {
    //     return this.apiService.delete('/articles/' + slug + '/favorite');
    // }
    async getAllComments(refers) {
        let extraParam = new Map();
        extraParam = extraParam.set('_sort', '-date');
        // extraParam = extraParam.set('relatesto:missing', true);
        return this.documentReferenceApi
            .search({
            relatesto: this.fhirConverter.getFHIRReference(refers),
            _revinclude: ['Practitioner:author'],
        }, extraParam)
            .toPromise()
            .then((bundle) => this.bundleUtils.mergeBundle(bundle))
            .then((bundle) => bundle?.entry
            ?.filter((entry) => entry.resource instanceof DocumentReference)
            .map((entry) => this.fhirConverter.toDataModel(entry.resource, bundle))
            .map((cn) => {
            cn.refers = refers;
            return cn;
        }));
        // .then(notes => notes.sort((n1, n2) => compareAsc(n1.createdAt, n2.createdAt)));
    }
    async addComment(practitioner, refers, commentBody) {
        const comment = new ClinicalNote();
        comment.author = practitioner;
        comment.body = commentBody;
        // comment.title = undefined;
        comment.createdAt = new Date();
        comment.refers = refers;
        comment.patient = refers.patient;
        return this.saveNote(comment);
    }
    async deleteComment(id, refers) {
        return this.deleteNote(id);
    }
    saveNote(clinicalNote, enc) {
        const fhirNote = this.fhirConverter.fromDataModel(clinicalNote);
        if (enc) {
            fhirNote.context = [ModelToFHIRUtils.getReference(enc)];
            fhirNote.type = HeartValueSet.Common.ClinicalImpression.OBSERVE_PATIENT.toCodeableConcept();
        }
        if (clinicalNote.id != undefined) {
            return lastValueFrom(this.documentReferenceApi.update(clinicalNote.id, fhirNote)).then((res) => {
                return clinicalNote;
            });
        }
        else {
            // FIXME: why is a default id generated? HAPI returns an error on create if id is provided
            fhirNote.id = undefined;
            return lastValueFrom(this.documentReferenceApi.create(fhirNote)).then((res) => {
                clinicalNote.id = res.location ? res.location : undefined;
                return clinicalNote;
            });
        }
    }
    deleteNote(fhirId) {
        return this.documentReferenceApi
            .patch(fhirId, {
            jsonPatchBody: [
                { op: 'remove', path: 'content' }, // removes the content instead of the actual note
            ],
        })
            .toPromise()
            .then(() => true);
    }
}

class BackendConditionConnector {
    constructor(http, restApiFullUrl, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        // this.baseHeaders = new HttpHeaders({
        //     'Content-Type': 'application/json',
        //     'Accept': 'application/json',
        // });
        this.fhirConverter = fhirConverter;
        this.conditionApi = new ConditionApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    /**
     *
     * @param nName - matches any of the string field name/alias
     */
    async search() {
        const search = this.conditionApi.search({});
        const bundle = await lastValueFrom(search);
        const conditions = bundle?.entry
            ?.map((entry) => entry.resource)
            .map(fhir => this.fhirConverter.toDataModel(fhir)) || [];
        return Promise.resolve(conditions);
    }
    async searchByReference(reference) {
        const search = this.conditionApi.getById(reference.id + '');
        const fhir = await lastValueFrom(search);
        let condition = this.fhirConverter.toDataModel(fhir);
        return condition;
    }
    async create(newCondition, author, encounter) {
        let fhir;
        if (newCondition.author != author) {
            newCondition.author = author;
        }
        fhir = this.fhirConverter.fromDataModel(newCondition);
        fhir.encounter = ModelToFHIRUtils.getReference(encounter);
        const createObs = this.conditionApi.create(fhir);
        const res = await lastValueFrom(createObs);
        newCondition.id = res?.location;
        return newCondition;
    }
    async update(updateCondition, author, encounter) {
        if (updateCondition.id == undefined) {
            throw new Error(`Error while updating the Condition as the FHIR ID is missing.`);
        }
        let fhir;
        if (updateCondition.author != author) {
            updateCondition.author = author;
        }
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        fhir = this.fhirConverter.fromDataModel(updateCondition);
        fhir.encounter = ModelToFHIRUtils.getReference(encounter);
        const update = this.conditionApi.update(updateCondition.id, fhir);
        await lastValueFrom(update);
        return updateCondition;
    }
    searchByPatients(pats) {
        const extraParams = new Map();
        extraParams.set('subject', pats?.map(p => p.id).join(','));
        return this.conditionApi.search({}, extraParams).toPromise()
            .then((bundle) => this.bundleUtils.mergeBundle(bundle))
            .then((bundle) => {
            return (bundle.entry?.map((entry) => this.fhirConverter.toDataModel(entry.resource)) || []);
        });
    }
}

class BackendConsentConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        // this.baseHeaders = new HttpHeaders({
        //     'Content-Type': 'application/json',
        //     'Accept': 'application/json',
        // });
        this.fhirConverter = fhirConverter;
        this.consentApi = new ConsentApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        // this.documentReferenceApi = new DocumentReferenceApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    async searchConsentsByPatient(patient, retrieveAll = false, callback) {
        const promise = this.consentApi
            .search({
            patient: this.fhirConverter.getFHIRReference(patient),
        })
            .toPromise();
        if (callback) {
            return promise.then((bundle) => {
                if (bundle && bundle.entry) {
                    if (retrieveAll) {
                        return this.bundleUtils.mergeBundleIncrementally(bundle, callback);
                    }
                    else {
                        return callback(bundle.entry.map((entry) => entry.resource));
                    }
                }
                else {
                    return callback([]);
                }
            });
        }
        else {
            return promise
                .then((bundle) => {
                if (bundle && bundle.entry) {
                    if (retrieveAll) {
                        return this.bundleUtils.mergeBundle(bundle);
                    }
                    else {
                        return Promise.resolve(bundle.entry.map((entry) => entry.resource));
                    }
                }
                else {
                    return Promise.resolve([]);
                }
            })
                .then((res) => {
                return res instanceof Bundle
                    ? res.entry.map((entry) => this.fhirConverter.toDataModel(entry.resource))
                    : res.map((entry) => this.fhirConverter.toDataModel(entry));
            });
        }
    }
    async create(consent) {
        const fhirConsent = this.fhirConverter.fromDataModel(consent);
        return this.consentApi
            .create(fhirConsent)
            .toPromise()
            .then((res) => {
            consent.id = res.location ? res.location : undefined;
            return consent;
        });
    }
    async update(consent) {
        await this.consentApi
            .update(+consent.fhirId, this.fhirConverter.fromDataModel(consent))
            .toPromise();
    }
    getContentAttachmentURL(consent) {
        if (consent.attachmentTitle && !!consent.id) {
            return this.consentApi.binaryAccessRead(+consent.id);
        }
        else {
            return undefined;
        }
    }
    async uploadConsentFiles(consent, file, callback) {
        const reference = this.consentApi.binaryAccessWrite(this.fhirConverter.fromDataModel(consent), file, callback);
        const idPart = (await reference)?.getReferenceIdPart();
        return idPart ? idPart + '' : undefined;
    }
}

class BackendGenomicStudyConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        this.fhirConverter = fhirConverter;
        this.genomicApi = new GenomicStudyApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.docRefApi = new DocumentReferenceApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    searchGenomicStudiesByPatient(patient, retrieveAll, callback) {
        const extraParams = new Map();
        const patientRef = ModelToFHIRUtils.getReference(patient);
        extraParams.set('analysis-output-file.type', 'filtered-vcf');
        return this.genomicApi.search({ subject: patientRef, _includes: ['GenomicStudy:analysis-specimen'] }, extraParams).pipe(map(res => {
            if (res.entry) {
                const toRet = [];
                res.entry.forEach(item => {
                    if (item.resource.resourceType == 'Specimen')
                        return; //skip - Specimen is managed in the GenomicStudy converter toDataModel
                    toRet.push(this.fhirConverter.toDataModel(item.resource, res));
                });
                return toRet;
            }
            else {
                return [];
            }
        }));
    }
    async retrieveCramUrl(reference) {
        const search = this.docRefApi.getById(reference);
        const fhir = await lastValueFrom(search);
        let cramUrl = fhir?.content[0]?.attachment?.url;
        let craiUrl = fhir?.content[1]?.attachment?.contentType == 'application/index' ? fhir?.content[1]?.attachment?.url : undefined;
        return [cramUrl, craiUrl];
    }
}

class BackendGoalConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        // this.baseHeaders = new HttpHeaders({
        //     'Content-Type': 'application/json',
        //     'Accept': 'application/json',
        // });
        this.fhirConverter = fhirConverter;
        this.goalApi = new GoalApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    async searchByPatient(patient, status) {
        const patientRef = ModelToFHIRUtils.getReference(patient);
        const promise = this.goalApi
            .search({
            patient: patientRef,
            // lifecycle_status: FhirCodesMapperUtils.GoalStatusToFHIR( status )?.toString(),
            _includes: ['Goal:patient'],
        })
            .toPromise();
        return promise
            .then((bundle) => {
            if (bundle && bundle.entry) {
                return this.bundleUtils.mergeBundle(bundle);
            }
            else {
                return Promise.resolve(undefined);
            }
        })
            .then((res) => {
            return res?.entry?.map((entry) => entry.resource).map((fhirGoal) => this.fhirConverter.toDataModel(fhirGoal, res)) || [];
        });
    }
    async searchByReference(goal) {
        const reference = ModelToFHIRUtils.getReference(goal);
        const ref = reference.reference;
        return this.goalApi
            .getById(ref)
            .toPromise()
            .then((fhirGoal) => this.fhirConverter.toDataModel(fhirGoal));
    }
    async deleteAll(goals) {
        const ids = goals.filter((g) => g.id != undefined).map((goal) => '' + goal.id);
        if (ids.length === 0) {
            return Promise.resolve();
        }
        try {
            await lastValueFrom(this.goalApi.deleteAllById(ids));
            return Promise.resolve();
        }
        catch (error) {
            console.error('Error deleting goals:', error);
            return Promise.reject(error);
        }
    }
    async updateMacro(macro) {
        return lastValueFrom(await this.goalApi.transaction(macro.map((m) => this.fhirConverter.fromDataModel(m)))).then((res) => {
            return res?.entry?.map((entry) => entry.resource).map((fhirGoal) => this.fhirConverter.toDataModel(fhirGoal, res)) || [];
        });
    }
}

// prettier-ignore
class BackendMeasureConnector {
    constructor(http, restApiFullUrl, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        this.http = http;
        this.restApiFullUrl = restApiFullUrl;
        this.fhirConverter = fhirConverter;
        this.measureConverter = this.fhirConverter.converterService.measure;
        this.baseHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json',
        });
        this.observationApi = new ObservationApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    /**
     *
     * @param patientRef
     * @param types
     * @param period from is start of day (included), while to is end of day (included)
     * @param limit
     * @returns
     */
    async searchByPatientAndType(patient, types, period, limit, sortByDescDate = false, forceGenericMeasure = false) {
        const patientRef = ModelToFHIRUtils.getReference(patient);
        let extraParams = new Map();
        if (limit > 0) {
            extraParams = extraParams.set('_count', '' + limit);
        }
        if (period) {
            const dateRange = [];
            if (period.from) {
                dateRange.push('ge' + startOfDay(period.from).toISOString());
            }
            if (period.to) {
                dateRange.push('le' + endOfDay(period.to).toISOString());
            }
            extraParams = extraParams.set('date', dateRange);
        }
        if (sortByDescDate) {
            extraParams = extraParams.set('_sort', '-date');
        }
        const promise = this.observationApi
            .search({
            patient: patientRef,
            code: types?.map(t => t.code).join(',')
        }, extraParams)
            .toPromise();
        return promise
            .then((bundle) => {
            if (bundle && bundle.entry) {
                return this.bundleUtils.mergeBundle(bundle);
            }
            else {
                return Promise.resolve([]);
            }
        })
            .then((res) => {
            const obs = res instanceof Bundle ? res.entry
                .map((entry) => entry.resource) : res;
            if (forceGenericMeasure) {
                return obs?.map((fhir) => {
                    try {
                        return this.measureConverter.toDataModelGenericMeasure(fhir);
                    }
                    catch (err) {
                        return undefined;
                    }
                })?.filter(e => (e && e instanceof GenericQuantitativeMeasure));
            }
            else {
                return obs?.map((fhir) => this.fhirConverter.toDataModel(fhir));
            }
        });
    }
    async searchByReference(measure) {
        const reference = ModelToFHIRUtils.getReference(measure);
        const ref = reference.reference;
        return this.observationApi
            .getById(ref)
            .toPromise()
            .then((fhir) => this.fhirConverter.toDataModel(fhir));
    }
    async trendByPatientAndType(patient, typeValueSet, options) {
        const patientRef = ModelToFHIRUtils.getReference(patient);
        const type = typeValueSet?.code;
        if (!(type === HeartValueSet.Common.Measurement.WAIST_CODINGS.code ||
            type === HeartValueSet.Common.Measurement.WEIGHT_CODINGS.code ||
            type === HeartValueSet.Common.Measurement.HEIGHT_CODINGS.code ||
            // type === HeartValueSet.Common.Measurement.BLOOD_PRESSURE_CODINGS.code ||
            type === HeartValueSet.Common.Measurement.SYSTOLIC_BLOOD_PRESSURE_CODINGS.code || type === HeartValueSet.Common.Measurement.DIASTOLIC_BLOOD_PRESSURE_CODINGS.code ||
            type === HeartValueSet.Common.Measurement.CHOLESTEROL_LDL_CODINGS.code || type === HeartValueSet.Common.Measurement.CHOLESTEROL_HDL_CODINGS.code || type === HeartValueSet.Common.Measurement.CHOLESTEROL_CODINGS.code ||
            type === HeartValueSet.Common.Measurement.BLOOD_GLUCOSE_MASS_CODINGS.code || type === HeartValueSet.Common.Measurement.BLOOD_GLUCOSE_MASS_INSULIN_CODINGS.code ||
            type === HeartValueSet.Common.Measurement.CIGARETTES_DAILY_AMOUNT_CODINGS.code ||
            // type === HeartValueSet.Common.Measurement.MEAL_CODINGS.code ||
            type === HeartValueSet.Common.Measurement.CALORIC_DAILY_INTAKE_CODINGS.code || type === HeartValueSet.Common.Measurement.CARBOHYDRATES_DAILY_INTAKE_CODINGS.code || type === HeartValueSet.Common.Measurement.FATS_DAILY_INTAKE_CODINGS.code ||
            type === HeartValueSet.Common.Measurement.FRUIT_PORTIONS_DAILY_INTAKE_CODINGS.code || type === HeartValueSet.Common.Measurement.VEGETABLES_PORTIONS_DAILY_INTAKE_CODINGS.code ||
            type === HeartValueSet.Common.Measurement.BODY_TEMPERATURE_CODINGS.code ||
            type === HeartValueSet.Common.Measurement.HEART_RATE_RESTING_CODING.code ||
            type === HeartValueSet.Common.Measurement.CHEST_PAIN_CODINGS.code || type === HeartValueSet.Common.Measurement.CHEST_PAIN_QUESTIONNAIRE.code ||
            type === HeartValueSet.Common.Measurement.SUGARY_BEVERAGE_DAILY_INTAKE_CODINGS.code || type === HeartValueSet.Common.Measurement.ALCOHOL_DAILY_INTAKE_CODINGS.code ||
            type === HeartValueSet.Common.Measurement.MODERATE_PHYSICAL_ACTIVITY_DURATION_WEEKLY_CODINGS.code || type === HeartValueSet.Common.Measurement.VIGOROUS_PHYSICAL_ACTIVITY_DURATION_WEEKLY_CODINGS.code ||
            type === HeartValueSet.Common.Measurement.STRENGTH_PHYSICAL_ACTIVITY_SESSION_WEEKLY_CODINGS.code || type === HeartValueSet.Common.Measurement.STEPS_CODINGS.code)) {
            throw Error(`Invalid type ${typeValueSet.code} for trend request.`);
        }
        const url = this.restApiFullUrl + '/stats/series';
        let aggregation = options?.aggregate || 'NONE';
        let fill = !!options?.fill;
        let httpParams = new HttpParams();
        if (patientRef) {
            httpParams = httpParams.set('patient', patientRef.getReferenceIdPart() + '');
        }
        if (typeValueSet) {
            httpParams = httpParams.append('measure', typeValueSet.code);
        }
        if (options) {
            if (options.from) {
                httpParams = httpParams.set('from', startOfDay(options.from).toISOString());
            }
            if (options.to) {
                httpParams = httpParams.set('to', endOfDay(options.to).toISOString());
            }
        }
        // if ( duration ) { // windowDuration
        //     httpParams = httpParams.set('duration', duration);
        // }
        if (aggregation && aggregation != 'NONE') {
            httpParams = httpParams.set('aggregation', aggregation);
        }
        if (fill) {
            httpParams = httpParams.set('fill', 'true');
        }
        return this.http.get(url, {
            headers: this.baseHeaders,
            params: httpParams
        })
            .toPromise()
            .then((results) => {
            // { name: string, series: { name: string | number, value: number}[] }[]
            // renames 'time' in 'name'
            return results?.map(series => ({
                name: series.name,
                series: series.series.map(dataPoint => ({ name: dataPoint.time, value: dataPoint.value }))
            })) || [];
        })
            .catch(err => {
            console.error(err);
            return [];
        });
    }
    async create(measures, author, encounter, forceGenericMeasure) {
        const obs = measures?.map((measure) => this.fhirConverter.fromDataModel(measure)) || [];
        let encounterRef = ModelToFHIRUtils.getReference(encounter);
        let performer = author ? [ModelToFHIRUtils.getReference(author)] : undefined;
        // adding perfomer and encounter - if present
        obs.forEach(o => {
            o.performer = performer;
            o.encounter = encounterRef;
        });
        return this.observationApi.transaction(obs)
            .toPromise()
            .then((res) => this.bundleUtils.mergeBundle(res))
            .then((mergedRes) => {
            const resultObs = mergedRes.entry
                .map((entry) => entry.resource);
            if (forceGenericMeasure) {
                return resultObs?.map((fhir) => {
                    try {
                        return this.measureConverter.toDataModelGenericMeasure(fhir);
                    }
                    catch (err) {
                        return undefined;
                    }
                })?.filter(e => (e && e instanceof GenericQuantitativeMeasure));
            }
            else {
                return resultObs?.map((fhir) => this.fhirConverter.toDataModel(fhir));
            }
        });
    }
    searchByPatientsAndType(patients, types, period, limit, sortByDescDate) {
        let extraParams = new Map();
        extraParams.set('subject', patients?.map(p => p.id).join(','));
        if (limit > 0) {
            extraParams = extraParams.set('_count', '' + limit);
        }
        if (period) {
            const dateRange = [];
            if (period.from) {
                dateRange.push('ge' + startOfDay(period.from).toISOString());
            }
            if (period.to) {
                dateRange.push('le' + endOfDay(period.to).toISOString());
            }
            extraParams = extraParams.set('date', dateRange);
        }
        if (sortByDescDate) {
            extraParams = extraParams.set('_sort', '-date');
        }
        const promise = this.observationApi
            .search({
            code: types?.map(t => t.code).join(',')
        }, extraParams)
            .toPromise();
        return promise
            .then((bundle) => {
            if (bundle && bundle.entry) {
                return this.bundleUtils.mergeBundle(bundle);
            }
            else {
                return Promise.resolve([]);
            }
        })
            .then((res) => {
            return res instanceof Bundle
                ? res.entry
                    .map((entry) => entry.resource)
                    .map((fhir) => this.fhirConverter.toDataModel(fhir))
                : res?.map((fhir) => this.fhirConverter.toDataModel(fhir));
        });
    }
}

class BackendOrganizationConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        this.fhirConverter = fhirConverter;
        this.organizationApi = new OrganizationApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    async create(newOrg) {
        if (newOrg.id) {
            return Promise.reject('Organization already has an id');
        }
        const fhirOrganization = this.fhirConverter.fromDataModel(newOrg);
        const response = await lastValueFrom(this.organizationApi.create(fhirOrganization));
        newOrg.id = response?.location;
        return newOrg;
    }
    async update(newOrg) {
        if (newOrg.id == undefined) {
            return Promise.reject('Organization must have an id');
        }
        const fhirOrganization = this.fhirConverter.fromDataModel(newOrg);
        await lastValueFrom(this.organizationApi.update(newOrg.id, fhirOrganization));
        return newOrg;
    }
    /*  public getOrganizations(): Promise<Organization[]> {
            return this.organization.getResources().toPromise().then(b => b.entry.map(entry => entry.resource as Organization));
        }*/
    async searchOrganizationsByName(name, retrieveAll = false, callback) {
        const promise = this.organizationApi.search({ name: name }).toPromise();
        if (callback) {
            return promise.then((bundle) => {
                if (bundle && bundle.entry) {
                    if (retrieveAll) {
                        return callback(bundle.entry.map((entry) => entry.resource));
                    }
                    else {
                        return this.bundleUtils.mergeBundleIncrementally(bundle, callback);
                    }
                }
                else {
                    return callback([]);
                }
            });
        }
        else {
            return promise
                .then((bundle) => {
                if (bundle && bundle.entry) {
                    if (retrieveAll) {
                        return Promise.resolve(bundle.entry.map((entry) => entry.resource));
                    }
                    else {
                        return this.bundleUtils.mergeBundle(bundle);
                    }
                }
                else {
                    return Promise.resolve([]);
                }
            })
                .then((res) => {
                return res instanceof Bundle
                    ? res.entry.map((entry) => this.fhirConverter.toDataModel(entry.resource))
                    : res.map((fhir) => this.fhirConverter.toDataModel(fhir));
            });
        }
    }
    // FIXME: in v2 potremmo introdurre queste, quando ci sarà un corrispettivo oggetto nel modello Easy. per ora generano dipendenza diretta da FHIR
    // public async createPractitionerRole(
    //     practitionerRole: FHIRPractitionerRole
    // ): Promise<number> {
    //     return this.practitionerRole
    //         .create(practitionerRole)
    //         .toPromise()
    //         .then((res) => res.location);
    // }
    // public async searchPractitionerRoles(): Promise<FHIRPractitionerRole[]> {
    //     return this.practitionerRole
    //         .search({})
    //         .toPromise()
    //         .then((bundle) =>
    //             bundle?.entry?.length > 0
    //                 ? bundle?.entry?.map(
    //                       (entry) => entry.resource as FHIRPractitionerRole
    //                   )
    //                 : []
    //         );
    // }
    /**
     *
     * @param nName - matches any of the string field name/alias
     */
    async searchOrganizations() {
        const request = lastValueFrom(this.organizationApi.search({}));
        return request.then((bundle) => bundle?.entry?.map((entry) => this.fhirConverter.toDataModel(entry.resource)) || []);
    }
    async searchByReference(reference) {
        const ref = ModelToFHIRUtils.getReference(reference).reference;
        // const id: string = ref.startsWith('Organization/') ? ref.substring('Organization/'.length) : ref;
        return this.organizationApi
            .getById(ref)
            .toPromise()
            .then((fhir) => this.fhirConverter.toDataModel(fhir));
    }
}

class BackendUserConnector {
    // prettier-ignore
    constructor(http, restApiFullUrl, userApi, exceptionHandler, fhirConverter) {
        this.http = http;
        this.restApiFullUrl = restApiFullUrl;
        this.userApi = userApi;
        this.exceptionHandler = exceptionHandler;
        this.fhirConverter = fhirConverter;
        this.baseHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        });
    }
    /**
     * Verifies if the specified username (or email address) is currently available
     *
     * Returns true if available, false otherwise
     *
     * @param usernameOrEmail
     */
    async isUsernameAvailable(username) {
        const url = this.restApiFullUrl + '/user/check-username-availability';
        const data = {
            username: username.trim(),
        };
        const request = lastValueFrom(this.userApi.checkUsernameAvailability(data));
        return request
            .then((result) => result ? !!result.available : Promise.resolve(undefined))
            .catch((err) => {
            if (err instanceof HttpErrorResponse) {
                this.exceptionHandler('username')(err);
            }
            return Promise.reject(err);
        });
    }
    /**
     * The method creates the Patient/Practitioner on the server and at the same time it creates the user account
     *
     * @param user
     */
    registerUser(user) {
        /**
         *  create the property 'organizationRoles' (not supported in the 'easy' model)
         */
        const personRoles = new Map();
        user.person?.personRoles.forEach((pr) => {
            const orgId = pr.organization.id;
            let roles = personRoles.get(orgId);
            if (!roles) {
                roles = [];
                personRoles.set(orgId, roles);
            }
            roles.push(pr.role);
        });
        // manual convertion of the Map as JSON stringify returns an empty map
        const organizationRolesMap = {};
        personRoles.forEach((value, key) => {
            organizationRolesMap[key] = value;
        });
        const reqUserDTO = {
            person: this.fhirConverter.fromDataModel(user.person),
            username: user.username,
            locale: user.locale,
            organizationRoles: organizationRolesMap,
            password: user.password,
            temporaryPassword: user.temporaryPassword,
            emailVerified: user.emailVerified,
        };
        const ret = lastValueFrom(this.userApi.registerUser(reqUserDTO, 'response'));
        return ret.then((response) => {
            if (response instanceof HttpErrorResponse) {
                throw response.error.issue[0];
            }
            else if (response instanceof HttpResponse) {
                const body = response.body;
                if (body.resourceType === 'Patient') {
                    return this.fhirConverter.toDataModel(Patient.revive(body));
                }
                else if (body.resourceType === 'Practitioner') {
                    return this.fhirConverter.toDataModel(Practitioner.revive(body));
                }
            }
            return undefined;
        });
    }
    async searchUsers(type = 'all', organization, onlyEnabled = false) {
        let userType = undefined;
        if (type !== 'all') {
            userType = (type == 'HealthCareProfessional') ? 'Practitioner' : 'Patient';
        }
        const request = lastValueFrom(this.userApi.searchUsers(undefined, userType, onlyEnabled, organization?.id, 'body'));
        return request
            .then((results) => {
            if (results) {
                return results.map((user) => {
                    let person;
                    const resource = user.person;
                    if (resource.resourceType === 'Patient') {
                        const fhirPerson = this.fhirConverter.converterService
                            .person;
                        person = fhirPerson.toDataModelPatient(Patient.revive(resource));
                    }
                    else if (resource.resourceType === 'Practitioner') {
                        const fhirPerson = this.fhirConverter.converterService
                            .person;
                        person = fhirPerson.toDataModelHealthCareProfessional(Practitioner.revive(resource));
                    }
                    else {
                        throw new Error('Unknown result type: ' + resource);
                    }
                    /**
                     *  deserialize the property 'organizationRoles' (not supported in the 'easy' model)
                     */
                    let personRoles = [];
                    if (user.organizationRoles) {
                        const entries = Object.entries(user.organizationRoles);
                        personRoles = entries
                            .map((e) => {
                            const roles = e[1];
                            return roles
                                .map((r) => Role.convertFromString(r))
                                .filter((r) => r != undefined)
                                .map((r) => new PersonRole(new Organization(+e[0]), r));
                        })
                            .flat();
                    }
                    person.personRoles = personRoles;
                    return new User({
                        username: user.username,
                        person: person,
                        logged: false,
                        // FIXME i ruoli sono in person?
                        // person.resourceType === 'Practitioner' ? [Role.PRACTITIONER] : [Role.PATIENT],
                        // roles: user.roles?.map(r => Role.convertFromString(r)),
                        enabled: user.enabled,
                        // FIXME: convertire i badges
                        //badges: user.badges,
                        lastUpdate: user.lastUpdate,
                    });
                });
            }
            return Promise.resolve(undefined);
        })
            .catch((err) => {
            if (err instanceof HttpErrorResponse) {
                this.exceptionHandler('searchAllUsers')(err);
            }
            return Promise.reject(err);
        });
    }
    async searchUserByUsername(username) {
        const request = lastValueFrom(this.userApi.searchUsers(username));
        return request
            .then((results) => {
            if (results) {
                return results.map((user) => {
                    let person;
                    const resource = user.person;
                    if (resource.resourceType === 'Patient') {
                        person = this.fhirConverter.toDataModel(Patient.revive(resource));
                    }
                    else if (resource.resourceType === 'Practitioner') {
                        person = this.fhirConverter.toDataModel(Practitioner.revive(resource));
                    }
                    else {
                        throw new Error('Unknown result type: ' + resource);
                    }
                    /**
                     *  deserialize the property 'organizationRoles' (not supported in the 'easy' model)
                     */
                    let personRoles = [];
                    if (user.organizationRoles) {
                        const entries = Object.entries(user.organizationRoles);
                        personRoles = entries
                            .map((e) => {
                            const roles = e[1];
                            return roles
                                .map((r) => Role.convertFromString(r))
                                .filter((r) => r != undefined)
                                .map((r) => new PersonRole(new Organization(+e[0]), r));
                        })
                            .flat();
                    }
                    person.personRoles = personRoles;
                    return new User({
                        username: user.username,
                        person: person,
                        logged: false,
                        // FIXME i ruoli sono in person?
                        // person.resourceType === 'Practitioner' ? [Role.PRACTITIONER] : [Role.PATIENT],
                        // roles: user.roles?.map(r => Role.convertFromString(r)),
                        enabled: user.enabled,
                        // FIXME: i badges arrivano dal server EMR o solo da keycloak? comunque vanno convertiti
                        // badges: user.badges,
                        lastUpdate: user.lastUpdate,
                    });
                });
            }
            return Promise.resolve(undefined);
        })
            .catch((err) => {
            if (err instanceof HttpErrorResponse) {
                this.exceptionHandler('searchByUsername')(err);
            }
            return Promise.reject(err);
        });
    }
    /**
     * Remove all the data related to a specific patient
     *
     * NTOE: as this operation REALLY deletes all the data it must be used only in special situations (like DEVELOPMENT or explicit request from the Patient)
     *
     * @param patient
     */
    async eraseUserAndData(user) {
        const request = lastValueFrom(this.userApi.removeUser(user.id, 'response'));
        return request
            .then((response) => {
            if (response instanceof HttpErrorResponse) {
                return response.error.issue[0];
            }
            else if (response instanceof HttpResponse) {
                return true;
            }
            return false;
        })
            .catch((err) => {
            console.log(err);
            throw new Error(err);
        });
    }
    /**
     * tells if the user account is currently enabled
     *
     * @param user
     */
    async isUserEnabled(user) {
        return this.userApi
            .userStatus(user.id, 'response')
            .pipe(map$1((response) => {
            if (response instanceof HttpErrorResponse) {
                return response.error.issue[0];
            }
            else if (response instanceof HttpResponse) {
                return response.body;
            }
            return false;
        }))
            .toPromise()
            .catch((err) => {
            console.log(err);
            return false;
        });
    }
    /**
     * disable the user account without deleting the related data
     *
     * @param user
     */
    async disableUser(user) {
        return this.changeUserStatus(user, false);
    }
    /**
     * enable the user account for a previously disabled user
     *
     * @param user
     */
    async enableUser(user) {
        return this.changeUserStatus(user, true);
    }
    /**
     * Forced update of the password if the user in input
     *
     * @param newPassword
     * @param user
     */
    async sendResetPasswordMessage(password, user) {
        const body = {
            newPassword: password,
            username: user?.username,
        };
        const request = lastValueFrom(this.userApi.forceResetPasswordForOtherUser(body, user?.person?.id, 'response'));
        return request
            .then((response) => {
            if (response instanceof HttpErrorResponse) {
                return response.error.issue[0];
            }
            else if (response instanceof HttpResponse) {
                return true;
            }
            return false;
        })
            .catch((err) => {
            console.log(err);
            return undefined;
        });
    }
    /**
     * Update the password of the logged user
     *
     * @param user
     * @param oldPassword
     * @param newPassword
     */
    async updatePassword(oldPassword, newPassword) {
        const body = {
            oldPassword: oldPassword,
            newPassword: newPassword,
            // user: user.id,
        };
        const request = lastValueFrom(this.userApi.changeUserPassword(body, 'response'));
        return request
            .then((response) => {
            if (response instanceof HttpErrorResponse) {
                return response.error.issue[0];
            }
            else if (response instanceof HttpResponse) {
                return true;
            }
            return false;
        })
            .catch((err) => {
            console.log(err);
            return undefined;
        });
    }
    changeUserStatus(user, status) {
        const statusDTO = {
            enabled: status
        };
        const request = lastValueFrom(this.userApi.changeUserStatus(statusDTO, user.id, 'response'));
        return request
            .then((response) => {
            if (response instanceof HttpErrorResponse) {
                return response.error.issue[0];
            }
            else if (response instanceof HttpResponse) {
                return true;
            }
            return false;
        })
            .catch((err) => {
            console.log(err);
            return undefined;
        });
    }
}

class BackendPatientConnector extends BackendUserConnector {
    // prettier-ignore
    constructor(http, restApiFullUrl, fhirBaseFullUrl, userMService, exceptionHandler, fhirConverter) {
        super(http, restApiFullUrl, userMService, exceptionHandler, fhirConverter);
        this.patientApi = new PatientApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.observationApi = new ObservationApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.clinicalImpressionApi = new ClinicalImpressionApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.documentReferenceApi = new DocumentReferenceApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    async registerUser(user) {
        return super.registerUser(user);
    }
    async eraseUserAndData(patient) {
        return super.eraseUserAndData(patient);
    }
    async searchHealthStatusAndObservableByPatientReference(patient, participant) {
        const data = {};
        data.healthStatus = await this.observationApi
            .search({
            code: HeartValueSet.Common.Measurement.PATIENT_HEALTH_STATUS_CODING.code,
            patient: ModelToFHIRUtils.getReference(patient),
        })
            .toPromise()
            .then((bundle) => {
            return bundle.entry?.map((entry) => this.fhirConverter.toDataModel(entry.resource)).pop();
        });
        const extraParams = new Map();
        data.observe = await this.clinicalImpressionApi
            .search({
            patient: ModelToFHIRUtils.getReference(patient),
        }, extraParams)
            .toPromise()
            .then((bundle) => {
            return bundle.entry?.map((entry) => this.fhirConverter.toDataModel(entry.resource)).pop();
        });
        // avoid an empty structure
        return data.healthStatus || data.observe ? data : undefined;
    }
    async searchHealthStatusAndObservableByName(fullName, participant) {
        const extraParamsHS = new Map();
        // if (participant) {
        //     extraParamsHS.set('_has:CareTeam:subject:participant', participant.organization?.reference + ',' + participant.practitioner?.reference);
        // }
        extraParamsHS.set('_total', 'none');
        extraParamsHS.set('_count', '1000');
        const resultsPatientHealthStatuses = await this.observationApi
            .search({
            code: HeartValueSet.Common.Measurement.PATIENT_HEALTH_STATUS_CODING.code,
        }, extraParamsHS)
            .toPromise()
            .then((bundle) => this.bundleUtils.mergeBundle(bundle))
            .then((bundle) => {
            return bundle.entry?.map((entry) => this.fhirConverter.toDataModel(entry.resource)) || [];
        });
        const extraParams = new Map();
        if (participant) {
            extraParams.set('_has:CareTeam:subject:participant', ModelToFHIRUtils.getReference(participant.organization)?.reference + ',' + ModelToFHIRUtils.getReference(participant.practitioner)?.reference);
        }
        extraParams.set('_total', 'none');
        extraParams.set('_count', '1000');
        const results = await this.patientApi
            .search({
            name: fullName,
            _revinclude: ['ClinicalImpression:subject'],
        }, extraParams)
            .toPromise()
            .then((bundle) => this.bundleUtils.mergeBundle(bundle))
            .then((bundle) => {
            if (bundle.entry) {
                const aggregator = new Map();
                bundle.entry
                    ?.filter((entry) => entry.resource.resourceType === 'Patient')
                    .map((entry) => this.fhirConverter.toDataModel(entry.resource))
                    .forEach((p) => aggregator.set(this.fhirConverter.getFHIRReference(p).reference, {
                    patient: p,
                }));
                bundle.entry
                    ?.filter((entry) => entry.resource.resourceType === 'ClinicalImpression')
                    .map((entry) => this.fhirConverter.toDataModel(entry.resource))
                    .filter((observePatient) => !!observePatient.status)
                    .forEach((observePatient) => {
                    const ref = this.fhirConverter.getFHIRReference(observePatient.patient).reference;
                    const data = aggregator.get(ref);
                    if (data) {
                        data.settings = Object.assign(data.settings || {}, {
                            observe: observePatient,
                        });
                    }
                });
                resultsPatientHealthStatuses.forEach((phs) => {
                    const ref = this.fhirConverter.getFHIRReference(phs.patient).reference;
                    if (ref) {
                        const data = aggregator.get(ref);
                        if (data) {
                            data.settings = Object.assign(data.settings || {}, {
                                healthStatus: phs,
                            });
                        }
                    }
                    else {
                        console.log(`ERROR no patient reference in PatientHealthStatus`);
                    }
                });
                return [...aggregator.values()];
            }
            return [];
        });
        return results;
    }
    /**
     *
     * @param fullName - matches any of the string fields in the FHIR HumanName, including family, give, prefix, suffix, suffix, and/or text
     */
    async searchPatients(fullName, disableCache = false, retrieveAll = false, participant, onlyWithActivePlan = false, callback) {
        const extraParams = new Map();
        if (participant) {
            let queries = [];
            if (participant.organization) {
                queries.push(ModelToFHIRUtils.getReference(participant.organization)?.reference);
            }
            if (participant.practitioner) {
                queries.push(ModelToFHIRUtils.getReference(participant.practitioner)?.reference);
            }
            if (queries.length > 0) {
                extraParams.set('_has:CareTeam:subject:participant', queries.join(','));
                extraParams.set('_has:CareTeam:subject:status', 'active');
            }
        }
        extraParams.set('_total', 'none');
        extraParams.set('_count', '1000');
        if (!!onlyWithActivePlan) {
            extraParams.set('_has:CarePlan:patient:status', 'active');
        }
        /*
          Bugfix 1044, added for the button to force refresh of the lists
        */
        let promise;
        if (disableCache) {
            promise = this.patientApi.disableCache().search({ name: fullName }, extraParams).toPromise();
        }
        else {
            promise = this.patientApi.search({ name: fullName }, extraParams).toPromise();
        }
        if (callback) {
            return promise.then((bundle) => {
                if (bundle && bundle.entry) {
                    if (retrieveAll) {
                        return this.bundleUtils.mergeBundleIncrementally(bundle, callback);
                    }
                    else {
                        const items = bundle.entry.map((entry) => entry.resource);
                        return callback(items, items);
                    }
                }
                else {
                    return callback([], []);
                }
            });
        }
        else {
            return promise
                .then((bundle) => {
                if (bundle && bundle.entry) {
                    if (retrieveAll) {
                        return this.bundleUtils.mergeBundle(bundle);
                    }
                    else {
                        return Promise.resolve(bundle.entry.map((entry) => entry.resource));
                    }
                }
                else {
                    return Promise.resolve([]);
                }
            })
                .then((res) => {
                return res instanceof Bundle
                    ? res.entry.map((entry) => this.fhirConverter.toDataModel(entry.resource))
                    : res.map((fhir) => this.fhirConverter.toDataModel(fhir));
            });
        }
    }
    /**
     *
     * @param uuid - matches with the identifier field in the server FHIR using the UUID
     */
    async searchPatientByUUID(uuid) {
        return this.patientApi
            .search({
            identifier: uuid, // 'UID|' + uuid
        })
            .toPromise()
            .then((bundle) => (bundle.entry ? bundle.entry?.map((entry) => this.fhirConverter.toDataModel(entry.resource)).pop() : undefined));
    }
    async searchPatientByUsername(username) {
        return super.searchUserByUsername(username).then((user) => user?.person);
    }
    async searchPatientsByReferences(references) {
        const refs = references?.map((r) => ModelToFHIRUtils.getReference(r).reference) || [];
        if (refs.length === 0) {
            return [];
        }
        const extraParams = new Map();
        extraParams.set('_id', refs.join(','));
        return this.patientApi
            .search({}, extraParams)
            .toPromise()
            .then((bundle) => bundle?.entry?.map((entry) => this.fhirConverter.toDataModel(entry.resource)).filter((p) => !!p) || []);
    }
    async create(patient) {
        return this.patientApi
            .create(this.fhirConverter.fromDataModel(patient))
            .toPromise()
            .then((res) => res.location);
    }
    async createFHIRPatient(patient) {
        return this.patientApi
            .create(patient)
            .toPromise()
            .then((res) => res.location);
    }
    async update(patient) {
        return this.patientApi
            .update(patient.id, this.fhirConverter.fromDataModel(patient))
            .toPromise()
            .then((res) => res.id);
    }
    /*   public async isPseudonymAvailable(pseudonym: string): Promise<boolean> {
      return this.patientApi
            .search({
              // FIXME: use '<system>|pseudonym'?
              identifier: pseudonym,
            })
            .toPromise()
            .then((res) => res.entry?.length > 0);
    } */
    async isPseudonymAvailable(pseudonym) {
        const res = await this.patientApi
            .search({
            identifier: pseudonym,
        })
            .toPromise();
        // Controllare solo che length fosse maggiore di zero pare non fosse sufficente
        // Nel caso che il .search non trovi nulla, il parametro .entry è undefined ed il check errato
        // in questo modo controlliamo che entry è undefined e ciò vuol dire che lo pseudonimo è disponibile
        // Solo se entry esiste ed il suo valore è superiore a zero, allora lo pseudonimo NON è disponibile
        return res.entry == undefined || res.entry?.length <= 0;
    }
    async getAllChatSettings(practitioner) {
        const practitionerId = practitioner.fhirId + '';
        let path = this.restApiFullUrl + '/channels/settings/Practitioner/{practitionerId}'.replace('{practitionerId}', practitionerId);
        const headerParams = this.baseHeaders;
        return this.http
            .get(path, { headers: headerParams })
            .toPromise()
            .then((ps) => {
            return ps?.length > 0 ? ps.map((s) => ChatSettings.revive(s)) : [];
        });
    }
    async getChatSettings(patient, practitioner) {
        const patientId = patient.fhirId + '';
        const practitionerId = practitioner.fhirId + '';
        let path = this.restApiFullUrl + '/channels/settings/Patient/{patientId}/Practitioner/{practitionerId}'.replace('{patientId}', patientId).replace('{practitionerId}', practitionerId);
        const headerParams = this.baseHeaders;
        return this.http
            .get(path, { headers: headerParams })
            .toPromise()
            .then((ps) => {
            if (!ps) {
                return undefined;
            }
            if (Array.isArray(ps)) {
                return ps?.length > 0 ? ChatSettings.revive(ps[0]) : undefined;
            }
            else {
                return ChatSettings.revive(ps);
            }
        });
    }
    async saveChatSettings(chatSettings) {
        const patientId = chatSettings.patient.fhirId + '';
        const practitionerId = chatSettings.practitioner.fhirId + '';
        let path = this.restApiFullUrl + '/channels/settings/Patient/{patientId}/Practitioner/{practitionerId}'.replace('{patientId}', patientId).replace('{practitionerId}', practitionerId);
        const headerParams = this.baseHeaders;
        return this.http
            .put(path, chatSettings, {
            headers: headerParams,
        })
            .toPromise()
            .then((id) => {
            // chatSettings.id = +id;
            return chatSettings;
        });
    }
    async updateObservePatient(observe) {
        const ci = this.fhirConverter.fromDataModel(observe);
        if (observe.id) {
            return this.clinicalImpressionApi
                .update(ci.getReference().getReferenceIdPart(), ci)
                .toPromise()
                .then((r) => {
                return observe;
            });
        }
        else {
            return this.clinicalImpressionApi
                .create(ci)
                .toPromise()
                .then((res) => {
                observe.id = res.location ? res.location : undefined;
                return observe;
            });
        }
    }
    async updatePatientHealthStatus(healthStatus) {
        const obs = this.fhirConverter.fromDataModel(healthStatus);
        // IMPORTANT: obs id is always != undefined
        if (healthStatus.id) {
            return this.observationApi
                .update(obs.getReference().getReferenceIdPart(), obs)
                .toPromise()
                .then((r) => {
                return healthStatus;
            });
        }
        else {
            return this.observationApi
                .create(obs)
                .toPromise()
                .then((res) => {
                healthStatus.id = res.location ? res.location : undefined;
                return healthStatus;
            });
        }
    }
    searchPatientsWithVCF() {
        // vorrei solo i pazienti che hanno un VCF consultabile - NON I VCF in questo momento
        const extraParams = new Map();
        extraParams.set('_has:DiagnosticReport:patient:code', '81247-9');
        return this.patientApi
            .search({}, extraParams)
            .toPromise()
            .then((bundle) => this.bundleUtils.mergeBundle(bundle))
            .then((bundle) => bundle?.entry
            ?.filter((entry) => entry.resource instanceof Patient)
            .map((entry) => {
            return this.fhirConverter.toDataModel(entry.resource, bundle);
        }));
    }
}

class BackendPractitionerConnector extends BackendUserConnector {
    constructor(http, restApiFullUrl, fhirBaseFullUrl, userApis, exceptionHandler, fhirConverter) {
        super(http, restApiFullUrl, userApis, exceptionHandler, fhirConverter);
        this.practitionerApi = new PractitionerApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    async registerUser(user) {
        return super.registerUser(user);
    }
    async eraseUserAndData(practitioner) {
        return super.eraseUserAndData(practitioner);
    }
    /**
     *
     * @param fullName - matches any of the string fields in the FHIR HumanName, including family, give, prefix, suffix, suffix, and/or text
     */
    async searchPractitionersByName(fullName, organization) {
        const extraParams = new Map();
        const reference = ModelToFHIRUtils.getReference(organization);
        if (organization) {
            extraParams.set('_has:PractitionerRole:practitioner:organization', reference.reference);
        }
        return lastValueFrom(this.practitionerApi.search({
            name: fullName,
        }, extraParams)).then((bundle) => {
            return (bundle?.entry?.map((entry) => this.newPractitionerWithRole(entry.resource)) || []);
        });
    }
    /**
     *
     * @param uuid - matches with the identifier field in the server FHIR using the UUID
     */
    async searchPractitionerByUUID(uuid) {
        const extraParams = new Map();
        extraParams.set('_revinclude', 'PractitionerRole:practitioner');
        extraParams.set('_include:iterate', 'PractitionerRole:organization');
        return lastValueFrom(this.practitionerApi.search({
            identifier: uuid, // 'UID|' + uuid
        }, extraParams)).then((bundle) => {
            if (bundle?.entry?.length > 0) {
                const practitioner = bundle.entry
                    ?.filter((entry) => entry.search.mode === 'match')
                    .map((entry) => entry.resource)
                    .pop();
                const practitionerRoles = bundle.entry
                    ?.filter((entry) => {
                    return (entry.search.mode === 'include' &&
                        entry.resource instanceof DomainResource &&
                        entry.resource.resourceType === 'PractitionerRole');
                })
                    .map((entry) => entry.resource);
                const organizations = bundle.entry
                    ?.filter((entry) => {
                    return (entry.search.mode === 'include' &&
                        entry.resource instanceof DomainResource &&
                        entry.resource.resourceType === 'Organization');
                })
                    .map((entry) => entry.resource);
                return this.newPractitionerWithRole(practitioner, practitionerRoles, organizations);
            }
            return undefined;
        });
    }
    /**
     *
     * @param uuid - matches with the identifier field in the server FHIR using the UUID
     */
    async searchPractitionerByReference(stub) {
        const reference = ModelToFHIRUtils.getReference(stub);
        const ref = reference.reference;
        const extraParams = new Map();
        extraParams.set('_revinclude', 'PractitionerRole:practitioner');
        extraParams.set('_include:iterate', 'PractitionerRole:organization');
        return lastValueFrom(this.practitionerApi.search({
            id: ref,
        }, extraParams)).then((bundle) => {
            if (bundle?.entry?.length > 0) {
                const practitioner = bundle.entry
                    ?.filter((entry) => entry.search.mode === 'match')
                    .map((entry) => entry.resource)
                    .pop();
                const practitionerRoles = bundle.entry
                    ?.filter((entry) => {
                    return (entry.search.mode === 'include' &&
                        entry.resource instanceof DomainResource &&
                        entry.resource.resourceType === 'PractitionerRole');
                })
                    .map((entry) => entry.resource);
                const organizations = bundle.entry
                    ?.filter((entry) => {
                    return (entry.search.mode === 'include' &&
                        entry.resource instanceof DomainResource &&
                        entry.resource.resourceType === 'Organization');
                })
                    .map((entry) => entry.resource);
                return this.newPractitionerWithRole(practitioner, practitionerRoles, organizations);
            }
            return undefined;
        });
    }
    /**
     *
     * @param id - FHIR ID
     */
    async searchPractitionerById(id) {
        return lastValueFrom(this.practitionerApi.getById(id)).then((fhirPractitioner) => {
            if (fhirPractitioner) {
                return this.fhirConverter.toDataModel(fhirPractitioner);
            }
            return undefined;
        });
    }
    async searchPractitionerByUsername(username) {
        return super
            .searchUserByUsername(username)
            .then((user) => user?.person);
    }
    async createFHIRPractitioner(practitioner) {
        return lastValueFrom(this.practitionerApi.create(practitioner)).then((res) => res.location);
    }
    async update(practitioner) {
        await lastValueFrom(this.practitionerApi.update(+practitioner.fhirId, this.fhirConverter.fromDataModel(practitioner)));
    }
    newPractitionerWithRole(practitioner, practitionerRoles, organizations) {
        const hcp = this.fhirConverter.converterService.person.toDataModelHealthCareProfessional(practitioner, practitionerRoles, organizations);
        return hcp;
    }
}

// prettier-ignore
class BackendProcedureConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        // this.baseHeaders = new HttpHeaders({
        //     'Content-Type': 'application/json',
        //     'Accept': 'application/json',
        // });
        this.fhirConverter = fhirConverter;
        this.procedureApi = new ProcedureApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    async searchWorkoutByPatient(patient, 
    // type: HeartValueSet.Common.Measurement,
    period, limit) {
        const patientRef = ModelToFHIRUtils.getReference(patient);
        let extraParams = new Map();
        if (limit > 0) {
            extraParams = extraParams.set('_count', '' + limit);
        }
        if (period) {
            const dateRange = [];
            if (period.from) {
                dateRange.push('ge' + period.from);
            }
            if (period.to) {
                dateRange.push('le' + period.to);
            }
            extraParams = extraParams.set('date', dateRange);
        }
        const promise = this.procedureApi
            .search({
            patient: patientRef,
            code: HeartValueSet.Common.Measurement.PHYSICAL_ACTIVITY_CODINGS.code
        }, extraParams)
            .toPromise();
        return promise
            .then((bundle) => {
            if (bundle && bundle.entry) {
                return this.bundleUtils.mergeBundle(bundle);
            }
            else {
                return Promise.resolve([]);
            }
        })
            .then((res) => {
            return res instanceof Bundle
                ? res.entry
                    .map((entry) => entry.resource)
                    .map((fhir) => this.fhirConverter.toDataModel(fhir))
                : res?.map((fhir) => this.fhirConverter.toDataModel(fhir));
        });
    }
    async searchByReference(stub) {
        const reference = ModelToFHIRUtils.getReference(stub);
        const ref = reference.reference;
        return this.procedureApi
            .getById(ref)
            .toPromise()
            .then((fhir) => this.fhirConverter.toDataModel(fhir));
    }
}

class BackendQuestionnaireConnector {
    constructor(http, restApiFullUrl, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        // this.baseHeaders = new HttpHeaders({
        //     'Content-Type': 'application/json',
        //     'Accept': 'application/json',
        // });
        this.fhirConverter = fhirConverter;
        // questionnaire cache
        this.cache = {};
        // valueset cache. the cache maintains an array of codedvalues for each valueset URL
        this.valueSetCache = {};
        // STD dictionaries included statically
        this.standardDictionaryYesNoDontKnow = [
            new CodedValue('http://terminology.hl7.org/CodeSystem/v2-0532', 'Y', BackendQuestionnaireConnector.PREFIX + 'http://terminology.hl7.org/CodeSystem/v2-0532' + BackendQuestionnaireConnector.SEPARATOR + 'Y' + BackendQuestionnaireConnector.SUFFIX),
            new CodedValue('http://terminology.hl7.org/CodeSystem/v2-0532', 'N', BackendQuestionnaireConnector.PREFIX + 'http://terminology.hl7.org/CodeSystem/v2-0532' + BackendQuestionnaireConnector.SEPARATOR + 'N' + BackendQuestionnaireConnector.SUFFIX),
            new CodedValue('http://terminology.hl7.org/CodeSystem/data-absent-reason', 'asked-unknown', BackendQuestionnaireConnector.PREFIX +
                'http://terminology.hl7.org/CodeSystem/data-absent-reason' +
                BackendQuestionnaireConnector.SEPARATOR +
                'asked-unknown' +
                BackendQuestionnaireConnector.SUFFIX),
        ];
        this.isValuesetToBeExpanded = (q) => typeof q.permittedAnswers == 'string';
        this.questionnaireApi = new QuestionnaireApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.questionnaireResponseApi = new QuestionnaireResponseApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        // this.valueSetApi = new ValueSetApi(
        //   http,
        //   fhirBaseFullUrl,
        //   undefined,
        //   exceptionHandler
        // );
        this.terminologyValueSetApi = new TerminologyValueSetApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        // this.codeSystemApi = new CodeSystemApi(
        //   http,
        //   fhirBaseFullUrl,
        //   undefined,
        //   exceptionHandler
        // );
        // this.bundleUtils = new BundleUtilityApi(
        //   http,
        //   fhirBaseFullUrl,
        //   undefined,
        //   exceptionHandler
        // );
        this.createStandardDictionaryCache();
    }
    createStandardDictionaryCache() {
        this.valueSetCache['http://hl7.org/fhir/ValueSet/yesnodontknow'] = this.standardDictionaryYesNoDontKnow.map((cv) => new Choice(cv));
    }
    /**
     *
     * @param nName - matches any of the string field name/alias
     */
    async search(ignoreExpansionForValueSets, sortValues = true) {
        const search = this.questionnaireApi.search({});
        const bundle = await lastValueFrom(search);
        const questionnaires = bundle?.entry?.map((entry) => entry.resource).map((fhir) => this.fhirConverter.toDataModel(fhir)) || [];
        for (let i = 0; i < questionnaires.length; i++) {
            const q = questionnaires[i];
            if (this.cache[q.id]) {
                // feches expanded questionnaires from the cache
                questionnaires[i] = this.cache[q.id];
            }
            else {
                await this.expandQuestionnaireValuesets(q, ignoreExpansionForValueSets, sortValues);
                // cache the fetched (and expanded) questionnaire to improve future searches
                this.cache[q.questionnaireId] = q;
            }
        }
        return Promise.resolve(questionnaires);
    }
    /**
     * Expand any occurrence of a ValueSet URL in the Questionnaire items
     *
     * For performance reason the method creates a temporary cache
     *
     * @param questionnaire
     */
    async expandQuestionnaireValuesets(questionnaire, ignoreExpansionForValueSets, sortValues) {
        let valuesetsToBeExpanded = [];
        // create a map of ValueSet to be expanded
        this.extractValuesetToBeExpanded(questionnaire.items, valuesetsToBeExpanded);
        // exclude from the 'valuesetsToBeExpanded' array the valueset to be ignored
        if (ignoreExpansionForValueSets) {
            const ignoreExpansionForValueSetsURL = ignoreExpansionForValueSets.map((vs) => vs.system);
            valuesetsToBeExpanded = valuesetsToBeExpanded.filter((v) => !ignoreExpansionForValueSetsURL.includes(v));
        }
        // if there are valueset than it expands them
        if (valuesetsToBeExpanded.length > 0) {
            // promise expanding the valuesest and enriching the 'valueSetCache'
            await this.fetchValueSets(uniq(valuesetsToBeExpanded), sortValues);
            // check if there are "choices" of type string and, in case, expand them
            this.setChoices(questionnaire.items);
        }
    }
    extractValuesetToBeExpanded(items, valuesetsToBeExpanded) {
        for (let i = 0; i < items.length; i++) {
            var item = items[i];
            if (item instanceof Question && this.isValuesetToBeExpanded(item)) {
                valuesetsToBeExpanded.push(item.permittedAnswers);
            }
            if (item.items?.length > 0) {
                this.extractValuesetToBeExpanded(item.items, valuesetsToBeExpanded);
            }
        }
    }
    setChoices(items) {
        if (!items) {
            return;
        }
        for (const item of items) {
            this.setChoices(item.items);
            if (item instanceof Question) {
                // la domanda FOGLIA
                if (this.isValuesetToBeExpanded(item)) {
                    const url = item.permittedAnswers;
                    item.permittedAnswers = this.valueSetCache[url] || [];
                }
            }
        }
    }
    async fetchValueSets(urls = [], sortValues) {
        for (let index = 0; index < urls.length; index++) {
            const url = urls[index];
            if (this.valueSetCache[url]) {
                // as the URL has already been expanded there is no need to query the server
                // so remove it from the input array
                urls.splice(index, 1);
            }
        }
        if (urls.length == 0) {
            // in case that there are no urls to solve avoid the following code
            return;
        }
        // an alternative is to run ../base/ValueSet/$expand?url=<URL> that return the codes in ValueSet.expansion.contains[*]
        // but it can expand one ValueSet at the time
        for (let urlIndex = 0; urlIndex < urls.length; urlIndex++) {
            const _url = urls[urlIndex];
            const vs = await lastValueFrom(this.terminologyValueSetApi.expand({ url: _url }));
            let cv = vs.expansion?.contains?.map((concept) => {
                const system = concept.system;
                const code = concept.code;
                const display = BackendQuestionnaireConnector.PREFIX + system + BackendQuestionnaireConnector.SEPARATOR + code + BackendQuestionnaireConnector.SUFFIX;
                const originalDisplay = concept.display;
                return new CodedValue(system, code, display, originalDisplay);
            });
            if (sortValues) {
                // sort only if the developer needs it
                cv = cv.sort((cv1, cv2) => cv1?.code.localeCompare(cv2?.code));
            }
            const ch = cv.map((cv) => new Choice(cv)) || [];
            if (ch.length > 0) {
                // cache the expanded valuesets
                this.valueSetCache[_url] = ch;
            }
        }
        //
        // NOTE: the following code is a 'manual' alternative to invoking the ValueSet$expand (to be used if the $expand is not supported by the server)
        //
        // const extraParam = new Map<string, any>();
        // extraParam.set('url', urls.join(','));
        // const search = this.valueSetApi.search({ }, extraParam);
        // let bundle = await lastValueFrom(search);
        // // just in case there are too many pages
        // bundle = await this.bundleUtils.mergeBundle(bundle);
        // // extract entries
        // const valueSets: FHIRValueSet[] = bundle?.entry
        //   ?.map((entry) => entry.resource as FHIRValueSet)
        //   ?.filter((entry) => entry != undefined) || [];
        // var codeSystemCache = {};
        // for (let valueSetsIndex = 0; valueSetsIndex < valueSets.length; valueSetsIndex++ ) {
        //   var entry : FHIRValueSet = valueSets[valueSetsIndex];
        //   const _url : string = entry.url // chiave della cache
        //   const cv : CodedValue[] = [];
        //   let conceptSets = entry.compose?.include || [];
        //   for (let conceptsIndex = 0; conceptsIndex < conceptSets?.length; conceptsIndex++) {
        //     var cs = conceptSets[conceptsIndex];
        //     const system = cs.system;
        //     let concepts: FHIRValueSet.ConceptReferenceComponent[] | FHIRCodeSystem.ConceptDefinitionComponent[] = cs.concept || [];
        //     if ( !(concepts.length > 0) && system ) {
        //       if ( codeSystemCache[system] ) {
        //         concepts = codeSystemCache[system];
        //       } else {
        //         const obs = this.codeSystemApi.search( {url: system} );
        //         const codeSystemBundle = await lastValueFrom(obs);
        //         if ( codeSystemBundle && codeSystemBundle.entry?.length > 0 ) {
        //           concepts = (codeSystemBundle.entry[0].resource as FHIRCodeSystem).concept;
        //           codeSystemCache[system] = concepts;
        //         }
        //       }
        //     }
        //     concepts?.forEach(concept => {
        //       const display: string = BackendQuestionnaireConnector.PREFIX + system + BackendQuestionnaireConnector.SEPARATOR + concept.code + BackendQuestionnaireConnector.SUFFIX;
        //       const originalDisplay = concept.display;
        //       cv.push(new CodedValue(system, concept.code, display, originalDisplay));
        //     });
        //   }
        //   // cache the expanded valuesets
        //   this.valueSetCache[_url] = cv.map((cv : CodedValue) => new Choice(cv));
        // }
    }
    async searchByReference(reference, ignoreExpansionForValueSets, sortValues = true) {
        const ref = reference.questionnaireId;
        if (this.cache[ref]) {
            return Promise.resolve(this.cache[ref]);
        }
        const search = this.questionnaireApi.search({ url: ref });
        const bundle = await lastValueFrom(search);
        const responses = bundle?.entry?.map((entry) => entry.resource).map((fhir) => this.fhirConverter.toDataModel(fhir)) || [];
        let questionnaire = undefined;
        // there can be at most 1 questionnaire in the answer
        if (responses?.length > 0) {
            questionnaire = responses[0];
            await this.expandQuestionnaireValuesets(questionnaire, ignoreExpansionForValueSets, sortValues);
            // cache the fetched (and expanded) questionnaire to improve future searches
            this.cache[questionnaire.questionnaireId] = questionnaire;
        }
        return questionnaire;
    }
    async createResponse(response, author, encounter) {
        let fhir;
        fhir = this.fhirConverter.fromDataModel(response);
        if (author) {
            fhir.author = ModelToFHIRUtils.getReference(author);
        }
        fhir.encounter = ModelToFHIRUtils.getReference(encounter);
        const createObs = this.questionnaireResponseApi.create(fhir);
        const res = await lastValueFrom(createObs);
        response.id = res?.location;
        return response;
    }
    async hasResponse(questionnaireReference, patient) {
        const extra = new Map();
        extra.set('_summary', 'count');
        const searchObs = this.questionnaireResponseApi.search({
            patient: ModelToFHIRUtils.getReference(patient),
            questionnaire: new Reference({ reference: questionnaireReference?.questionnaireId }),
        }, extra);
        const bundle = await lastValueFrom(searchObs);
        // when using '_summary=count' the bundle total returns a count of the matching resources, without returning the actual matches
        return bundle?.total > 0;
    }
    async searchResponse(questionnaireReference, patient, repeatableAnswerGroupIDs, latest = false) {
        let extraParams = new Map();
        if (latest) {
            //    _sort=-authored&_count=1
            extraParams = extraParams.set('_sort', '-authored');
            extraParams = extraParams.set('_count', '1');
        }
        const bundle = await lastValueFrom(this.questionnaireResponseApi.search({
            patient: ModelToFHIRUtils.getReference(patient),
            questionnaire: new Reference({ reference: questionnaireReference?.questionnaireId }),
        }, extraParams));
        const bundleWithURLs = this.createQuestionnaireResponseContext(repeatableAnswerGroupIDs);
        return bundle?.entry?.map((entry) => entry.resource)?.map((fhir) => this.fhirConverter.toDataModel(fhir, bundleWithURLs)) || []; // FIXME: punto per possibile buco
    }
    createQuestionnaireResponseContext(repeatableAnswerGroupIDs) {
        const bundleWithURLs = new Bundle();
        if (repeatableAnswerGroupIDs) {
            const ns = new NamingSystem();
            ns.uniqueId = repeatableAnswerGroupIDs.map((id) => {
                const uniqueId = new NamingSystem.NamingSystemUniqueIdComponent();
                uniqueId.value = id;
                return uniqueId;
            });
            const entry = new Bundle.BundleEntryComponent();
            entry.resource = ns;
            bundleWithURLs.entry = [entry];
        }
        return bundleWithURLs;
    }
    async updateResponse(response, author, encounter) {
        if (response.id == undefined) {
            throw new Error(`Error while updating the QuestionnaireResponse as the FHIR ID is missing.`);
        }
        let fhir;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        fhir = this.fhirConverter.fromDataModel(response);
        fhir.author = ModelToFHIRUtils.getReference(author);
        fhir.encounter = ModelToFHIRUtils.getReference(encounter);
        const update = this.questionnaireResponseApi.update(response.id, fhir);
        await lastValueFrom(update);
        return response;
    }
    async updateStatus(questionnaireResponse, status, author) {
        if (questionnaireResponse?.id == undefined) {
            throw new Error(`Invalid QuestionnaireResponse. Expected item with an ID to update the response status`);
        }
        let statusStr;
        switch (status) {
            case ResponseStatus.inprogress:
                statusStr = 'in-progress';
                break;
            case ResponseStatus.completed:
                statusStr = 'completed';
                break;
            case ResponseStatus.amended:
                statusStr = 'amended';
                break;
            case ResponseStatus.enteredinerror:
                statusStr = 'entered-in-error';
                break;
            case ResponseStatus.stopped:
                statusStr = 'stopped';
                break;
        }
        const patches = [];
        if (statusStr) {
            patches.push({
                op: 'replace',
                path: '/status',
                value: statusStr,
            });
        }
        if (author) {
            patches.push({
                op: 'replace',
                path: '/author/reference',
                // value: new Reference({ reference: ((author instanceof Patient) ? 'Patient/' : 'Practitioner/') + author?.id }),
                value: (author instanceof Patient$1 ? 'Patient/' : 'Practitioner/') + author?.id,
            });
        }
        const promise = lastValueFrom(this.questionnaireResponseApi.patch(questionnaireResponse.id, { jsonPatchBody: patches }));
        return promise.then(() => {
            if (author) {
                questionnaireResponse.author = author;
            }
            if (statusStr) {
                questionnaireResponse.status = status;
            }
            return questionnaireResponse;
        });
    }
}
// construction of string to display
BackendQuestionnaireConnector.PREFIX = 'questionnaire.';
BackendQuestionnaireConnector.SEPARATOR = '|';
BackendQuestionnaireConnector.SUFFIX = '.label';

class BackendServerConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        // this.baseHeaders = new HttpHeaders({
        //     'Content-Type': 'application/json',
        //     'Accept': 'application/json',
        // });
        this.fhirConverter = fhirConverter;
        this.basic = new BasicApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    transaction(resources) {
        return this.basic
            .transaction(resources)
            .toPromise()
            .then((bundle) => bundle && bundle.entry && !!bundle.entry[0]);
    }
    transactionWithShareable(resources) {
        if (!(resources?.length > 0)) {
            return Promise.resolve(false);
        }
        return this.basic
            .transaction(resources.map((r) => this.fhirConverter.fromDataModel(r)))
            .toPromise()
            .then((bundle) => bundle && bundle.entry && !!bundle.entry[0]);
    }
    batch(resources) {
        return this.basic
            .transaction(resources, [], true)
            .toPromise()
            .then((bundle) => bundle && bundle.entry && !!bundle.entry[0]);
    }
}

// prettier-ignore
class BackendDocRefConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        this.fhirConverter = fhirConverter;
        this.docRefApi = new DocumentReferenceApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    // at least one document with the specific code or system|code
    // isDocumentPresent(patient : Patient, documentReferenceSystemCode: string): Promise<boolean | void> {
    //   const ABUNDANCE_MATRIX_TYPE = `http://it4h.eng.it/uhm/CodeSystem/preprocessed-data-type\|${documentReferenceSystemCode}`;
    //   // throw new Error('Method not implemented.');
    //   const extraParams: Map<string, any> = new Map<string, any>();
    //   extraParams.set(
    //     '_summary',
    //     'count'
    //   );
    //   return this.docRefApi
    //   .search({patient: this.fhirConverter.getFHIRReference(patient), type: ABUNDANCE_MATRIX_TYPE}, extraParams).toPromise()
    //   .then((bundle) => this.bundleUtils.mergeBundle(bundle))
    //   .then((bundle) => {
    //     return bundle.entry.length > 0
    //     }
    //     // bundle?.entry
    //     //   ?.filter((entry) => entry.resource instanceof DocumentReference)
    //     //   .map(
    //     //     (entry) => {
    //     //       return entry != undefined
    //     //     }
    //     //   )
    //   )
    // }
    retrieveDocumentReferencesForTypes(docRefCVs, patientId) {
        const extraParams = new Map();
        if (patientId != undefined) {
            extraParams.set('subject', patientId);
        }
        extraParams.set('_elements', '_id,subject,type,date');
        const allTypes = docRefCVs.map(cv => cv.code).join(",");
        return this.docRefApi
            .search({ type: allTypes }, extraParams).toPromise()
            .then((bundle) => { return this.bundleUtils.mergeBundle(bundle); })
            .then((bundle) => {
            return bundle?.entry
                ?.filter((entry) => entry.resource instanceof DocumentReference)
                .map((entry) => {
                // splitted for debug purpose
                const res = entry.resource;
                const id = +res.subject.reference.split("/")[1];
                const cv = ModelToFHIRUtils.toCodedValueModel(res.type);
                const date = res.date ?? new Date();
                const docRef = new DocRef(id, cv, date);
                return docRef;
            });
        });
    }
}
// solo il totale delle occorrenze:
// /base/DocumentReference?_summary=count&patient=Patient/XXXX&type=
// http://it4h.eng.it/uhm/CodeSystem/preprocessed-data-type
// |<type>
// DocumentReference?category=http://it4h.eng.it/uhm/CodeSystem/preprocessed-data-category|preprocessed-data&
// type=http://it4h.eng.it/uhm/CodeSystem/preprocessed-data-type
// |<type>
// <type> uno tra
// iit-genomic-vector
// abundance-matrix-proteomic
// abundance-matrix-lipidomic

class BackendEncounterConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        this.fhirConverter = fhirConverter;
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.encounterApi = new EncounterApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    async searchEncountersByPatient(patient, disableCache, retrieveAll, callback) {
        let api = this.encounterApi;
        /*
          Bugfix 1044, added for the button to force refresh of the lists
        */
        if (disableCache) {
            api = this.encounterApi;
        }
        const bundle = await lastValueFrom(api.search({
            patient: this.fhirConverter.getFHIRReference(patient),
        }));
        if (callback) {
            if (bundle && bundle.entry) {
                if (retrieveAll) {
                    return this.bundleUtils.mergeBundleIncrementally(bundle, callback);
                }
                else {
                    const encounters = bundle.entry?.filter((entry) => entry.resource.resourceType == 'Encounter').map((entry) => entry.resource, bundle);
                    return callback(encounters);
                }
            }
            else {
                return callback([]);
            }
        }
        else {
            let res;
            if (bundle && bundle.entry) {
                if (retrieveAll) {
                    res = await this.bundleUtils.mergeBundle(bundle);
                }
                else {
                    // FIXME
                    res = bundle.entry?.filter((entry) => entry.resource.resourceType == 'Encounter').map((entry) => entry.resource, bundle);
                }
            }
            else {
                res = [];
            }
            if (res instanceof Bundle) {
                return res.entry
                    ?.filter((entry) => entry.resource.resourceType == 'Encounter')
                    .map((entry) => this.fhirConverter.toDataModel(entry.resource, res));
            }
            else {
                return res.map((entry) => this.fhirConverter.toDataModel(entry));
            }
        }
    }
    async searchByReference(reference) {
        const ref = ModelToFHIRUtils.getReference(reference).reference;
        return this.encounterApi
            .getById(ref)
            .toPromise()
            .then((fhir) => this.fhirConverter.toDataModel(fhir));
    }
    async create(encounter) {
        const fhirEnc = this.fhirConverter.fromDataModel(encounter);
        const createEnc = this.encounterApi.create(fhirEnc);
        const res = await lastValueFrom(createEnc);
        encounter.id = res?.location;
        return encounter;
    }
    async update(updateEncounter) {
        if (updateEncounter.id == undefined) {
            throw new Error(`Error while updating the Condition as the FHIR ID is missing.`);
        }
        let fhir;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        fhir = this.fhirConverter.fromDataModel(updateEncounter);
        const update = this.encounterApi.update(updateEncounter.id, fhir);
        await lastValueFrom(update);
        return;
    }
    async searchEncountersByProvider(provider, disableCache, retrieveAll, callback) {
        let api = this.encounterApi;
        /*
          Bugfix 1044, added for the button to force refresh of the lists
        */
        if (disableCache) {
            api = this.encounterApi;
        }
        const bundle = await lastValueFrom(api.search({
            service_provider: this.fhirConverter.getFHIRReference(provider),
        }));
        if (callback) {
            if (bundle && bundle.entry) {
                if (retrieveAll) {
                    return this.bundleUtils.mergeBundleIncrementally(bundle, callback);
                }
                else {
                    const encounters = bundle.entry?.filter((entry) => entry.resource.resourceType == 'Encounter').map((entry) => entry.resource, bundle);
                    return callback(encounters);
                }
            }
            else {
                return callback([]);
            }
        }
        else {
            let res;
            if (bundle && bundle.entry) {
                if (retrieveAll) {
                    res = await this.bundleUtils.mergeBundle(bundle);
                }
                else {
                    // FIXME
                    res = bundle.entry?.filter((entry) => entry.resource.resourceType == 'Encounter').map((entry) => entry.resource, bundle);
                }
            }
            else {
                res = [];
            }
            if (res instanceof Bundle) {
                return res.entry
                    ?.filter((entry) => entry.resource.resourceType == 'Encounter')
                    .map((entry) => this.fhirConverter.toDataModel(entry.resource, res));
            }
            else {
                return res.map((entry) => this.fhirConverter.toDataModel(entry));
            }
        }
    }
    async searchEncounters() {
        const bundle = await lastValueFrom(this.encounterApi.search({}));
        const encounters = bundle?.entry
            ?.filter((entry) => entry.resource.resourceType == 'Encounter')
            ?.map((entry) => this.fhirConverter.toDataModel(entry.resource, bundle)) || [];
        return Promise.resolve(encounters);
    }
    async enrichEncounter(partialEncounter, retrieveAll = true) {
        // TODO: quando sapremo le altre risorse di encounter (easy) aggiungere le classi e attributi dopo 'QuestionnaireResponse.encounter'
        const promise = lastValueFrom(this.encounterApi.search({
            id: ModelToFHIRUtils.getReference(partialEncounter).reference,
            _revinclude: ['QuestionnaireResponse:encounter', 'Condition:encounter', 'Observation:encounter', 'ServiceRequest:encounter', 'DocumentReference:context'],
        }));
        const encs = await promise
            .then((bundle) => {
            if (bundle && bundle.entry) {
                if (retrieveAll) {
                    return this.bundleUtils.mergeBundle(bundle);
                }
                else {
                    return Promise.resolve(
                    // bundle.entry.map((entry) => entry.resource as FhirEncounter)
                    bundle.entry.filter((i) => i.resource.resourceType == 'Encounter').map((entry) => entry.resource));
                }
            }
            else {
                return Promise.resolve([]);
            }
        })
            .then((res) => {
            return res instanceof Bundle
                ? res.entry.filter((i) => i.resource.resourceType == 'Encounter').map((entry) => this.fhirConverter.toDataModel(entry.resource, res))
                : res.map((fhir) => this.fhirConverter.toDataModel(fhir));
        });
        return Promise.resolve(encs.length > 0 ? encs[0] : partialEncounter);
    }
}

class BackendEpisodeConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        this.fhirConverter = fhirConverter;
        this.episodeApi = new EpisodeOfCareApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.encounterApi = new EncounterApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    async searchEpisodesByPatient(patient, disableCache = false, retrieveAll = false, callback) {
        let api = this.episodeApi;
        /*
          Bugfix 1044, added for the button to force refresh of the lists
        */
        if (disableCache) {
            api = this.episodeApi;
        }
        const promise = api
            .search({
            patient: this.fhirConverter.getFHIRReference(patient),
            _revinclude: ['Encounter:episode-of-care']
        })
            .toPromise();
        if (callback) {
            return promise.then((bundle) => {
                if (bundle && bundle.entry) {
                    if (retrieveAll) {
                        return this.bundleUtils.mergeBundleIncrementally(bundle, callback);
                    }
                    else {
                        const episodes = bundle.entry
                            ?.filter(entry => entry.resource.resourceType == 'EpisodeOfCare')
                            .map((entry) => entry.resource, bundle);
                        return callback(episodes);
                    }
                }
                else {
                    return callback([]);
                }
            });
        }
        else {
            return promise
                .then((bundle) => {
                if (bundle && bundle.entry) {
                    if (retrieveAll) {
                        return this.bundleUtils.mergeBundle(bundle);
                    }
                    else {
                        // FIXME
                        const episodes = bundle.entry
                            ?.filter(entry => entry.resource.resourceType == 'EpisodeOfCare')
                            .map((entry) => entry.resource, bundle);
                        return Promise.resolve(episodes);
                    }
                }
                else {
                    return Promise.resolve([]);
                }
            })
                .then((res) => {
                if (res instanceof Bundle) {
                    return res.entry
                        ?.filter(entry => entry.resource.resourceType == 'EpisodeOfCare')
                        .map((entry) => this.fhirConverter.toDataModel(entry.resource, res));
                }
                else {
                    return res.map((entry) => this.fhirConverter.toDataModel(entry));
                }
            });
        }
    }
    /**
     *
     * @param nName - matches any of the string field name/alias
     */
    async searchEpisodes() {
        const request = lastValueFrom(this.episodeApi.search({
            _revinclude: ['Encounter:episode-of-care']
        }));
        return request.then((bundle) => bundle?.entry
            ?.filter(entry => entry.resource.resourceType == 'EpisodeOfCare')
            ?.map((entry) => this.fhirConverter.toDataModel(entry.resource, bundle)) || []);
    }
    async searchByReference(reference) {
        const ref = ModelToFHIRUtils.getReference(reference).reference;
        return this.episodeApi
            .getById(ref)
            .toPromise()
            .then((fhir) => this.fhirConverter.toDataModel(fhir));
    }
    // TODO: possibile punto in cui recuperare tutto l'oggetto Episode, compresi Encounters e suoi attributi
    /**
     * This method is used to enrich the data of an EpisodeOfCare a to implement a lazy loadng mechanism.
     *
     * When invoked all resources (e.g. QuestionnaireResponse, Condition, ...) related to a specific Encounter of an EpisodeOfCare are loaded from the server
     *
     * @param partialEpisode
     * @param retrieveAll
     * @returns
     */
    async enrichEpisode(partialEpisode, retrieveAll = true) {
        // TODO: per l'episodio passato in input, che contiene i dati parziali, bisogna scaricare tutto e resituire l'oggetto completo
        const completeEpisode = await this.searchByReference(partialEpisode);
        // const promise  = lastValueFrom(this.encounterApi.search({'episode_of_care' : ModelToFHIRUtils.getReference(partialEpisode)}))
        // TODO: quando sapremo le altre risorse di encounter (easy) aggiungere le classi e attributi dopo 'QuestionnaireResponse.encounter'
        const promise = lastValueFrom(this.encounterApi.search({
            'episode_of_care': ModelToFHIRUtils.getReference(partialEpisode),
            _revinclude: ['QuestionnaireResponse:encounter', "Condition:encounter", "Observation:encounter", "ServiceRequest:encounter"]
        }));
        const encs = await promise.then((bundle) => {
            if (bundle && bundle.entry) {
                if (retrieveAll) {
                    return this.bundleUtils.mergeBundle(bundle);
                }
                else {
                    return Promise.resolve(
                    // bundle.entry.map((entry) => entry.resource as FhirEncounter)
                    bundle.entry.filter(i => i.resource.resourceType == 'Encounter').map((entry) => entry.resource));
                }
            }
            else {
                return Promise.resolve([]);
            }
        })
            .then((res) => {
            return res instanceof Bundle
                ? res.entry.filter(i => i.resource.resourceType == 'Encounter').map((entry) => this.fhirConverter.toDataModel(entry.resource, res))
                : res.map((fhir) => this.fhirConverter.toDataModel(fhir));
        });
        // aggiunta degli encounters all'episodio
        completeEpisode.encounter = encs;
        // TODO: lo stesso bisognerebbe fare per ogni attributo dell'encounter
        return Promise.resolve(completeEpisode);
    }
    async create(episode) {
        const fhirEoC = this.fhirConverter.fromDataModel(episode);
        const encounters = fhirEoC.contained || [];
        if (encounters?.length > 0) {
            // uses 'contained' as temporary variable
            fhirEoC.contained = undefined;
        }
        return this.episodeApi
            .transaction([fhirEoC, ...encounters])
            .toPromise()
            .then((res) => {
            const entries = res.entry;
            if (entries[0].response?.location) {
                episode.id = +this.getIdFromLocation(entries[0].response?.location);
            }
            for (let index = 1; index < entries.length; index++) {
                const entry = entries[index];
                episode.encounter[index - 1].id = +this.getIdFromLocation(entry.response?.location);
            }
            return episode;
        });
    }
    async update(episode) {
        const inProgEnc = episode.encounter?.filter(e => e.status == EncounterStatus.INPROGRESS);
        const fhirEoC = this.fhirConverter.fromDataModel(episode);
        // remove Encounters?
        // maybe later -> to be updated in any way if 'in-progress'
        if (fhirEoC.contained?.length > 0) {
            const attivi = fhirEoC.contained.filter(i => i.resourceType == 'Encounter' && i.status == 'in-progress');
            for (let i = 0; i < attivi.length; i++) {
                const enc = attivi[i];
                if (enc.id) {
                    await lastValueFrom(this.encounterApi.update(+enc.id, enc));
                }
                else {
                    const id = await lastValueFrom(this.encounterApi.create(enc));
                    inProgEnc[i].id = id.location;
                }
            }
        }
        fhirEoC.contained = undefined;
        await this.episodeApi
            .update(+episode.fhirId, fhirEoC)
            .toPromise();
    }
    getIdFromLocation(location) {
        if (!location) {
            return undefined;
        }
        const _historyIndex = location.indexOf('/_history');
        let startIndex = undefined;
        let endIndex = undefined;
        if (_historyIndex > 0) {
            endIndex = _historyIndex;
        }
        startIndex = location.indexOf('/');
        if (endIndex) {
            return location.substring(startIndex + 1, endIndex);
        }
        else {
            return location.substring(startIndex + 1);
        }
    }
}

class BackendGenomicVariantConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        // this.baseHeaders = new HttpHeaders({
        //     'Content-Type': 'application/json',
        //     'Accept': 'application/json',
        // });
        this.fhirConverter = fhirConverter;
        this.diagnosticReportApi = new DiagnosticReportApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        /*
            this.observationApi = new ObservationApi(
                http,
                fhirBaseFullUrl,
                undefined,
                exceptionHandler
            );
            */
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    // TODO: CMP3 - invocato dalla GUI, sulla base del paziente selezionato ritorna tutti gli items necessari al rendering della tabella di variante genomica
    async searchByPatientAndReport(patient, reportId) {
        let carePlanExtras = new Map();
        const patientRef = ModelToFHIRUtils.getReference(patient);
        // 1. search for the active careplans
        return this.diagnosticReportApi
            .search({
            subject: patientRef,
            id: reportId,
            _includes: ['DiagnosticReport:result'], //FIXME - inserire il nome corretto dell'attributo in cui sono memorizzate tutte le observation
        }, carePlanExtras)
            .toPromise()
            .then((bundle) => {
            // 2. merge of the diagnostic report request in case of too many 'Observation'
            return bundle?.entry ? this.bundleUtils.mergeBundle(bundle) : undefined;
        })
            .then((bundle) => {
            // TODO: verificare che in questo bundle ci sia il diagnostic report e tutte le observation popolate
            // ALessio: non penso ci serva, useremo solamente le Observation
            // qui torva i/il diagnostic report
            const firstPlanComponent = bundle?.entry?.find((e) => e.resource.resourceType ===
                'DiagnosticReport');
            // il diagnostic report potrebbe essere eliminato se non occorre [NB - find trova solo il primo, se sono di più utilizzare un filtro]
            return bundle;
        })
            .then((res) => {
            // assumiamo che ci siano solo le Observation FHIR in questo bundle
            if (!res) {
                return [];
            }
            // TODO foreach entry di interesse
            const toRet = [];
            const dImpls = [];
            const tImpls = [];
            const molConseqs = [];
            res.entry.forEach((item) => {
                // gestire solo DomainResource di tipo Observation
                const resource = item.resource;
                if (resource && resource.resourceType === 'Observation') {
                    // in questo metodo c'è il controllo dell'instance of che rimanderà al Measure.toDataModel -> in questo c'è il check del codice che rimanderà al metodo corretto
                    const shareable = this.fhirConverter.toDataModel(resource);
                    if (shareable instanceof GenomicVariant) {
                        toRet.push(shareable);
                    }
                    else if (shareable instanceof DiagnosticImplication) {
                        dImpls.push(shareable);
                    }
                    else if (shareable instanceof TherapeuticImplication) {
                        tImpls.push(shareable);
                    }
                    else if (shareable instanceof MolecularConsequence) {
                        molConseqs.push(shareable);
                    }
                }
            });
            // ricrea il legame tra GV e DiagnosticImplication o TherapeuticImplication
            dImpls.forEach((di) => {
                let relatedGv = toRet.find((gv) => gv.id === di.relatedGenomicVariantId);
                if (relatedGv) {
                    relatedGv.diagImplication = di;
                }
            });
            tImpls.forEach((ti) => {
                let relatedGv = toRet.find((gv) => gv.id === ti.relatedGenomicVariantId);
                if (relatedGv) {
                    relatedGv.therapImplication = ti;
                }
            });
            molConseqs.forEach((mc) => {
                let relatedGv = toRet.find((gv) => gv.id === mc.relatedGenomicVariantId);
                if (relatedGv) {
                    relatedGv.molecularConsequences.push(mc);
                }
            });
            return toRet;
        });
    }
}

class BackendServiceRequestConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        this.fhirConverter = fhirConverter;
        this.serviceRequestApi = new ServiceRequestApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    async create(examPrescriptions, author, encounter) {
        examPrescriptions.forEach((ep) => {
            ep.author = ep.author != author ? author : ep.author;
        });
        const serReqs = examPrescriptions.map((ep) => this.fhirConverter.fromDataModel(ep)) || [];
        let encounterRef = ModelToFHIRUtils.getReference(encounter);
        let requester = author ? ModelToFHIRUtils.getReference(author) : undefined;
        serReqs.forEach((srs) => {
            srs.requester = requester;
            srs.encounter = encounterRef;
        });
        return this.serviceRequestApi
            .transaction(serReqs)
            .toPromise()
            .then((bundle) => this.bundleUtils.mergeBundle(bundle))
            .then((bundle) => {
            return bundle.entry?.map((entry) => this.fhirConverter.toDataModel(entry.resource)) || [];
        });
    }
    searchByEncounter(encounter) {
        throw new Error('Method not implemented');
        // const extraParams: Map<string, any> = new Map<string, any>();
        // extraParams.set(
        //   'subject',
        //   pats?.map(p => p.id).join(',')
        // );
        // return this.conditionApi.search({}, extraParams).toPromise()
        // .then((bundle: Bundle) => this.bundleUtils.mergeBundle(bundle))
        // .then((bundle: Bundle) => {
        //   return (
        //     bundle.entry?.map(
        //       (entry) =>
        //         this.fhirConverter.toDataModel(
        //           entry.resource as FHIRCondition
        //         ) as Condition
        //     ) || []
        //   );
        // });
    }
    update(examPrescriptions, author, encounter) {
        throw new Error('Method not implemented.');
    }
    async getAllCounsellingForPatient(patient) {
        // Define the extraParams to search by both the patientId and the counselling
        const extraParams = new Map();
        extraParams.set('subject', `Patient/${patient.id}`);
        extraParams.set('category', '409063005');
        // search for counselling prescriptions
        const bundle = await lastValueFrom(this.serviceRequestApi.search({}, extraParams));
        /**
         * call toDataModel for each entry in the bundle to convert FHIR ServiceRequest to CounsellingPrescription
         * and pass the bundle for context
         * if no entries are found, it returns an empty array
         */
        return (bundle.entry?.map((entry) => this.fhirConverter.toDataModel(entry.resource, bundle // Pass bundle for context
        )) || []);
    }
    async getAllCounselling(patients) {
        // Define the extraParams to search by both the patientId and the counselling
        const extraParams = new Map();
        if (patients && patients.length > 0) {
            const patientIds = patients.map((p) => `${p.id}`).join(',');
            extraParams.set('subject', patientIds);
        }
        extraParams.set('category', '409063005');
        // search for counselling prescriptions
        let bundle = await lastValueFrom(this.serviceRequestApi.search({}, extraParams));
        if (bundle && bundle.entry) {
            bundle = await this.bundleUtils.mergeBundle(bundle);
        }
        /**
         * call toDataModel for each entry in the bundle to convert FHIR ServiceRequest to CounsellingPrescription
         * and pass the bundle for context
         * if no entries are found, it returns an empty array
         */
        return (bundle?.entry?.map((entry) => this.fhirConverter.toDataModel(entry.resource, bundle // Pass bundle for context
        )) || []);
    }
    async updateCounselling(prescription) {
        if (prescription.id == undefined) {
            throw new Error(`Error while updating the ServiceRequest as the FHIR ID is missing.`);
        }
        // Convert cp to FHIR ServiceRequest so it can be correctly updated in the FHIR server.
        const fhirRequest = this.fhirConverter.fromDataModel(prescription);
        // FHIR transaction makes effective the ServiceRequest resource update in the FHIR server
        const response = await lastValueFrom(this.serviceRequestApi.update(prescription.id, fhirRequest));
        // Data synchronization: the updated ServiceRequest in the mergedBundle is sent to toDataModel so also the CP is updated
        return this.fhirConverter.toDataModel(response);
    }
    async createCounselling(prescription) {
        // Convert cp to FHIR ServiceRequest so it can be correctly updated in the FHIR server.
        const fhirRequest = this.fhirConverter.fromDataModel(prescription);
        // FHIR transaction makes effective the ServiceRequest resource update in the FHIR server
        const response = await lastValueFrom(this.serviceRequestApi.create(fhirRequest));
        // Data synchronization: the updated ServiceRequest in the mergedBundle is sent to toDataModel so also the CP is updated
        prescription.id = response?.location;
        return prescription;
    }
}

// prettier-ignore
class BackendVcfConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        // this.baseHeaders = new HttpHeaders({
        //     'Content-Type': 'application/json',
        //     'Accept': 'application/json',
        // });
        this.fhirConverter = fhirConverter;
        this.diagnosticReportApi = new DiagnosticReportApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    // DiagnosticReport?media=DocumentReference/xx
    retrieveVcf(documentReferenceId) {
        // const dcr = new DocumentReference();
        // dcr.id=documentReferenceId
        const dcr = new Reference({
            type: "DocumentReference",
            id: documentReferenceId
        });
        let vcf = new Vcf();
        vcf.variants = [];
        const dImpls = [];
        const tImpls = [];
        const molConseqs = [];
        // const toRemove = new Reference({ //FIXME - to remove, only for developing purposes
        //     type: "Patient",
        //     id: 155
        // })
        let b;
        // return this.diagnosticReportApi.search({media: dcr}).pipe(
        // return this.diagnosticReportApi.search({patient: toRemove}).pipe( //FIXME - to remove, only for developing purposes
        //     map(bundle => {
        //         return this.bundleUtils.mergeBundle(bundle).then(res => {
        //             b = res
        //             if (b && b.entry){
        //                 b.entry.forEach(entry => {
        //                     const dr = entry.resource as DiagnosticReport
        //                     const obs = dr.contained;
        //                     obs.forEach(item => { // preso da connettore CMP3
        //                         // gestire solo DomainResource di tipo Observation
        //             //   const resource: DomainResource = item.resource as DomainResource;
        //               if (item && item.resourceType === 'Observation') {
        //                 const shareable: Shareable =
        //                   this.fhirConverter.toDataModel(item); // TO CHECK if is correct for SHE
        //                 if (shareable instanceof GenomicVariant)
        //                   vcf.variants.push(shareable as GenomicVariant);
        //                 // else if (shareable instanceof DiagnosticImplication)
        //                 //   dImpls.push(shareable as DiagnosticImplication);
        //                 // else if (shareable instanceof TherapeuticImplication)
        //                 //   tImpls.push(shareable as TherapeuticImplication);
        //               }
        //                     })
        //                 })
        //             }
        //             return Promise.resolve(vcf)
        //         })
        //     })
        // )
        // return this.diagnosticReportApi.search({patient: toRemove}).toPromise().then( bundle => {
        return this.diagnosticReportApi.search({ media: dcr }).toPromise().then(bundle => {
            return this.bundleUtils.mergeBundle(bundle).then(res => {
                b = res;
                if (b && b.entry) {
                    b.entry.forEach(entry => {
                        const dr = entry.resource;
                        const obs = dr.contained;
                        obs.forEach(item => {
                            // gestire solo DomainResource di tipo Observation
                            //   const resource: DomainResource = item.resource as DomainResource;
                            if (item && item.resourceType === 'Observation') {
                                const shareable = this.fhirConverter.toDataModel(item); // TO CHECK if is correct for SHE
                                if (shareable instanceof GenomicVariant) {
                                    vcf.variants.push(shareable);
                                }
                                else if (shareable instanceof DiagnosticImplication) {
                                    dImpls.push(shareable);
                                }
                                else if (shareable instanceof TherapeuticImplication) {
                                    tImpls.push(shareable);
                                }
                                else if (shareable instanceof MolecularConsequence) {
                                    molConseqs.push(shareable);
                                }
                            }
                        });
                    });
                    // ricrea il legame tra GV e DiagnosticImplication o TherapeuticImplication
                    dImpls.forEach((di) => {
                        let relatedGv = vcf?.variants?.find((gv) => (gv.id === di.relatedGenomicVariantId || di.relatedGenomicVariantId.endsWith(gv.linkedId)));
                        if (relatedGv)
                            relatedGv.diagImplication = di;
                    });
                    tImpls.forEach((ti) => {
                        let relatedGv = vcf?.variants?.find((gv) => (gv.id === ti.relatedGenomicVariantId || ti.relatedGenomicVariantId.endsWith(gv.linkedId)));
                        if (relatedGv)
                            relatedGv.therapImplication = ti;
                    });
                    molConseqs.forEach((mc) => {
                        let relatedGv = vcf?.variants?.find((gv) => gv.id === mc.relatedGenomicVariantId || mc.relatedGenomicVariantId.endsWith(gv.linkedId));
                        if (relatedGv) {
                            if (!relatedGv.molecularConsequences) {
                                relatedGv.molecularConsequences = [];
                            }
                            relatedGv.molecularConsequences.push(mc);
                        }
                    });
                }
                return Promise.resolve(vcf);
            });
        });
    }
}

class HeartUiConnectorService {
}

class BackendAppointmentConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        this.fhirConverter = fhirConverter;
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.appointmentApi = new AppointmentApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    async searchAppointmentsByPatient(patient, disableCache, retrieveAll, callback) {
        let api = this.appointmentApi;
        /*
          Bugfix 1044, added for the button to force refresh of the lists
        */
        if (disableCache) {
            api = this.appointmentApi;
        }
        const bundle = await lastValueFrom(api.search({
            patient: this.fhirConverter.getFHIRReference(patient),
        }));
        if (callback) {
            if (bundle && bundle.entry) {
                if (retrieveAll) {
                    return this.bundleUtils.mergeBundleIncrementally(bundle, callback);
                }
                else {
                    const appointments = bundle.entry?.filter((entry) => entry.resource.resourceType == 'Appointment').map((entry) => entry.resource, bundle);
                    return callback(appointments);
                }
            }
            else {
                return callback([]);
            }
        }
        else {
            let res;
            if (bundle && bundle.entry) {
                if (retrieveAll) {
                    res = await this.bundleUtils.mergeBundle(bundle);
                }
                else {
                    // FIXME
                    res = bundle.entry?.filter((entry) => entry.resource.resourceType == 'Appointment').map((entry) => entry.resource, bundle);
                }
            }
            else {
                res = [];
            }
            if (res instanceof Bundle) {
                return res.entry
                    ?.filter((entry) => entry.resource.resourceType == 'Appointment')
                    .map((entry) => this.fhirConverter.toDataModel(entry.resource, res));
            }
            else {
                return res.map((entry) => this.fhirConverter.toDataModel(entry));
            }
        }
    }
    async searchByReference(reference) {
        const ref = ModelToFHIRUtils.getReference(reference).reference;
        return this.appointmentApi
            .getById(ref)
            .toPromise()
            .then((fhir) => this.fhirConverter.toDataModel(fhir));
    }
    async create(appointment) {
        const fhirEnc = this.fhirConverter.fromDataModel(appointment);
        const createEnc = this.appointmentApi.create(fhirEnc);
        const res = await lastValueFrom(createEnc);
        appointment.id = res?.location;
        return appointment;
    }
    async update(updateAppointment) {
        if (updateAppointment.id == undefined) {
            throw new Error(`Error while updating the Condition as the FHIR ID is missing.`);
        }
        let fhir;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        fhir = this.fhirConverter.fromDataModel(updateAppointment);
        const update = this.appointmentApi.update(updateAppointment.id, fhir);
        fhir = await lastValueFrom(update);
        updateAppointment.id = +fhir.id;
        return updateAppointment;
    }
    async delete(appointment) {
        try {
            await lastValueFrom(this.appointmentApi.delete(appointment.id));
            return true;
        }
        catch (error) {
            return false;
        }
    }
    async searchAppointmentsByHCP(hcp, disableCache, retrieveAll, callback) {
        let api = this.appointmentApi;
        /*
          Bugfix 1044, added for the button to force refresh of the lists
        */
        if (disableCache) {
            api = this.appointmentApi;
        }
        const bundle = await lastValueFrom(api.search({
            practitioner: this.fhirConverter.getFHIRReference(hcp),
        }));
        if (callback) {
            if (bundle && bundle.entry) {
                if (retrieveAll) {
                    return this.bundleUtils.mergeBundleIncrementally(bundle, callback);
                }
                else {
                    const appointments = bundle.entry?.filter((entry) => entry.resource.resourceType == 'Appointment').map((entry) => entry.resource, bundle);
                    return callback(appointments);
                }
            }
            else {
                return callback([]);
            }
        }
        else {
            let res;
            if (bundle && bundle.entry) {
                if (retrieveAll) {
                    res = await this.bundleUtils.mergeBundle(bundle);
                }
                else {
                    // FIXME
                    res = bundle.entry?.filter((entry) => entry.resource.resourceType == 'Appointment').map((entry) => entry.resource, bundle);
                }
            }
            else {
                res = [];
            }
            if (res instanceof Bundle) {
                return res.entry
                    ?.filter((entry) => entry.resource.resourceType == 'Appointment')
                    .map((entry) => this.fhirConverter.toDataModel(entry.resource, res));
            }
            else {
                return res.map((entry) => this.fhirConverter.toDataModel(entry));
            }
        }
    }
    async searchAppointments() {
        const bundle = await lastValueFrom(this.appointmentApi.search({}));
        const appointments = bundle?.entry
            ?.filter((entry) => entry.resource.resourceType == 'Appointment')
            ?.map((entry) => this.fhirConverter.toDataModel(entry.resource, bundle)) || [];
        return Promise.resolve(appointments);
    }
}

class BackendKinshipConnector {
    // prettier-ignore
    constructor(http, fhirBaseFullUrl, exceptionHandler, _fhirConverter) {
        this._fhirConverter = _fhirConverter;
        this.patientApi = new PatientApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.personApi = new PersonApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.relatedPersonAPi = new RelatedPersonApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    // 0 - create the "Person" (for the patient)
    // 1 - create the link array and set
    //      [0] the reference to the patient
    // for each relative present in the patient object
    // a - create the RelatedPerson
    //  set the relative relationship code
    //  set the relative's  identifier as Patient
    //   //  and persist it
    //       // b - retrieve the fhirId OR anyway get the Reference of the RelatedPerson
    //       // c - add the link to the just created RelatedPerson in the patient with the value or the RelatedPerson Reference
    //     //     // finally - persist the Person
    async create(enrichedPatient) {
        // check the current presence of Person
        let patientPersonPersisted;
        let rpsToCreate = [];
        const alreadyStoredPersons = await this.searchPersonByPatient(enrichedPatient);
        if (alreadyStoredPersons) {
            // if already present, let's check if the link[0] is the patient reference
            patientPersonPersisted = alreadyStoredPersons.find((ps) => ps.link[0] && ps.link[0].target.reference == ModelToFHIRUtils.getReference(enrichedPatient).reference);
            if (patientPersonPersisted) {
                // check the relatedPerson already stored
                const persistedPatient = await this.searchByPatientReference(ModelToFHIRUtils.getReference(enrichedPatient));
                if (persistedPatient.relatives) {
                    const alreadyPresentRelative = persistedPatient.relatives;
                    enrichedPatient.relatives.forEach((rel) => {
                        if (rel.relatedPersonId == undefined) {
                            rpsToCreate.push(rel);
                        }
                        // if (alreadyPresentRelative.filter((aprp) => aprp.relative.patientIdentifier == rel.relative.patientIdentifier).length == 0) {
                        //   rpsToCreate.push(rel);
                        // }
                    });
                }
            }
        }
        const fhirKinship = KinshipConverterUtils.createFhirResourcesToPersist(enrichedPatient, rpsToCreate, patientPersonPersisted);
        const kinshipNoIds = enrichedPatient.relatives.filter(k => k.relatedPersonId == undefined);
        const patKinshipNoIds = kinshipNoIds.map(kni => kni.relative);
        const toPersist = [];
        fhirKinship.relatedPersons.forEach(frp => {
            patKinshipNoIds.find(p => {
                if (p.id == frp.patient.getReferenceIdPart()) {
                    toPersist.push(frp);
                }
            });
        });
        // const storedRelatedPerson: RelatedPerson[] = await this.createRelatedPerson(fhirKinship?.relatedPersons); 
        const storedRelatedPerson = await this.createRelatedPerson(toPersist);
        // console.log(storedRelatedPerson.forEach(strp => console.log(strp.id)))
        // storedRelatedPerson?.forEach((frp) => {
        fhirKinship?.relatedPersons?.forEach((frp) => {
            if (frp?.id) {
                KinshipConverterUtils.addRelatedPersonLink(fhirKinship, frp); // here the "person" should contains all the links (also the already persisted related person)
            }
        });
        if (patientPersonPersisted) {
            const jointArray = union(patientPersonPersisted.link, fhirKinship.person.link);
            fhirKinship.person.link = jointArray;
        }
        return this.createPerson(fhirKinship);
    }
    createRelatedPerson(relatedPersons) {
        const toPersist = relatedPersons.filter((rp) => rp.id == undefined);
        return (this.relatedPersonAPi
            // .transaction(relatedPersons)
            .transaction(toPersist)
            .toPromise()
            .then((res) => this.bundleUtils.mergeBundle(res))
            .then((mergedRes) => {
            return mergedRes.entry
                ?.filter((entry) => entry?.resource instanceof RelatedPerson)
                .map((entry) => {
                const rp = entry.resource;
                const start = entry.resource.resourceType.length + 1;
                const end = entry.response.location.indexOf('/', start);
                const id = entry.response.location.substring(start, end);
                rp.id = id;
                return rp;
            });
        }));
    }
    createPerson(fhirKinship) {
        // finally - persist the Person
        console.log('Persisting the person ' + JSON.stringify(fhirKinship.person));
        if (fhirKinship.person.id) {
            // UPDATE
            return this.personApi
                .update(+fhirKinship.person.id, fhirKinship.person)
                .toPromise()
                .then((res) => Promise.resolve(res ? true : false));
        }
        else {
            // CREATE
            return this.personApi
                .create(fhirKinship.person)
                .toPromise()
                .then((res) => {
                fhirKinship.person.id = res.location + '';
                return Promise.resolve(res ? true : false);
            });
        }
    }
    // Observable
    // private createPerson(fhirKinship: FhirKinship) : Observable<Person> {
    //   // finally - persist the Person
    //   console.log('Persisting the person ' + JSON.stringify(fhirKinship.person));
    //   if (fhirKinship.person.id){ // UPDATE
    //     return this.personApi.update(+fhirKinship.person.id, fhirKinship.person).pipe(
    //       tap(console.log)
    //     );
    //   }else {
    //     return this.personApi.create(fhirKinship.person).pipe(
    //       switchMap(res => {
    //         fhirKinship.person.id = res.location + '';
    //         return of(fhirKinship.person);
    //       })
    //     );
    //   }
    // }
    update(enrichedPatient) {
        throw new Error('Method not implemented.');
    }
    delete(patient, kinship) {
        return this.searchByPatient(patient).then((p) => {
            let kinshipPos = p.relatives.findIndex((r) => r.relative.patientIdentifier == kinship.relative.patientIdentifier);
            if (kinshipPos < 0) { // this should be an error, i cannot delete a kinship that does not part of the patient
                return Promise.resolve(patient);
            }
            let relativeToRemove = p.relatives.splice(kinshipPos, 1)[0].relative;
            const extraParams = new Map();
            extraParams.set('patient', relativeToRemove.id);
            this.relatedPersonAPi.delete(Number(kinship.relatedPersonId)).subscribe(res => console.log(`Deleted: ` + res));
            let b;
            this.relatedPersonAPi.delete(relativeToRemove.id).subscribe((removedRP) => {
                console.log(removedRP);
                this.personApi
                    .disableCache()
                    .search({ link: ModelToFHIRUtils.getReference(patient) })
                    .toPromise()
                    .then((bundle) => {
                    this.bundleUtils.mergeBundle(bundle).then((res) => {
                        b = res;
                        if (b && b.entry) {
                            b.entry.forEach((entry) => {
                                if (entry.resource.resourceType == 'Person') {
                                    const fhirPers = entry.resource;
                                    if (fhirPers.link) {
                                        const posToRemove = fhirPers.link.findIndex((l) => l.target.getReferenceIdPart() == +kinship.relatedPersonId);
                                        console.log(`Link to remove ${posToRemove}`);
                                        fhirPers.link.splice(posToRemove, 1);
                                        this.personApi.update(+fhirPers.id, fhirPers).subscribe(res => Promise.resolve(res));
                                    }
                                }
                            });
                        }
                    });
                });
            });
            return Promise.resolve(p);
        });
    }
    searchByPatient(patient) {
        return this.searchByPatientReference(ModelToFHIRUtils.getReference(patient));
    }
    searchByPatientReference(patientReference) {
        const patients = [];
        const kinMap = new Map();
        // let persistedPatient = cloneDeep(patient)
        let persistedPatient = new Patient$1();
        // throw new Error('Method not implemented.');
        // 0 Get the patient + person + relatedPerson as Bundle ?
        // {{baseUrlRPI}}/api/rpi/base/Person?link={{patient_id}}&_include:iterate=Person:link&_include:iterate=RelatedPerson:patient
        const extraParams = new Map();
        extraParams.set('_include:iterate', ['Person:link', 'RelatedPerson:patient']);
        let b;
        // .search({ link: ModelToFHIRUtils.getReference(patient) }, extraParams)
        return this.personApi
            .disableCache()
            .search({ link: patientReference }, extraParams)
            .toPromise()
            .then((bundle) => {
            return this.bundleUtils.mergeBundle(bundle).then((res) => {
                b = res;
                if (b && b.entry) {
                    b.entry.forEach((entry) => {
                        switch (entry.resource.resourceType) {
                            case 'RelatedPerson':
                                const pid = entry.resource.patient.getReferenceIdPart();
                                const cv = new CodedValue(entry.resource.relationship[0]?.coding[0].system, entry.resource.relationship[0]?.coding[0].code);
                                const rpId = entry.resource.id;
                                kinMap.set(pid, { rpid: rpId, rel: cv });
                                break;
                            case 'Person':
                                console.log('[BackendKinshipConnector] Actually the person is not so important to retrieve');
                                break;
                            case 'Patient':
                                let pat = this._fhirConverter.toDataModel(entry.resource);
                                if (ModelToFHIRUtils.getReference(pat).reference?.toString() == patientReference.reference.toString()) {
                                    persistedPatient = pat;
                                }
                                patients.push(this._fhirConverter.toDataModel(entry.resource));
                                break;
                            default:
                                console.warn(`[BackendKinshipConnector]${entry.resource.resourceType} NOT MANAGED`);
                                break;
                        }
                    });
                    persistedPatient.relatives = [];
                    kinMap.forEach((value, key) => {
                        const p = patients.find((p) => key == p.id);
                        if (p) {
                            persistedPatient.relatives.push(new Kinship(p, value.rel, value.rpid));
                        }
                    });
                }
                return Promise.resolve(persistedPatient);
            });
        });
    }
    searchPersonByPatient(patient) {
        const persons = []; // should be just one
        const extraParams = new Map();
        extraParams.set('_include:iterate', ['Person:link']);
        let b;
        return this.personApi
            .search({ link: ModelToFHIRUtils.getReference(patient) }, extraParams)
            .toPromise()
            .then((bundle) => {
            return this.bundleUtils.mergeBundle(bundle).then((res) => {
                b = res;
                if (b && b.entry) {
                    b.entry.forEach((entry) => {
                        if (entry.resource.resourceType == 'Person') {
                            persons.push(entry.resource);
                        }
                    });
                }
                return Promise.resolve(persons);
            });
        });
    }
}

class BackendRiskConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        // this.baseHeaders = new HttpHeaders({
        //     'Content-Type': 'application/json',
        //     'Accept': 'application/json',
        // });
        this.fhirConverter = fhirConverter;
        this.riskApi = new RiskAssessmentApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    async remove(risk) {
        if (!risk.id)
            return Promise.reject('id is needed');
        try {
            await lastValueFrom(this.riskApi.delete(risk.id));
            return;
        }
        catch (error) {
            return Promise.reject(error);
        }
    }
    /**
     *
     * @param nName - matches any of the string field name/alias
     */
    async search() {
        const search = this.riskApi.search({});
        const bundle = await lastValueFrom(search);
        const risks = bundle?.entry?.map((entry) => entry.resource).map((fhir) => this.fhirConverter.toDataModel(fhir)) || [];
        return Promise.resolve(risks);
    }
    async searchByReference(reference) {
        const search = this.riskApi.getById(reference.id + '');
        const fhir = await lastValueFrom(search);
        let condition = this.fhirConverter.toDataModel(fhir);
        return condition;
    }
    async create(newRisk) {
        let fhir;
        fhir = this.fhirConverter.fromDataModel(newRisk);
        const createRisk = this.riskApi.create(fhir);
        const res = await lastValueFrom(createRisk);
        newRisk.id = res?.location;
        return newRisk;
    }
    async searchByPatient(pat) {
        const extraParams = new Map();
        extraParams.set('subject', pat?.id);
        return this.riskApi
            .search({}, extraParams)
            .toPromise()
            .then((bundle) => this.bundleUtils.mergeBundle(bundle))
            .then((bundle) => {
            return bundle.entry?.map((entry) => this.fhirConverter.toDataModel(entry.resource)) || [];
        });
    }
    async searchLatestByPatient(pat) {
        const risks = await this.searchByPatient(pat);
        return this.getMostRecentRisks(risks);
    }
    async addAllRisks(risks) {
        return lastValueFrom(await this.riskApi.transaction(risks.map((m) => this.fhirConverter.fromDataModel(m)))).then((res) => {
            return res?.entry?.map((entry) => entry.resource).map((fhirRisk) => this.fhirConverter.toDataModel(fhirRisk, res)) || [];
        });
    }
    getMostRecentRisks(risks) {
        const latestRisks = new Map();
        risks.forEach((risk) => {
            if (risk.predictions.length > 0) {
                const uniqueLabelKey = risk.predictions[0].code.uniqueLabelKey;
                const existing = latestRisks.get(uniqueLabelKey);
                if (!existing || risk.date > existing.date) {
                    latestRisks.set(uniqueLabelKey, risk);
                }
            }
        });
        return Array.from(latestRisks.values());
    }
}

class BackendTrialConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        this.fhirConverter = fhirConverter;
        this.rSubjectApi = new ResearchSubjectApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.studyApi = new ResearchStudyApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    async getStudyRefByName(studyName) {
        const bundle = await lastValueFrom(this.studyApi.search({ name: studyName }));
        const result = bundle?.entry?.length > 0 ? bundle.entry.map((entry) => new Trial(+entry.resource.id)) : [];
        return Promise.resolve(result);
    }
    async createTrialSubject(ct) {
        const fhirCT = this.fhirConverter.fromDataModel(ct);
        let res = await lastValueFrom(this.rSubjectApi.create(fhirCT));
        ct.id = res.location;
        return ct;
    }
    async getTrialByPatient(patient, studyName) {
        const extra = new Map();
        if (studyName)
            extra.set('study.name', studyName);
        const bundle = await lastValueFrom(this.rSubjectApi.search({
            subject: this.fhirConverter.getFHIRReference(patient),
        }, extra));
        const result = bundle?.entry?.length > 0 ? bundle.entry.map((entry) => this.fhirConverter.toDataModel(entry.resource)) : [];
        return Promise.resolve(result);
    }
    async getSubjectsByTrial(studyName) {
        const extra = new Map();
        if (studyName)
            extra.set('study.name', studyName);
        let bundle = await lastValueFrom(this.rSubjectApi.search({}, extra));
        if (bundle && bundle.entry) {
            bundle = await this.bundleUtils.mergeBundle(bundle);
        }
        const result = bundle?.entry?.length > 0 ? bundle.entry.map((entry) => this.fhirConverter.toDataModel(entry.resource)) : [];
        return Promise.resolve(result);
    }
    async deleteTrialSubject(id) {
        await lastValueFrom(this.rSubjectApi.delete(id.id));
        return;
    }
}

class BackendNutritionConnector {
    constructor(http, fhirBaseFullUrl, exceptionHandler, fhirConverter) {
        this.fhirConverter = fhirConverter;
        this.nutritionApi = new NutritionIntakeApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
        this.bundleUtils = new BundleUtilityApi(http, fhirBaseFullUrl, undefined, exceptionHandler);
    }
    // Altri metodi del connettore (create, update, delete, ecc.) che sono commentati per ora nel nutrition.connector.ts
    async searchByPatient(patient) {
        const extraParams = new Map();
        extraParams.set('subject', patient.id); // Utilizziamo l'ID del paziente come parametro 'subject'
        return this.nutritionApi
            .search({}, extraParams)
            .toPromise()
            .then((bundle) => this.bundleUtils.mergeBundle(bundle))
            .then((bundle) => {
            return bundle.entry?.map((entry) => this.fhirConverter.toDataModel(entry.resource)) || [];
        });
    }
    async create(nutrition) {
        const obs = nutrition?.map((n) => this.fhirConverter.fromDataModel(n)) || [];
        return this.nutritionApi
            .transaction(obs)
            .toPromise()
            .then((res) => this.bundleUtils.mergeBundle(res))
            .then((mergedRes) => {
            const resultObs = mergedRes.entry.map((entry) => entry.resource);
            return resultObs?.map((fhir) => this.fhirConverter.toDataModel(fhir)) || [];
        });
    }
}

/**
* CustomHttpUrlEncodingCodec
* Fix plus sign (+) not encoding, so sent as blank space
* See: https://github.com/angular/angular/issues/11058#issuecomment-247367318
*/
class CustomHttpUrlEncodingCodec extends HttpUrlEncodingCodec {
    encodeKey(k) {
        k = super.encodeKey(k);
        return k.replace(/\+/gi, '%2B');
    }
    encodeValue(v) {
        v = super.encodeValue(v);
        return v.replace(/\+/gi, '%2B');
    }
}

const BASE_PATH = new InjectionToken('basePath');
const COLLECTION_FORMATS = {
    'csv': ',',
    'tsv': '   ',
    'ssv': ' ',
    'pipes': '|'
};

class Configuration {
    constructor(configurationParameters = {}) {
        this.apiKeys = configurationParameters.apiKeys;
        this.username = configurationParameters.username;
        this.password = configurationParameters.password;
        this.accessToken = configurationParameters.accessToken;
        this.basePath = configurationParameters.basePath;
        this.withCredentials = configurationParameters.withCredentials;
    }
    /**
     * Select the correct content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param contentTypes - the array of content types that are available for selection
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderContentType(contentTypes) {
        if (contentTypes.length == 0) {
            return undefined;
        }
        let type = contentTypes.find(x => this.isJsonMime(x));
        if (type === undefined) {
            return contentTypes[0];
        }
        return type;
    }
    /**
     * Select the correct accept content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct accept content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param accepts - the array of content types that are available for selection.
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderAccept(accepts) {
        if (accepts.length == 0) {
            return undefined;
        }
        let type = accepts.find(x => this.isJsonMime(x));
        if (type === undefined) {
            return accepts[0];
        }
        return type;
    }
    /**
     * Check if the given MIME is a JSON MIME.
     * JSON MIME examples:
     *   application/json
     *   application/json; charset=UTF8
     *   APPLICATION/JSON
     *   application/vnd.company+json
     * @param mime - MIME (Multipurpose Internet Mail Extensions)
     * @return True if the given MIME is JSON, false otherwise.
     */
    isJsonMime(mime) {
        const jsonMime = new RegExp('^(application\/json|[^;/ \t]+\/[^;/ \t]+[+]json)[ \t]*(;.*)?$', 'i');
        return mime != null && (jsonMime.test(mime) || mime.toLowerCase() === 'application/json-patch+json');
    }
}

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */ /* tslint:disable:no-unused-variable member-ordering */
class UserManagementAPIsService {
    constructor(httpClient, basePath, configuration) {
        this.httpClient = httpClient;
        this.basePath = 'http://localhost:8080/emr';
        this.defaultHeaders = new HttpHeaders();
        this.configuration = new Configuration();
        if (basePath) {
            this.basePath = basePath;
        }
        if (configuration) {
            this.configuration = configuration;
            this.basePath = basePath || configuration.basePath || this.basePath;
        }
    }
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    canConsumeForm(consumes) {
        const form = 'multipart/form-data';
        for (const consume of consumes) {
            if (form === consume) {
                return true;
            }
        }
        return false;
    }
    changeUserPassword(body, observe = 'body', reportProgress = false) {
        if (body === null || body === undefined) {
            throw new Error('Required parameter body was null or undefined when calling changeUserPassword.');
        }
        let headers = this.defaultHeaders;
        // to determine the Accept header
        let httpHeaderAccepts = [
            'application/json'
        ];
        const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(httpHeaderAccepts);
        if (httpHeaderAcceptSelected != undefined) {
            headers = headers.set('Accept', httpHeaderAcceptSelected);
        }
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected != undefined) {
            headers = headers.set('Content-Type', httpContentTypeSelected);
        }
        return this.httpClient.request('put', `${this.basePath}/user/update-password`, {
            body: body,
            withCredentials: this.configuration.withCredentials,
            headers: headers,
            observe: observe,
            reportProgress: reportProgress
        });
    }
    changeUserStatus(body, id, observe = 'body', reportProgress = false) {
        if (body === null || body === undefined) {
            throw new Error('Required parameter body was null or undefined when calling changeUserStatus.');
        }
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling changeUserStatus.');
        }
        let headers = this.defaultHeaders;
        // to determine the Accept header
        let httpHeaderAccepts = [];
        const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(httpHeaderAccepts);
        if (httpHeaderAcceptSelected != undefined) {
            headers = headers.set('Accept', httpHeaderAcceptSelected);
        }
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected != undefined) {
            headers = headers.set('Content-Type', httpContentTypeSelected);
        }
        return this.httpClient.request('patch', `${this.basePath}/user/${encodeURIComponent(String(id))}/status`, {
            body: body,
            withCredentials: this.configuration.withCredentials,
            headers: headers,
            observe: observe,
            reportProgress: reportProgress
        });
    }
    checkUsernameAvailability(body, observe = 'body', reportProgress = false) {
        if (body === null || body === undefined) {
            throw new Error('Required parameter body was null or undefined when calling checkUsernameAvailability.');
        }
        let headers = this.defaultHeaders;
        // to determine the Accept header
        let httpHeaderAccepts = [
            'application/json'
        ];
        const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(httpHeaderAccepts);
        if (httpHeaderAcceptSelected != undefined) {
            headers = headers.set('Accept', httpHeaderAcceptSelected);
        }
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected != undefined) {
            headers = headers.set('Content-Type', httpContentTypeSelected);
        }
        return this.httpClient.request('post', `${this.basePath}/user/check-username-availability`, {
            body: body,
            withCredentials: this.configuration.withCredentials,
            headers: headers,
            observe: observe,
            reportProgress: reportProgress
        });
    }
    fetchRoles(observe = 'body', reportProgress = false) {
        let headers = this.defaultHeaders;
        // to determine the Accept header
        let httpHeaderAccepts = [
            'application/json'
        ];
        const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(httpHeaderAccepts);
        if (httpHeaderAcceptSelected != undefined) {
            headers = headers.set('Accept', httpHeaderAcceptSelected);
        }
        // to determine the Content-Type header
        const consumes = [];
        return this.httpClient.request('get', `${this.basePath}/user/role`, {
            withCredentials: this.configuration.withCredentials,
            headers: headers,
            observe: observe,
            reportProgress: reportProgress
        });
    }
    forceResetPasswordForOtherUser(body, id, observe = 'body', reportProgress = false) {
        if (body === null || body === undefined) {
            throw new Error('Required parameter body was null or undefined when calling forceResetPasswordForOtherUser.');
        }
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling forceResetPasswordForOtherUser.');
        }
        let headers = this.defaultHeaders;
        // to determine the Accept header
        let httpHeaderAccepts = [
            'application/json'
        ];
        const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(httpHeaderAccepts);
        if (httpHeaderAcceptSelected != undefined) {
            headers = headers.set('Accept', httpHeaderAcceptSelected);
        }
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected != undefined) {
            headers = headers.set('Content-Type', httpContentTypeSelected);
        }
        return this.httpClient.request('patch', `${this.basePath}/user/${encodeURIComponent(String(id))}/password`, {
            body: body,
            withCredentials: this.configuration.withCredentials,
            headers: headers,
            observe: observe,
            reportProgress: reportProgress
        });
    }
    registerUser(body, observe = 'body', reportProgress = false) {
        if (body === null || body === undefined) {
            throw new Error('Required parameter body was null or undefined when calling registerUser.');
        }
        let headers = this.defaultHeaders;
        // to determine the Accept header
        let httpHeaderAccepts = [
            // 'application/fhir+json',
            'application/json'
        ];
        const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(httpHeaderAccepts);
        if (httpHeaderAcceptSelected != undefined) {
            headers = headers.set('Accept', httpHeaderAcceptSelected);
        }
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected != undefined) {
            headers = headers.set('Content-Type', httpContentTypeSelected);
        }
        return this.httpClient.request('post', `${this.basePath}/user`, {
            body: body,
            withCredentials: this.configuration.withCredentials,
            headers: headers,
            observe: observe,
            reportProgress: reportProgress
        });
    }
    removeUser(id, observe = 'body', reportProgress = false) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling removeUser.');
        }
        let headers = this.defaultHeaders;
        // to determine the Accept header
        let httpHeaderAccepts = [
            'application/json'
        ];
        const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(httpHeaderAccepts);
        if (httpHeaderAcceptSelected != undefined) {
            headers = headers.set('Accept', httpHeaderAcceptSelected);
        }
        // to determine the Content-Type header
        const consumes = [];
        return this.httpClient.request('delete', `${this.basePath}/user/${encodeURIComponent(String(id))}`, {
            withCredentials: this.configuration.withCredentials,
            headers: headers,
            observe: observe,
            reportProgress: reportProgress
        });
    }
    searchUsers(username, type, onlyEnabled, organization, observe = 'body', reportProgress = false) {
        let queryParameters = new HttpParams({ encoder: new CustomHttpUrlEncodingCodec() });
        if (username !== undefined && username !== null) {
            queryParameters = queryParameters.set('username', username);
        }
        if (type !== undefined && type !== null) {
            queryParameters = queryParameters.set('type', type);
        }
        if (onlyEnabled !== undefined && onlyEnabled !== null) {
            queryParameters = queryParameters.set('only-enabled', onlyEnabled);
        }
        if (organization !== undefined && organization !== null) {
            queryParameters = queryParameters.set('organization', organization);
        }
        let headers = this.defaultHeaders;
        // to determine the Accept header
        let httpHeaderAccepts = [
            'application/json'
        ];
        const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(httpHeaderAccepts);
        if (httpHeaderAcceptSelected != undefined) {
            headers = headers.set('Accept', httpHeaderAcceptSelected);
        }
        // to determine the Content-Type header
        const consumes = [];
        return this.httpClient.request('get', `${this.basePath}/user`, {
            params: queryParameters,
            withCredentials: this.configuration.withCredentials,
            headers: headers,
            observe: observe,
            reportProgress: reportProgress
        });
    }
    userStatus(id, observe = 'body', reportProgress = false) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling userStatus.');
        }
        let headers = this.defaultHeaders;
        // to determine the Accept header
        let httpHeaderAccepts = [
            'application/json'
        ];
        const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(httpHeaderAccepts);
        if (httpHeaderAcceptSelected != undefined) {
            headers = headers.set('Accept', httpHeaderAcceptSelected);
        }
        // to determine the Content-Type header
        const consumes = [];
        return this.httpClient.request('get', `${this.basePath}/user/${encodeURIComponent(String(id))}/status`, {
            withCredentials: this.configuration.withCredentials,
            headers: headers,
            observe: observe,
            reportProgress: reportProgress
        });
    }
}
UserManagementAPIsService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: UserManagementAPIsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
UserManagementAPIsService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: UserManagementAPIsService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: UserManagementAPIsService, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }]; } });

const APIS = [UserManagementAPIsService];

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */

class ApiModule {
    constructor(parentModule, http) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
                'See also https://github.com/angular/angular/issues/20575');
        }
    }
    static forRoot(configurationFactory) {
        return {
            ngModule: ApiModule,
            providers: [{ provide: Configuration, useFactory: configurationFactory }]
        };
    }
}
ApiModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ApiModule, deps: [{ token: ApiModule, optional: true, skipSelf: true }, { token: i1.HttpClient, optional: true }], target: i0.ɵɵFactoryTarget.NgModule });
ApiModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: ApiModule });
ApiModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ApiModule, providers: [
        UserManagementAPIsService
    ] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ApiModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    declarations: [],
                    exports: [],
                    providers: [
                        UserManagementAPIsService
                    ]
                }]
        }], ctorParameters: function () { return [{ type: ApiModule, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.HttpClient, decorators: [{
                    type: Optional
                }] }]; } });

const REST_URL = new InjectionToken('REST_URL');
const FHIR_URL = new InjectionToken('FHIR_URL');
class HeartUiBackendConnectorService extends HeartUiConnectorService {
    constructor(http, converterFactory, eHandler, restUrl, fhirUrl, _userOpenApi) {
        super();
        this.http = http;
        this.converterFactory = converterFactory;
        this.eHandler = eHandler;
        this.restUrl = restUrl;
        this.fhirUrl = fhirUrl;
        this._userOpenApi = _userOpenApi;
        this.converterFactory.initConverter(ConvertibleFormat.FHIR);
        const fhirConverter = this.converterFactory.getFhirConverter();
        const eh = this.eHandler.getExceptionHandler();
        this._userOpenApi.basePath = restUrl;
        this._patient = new BackendPatientConnector(this.http, this.restUrl, this.fhirUrl, this._userOpenApi, eh, fhirConverter);
        this._practitioner = new BackendPractitionerConnector(this.http, this.restUrl, this.fhirUrl, this._userOpenApi, eh, fhirConverter);
        this._server = new BackendServerConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._organization = new BackendOrganizationConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._consent = new BackendConsentConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._measure = new BackendMeasureConnector(this.http, this.restUrl, this.fhirUrl, eh, fhirConverter);
        this._procedure = new BackendProcedureConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._careTeam = new BackendCareTeamConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._relatedPerson = new BackendRelatedPersonConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._goal = new BackendGoalConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._carePlan = new BackendCarePlanConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._clinicalNote = new BackendClinicalNoteConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._genomicVariant = new BackendGenomicVariantConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._questionnaire = new BackendQuestionnaireConnector(this.http, this.restUrl, this.fhirUrl, eh, fhirConverter);
        this._condition = new BackendConditionConnector(this.http, this.restUrl, this.fhirUrl, eh, fhirConverter);
        this._episode = new BackendEpisodeConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._encounter = new BackendEncounterConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._appointment = new BackendAppointmentConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._genomic = new BackendGenomicStudyConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._vcf = new BackendVcfConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._docRef = new BackendDocRefConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._serviceRequest = new BackendServiceRequestConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._docRef = new BackendDocRefConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._kinship = new BackendKinshipConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._risk = new BackendRiskConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._trial = new BackendTrialConnector(this.http, this.fhirUrl, eh, fhirConverter);
        this._nutrition = new BackendNutritionConnector(this.http, this.fhirUrl, eh, fhirConverter);
    }
    get patientConnector() {
        if (!this._patient) {
            throw new Error('The connector service is not initialized');
        }
        return this._patient;
    }
    get practitionerConnector() {
        if (!this._practitioner) {
            throw new Error('The connector service is not initialized');
        }
        return this._practitioner;
    }
    get serverConnector() {
        if (!this._server) {
            throw new Error('The connector service is not initialized');
        }
        return this._server;
    }
    get organizationConnector() {
        if (!this._organization) {
            throw new Error('The connector service is not initialized');
        }
        return this._organization;
    }
    get consentConnector() {
        if (!this._consent) {
            throw new Error('The connector service is not initialized');
        }
        return this._consent;
    }
    get measureConnector() {
        if (!this._measure) {
            throw new Error('The connector service is not initialized');
        }
        return this._measure;
    }
    get procedureConnector() {
        if (!this._procedure) {
            throw new Error('The connector service is not initialized');
        }
        return this._procedure;
    }
    get careTeamConnector() {
        if (!this._careTeam) {
            throw new Error('The connector service is not initialized');
        }
        return this._careTeam;
    }
    get goalConnector() {
        if (!this._goal) {
            throw new Error('The connector service is not initialized');
        }
        return this._goal;
    }
    get carePlanConnector() {
        if (!this._carePlan) {
            throw new Error('The connector service is not initialized');
        }
        return this._carePlan;
    }
    get clinicalNoteConnector() {
        if (!this._clinicalNote) {
            throw new Error('The connector service is not initialized');
        }
        return this._clinicalNote;
    }
    get genomicVariantConnector() {
        if (!this._genomicVariant) {
            throw new Error('The connector service is not initialized');
        }
        return this._genomicVariant;
    }
    get questionnaireConnector() {
        if (!this._questionnaire) {
            throw new Error('The connector service is not initialized');
        }
        return this._questionnaire;
    }
    get conditionConnector() {
        if (!this._condition) {
            throw new Error('The connector service is not initialized');
        }
        return this._condition;
    }
    get episodeConnector() {
        if (!this._episode) {
            throw new Error('The connector service is not initialized');
        }
        return this._episode;
    }
    get genomicStudyConnector() {
        if (!this._genomic) {
            throw new Error('The connector service is not initialized');
        }
        return this._genomic;
    }
    get vcfConnector() {
        if (!this._vcf) {
            throw new Error('The connector service is not initialized');
        }
        return this._vcf;
    }
    get docRefConnector() {
        if (!this._docRef) {
            throw new Error('The connector service is not initialized');
        }
        return this._docRef;
    }
    get serviceRequestConnector() {
        if (!this._serviceRequest) {
            throw new Error('The connector service is not initialized');
        }
        return this._serviceRequest;
    }
    get encounterConnector() {
        if (!this._encounter) {
            throw new Error('The connector service is not initialized');
        }
        return this._encounter;
    }
    get kinshipConnector() {
        if (!this._kinship) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._kinship;
    }
    get appointmentConnector() {
        if (!this._appointment) {
            throw new Error('The connector service is not initialized');
        }
        return this._appointment;
    }
    get relatedPerson() {
        if (!this._relatedPerson) {
            throw new Error('The connector service is not initialized');
        }
        return this._relatedPerson;
    }
    get riskConnector() {
        if (!this._risk) {
            throw new Error('The connector service is not initialized');
        }
        return this._risk;
    }
    get trialConnector() {
        if (!this._trial) {
            throw new Error('The connector service is not initialized');
        }
        return this._trial;
    }
    get nutritionConnector() {
        if (!this._nutrition) {
            throw new Error('The connector service is not initialized');
        }
        return this._nutrition;
    }
}
HeartUiBackendConnectorService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartUiBackendConnectorService, deps: [{ token: i1.HttpClient }, { token: DataConverterFactory }, { token: ExceptionHandlerService }, { token: REST_URL }, { token: FHIR_URL }, { token: UserManagementAPIsService }], target: i0.ɵɵFactoryTarget.Injectable });
HeartUiBackendConnectorService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartUiBackendConnectorService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartUiBackendConnectorService, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: i1.HttpClient }, { type: DataConverterFactory }, { type: ExceptionHandlerService }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [REST_URL]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [FHIR_URL]
                }] }, { type: UserManagementAPIsService }]; } });

class ConnectorModule {
    static forRoot(config) {
        return {
            ngModule: ConnectorModule,
            providers: [
                config.exceptionHandler || {
                    provide: ExceptionHandlerService,
                    useClass: BasicExceptionHandler,
                },
                { provide: FHIR_URL, useValue: config.fhirBaseFullUrl },
                { provide: REST_URL, useValue: config.restServiceFullUrl },
                DataConverterFactory,
                config.connectorService || {
                    provide: HeartUiConnectorService,
                    multi: false,
                    useClass: HeartUiBackendConnectorService,
                },
            ],
        };
    }
}
ConnectorModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ConnectorModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
ConnectorModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: ConnectorModule, imports: [ApiModule] });
ConnectorModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ConnectorModule, imports: [ApiModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ConnectorModule, decorators: [{
            type: NgModule,
            args: [{ imports: [ApiModule] }]
        }] });

class HeartUiStubConnectorService extends HeartUiConnectorService {
    constructor(_converterFactory, _eHandler) {
        super();
        this._converterFactory = _converterFactory;
        this._eHandler = _eHandler;
        this._converterFactory.initConverter(ConvertibleFormat.FHIR);
        this.initConnectorsAndData();
    }
    get patientConnector() {
        if (!this._patient) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._patient;
    }
    get practitionerConnector() {
        if (!this._practitioner) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._practitioner;
    }
    get serverConnector() {
        if (!this._server) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._server;
    }
    get organizationConnector() {
        if (!this._organization) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._organization;
    }
    get consentConnector() {
        if (!this._consent) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._consent;
    }
    get measureConnector() {
        if (!this._measure) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._measure;
    }
    get procedureConnector() {
        if (!this._procedure) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._procedure;
    }
    get careTeamConnector() {
        if (!this._careTeam) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._careTeam;
    }
    get goalConnector() {
        if (!this._goal) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._goal;
    }
    get carePlanConnector() {
        if (!this._carePlan) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._carePlan;
    }
    get clinicalNoteConnector() {
        if (!this._clinicalNote) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._clinicalNote;
    }
    get genomicVariantConnector() {
        if (!this._genomicVariant) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._genomicVariant;
    }
    get questionnaireConnector() {
        if (!this._questionnaire) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._questionnaire;
    }
    get conditionConnector() {
        if (!this._condition) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._condition;
    }
    get episodeConnector() {
        if (!this._episode) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._episode;
    }
    get encounterConnector() {
        if (!this._encounter) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._encounter;
    }
    get genomicStudyConnector() {
        if (!this._genomicStudy) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._genomicStudy;
    }
    get vcfConnector() {
        if (!this._vcf) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._vcf;
    }
    get docRefConnector() {
        if (!this._docRef) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._docRef;
    }
    get serviceRequestConnector() {
        if (!this._serviceRequestConnector) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._serviceRequestConnector;
    }
    get appointmentConnector() {
        if (!this._appointment) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._appointment;
    }
    get kinshipConnector() {
        if (!this._kinship) {
            throw new Error('The connector stub service is not initialized');
        }
        return this._kinship;
    }
    get relatedPerson() {
        if (!this._relatedPerson) {
            throw new Error('The connector service is not initialized');
        }
        return this._relatedPerson;
    }
    get riskConnector() {
        if (!this._risk) {
            throw new Error('The connector service is not initialized');
        }
        return this._risk;
    }
    get trialConnector() {
        if (!this._trial) {
            throw new Error('The connector service is not initialized');
        }
        return this._trial;
    }
    get nutritionConnector() {
        if (!this._nutrition) {
            throw new Error('The connector service is not initialized');
        }
        return this._nutrition;
    }
}

/*
 * Public API Surface of heart-ui-connector
 */

/**
 * Generated bundle index. Do not edit.
 */

export { BasicExceptionHandler, ConnectorModule, ConvertibleFormat, DataConverterFactory, ExceptionHandlerService, FHIR_URL, HeartUiBackendConnectorService, HeartUiConnectorService, HeartUiStubConnectorService, REST_URL, UserManagementAPIsService };
//# sourceMappingURL=eng-it4h-heart-ui-connector.mjs.map
