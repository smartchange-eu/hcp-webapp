import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import * as i0 from "@angular/core";
/**
 * Conversion manager providing the right converter to/from the local model
 */
export declare class DataConverterFactory {
    private fhir;
    constructor();
    initConverter(format: ConvertibleFormat): void;
    getConverter(format: ConvertibleFormat): FhirConverter;
    getFhirConverter(): FhirConverter;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataConverterFactory, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DataConverterFactory>;
}
export declare enum ConvertibleFormat {
    FHIR = 0
}
