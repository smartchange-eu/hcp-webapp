import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import * as i0 from "@angular/core";
export declare abstract class ExceptionHandlerService {
    abstract getExceptionHandler(): ExceptionHandler;
}
/**
 * This service is just a placeholder that just logs the error to the console, in case you don't need it at all
 */
export declare class BasicExceptionHandler extends ExceptionHandlerService {
    getExceptionHandler(): ExceptionHandler;
    static ɵfac: i0.ɵɵFactoryDeclaration<BasicExceptionHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BasicExceptionHandler>;
}
