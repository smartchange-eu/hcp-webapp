export interface ServerError {
    severity: string;
    code: string;
    diagnostics: string;
}
