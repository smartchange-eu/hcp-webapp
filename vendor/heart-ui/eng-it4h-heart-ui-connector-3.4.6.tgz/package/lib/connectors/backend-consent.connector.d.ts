import { HttpClient } from '@angular/common/http';
import { Consent as FHIRConsent, ExceptionHandler } from '@eng-it4h/fhir-r5';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { Patient, PatientConsent } from '@eng-it4h/heart-ui-model';
import { ConsentConnector } from '../api/consent.connector';
export declare class BackendConsentConnector implements ConsentConnector {
    private fhirConverter;
    private consentApi;
    private bundleUtils;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    searchConsentsByPatient(patient: Patient, retrieveAll?: boolean, callback?: (allItems: FHIRConsent[]) => Promise<void>): Promise<PatientConsent[] | void>;
    create(consent: PatientConsent): Promise<PatientConsent>;
    update(consent: PatientConsent): Promise<void>;
    getContentAttachmentURL(consent: PatientConsent): string;
    uploadConsentFiles(consent: PatientConsent, file: File, callback?: (progress: number, loaded: number, size: number) => void): Promise<string>;
}
