import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ServerError } from './server-error.model';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { HealthCareProfessional, Organization, Patient, User } from '@eng-it4h/heart-ui-model';
import { UserManagementAPIsService } from '../api/emr_rest_api';
import { UserConnector } from '../api/user.connector';
export declare abstract class BackendUserConnector implements UserConnector {
    protected http: HttpClient;
    protected restApiFullUrl: string;
    protected userApi: UserManagementAPIsService;
    private exceptionHandler;
    protected fhirConverter: FhirConverter;
    protected baseHeaders: HttpHeaders;
    constructor(http: HttpClient, restApiFullUrl: string, userApi: UserManagementAPIsService, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    /**
     * Verifies if the specified username (or email address) is currently available
     *
     * Returns true if available, false otherwise
     *
     * @param usernameOrEmail
     */
    isUsernameAvailable(username: string): Promise<boolean>;
    /**
     * The method creates the Patient/Practitioner on the server and at the same time it creates the user account
     *
     * @param user
     */
    registerUser(user: User): Promise<Patient | HealthCareProfessional | ServerError>;
    searchUsers(type?: 'HealthCareProfessional' | 'Patient' | 'all', organization?: Organization, onlyEnabled?: boolean): Promise<User[]>;
    searchUserByUsername(username?: string): Promise<User>;
    /**
     * Remove all the data related to a specific patient
     *
     * NTOE: as this operation REALLY deletes all the data it must be used only in special situations (like DEVELOPMENT or explicit request from the Patient)
     *
     * @param patient
     */
    eraseUserAndData(user: Patient | HealthCareProfessional): Promise<boolean | ServerError>;
    /**
     * tells if the user account is currently enabled
     *
     * @param user
     */
    isUserEnabled(user: Patient | HealthCareProfessional): Promise<boolean | ServerError>;
    /**
     * disable the user account without deleting the related data
     *
     * @param user
     */
    disableUser(user: Patient | HealthCareProfessional): Promise<boolean | ServerError>;
    /**
     * enable the user account for a previously disabled user
     *
     * @param user
     */
    enableUser(user: Patient | HealthCareProfessional): Promise<boolean | ServerError>;
    /**
     * Forced update of the password if the user in input
     *
     * @param newPassword
     * @param user
     */
    sendResetPasswordMessage(password: string, user: User): Promise<boolean>;
    /**
     * Update the password of the logged user
     *
     * @param user
     * @param oldPassword
     * @param newPassword
     */
    updatePassword(oldPassword: string, newPassword: string): Promise<boolean>;
    private changeUserStatus;
}
