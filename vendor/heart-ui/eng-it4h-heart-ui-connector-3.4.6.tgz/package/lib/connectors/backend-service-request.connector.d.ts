import { HttpClient } from '@angular/common/http';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { HealthCareProfessional, Patient, Encounter, ExamPrescription, CounsellingPrescription } from '@eng-it4h/heart-ui-model';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { ServiceRequestConnector } from '../api/public-api';
export declare class BackendServiceRequestConnector implements ServiceRequestConnector {
    private fhirConverter;
    private serviceRequestApi;
    private bundleUtils;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    create(examPrescriptions: ExamPrescription[], author?: HealthCareProfessional, encounter?: Encounter): Promise<ExamPrescription[]>;
    searchByEncounter(encounter: Encounter): Promise<ExamPrescription[] | undefined>;
    update(examPrescriptions: ExamPrescription[], author?: HealthCareProfessional, encounter?: Encounter): Promise<ExamPrescription[] | undefined>;
    getAllCounsellingForPatient(patient: Patient): Promise<CounsellingPrescription[]>;
    getAllCounselling(patients?: Patient[]): Promise<CounsellingPrescription[]>;
    updateCounselling(prescription: CounsellingPrescription): Promise<CounsellingPrescription>;
    createCounselling(prescription: CounsellingPrescription): Promise<CounsellingPrescription>;
}
