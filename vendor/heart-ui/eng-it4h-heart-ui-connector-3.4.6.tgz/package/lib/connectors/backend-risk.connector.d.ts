import { HttpClient } from '@angular/common/http';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { Condition, Patient, Risk } from '@eng-it4h/heart-ui-model';
import { RiskConnector } from '../api/risk.connector';
export declare class BackendRiskConnector implements RiskConnector {
    private fhirConverter;
    private riskApi;
    private bundleUtils;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    remove(risk: Risk): Promise<void>;
    /**
     *
     * @param nName - matches any of the string field name/alias
     */
    search(): Promise<Risk[]>;
    searchByReference(reference: Condition): Promise<Condition | undefined>;
    create(newRisk: Risk): Promise<Risk>;
    searchByPatient(pat: Patient): Promise<Risk[] | undefined>;
    searchLatestByPatient(pat: Patient): Promise<Risk[] | undefined>;
    addAllRisks(risks: Risk[]): Promise<void | Risk[]>;
    private getMostRecentRisks;
}
