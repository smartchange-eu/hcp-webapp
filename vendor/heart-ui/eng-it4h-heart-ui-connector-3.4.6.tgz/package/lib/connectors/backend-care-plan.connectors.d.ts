import { HttpClient } from '@angular/common/http';
import { Patient, Plan, PlanDefinition } from '@eng-it4h/heart-ui-model';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { CarePlanConnector } from '../api/care-plan.connector';
export declare class BackendCarePlanConnector implements CarePlanConnector {
    private fhirConverter;
    private carePlanApi;
    private planDefApi;
    private goalApi;
    private bundleUtils;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    searchPlanDefinitions(): Promise<PlanDefinition[]>;
    searchByPatient(patient: Patient, status?: Plan.PlanStatus, limit?: number): Promise<Plan[]>;
    private retrievesReferredMilestones;
    searchByReference(plan: Plan): Promise<Plan>;
    update(plan: Plan): Promise<Plan>;
    create(plan: Plan): Promise<Plan>;
    private resolvePlan;
    private getIdFromLocation;
}
