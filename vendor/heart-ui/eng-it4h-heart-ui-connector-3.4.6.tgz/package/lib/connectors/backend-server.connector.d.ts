import { HttpClient } from '@angular/common/http';
import { ExceptionHandler, DomainResource } from '@eng-it4h/fhir-r5';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { Shareable } from '@eng-it4h/heart-ui-model';
import { ServerConnector } from '../api/server.connector';
export declare class BackendServerConnector implements ServerConnector {
    private fhirConverter;
    private basic;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    transaction(resources: DomainResource[]): Promise<boolean>;
    transactionWithShareable(resources: Shareable[]): Promise<boolean>;
    batch(resources: DomainResource[]): Promise<boolean>;
}
