import { HttpClient } from '@angular/common/http';
import { GenomicVariant, Patient } from '@eng-it4h/heart-ui-model';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { GenomicVariantConnector } from '../api/genomic-variant.connector';
export declare class BackendGenomicVariantConnector implements GenomicVariantConnector {
    private fhirConverter;
    private diagnosticReportApi;
    private bundleUtils;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    searchByPatientAndReport(patient: Patient, reportId: string): Promise<GenomicVariant[]>;
}
