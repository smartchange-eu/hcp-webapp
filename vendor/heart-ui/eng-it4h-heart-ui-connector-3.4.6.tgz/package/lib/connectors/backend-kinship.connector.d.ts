import { HttpClient } from '@angular/common/http';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { KinshipConnector } from '../api/kinship.connector';
import { Kinship, Patient } from '@eng-it4h/heart-ui-model';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
export declare class BackendKinshipConnector implements KinshipConnector {
    private _fhirConverter;
    private patientApi;
    private personApi;
    private relatedPersonAPi;
    private bundleUtils;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, _fhirConverter: FhirConverter);
    create(enrichedPatient: Patient): Promise<boolean>;
    private createRelatedPerson;
    private createPerson;
    update(enrichedPatient: Patient): Promise<Patient>;
    delete(patient: Patient, kinship: Kinship): Promise<Patient>;
    searchByPatient(patient: Patient): Promise<Patient>;
    private searchByPatientReference;
    private searchPersonByPatient;
}
