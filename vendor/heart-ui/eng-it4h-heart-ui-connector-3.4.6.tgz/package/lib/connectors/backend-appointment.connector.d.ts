import { HttpClient } from '@angular/common/http';
import { Appointment as FhirAppointment, ExceptionHandler } from '@eng-it4h/fhir-r5';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { Appointment, HealthCareProfessional, Patient } from '@eng-it4h/heart-ui-model';
import { AppointmentConnector } from '../api/appointment.connector';
export declare class BackendAppointmentConnector implements AppointmentConnector {
    private fhirConverter;
    private bundleUtils;
    private appointmentApi;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    searchAppointmentsByPatient(patient: Patient, disableCache?: boolean, retrieveAll?: boolean, callback?: (allItems: FhirAppointment[]) => Promise<void>): Promise<Appointment[] | void>;
    searchByReference(reference: Appointment): Promise<Appointment>;
    create(appointment: Appointment): Promise<Appointment>;
    update(updateAppointment: Appointment): Promise<Appointment>;
    delete(appointment: Appointment): Promise<boolean>;
    searchAppointmentsByHCP(hcp: HealthCareProfessional, disableCache?: boolean, retrieveAll?: boolean, callback?: (allItems: any[]) => Promise<void>): Promise<Appointment[] | void>;
    searchAppointments(): Promise<Appointment[]>;
}
