import { HttpClient } from '@angular/common/http';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { Patient, Study } from '@eng-it4h/heart-ui-model';
import { GenomicStudyConnector } from '../api/genomic-study.connector';
import { Observable } from 'rxjs';
export declare class BackendGenomicStudyConnector implements GenomicStudyConnector {
    private fhirConverter;
    private genomicApi;
    private bundleUtils;
    private docRefApi;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    searchGenomicStudiesByPatient(patient: Patient, retrieveAll?: boolean, callback?: (allItems: any[]) => Promise<void>): Observable<void | Study[]>;
    retrieveCramUrl(reference: string): Promise<string[] | undefined>;
}
