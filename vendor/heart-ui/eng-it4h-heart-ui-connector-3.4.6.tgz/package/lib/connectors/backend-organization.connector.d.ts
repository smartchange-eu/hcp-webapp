import { HttpClient } from '@angular/common/http';
import { ExceptionHandler, Organization as FHIROrganization } from '@eng-it4h/fhir-r5';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { Organization } from '@eng-it4h/heart-ui-model';
import { OrganizationConnector } from '../api/organization.connector';
export declare class BackendOrganizationConnector implements OrganizationConnector {
    private fhirConverter;
    private organizationApi;
    private bundleUtils;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    create(newOrg: Organization): Promise<Organization>;
    update(newOrg: Organization): Promise<Organization>;
    searchOrganizationsByName(name: string, retrieveAll?: boolean, callback?: (allItems: FHIROrganization[]) => Promise<void>): Promise<Organization[] | void>;
    /**
     *
     * @param nName - matches any of the string field name/alias
     */
    searchOrganizations(): Promise<Organization[]>;
    searchByReference(reference: Organization): Promise<Organization>;
}
