import { HttpClient } from '@angular/common/http';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { QuestionnaireConnector } from '../api/questionnaire.connector';
import { HealthCareProfessional, Patient, ResponseStatus, Questionnaire, QuestionnaireResponse, CodedValue, Encounter } from '@eng-it4h/heart-ui-model';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
export declare class BackendQuestionnaireConnector implements QuestionnaireConnector {
    private fhirConverter;
    private questionnaireApi;
    private questionnaireResponseApi;
    private terminologyValueSetApi;
    private static readonly PREFIX;
    private static readonly SEPARATOR;
    private static readonly SUFFIX;
    private cache;
    private valueSetCache;
    private standardDictionaryYesNoDontKnow;
    constructor(http: HttpClient, restApiFullUrl: string, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    private createStandardDictionaryCache;
    /**
     *
     * @param nName - matches any of the string field name/alias
     */
    search(ignoreExpansionForValueSets?: CodedValue[], sortValues?: boolean): Promise<Questionnaire[]>;
    /**
     * Expand any occurrence of a ValueSet URL in the Questionnaire items
     *
     * For performance reason the method creates a temporary cache
     *
     * @param questionnaire
     */
    private expandQuestionnaireValuesets;
    private extractValuesetToBeExpanded;
    private isValuesetToBeExpanded;
    private setChoices;
    private fetchValueSets;
    searchByReference(reference: Questionnaire, ignoreExpansionForValueSets?: CodedValue[], sortValues?: boolean): Promise<Questionnaire | undefined>;
    createResponse(response: QuestionnaireResponse, author?: Patient | HealthCareProfessional, encounter?: Encounter): Promise<QuestionnaireResponse>;
    hasResponse(questionnaireReference: Questionnaire, patient: Patient): Promise<boolean>;
    searchResponse(questionnaireReference?: Questionnaire, patient?: Patient, repeatableAnswerGroupIDs?: string[], latest?: boolean): Promise<QuestionnaireResponse[]>;
    private createQuestionnaireResponseContext;
    updateResponse(response: QuestionnaireResponse, author: Patient | HealthCareProfessional, encounter?: Encounter): Promise<QuestionnaireResponse | undefined>;
    updateStatus(questionnaireResponse: QuestionnaireResponse, status: ResponseStatus, author: Patient | HealthCareProfessional): Promise<QuestionnaireResponse | undefined>;
}
