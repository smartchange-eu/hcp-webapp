import { HttpClient } from '@angular/common/http';
import { ExceptionHandler, EpisodeOfCare as FhirEpisodeOfCare } from '@eng-it4h/fhir-r5';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { Episode, Patient } from '@eng-it4h/heart-ui-model';
import { EpisodeConnector } from '../api/episode.connector';
export declare class BackendEpisodeConnector implements EpisodeConnector {
    private fhirConverter;
    private episodeApi;
    private bundleUtils;
    private encounterApi;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    searchEpisodesByPatient(patient: Patient, disableCache?: boolean, retrieveAll?: boolean, callback?: (allItems: FhirEpisodeOfCare[]) => Promise<void>): Promise<Episode[] | void>;
    /**
     *
     * @param nName - matches any of the string field name/alias
     */
    searchEpisodes(): Promise<Episode[]>;
    searchByReference(reference: Episode): Promise<Episode>;
    /**
     * This method is used to enrich the data of an EpisodeOfCare a to implement a lazy loadng mechanism.
     *
     * When invoked all resources (e.g. QuestionnaireResponse, Condition, ...) related to a specific Encounter of an EpisodeOfCare are loaded from the server
     *
     * @param partialEpisode
     * @param retrieveAll
     * @returns
     */
    enrichEpisode(partialEpisode: Episode, retrieveAll?: boolean): Promise<Episode>;
    create(episode: Episode): Promise<Episode>;
    update(episode: Episode): Promise<void>;
    private getIdFromLocation;
}
