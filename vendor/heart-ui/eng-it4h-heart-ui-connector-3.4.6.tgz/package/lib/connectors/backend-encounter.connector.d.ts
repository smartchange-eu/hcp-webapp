import { HttpClient } from '@angular/common/http';
import { Encounter as FhirEncounter, ExceptionHandler } from '@eng-it4h/fhir-r5';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { Encounter, Organization, Patient } from '@eng-it4h/heart-ui-model';
import { EncounterConnector } from '../api/encounter.connector';
export declare class BackendEncounterConnector implements EncounterConnector {
    private fhirConverter;
    private bundleUtils;
    private encounterApi;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    searchEncountersByPatient(patient: Patient, disableCache?: boolean, retrieveAll?: boolean, callback?: (allItems: FhirEncounter[]) => Promise<void>): Promise<Encounter[] | void>;
    searchByReference(reference: Encounter): Promise<Encounter>;
    create(encounter: Encounter): Promise<Encounter>;
    update(updateEncounter: Encounter): Promise<void>;
    searchEncountersByProvider(provider: Organization, disableCache?: boolean, retrieveAll?: boolean, callback?: (allItems: any[]) => Promise<void>): Promise<Encounter[] | void>;
    searchEncounters(): Promise<Encounter[]>;
    enrichEncounter(partialEncounter: Encounter, retrieveAll?: boolean): Promise<Encounter>;
}
