import { HttpClient } from '@angular/common/http';
import { Patient, Procedure, Workout } from '@eng-it4h/heart-ui-model';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { ProcedureConnector } from '../api/procedure.connector';
export declare class BackendProcedureConnector implements ProcedureConnector {
    private fhirConverter;
    private procedureApi;
    private bundleUtils;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    searchWorkoutByPatient(patient: Patient, period?: {
        from: Date;
        to: Date;
    }, limit?: number): Promise<Workout[]>;
    searchByReference(stub: Procedure): Promise<Procedure | undefined>;
}
