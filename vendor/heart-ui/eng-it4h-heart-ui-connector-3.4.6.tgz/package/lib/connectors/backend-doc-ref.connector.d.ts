import { HttpClient } from '@angular/common/http';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { DocRefConnector } from '../api/doc-ref.connector';
import { CodedValue, DocRef } from '@eng-it4h/heart-ui-model';
export declare class BackendDocRefConnector implements DocRefConnector {
    private fhirConverter;
    private docRefApi;
    private bundleUtils;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    retrieveDocumentReferencesForTypes(docRefCVs: CodedValue[], patientId?: number): Promise<void | DocRef[]>;
}
