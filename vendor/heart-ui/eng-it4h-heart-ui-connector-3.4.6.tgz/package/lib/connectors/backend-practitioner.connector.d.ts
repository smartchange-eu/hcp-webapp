import { HttpClient } from '@angular/common/http';
import { HealthCareProfessional, Organization, User } from '@eng-it4h/heart-ui-model';
import { ServerError } from './server-error.model';
import { ExceptionHandler, Practitioner as FHIRPractitioner } from '@eng-it4h/fhir-r5';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { BackendUserConnector } from './backend-user.connector';
import { PractitionerConnector } from '../api/practitioner.connector';
import { UserManagementAPIsService } from '../api/emr_rest_api';
export declare class BackendPractitionerConnector extends BackendUserConnector implements PractitionerConnector {
    private practitionerApi;
    constructor(http: HttpClient, restApiFullUrl: string, fhirBaseFullUrl: string, userApis: UserManagementAPIsService, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    registerUser(user: User): Promise<HealthCareProfessional | ServerError>;
    eraseUserAndData(practitioner: HealthCareProfessional): Promise<any>;
    /**
     *
     * @param fullName - matches any of the string fields in the FHIR HumanName, including family, give, prefix, suffix, suffix, and/or text
     */
    searchPractitionersByName(fullName: string, organization: Organization): Promise<HealthCareProfessional[]>;
    /**
     *
     * @param uuid - matches with the identifier field in the server FHIR using the UUID
     */
    searchPractitionerByUUID(uuid?: string): Promise<HealthCareProfessional>;
    /**
     *
     * @param uuid - matches with the identifier field in the server FHIR using the UUID
     */
    searchPractitionerByReference(stub: HealthCareProfessional): Promise<HealthCareProfessional>;
    /**
     *
     * @param id - FHIR ID
     */
    searchPractitionerById(id: string): Promise<HealthCareProfessional>;
    searchPractitionerByUsername(username?: string): Promise<HealthCareProfessional>;
    createFHIRPractitioner(practitioner: FHIRPractitioner): Promise<number>;
    update(practitioner: HealthCareProfessional): Promise<void>;
    private newPractitionerWithRole;
}
