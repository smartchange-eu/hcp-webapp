import { HttpClient } from '@angular/common/http';
import { Vcf } from '@eng-it4h/heart-ui-model';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { VcfConnector } from '../api/vcf.connector';
export declare class BackendVcfConnector implements VcfConnector {
    private fhirConverter;
    private diagnosticReportApi;
    private bundleUtils;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    retrieveVcf(documentReferenceId: string): Promise<Vcf | void>;
}
