import { HttpClient } from '@angular/common/http';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { CareGiver, Patient } from '@eng-it4h/heart-ui-model';
import { RelatedPersonConnector } from '../api/related-person.connector';
export declare class BackendRelatedPersonConnector implements RelatedPersonConnector {
    private fhirConverter;
    private bundleUtils;
    private relatedPersonApi;
    private patientApi;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    create(relatedPerson: CareGiver): Promise<CareGiver>;
    private resolveCareGiver;
    createAll(familyMembers: CareGiver[]): Promise<CareGiver[]>;
    update(relatedPerson: CareGiver): Promise<void>;
    delete(relatedPerson: CareGiver, cascade?: boolean): Promise<void>;
    searchByReference(model: CareGiver, withSeeAlso?: boolean): Promise<CareGiver>;
    searcByPatient(patient: Patient, withSeeAlso?: boolean): Promise<CareGiver[]>;
    searcByPatients(patients: Patient[]): Promise<CareGiver[]>;
    private resolveInternal;
    private createSeeAlso;
    private getIdFromLocation;
}
