import { HttpClient } from '@angular/common/http';
import { CodedValue, Encounter, HealthCareProfessional, Measure, Patient } from '@eng-it4h/heart-ui-model';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { FhirConverter, HeartValueSet } from '@eng-it4h/heart-ui-converter';
import { MeasureConnector, Trend } from '../api/measure.connector';
export declare type AggregationType = 'NONE' | 'DAILY_MEDIAN' | 'WEEKLY_MEDIAN' | 'DAILY_MEAN' | 'DAILY_LAST' | 'WEEKLY_MEAN' | 'DAILY_SUM' | 'WEEKLY_SUM' | 'WEEKLY_LAST';
export declare class BackendMeasureConnector implements MeasureConnector {
    private http;
    private restApiFullUrl;
    private fhirConverter;
    private baseHeaders;
    private measureConverter;
    private observationApi;
    private bundleUtils;
    constructor(http: HttpClient, restApiFullUrl: string, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    /**
     *
     * @param patientRef
     * @param types
     * @param period from is start of day (included), while to is end of day (included)
     * @param limit
     * @returns
     */
    searchByPatientAndType(patient: Patient, types: HeartValueSet.Common.Measurement[] | CodedValue[], period?: {
        from: Date;
        to: Date;
    }, limit?: number, sortByDescDate?: boolean, forceGenericMeasure?: boolean): Promise<Measure[]>;
    searchByReference(measure: Measure): Promise<Measure>;
    trendByPatientAndType(patient: Patient, typeValueSet: HeartValueSet.Common.Measurement, options?: {
        from?: Date;
        to?: Date;
        aggregate?: AggregationType;
        fill?: boolean;
    }): Promise<Trend[]>;
    create(measures: Measure[], author?: HealthCareProfessional, encounter?: Encounter, forceGenericMeasure?: boolean): Promise<Measure[]>;
    searchByPatientsAndType(patients: Patient[], types: HeartValueSet.Common.Measurement[] | CodedValue[], period?: {
        from: Date;
        to: Date;
    }, limit?: number, sortByDescDate?: boolean): Promise<Measure[]>;
}
