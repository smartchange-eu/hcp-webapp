import { HttpClient } from '@angular/common/http';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { CareGiver, CareTeam, Patient } from '@eng-it4h/heart-ui-model';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { CareTeamConnector } from '../api/care-team.connector';
export declare class BackendCareTeamConnector implements CareTeamConnector {
    private fhirConverter;
    private careTeamApi;
    private relatedPersonConnector;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    create(ct: CareTeam): Promise<CareTeam>;
    searchByPatient(patient: Patient): Promise<CareTeam[]>;
    searchByPatients(patients: Patient[]): Promise<CareTeam[]>;
    private retrieveCaregivers;
    /**
     *
     * @param id
     * @param careTeam
     * @param caregiverChange
     * @param oldCaregiver - used to refer the caregiver in case of caregiverChange === 'deleted'
     */
    update(careTeam: CareTeam, caregiverChange?: 'created' | 'changed' | 'deleted', oldCaregiver?: CareGiver): Promise<void>;
}
