import { HttpClient } from '@angular/common/http';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { ClinicalNote, Encounter, HealthCareProfessional } from '@eng-it4h/heart-ui-model';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { ClinicalNoteConnector, ClinicalNotesFilter } from '../api/clinical-note.connector';
export declare class BackendClinicalNoteConnector implements ClinicalNoteConnector {
    private fhirConverter;
    private documentReferenceApi;
    private bundleUtils;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    searchByPatient(config: ClinicalNotesFilter): Promise<{
        articles: ClinicalNote[];
        articlesCount: number;
    }>;
    searchByReference(stub: ClinicalNote): Promise<ClinicalNote | undefined>;
    delete(clinicalNote: ClinicalNote): Promise<boolean>;
    save(practitioner: HealthCareProfessional, article: ClinicalNote, encounter?: Encounter): Promise<ClinicalNote>;
    getAllComments(refers: ClinicalNote): Promise<ClinicalNote[]>;
    addComment(practitioner: HealthCareProfessional, refers: ClinicalNote, commentBody: string): Promise<ClinicalNote | undefined>;
    deleteComment(id: number, refers: ClinicalNote): Promise<boolean>;
    private saveNote;
    private deleteNote;
}
