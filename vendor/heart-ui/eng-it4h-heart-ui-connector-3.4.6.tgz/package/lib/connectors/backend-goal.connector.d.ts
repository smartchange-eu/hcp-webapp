import { HttpClient } from '@angular/common/http';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { Goal, Patient } from '@eng-it4h/heart-ui-model';
import { GoalConnector } from '../api/goal.connector';
export declare class BackendGoalConnector implements GoalConnector {
    private fhirConverter;
    private goalApi;
    private bundleUtils;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    searchByPatient(patient: Patient, status?: Goal.GoalStatus): Promise<Goal[]>;
    searchByReference(goal: Goal): Promise<Goal>;
    deleteAll(goals: Goal[]): Promise<void>;
    updateMacro(macro: Goal[]): Promise<void | Goal[]>;
}
