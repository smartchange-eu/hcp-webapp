import { HttpClient } from '@angular/common/http';
import { ChatSettings, HealthCareProfessional, ObservePatient, Organization, Patient, PatientHealthStatus, User } from '@eng-it4h/heart-ui-model';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { ExceptionHandler, Patient as FHIRPatient } from '@eng-it4h/fhir-r5';
import { BackendUserConnector } from './backend-user.connector';
import { ServerError } from './server-error.model';
import { HealthStatusAndObserve, PatientConnector, PatientHealthStatusAndObserve } from '../api/patient.connector';
import { UserManagementAPIsService } from '../api/emr_rest_api';
export declare class BackendPatientConnector extends BackendUserConnector implements PatientConnector {
    private patientApi;
    private observationApi;
    private clinicalImpressionApi;
    private bundleUtils;
    private documentReferenceApi;
    constructor(http: HttpClient, restApiFullUrl: string, fhirBaseFullUrl: string, userMService: UserManagementAPIsService, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    registerUser(user: User): Promise<Patient | ServerError>;
    eraseUserAndData(patient: Patient): Promise<any>;
    searchHealthStatusAndObservableByPatientReference(patient: Patient, participant?: {
        organization: Organization;
        practitioner: HealthCareProfessional;
    }): Promise<HealthStatusAndObserve>;
    searchHealthStatusAndObservableByName(fullName: string, participant?: {
        organization: Organization;
        practitioner: HealthCareProfessional;
    }): Promise<PatientHealthStatusAndObserve[]>;
    /**
     *
     * @param fullName - matches any of the string fields in the FHIR HumanName, including family, give, prefix, suffix, suffix, and/or text
     */
    searchPatients(fullName?: string, disableCache?: boolean, retrieveAll?: boolean, participant?: {
        organization?: Organization;
        practitioner?: HealthCareProfessional;
    }, onlyWithActivePlan?: boolean, callback?: (allItems: FHIRPatient[], newItems: FHIRPatient[]) => Promise<void>): Promise<Patient[] | void>;
    /**
     *
     * @param uuid - matches with the identifier field in the server FHIR using the UUID
     */
    searchPatientByUUID(uuid?: string): Promise<Patient>;
    searchPatientByUsername(username?: string): Promise<Patient>;
    searchPatientsByReferences(references: Patient[]): Promise<Patient[]>;
    create(patient: Patient): Promise<number>;
    createFHIRPatient(patient: FHIRPatient): Promise<number>;
    update(patient: Patient): Promise<string>;
    isPseudonymAvailable(pseudonym: any): Promise<boolean>;
    getAllChatSettings(practitioner: HealthCareProfessional): Promise<ChatSettings[]>;
    getChatSettings(patient: Patient, practitioner: HealthCareProfessional): Promise<ChatSettings>;
    saveChatSettings(chatSettings: ChatSettings): Promise<ChatSettings>;
    updateObservePatient(observe: ObservePatient): Promise<ObservePatient>;
    updatePatientHealthStatus(healthStatus: PatientHealthStatus): Promise<PatientHealthStatus>;
    searchPatientsWithVCF(): Promise<Patient[] | void[]>;
}
