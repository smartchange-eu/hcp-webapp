import { HttpClient } from '@angular/common/http';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { Patient, Nutrition } from '@eng-it4h/heart-ui-model';
import { NutritionConnector } from '../api/nutrition.connector';
export declare class BackendNutritionConnector implements NutritionConnector {
    private fhirConverter;
    private nutritionApi;
    private bundleUtils;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    searchByPatient(patient: Patient): Promise<Nutrition[] | undefined>;
    create(nutrition: Nutrition[]): Promise<Nutrition[]>;
}
