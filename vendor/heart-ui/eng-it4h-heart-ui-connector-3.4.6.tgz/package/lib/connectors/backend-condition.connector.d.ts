import { HttpClient } from '@angular/common/http';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { ConditionConnector } from '../api/condition.connector';
import { HealthCareProfessional, Patient, Condition, Encounter } from "@eng-it4h/heart-ui-model";
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
export declare class BackendConditionConnector implements ConditionConnector {
    private fhirConverter;
    private conditionApi;
    private bundleUtils;
    constructor(http: HttpClient, restApiFullUrl: string, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    /**
     *
     * @param nName - matches any of the string field name/alias
     */
    search(): Promise<Condition[]>;
    searchByReference(reference: Condition): Promise<Condition | undefined>;
    create(newCondition: Condition, author?: Patient | HealthCareProfessional, encounter?: Encounter): Promise<Condition>;
    update(updateCondition: Condition, author: Patient | HealthCareProfessional, encounter?: Encounter): Promise<Condition | undefined>;
    searchByPatients(pats: Patient[]): Promise<Condition[] | undefined>;
}
