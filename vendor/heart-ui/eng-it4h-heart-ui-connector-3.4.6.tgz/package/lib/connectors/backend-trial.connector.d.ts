import { HttpClient } from '@angular/common/http';
import { ExceptionHandler } from '@eng-it4h/fhir-r5';
import { Patient, Trial, TrialSubject } from '@eng-it4h/heart-ui-model';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { TrialConnector } from '../api/trial.connector';
export declare class BackendTrialConnector implements TrialConnector {
    private fhirConverter;
    private rSubjectApi;
    private studyApi;
    private bundleUtils;
    constructor(http: HttpClient, fhirBaseFullUrl: string, exceptionHandler: ExceptionHandler, fhirConverter: FhirConverter);
    getStudyRefByName(studyName: string): Promise<Trial[]>;
    createTrialSubject(ct: TrialSubject): Promise<TrialSubject>;
    getTrialByPatient(patient: Patient, studyName?: string): Promise<TrialSubject[]>;
    getSubjectsByTrial(studyName: string): Promise<TrialSubject[]>;
    deleteTrialSubject(id: TrialSubject): Promise<void>;
}
