import { ModuleWithProviders, Provider } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "./api/emr_rest_api/api.module";
export interface ConnectorModuleConfig {
    exceptionHandler?: Provider;
    fhirBaseFullUrl: string;
    restServiceFullUrl: string;
    connectorService?: Provider;
}
export declare class ConnectorModule {
    static forRoot(config: ConnectorModuleConfig): ModuleWithProviders<ConnectorModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConnectorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConnectorModule, never, [typeof i1.ApiModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConnectorModule>;
}
