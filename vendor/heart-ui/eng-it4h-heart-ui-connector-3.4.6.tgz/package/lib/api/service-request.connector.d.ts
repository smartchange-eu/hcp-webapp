import { CounsellingPrescription, Encounter, ExamPrescription, HealthCareProfessional, Patient } from '@eng-it4h/heart-ui-model';
export interface ServiceRequestConnector {
    searchByEncounter(encounter: Encounter): Promise<ExamPrescription[] | undefined>;
    create(examPrescriptions: ExamPrescription[], author?: HealthCareProfessional, encounter?: Encounter): Promise<ExamPrescription[]>;
    /**
     * Updates the whole ServiceRequest resource and ensures that the author of the change is traced
     *
     * @param ExamPrescriptions
     */
    update(examPrescriptions: ExamPrescription[], author?: HealthCareProfessional, encounter?: Encounter): Promise<ExamPrescription[] | undefined>;
    /**
     * extends the ServiceRequestConnector to
     * 1. get all CounsellingPrescription for a patient
     * 2. update CounsellingPrescription
     */
    getAllCounsellingForPatient(patient: Patient): Promise<CounsellingPrescription[]>;
    getAllCounselling(patients?: Patient[]): Promise<CounsellingPrescription[]>;
    updateCounselling(prescriptions: CounsellingPrescription): Promise<CounsellingPrescription>;
    createCounselling(prescriptions: CounsellingPrescription): Promise<CounsellingPrescription>;
}
