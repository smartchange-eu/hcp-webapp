import { CodedValue, DocRef } from "@eng-it4h/heart-ui-model";
export interface DocRefConnector {
    retrieveDocumentReferencesForTypes(docRefCVs: CodedValue[], patientId?: number): Promise<DocRef[] | void>;
}
