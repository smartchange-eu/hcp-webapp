import { GenomicVariant, Patient } from "@eng-it4h/heart-ui-model";
export interface GenomicVariantConnector {
    searchByPatientAndReport(patient: Patient, reportId: string): Promise<GenomicVariant[]>;
}
