export * from './userManagementAPIs.service';
import { UserManagementAPIsService } from './userManagementAPIs.service';
export declare const APIS: (typeof UserManagementAPIsService)[];
