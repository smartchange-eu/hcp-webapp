import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PasswordChangeRequestDTO } from '../model/passwordChangeRequestDTO';
import { PasswordResetRequestDTO } from '../model/passwordResetRequestDTO';
import { UserInfoDTO } from '../model/userInfoDTO';
import { UserRegistrationDTO } from '../model/userRegistrationDTO';
import { UserStatusDTO } from '../model/userStatusDTO';
import { UsernameAvailabilityRequestDTO } from '../model/usernameAvailabilityRequestDTO';
import { UsernameAvailabilityResponseDTO } from '../model/usernameAvailabilityResponseDTO';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class UserManagementAPIsService {
    protected httpClient: HttpClient;
    basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     * Receives an object with the OLD and NEW password and it checks that the old password is valid for the authenticated user
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    changeUserPassword(body: PasswordChangeRequestDTO, observe?: 'body', reportProgress?: boolean): Observable<boolean>;
    changeUserPassword(body: PasswordChangeRequestDTO, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<boolean>>;
    changeUserPassword(body: PasswordChangeRequestDTO, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<boolean>>;
    /**
     *
     * Enable/Disable a practitioner and/or a patient from the system
     * @param body
     * @param id
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    changeUserStatus(body: UserStatusDTO, id: number, observe?: 'body', reportProgress?: boolean): Observable<any>;
    changeUserStatus(body: UserStatusDTO, id: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    changeUserStatus(body: UserStatusDTO, id: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     * Check if the specified username (be it email address or a generic username) is available or not
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    checkUsernameAvailability(body: UsernameAvailabilityRequestDTO, observe?: 'body', reportProgress?: boolean): Observable<UsernameAvailabilityResponseDTO>;
    checkUsernameAvailability(body: UsernameAvailabilityRequestDTO, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<UsernameAvailabilityResponseDTO>>;
    checkUsernameAvailability(body: UsernameAvailabilityRequestDTO, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<UsernameAvailabilityResponseDTO>>;
    /**
     *
     * Fetches the valid application roles that can be used to register a new user or change his/her current roles
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    fetchRoles(observe?: 'body', reportProgress?: boolean): Observable<any>;
    fetchRoles(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    fetchRoles(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     * Receives an object with the NEW password and the reference to an existing user for which the current user desires to reset the password. The method is meant to be used to reset existing passwords so it is suggested to use it in combination for the&#x27;update_password&#x27; policy a set for the end use to change the passowrd after the first use,
     * @param body
     * @param id
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    forceResetPasswordForOtherUser(body: PasswordResetRequestDTO, id: number, observe?: 'body', reportProgress?: boolean): Observable<boolean>;
    forceResetPasswordForOtherUser(body: PasswordResetRequestDTO, id: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<boolean>>;
    forceResetPasswordForOtherUser(body: PasswordResetRequestDTO, id: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<boolean>>;
    /**
     *
     * Register a new user (be it a Patient or HealthCareProfessional) by using the received credentials. It returns the FHIR representation of the new Person as FHIR Patient or FHIR Practitioner
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    registerUser(body: UserRegistrationDTO, observe?: 'body', reportProgress?: boolean): Observable<any>;
    registerUser(body: UserRegistrationDTO, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    registerUser(body: UserRegistrationDTO, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     * Remove a practitioner and/or a patient from the system
     * @param id
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    removeUser(id: number, observe?: 'body', reportProgress?: boolean): Observable<string>;
    removeUser(id: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<string>>;
    removeUser(id: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<string>>;
    /**
     *
     * Retrieve all the registered users and the related FHIR resource (i.e. practitioner or patient) from the system. If the &#x27;username&#x27; (optional) is specified the other filters are ignored
     * @param username Filter users by username. In case this filter is used no more than 1 result is expected
     * @param type Filter by &#x27;person&#x27; type. Valid values are Practitioner and Patient (case sensitive)
     * @param onlyEnabled Filter by user status to retrive only the currently enabled users. If not specified it returns also the disabled ones
     * @param organization Filter by organization FHIR ID
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    searchUsers(username?: string, type?: string, onlyEnabled?: boolean, organization?: number, observe?: 'body', reportProgress?: boolean): Observable<Array<UserInfoDTO>>;
    searchUsers(username?: string, type?: string, onlyEnabled?: boolean, organization?: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<UserInfoDTO>>>;
    searchUsers(username?: string, type?: string, onlyEnabled?: boolean, organization?: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<UserInfoDTO>>>;
    /**
     *
     * Return the status of the user. It returns &#x27;true&#x27; if the user account is enabled, false otherwise
     * @param id
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    userStatus(id: number, observe?: 'body', reportProgress?: boolean): Observable<boolean>;
    userStatus(id: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<boolean>>;
    userStatus(id: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<boolean>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserManagementAPIsService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserManagementAPIsService>;
}
