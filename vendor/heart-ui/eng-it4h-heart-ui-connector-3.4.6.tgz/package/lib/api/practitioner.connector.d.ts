import { HealthCareProfessional, Organization, User } from '@eng-it4h/heart-ui-model';
import { Practitioner as FHIRPractitioner } from '@eng-it4h/fhir-r5';
import { ServerError } from "../connectors/server-error.model";
import { UserConnector } from "./user.connector";
export interface PractitionerConnector extends UserConnector {
    registerUser(user: User): Promise<ServerError | HealthCareProfessional>;
    eraseUserAndData(practitioner: HealthCareProfessional): Promise<any>;
    searchPractitionersByName(fullName: string, organization: Organization): Promise<HealthCareProfessional[]>;
    searchPractitionerByUUID(uuid?: string): Promise<HealthCareProfessional | undefined>;
    searchPractitionerByReference(stub: HealthCareProfessional): Promise<HealthCareProfessional | undefined>;
    searchPractitionerByUsername(username?: string): Promise<HealthCareProfessional | undefined>;
    createFHIRPractitioner(practitioner: FHIRPractitioner): Promise<number>;
    update(practitioner: HealthCareProfessional): Promise<void>;
    searchPractitionerById(id: string): Promise<HealthCareProfessional | undefined>;
}
