import { Patient, Trial, TrialSubject } from '@eng-it4h/heart-ui-model';
export interface TrialConnector {
    createTrialSubject(ct: TrialSubject): Promise<TrialSubject>;
    getTrialByPatient(patient: Patient, studyName?: string): Promise<TrialSubject[]>;
    getSubjectsByTrial(studyName: string): Promise<TrialSubject[]>;
    getStudyRefByName(studyName: string): Promise<Trial[]>;
    deleteTrialSubject(s: TrialSubject): Promise<void>;
}
