import { Vcf } from '@eng-it4h/heart-ui-model';
export interface VcfConnector {
    retrieveVcf(documentReferenceId: string): Promise<Vcf | void>;
}
