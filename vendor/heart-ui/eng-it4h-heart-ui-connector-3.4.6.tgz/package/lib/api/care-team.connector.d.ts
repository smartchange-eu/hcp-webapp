import { CareGiver, CareTeam, Patient } from '@eng-it4h/heart-ui-model';
export interface CareTeamConnector {
    create(ct: CareTeam): Promise<CareTeam>;
    searchByPatient(patient: Patient): Promise<CareTeam[]>;
    searchByPatients(patients: Patient[]): Promise<CareTeam[]>;
    /**
     *
     * @param id
     * @param careTeam
     * @param caregiverChange
     * @param oldCaregiver - used to refer the caregiver in case of caregiverChange === 'deleted'
     */
    update(careTeam: CareTeam, caregiverChange?: 'created' | 'changed' | 'deleted', oldCaregiver?: CareGiver): Promise<void>;
}
