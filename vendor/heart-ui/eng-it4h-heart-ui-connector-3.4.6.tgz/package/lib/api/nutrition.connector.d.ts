import { Patient, Nutrition } from '@eng-it4h/heart-ui-model';
export interface NutritionConnector {
    create(nutrition: Nutrition[]): Promise<Nutrition[]>;
    searchByPatient(pat: Patient): Promise<Nutrition[] | undefined>;
}
