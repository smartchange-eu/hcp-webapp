import { CodedValue, Encounter, HealthCareProfessional, Measure, Patient } from '@eng-it4h/heart-ui-model';
import { HeartValueSet } from '@eng-it4h/heart-ui-converter';
export declare type Trend = {
    name: string;
    series: {
        name: string | number;
        value: number;
    }[];
};
export declare type AggregationType = 'NONE' | 'DAILY_MEDIAN' | 'WEEKLY_MEDIAN' | 'DAILY_MEAN' | 'DAILY_LAST' | 'WEEKLY_MEAN' | 'DAILY_SUM' | 'WEEKLY_SUM' | 'WEEKLY_LAST';
export interface MeasureConnector {
    /**
     *
     * @param patientRef
     * @param types
     * @param period from is start of day (included), while to is end of day (included)
     * @param limit
     * @returns
     */
    searchByPatientAndType(patient: Patient, types: HeartValueSet.Common.Measurement[] | CodedValue[], period?: {
        from: Date;
        to: Date;
    }, limit?: number, sortByDescDate?: boolean, forceGenericMeasure?: boolean): Promise<Measure[]>;
    searchByReference(measure: Measure, forceGenericMeasure?: boolean): Promise<Measure>;
    trendByPatientAndType(patient: Patient, typeValueSet: HeartValueSet.Common.Measurement, options?: {
        from?: Date;
        to?: Date;
        aggregate?: AggregationType;
        fill?: boolean;
    }, forceGenericMeasure?: boolean): Promise<Trend[]>;
    create(measures: Measure[], author?: HealthCareProfessional, encounter?: Encounter, forceGenericMeasure?: boolean): Promise<Measure[]>;
    /**
     *
     * @param patientRef
     * @param types
     * @param period from is start of day (included), while to is end of day (included)
     * @param limit
     * @returns
     */
    searchByPatientsAndType(patients: Patient[], types: HeartValueSet.Common.Measurement[] | CodedValue[], period?: {
        from: Date;
        to: Date;
    }, limit?: number, sortByDescDate?: boolean): Promise<Measure[]>;
}
