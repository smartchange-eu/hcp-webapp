import { Patient, HealthCareProfessional, User, Organization } from '@eng-it4h/heart-ui-model';
import { ServerError } from '../connectors/server-error.model';
export interface UserConnector {
    /**
     * Verifies if the specified username (or email address) is currently available
     *
     * Returns true if available, false otherwise
     *
     * @param username
     */
    isUsernameAvailable(username: string): Promise<boolean>;
    /**
     * The method creates the Patient/Practitioner on the server and at the same time it creates the user account
     *
     * @param user
     * @param usernameOrEmail
     * @param pwd
     * // @param phone
     */
    registerUser(user: User): Promise<Patient | HealthCareProfessional | ServerError>;
    searchUsers(type?: 'HealthCareProfessional' | 'Patient' | 'all', organization?: Organization, onlyEnabled?: boolean): Promise<User[]>;
    searchUserByUsername(username?: string): Promise<User | undefined>;
    /**
     * Remove all the data related to a specific patient
     *
     * NTOE: as this operation REALLY deletes all the data it must be used only in special situations (like DEVELOPMENT or explicit request from the Patient)
     *
     * @param patient
     */
    eraseUserAndData(user: Patient | HealthCareProfessional): Promise<boolean | ServerError>;
    /**
     * tells if the user account is currently enabled
     *
     * @param user
     */
    isUserEnabled(user: Patient | HealthCareProfessional): Promise<boolean | ServerError>;
    /**
     * disable the user account without deleting the related data
     *
     * @param user
     */
    disableUser(user: Patient | HealthCareProfessional): Promise<boolean | ServerError>;
    /**
     * enable the user account for a previously disabled user
     *
     * @param user
     */
    enableUser(user: Patient | HealthCareProfessional): Promise<boolean | ServerError>;
    /**
     * Update the password of the logged user
     *
     * @param user
     * @param oldPassword
     * @param newPassword
     */
    updatePassword(oldPassword: string, newPassword: string): Promise<boolean | ServerError>;
    sendResetPasswordMessage(password: string, user: User): Promise<boolean | ServerError>;
}
