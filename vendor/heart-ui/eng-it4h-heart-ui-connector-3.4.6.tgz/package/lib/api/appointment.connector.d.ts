import { Appointment, HealthCareProfessional, Patient } from '@eng-it4h/heart-ui-model';
export interface AppointmentConnector {
    searchAppointmentsByPatient(patient: Patient, disableCache?: boolean, retrieveAll?: boolean, callback?: (allItems: any[]) => Promise<void>): Promise<Appointment[] | void>;
    searchAppointmentsByHCP(hcp: HealthCareProfessional, disableCache?: boolean, retrieveAll?: boolean, callback?: (allItems: any[]) => Promise<void>): Promise<Appointment[] | void>;
    /**
     *
     * @param nName - matches any of the string field name/alias
     */
    searchAppointments(): Promise<Appointment[]>;
    searchByReference(reference: Appointment): Promise<Appointment>;
    create(appointment: Appointment): Promise<Appointment>;
    update(appointment: Appointment): Promise<Appointment>;
    delete(appointment: Appointment): Promise<boolean>;
}
