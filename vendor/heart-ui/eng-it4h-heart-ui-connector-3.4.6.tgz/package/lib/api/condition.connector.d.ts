import { Encounter, HealthCareProfessional, Condition, Patient } from "@eng-it4h/heart-ui-model";
export interface ConditionConnector {
    search(): Promise<Condition[]>;
    searchByReference(reference: Condition): Promise<Condition | undefined>;
    create(condition: Condition, author?: Patient | HealthCareProfessional, encounter?: Encounter): Promise<Condition>;
    /**
     * Updates the whole Condition resource and ensures that the author of the change is traced
     *
     * @param condition
     */
    update(condition: Condition, author?: Patient | HealthCareProfessional, encounter?: Encounter): Promise<Condition | undefined>;
    searchByPatients(pats: Patient[]): Promise<Condition[] | undefined>;
}
