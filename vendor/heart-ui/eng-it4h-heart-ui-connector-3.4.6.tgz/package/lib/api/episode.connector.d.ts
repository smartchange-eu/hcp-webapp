import { Episode, Patient } from "@eng-it4h/heart-ui-model";
export interface EpisodeConnector {
    searchEpisodesByPatient(patient: Patient, disableCache?: boolean, retrieveAll?: boolean, callback?: (allItems: (any)[]) => Promise<void>): Promise<Episode[] | void>;
    /**
     *
     * @param nName - matches any of the string field name/alias
     */
    searchEpisodes(): Promise<Episode[]>;
    searchByReference(reference: Episode): Promise<Episode>;
    create(episode: Episode): Promise<Episode>;
    update(episode: Episode): Promise<void>;
    enrichEpisode(episode: Episode): Promise<Episode>;
}
