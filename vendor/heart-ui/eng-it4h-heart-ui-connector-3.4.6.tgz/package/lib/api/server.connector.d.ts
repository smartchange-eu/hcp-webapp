import { DomainResource } from '@eng-it4h/fhir-r5';
import { Shareable } from '@eng-it4h/heart-ui-model';
export interface ServerConnector {
    transaction(resources: DomainResource[]): Promise<boolean>;
    transactionWithShareable(resources: Shareable[]): Promise<boolean>;
    batch(resources: DomainResource[]): Promise<boolean>;
}
