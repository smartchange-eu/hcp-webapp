import { Goal, Patient } from '@eng-it4h/heart-ui-model';
export interface GoalConnector {
    searchByPatient(patient: Patient, status?: Goal.GoalStatus): Promise<Goal[]>;
    searchByReference(goal: Goal): Promise<Goal>;
    updateMacro(macro: Goal[]): Promise<void | Goal[]>;
    deleteAll(goals: Goal[]): Promise<void>;
}
