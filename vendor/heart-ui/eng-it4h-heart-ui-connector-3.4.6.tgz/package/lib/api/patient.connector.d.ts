import { Patient, PatientHealthStatus, ObservePatient, HealthCareProfessional, ChatSettings, User, Organization } from '@eng-it4h/heart-ui-model';
import { ServerError } from '../connectors/server-error.model';
import { UserConnector } from './user.connector';
export declare type HealthStatusAndObserve = {
    healthStatus?: PatientHealthStatus;
    observe?: ObservePatient;
};
export declare type PatientHealthStatusAndObserve = {
    patient: Patient;
    settings?: HealthStatusAndObserve;
};
export interface PatientConnector extends UserConnector {
    registerUser(user: User): Promise<Patient | ServerError>;
    eraseUserAndData(patient: Patient): Promise<any>;
    searchHealthStatusAndObservableByPatientReference(patient: Patient, participant?: {
        organization: Organization;
        practitioner: HealthCareProfessional;
    }): Promise<HealthStatusAndObserve | undefined>;
    searchHealthStatusAndObservableByName(fullName: string, participant?: {
        organization: Organization;
        practitioner: HealthCareProfessional;
    }): Promise<PatientHealthStatusAndObserve[]>;
    searchPatients(fullName?: string, disableCache?: boolean, retrieveAll?: boolean, participant?: {
        organization?: Organization;
        practitioner?: HealthCareProfessional;
    }, onlyWithActivePlan?: boolean, callback?: (allItems: any[], newItems?: any[]) => Promise<void>): Promise<void | Patient[]>;
    searchPatientByUUID(uuid?: string): Promise<Patient | undefined>;
    searchPatientByUsername(username?: string): Promise<Patient | undefined>;
    searchPatientsByReferences(references: Patient[]): Promise<Patient[]>;
    searchPatientsWithVCF(): Promise<Patient[] | void[]>;
    create(patient: Patient): Promise<number>;
    update(patient: Patient): Promise<string>;
    isPseudonymAvailable(pseudonym: string): Promise<boolean>;
    getAllChatSettings(practitioner: HealthCareProfessional): Promise<ChatSettings[]>;
    getChatSettings(patient: Patient, practitioner: HealthCareProfessional): Promise<ChatSettings | undefined>;
    saveChatSettings(chatSettings: ChatSettings): Promise<ChatSettings>;
    updateObservePatient(observe: ObservePatient): Promise<ObservePatient>;
    updatePatientHealthStatus(healthStatus: PatientHealthStatus): Promise<PatientHealthStatus>;
}
