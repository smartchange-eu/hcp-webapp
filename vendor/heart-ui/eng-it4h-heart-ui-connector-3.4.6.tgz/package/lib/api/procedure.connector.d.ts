import { Patient, Procedure, Workout } from '@eng-it4h/heart-ui-model';
export interface ProcedureConnector {
    searchWorkoutByPatient(patient: Patient, period?: {
        from: Date;
        to: Date;
    }, limit?: number): Promise<Workout[]>;
    searchByReference(procedure: Procedure): Promise<Procedure | undefined>;
}
