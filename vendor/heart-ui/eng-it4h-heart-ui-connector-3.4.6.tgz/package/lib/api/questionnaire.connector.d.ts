import { CodedValue, Encounter, ResponseStatus } from '@eng-it4h/heart-ui-model';
import { HealthCareProfessional } from '@eng-it4h/heart-ui-model';
import { Questionnaire, Patient, QuestionnaireResponse } from '@eng-it4h/heart-ui-model';
export interface QuestionnaireConnector {
    /**
     *
     * @param ignoreExpansionForValueSets - ValueSet for which it is not expected the expasion (e.g. they are too big)
     */
    search(ignoreExpansionForValueSets?: CodedValue[], sortValues?: boolean): Promise<Questionnaire[]>;
    /**
     *
     * @param reference
     * @param ignoreExpansionForValueSets - ValueSet for which it is not expected the expasion (e.g. they are too big)
     */
    searchByReference(reference: Questionnaire, ignoreExpansionForValueSets?: CodedValue[], sortValues?: boolean): Promise<Questionnaire | undefined>;
    createResponse(response: QuestionnaireResponse, author?: Patient | HealthCareProfessional, encounter?: Encounter): Promise<QuestionnaireResponse>;
    hasResponse(questionnaire: Questionnaire, patient: Patient): Promise<boolean>;
    searchResponse(questionnaire?: Questionnaire, patient?: Patient, repeatableAnswerGroupIDs?: string[], latest?: boolean): Promise<QuestionnaireResponse[]>;
    /**
     * Updates the whole QuestionnaireResponse resource and ensures that the author of the change is traced
     *
     * @param response
     */
    updateResponse(response: QuestionnaireResponse, author?: Patient | HealthCareProfessional, encounter?: Encounter): Promise<QuestionnaireResponse | undefined>;
    /**
     * Changes only the status of the QuestionnaireResponse and ensures that the author of the change is traced
     *
     * @param questionnaireResponse
     * @param status
     * @param author
     */
    updateStatus(questionnaireResponse: QuestionnaireResponse, status: ResponseStatus, author?: Patient | HealthCareProfessional): Promise<QuestionnaireResponse | undefined>;
}
