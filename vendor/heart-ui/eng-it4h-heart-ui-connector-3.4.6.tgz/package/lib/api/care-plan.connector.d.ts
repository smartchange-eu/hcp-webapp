import { Plan, Patient, PlanDefinition } from '@eng-it4h/heart-ui-model';
export interface CarePlanConnector {
    searchByPatient(patient: Patient, status?: Plan.PlanStatus, limit?: number): Promise<Plan[]>;
    searchByReference(plan: Plan): Promise<Plan | undefined>;
    update(plan: Plan): Promise<Plan>;
    create(plan: Plan): Promise<Plan>;
    searchPlanDefinitions(): Promise<PlanDefinition[]>;
}
