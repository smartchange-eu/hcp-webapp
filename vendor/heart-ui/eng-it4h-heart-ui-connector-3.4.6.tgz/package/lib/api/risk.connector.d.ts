import { Patient, Risk } from '@eng-it4h/heart-ui-model';
export interface RiskConnector {
    search(): Promise<Risk[]>;
    create(condition: Risk): Promise<Risk>;
    remove(risk: Risk): Promise<void>;
    searchByPatient(pat: Patient): Promise<Risk[] | undefined>;
    addAllRisks(risks: Risk[]): Promise<void | Risk[]>;
    searchLatestByPatient(pat: Patient): Promise<Risk[] | undefined>;
}
