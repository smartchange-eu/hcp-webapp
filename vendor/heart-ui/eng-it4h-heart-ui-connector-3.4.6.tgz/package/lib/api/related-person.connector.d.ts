import { CareGiver, Patient } from '@eng-it4h/heart-ui-model';
export interface RelatedPersonConnector {
    create(relatedPerson: CareGiver): Promise<CareGiver>;
    createAll(relatedPersons: CareGiver[]): Promise<CareGiver[]>;
    update(relatedPerson: CareGiver): Promise<void>;
    delete(relatedPerson: CareGiver, cascade?: boolean): Promise<void>;
    searchByReference(reference: CareGiver, withSeeAlso?: boolean): Promise<CareGiver>;
    searcByPatient(patient: Patient, withSeeAlso?: boolean): Promise<CareGiver[]>;
    searcByPatients(patients: Patient[]): Promise<CareGiver[]>;
}
