import { Patient, Study } from '@eng-it4h/heart-ui-model';
import { Observable } from 'rxjs';
export interface GenomicStudyConnector {
    searchGenomicStudiesByPatient(patient: Patient, retrieveAll?: boolean, callback?: (allItems: (any)[]) => Promise<void>): Observable<Study[] | void>;
    retrieveCramUrl(reference: string): Promise<string[] | undefined>;
}
