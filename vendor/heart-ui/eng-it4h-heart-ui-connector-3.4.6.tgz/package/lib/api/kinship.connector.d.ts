import { Kinship, Patient } from "@eng-it4h/heart-ui-model";
export interface KinshipConnector {
    create(enrichedPatient: Patient): Promise<boolean>;
    update(enrichedPatient: Patient): Promise<Patient>;
    delete(patient: Patient, kinship: Kinship): Promise<Patient>;
    searchByPatient(patient: Patient): Promise<Patient>;
}
