import { Patient, PatientConsent } from '@eng-it4h/heart-ui-model';
export interface ConsentConnector {
    searchConsentsByPatient(patient: Patient, retrieveAll?: boolean, callback?: (allItems: (any)[]) => Promise<void>): Promise<PatientConsent[] | void>;
    create(consent: PatientConsent): Promise<PatientConsent>;
    update(consent: PatientConsent): Promise<void>;
    getContentAttachmentURL(consent: PatientConsent): string | undefined;
    uploadConsentFiles(consent: PatientConsent, file: File, callback?: (progress: number, loaded: number, size: number) => void): Promise<string>;
}
