import { ClinicalNote, Encounter, HealthCareProfessional, Patient, Person } from '@eng-it4h/heart-ui-model';
export declare type ClinicalNotesFilter = {
    patient: Patient;
    filters: {
        tag?: string;
        author?: Person;
        limit?: number;
        offset?: number;
    };
};
export interface ClinicalNoteConnector {
    searchByPatient(config: ClinicalNotesFilter): Promise<{
        articles: ClinicalNote[];
        articlesCount: number;
    }>;
    searchByReference(clinicalNote: ClinicalNote): Promise<ClinicalNote | undefined>;
    delete(clinicalNote: ClinicalNote): Promise<boolean>;
    save(practitioner: HealthCareProfessional, article: ClinicalNote, encounter?: Encounter): Promise<ClinicalNote>;
    getAllComments(refers: ClinicalNote): Promise<ClinicalNote[]>;
    addComment(practitioner: HealthCareProfessional, refers: ClinicalNote, commentBody: string): Promise<ClinicalNote | undefined>;
    deleteComment(id: number, refers: ClinicalNote): Promise<boolean>;
}
