import { Organization } from '@eng-it4h/heart-ui-model';
export interface OrganizationConnector {
    searchOrganizationsByName(name: string, retrieveAll?: boolean, callback?: (allItems: any[]) => Promise<void>): Promise<Organization[] | void>;
    /**
     *
     * @param nName - matches any of the string field name/alias
     */
    searchOrganizations(): Promise<Organization[]>;
    searchByReference(reference: Organization): Promise<Organization>;
    create(reference: Organization): Promise<Organization>;
    update(reference: Organization): Promise<Organization>;
}
