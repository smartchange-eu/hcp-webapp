import { Encounter, Organization, Patient } from '@eng-it4h/heart-ui-model';
export interface EncounterConnector {
    searchEncountersByPatient(patient: Patient, disableCache?: boolean, retrieveAll?: boolean, callback?: (allItems: any[]) => Promise<void>): Promise<Encounter[] | void>;
    searchEncountersByProvider(provider: Organization, disableCache?: boolean, retrieveAll?: boolean, callback?: (allItems: any[]) => Promise<void>): Promise<Encounter[] | void>;
    /**
     *
     * @param nName - matches any of the string field name/alias
     */
    searchEncounters(): Promise<Encounter[]>;
    searchByReference(reference: Encounter): Promise<Encounter>;
    create(encounter: Encounter): Promise<Encounter>;
    update(encounter: Encounter): Promise<void>;
    enrichEncounter(encounter: Encounter): Promise<Encounter>;
}
