import * as i0 from "@angular/core";
import * as i1 from "./bmi-on-matrix.component";
import * as i2 from "@angular/common";
export declare class BmiOnMatrixModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BmiOnMatrixModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BmiOnMatrixModule, [typeof i1.BmiOnMatrixComponent], [typeof i2.CommonModule], [typeof i1.BmiOnMatrixComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BmiOnMatrixModule>;
}
