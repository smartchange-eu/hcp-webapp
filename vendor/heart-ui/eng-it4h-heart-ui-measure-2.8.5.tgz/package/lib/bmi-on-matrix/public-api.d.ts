export * from './bmi-on-matrix.module';
export * from './bmi-on-matrix.component';
