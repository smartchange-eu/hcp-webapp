import { OnInit } from '@angular/core';
import { BMI } from '@eng-it4h/heart-ui-model';
import * as i0 from "@angular/core";
export declare class BmiOnMatrixComponent implements OnInit {
    bmi: BMI;
    underweight: number[];
    healthy: number[];
    overweight: number[];
    obese: number[];
    extremelyobese: number[];
    min: number;
    max: number;
    thresholdConfig: {
        '12': {
            color: string;
            bgOpacity: number;
        };
        '19': {
            color: string;
            bgOpacity: number;
        };
        '25': {
            color: string;
            bgOpacity: number;
        };
        '30': {
            color: string;
            bgOpacity: number;
        };
        '42': {
            color: string;
            bgOpacity: number;
        };
    };
    markers: {
        "19": {
            color: string;
            type: string;
            size: number;
            label: string;
            font: string;
        };
        "24": {
            color: string;
            type: string;
            size: number;
            label: string;
            font: string;
        };
        "29": {
            color: string;
            type: string;
            size: number;
            label: string;
            font: string;
        };
        "41": {
            color: string;
            type: string;
            size: number;
            label: string;
            font: string;
        };
    };
    gaugeValue: any;
    gaugeLabel: string;
    gaugeAppendText: string;
    size: number;
    thick: number;
    margin: number;
    style: string;
    constructor();
    ngOnInit(): void;
    ngOnChanges(): void;
    update(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BmiOnMatrixComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BmiOnMatrixComponent, "heart-bmi-on-matrix", never, { "bmi": "bmi"; }, {}, never, never, false, never>;
}
