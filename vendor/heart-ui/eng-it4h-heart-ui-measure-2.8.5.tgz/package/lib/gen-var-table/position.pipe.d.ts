import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class PoistionPipe implements PipeTransform {
    private SEPARATOR;
    private START_CHAR;
    private END_CHAR;
    constructor();
    transform(value: number[]): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PoistionPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<PoistionPipe, "position", false>;
}
