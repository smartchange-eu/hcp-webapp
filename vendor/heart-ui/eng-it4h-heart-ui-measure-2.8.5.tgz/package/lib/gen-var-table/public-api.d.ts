export * from './gen-var-table.module';
export * from './gen-var-table.component';
