import { OnInit } from "@angular/core";
import { MatDialogRef } from "@angular/material/dialog";
import { GenomicVariant } from "@eng-it4h/heart-ui-model";
import * as i0 from "@angular/core";
export declare class GenVarDetail implements OnInit {
    dialogRef: MatDialogRef<GenVarDetail>;
    data: any;
    item: GenomicVariant;
    closeLabel: string;
    okLabel: string;
    lang: string;
    separator: string;
    constructor(dialogRef: MatDialogRef<GenVarDetail>, data: any);
    ngOnInit(): void;
    save(): void;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GenVarDetail, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GenVarDetail, "gen-var-detail", never, {}, {}, never, never, false, never>;
}
