import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class PhenoPipe implements PipeTransform {
    private SEPARATOR;
    constructor();
    transform(value: string[], separator?: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PhenoPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<PhenoPipe, "pheno", false>;
}
