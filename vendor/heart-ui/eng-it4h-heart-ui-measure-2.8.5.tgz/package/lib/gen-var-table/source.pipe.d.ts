import { PipeTransform } from '@angular/core';
import { CodedValue } from '@eng-it4h/heart-ui-model';
import * as i0 from "@angular/core";
export declare class SourcePipe implements PipeTransform {
    private map;
    constructor();
    transform(value: CodedValue): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SourcePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SourcePipe, "source", false>;
}
