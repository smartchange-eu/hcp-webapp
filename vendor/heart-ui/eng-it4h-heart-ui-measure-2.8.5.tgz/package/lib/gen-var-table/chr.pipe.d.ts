import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ChrPipe implements PipeTransform {
    private divider;
    constructor();
    transform(value: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChrPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ChrPipe, "chr", false>;
}
