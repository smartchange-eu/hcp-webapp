import { PipeTransform } from '@angular/core';
import { MolecularConsequence } from '@eng-it4h/heart-ui-model';
import * as i0 from "@angular/core";
export declare class MolecularPipe implements PipeTransform {
    private SEPARATOR;
    constructor();
    transform(molConseqs: MolecularConsequence[], type: string): string;
    joinStringArray(toJoin: string[]): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<MolecularPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<MolecularPipe, "molecular", false>;
}
