import { FormGroup } from '@angular/forms';
import { CodedValueQuestion, GenericQuantitativeFormStructure, GenericQuantitativeMeasure, QuantitativeSectionFormStructure } from '@eng-it4h/heart-ui-model';
export declare class FormMeasureService {
    static dateTimeControlName: string;
    static noteControlName: string;
    constructor();
    generateArrayOfMeasure(form: FormGroup, structure: GenericQuantitativeFormStructure, sectionsOrder: string[], questionsOrder: Map<number, string[]>): GenericQuantitativeMeasure[];
    private generateMeasure;
    getSection(structure: GenericQuantitativeFormStructure, secPos: number): QuantitativeSectionFormStructure;
    getQuestion(structure: GenericQuantitativeFormStructure, secPos: number, qPos: number): CodedValueQuestion;
    private hasComponents;
    private checkAndMergeComponents;
}
