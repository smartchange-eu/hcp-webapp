import { EventEmitter, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { QuantitativeSectionFormStructure, GenericQuantitativeMeasure, CodedValueQuestion, GenericQuantitativeFormStructure, Choice } from '@eng-it4h/heart-ui-model';
import { SubTranslateService } from '@eng-it4h/heart-ui-utils';
import { FormMeasureService } from './form-measure.service';
import { NgxMatDateAdapter } from '@angular-material-components/datetime-picker';
import * as i0 from "@angular/core";
export declare class GenericQuantitativeFormComponent implements OnInit, OnChanges {
    private _dateAdapter;
    private _subTranslateService;
    private _formMeasureService;
    dateTimeControlName: string;
    noteControlName: string;
    protected maxValuesForRadio: number;
    /**
     * ASPECT SETTINGS
     */
    appearance: 'fill' | 'outline';
    lang: string;
    forceRadioButton: boolean;
    /**
     * OPERATING MODE SETTINGS
     */
    readOnly: boolean;
    enableActionButtons: boolean;
    editMode?: boolean;
    mandTimestamp: boolean;
    showNotes: boolean;
    customButtonLabel: string;
    structure: GenericQuantitativeFormStructure;
    alreadyCollected?: GenericQuantitativeMeasure[];
    measures: EventEmitter<GenericQuantitativeMeasure[]>;
    protected sectionsOrder: string[];
    protected questionsOrder: Map<number, string[]>;
    protected form: FormGroup;
    protected defaultTime: any[];
    constructor(_dateAdapter: NgxMatDateAdapter<Date>, _subTranslateService: SubTranslateService, _formMeasureService: FormMeasureService);
    ngOnInit(): void;
    private refresh;
    ngOnChanges(changes: SimpleChanges): void;
    private createDictionary;
    private createForm;
    createFormControl(s: QuantitativeSectionFormStructure, alreadyCollected?: GenericQuantitativeMeasure[]): FormGroup;
    private getValue;
    private updateExisting;
    protected onSubmit(arg: any): void;
    protected getSection(secPos: number): QuantitativeSectionFormStructure;
    protected getQuestion(secPos: number, qPos: number): CodedValueQuestion;
    protected isFormValid(): boolean;
    protected getPermittedAnswers(question: CodedValueQuestion): Choice[];
    correctlySaved(): void;
    hasError(control: FormGroup, key: string, error: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<GenericQuantitativeFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GenericQuantitativeFormComponent, "heart-generic-quantitative-form", never, { "appearance": "appearance"; "lang": "lang"; "forceRadioButton": "forceRadioButton"; "readOnly": "readOnly"; "enableActionButtons": "enableActionButtons"; "editMode": "editMode"; "mandTimestamp": "mandTimestamp"; "showNotes": "showNotes"; "customButtonLabel": "customButtonLabel"; "structure": "structure"; "alreadyCollected": "alreadyCollected"; }, { "measures": "measures"; }, never, never, false, never>;
}
