export declare const en: {
    "measure.generic-form.xxx.label": string;
};
