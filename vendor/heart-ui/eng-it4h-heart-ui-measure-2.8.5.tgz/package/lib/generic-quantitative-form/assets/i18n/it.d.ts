export declare const it: {
    "measure.generic-form.datetime.label": string;
    "measure.generic-form.notes.label": string;
    "measure.generic-form.save.label": string;
    "measure.generic-form.nothing.label": string;
};
