export * from './generic-quantitative-form.module';
export * from './generic-quantitative-form.component';
