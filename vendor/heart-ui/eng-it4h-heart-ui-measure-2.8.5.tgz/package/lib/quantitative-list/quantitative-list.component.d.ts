import { EventEmitter, OnInit } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { QuantitativeMeasure } from '@eng-it4h/heart-ui-model';
import * as i0 from "@angular/core";
export declare class QuantitativeListComponent implements OnInit {
    items: QuantitativeMeasure[];
    paginationOptions: number[];
    pageSize: number;
    title: string;
    selected: EventEmitter<QuantitativeMeasure>;
    stdPaginationOptions: number[];
    stdPageSize: number;
    displayedColumns: string[];
    dataSource: MatTableDataSource<QuantitativeMeasure>;
    paginator: MatPaginator;
    sort: MatSort;
    constructor();
    ngOnInit(): void;
    ngAfterViewInit(): void;
    applyFilter(event: Event): void;
    clicked(row: QuantitativeMeasure): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuantitativeListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuantitativeListComponent, "heart-quantitative-list", never, { "items": "items"; "paginationOptions": "paginationOptions"; "pageSize": "pageSize"; "title": "title"; }, { "selected": "selected"; }, never, never, false, never>;
}
