export * from './quantitative-list.module';
export * from './quantitative-list.component';
