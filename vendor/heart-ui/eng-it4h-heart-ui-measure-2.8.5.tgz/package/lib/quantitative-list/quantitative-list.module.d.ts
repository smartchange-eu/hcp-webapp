import * as i0 from "@angular/core";
import * as i1 from "./quantitative-list.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/material/table";
import * as i4 from "@angular/material/form-field";
import * as i5 from "@angular/material/paginator";
import * as i6 from "@angular/material/input";
import * as i7 from "@angular/material/sort";
export declare class QuantitativeListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuantitativeListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuantitativeListModule, [typeof i1.QuantitativeListComponent], [typeof i2.CommonModule, typeof i3.MatTableModule, typeof i4.MatFormFieldModule, typeof i5.MatPaginatorModule, typeof i6.MatInputModule, typeof i7.MatSortModule], [typeof i1.QuantitativeListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuantitativeListModule>;
}
