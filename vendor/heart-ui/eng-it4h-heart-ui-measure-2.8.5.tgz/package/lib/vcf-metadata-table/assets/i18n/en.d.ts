export declare const en: {
    "measure.vcf-metadata-table.***.***": string;
};
