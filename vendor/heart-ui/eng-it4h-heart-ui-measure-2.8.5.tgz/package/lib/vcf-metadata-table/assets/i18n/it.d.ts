export declare const it: {
    "measure.vcf-metadata-table.***.***": string;
    "measure.vcf-metadata-table.filter.label": string;
    "measure.vcf-metadata-table.filter.placeholder": string;
    "measure.vcf-metadata-table.button.refresh": string;
    "measure.vcf-metadata-table.table.header.id": string;
    "measure.vcf-metadata-table.table.header.date": string;
    "measure.vcf-metadata-table.table.header.specimen": string;
    "measure.vcf-metadata-table.table.header.sequencing": string;
    "measure.vcf-metadata-table.table.header.cram": string;
    "measure.vcf-metadata-table.table.no-data": string;
    "measure.vcf-metadata-table.table.paginator.label": string;
    "measure.vcf-metadata-table.cram.not-available": string;
};
