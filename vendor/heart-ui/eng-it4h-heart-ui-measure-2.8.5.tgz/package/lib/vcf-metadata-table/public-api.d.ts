export * from './vcf-metadata-table.module';
export * from './vcf-metadata-table.component';
