import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as i0 from "@angular/core";
import * as i1 from "./vcf-metadata-table.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/material/table";
import * as i4 from "@angular/material/form-field";
import * as i5 from "@angular/material/paginator";
import * as i6 from "@angular/material/input";
import * as i7 from "@angular/material/sort";
import * as i8 from "@eng-it4h/heart-ui-utils";
import * as i9 from "@angular/material/button";
import * as i10 from "@angular/material/tooltip";
import * as i11 from "@angular/material/icon";
import * as i12 from "@ngx-translate/core";
export declare function HttpLoaderFactoryVcfMetadataList(http: HttpClient): TranslateHttpLoader;
export declare class VcfMetadataTableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<VcfMetadataTableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VcfMetadataTableModule, [typeof i1.VcfMetadataTableComponent], [typeof i2.CommonModule, typeof i3.MatTableModule, typeof i4.MatFormFieldModule, typeof i5.MatPaginatorModule, typeof i6.MatInputModule, typeof i7.MatSortModule, typeof i8.SubTranslateModule, typeof i9.MatButtonModule, typeof i10.MatTooltipModule, typeof i11.MatIconModule, typeof i12.TranslateModule], [typeof i1.VcfMetadataTableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VcfMetadataTableModule>;
}
