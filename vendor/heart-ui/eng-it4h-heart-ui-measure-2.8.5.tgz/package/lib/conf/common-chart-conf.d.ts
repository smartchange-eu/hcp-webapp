import { Color } from '@swimlane/ngx-charts';
export declare class CommonChartConf {
    static defaultColorScheme: Color;
    static view: any[];
    static legend: boolean;
    static showLabels: boolean;
    static animations: boolean;
    static xAxis: boolean;
    static yAxis: boolean;
    static showYAxisLabel: boolean;
    static showXAxisLabel: boolean;
    static unitAsYAxis: boolean;
    static xAxisLabel: string;
    static yAxisLabel: string;
    static timeline: boolean;
    static colorScheme: Color;
    static dateFormat: string;
    static gradient: boolean;
    static percentilesTimespan: number;
    static showDots: boolean;
}
