import { ElementRef, OnInit, AfterViewInit } from '@angular/core';
import { QuantitativeMeasure } from '@eng-it4h/heart-ui-model';
import { LegendPosition, Color } from '@swimlane/ngx-charts';
import { SubTranslateService } from '@eng-it4h/heart-ui-utils';
import { TranslateService } from '@ngx-translate/core';
import { CentileValue } from '../common/centiles.model';
import { DateSeries, Point } from '../common/data-series.model';
import * as i0 from "@angular/core";
export declare class QuantitativeLinechartComponent implements OnInit, AfterViewInit {
    private _subTranslateService;
    private _translateService;
    protected lineChartRef?: ElementRef;
    items: QuantitativeMeasure[];
    xAxisLabel: string;
    yAxisLabel: string;
    showLegend: boolean;
    showYAxisLabel: boolean;
    showXAxisLabel: boolean;
    dataLabel: string;
    timeline: boolean;
    percentilesTimespan: number;
    title: string;
    lang: string;
    dateFormat: string;
    monthPercentiles?: Map<number, CentileValue[]>;
    birthDate?: Date;
    unitAsYAxis: boolean;
    colorScheme?: Color;
    showDots: boolean;
    showNotes: boolean;
    showLabels: boolean;
    animations: boolean;
    xAxis: boolean;
    yAxis: boolean;
    gradient: boolean;
    protected unit: string;
    toShow: DateSeries[];
    private dataSeries;
    private centilesSeries;
    private cHelper;
    protected singlePointSeriesIndex: number[];
    protected yAxisLabelToRender: string;
    constructor(_subTranslateService: SubTranslateService, _translateService: TranslateService);
    createDictionary(): void;
    ngOnInit(): void;
    render(): void;
    private highlightData;
    prepareDataStructure(): void;
    ngAfterViewInit(): void;
    toSeriesArray(map: Map<string, Point[]>): DateSeries[];
    private manageComponents;
    onSelect(event: any): void;
    getTranslation(key: string): any;
    xAxisTickFormatting: (val: any) => any;
    /**
     * Maps an age-based percentile table to a format compatible with the chart.
     * @param percentiles Array of objects where each represents age and associated percentile values.
     * @returns Formatted series data for the chart.
     */
    private mapAgePercentilesToSeries;
    get showCentiles(): boolean;
    get legendPosition(): LegendPosition;
    customColors: (statName: string) => string;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuantitativeLinechartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuantitativeLinechartComponent, "heart-quantitative-linechart", never, { "items": "items"; "xAxisLabel": "xAxisLabel"; "yAxisLabel": "yAxisLabel"; "showLegend": "showLegend"; "showYAxisLabel": "showYAxisLabel"; "showXAxisLabel": "showXAxisLabel"; "dataLabel": "dataLabel"; "timeline": "timeline"; "percentilesTimespan": "percentilesTimespan"; "title": "title"; "lang": "lang"; "dateFormat": "dateFormat"; "monthPercentiles": "monthPercentiles"; "birthDate": "birthDate"; "unitAsYAxis": "unitAsYAxis"; "colorScheme": "colorScheme"; "showDots": "showDots"; "showNotes": "showNotes"; }, {}, never, never, false, never>;
}
