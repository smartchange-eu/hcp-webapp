import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient } from '@angular/common/http';
import * as i0 from "@angular/core";
import * as i1 from "./quantitative-linechart.component";
import * as i2 from "@angular/common";
import * as i3 from "@swimlane/ngx-charts";
import * as i4 from "@angular/common/http";
import * as i5 from "@eng-it4h/heart-ui-utils";
import * as i6 from "@ngx-translate/core";
export declare function HttpLoaderFactoryQuantitativeLinechart(http: HttpClient): TranslateHttpLoader;
export declare class QuantitativeLinechartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuantitativeLinechartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuantitativeLinechartModule, [typeof i1.QuantitativeLinechartComponent], [typeof i2.CommonModule, typeof i3.LineChartModule, typeof i4.HttpClientModule, typeof i5.SubTranslateModule, typeof i6.TranslateModule], [typeof i1.QuantitativeLinechartComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuantitativeLinechartModule>;
}
