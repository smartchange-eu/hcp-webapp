export declare const en: {
    "measure.bmi.label": string;
    "measure.weight.label": string;
};
