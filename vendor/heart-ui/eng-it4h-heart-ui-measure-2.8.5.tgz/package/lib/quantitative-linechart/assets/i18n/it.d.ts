export declare const it: {
    "measure.bmi.label": string;
    "measure.weight.label": string;
};
