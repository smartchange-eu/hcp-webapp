export * from './bmi-list.module';
export * from './bmi-list.component';
