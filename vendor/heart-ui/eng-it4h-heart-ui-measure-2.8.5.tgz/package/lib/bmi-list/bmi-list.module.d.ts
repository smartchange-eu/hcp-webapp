import * as i0 from "@angular/core";
import * as i1 from "./bmi-list.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/material/table";
import * as i4 from "@angular/material/form-field";
import * as i5 from "@angular/material/paginator";
import * as i6 from "@angular/material/input";
import * as i7 from "@angular/material/sort";
export declare class BmiListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BmiListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BmiListModule, [typeof i1.BmiListComponent], [typeof i2.CommonModule, typeof i3.MatTableModule, typeof i4.MatFormFieldModule, typeof i5.MatPaginatorModule, typeof i6.MatInputModule, typeof i7.MatSortModule], [typeof i1.BmiListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BmiListModule>;
}
