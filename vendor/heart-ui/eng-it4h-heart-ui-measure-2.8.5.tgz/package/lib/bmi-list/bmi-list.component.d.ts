import { EventEmitter, OnInit } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { BMI } from '@eng-it4h/heart-ui-model';
import * as i0 from "@angular/core";
export declare class BmiListComponent implements OnInit {
    stdPaginationOptions: number[];
    stdPageSize: number;
    displayedColumns: string[];
    dataSource: MatTableDataSource<BMI>;
    paginator: MatPaginator;
    sort: MatSort;
    items: BMI[];
    paginationOptions: number[];
    pageSize: number;
    selected: EventEmitter<BMI>;
    constructor();
    ngOnInit(): void;
    ngAfterViewInit(): void;
    applyFilter(event: Event): void;
    clicked(row: BMI): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BmiListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BmiListComponent, "heart-bmi-list", never, { "items": "items"; "paginationOptions": "paginationOptions"; "pageSize": "pageSize"; }, { "selected": "selected"; }, never, never, false, never>;
}
