export * from './bmi-barchart.module';
export * from './bmi-barchart.component';
