import * as i0 from "@angular/core";
import * as i1 from "./bmi-barchart.component";
import * as i2 from "@angular/common";
import * as i3 from "@swimlane/ngx-charts";
export declare class BmiBarchartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BmiBarchartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BmiBarchartModule, [typeof i1.BmiBarchartComponent], [typeof i2.CommonModule, typeof i3.BarChartModule], [typeof i1.BmiBarchartComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BmiBarchartModule>;
}
