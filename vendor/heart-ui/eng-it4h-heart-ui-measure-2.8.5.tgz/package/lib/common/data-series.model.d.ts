export declare class Point {
    name: Date;
    value: number;
    extra?: {
        unit?: string;
        note?: string;
        centile?: number;
    };
    constructor(name: Date, value: number, extra?: {
        unit?: string;
        note?: string;
        centile?: number;
    });
}
export declare class DateSeries {
    name: string;
    series: Point[];
    constructor(name: string, series: Point[]);
}
