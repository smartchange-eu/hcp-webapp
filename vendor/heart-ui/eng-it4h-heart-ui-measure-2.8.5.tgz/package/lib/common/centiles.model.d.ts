export declare class CentileValue {
    month: number;
    value: number;
    constructor(month: number, value: number);
}
