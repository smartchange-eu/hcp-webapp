export * from './quantitative-barchart.module';
export * from './quantitative-barchart.component';
