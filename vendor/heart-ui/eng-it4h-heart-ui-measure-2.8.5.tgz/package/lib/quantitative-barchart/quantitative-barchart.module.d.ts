import * as i0 from "@angular/core";
import * as i1 from "./quantitative-barchart.component";
import * as i2 from "@angular/common";
import * as i3 from "@swimlane/ngx-charts";
import * as i4 from "@ngx-translate/core";
export declare class QuantitativeBarchartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuantitativeBarchartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuantitativeBarchartModule, [typeof i1.QuantitativeBarchartComponent], [typeof i2.CommonModule, typeof i3.BarChartModule, typeof i4.TranslateModule], [typeof i1.QuantitativeBarchartComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuantitativeBarchartModule>;
}
