export * from './bmi-linechart.module';
export * from './bmi-linechart.component';
