import * as i0 from "@angular/core";
import * as i1 from "./bmi-linechart.component";
import * as i2 from "@angular/common";
import * as i3 from "@swimlane/ngx-charts";
export declare class BmiLinechartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BmiLinechartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BmiLinechartModule, [typeof i1.BmiLinechartComponent], [typeof i2.CommonModule, typeof i3.LineChartModule], [typeof i1.BmiLinechartComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BmiLinechartModule>;
}
