import * as i0 from '@angular/core';
import { EventEmitter, Component, ViewChild, Input, Output, NgModule } from '@angular/core';
import * as i3 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i6 from '@angular/material/paginator';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import * as i8 from '@angular/material/sort';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { EncounterStatus, AppointmentStatus, Appointment, EncounterType } from '@eng-it4h/heart-ui-model';
import * as i4 from '@angular/material/table';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { format, addHours, addMinutes } from 'date-fns';
import * as i1 from '@eng-it4h/heart-ui-utils';
import { SubTranslateModule, PreventDoubleClickModule } from '@eng-it4h/heart-ui-utils';
import * as i2 from '@ngx-translate/core';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import * as i5 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i7 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import * as i11 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i10 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i11$1 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as i4$1 from '@angular/forms';
import { FormsModule, FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import * as i7$1 from '@angular/material/datepicker';
import { MatDatepickerModule } from '@angular/material/datepicker';
import * as i2$1 from '@angular/material/core';
import { MAT_DATE_FORMATS, DateAdapter, MAT_DATE_LOCALE } from '@angular/material/core';
import { trigger, state, style, transition, animate } from '@angular/animations';
import * as i6$1 from '@angular/material/list';
import { MatListModule } from '@angular/material/list';
import { MAT_DATE_FNS_FORMATS, DateFnsAdapter } from '@angular/material-date-fns-adapter';
import { enGB } from 'date-fns/locale';
import * as i2$2 from '@angular-material-components/datetime-picker';
import { NgxMatTimepickerModule, NgxMatDatetimePickerModule, NgxMatNativeDateModule } from '@angular-material-components/datetime-picker';
import { MatCardModule } from '@angular/material/card';
import * as i8$1 from '@angular/material/select';
import { MatSelectModule } from '@angular/material/select';
import { MatSliderModule } from '@angular/material/slider';

const en$2 = {
    'encounter.table.filter.label': 'Filter',
    'encounter.table.header.type': 'Type',
    'encounter.table.header.openingDate': 'Opening date',
    'encounter.table.header.closingDate': 'Closing date',
    'encounter.table.header.reason': 'Reason',
    'encounter.table.header.organization': 'Organization',
    'encounter.table.header.status': 'Status',
    'encounter.table.no-data': 'No data matching the filter',
    'encounter.table.paginator.label': 'Select page of encounters',
    'encounter.table.button.refresh': 'Refresh List',
};

const it$2 = {
    "episode.table.filter.label": "Filtra",
    "episode.table.header.type": "Tipo",
    "episode.table.header.openingDate": "Data apertura",
    "episode.table.header.closingDate": "Data chiusura",
    "episode.table.header.reason": "Motivo",
    "episode.table.header.organization": "Organizzazione",
    "episode.table.header.status": "Stato",
    "episode.table.header.status.locked": "Bloccato",
    "episode.table.header.status.editable": "Modificabile",
    "episode.table.no-data": "Nessun dato corrispondente al filtro",
    "episode.table.paginator.label": "Seleziona la pagina degli utenti",
    "episode.table.button.refresh": "Ricarica Lista",
};

class HeartEncounterTableComponent {
    constructor(_subTranslateService, _translate) {
        this._subTranslateService = _subTranslateService;
        this._translate = _translate;
        this.stdDisplayedColumns = ['status', 'type', 'openingDate', 'closingDate', 'organization'];
        this.stdPaginationOptions = [5, 10, 25, 100];
        this.stdPageSize = 25;
        this.finishedStatus = EncounterStatus.COMPLETED;
        this.paginationOptions = [5, 10, 25, 100];
        this.pageSize = 25;
        this.enableRefreshButton = false;
        this.typeSystem = '';
        this.selected = new EventEmitter();
        this.askRefresh = new EventEmitter();
        this.lang = this.lang;
        this.createDictionary();
    }
    // approccio per unificare il servizio di traduzione
    createDictionary() {
        const dictionary = new Map();
        dictionary.set('en', en$2);
        dictionary.set('it', it$2);
        this._subTranslateService.setLanguages(dictionary);
    }
    ngDoCheck() {
        var _a;
        if (((_a = this.encounters) === null || _a === void 0 ? void 0 : _a.length) != this.prevLength) {
            this.refresh();
        }
    }
    ngOnChanges(changes) {
        this.refresh();
    }
    ngOnInit() { }
    ngAfterViewInit() {
        this.refresh();
    }
    refresh() {
        var _a, _b, _c, _d;
        this.prevLength = (_a = this.toShow) === null || _a === void 0 ? void 0 : _a.length;
        this.toShow = this.encounters;
        this.dataSource = new MatTableDataSource(this.encounters);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.displayedColumns = (_b = this.displayedColumns) !== null && _b !== void 0 ? _b : this.stdDisplayedColumns;
        this.pageSize = (_c = this.pageSize) !== null && _c !== void 0 ? _c : this.stdPageSize;
        this.paginationOptions = (_d = this.paginationOptions) !== null && _d !== void 0 ? _d : this.stdPaginationOptions;
        this.dataSource.filterPredicate = this.getFilterPredicate();
    }
    applyFilter(event) {
        const filterValue = event.target.value;
        this.dataSource.filter = filterValue.trim().toLowerCase();
        if (this.dataSource.paginator) {
            this.dataSource.paginator.firstPage();
        }
    }
    clicked(row) {
        this.selected.emit(row);
        console.log(this._translate.instant(row.type));
    }
    refreshList() {
        this.askRefresh.emit();
    }
    getFilterPredicate() {
        let filterPredicate = (data, value // filtering string
        ) => {
            var _a, _b, _c, _d, _e, _f;
            const matchFilter = [];
            // primitive
            matchFilter.push((_a = this._translate.instant(data.type)) === null || _a === void 0 ? void 0 : _a.toString().toLowerCase().includes(value.toLocaleLowerCase()));
            matchFilter.push((_c = (_b = data.serviceProvider) === null || _b === void 0 ? void 0 : _b.name) === null || _c === void 0 ? void 0 : _c.toString().toLowerCase().includes(value.toLocaleLowerCase()));
            matchFilter.push((_d = format(data.startDate, 'dd/MM/yyyy')) === null || _d === void 0 ? void 0 : _d.toString().toLowerCase().includes(value.toLocaleLowerCase()));
            matchFilter.push((_f = format((_e = data.closingDate) !== null && _e !== void 0 ? _e : data.startDate, 'dd/MM/yyyy')) === null || _f === void 0 ? void 0 : _f.toString().toLowerCase().includes(value.toLocaleLowerCase()));
            matchFilter.push(data.status.toString().toLowerCase().includes(value.toLocaleLowerCase()));
            return matchFilter.some(Boolean);
        };
        return filterPredicate;
    }
}
HeartEncounterTableComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartEncounterTableComponent, deps: [{ token: i1.SubTranslateService }, { token: i2.TranslateService }], target: i0.ɵɵFactoryTarget.Component });
HeartEncounterTableComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: HeartEncounterTableComponent, selector: "heart-encounter-table", inputs: { displayedColumns: "displayedColumns", encounters: "encounters", paginationOptions: "paginationOptions", pageSize: "pageSize", lang: "lang", enableRefreshButton: "enableRefreshButton", typeSystem: "typeSystem" }, outputs: { selected: "selected", askRefresh: "askRefresh" }, viewQueries: [{ propertyName: "paginator", first: true, predicate: MatPaginator, descendants: true }, { propertyName: "sort", first: true, predicate: MatSort, descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div>\n\n    <div class=\"d-flex flex-justify-between\">\n\n        <mat-form-field appearance=\"fill\">\n            <mat-label>{{ 'encounter.table.filter.label' | subtranslate:lang }}</mat-label>\n            <input matInput (keyup)=\"applyFilter($event)\"\n                placeholder=\"{{ 'encounter.table.filter.label' | subtranslate:lang }}\" #input>\n        </mat-form-field>\n\n        <button class=\"refreshButton\" *ngIf=\"enableRefreshButton\" mat-icon-button (click)=\"refreshList()\"\n            matTooltip=\"{{'encounter.table.button.refresh' | subtranslate:lang }}\" matTooltipPosition=\"above\">\n            <mat-icon>refresh</mat-icon>\n        </button>\n\n    </div>\n\n    <div class=\"mat-elevation-z8\">\n        <table mat-table [dataSource]=\"dataSource\" matSort>\n\n            <ng-container matColumnDef=\"type\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{ 'encounter.table.header.type' |\n                    subtranslate:lang }} </th>\n                <td mat-cell *matCellDef=\"let row\" class=\"medium-field\"> {{typeSystem+'|'+row.type | translate}} </td>\n            </ng-container>\n\n            <ng-container matColumnDef=\"openingDate\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{ 'encounter.table.header.openingDate' |\n                    subtranslate:lang }} </th>\n                <td mat-cell *matCellDef=\"let row\" class=\"date-field\"> {{row.startDate | date:'dd/MM/yyyy'}} </td>\n            </ng-container>\n\n            <ng-container matColumnDef=\"closingDate\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{ 'encounter.table.header.closingDate' |\n                    subtranslate:lang }} </th>\n                <td mat-cell *matCellDef=\"let row\" class=\"date-field\"> {{row.closingDate?? '' | date:'dd/MM/yyyy'}}\n                </td>\n            </ng-container>\n\n            <ng-container matColumnDef=\"organization\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{ 'encounter.table.header.organization' |\n                    subtranslate:lang }} </th>\n                <td mat-cell *matCellDef=\"let row\" class=\"large-field\"> {{row.serviceProvider?.name}} </td>\n            </ng-container>\n\n            <ng-container matColumnDef=\"status\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{ 'encounter.table.header.status' |\n                    subtranslate:lang }} </th>\n                <td mat-cell *matCellDef=\"let row\" class=\"icon-field\">\n                    <!-- TODO: leggerlo da elenco statico del component -->\n                    <mat-icon *ngIf=\"row.status == finishedStatus; else edit \"\n                        matTooltip=\"{{ 'encounter.table.header.status.locked' | subtranslate:lang }}\"\n                        matTooltipPosition=\"before\">\n                        lock\n                    </mat-icon>\n                    <ng-template #edit>\n                        <mat-icon matTooltip=\"{{ 'encounter.table.header.status.editable' | subtranslate:lang }}\"\n                            matTooltipPosition=\"before\">edit</mat-icon>\n                    </ng-template>\n                </td>\n            </ng-container>\n\n            <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n            <tr mat-row mat-row (click)=\"clicked(row)\" *matRowDef=\"let row; columns: displayedColumns;\"></tr>\n\n            <!-- Row shown when there is no matching data. -->\n            <tr class=\"mat-row\" *matNoDataRow>\n                <td class=\"mat-cell\" colspan=\"4\">{{ 'encounter.table.no-data' | subtranslate:lang }} \"{{input.value}}\"\n                </td>\n            </tr>\n        </table>\n\n        <mat-paginator [pageSizeOptions]=\"paginationOptions\" [pageSize]=\"pageSize\"></mat-paginator>\n    </div>\n</div>", styles: [".container{margin:16px!important}table{width:100%;margin-bottom:16px}mat-form-field{flex-grow:2;height:auto!important}.refreshButton{margin-top:10px;margin-left:16px!important;margin-right:16px!important}.mat-mdc-row .mat-mdc-cell{border-bottom:1px solid transparent;border-top:1px solid transparent;cursor:pointer}.icon-field{width:5vw}.date-field{width:10vw}.small-field{min-width:150px;max-width:10vw}.medium-field{min-width:12vw;max-width:25vw;flex-basis:25%}.large-field{min-width:25vw;max-width:40vw}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i4.MatTable, selector: "mat-table, table[mat-table]", exportAs: ["matTable"] }, { kind: "directive", type: i4.MatHeaderCellDef, selector: "[matHeaderCellDef]" }, { kind: "directive", type: i4.MatHeaderRowDef, selector: "[matHeaderRowDef]", inputs: ["matHeaderRowDef", "matHeaderRowDefSticky"] }, { kind: "directive", type: i4.MatColumnDef, selector: "[matColumnDef]", inputs: ["sticky", "matColumnDef"] }, { kind: "directive", type: i4.MatCellDef, selector: "[matCellDef]" }, { kind: "directive", type: i4.MatRowDef, selector: "[matRowDef]", inputs: ["matRowDefColumns", "matRowDefWhen"] }, { kind: "directive", type: i4.MatHeaderCell, selector: "mat-header-cell, th[mat-header-cell]" }, { kind: "directive", type: i4.MatCell, selector: "mat-cell, td[mat-cell]" }, { kind: "component", type: i4.MatHeaderRow, selector: "mat-header-row, tr[mat-header-row]", exportAs: ["matHeaderRow"] }, { kind: "component", type: i4.MatRow, selector: "mat-row, tr[mat-row]", exportAs: ["matRow"] }, { kind: "directive", type: i4.MatNoDataRow, selector: "ng-template[matNoDataRow]" }, { kind: "component", type: i5.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i5.MatLabel, selector: "mat-label" }, { kind: "component", type: i6.MatPaginator, selector: "mat-paginator", inputs: ["disabled"], exportAs: ["matPaginator"] }, { kind: "directive", type: i7.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "directive", type: i8.MatSort, selector: "[matSort]", inputs: ["matSortDisabled", "matSortActive", "matSortStart", "matSortDirection", "matSortDisableClear"], outputs: ["matSortChange"], exportAs: ["matSort"] }, { kind: "component", type: i8.MatSortHeader, selector: "[mat-sort-header]", inputs: ["disabled", "mat-sort-header", "arrowPosition", "start", "sortActionDescription", "disableClear"], exportAs: ["matSortHeader"] }, { kind: "component", type: i11.MatIconButton, selector: "button[mat-icon-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: i10.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: i11$1.MatTooltip, selector: "[matTooltip]", exportAs: ["matTooltip"] }, { kind: "pipe", type: i3.DatePipe, name: "date" }, { kind: "pipe", type: i1.SubTranslatePipe, name: "subtranslate" }, { kind: "pipe", type: i2.TranslatePipe, name: "translate" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartEncounterTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-encounter-table', template: "<div>\n\n    <div class=\"d-flex flex-justify-between\">\n\n        <mat-form-field appearance=\"fill\">\n            <mat-label>{{ 'encounter.table.filter.label' | subtranslate:lang }}</mat-label>\n            <input matInput (keyup)=\"applyFilter($event)\"\n                placeholder=\"{{ 'encounter.table.filter.label' | subtranslate:lang }}\" #input>\n        </mat-form-field>\n\n        <button class=\"refreshButton\" *ngIf=\"enableRefreshButton\" mat-icon-button (click)=\"refreshList()\"\n            matTooltip=\"{{'encounter.table.button.refresh' | subtranslate:lang }}\" matTooltipPosition=\"above\">\n            <mat-icon>refresh</mat-icon>\n        </button>\n\n    </div>\n\n    <div class=\"mat-elevation-z8\">\n        <table mat-table [dataSource]=\"dataSource\" matSort>\n\n            <ng-container matColumnDef=\"type\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{ 'encounter.table.header.type' |\n                    subtranslate:lang }} </th>\n                <td mat-cell *matCellDef=\"let row\" class=\"medium-field\"> {{typeSystem+'|'+row.type | translate}} </td>\n            </ng-container>\n\n            <ng-container matColumnDef=\"openingDate\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{ 'encounter.table.header.openingDate' |\n                    subtranslate:lang }} </th>\n                <td mat-cell *matCellDef=\"let row\" class=\"date-field\"> {{row.startDate | date:'dd/MM/yyyy'}} </td>\n            </ng-container>\n\n            <ng-container matColumnDef=\"closingDate\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{ 'encounter.table.header.closingDate' |\n                    subtranslate:lang }} </th>\n                <td mat-cell *matCellDef=\"let row\" class=\"date-field\"> {{row.closingDate?? '' | date:'dd/MM/yyyy'}}\n                </td>\n            </ng-container>\n\n            <ng-container matColumnDef=\"organization\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{ 'encounter.table.header.organization' |\n                    subtranslate:lang }} </th>\n                <td mat-cell *matCellDef=\"let row\" class=\"large-field\"> {{row.serviceProvider?.name}} </td>\n            </ng-container>\n\n            <ng-container matColumnDef=\"status\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{ 'encounter.table.header.status' |\n                    subtranslate:lang }} </th>\n                <td mat-cell *matCellDef=\"let row\" class=\"icon-field\">\n                    <!-- TODO: leggerlo da elenco statico del component -->\n                    <mat-icon *ngIf=\"row.status == finishedStatus; else edit \"\n                        matTooltip=\"{{ 'encounter.table.header.status.locked' | subtranslate:lang }}\"\n                        matTooltipPosition=\"before\">\n                        lock\n                    </mat-icon>\n                    <ng-template #edit>\n                        <mat-icon matTooltip=\"{{ 'encounter.table.header.status.editable' | subtranslate:lang }}\"\n                            matTooltipPosition=\"before\">edit</mat-icon>\n                    </ng-template>\n                </td>\n            </ng-container>\n\n            <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n            <tr mat-row mat-row (click)=\"clicked(row)\" *matRowDef=\"let row; columns: displayedColumns;\"></tr>\n\n            <!-- Row shown when there is no matching data. -->\n            <tr class=\"mat-row\" *matNoDataRow>\n                <td class=\"mat-cell\" colspan=\"4\">{{ 'encounter.table.no-data' | subtranslate:lang }} \"{{input.value}}\"\n                </td>\n            </tr>\n        </table>\n\n        <mat-paginator [pageSizeOptions]=\"paginationOptions\" [pageSize]=\"pageSize\"></mat-paginator>\n    </div>\n</div>", styles: [".container{margin:16px!important}table{width:100%;margin-bottom:16px}mat-form-field{flex-grow:2;height:auto!important}.refreshButton{margin-top:10px;margin-left:16px!important;margin-right:16px!important}.mat-mdc-row .mat-mdc-cell{border-bottom:1px solid transparent;border-top:1px solid transparent;cursor:pointer}.icon-field{width:5vw}.date-field{width:10vw}.small-field{min-width:150px;max-width:10vw}.medium-field{min-width:12vw;max-width:25vw;flex-basis:25%}.large-field{min-width:25vw;max-width:40vw}\n"] }]
        }], ctorParameters: function () { return [{ type: i1.SubTranslateService }, { type: i2.TranslateService }]; }, propDecorators: { paginator: [{
                type: ViewChild,
                args: [MatPaginator]
            }], sort: [{
                type: ViewChild,
                args: [MatSort]
            }], displayedColumns: [{
                type: Input
            }], encounters: [{
                type: Input
            }], paginationOptions: [{
                type: Input
            }], pageSize: [{
                type: Input
            }], lang: [{
                type: Input
            }], enableRefreshButton: [{
                type: Input
            }], typeSystem: [{
                type: Input
            }], selected: [{
                type: Output
            }], askRefresh: [{
                type: Output
            }] } });

// AoT requires an exported function for factories
function HttpLoaderFactoryEncounterList(http) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class HeartEncounterTableModule {
}
HeartEncounterTableModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartEncounterTableModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
HeartEncounterTableModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: HeartEncounterTableModule, declarations: [HeartEncounterTableComponent], imports: [CommonModule,
        MatTableModule,
        MatFormFieldModule,
        MatPaginatorModule,
        MatInputModule,
        MatSortModule,
        MatButtonModule,
        MatIconModule,
        MatTooltipModule,
        SubTranslateModule, i2.TranslateModule], exports: [HeartEncounterTableComponent] });
HeartEncounterTableModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartEncounterTableModule, imports: [CommonModule,
        MatTableModule,
        MatFormFieldModule,
        MatPaginatorModule,
        MatInputModule,
        MatSortModule,
        MatButtonModule,
        MatIconModule,
        MatTooltipModule,
        SubTranslateModule,
        TranslateModule.forChild({
            defaultLanguage: 'en',
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactoryEncounterList,
                deps: [HttpClient],
            },
            isolate: false,
        })] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartEncounterTableModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [HeartEncounterTableComponent],
                    imports: [
                        CommonModule,
                        MatTableModule,
                        MatFormFieldModule,
                        MatPaginatorModule,
                        MatInputModule,
                        MatSortModule,
                        MatButtonModule,
                        MatIconModule,
                        MatTooltipModule,
                        SubTranslateModule,
                        TranslateModule.forChild({
                            defaultLanguage: 'en',
                            loader: {
                                provide: TranslateLoader,
                                useFactory: HttpLoaderFactoryEncounterList,
                                deps: [HttpClient],
                            },
                            isolate: false,
                        }),
                    ],
                    exports: [HeartEncounterTableComponent],
                }]
        }] });

const en$1 = {
    'appointment.list.button.refresh': 'Refresh List',
    'appointment.list.button.clear': 'Reset',
    'appointment.list.table.header.date': 'Date',
    'appointment.list.table.header.start': 'Start time',
    'appointment.list.table.header.end': 'End time',
    'appointment.list.table.header.patient': 'Patient',
    'appointment.list.table.header.type': 'Type',
    'appointment.list.table.header.notes': 'Notes',
    'appointment.list.table.header.actions': 'Actions',
    'appointment.list.table.delete': 'DELETE',
    'appointment.list.table.confirm': 'CONFIRM',
    'appointment.list.table.open-dashboard': 'OPEN DASHBOARD',
    'appointment.list.table.no-data-date': 'No appointments found for ',
    'appointment.list.table.no-data': 'No appointments found',
    'appointment.list.table.paginator.label': 'Select page of users',
    'appointment.list.date.placeholder': 'Choose a date',
    'appointment.list.table.title': 'Your Appointments',
    'appointment.list.table.title-date': 'Your Appointments for ',
    'annual-screening': 'Annual Screening',
    'first-encounter': 'First Encounter',
    'school-check': 'School Check',
    'prevention-campaign': 'Prevention Campaign',
    other: 'Other',
};

const it$1 = {
    'appointment.list.filter.label': 'Filtra',
};

class AppointmentsBrowserComponent {
    constructor(_subTranslateService, _da) {
        this._subTranslateService = _subTranslateService;
        this._da = _da;
        this.stdDisplayedColumns = ['date', 'start', 'end', 'patient', 'type', 'expand'];
        this.stdPaginationOptions = [5, 10, 25, 100];
        this.stdPageSize = 25;
        this.appointments = [];
        this.typeSystem = '';
        this.enableRefreshButton = false;
        this.deleteAppointment = new EventEmitter();
        this.editAppointment = new EventEmitter();
        this.openAppointment = new EventEmitter();
        this.confirmAppointment = new EventEmitter();
        this.askRefresh = new EventEmitter();
        this.selectedDate = null;
        this.filteredAppointments = [];
        this.lang = this.lang; // ? this.lang : conf.lang;
        this.createDictionary();
    }
    // approccio per unificare il servizio di traduzione
    createDictionary() {
        const dictionary = new Map();
        dictionary.set('en', en$1);
        dictionary.set('it', it$1);
        this._subTranslateService.setLanguages(dictionary);
    }
    ngDoCheck() {
        var _a;
        if (((_a = this.appointments) === null || _a === void 0 ? void 0 : _a.length) != this.prevLength) {
            this.refresh();
        }
    }
    ngOnChanges(changes) {
        const _lang = changes['lang'];
        if (_lang) {
            if (_lang.currentValue != _lang.previousValue) {
                const locale = this._subTranslateService.getFnsLocale(this.lang);
                if (locale)
                    this._da.setLocale(locale);
            }
        }
        // console.log("OnChanges: "+changes);
        this.refresh();
    }
    ngOnInit() {
        const locale = this._subTranslateService.getFnsLocale(this.lang);
        if (locale)
            this._da.setLocale(locale);
    }
    ngAfterViewInit() {
        this.refresh();
    }
    refresh() {
        var _a, _b, _c;
        this.filterAppointments();
        // console.log(`refreshing`);
        this.prevLength = this.appointments.length;
        this.dataSource = new MatTableDataSource(this.filteredAppointments);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.displayedColumns = (_a = this.displayedColumns) !== null && _a !== void 0 ? _a : this.stdDisplayedColumns;
        this.pageSize = (_b = this.pageSize) !== null && _b !== void 0 ? _b : this.stdPageSize;
        this.paginationOptions = (_c = this.paginationOptions) !== null && _c !== void 0 ? _c : this.stdPaginationOptions;
        if (this.dataSource.paginator) {
            this.dataSource.paginator.firstPage();
        }
    }
    onDateChange(date) {
        this.selectedDate = date;
        this.refresh();
    }
    filterAppointments() {
        if (this.selectedDate) {
            this.filteredAppointments = this.appointments.filter((app) => this.dateCompare(app.start, this.selectedDate));
        }
        else {
            this.filteredAppointments = [...this.appointments];
        }
    }
    refreshList() {
        this.askRefresh.emit();
    }
    handleDelete(appointment) {
        this.deleteAppointment.emit(appointment);
    }
    handleEdit(appointment) {
        this.editAppointment.emit(appointment);
    }
    handleOpen(appointment) {
        this.openAppointment.emit(appointment);
    }
    handleConfirm(appointment) {
        this.confirmAppointment.emit(appointment);
    }
    dateCompare(d1, d2) {
        return d1.getFullYear() === d2.getFullYear() && d1.getMonth() === d2.getMonth() && d1.getDate() === d2.getDate();
    }
    getStatusIcon(status) {
        switch (status) {
            case AppointmentStatus.FULFILLED:
                return 'check_circle_outline';
            case AppointmentStatus.CANCELLED:
                return 'error_outline';
            default:
                return 'help_outline';
        }
    }
}
AppointmentsBrowserComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: AppointmentsBrowserComponent, deps: [{ token: i1.SubTranslateService }, { token: i2$1.DateAdapter }], target: i0.ɵɵFactoryTarget.Component });
AppointmentsBrowserComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: AppointmentsBrowserComponent, selector: "heart-appointments-browser", inputs: { displayedColumns: "displayedColumns", appointments: "appointments", paginationOptions: "paginationOptions", pageSize: "pageSize", lang: "lang", typeSystem: "typeSystem", enableRefreshButton: "enableRefreshButton" }, outputs: { deleteAppointment: "deleteAppointment", editAppointment: "editAppointment", openAppointment: "openAppointment", confirmAppointment: "confirmAppointment", askRefresh: "askRefresh" }, viewQueries: [{ propertyName: "paginator", first: true, predicate: MatPaginator, descendants: true }, { propertyName: "sort", first: true, predicate: MatSort, descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"appointment-browser\">\n    <div class=\"d-flex flex-justify-between\">\n        <div>\n            <mat-form-field appearance=\"fill\" class=\"date-picker\">\n                <input #datepickerInput readonly class=\"mat-datepicker-input\" matInput [matDatepicker]=\"picker\"\n                    (dateChange)=\"onDateChange($event.value)\" [(ngModel)]=\"selectedDate\"\n                    [placeholder]=\"'appointment.list.date.placeholder' | subtranslate:lang\">\n                <mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\n                <mat-datepicker #picker></mat-datepicker>\n            </mat-form-field>\n            <button mat-raised-button class=\"ml-2\" color=\"primary\" (click)=\"onDateChange(null)\">{{\n                'appointment.list.button.clear' |\n                subtranslate:lang}}</button>\n        </div>\n        <button class=\"refreshButton\" *ngIf=\"enableRefreshButton\" mat-icon-button color=\"secondary\"\n            (click)=\"refreshList()\" matTooltip=\"{{'appointment.list.button.refresh' | subtranslate:lang }}\"\n            matTooltipPosition=\"above\">\n            <mat-icon>refresh</mat-icon>\n        </button>\n    </div>\n    <h2 class=\"m-2 text-center width-full\">\n        {{selectedDate? ('appointment.list.table.title-date' |\n        subtranslate:lang): ('appointment.list.table.title' | subtranslate:lang) }}\n        {{selectedDate |\n        date: 'fullDate'}}\n    </h2>\n    <div class=\"mat-elevation-z8\">\n        <table mat-table matSort multiTemplateDataRows [dataSource]=\"dataSource\">\n            <!-- End Column -->\n            <ng-container matColumnDef=\"date\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{'appointment.list.table.header.date' |\n                    subtranslate:lang}}\n                </th>\n                <td mat-cell *matCellDef=\"let appointment\">\n                    {{ appointment.start | date: 'shortDate' }}\n                </td>\n            </ng-container>\n            <!-- Start Column -->\n            <ng-container matColumnDef=\"start\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{'appointment.list.table.header.start' |\n                    subtranslate:lang}}\n                </th>\n                <td mat-cell *matCellDef=\"let appointment\">\n                    {{ appointment.start | date: 'HH:mm' }}\n                </td>\n            </ng-container>\n\n            <!-- End Column -->\n            <ng-container matColumnDef=\"end\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{'appointment.list.table.header.end' |\n                    subtranslate:lang}}\n                </th>\n                <td mat-cell *matCellDef=\"let appointment\">\n                    {{ appointment.end | date: 'HH:mm' }}\n                </td>\n            </ng-container>\n\n            <!-- Patient Column -->\n            <ng-container matColumnDef=\"patient\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{'appointment.list.table.header.patient' |\n                    subtranslate:lang}}\n                </th>\n                <td mat-cell *matCellDef=\"let appointment\">\n                    {{ appointment.patient?.getFullName() || 'N/A' }}\n                </td>\n            </ng-container>\n\n            <!-- Type Column -->\n            <ng-container matColumnDef=\"type\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{'appointment.list.table.header.type' |\n                    subtranslate:lang}}\n                </th>\n                <td mat-cell *matCellDef=\"let appointment\">\n                    {{ (typeSystem+'|'+appointment.type | translate) || 'N/A' }}\n                </td>\n            </ng-container>\n\n            <!-- Note Column -->\n            <ng-container matColumnDef=\"note\">\n                <th mat-header-cell *matHeaderCellDef> {{'appointment.list.table.header.notes' | subtranslate:lang}}\n                </th>\n                <td mat-cell *matCellDef=\"let appointment\">\n                    {{ appointment.note }}\n                </td>\n            </ng-container>\n\n            <!-- Actions Column -->\n            <ng-container matColumnDef=\"edit\">\n                <th mat-header-cell *matHeaderCellDef>\n                    {{ \"appointment.table.edit.label\" | subtranslate:lang }}\n                </th>\n                <td mat-cell *matCellDef=\"let appointment\">\n                    <button mat-icon-button color=\"accent\" (click)=\"handleEdit(appointment)\">\n                        <mat-icon>edit</mat-icon>\n                    </button>\n                </td>\n            </ng-container>\n            <ng-container matColumnDef=\"delete\">\n                <th mat-header-cell *matHeaderCellDef>\n                    {{ \"appointment.table.delete.label\" | subtranslate:lang }}\n                </th>\n                <td mat-cell *matCellDef=\"let appointment\">\n                    <button mat-icon-button color=\"warn\" (click)=\"handleDelete(appointment)\">\n                        <mat-icon>delete</mat-icon>\n                    </button>\n                </td>\n            </ng-container>\n            <ng-container matColumnDef=\"expand\">\n                <th mat-header-cell *matHeaderCellDef aria-label=\"row actions\">&nbsp;</th>\n                <td mat-cell *matCellDef=\"let appointment\">\n                    <button mat-icon-button aria-label=\"expand row\"\n                        (click)=\"(expandedElement = expandedElement === appointment ? null : appointment); $event.stopPropagation()\">\n                        <mat-icon *ngIf=\"expandedElement !== appointment\">keyboard_arrow_down</mat-icon>\n                        <mat-icon *ngIf=\"expandedElement === appointment\">keyboard_arrow_up</mat-icon>\n                    </button>\n                </td>\n            </ng-container>\n            <!-- Expanded Content Column - The detail row is made up of this one column that spans across all columns -->\n            <ng-container matColumnDef=\"expandedDetail\">\n                <td mat-cell *matCellDef=\"let element\" [attr.colspan]=\"displayedColumns.length\">\n                    <div class=\"appointment-summary\"\n                        [@detailExpand]=\"element == expandedElement ? 'expanded' : 'collapsed'\">\n                        <mat-list *ngIf=\"element\">\n                            <mat-list-item>\n                                <mat-icon matListItemIcon>person</mat-icon>\n                                <div>{{element.patient?.getFullName()}}</div>\n                            </mat-list-item>\n                            <mat-list-item>\n                                <mat-icon matListItemIcon>{{getStatusIcon(element.status)}}</mat-icon>\n                                <div>{{element.status}}</div>\n                            </mat-list-item>\n                            <mat-list-item>\n                                <mat-icon matListItemIcon>date_range</mat-icon>\n                                <div>{{element.start | date:'dd/MM/YY HH:mm'}} -\n                                    {{element.end | date:'dd/MM/YY HH:mm'}}</div>\n                            </mat-list-item>\n                            <mat-list-item *ngIf=\"element.note != undefined\">\n                                <mat-icon matListItemIcon>note</mat-icon>\n                                <div>{{element.note}}</div>\n                            </mat-list-item>\n                        </mat-list>\n\n                        <div class=\"d-flex flex-row flex-row-reverse p-2\">\n                            <button mat-raised-button color=\"primary\" heartDebouncedButton\n                                (debounceClick)=\"handleOpen(element)\"><mat-icon>open_in_new</mat-icon>{{'appointment.list.table.open-dashboard'|\n                                subtranslate:lang}}</button>\n                            <button class=\"mr-2\" *ngIf=\"element.status === 'pending'\" mat-raised-button\n                                heartDebouncedButton\n                                (debounceClick)=\"handleConfirm(element)\"><mat-icon>event_available</mat-icon>{{'appointment.list.table.confirm'|\n                                subtranslate:lang}}</button>\n                            <button class=\"mr-2\" mat-raised-button color=\"warn\" heartDebouncedButton\n                                (debounceClick)=\"handleDelete(element)\"><mat-icon>delete</mat-icon>{{'appointment.list.table.delete'|\n                                subtranslate:lang}}</button>\n\n                        </div>\n\n                    </div>\n                </td>\n            </ng-container>\n            <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n            <tr mat-row *matRowDef=\"let element; columns: displayedColumns;\" class=\"element-row\"\n                [class.expanded-row]=\"expandedElement === element\"\n                (click)=\"expandedElement = expandedElement === element ? null : element\">\n            </tr>\n            <tr mat-row *matRowDef=\"let row; columns: ['expandedDetail']\" class=\"detail-row\"></tr>\n\n\n            <!-- Row shown when there is no matching data. -->\n            <tr class=\"mat-row\" *matNoDataRow>\n                <td class=\"mat-cell\" colspan=\"4\"> {{selectedDate? ('appointment.list.table.no-data-date' |\n                    subtranslate:lang): 'appointment.list.table.no-data' | subtranslate:lang }}\n                    {{selectedDate |\n                    date: 'shortDate'}}\n                </td>\n            </tr>\n        </table>\n\n        <mat-paginator [pageSizeOptions]=\"paginationOptions\" [pageSize]=\"pageSize\"></mat-paginator>\n    </div>\n</div>", styles: [".appointment-browser{display:flex;flex-direction:column;gap:16px}.appointment-browser mat-table{width:100%;margin-bottom:16px}.appointment-browser .mat-mdc-row .mat-mdc-cell{border-bottom:1px solid transparent;border-top:1px solid transparent;cursor:pointer}.appointment-browser .mat-mdc-row:hover .mat-mdc-cell{font-weight:bolder}.appointment-browser .mat-column-patient{max-width:40%;padding-left:16px}.appointment-browser .mat-column-expand{width:5%;padding-left:16px}.appointment-browser .mat-column-date{width:15%;padding-left:16px}.appointment-browser .mat-column-start{width:10%;padding-left:16px}.appointment-browser .mat-column-end{width:10%;padding-left:16px;border-right:1px solid currentColor}.appointment-browser .mat-column-type{width:15%;padding-left:16px}.appointment-browser .mat-column-edit,.appointment-browser .mat-column-delete{width:5%;padding-left:16px}.appointment-browser .light-disabled{background-color:#dadada;font-style:italic}.appointment-browser mat-icon-button{margin-right:8px}.appointment-browser mat-icon-button:last-child{margin-right:0}.appointment-browser .appointment-summary{overflow:hidden;display:flex;flex-direction:column}.appointment-browser tr.detail-row{height:0}.appointment-browser .element-row td{border-bottom-width:0}.appointment-browser tr.element-row:not(.expanded-row):hover{background:whitesmoke}.appointment-browser tr.element-row:not(.expanded-row):active{background:#efefef}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i6.MatPaginator, selector: "mat-paginator", inputs: ["disabled"], exportAs: ["matPaginator"] }, { kind: "directive", type: i4$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i4$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: i6$1.MatList, selector: "mat-list", exportAs: ["matList"] }, { kind: "component", type: i6$1.MatListItem, selector: "mat-list-item, a[mat-list-item], button[mat-list-item]", inputs: ["activated"], exportAs: ["matListItem"] }, { kind: "directive", type: i6$1.MatListItemIcon, selector: "[matListItemIcon]" }, { kind: "component", type: i7$1.MatDatepicker, selector: "mat-datepicker", exportAs: ["matDatepicker"] }, { kind: "directive", type: i7$1.MatDatepickerInput, selector: "input[matDatepicker]", inputs: ["matDatepicker", "min", "max", "matDatepickerFilter"], exportAs: ["matDatepickerInput"] }, { kind: "component", type: i7$1.MatDatepickerToggle, selector: "mat-datepicker-toggle", inputs: ["for", "tabIndex", "aria-label", "disabled", "disableRipple"], exportAs: ["matDatepickerToggle"] }, { kind: "directive", type: i7.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i5.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i5.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "component", type: i4.MatTable, selector: "mat-table, table[mat-table]", exportAs: ["matTable"] }, { kind: "directive", type: i4.MatHeaderCellDef, selector: "[matHeaderCellDef]" }, { kind: "directive", type: i4.MatHeaderRowDef, selector: "[matHeaderRowDef]", inputs: ["matHeaderRowDef", "matHeaderRowDefSticky"] }, { kind: "directive", type: i4.MatColumnDef, selector: "[matColumnDef]", inputs: ["sticky", "matColumnDef"] }, { kind: "directive", type: i4.MatCellDef, selector: "[matCellDef]" }, { kind: "directive", type: i4.MatRowDef, selector: "[matRowDef]", inputs: ["matRowDefColumns", "matRowDefWhen"] }, { kind: "directive", type: i4.MatHeaderCell, selector: "mat-header-cell, th[mat-header-cell]" }, { kind: "directive", type: i4.MatCell, selector: "mat-cell, td[mat-cell]" }, { kind: "component", type: i4.MatHeaderRow, selector: "mat-header-row, tr[mat-header-row]", exportAs: ["matHeaderRow"] }, { kind: "component", type: i4.MatRow, selector: "mat-row, tr[mat-row]", exportAs: ["matRow"] }, { kind: "directive", type: i4.MatNoDataRow, selector: "ng-template[matNoDataRow]" }, { kind: "component", type: i11.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: i11.MatIconButton, selector: "button[mat-icon-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "directive", type: i11$1.MatTooltip, selector: "[matTooltip]", exportAs: ["matTooltip"] }, { kind: "directive", type: i8.MatSort, selector: "[matSort]", inputs: ["matSortDisabled", "matSortActive", "matSortStart", "matSortDirection", "matSortDisableClear"], outputs: ["matSortChange"], exportAs: ["matSort"] }, { kind: "component", type: i8.MatSortHeader, selector: "[mat-sort-header]", inputs: ["disabled", "mat-sort-header", "arrowPosition", "start", "sortActionDescription", "disableClear"], exportAs: ["matSortHeader"] }, { kind: "component", type: i10.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: i1.DebouncedButtonDirective, selector: "[heartDebouncedButton]", inputs: ["debounceClickTime"], outputs: ["debounceClick"] }, { kind: "pipe", type: i3.DatePipe, name: "date" }, { kind: "pipe", type: i1.SubTranslatePipe, name: "subtranslate" }, { kind: "pipe", type: i2.TranslatePipe, name: "translate" }], animations: [
        trigger('detailExpand', [
            state('collapsed', style({ height: '0px', minHeight: '0' })),
            state('expanded', style({ height: '*' })),
            transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
        ]),
    ] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: AppointmentsBrowserComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-appointments-browser', animations: [
                        trigger('detailExpand', [
                            state('collapsed', style({ height: '0px', minHeight: '0' })),
                            state('expanded', style({ height: '*' })),
                            transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
                        ]),
                    ], template: "<div class=\"appointment-browser\">\n    <div class=\"d-flex flex-justify-between\">\n        <div>\n            <mat-form-field appearance=\"fill\" class=\"date-picker\">\n                <input #datepickerInput readonly class=\"mat-datepicker-input\" matInput [matDatepicker]=\"picker\"\n                    (dateChange)=\"onDateChange($event.value)\" [(ngModel)]=\"selectedDate\"\n                    [placeholder]=\"'appointment.list.date.placeholder' | subtranslate:lang\">\n                <mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\n                <mat-datepicker #picker></mat-datepicker>\n            </mat-form-field>\n            <button mat-raised-button class=\"ml-2\" color=\"primary\" (click)=\"onDateChange(null)\">{{\n                'appointment.list.button.clear' |\n                subtranslate:lang}}</button>\n        </div>\n        <button class=\"refreshButton\" *ngIf=\"enableRefreshButton\" mat-icon-button color=\"secondary\"\n            (click)=\"refreshList()\" matTooltip=\"{{'appointment.list.button.refresh' | subtranslate:lang }}\"\n            matTooltipPosition=\"above\">\n            <mat-icon>refresh</mat-icon>\n        </button>\n    </div>\n    <h2 class=\"m-2 text-center width-full\">\n        {{selectedDate? ('appointment.list.table.title-date' |\n        subtranslate:lang): ('appointment.list.table.title' | subtranslate:lang) }}\n        {{selectedDate |\n        date: 'fullDate'}}\n    </h2>\n    <div class=\"mat-elevation-z8\">\n        <table mat-table matSort multiTemplateDataRows [dataSource]=\"dataSource\">\n            <!-- End Column -->\n            <ng-container matColumnDef=\"date\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{'appointment.list.table.header.date' |\n                    subtranslate:lang}}\n                </th>\n                <td mat-cell *matCellDef=\"let appointment\">\n                    {{ appointment.start | date: 'shortDate' }}\n                </td>\n            </ng-container>\n            <!-- Start Column -->\n            <ng-container matColumnDef=\"start\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{'appointment.list.table.header.start' |\n                    subtranslate:lang}}\n                </th>\n                <td mat-cell *matCellDef=\"let appointment\">\n                    {{ appointment.start | date: 'HH:mm' }}\n                </td>\n            </ng-container>\n\n            <!-- End Column -->\n            <ng-container matColumnDef=\"end\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{'appointment.list.table.header.end' |\n                    subtranslate:lang}}\n                </th>\n                <td mat-cell *matCellDef=\"let appointment\">\n                    {{ appointment.end | date: 'HH:mm' }}\n                </td>\n            </ng-container>\n\n            <!-- Patient Column -->\n            <ng-container matColumnDef=\"patient\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{'appointment.list.table.header.patient' |\n                    subtranslate:lang}}\n                </th>\n                <td mat-cell *matCellDef=\"let appointment\">\n                    {{ appointment.patient?.getFullName() || 'N/A' }}\n                </td>\n            </ng-container>\n\n            <!-- Type Column -->\n            <ng-container matColumnDef=\"type\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> {{'appointment.list.table.header.type' |\n                    subtranslate:lang}}\n                </th>\n                <td mat-cell *matCellDef=\"let appointment\">\n                    {{ (typeSystem+'|'+appointment.type | translate) || 'N/A' }}\n                </td>\n            </ng-container>\n\n            <!-- Note Column -->\n            <ng-container matColumnDef=\"note\">\n                <th mat-header-cell *matHeaderCellDef> {{'appointment.list.table.header.notes' | subtranslate:lang}}\n                </th>\n                <td mat-cell *matCellDef=\"let appointment\">\n                    {{ appointment.note }}\n                </td>\n            </ng-container>\n\n            <!-- Actions Column -->\n            <ng-container matColumnDef=\"edit\">\n                <th mat-header-cell *matHeaderCellDef>\n                    {{ \"appointment.table.edit.label\" | subtranslate:lang }}\n                </th>\n                <td mat-cell *matCellDef=\"let appointment\">\n                    <button mat-icon-button color=\"accent\" (click)=\"handleEdit(appointment)\">\n                        <mat-icon>edit</mat-icon>\n                    </button>\n                </td>\n            </ng-container>\n            <ng-container matColumnDef=\"delete\">\n                <th mat-header-cell *matHeaderCellDef>\n                    {{ \"appointment.table.delete.label\" | subtranslate:lang }}\n                </th>\n                <td mat-cell *matCellDef=\"let appointment\">\n                    <button mat-icon-button color=\"warn\" (click)=\"handleDelete(appointment)\">\n                        <mat-icon>delete</mat-icon>\n                    </button>\n                </td>\n            </ng-container>\n            <ng-container matColumnDef=\"expand\">\n                <th mat-header-cell *matHeaderCellDef aria-label=\"row actions\">&nbsp;</th>\n                <td mat-cell *matCellDef=\"let appointment\">\n                    <button mat-icon-button aria-label=\"expand row\"\n                        (click)=\"(expandedElement = expandedElement === appointment ? null : appointment); $event.stopPropagation()\">\n                        <mat-icon *ngIf=\"expandedElement !== appointment\">keyboard_arrow_down</mat-icon>\n                        <mat-icon *ngIf=\"expandedElement === appointment\">keyboard_arrow_up</mat-icon>\n                    </button>\n                </td>\n            </ng-container>\n            <!-- Expanded Content Column - The detail row is made up of this one column that spans across all columns -->\n            <ng-container matColumnDef=\"expandedDetail\">\n                <td mat-cell *matCellDef=\"let element\" [attr.colspan]=\"displayedColumns.length\">\n                    <div class=\"appointment-summary\"\n                        [@detailExpand]=\"element == expandedElement ? 'expanded' : 'collapsed'\">\n                        <mat-list *ngIf=\"element\">\n                            <mat-list-item>\n                                <mat-icon matListItemIcon>person</mat-icon>\n                                <div>{{element.patient?.getFullName()}}</div>\n                            </mat-list-item>\n                            <mat-list-item>\n                                <mat-icon matListItemIcon>{{getStatusIcon(element.status)}}</mat-icon>\n                                <div>{{element.status}}</div>\n                            </mat-list-item>\n                            <mat-list-item>\n                                <mat-icon matListItemIcon>date_range</mat-icon>\n                                <div>{{element.start | date:'dd/MM/YY HH:mm'}} -\n                                    {{element.end | date:'dd/MM/YY HH:mm'}}</div>\n                            </mat-list-item>\n                            <mat-list-item *ngIf=\"element.note != undefined\">\n                                <mat-icon matListItemIcon>note</mat-icon>\n                                <div>{{element.note}}</div>\n                            </mat-list-item>\n                        </mat-list>\n\n                        <div class=\"d-flex flex-row flex-row-reverse p-2\">\n                            <button mat-raised-button color=\"primary\" heartDebouncedButton\n                                (debounceClick)=\"handleOpen(element)\"><mat-icon>open_in_new</mat-icon>{{'appointment.list.table.open-dashboard'|\n                                subtranslate:lang}}</button>\n                            <button class=\"mr-2\" *ngIf=\"element.status === 'pending'\" mat-raised-button\n                                heartDebouncedButton\n                                (debounceClick)=\"handleConfirm(element)\"><mat-icon>event_available</mat-icon>{{'appointment.list.table.confirm'|\n                                subtranslate:lang}}</button>\n                            <button class=\"mr-2\" mat-raised-button color=\"warn\" heartDebouncedButton\n                                (debounceClick)=\"handleDelete(element)\"><mat-icon>delete</mat-icon>{{'appointment.list.table.delete'|\n                                subtranslate:lang}}</button>\n\n                        </div>\n\n                    </div>\n                </td>\n            </ng-container>\n            <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n            <tr mat-row *matRowDef=\"let element; columns: displayedColumns;\" class=\"element-row\"\n                [class.expanded-row]=\"expandedElement === element\"\n                (click)=\"expandedElement = expandedElement === element ? null : element\">\n            </tr>\n            <tr mat-row *matRowDef=\"let row; columns: ['expandedDetail']\" class=\"detail-row\"></tr>\n\n\n            <!-- Row shown when there is no matching data. -->\n            <tr class=\"mat-row\" *matNoDataRow>\n                <td class=\"mat-cell\" colspan=\"4\"> {{selectedDate? ('appointment.list.table.no-data-date' |\n                    subtranslate:lang): 'appointment.list.table.no-data' | subtranslate:lang }}\n                    {{selectedDate |\n                    date: 'shortDate'}}\n                </td>\n            </tr>\n        </table>\n\n        <mat-paginator [pageSizeOptions]=\"paginationOptions\" [pageSize]=\"pageSize\"></mat-paginator>\n    </div>\n</div>", styles: [".appointment-browser{display:flex;flex-direction:column;gap:16px}.appointment-browser mat-table{width:100%;margin-bottom:16px}.appointment-browser .mat-mdc-row .mat-mdc-cell{border-bottom:1px solid transparent;border-top:1px solid transparent;cursor:pointer}.appointment-browser .mat-mdc-row:hover .mat-mdc-cell{font-weight:bolder}.appointment-browser .mat-column-patient{max-width:40%;padding-left:16px}.appointment-browser .mat-column-expand{width:5%;padding-left:16px}.appointment-browser .mat-column-date{width:15%;padding-left:16px}.appointment-browser .mat-column-start{width:10%;padding-left:16px}.appointment-browser .mat-column-end{width:10%;padding-left:16px;border-right:1px solid currentColor}.appointment-browser .mat-column-type{width:15%;padding-left:16px}.appointment-browser .mat-column-edit,.appointment-browser .mat-column-delete{width:5%;padding-left:16px}.appointment-browser .light-disabled{background-color:#dadada;font-style:italic}.appointment-browser mat-icon-button{margin-right:8px}.appointment-browser mat-icon-button:last-child{margin-right:0}.appointment-browser .appointment-summary{overflow:hidden;display:flex;flex-direction:column}.appointment-browser tr.detail-row{height:0}.appointment-browser .element-row td{border-bottom-width:0}.appointment-browser tr.element-row:not(.expanded-row):hover{background:whitesmoke}.appointment-browser tr.element-row:not(.expanded-row):active{background:#efefef}\n"] }]
        }], ctorParameters: function () { return [{ type: i1.SubTranslateService }, { type: i2$1.DateAdapter }]; }, propDecorators: { paginator: [{
                type: ViewChild,
                args: [MatPaginator]
            }], sort: [{
                type: ViewChild,
                args: [MatSort]
            }], displayedColumns: [{
                type: Input
            }], appointments: [{
                type: Input
            }], paginationOptions: [{
                type: Input
            }], pageSize: [{
                type: Input
            }], lang: [{
                type: Input
            }], typeSystem: [{
                type: Input
            }], enableRefreshButton: [{
                type: Input
            }], deleteAppointment: [{
                type: Output
            }], editAppointment: [{
                type: Output
            }], openAppointment: [{
                type: Output
            }], confirmAppointment: [{
                type: Output
            }], askRefresh: [{
                type: Output
            }] } });

class AppointmentsBrowserModule {
}
AppointmentsBrowserModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: AppointmentsBrowserModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
AppointmentsBrowserModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: AppointmentsBrowserModule, declarations: [AppointmentsBrowserComponent], imports: [CommonModule,
        SubTranslateModule, i2.TranslateModule, MatPaginatorModule,
        FormsModule,
        MatListModule,
        MatDatepickerModule,
        MatInputModule,
        MatTableModule,
        MatButtonModule,
        MatTooltipModule,
        MatSortModule,
        MatIconModule,
        PreventDoubleClickModule], exports: [AppointmentsBrowserComponent] });
AppointmentsBrowserModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: AppointmentsBrowserModule, providers: [
        { provide: MAT_DATE_FORMATS, useValue: MAT_DATE_FNS_FORMATS },
        { provide: DateAdapter, useClass: DateFnsAdapter, deps: [MAT_DATE_LOCALE] },
        { provide: MAT_DATE_LOCALE, useValue: enGB },
    ], imports: [CommonModule,
        SubTranslateModule,
        TranslateModule.forChild(),
        MatPaginatorModule,
        FormsModule,
        MatListModule,
        MatDatepickerModule,
        MatInputModule,
        MatTableModule,
        MatButtonModule,
        MatTooltipModule,
        MatSortModule,
        MatIconModule,
        PreventDoubleClickModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: AppointmentsBrowserModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [AppointmentsBrowserComponent],
                    imports: [
                        CommonModule,
                        SubTranslateModule,
                        TranslateModule.forChild(),
                        MatPaginatorModule,
                        FormsModule,
                        MatListModule,
                        MatDatepickerModule,
                        MatInputModule,
                        MatTableModule,
                        MatButtonModule,
                        MatTooltipModule,
                        MatSortModule,
                        MatIconModule,
                        PreventDoubleClickModule,
                    ],
                    providers: [
                        { provide: MAT_DATE_FORMATS, useValue: MAT_DATE_FNS_FORMATS },
                        { provide: DateAdapter, useClass: DateFnsAdapter, deps: [MAT_DATE_LOCALE] },
                        { provide: MAT_DATE_LOCALE, useValue: enGB },
                    ],
                    exports: [AppointmentsBrowserComponent],
                }]
        }] });

const en = {
    'appointment-form.patient.label': 'Subject',
    'appointment-form.type.label': 'Appointment type',
    'appointment-form.start.label': 'Time and Date',
    'appointment-form.cancel.label': 'Cancel',
    'appointment-form.apply.label': 'Save',
    'appointment-form.duration.label': 'Duration',
    'appointment-form.notes.label': 'Notes',
    'appointment-form.hour.unit': 'Hour(s)',
    'appointment-form.button.store.label': 'Save',
    'appointment-form.button.cancel.label': 'Cancel',
    '<TYPESYSTEM>|annual-screening': 'Annual Screening',
    '<TYPESYSTEM>|first-encounter': 'First Encounter',
    '<TYPESYSTEM>|school-check': 'School Check',
    '<TYPESYSTEM>|prevention-campaign': 'Prevention Campaign',
    '<TYPESYSTEM>|other': 'Other',
    'appointment-form.date-past.error': 'Date and time cannot be in the past',
};

const it = {
    "measure.generic-form.datetime.label": "Data e ora",
    "measure.generic-form.notes.label": "Note",
    "measure.generic-form.save.label": "Salva",
    "measure.generic-form.nothing.label": "Nessun valore",
};

class HeartAppointmentFormComponent {
    constructor(_subTranslateService, _da) {
        this._subTranslateService = _subTranslateService;
        this._da = _da;
        /**
         * ASPECT SETTINGS
         */
        this.appearance = 'outline';
        /**
         * OPERATING MODE SETTINGS
         */
        this.readOnly = false; // if the appointment cannot be modified (in this case the action buttons are not rendered)
        this.appointmentTypes = []; // Types that will fill the select dropdown menu
        this.defaultLength = 1; // default length of the appointment in hours
        this.save = new EventEmitter();
        this.defaultTime = [];
        this.createDictionary();
        this.now = new Date();
    }
    ngOnInit() {
        let defaultDate = addHours(this.now, this.defaultLength);
        defaultDate.setMinutes(0, 0);
        this.minDate = defaultDate;
        const locale = this._subTranslateService.getLocaleCode(this.lang);
        if (locale)
            this._da.setLocale(locale);
        this.render();
    }
    // approccio per unificare il servizio di traduzione
    createDictionary() {
        const dictionary = new Map();
        dictionary.set('en', en);
        dictionary.set('it', it);
        this._subTranslateService.setLanguages(dictionary);
    }
    render() {
        this.form = new FormGroup({});
        this.form.addControl('patient', new FormControl(undefined, Validators.required));
        this.form.addControl('start', new FormControl(this.minDate, [Validators.required]));
        this.form.addControl('duration', new FormControl(1, [Validators.required, Validators.min(0.5), Validators.max(2)]));
        this.form.addControl('type', new FormControl(undefined, Validators.required));
        this.form.addControl('notes', new FormControl(''));
    }
    formatLabel(value) {
        return `${value} hrs`;
    }
    onSubmit(arg) {
        if (this.form.dirty) {
            const toStore = this.prepare();
            this.save.emit(toStore);
        }
    }
    doCancel() {
        this.resetForm();
        this.save.emit(undefined);
    }
    resetForm() {
        this.form.reset({ start: this.minDate, duration: 1 });
        this.form.controls['patient'].setErrors(null);
        this.form.controls['start'].setErrors(null);
        this.form.controls['duration'].setErrors(null);
        this.form.controls['type'].setErrors(null);
    }
    prepare() {
        var _a, _b, _c, _d, _e;
        const toRet = new Appointment();
        toRet.patient = (_a = this.form.get('patient')) === null || _a === void 0 ? void 0 : _a.value;
        toRet.start = (_b = this.form.get('start')) === null || _b === void 0 ? void 0 : _b.value;
        const duration = (_c = this.form.get('duration')) === null || _c === void 0 ? void 0 : _c.value;
        const hrs = Math.floor(duration);
        const mins = (duration - hrs) * 60;
        let end = hrs > 0 ? addHours(toRet.start, hrs) : toRet.start;
        end = mins > 0 ? addMinutes(end, mins) : end;
        toRet.end = end;
        toRet.note = (_d = this.form.get('notes')) === null || _d === void 0 ? void 0 : _d.value;
        const type = (_e = this.form.get('type')) === null || _e === void 0 ? void 0 : _e.value;
        toRet.type = EncounterType.convertFromString(type.code);
        toRet.status = AppointmentStatus.PENDING;
        return toRet;
    }
    getErrorMessage(formControlName) {
        if (this.form.contains(formControlName)) {
            const control = this.form.get(formControlName);
            if (control === null || control === void 0 ? void 0 : control.hasError('required')) {
                return this._subTranslateService.getTranslation('appointment-form.required.error', this.lang);
            }
            if (formControlName === 'start')
                return this._subTranslateService.getTranslation('appointment-form.date-past.error', this.lang);
        }
        return undefined;
    }
    correctlySaved() {
        // Anche se resettato, i validatori segnano i campi come errati
        // sono cmq untouched, non dirty
        this.resetForm();
    }
}
HeartAppointmentFormComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartAppointmentFormComponent, deps: [{ token: i1.SubTranslateService }, { token: i2$2.NgxMatDateAdapter }], target: i0.ɵɵFactoryTarget.Component });
HeartAppointmentFormComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: HeartAppointmentFormComponent, selector: "heart-appointment-form", inputs: { appearance: "appearance", lang: "lang", readOnly: "readOnly", patients: "patients", appointmentTypes: "appointmentTypes", defaultLength: "defaultLength" }, outputs: { save: "save" }, ngImport: i0, template: "<div class=\"p-2\">\n    <form [formGroup]=\"form\" class=\"appointment-form\" (ngSubmit)=\"form.valid && onSubmit($event)\">\n        <div class=\"d-flex flex-column\">\n            <mat-form-field [appearance]=\"appearance\">\n                <mat-label>{{'appointment-form.patient.label' | subtranslate:lang}}</mat-label>\n                <mat-select formControlName=\"patient\">\n                    <mat-option *ngFor=\"let g of patients\" [value]=\"g\">{{g.getFullName()}}</mat-option>\n                </mat-select>\n                <mat-error>{{getErrorMessage(\"patient\")}}</mat-error>\n            </mat-form-field>\n\n            <mat-form-field [appearance]=\"appearance\">\n                <mat-label>{{'appointment-form.type.label' | subtranslate:lang}}</mat-label>\n                <mat-select formControlName=\"type\">\n                    <mat-option *ngFor=\"let type of appointmentTypes\" [value]=\"type\">{{ type.uniqueLabelKey |\n                        translate }}</mat-option>\n                </mat-select>\n                <mat-error>{{getErrorMessage(\"type\")}}</mat-error>\n            </mat-form-field>\n        </div>\n        <div class=\"d-flex flex-column flex-md-row\">\n            <mat-form-field [appearance]=\"appearance\" class=\"flex-1 mr-md-2 date-selector\">\n                <mat-label>{{'appointment-form.start.label' | subtranslate:lang}}</mat-label>\n                <input matInput readonly [ngxMatDatetimePicker]=\"pickerStart\" formControlName=\"start\" [min]=\"now\">\n                <ngx-mat-datepicker-toggle matSuffix [for]=\"pickerStart\"></ngx-mat-datepicker-toggle>\n                <ngx-mat-datetime-picker #pickerStart [showSpinners]=\"true\" [showSeconds]=\"false\" [stepHour]=\"1\"\n                    [stepMinute]=\"10\">\n                    <ngx-mat-datepicker-actions>\n                        <button mat-button ngxMatDatepickerCancel>{{'appointment-form.cancel.label' |\n                            subtranslate:lang}}</button>\n                        <button mat-raised-button color=\"primary\" ngxMatDatepickerApply>{{'appointment-form.apply.label'\n                            | subtranslate:lang}}</button>\n                    </ngx-mat-datepicker-actions>\n                </ngx-mat-datetime-picker>\n                <mat-error>{{getErrorMessage(\"start\")}}</mat-error>\n            </mat-form-field>\n\n            <mat-form-field [appearance]=\"appearance\" class=\"flex-1 mr-md-2\">\n                <mat-label>{{'appointment-form.duration.label' | subtranslate:lang}}</mat-label>\n                <span matTextSuffix>{{'appointment-form.hour.unit' |subtranslate:lang }}</span>\n                <input matInput type=\"number\" min=\"1\" step=\"0.5\" formControlName=\"duration\">\n                <mat-icon matSuffix>timelapse</mat-icon>\n            </mat-form-field>\n        </div>\n        <!-- notes -->\n        <div class=\"d-flex flex-column\">\n            <mat-form-field [appearance]=\"appearance\" class=\"notes\">\n                <mat-label>{{'appointment-form.notes.label' | subtranslate:lang}}</mat-label>\n                <textarea matInput formControlName=\"notes\"></textarea>\n            </mat-form-field>\n        </div>\n        <div class=\"d-flex flex-row\">\n            <button class=\"mr-2\" mat-raised-button (click)=\"doCancel()\">{{'appointment-form.button.cancel.label' |\n                subtranslate:lang}}</button>\n            <button mat-raised-button [disabled]=\"(!form.touched || !form.valid)\" type=\"submit\"\n                color=\"primary\">{{'appointment-form.button.store.label' |\n                subtranslate:lang}}</button>\n        </div>\n    </form>\n</div>", styles: ["td.ngx-mat-timepicker-spacer{padding-bottom:20px!important}\n"], dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i4$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i4$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i4$1.NumberValueAccessor, selector: "input[type=number][formControlName],input[type=number][formControl],input[type=number][ngModel]" }, { kind: "directive", type: i4$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i4$1.MinValidator, selector: "input[type=number][min][formControlName],input[type=number][min][formControl],input[type=number][min][ngModel]", inputs: ["min"] }, { kind: "directive", type: i4$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i4$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i5.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i5.MatLabel, selector: "mat-label" }, { kind: "directive", type: i5.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i5.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "directive", type: i7.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i10.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i8$1.MatSelect, selector: "mat-select", inputs: ["disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator"], exportAs: ["matSelect"] }, { kind: "component", type: i2$1.MatOption, selector: "mat-option", exportAs: ["matOption"] }, { kind: "component", type: i11.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: i2$2.NgxMatDatetimepicker, selector: "ngx-mat-datetime-picker", exportAs: ["ngxMatDatetimePicker"] }, { kind: "directive", type: i2$2.NgxMatDatepickerInput, selector: "input[ngxMatDatetimePicker]", inputs: ["ngxMatDatetimePicker", "min", "max", "matDatepickerFilter"], exportAs: ["ngxMatDatepickerInput"] }, { kind: "component", type: i2$2.NgxMatDatepickerToggle, selector: "ngx-mat-datepicker-toggle", inputs: ["for", "tabIndex", "aria-label", "disabled", "disableRipple"], exportAs: ["ngxMatDatepickerToggle"] }, { kind: "component", type: i2$2.NgxMatDatepickerActions, selector: "ngx-mat-datepicker-actions, ngx-mat-date-range-picker-actions" }, { kind: "directive", type: i2$2.NgxMatDatepickerCancel, selector: "[ngxMatDatepickerCancel], [ngxMatDateRangePickerCancel]" }, { kind: "directive", type: i2$2.NgxMatDatepickerApply, selector: "[ngxMatDatepickerApply], [ngxMatDateRangePickerApply]" }, { kind: "pipe", type: i1.SubTranslatePipe, name: "subtranslate" }, { kind: "pipe", type: i2.TranslatePipe, name: "translate" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartAppointmentFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-appointment-form', template: "<div class=\"p-2\">\n    <form [formGroup]=\"form\" class=\"appointment-form\" (ngSubmit)=\"form.valid && onSubmit($event)\">\n        <div class=\"d-flex flex-column\">\n            <mat-form-field [appearance]=\"appearance\">\n                <mat-label>{{'appointment-form.patient.label' | subtranslate:lang}}</mat-label>\n                <mat-select formControlName=\"patient\">\n                    <mat-option *ngFor=\"let g of patients\" [value]=\"g\">{{g.getFullName()}}</mat-option>\n                </mat-select>\n                <mat-error>{{getErrorMessage(\"patient\")}}</mat-error>\n            </mat-form-field>\n\n            <mat-form-field [appearance]=\"appearance\">\n                <mat-label>{{'appointment-form.type.label' | subtranslate:lang}}</mat-label>\n                <mat-select formControlName=\"type\">\n                    <mat-option *ngFor=\"let type of appointmentTypes\" [value]=\"type\">{{ type.uniqueLabelKey |\n                        translate }}</mat-option>\n                </mat-select>\n                <mat-error>{{getErrorMessage(\"type\")}}</mat-error>\n            </mat-form-field>\n        </div>\n        <div class=\"d-flex flex-column flex-md-row\">\n            <mat-form-field [appearance]=\"appearance\" class=\"flex-1 mr-md-2 date-selector\">\n                <mat-label>{{'appointment-form.start.label' | subtranslate:lang}}</mat-label>\n                <input matInput readonly [ngxMatDatetimePicker]=\"pickerStart\" formControlName=\"start\" [min]=\"now\">\n                <ngx-mat-datepicker-toggle matSuffix [for]=\"pickerStart\"></ngx-mat-datepicker-toggle>\n                <ngx-mat-datetime-picker #pickerStart [showSpinners]=\"true\" [showSeconds]=\"false\" [stepHour]=\"1\"\n                    [stepMinute]=\"10\">\n                    <ngx-mat-datepicker-actions>\n                        <button mat-button ngxMatDatepickerCancel>{{'appointment-form.cancel.label' |\n                            subtranslate:lang}}</button>\n                        <button mat-raised-button color=\"primary\" ngxMatDatepickerApply>{{'appointment-form.apply.label'\n                            | subtranslate:lang}}</button>\n                    </ngx-mat-datepicker-actions>\n                </ngx-mat-datetime-picker>\n                <mat-error>{{getErrorMessage(\"start\")}}</mat-error>\n            </mat-form-field>\n\n            <mat-form-field [appearance]=\"appearance\" class=\"flex-1 mr-md-2\">\n                <mat-label>{{'appointment-form.duration.label' | subtranslate:lang}}</mat-label>\n                <span matTextSuffix>{{'appointment-form.hour.unit' |subtranslate:lang }}</span>\n                <input matInput type=\"number\" min=\"1\" step=\"0.5\" formControlName=\"duration\">\n                <mat-icon matSuffix>timelapse</mat-icon>\n            </mat-form-field>\n        </div>\n        <!-- notes -->\n        <div class=\"d-flex flex-column\">\n            <mat-form-field [appearance]=\"appearance\" class=\"notes\">\n                <mat-label>{{'appointment-form.notes.label' | subtranslate:lang}}</mat-label>\n                <textarea matInput formControlName=\"notes\"></textarea>\n            </mat-form-field>\n        </div>\n        <div class=\"d-flex flex-row\">\n            <button class=\"mr-2\" mat-raised-button (click)=\"doCancel()\">{{'appointment-form.button.cancel.label' |\n                subtranslate:lang}}</button>\n            <button mat-raised-button [disabled]=\"(!form.touched || !form.valid)\" type=\"submit\"\n                color=\"primary\">{{'appointment-form.button.store.label' |\n                subtranslate:lang}}</button>\n        </div>\n    </form>\n</div>", styles: ["td.ngx-mat-timepicker-spacer{padding-bottom:20px!important}\n"] }]
        }], ctorParameters: function () { return [{ type: i1.SubTranslateService }, { type: i2$2.NgxMatDateAdapter }]; }, propDecorators: { appearance: [{
                type: Input
            }], lang: [{
                type: Input
            }], readOnly: [{
                type: Input
            }], patients: [{
                type: Input
            }], appointmentTypes: [{
                type: Input
            }], defaultLength: [{
                type: Input
            }], save: [{
                type: Output
            }] } });

// AoT requires an exported function for factories
function HttpLoaderFactoryAppointmentForm(http) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class HeartAppointmentFormModule {
}
HeartAppointmentFormModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartAppointmentFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
HeartAppointmentFormModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: HeartAppointmentFormModule, declarations: [HeartAppointmentFormComponent], imports: [CommonModule,
        ReactiveFormsModule,
        HttpClientModule,
        SubTranslateModule, i2.TranslateModule, MatCardModule,
        MatFormFieldModule,
        MatInputModule,
        MatIconModule,
        MatSelectModule,
        MatButtonModule,
        MatDatepickerModule,
        NgxMatTimepickerModule,
        NgxMatDatetimePickerModule,
        MatSliderModule,
        NgxMatNativeDateModule], exports: [HeartAppointmentFormComponent] });
HeartAppointmentFormModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartAppointmentFormModule, imports: [CommonModule,
        ReactiveFormsModule,
        HttpClientModule,
        SubTranslateModule,
        TranslateModule.forChild({
            defaultLanguage: 'en',
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactoryAppointmentForm,
                deps: [HttpClient],
            },
            isolate: true,
        }),
        MatCardModule,
        MatFormFieldModule,
        MatInputModule,
        MatIconModule,
        MatSelectModule,
        MatButtonModule,
        MatDatepickerModule,
        NgxMatTimepickerModule,
        NgxMatDatetimePickerModule,
        MatSliderModule,
        NgxMatNativeDateModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartAppointmentFormModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [HeartAppointmentFormComponent],
                    imports: [
                        CommonModule,
                        ReactiveFormsModule,
                        HttpClientModule,
                        SubTranslateModule,
                        TranslateModule.forChild({
                            defaultLanguage: 'en',
                            loader: {
                                provide: TranslateLoader,
                                useFactory: HttpLoaderFactoryAppointmentForm,
                                deps: [HttpClient],
                            },
                            isolate: true,
                        }),
                        MatCardModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatIconModule,
                        MatSelectModule,
                        MatButtonModule,
                        MatDatepickerModule,
                        NgxMatTimepickerModule,
                        NgxMatDatetimePickerModule,
                        MatSliderModule,
                        NgxMatNativeDateModule,
                    ],
                    providers: [],
                    exports: [HeartAppointmentFormComponent],
                }]
        }] });

/*
 * Public API Surface of heart-ui-encounter
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AppointmentsBrowserComponent, AppointmentsBrowserModule, HeartAppointmentFormComponent, HeartAppointmentFormModule, HeartEncounterTableComponent, HeartEncounterTableModule, HttpLoaderFactoryAppointmentForm, HttpLoaderFactoryEncounterList };
//# sourceMappingURL=eng-it4h-heart-ui-encounter.mjs.map
