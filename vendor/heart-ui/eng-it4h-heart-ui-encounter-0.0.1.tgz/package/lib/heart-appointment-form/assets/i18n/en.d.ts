export declare const en: {
    'appointment-form.patient.label': string;
    'appointment-form.type.label': string;
    'appointment-form.start.label': string;
    'appointment-form.cancel.label': string;
    'appointment-form.apply.label': string;
    'appointment-form.duration.label': string;
    'appointment-form.notes.label': string;
    'appointment-form.hour.unit': string;
    'appointment-form.button.store.label': string;
    'appointment-form.button.cancel.label': string;
    '<TYPESYSTEM>|annual-screening': string;
    '<TYPESYSTEM>|first-encounter': string;
    '<TYPESYSTEM>|school-check': string;
    '<TYPESYSTEM>|prevention-campaign': string;
    '<TYPESYSTEM>|other': string;
    'appointment-form.date-past.error': string;
};
