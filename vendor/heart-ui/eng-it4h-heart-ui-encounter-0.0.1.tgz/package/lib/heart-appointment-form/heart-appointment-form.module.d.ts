import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as i0 from "@angular/core";
import * as i1 from "./heart-appointment-form.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "@angular/common/http";
import * as i5 from "@eng-it4h/heart-ui-utils";
import * as i6 from "@ngx-translate/core";
import * as i7 from "@angular/material/card";
import * as i8 from "@angular/material/form-field";
import * as i9 from "@angular/material/input";
import * as i10 from "@angular/material/icon";
import * as i11 from "@angular/material/select";
import * as i12 from "@angular/material/button";
import * as i13 from "@angular/material/datepicker";
import * as i14 from "@angular-material-components/datetime-picker";
import * as i15 from "@angular/material/slider";
export declare function HttpLoaderFactoryAppointmentForm(http: HttpClient): TranslateHttpLoader;
export declare class HeartAppointmentFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<HeartAppointmentFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HeartAppointmentFormModule, [typeof i1.HeartAppointmentFormComponent], [typeof i2.CommonModule, typeof i3.ReactiveFormsModule, typeof i4.HttpClientModule, typeof i5.SubTranslateModule, typeof i6.TranslateModule, typeof i7.MatCardModule, typeof i8.MatFormFieldModule, typeof i9.MatInputModule, typeof i10.MatIconModule, typeof i11.MatSelectModule, typeof i12.MatButtonModule, typeof i13.MatDatepickerModule, typeof i14.NgxMatTimepickerModule, typeof i14.NgxMatDatetimePickerModule, typeof i15.MatSliderModule, typeof i14.NgxMatNativeDateModule], [typeof i1.HeartAppointmentFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HeartAppointmentFormModule>;
}
