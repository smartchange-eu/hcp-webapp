import { EventEmitter, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { SubTranslateService } from '@eng-it4h/heart-ui-utils';
import { Appointment, CodedValue, Patient } from '@eng-it4h/heart-ui-model';
import { NgxMatDateAdapter } from '@angular-material-components/datetime-picker';
import * as i0 from "@angular/core";
export declare class HeartAppointmentFormComponent implements OnInit {
    private _subTranslateService;
    private _da;
    protected minDate: Date;
    protected now: Date;
    /**
     * ASPECT SETTINGS
     */
    appearance: 'fill' | 'outline';
    lang: string;
    /**
     * OPERATING MODE SETTINGS
     */
    readOnly: boolean;
    patients: Patient[];
    appointmentTypes: CodedValue[];
    defaultLength: number;
    save: EventEmitter<Appointment>;
    protected form: FormGroup;
    protected defaultTime: any[];
    protected selectedAppointment: Appointment;
    constructor(_subTranslateService: SubTranslateService, _da: NgxMatDateAdapter<Date>);
    ngOnInit(): void;
    private createDictionary;
    private render;
    formatLabel(value: number): string;
    onSubmit(arg: any): void;
    doCancel(): void;
    resetForm(): void;
    prepare(): Appointment;
    getErrorMessage(formControlName: string): string;
    correctlySaved(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HeartAppointmentFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HeartAppointmentFormComponent, "heart-appointment-form", never, { "appearance": "appearance"; "lang": "lang"; "readOnly": "readOnly"; "patients": "patients"; "appointmentTypes": "appointmentTypes"; "defaultLength": "defaultLength"; }, { "save": "save"; }, never, never, false, never>;
}
