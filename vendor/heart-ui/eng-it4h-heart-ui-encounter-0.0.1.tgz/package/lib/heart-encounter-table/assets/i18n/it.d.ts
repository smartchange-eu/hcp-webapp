export declare const it: {
    "episode.table.filter.label": string;
    "episode.table.header.type": string;
    "episode.table.header.openingDate": string;
    "episode.table.header.closingDate": string;
    "episode.table.header.reason": string;
    "episode.table.header.organization": string;
    "episode.table.header.status": string;
    "episode.table.header.status.locked": string;
    "episode.table.header.status.editable": string;
    "episode.table.no-data": string;
    "episode.table.paginator.label": string;
    "episode.table.button.refresh": string;
};
