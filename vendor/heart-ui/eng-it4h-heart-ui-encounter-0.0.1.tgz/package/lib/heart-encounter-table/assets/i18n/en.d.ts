export declare const en: {
    'encounter.table.filter.label': string;
    'encounter.table.header.type': string;
    'encounter.table.header.openingDate': string;
    'encounter.table.header.closingDate': string;
    'encounter.table.header.reason': string;
    'encounter.table.header.organization': string;
    'encounter.table.header.status': string;
    'encounter.table.no-data': string;
    'encounter.table.paginator.label': string;
    'encounter.table.button.refresh': string;
};
