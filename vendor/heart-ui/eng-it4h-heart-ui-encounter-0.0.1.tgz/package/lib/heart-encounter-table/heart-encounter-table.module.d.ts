import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as i0 from "@angular/core";
import * as i1 from "./heart-encounter-table.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/material/table";
import * as i4 from "@angular/material/form-field";
import * as i5 from "@angular/material/paginator";
import * as i6 from "@angular/material/input";
import * as i7 from "@angular/material/sort";
import * as i8 from "@angular/material/button";
import * as i9 from "@angular/material/icon";
import * as i10 from "@angular/material/tooltip";
import * as i11 from "@eng-it4h/heart-ui-utils";
import * as i12 from "@ngx-translate/core";
export declare function HttpLoaderFactoryEncounterList(http: HttpClient): TranslateHttpLoader;
export declare class HeartEncounterTableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<HeartEncounterTableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HeartEncounterTableModule, [typeof i1.HeartEncounterTableComponent], [typeof i2.CommonModule, typeof i3.MatTableModule, typeof i4.MatFormFieldModule, typeof i5.MatPaginatorModule, typeof i6.MatInputModule, typeof i7.MatSortModule, typeof i8.MatButtonModule, typeof i9.MatIconModule, typeof i10.MatTooltipModule, typeof i11.SubTranslateModule, typeof i12.TranslateModule], [typeof i1.HeartEncounterTableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HeartEncounterTableModule>;
}
