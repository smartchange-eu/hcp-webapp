export declare const it: {
    'appointment.list.filter.label': string;
};
