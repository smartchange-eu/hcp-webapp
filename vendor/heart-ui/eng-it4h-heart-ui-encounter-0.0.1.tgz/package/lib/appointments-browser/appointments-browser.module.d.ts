import * as i0 from "@angular/core";
import * as i1 from "./appointments-browser.component";
import * as i2 from "@angular/common";
import * as i3 from "@eng-it4h/heart-ui-utils";
import * as i4 from "@ngx-translate/core";
import * as i5 from "@angular/material/paginator";
import * as i6 from "@angular/forms";
import * as i7 from "@angular/material/list";
import * as i8 from "@angular/material/datepicker";
import * as i9 from "@angular/material/input";
import * as i10 from "@angular/material/table";
import * as i11 from "@angular/material/button";
import * as i12 from "@angular/material/tooltip";
import * as i13 from "@angular/material/sort";
import * as i14 from "@angular/material/icon";
export declare class AppointmentsBrowserModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AppointmentsBrowserModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AppointmentsBrowserModule, [typeof i1.AppointmentsBrowserComponent], [typeof i2.CommonModule, typeof i3.SubTranslateModule, typeof i4.TranslateModule, typeof i5.MatPaginatorModule, typeof i6.FormsModule, typeof i7.MatListModule, typeof i8.MatDatepickerModule, typeof i9.MatInputModule, typeof i10.MatTableModule, typeof i11.MatButtonModule, typeof i12.MatTooltipModule, typeof i13.MatSortModule, typeof i14.MatIconModule, typeof i3.PreventDoubleClickModule], [typeof i1.AppointmentsBrowserComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AppointmentsBrowserModule>;
}
