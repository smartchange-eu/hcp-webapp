import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { FormControlStatus } from '@angular/forms';
import { AnswerGroup, Question, QuestionGroup, QuestionType, QuestionnaireResponse } from '@eng-it4h/heart-ui-model';
import { SubTranslateService } from '@eng-it4h/heart-ui-utils';
import { DateAdapter } from '@angular/material/core';
import * as i0 from "@angular/core";
export declare type QuestionnaireGroupFormat = 'none' | 'box' | 'card' | 'tab' | 'expansion';
export declare class DynBuiltQuestionnaireComponent implements OnChanges {
    private _dateAdapter;
    private _subTranslateService;
    private debug;
    questionnaireResponse: QuestionnaireResponse;
    questionnaireResponseChange: EventEmitter<QuestionnaireResponse>;
    /**
     * ASPECT SETTINGS
     */
    appearance: 'fill' | 'outline';
    lang: string;
    questionLastChar: string;
    headerBackgroundColor: string;
    showHeader: boolean;
    firstLevelGroupFormat: QuestionnaireGroupFormat;
    /**
     * OPERATING MODE SETTINGS
     */
    readOnly: boolean;
    enableActionButtons: boolean;
    editMode?: boolean;
    onModeChange: EventEmitter<boolean>;
    /**
     * EDIT FORM RENDERING SETTINGS
     */
    forceRadioButton?: boolean;
    maxValuesForRadio: number;
    smallQuestionColumn: boolean;
    emptyAnswerPlaceholder: string;
    onCancel?: EventEmitter<void>;
    onSave: EventEmitter<QuestionnaireResponse>;
    private editorComponent?;
    protected editorFormStatus?: FormControlStatus;
    protected readonly types: typeof QuestionType;
    protected readonly Question: typeof Question;
    protected readonly QuestionGroup: typeof QuestionGroup;
    protected readonly AnswerGroup: typeof AnswerGroup;
    constructor(_dateAdapter: DateAdapter<Date>, _subTranslateService: SubTranslateService);
    ngOnChanges(changes: SimpleChanges): void;
    private createDictionary;
    protected onCancelEdit(): void;
    /**
     * Attiva la modalità DISPLAY
     */
    setDisplayModeOn(): void;
    /**
     * Attiva la modalità EDIT ed imposta nei campi del form
     * il valore della risposta precedentemente digitato (qualora vi sia).
     * Nel caso non sia mai stato inserito un valore, resetta il campo.
     */
    setEditModeOn(): void;
    appendAnswerGroups(answersGroups: AnswerGroup[], path: string[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DynBuiltQuestionnaireComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DynBuiltQuestionnaireComponent, "heart-dyn-built-questionnaire", never, { "questionnaireResponse": "questionnaireResponse"; "appearance": "appearance"; "lang": "lang"; "questionLastChar": "questionLastChar"; "headerBackgroundColor": "headerBackgroundColor"; "showHeader": "showHeader"; "firstLevelGroupFormat": "firstLevelGroupFormat"; "readOnly": "readOnly"; "enableActionButtons": "enableActionButtons"; "editMode": "editMode"; "forceRadioButton": "forceRadioButton"; "maxValuesForRadio": "maxValuesForRadio"; "smallQuestionColumn": "smallQuestionColumn"; "emptyAnswerPlaceholder": "emptyAnswerPlaceholder"; }, { "questionnaireResponseChange": "questionnaireResponseChange"; "onModeChange": "onModeChange"; "onCancel": "onCancel"; "onSave": "onSave"; }, never, never, false, never>;
}
