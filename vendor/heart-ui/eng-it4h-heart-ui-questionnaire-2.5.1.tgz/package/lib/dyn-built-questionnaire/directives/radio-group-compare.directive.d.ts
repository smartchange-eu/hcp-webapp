import { AfterContentInit, ChangeDetectorRef, OnDestroy, QueryList } from '@angular/core';
import { Subscription } from 'rxjs';
import { MatRadioButton } from '@angular/material/radio';
import { FormControl, FormControlName } from '@angular/forms';
import * as i0 from "@angular/core";
/**
 * Add 'compareWith' to mat-radio-group just like mat-select, because angular team didn't implement it
 * see https://github.com/angular/components/issues/10495
 */
export declare class RadioGroupCompare<T> implements AfterContentInit, OnDestroy {
    private formControlName;
    private cdr;
    compareWith: (o1: T, o2: T) => boolean;
    formControl: FormControl;
    radioButtons: QueryList<MatRadioButton>;
    formControlSub: Subscription;
    constructor(formControlName: FormControlName, cdr: ChangeDetectorRef);
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioGroupCompare<any>, [{ optional: true; }, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RadioGroupCompare<any>, "mat-radio-group[compareWith]", never, { "compareWith": "compareWith"; "formControl": "formControl"; }, {}, ["radioButtons"], never, false, never>;
}
