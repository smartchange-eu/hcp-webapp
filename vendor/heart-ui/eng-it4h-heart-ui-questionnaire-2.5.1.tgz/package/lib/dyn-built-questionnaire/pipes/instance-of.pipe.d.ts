import type { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
declare type AbstractType<T> = abstract new (...args: any[]) => T;
export declare class InstanceofPipe implements PipeTransform {
    transform<V, R>(value: V, type: AbstractType<R>): R | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<InstanceofPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<InstanceofPipe, "instanceof", false>;
}
export {};
