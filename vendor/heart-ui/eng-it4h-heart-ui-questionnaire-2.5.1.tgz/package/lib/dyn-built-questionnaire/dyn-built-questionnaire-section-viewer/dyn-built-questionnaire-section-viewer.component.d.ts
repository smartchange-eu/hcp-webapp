import { OnInit } from '@angular/core';
import { Answer, AnswerGroup, Question, QuestionGroup, QuestionType, QuestionnaireResponse } from '@eng-it4h/heart-ui-model';
import * as i0 from "@angular/core";
export declare class DynBuiltQuestionnaireSectionViewerComponent implements OnInit {
    questionnaireResponse: QuestionnaireResponse;
    appearance: 'fill' | 'outline';
    smallQuestionColumn: boolean;
    emptyAnswerPlaceholder: string;
    questionLastChar: string;
    lang: string;
    protected readonly types: typeof QuestionType;
    protected readonly Question: typeof Question;
    protected readonly QuestionGroup: typeof QuestionGroup;
    protected readonly AnswerGroup: typeof AnswerGroup;
    constructor();
    ngOnInit(): void;
    protected findAnswerByQuestion(answers: (Answer | AnswerGroup)[], question: Question): Answer;
    protected findAnswerGroupByQuestionGroup(answers: (Answer | AnswerGroup)[], questionGroup: QuestionGroup): AnswerGroup | AnswerGroup[];
    extractAnswerValue(answer: Answer, question: Question): string | number | Date | boolean;
    extractTextualAnswerValue(answer: Answer, question: Question): string;
    extractDateAnswerValue(answer: Answer, question: Question): Date | string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DynBuiltQuestionnaireSectionViewerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DynBuiltQuestionnaireSectionViewerComponent, "heart-dyn-built-questionnaire-section-viewer", never, { "questionnaireResponse": "questionnaireResponse"; "appearance": "appearance"; "smallQuestionColumn": "smallQuestionColumn"; "emptyAnswerPlaceholder": "emptyAnswerPlaceholder"; "questionLastChar": "questionLastChar"; "lang": "lang"; }, {}, never, never, false, never>;
}
