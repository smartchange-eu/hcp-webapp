export declare const it: {
    "questionnaire.button.compile.label": string;
    "questionnaire.button.edit.label": string;
    "questionnaire.button.cancel.label": string;
    "questionnaire.button.save.label": string;
    "questionnaire.button.add.label": string;
    "msg.invalid_range": string;
    "msg.invalid_number_type": string;
};
