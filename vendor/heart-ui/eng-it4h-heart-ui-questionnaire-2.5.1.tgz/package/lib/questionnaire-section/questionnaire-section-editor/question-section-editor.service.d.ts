import { FormArray, FormGroup } from '@angular/forms';
import { Answer, AnswerGroup, Question, QuestionGroup, QuestionnaireResponse } from '@eng-it4h/heart-ui-model';
import * as i0 from "@angular/core";
export declare class QuestionSectionEditorService {
    private readonly DEFAULT_MAX_VALUE;
    createForm(questionnaireResponse: QuestionnaireResponse): FormGroup<any>;
    private createEnableWhenSubscription;
    private createFormControl;
    /**
     * Used to trigger the creation of a form group for repeteable question groups
     */
    createFormArrayGroup(parentGroup: FormArray, item: QuestionGroup, answerItem?: AnswerGroup): void;
    removeFormArrayGroup(parentGroup: FormArray, indexToRemove: number): void;
    /**
     *  Utility matcher of questions / answers in the Questionnaire and QuestionnaireResponse
     */
    matchQuestionAndAnswer: (q: Question | QuestionGroup, a: Answer | AnswerGroup) => boolean;
    /**
     * look for the nearest item as by FHIR Specification stating:
     * If multiple question occurrences are present for the same question (same linkId),
     * then this refers to the nearest question occurrence reachable by tracing first the "ancestor" axis
     * and then the "preceding" axis and then the "following" axis. If there are multiple items with the same
     * linkId and all are equadistant (e.g. a question references a question that appears in a separate repeating group), that is an error.
     *
     * (Consider using the enableWhenExpression extension to define logic to handle such a situation.)
     *
     * @param itemFormControl
     * @param linkId
     * @param direction
     * @returns
     */
    private lookForNearestFormControl;
    private evaluateCondition;
    isHidden(q: Question): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuestionSectionEditorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QuestionSectionEditorService>;
}
