import { AfterViewInit, EventEmitter, OnInit } from '@angular/core';
import { FormControlStatus, FormGroup } from '@angular/forms';
import { AnswerGroup, Question, QuestionGroup, QuestionnaireResponse } from '@eng-it4h/heart-ui-model';
import { QuestionnaireGroupFormat } from '../questionnaire-group-format.model';
import { QuestionSectionEditorService } from './question-section-editor.service';
import * as i0 from "@angular/core";
export declare class QuestionnaireSectionEditorComponent implements OnInit, AfterViewInit {
    private editorService;
    questionnaireResponse: QuestionnaireResponse;
    questionnaireResponseChange: EventEmitter<QuestionnaireResponse>;
    firstLevelGroupFormat: QuestionnaireGroupFormat;
    appearance: 'fill' | 'outline';
    questionLastChar: string;
    lang: string;
    smallQuestionColumn: boolean;
    maxValuesForRadio: number;
    forceRadioButton?: boolean;
    form?: FormGroup;
    validate: EventEmitter<FormControlStatus>;
    protected rootGroupAvailabilities: {
        [key: string]: boolean;
    };
    protected readonly Question: typeof Question;
    protected readonly QuestionGroup: typeof QuestionGroup;
    protected readonly AnswerGroup: typeof AnswerGroup;
    private viewInitialized;
    constructor(editorService: QuestionSectionEditorService);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    get formValid(): boolean;
    appendAnswerGroups(answersGroups: AnswerGroup[], paths: string[]): void;
    setEditFormGroup(): void;
    private createRootGroupAvailabilities;
    private _setEditFormGroup;
    private _setEditFormControl;
    /**
     * Legge le risposte fornite dall'utente e le salva
     * in una istanza di Response associata al Questionnaire
     */
    onSubmit(arg: any): void;
    /**
     * Provides a new instance of QuestionnaireResponse with the raw values available in the form.
     *
     * @returns
     */
    private prepareQuestionnaireResponse;
    private prepareAnswerGroup;
    private prepareAnswer;
    protected numericQuestionPlaceholder: (question: Question) => string;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuestionnaireSectionEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuestionnaireSectionEditorComponent, "heart-questionnaire-section-editor", never, { "questionnaireResponse": "questionnaireResponse"; "firstLevelGroupFormat": "firstLevelGroupFormat"; "appearance": "appearance"; "questionLastChar": "questionLastChar"; "lang": "lang"; "smallQuestionColumn": "smallQuestionColumn"; "maxValuesForRadio": "maxValuesForRadio"; "forceRadioButton": "forceRadioButton"; }, { "questionnaireResponseChange": "questionnaireResponseChange"; "validate": "validate"; }, never, never, false, never>;
}
