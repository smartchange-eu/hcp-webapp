export declare type QuestionnaireGroupFormat = 'none' | 'box' | 'card' | 'tab' | 'expansion';
