import { ModuleWithProviders } from '@angular/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient } from '@angular/common/http';
import { Locale as DateFnsLocale } from 'date-fns';
import * as i0 from "@angular/core";
import * as i1 from "./questionnaire-section.component";
import * as i2 from "./questionnaire-section-viewer/questionnaire-section-viewer.component";
import * as i3 from "./questionnaire-section-editor/questionnaire-section-editor.component";
import * as i4 from "./questionnaire-section-editor/questionnaire-section-editor-question/questionnaire-section-editor-question.component";
import * as i5 from "./questionnaire-section-editor/questionnaire-section-editor-group/questionnaire-section-editor-group.component";
import * as i6 from "./questionnaire-section-tester/questionnaire-section-tester.component";
import * as i7 from "./pipes/instance-of.pipe";
import * as i8 from "./directives/radio-group-compare.directive";
import * as i9 from "@angular/common";
import * as i10 from "@ngx-translate/core";
import * as i11 from "@angular/material/card";
import * as i12 from "@angular/material/expansion";
import * as i13 from "@angular/material/tabs";
import * as i14 from "@angular/material/form-field";
import * as i15 from "@angular/material/input";
import * as i16 from "@angular/material/icon";
import * as i17 from "@angular/material/select";
import * as i18 from "@angular/material/radio";
import * as i19 from "@angular/material/checkbox";
import * as i20 from "@angular/forms";
import * as i21 from "@angular/material/button";
import * as i22 from "@angular/material/datepicker";
import * as i23 from "@eng-it4h/heart-ui-utils";
export interface QuestionnaireSectionConfig {
    matDateLocale?: DateFnsLocale;
}
export declare function HttpLoaderFactoryQuestionnaire(http: HttpClient): TranslateHttpLoader;
export declare class QuestionnaireSectionModule {
    static forRoot(config: QuestionnaireSectionConfig): ModuleWithProviders<QuestionnaireSectionModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuestionnaireSectionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuestionnaireSectionModule, [typeof i1.QuestionnaireSectionComponent, typeof i2.QuestionnaireSectionViewerComponent, typeof i3.QuestionnaireSectionEditorComponent, typeof i4.QuestionnaireSectionEditorQuestionComponent, typeof i5.QuestionnaireSectionEditorGroupComponent, typeof i6.QuestionnaireSectionTesterComponent, typeof i7.InstanceofPipe, typeof i8.RadioGroupCompare], [typeof i9.CommonModule, typeof i10.TranslateModule, typeof i11.MatCardModule, typeof i12.MatExpansionModule, typeof i13.MatTabsModule, typeof i14.MatFormFieldModule, typeof i15.MatInputModule, typeof i16.MatIconModule, typeof i17.MatSelectModule, typeof i18.MatRadioModule, typeof i19.MatCheckboxModule, typeof i20.ReactiveFormsModule, typeof i21.MatButtonModule, typeof i22.MatDatepickerModule, typeof i23.SubTranslateModule, typeof i23.PreventDoubleClickModule], [typeof i1.QuestionnaireSectionComponent, typeof i6.QuestionnaireSectionTesterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuestionnaireSectionModule>;
}
