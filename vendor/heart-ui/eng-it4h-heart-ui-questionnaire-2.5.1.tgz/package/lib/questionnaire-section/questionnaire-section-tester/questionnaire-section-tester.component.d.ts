import { OnInit } from '@angular/core';
import { QuestionnaireGroupFormat } from '../questionnaire-group-format.model';
import { FormGroup } from '@angular/forms';
import { CodedValue, QuestionnaireResponse } from '@eng-it4h/heart-ui-model';
import * as i0 from "@angular/core";
export declare class QuestionnaireSectionTesterComponent implements OnInit {
    protected questionnaireResponseMixed: QuestionnaireResponse;
    protected questionnaireResponseWithOnlyGroups: QuestionnaireResponse;
    protected form?: FormGroup;
    /**
     * ASPECT SETTINGS
     */
    protected appearance: 'fill' | 'outline';
    protected appearanceOptions: CodedValue[];
    protected lang: string;
    protected langOptions: CodedValue[];
    protected questionLastChar: string;
    protected questionLastCharOptions: CodedValue[];
    protected showHeader: boolean;
    protected firstLevelGroupFormat: QuestionnaireGroupFormat;
    protected firstLevelGroupFormatOptions: CodedValue[];
    /**
     * OPERATING MODE SETTINGS
     */
    protected readOnly: boolean;
    protected enableActionButtons: boolean;
    protected editMode?: boolean;
    /**
     * EDIT FORM RENDERING SETTINGS
     */
    protected forceRadioButton?: boolean;
    protected maxValuesForRadio: number;
    protected maxValuesForRadioOptions: number[];
    protected smallQuestionColumn: boolean;
    protected emptyAnswerPlaceholder: string;
    protected emptyAnswerPlaceholderOptions: CodedValue[];
    protected questionnaireWithOnlyGroup: boolean;
    ngOnInit(): void;
    private createQuestionnaire;
    private questionGroup;
    private questionMultiChoiceGroup;
    private questionRepeatableGroup;
    private questionDisplay;
    private questionChoices;
    private questionInteger;
    private questionDecimal;
    private questionText;
    private questionString;
    private questionDate;
    private questionBoolean;
    private questionConditionedBoolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuestionnaireSectionTesterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuestionnaireSectionTesterComponent, "heart-questionnaire-section-tester", never, {}, {}, never, never, false, never>;
}
