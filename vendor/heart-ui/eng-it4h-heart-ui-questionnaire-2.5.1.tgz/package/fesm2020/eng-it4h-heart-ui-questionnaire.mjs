import * as i0 from '@angular/core';
import { Injectable, Directive, Optional, Input, ContentChildren, Component, Pipe, EventEmitter, Output, ViewChild, NgModule } from '@angular/core';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import { Answer, Question, AnswerGroup, QuestionGroup, QuestionType, CodedValue, QuestionEnableWhenOperator, QuestionnaireResponse, ResponseStatus, Questionnaire, Choice, QuestionEnableWhen, QuestionEnableWhenCondition } from '@eng-it4h/heart-ui-model';
import * as i10 from '@angular/forms';
import { FormGroup, FormArray, Validators, FormControl, ReactiveFormsModule } from '@angular/forms';
import { isBefore, isEqual, isAfter } from 'date-fns';
import * as i3$2 from '@angular/material/expansion';
import { MatExpansionModule } from '@angular/material/expansion';
import * as i4$1 from '@angular/material/tabs';
import { MatTabsModule } from '@angular/material/tabs';
import * as i3 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i3$1 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i4 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import * as i5 from '@angular/cdk/text-field';
import * as i6 from '@angular/material/select';
import { MatSelectModule } from '@angular/material/select';
import * as i1 from '@angular/material/core';
import { MAT_DATE_FORMATS, DateAdapter, MAT_DATE_LOCALE } from '@angular/material/core';
import * as i8 from '@angular/material/radio';
import { MatRadioButton, MatRadioModule } from '@angular/material/radio';
import * as i9 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';
import * as i11 from '@angular/material/datepicker';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { startWith } from 'rxjs';
import * as i1$1 from '@ngx-translate/core';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import * as i2$1 from '@eng-it4h/heart-ui-utils';
import { SubTranslateModule, PreventDoubleClickModule } from '@eng-it4h/heart-ui-utils';
import * as i5$1 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i4$2 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient } from '@angular/common/http';
import { MAT_DATE_FNS_FORMATS, DateFnsAdapter } from '@angular/material-date-fns-adapter';
import { enGB } from 'date-fns/locale';
import { random } from 'lodash-es';

const en$1 = {
    "questionnaire.button.compile.label": "Compile",
    "questionnaire.button.edit.label": "Edit",
    "questionnaire.button.cancel.label": "Cancel",
    "questionnaire.button.save.label": "Save",
    "questionnaire.button.add.label": "Add",
    "questionnaire.expansion.title.edited.label": "Edited",
    "questionnaire.expansion.description.available.label": "Filled",
    "msg.invalid_range": "Error. Possible invalid range.",
    "msg.invalid_number_type": "Error. Invalid numeric type."
};

const it$1 = {
    "questionnaire.button.compile.label": "Compila",
    "questionnaire.button.edit.label": "Modifica",
    "questionnaire.button.cancel.label": "Annulla",
    "questionnaire.button.save.label": "Salva",
    "questionnaire.button.add.label": "Aggiungi",
    "questionnaire.expansion.title.edited.label": "Modificato",
    "questionnaire.expansion.description.available.label": "Compilato",
    "msg.invalid_range": "Errore. Possibile intervallo errato.",
    "msg.invalid_number_type": "Errore. Formato non valido.",
    "questionnaire.star.explanation.text": "Con l'asterisco (*) sono contrassegnate domande o sezioni obbligatorie."
};

class QuestionSectionEditorService {
    constructor() {
        this.DEFAULT_MAX_VALUE = 1000000000;
        /**
         *  Utility matcher of questions / answers in the Questionnaire and QuestionnaireResponse
         */
        this.matchQuestionAndAnswer = (q, a) => (a instanceof Answer && q instanceof Question && a.questionId == q.questionId) || (a instanceof AnswerGroup && q instanceof QuestionGroup && a.groupId == q.groupId);
    }
    createForm(questionnaireResponse) {
        const group = new FormGroup([]);
        const relatedControlGroups = [];
        /*
         * Per ogni domanda del questionario:
         * 1. Crea l'istanza di FormControl
         * 2. Verifica se esista già una risposta data
         *    e nel caso valorizza il FormControl
         * 3. Qualora non esista una risposta già data
         *    in precedenza, verifica se c'è un valore di default
         *    da dare al FormControl
         */
        const questionnaireItems = questionnaireResponse.questionnaire?.items;
        questionnaireItems?.forEach((questionnaireItem) => {
            const isRepeated = questionnaireItem instanceof QuestionGroup && questionnaireItem.repeated;
            const _answerItem = questionnaireResponse.answers?.filter((a) => this.matchQuestionAndAnswer(questionnaireItem, a)) || [];
            const _answerItemWithOptionalRepeat = isRepeated ? _answerItem : _answerItem.pop();
            this.createFormControl(group, questionnaireItem, _answerItemWithOptionalRepeat, relatedControlGroups);
        });
        // once the form group has been created it adds all the logic to manage the identified 'enablingWhen'
        for (let index = 0; index < relatedControlGroups.length; index++) {
            const related = relatedControlGroups[index];
            const subscription = this.createEnableWhenSubscription(related.item, related.dependantControl);
            if (subscription == undefined) {
                throw new Error(`Missing subscription on enabling/disabling when event`);
            }
        }
        return group;
    }
    createEnableWhenSubscription(item, itemFormControl) {
        const when = item.enableWhen;
        if (!when) {
            return undefined;
        }
        const controls = [];
        for (const condition of when.conditions) {
            // look for nearest FormGroup with id == condition.linkId
            const linkedAnswerControl = this.lookForNearestFormControl(itemFormControl, condition.question);
            if (linkedAnswerControl) {
                controls.push({ formControl: linkedAnswerControl, condition: condition });
            }
            else {
                console.error(`FormControl for '${condition.question}' not found.`);
            }
        }
        const controlsCheck = (_controls, _when, _formControl) => {
            let enable = false;
            if (_when.behaviour == 'any' || (_when.behaviour == undefined && when.conditions.length == 1)) {
                // enable if behaviour is 'any'
                enable = _controls.some((c) => this.evaluateCondition(c.formControl.value, c.condition.operator, c.condition.answer));
            }
            else {
                // enable if behaviour is 'all'
                enable = _controls.every((c) => this.evaluateCondition(c.formControl.value, c.condition.operator, c.condition.answer));
            }
            if (enable) {
                _formControl.enable();
            }
            else {
                // FIX: bug #1485 to ensure that any nested question is not precompiled while
                // preparing the QuestionnaireRespone to be sent to the server and, thus, incurr in a server validation error
                _formControl.reset();
                _formControl.disable();
            }
        };
        // check the status of dependant form control during the form setup
        controlsCheck(controls, when, itemFormControl);
        // now create subscriptions for value change events
        const subscriptions = [];
        for (const c of controls) {
            const s = c.formControl.valueChanges.subscribe((currentValue) => {
                // trigger control checks
                controlsCheck(controls, when, itemFormControl);
            });
            subscriptions.push(s);
        }
        // return subscriptions to value changes
        return subscriptions;
    }
    createFormControl(parentGroup, item, answerItem, relatedControlGroups) {
        let newControl;
        let newControlName;
        if (item instanceof QuestionGroup) {
            newControlName = item.groupId;
            // if it is a repeteabled element let's prepare the form as to support the cloning
            // note that the condition on the FormArray is needed as recursion terminal condition while rendering existing RepeatableAnswerGroup items
            if (item.repeated && !(parentGroup instanceof FormArray)) {
                // manage RepeatedAnswerGroup
                newControl = new FormArray([]);
                // no actual item is created right now as we do it by calling the 'createFormArrayGroup' method
                if (answerItem != undefined && !Array.isArray(answerItem)) {
                    throw new Error(`This code can be reached only if 'answerItem' is instanceof repeated 'AnswerGroup`);
                }
                if (item.required) {
                    newControl.addValidators(Validators.required);
                }
                answerItem?.forEach((answer) => {
                    // in this case there is no need to look for repeated items
                    this.createFormControl(newControl, item, answer, relatedControlGroups);
                });
            }
            else {
                newControl = new FormGroup([]);
                if (answerItem != undefined && !(answerItem instanceof AnswerGroup) && !(parentGroup instanceof FormArray)) {
                    throw new Error(`This code can be reached only if 'answerItem' is instanceof 'AnswerGroup'`);
                }
                if (item.required) {
                    newControl.addValidators(Validators.required);
                }
                item.items?.forEach((questionnaireItem) => {
                    const isRepeated = questionnaireItem instanceof QuestionGroup && questionnaireItem.repeated;
                    const _answerItem = answerItem?.answers?.filter((a) => this.matchQuestionAndAnswer(questionnaireItem, a)) || [];
                    const _answerItemWithOptionalRepeat = isRepeated ? _answerItem : _answerItem.pop();
                    this.createFormControl(newControl, questionnaireItem, _answerItemWithOptionalRepeat, relatedControlGroups);
                });
            }
            if (item.enableWhen) {
                relatedControlGroups.push({ item: item, dependantControl: newControl });
            }
        }
        else {
            // from this line it manages simple Question items
            if (item.type != QuestionType.display) {
                const hasNestedQuestions = item.items?.length > 0;
                newControl = new FormControl();
                newControlName = item.questionId;
                // Validator in case of 'required' item
                if (item.required) {
                    newControl.addValidators(Validators.required);
                }
                // Validator per range numerico
                if (item.type === QuestionType.integer || item.type === QuestionType.decimal) {
                    if (item.type === QuestionType.integer) {
                        newControl.addValidators(Validators.pattern('[+-]?\\d+'));
                    }
                    else if (item.type === QuestionType.decimal) {
                        newControl.addValidators(Validators.pattern('[+-]?\\d+((\\.|\\,)\\d+)?'));
                    }
                    if (item.min != undefined) {
                        newControl.addValidators(Validators.min(item.min));
                    }
                    if (item.max != undefined) {
                        item.max = item.max || this.DEFAULT_MAX_VALUE;
                        newControl.addValidators(Validators.max(item.max));
                    }
                }
                // Imposta il valore del FormControl
                const answer = answerItem;
                if (answer) {
                    if (item.multiChoice && item.type == QuestionType.CodedValue && answer.value instanceof CodedValue) {
                        newControl.setValue([answer.value]);
                    }
                    else {
                        // se esiste una risposta già data la usa come value del control
                        // console.log("imposto il valore del control: " + q.questionId + " a " + answer.value);
                        newControl.setValue(answer.value);
                    }
                    // console.log("RISPOSTA per " + item.questionId + ": " + answer.value);
                }
                /*
                else {
                  // preset delle risposte predefinite - if any
                  const defaultChoice : Choice = q.permittedAnswers?.find(ans => ans.initialSelected);
                  if (defaultChoice){
                    // console.log("imposto il valore di default del control: " + q.questionId + " a " + defaultChoice.value);
                    group[q.questionId].value = defaultChoice.value;
                  }
                }
                */
                if (hasNestedQuestions) {
                    // it has nested Questions
                    // wrap the FormControl in a FormGroup by reusing the control name (i.e. questionId)
                    const newControlForm = newControl;
                    newControl = new FormGroup([]);
                    newControl.addControl(newControlName, newControlForm);
                    newControlName = item.questionId;
                    item.items?.forEach((questionnaireItem) => {
                        const _answerItem = answerItem?.answers?.find((a) => this.matchQuestionAndAnswer(questionnaireItem, a));
                        // in this case there is no need to look for repeated items (currently we do not support repeated Answer but only AnswerGroups)
                        this.createFormControl(newControl, questionnaireItem, _answerItem, relatedControlGroups);
                    });
                }
                // must be after 'hasNestedQuestions'!!!
                if (item.enableWhen) {
                    relatedControlGroups.push({ item: item, dependantControl: newControl });
                }
            }
        }
        // Disable the control if the item is 'readOnly'
        if (item.readOnly) {
            newControl.disable();
        }
        if (newControl) {
            // aggiunge il nuovo controllo al gruppo.
            if (parentGroup instanceof FormGroup) {
                parentGroup.addControl(newControlName, newControl);
            }
            else {
                parentGroup.push(newControl);
            }
        }
    }
    /**
     * Used to trigger the creation of a form group for repeteable question groups
     */
    createFormArrayGroup(parentGroup, item, answerItem) {
        const newControl = new FormGroup([]);
        const relatedControlGroups = [];
        item.items?.forEach((questionnaireItem) => {
            const _answerItem = answerItem?.answers?.find((a) => this.matchQuestionAndAnswer(questionnaireItem, a));
            // in this case there is no need to look for repeated items
            this.createFormControl(newControl, questionnaireItem, _answerItem, relatedControlGroups);
        });
        // once the form group has been created it adds all the logic to manage the identified 'enablingWhen'
        for (let index = 0; index < relatedControlGroups.length; index++) {
            const related = relatedControlGroups[index];
            const subscription = this.createEnableWhenSubscription(related.item, related.dependantControl);
            if (subscription == undefined) {
                throw new Error(`Missing subscription on enabling/disabling when event`);
            }
        }
        parentGroup.push(newControl);
    }
    removeFormArrayGroup(parentGroup, indexToRemove) {
        parentGroup.removeAt(indexToRemove);
    }
    /**
     * look for the nearest item as by FHIR Specification stating:
     * If multiple question occurrences are present for the same question (same linkId),
     * then this refers to the nearest question occurrence reachable by tracing first the "ancestor" axis
     * and then the "preceding" axis and then the "following" axis. If there are multiple items with the same
     * linkId and all are equadistant (e.g. a question references a question that appears in a separate repeating group), that is an error.
     *
     * (Consider using the enableWhenExpression extension to define logic to handle such a situation.)
     *
     * @param itemFormControl
     * @param linkId
     * @param direction
     * @returns
     */
    lookForNearestFormControl(itemFormControl, linkId, direction = 'up') {
        let formControl;
        if (direction == 'up') {
            const parent = itemFormControl.parent;
            if (!parent) {
                return undefined;
            }
            formControl = parent.get(linkId);
            if (formControl && formControl instanceof FormControl) {
                // the linked answer is a sibling of the current node
                return formControl;
            }
            else {
                // if not it starts looking in the 'ancestors' axis
                if (parent instanceof FormGroup) {
                    formControl = this.lookForNearestFormControl(parent, linkId);
                }
                else if (parent instanceof FormArray) {
                    // skip (as it can't refer a specific repeatable item) and look for its parent
                    formControl = this.lookForNearestFormControl(parent.parent, linkId);
                }
                if (!formControl) {
                    // look for 'preceding' axis ???
                    // look in the 'following' axis
                    if (itemFormControl instanceof FormGroup) {
                        const controls = itemFormControl.controls;
                        for (const controlName in controls) {
                            formControl = this.lookForNearestFormControl(controls[controlName], linkId, 'down');
                            if (formControl) {
                                continue;
                            }
                        }
                    }
                    else if (itemFormControl instanceof FormArray) {
                        // skip (as it can't refer a specific repeatable item)
                    }
                }
            }
        }
        if (direction == 'down') {
            const child = itemFormControl.get(linkId);
            if (child && child instanceof FormControl) {
                return child;
            }
            else {
                if (itemFormControl instanceof FormGroup) {
                    const controls = itemFormControl.controls;
                    for (const controlName in controls) {
                        formControl = this.lookForNearestFormControl(controls[controlName], linkId, 'down');
                        if (formControl) {
                            continue;
                        }
                    }
                }
                else if (itemFormControl instanceof FormArray) {
                    // skip (as it can't refer a specific repeatable item)
                }
            }
        }
        return formControl;
    }
    // evaluate condition
    evaluateCondition(currentValue, operator, answer) {
        switch (operator) {
            case QuestionEnableWhenOperator.EXISTS:
                return currentValue != undefined;
            case QuestionEnableWhenOperator.EQ: {
                if (currentValue instanceof Date) {
                    return isEqual(currentValue, answer);
                }
                else if (currentValue instanceof CodedValue) {
                    return currentValue?.code == answer?.code;
                }
                else {
                    return currentValue == answer;
                }
            }
            case QuestionEnableWhenOperator.NE:
                if (currentValue instanceof Date) {
                    return !isEqual(currentValue, answer);
                }
                else if (currentValue instanceof CodedValue) {
                    return currentValue?.code != answer?.code;
                }
                else {
                    return currentValue != answer;
                }
            case QuestionEnableWhenOperator.GT:
                if (currentValue instanceof Date) {
                    return isAfter(currentValue, answer);
                }
                else if (currentValue instanceof CodedValue) {
                    throw new Error(`Invalid comparision for GT of CodedValue`);
                }
                else {
                    return currentValue > answer;
                }
            case QuestionEnableWhenOperator.GE:
                if (currentValue instanceof Date) {
                    return isAfter(currentValue, answer) || isEqual(currentValue, answer);
                }
                else if (currentValue instanceof CodedValue) {
                    throw new Error(`Invalid comparision for GE of CodedValue`);
                }
                else {
                    return currentValue > answer;
                }
            case QuestionEnableWhenOperator.LT:
                if (currentValue instanceof Date) {
                    return isBefore(currentValue, answer);
                }
                else if (currentValue instanceof CodedValue) {
                    throw new Error(`Invalid comparision for BT of CodedValue`);
                }
                else {
                    return currentValue < answer;
                }
            case QuestionEnableWhenOperator.LE:
                if (currentValue instanceof Date) {
                    return isBefore(currentValue, answer) || isEqual(currentValue, answer);
                }
                else if (currentValue instanceof CodedValue) {
                    throw new Error(`Invalid comparision for LE of CodedValue`);
                }
                else {
                    return currentValue <= answer;
                }
        }
    }
    isHidden(q) {
        return q.readOnly && !(q.type === QuestionType.CodedValue);
    }
}
QuestionSectionEditorService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: QuestionSectionEditorService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
QuestionSectionEditorService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: QuestionSectionEditorService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: QuestionSectionEditorService, decorators: [{
            type: Injectable
        }] });

/**
 * Add 'compareWith' to mat-radio-group just like mat-select, because angular team didn't implement it
 * see https://github.com/angular/components/issues/10495
 */
let RadioGroupCompare$1 = class RadioGroupCompare {
    constructor(formControlName, cdr) {
        this.formControlName = formControlName;
        this.cdr = cdr;
    }
    ngAfterContentInit() {
        const control = this.formControl || this.formControlName;
        // Use ngAfterContentInit to make sure that radioButtons is initialized
        this.formControlSub = control.valueChanges
            .pipe(startWith(control.value))
            .subscribe((value) => {
            const foundRadioButton = this.radioButtons
                .toArray()
                .find((radioButton) => {
                // Find a radio button whose value compares to ngModel
                return this.compareWith(radioButton.value, value);
            });
            if (foundRadioButton) {
                foundRadioButton.checked = true;
                this.cdr.detectChanges();
            }
        });
    }
    ngOnDestroy() {
        if (this.formControlSub) {
            this.formControlSub.unsubscribe();
        }
    }
};
RadioGroupCompare$1.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RadioGroupCompare$1, deps: [{ token: i10.FormControlName, optional: true }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Directive });
RadioGroupCompare$1.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "15.2.10", type: RadioGroupCompare$1, selector: "mat-radio-group[compareWith]", inputs: { compareWith: "compareWith", formControl: "formControl" }, queries: [{ propertyName: "radioButtons", predicate: MatRadioButton, descendants: true }], ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RadioGroupCompare$1, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: 'mat-radio-group[compareWith]',
                }]
        }], ctorParameters: function () { return [{ type: i10.FormControlName, decorators: [{
                    type: Optional
                }] }, { type: i0.ChangeDetectorRef }]; }, propDecorators: { compareWith: [{
                type: Input
            }], formControl: [{
                type: Input
            }], radioButtons: [{
                type: ContentChildren,
                args: [MatRadioButton, { descendants: true }]
            }] } });

class QuestionnaireSectionEditorQuestionComponent {
    constructor(editorService) {
        this.editorService = editorService;
        this.smallQuestionColumn = false; // manage the width of the question column and the rendering of the overall questionnaire
        this.maxValuesForRadio = 5; // [GUIDELINE] max value for switching options from Radio to Select
        this.forceRadioButton = false; // render options only as Radio Button
        this.appearance = 'outline';
        this.questionLastChar = '?'; // last char to be added to questions
        // put to 'true' if you are rendering Questions nested in Questions (not in QuestionGroups)
        this.nestedQuestion = false;
        this.types = QuestionType;
        this.Question = Question;
        this.QuestionGroup = QuestionGroup;
        this.AnswerGroup = AnswerGroup;
        this.hiddenQuestion = false;
        this.numericQuestionPlaceholder = (question) => {
            return [question.min, question.max].filter((v) => v != undefined).join(' - ') || '';
        };
    }
    ngOnInit() {
        this.hiddenQuestion = this.editorService.isHidden(this.question);
    }
    get formGroup() {
        // if nested question
        if (this.nestedQuestion) {
            return this.form;
        }
        // if not nested but has nested questions
        if (this.question.items?.length > 0) {
            return this.form.get(this.question.questionId);
        }
        return this.form;
    }
    asFormGroup(formControl) {
        return formControl;
    }
    castAnswers(choices) {
        return choices;
    }
    compareCodedValues(c1, c2) {
        if (c1 == undefined || c2 == undefined) {
            return false;
        }
        // In case of primitive type
        if (c1 === c2) {
            return true;
        }
        if (c1 instanceof CodedValue && c2 instanceof CodedValue && c1.code == c2.code) {
            return true;
        }
        return false;
    }
    compareChoices(c1, c2) {
        const c1Value = c1?.value;
        const c2Value = c2?.value;
        if (c1Value == undefined || c2Value == undefined) {
            return false;
        }
        if (c1Value instanceof CodedValue && c2Value instanceof CodedValue) {
            return c1Value?.code == c2Value?.code;
        }
        return c1Value == c2Value;
    }
}
QuestionnaireSectionEditorQuestionComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: QuestionnaireSectionEditorQuestionComponent, deps: [{ token: QuestionSectionEditorService }], target: i0.ɵɵFactoryTarget.Component });
QuestionnaireSectionEditorQuestionComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: QuestionnaireSectionEditorQuestionComponent, selector: "heart-questionnaire-section-editor-question", inputs: { question: "question", form: "form", smallQuestionColumn: "smallQuestionColumn", maxValuesForRadio: "maxValuesForRadio", forceRadioButton: "forceRadioButton", appearance: "appearance", questionLastChar: "questionLastChar", lang: "lang", nestedQuestion: "nestedQuestion" }, ngImport: i0, template: "<div *ngIf=\"form && !hiddenQuestion\" [formGroup]=\"formGroup\"\n  [ngClass]=\"{'d-flex': true, 'responsive-row': true, 'bottom-bordered-responsive-row' : !smallQuestionColumn}\">\n\n  <ng-container *ngIf=\"question.type !== types.display\">\n    <!--  domanda -->\n    <div class=\"question\" *ngIf=\"!nestedQuestion\"\n      [ngClass]=\"{'flex-basis-50' : !smallQuestionColumn, 'flex-basis-25' : smallQuestionColumn, 'question-highlight': question.required}\">\n      <span *ngIf=\"question.required\">*&nbsp;</span><span\n        *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text | translate}}{{questionLastChar}}\n    </div>\n\n    <div class=\"d-flex flex-1 flex-column\">\n\n      <!-- se la risposta \u00E8 chiusa verifica quante sono le possibili risposte -->\n      <!-- radiobutton se < 5 -->\n      <div class=\"flex-1\"\n        *ngIf=\"!question.multiChoice && ((question.hasClosedAnswer() && question.permittedAnswers.length <= maxValuesForRadio) || forceRadioButton)\">\n        <mat-label class=\"mat-caption\" *ngIf=\"nestedQuestion\"><span *ngIf=\"question.required\">*&nbsp;</span><span\n            *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n          translate}}{{questionLastChar}}</mat-label>\n\n        <mat-radio-group [formControlName]=\"question.questionId\" [compareWith]=\"compareCodedValues\"\n          [ngClass]=\"{'vertical-radio-group' : !smallQuestionColumn}\">\n          <mat-radio-button *ngFor=\"let permittedAnswer of castAnswers(question.permittedAnswers)\"\n            [value]=\"permittedAnswer.value\">\n            {{permittedAnswer.label | translate}}\n          </mat-radio-button>\n        </mat-radio-group>\n      </div>\n\n      <!-- select se >= 5 -->\n      <!-- in ogni caso se la risposta \u00E8 chiusa e a risposta multipla mostra una combobox -->\n      <div class=\"flex-1\"\n        *ngIf=\"question.multiChoice || (question.hasClosedAnswer() && question.permittedAnswers.length > maxValuesForRadio)\">\n        <mat-form-field [appearance]=\"appearance\" [ngClass]=\"{'medium-width' : nestedQuestion}\">\n          <mat-label class=\"mat-caption\" *ngIf=\"nestedQuestion\"><span *ngIf=\"question.required\">*&nbsp;</span><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n          <mat-select [formControlName]=\"question.questionId\" [compareWith]=\"compareCodedValues\"\n            [multiple]=\"question.multiChoice\">\n\n            <mat-option *ngFor=\"let permittedAnswer of castAnswers(question.permittedAnswers)\"\n              [value]=\"permittedAnswer.value\">\n              {{permittedAnswer.label | translate}}\n            </mat-option>\n          </mat-select>\n        </mat-form-field>\n      </div>\n\n      <div class=\"flex-1\"\n        [ngClass]=\"{'d-flex flex-column': question.type === types.string || question.type === types.text}\"\n        *ngIf=\"!question.hasClosedAnswer()\">\n        <!-- risposta chiusa di tipo boolean -->\n        <ng-container *ngIf=\"question.type == types.boolean\">\n          <mat-label class=\"mat-caption\" *ngIf=\"nestedQuestion\"><span *ngIf=\"question.required\">*&nbsp;</span><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <section [ngClass]=\"{'vertical-radio-group' : !smallQuestionColumn}\">\n            <!-- if it is required we can't use a checkbox as it becomes mandatory to check it to valdiate the form -->\n            <mat-checkbox *ngIf=\"!question.required\" [formControlName]=\"question.questionId\"></mat-checkbox>\n\n            <!-- FORM: <small>{{ form.get(question.questionId) | json}}</small><br> -->\n            <mat-radio-group *ngIf=\"question.required\" [formControlName]=\"question.questionId\">\n              <mat-radio-button [value]=\"true\">{{ 'questionnaire.boolean.true' | translate}}</mat-radio-button>\n              <mat-radio-button [value]=\"false\">{{ 'questionnaire.boolean.false' | translate}}</mat-radio-button>\n            </mat-radio-group>\n          </section>\n        </ng-container>\n\n        <!-- risposta aperta di tipo number -->\n        <mat-form-field\n          *ngIf=\"((question.type === types.integer) || (question.type === types.decimal))&& !question.readOnly\"\n          [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <input matInput [formControlName]=\"question.questionId\" type=\"number\"\n            placeholder=\"{{ numericQuestionPlaceholder(question) }}\">\n          <mat-error\n            *ngIf=\"form.get(question.questionId)?.hasError('min') || form.get(question.questionId)?.hasError('max')\">{{('msg.invalid_range'\n            | subtranslate:lang) }} ({{ numericQuestionPlaceholder(question) }})</mat-error>\n          <mat-error *ngIf=\"form.get(question.questionId)?.hasError('pattern')\">{{ 'msg.invalid_number_type' |\n            subtranslate:lang }}</mat-error>\n        </mat-form-field>\n\n        <!-- risposta aperta di tipo text (long text) -->\n        <mat-form-field *ngIf=\"(question.type === types.text)\" [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <textarea matInput [formControlName]=\"question.questionId\" cdkTextareaAutosize cdkAutosizeMinRows=\"2\"\n            cdkAutosizeMaxRows=\"5\" [attr.maxlength]=\"question.maxLength\"></textarea>\n        </mat-form-field>\n\n        <!-- risposta aperta di tipo string (short text) -->\n        <mat-form-field *ngIf=\"(question.type === types.string)\" [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <input matInput [formControlName]=\"question.questionId\" type=\"text\">\n        </mat-form-field>\n\n        <!-- risposta aperta di tipo Date o DateTime -->\n        <mat-form-field *ngIf=\"(question.type === types.date)\" [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <input matInput readonly [matDatepicker]=\"picker\" [formControlName]=\"question.questionId\" />\n          <mat-datepicker-toggle matIconSuffix [for]=\"picker\"></mat-datepicker-toggle>\n          <mat-datepicker #picker></mat-datepicker>\n        </mat-form-field>\n\n        <!-- risposta aperta di tipo CodedValue senza permittedAnswer (serve solo se viene forzato un valore senza definire le possibili alternative ed, in quanto tale, \u00E8 sempre disabilitato) -->\n        <mat-form-field *ngIf=\"(question.type === types.CodedValue) && question.readOnly\" [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <input matInput type=\"string\" disabled\n            value=\"{{formGroup.get(question.questionId)?.value?.display | translate}}\">\n\n          <!-- <input matInput [formControlName]=\"question.questionId\" type=\"string\">{{formGroup.get(question.questionId)?.value?.display | translate}} -->\n        </mat-form-field>\n      </div>\n\n      <div *ngFor=\"let item of question.items\">\n        <heart-questionnaire-section-editor-question [questionLastChar]=\"questionLastChar\"\n          [smallQuestionColumn]=\"smallQuestionColumn\" [maxValuesForRadio]=\"maxValuesForRadio\"\n          [forceRadioButton]=\"forceRadioButton\" [appearance]=\"appearance\" [lang]=\"lang\"\n          [form]=\"asFormGroup(form.get(question.questionId))\" [nestedQuestion]=\"true\"\n          [question]=\"item\"></heart-questionnaire-section-editor-question>\n      </div>\n\n    </div>\n\n  </ng-container>\n\n  <!-- domanda di tipo 'display' -->\n  <span *ngIf=\"(question.type === types.display)\" class=\"mat-caption mb-2\">{{ question.text | translate }}</span>\n</div>", styles: [".questionnaire{min-width:400px}.questionnaire .question{overflow-wrap:break-word;font-weight:bolder;opacity:.8}.group-box{border-style:solid;border-width:1px;border-color:#00000061;border-radius:4px}.responsive-row{flex-direction:row;align-items:baseline}.title{font-weight:600}@media screen and (max-width: 768px){.gutter{column-gap:0}.responsive-row{flex-direction:column;align-items:stretch;column-gap:0}}mat-radio-button{margin-right:16px!important}.child-required:after{content:\"*\";color:#0009;size:16px;font-weight:400}.question.question-highlight{font-weight:700}.vertical-radio-group{display:flex;flex-direction:column;align-items:flex-start}medium-width{width:25rem}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i3.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i3.MatLabel, selector: "mat-label" }, { kind: "directive", type: i3.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i3.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "directive", type: i4.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "directive", type: i5.CdkTextareaAutosize, selector: "textarea[cdkTextareaAutosize]", inputs: ["cdkAutosizeMinRows", "cdkAutosizeMaxRows", "cdkTextareaAutosize", "placeholder"], exportAs: ["cdkTextareaAutosize"] }, { kind: "component", type: i6.MatSelect, selector: "mat-select", inputs: ["disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator"], exportAs: ["matSelect"] }, { kind: "component", type: i1.MatOption, selector: "mat-option", exportAs: ["matOption"] }, { kind: "directive", type: i8.MatRadioGroup, selector: "mat-radio-group", exportAs: ["matRadioGroup"] }, { kind: "component", type: i8.MatRadioButton, selector: "mat-radio-button", inputs: ["disableRipple", "tabIndex"], exportAs: ["matRadioButton"] }, { kind: "component", type: i9.MatCheckbox, selector: "mat-checkbox", inputs: ["disableRipple", "color", "tabIndex"], exportAs: ["matCheckbox"] }, { kind: "directive", type: i10.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i10.NumberValueAccessor, selector: "input[type=number][formControlName],input[type=number][formControl],input[type=number][ngModel]" }, { kind: "directive", type: i10.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i10.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i10.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i10.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i10.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i11.MatDatepicker, selector: "mat-datepicker", exportAs: ["matDatepicker"] }, { kind: "directive", type: i11.MatDatepickerInput, selector: "input[matDatepicker]", inputs: ["matDatepicker", "min", "max", "matDatepickerFilter"], exportAs: ["matDatepickerInput"] }, { kind: "component", type: i11.MatDatepickerToggle, selector: "mat-datepicker-toggle", inputs: ["for", "tabIndex", "aria-label", "disabled", "disableRipple"], exportAs: ["matDatepickerToggle"] }, { kind: "component", type: QuestionnaireSectionEditorQuestionComponent, selector: "heart-questionnaire-section-editor-question", inputs: ["question", "form", "smallQuestionColumn", "maxValuesForRadio", "forceRadioButton", "appearance", "questionLastChar", "lang", "nestedQuestion"] }, { kind: "directive", type: RadioGroupCompare$1, selector: "mat-radio-group[compareWith]", inputs: ["compareWith", "formControl"] }, { kind: "pipe", type: i1$1.TranslatePipe, name: "translate" }, { kind: "pipe", type: i2$1.SubTranslatePipe, name: "subtranslate" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: QuestionnaireSectionEditorQuestionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-questionnaire-section-editor-question', template: "<div *ngIf=\"form && !hiddenQuestion\" [formGroup]=\"formGroup\"\n  [ngClass]=\"{'d-flex': true, 'responsive-row': true, 'bottom-bordered-responsive-row' : !smallQuestionColumn}\">\n\n  <ng-container *ngIf=\"question.type !== types.display\">\n    <!--  domanda -->\n    <div class=\"question\" *ngIf=\"!nestedQuestion\"\n      [ngClass]=\"{'flex-basis-50' : !smallQuestionColumn, 'flex-basis-25' : smallQuestionColumn, 'question-highlight': question.required}\">\n      <span *ngIf=\"question.required\">*&nbsp;</span><span\n        *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text | translate}}{{questionLastChar}}\n    </div>\n\n    <div class=\"d-flex flex-1 flex-column\">\n\n      <!-- se la risposta \u00E8 chiusa verifica quante sono le possibili risposte -->\n      <!-- radiobutton se < 5 -->\n      <div class=\"flex-1\"\n        *ngIf=\"!question.multiChoice && ((question.hasClosedAnswer() && question.permittedAnswers.length <= maxValuesForRadio) || forceRadioButton)\">\n        <mat-label class=\"mat-caption\" *ngIf=\"nestedQuestion\"><span *ngIf=\"question.required\">*&nbsp;</span><span\n            *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n          translate}}{{questionLastChar}}</mat-label>\n\n        <mat-radio-group [formControlName]=\"question.questionId\" [compareWith]=\"compareCodedValues\"\n          [ngClass]=\"{'vertical-radio-group' : !smallQuestionColumn}\">\n          <mat-radio-button *ngFor=\"let permittedAnswer of castAnswers(question.permittedAnswers)\"\n            [value]=\"permittedAnswer.value\">\n            {{permittedAnswer.label | translate}}\n          </mat-radio-button>\n        </mat-radio-group>\n      </div>\n\n      <!-- select se >= 5 -->\n      <!-- in ogni caso se la risposta \u00E8 chiusa e a risposta multipla mostra una combobox -->\n      <div class=\"flex-1\"\n        *ngIf=\"question.multiChoice || (question.hasClosedAnswer() && question.permittedAnswers.length > maxValuesForRadio)\">\n        <mat-form-field [appearance]=\"appearance\" [ngClass]=\"{'medium-width' : nestedQuestion}\">\n          <mat-label class=\"mat-caption\" *ngIf=\"nestedQuestion\"><span *ngIf=\"question.required\">*&nbsp;</span><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n          <mat-select [formControlName]=\"question.questionId\" [compareWith]=\"compareCodedValues\"\n            [multiple]=\"question.multiChoice\">\n\n            <mat-option *ngFor=\"let permittedAnswer of castAnswers(question.permittedAnswers)\"\n              [value]=\"permittedAnswer.value\">\n              {{permittedAnswer.label | translate}}\n            </mat-option>\n          </mat-select>\n        </mat-form-field>\n      </div>\n\n      <div class=\"flex-1\"\n        [ngClass]=\"{'d-flex flex-column': question.type === types.string || question.type === types.text}\"\n        *ngIf=\"!question.hasClosedAnswer()\">\n        <!-- risposta chiusa di tipo boolean -->\n        <ng-container *ngIf=\"question.type == types.boolean\">\n          <mat-label class=\"mat-caption\" *ngIf=\"nestedQuestion\"><span *ngIf=\"question.required\">*&nbsp;</span><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <section [ngClass]=\"{'vertical-radio-group' : !smallQuestionColumn}\">\n            <!-- if it is required we can't use a checkbox as it becomes mandatory to check it to valdiate the form -->\n            <mat-checkbox *ngIf=\"!question.required\" [formControlName]=\"question.questionId\"></mat-checkbox>\n\n            <!-- FORM: <small>{{ form.get(question.questionId) | json}}</small><br> -->\n            <mat-radio-group *ngIf=\"question.required\" [formControlName]=\"question.questionId\">\n              <mat-radio-button [value]=\"true\">{{ 'questionnaire.boolean.true' | translate}}</mat-radio-button>\n              <mat-radio-button [value]=\"false\">{{ 'questionnaire.boolean.false' | translate}}</mat-radio-button>\n            </mat-radio-group>\n          </section>\n        </ng-container>\n\n        <!-- risposta aperta di tipo number -->\n        <mat-form-field\n          *ngIf=\"((question.type === types.integer) || (question.type === types.decimal))&& !question.readOnly\"\n          [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <input matInput [formControlName]=\"question.questionId\" type=\"number\"\n            placeholder=\"{{ numericQuestionPlaceholder(question) }}\">\n          <mat-error\n            *ngIf=\"form.get(question.questionId)?.hasError('min') || form.get(question.questionId)?.hasError('max')\">{{('msg.invalid_range'\n            | subtranslate:lang) }} ({{ numericQuestionPlaceholder(question) }})</mat-error>\n          <mat-error *ngIf=\"form.get(question.questionId)?.hasError('pattern')\">{{ 'msg.invalid_number_type' |\n            subtranslate:lang }}</mat-error>\n        </mat-form-field>\n\n        <!-- risposta aperta di tipo text (long text) -->\n        <mat-form-field *ngIf=\"(question.type === types.text)\" [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <textarea matInput [formControlName]=\"question.questionId\" cdkTextareaAutosize cdkAutosizeMinRows=\"2\"\n            cdkAutosizeMaxRows=\"5\" [attr.maxlength]=\"question.maxLength\"></textarea>\n        </mat-form-field>\n\n        <!-- risposta aperta di tipo string (short text) -->\n        <mat-form-field *ngIf=\"(question.type === types.string)\" [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <input matInput [formControlName]=\"question.questionId\" type=\"text\">\n        </mat-form-field>\n\n        <!-- risposta aperta di tipo Date o DateTime -->\n        <mat-form-field *ngIf=\"(question.type === types.date)\" [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <input matInput readonly [matDatepicker]=\"picker\" [formControlName]=\"question.questionId\" />\n          <mat-datepicker-toggle matIconSuffix [for]=\"picker\"></mat-datepicker-toggle>\n          <mat-datepicker #picker></mat-datepicker>\n        </mat-form-field>\n\n        <!-- risposta aperta di tipo CodedValue senza permittedAnswer (serve solo se viene forzato un valore senza definire le possibili alternative ed, in quanto tale, \u00E8 sempre disabilitato) -->\n        <mat-form-field *ngIf=\"(question.type === types.CodedValue) && question.readOnly\" [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <input matInput type=\"string\" disabled\n            value=\"{{formGroup.get(question.questionId)?.value?.display | translate}}\">\n\n          <!-- <input matInput [formControlName]=\"question.questionId\" type=\"string\">{{formGroup.get(question.questionId)?.value?.display | translate}} -->\n        </mat-form-field>\n      </div>\n\n      <div *ngFor=\"let item of question.items\">\n        <heart-questionnaire-section-editor-question [questionLastChar]=\"questionLastChar\"\n          [smallQuestionColumn]=\"smallQuestionColumn\" [maxValuesForRadio]=\"maxValuesForRadio\"\n          [forceRadioButton]=\"forceRadioButton\" [appearance]=\"appearance\" [lang]=\"lang\"\n          [form]=\"asFormGroup(form.get(question.questionId))\" [nestedQuestion]=\"true\"\n          [question]=\"item\"></heart-questionnaire-section-editor-question>\n      </div>\n\n    </div>\n\n  </ng-container>\n\n  <!-- domanda di tipo 'display' -->\n  <span *ngIf=\"(question.type === types.display)\" class=\"mat-caption mb-2\">{{ question.text | translate }}</span>\n</div>", styles: [".questionnaire{min-width:400px}.questionnaire .question{overflow-wrap:break-word;font-weight:bolder;opacity:.8}.group-box{border-style:solid;border-width:1px;border-color:#00000061;border-radius:4px}.responsive-row{flex-direction:row;align-items:baseline}.title{font-weight:600}@media screen and (max-width: 768px){.gutter{column-gap:0}.responsive-row{flex-direction:column;align-items:stretch;column-gap:0}}mat-radio-button{margin-right:16px!important}.child-required:after{content:\"*\";color:#0009;size:16px;font-weight:400}.question.question-highlight{font-weight:700}.vertical-radio-group{display:flex;flex-direction:column;align-items:flex-start}medium-width{width:25rem}\n"] }]
        }], ctorParameters: function () { return [{ type: QuestionSectionEditorService }]; }, propDecorators: { question: [{
                type: Input
            }], form: [{
                type: Input
            }], smallQuestionColumn: [{
                type: Input
            }], maxValuesForRadio: [{
                type: Input
            }], forceRadioButton: [{
                type: Input
            }], appearance: [{
                type: Input
            }], questionLastChar: [{
                type: Input
            }], lang: [{
                type: Input
            }], nestedQuestion: [{
                type: Input
            }] } });

let InstanceofPipe$1 = class InstanceofPipe {
    transform(value, type) {
        return value instanceof type ? value : undefined;
    }
};
InstanceofPipe$1.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: InstanceofPipe$1, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
InstanceofPipe$1.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: InstanceofPipe$1, name: "instanceof" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: InstanceofPipe$1, decorators: [{
            type: Pipe,
            args: [{
                    name: 'instanceof',
                    pure: true,
                }]
        }] });

class QuestionnaireSectionEditorGroupComponent {
    constructor(editorService) {
        this.editorService = editorService;
        this.firstLevel = false;
        this.firstLevelGroupFormat = 'box';
        this.smallQuestionColumn = false; // manage the width of the question column and the rendering of the overall questionnaire
        this.maxValuesForRadio = 5; // [GUIDELINE] max value for switching options from Radio to Select
        this.forceRadioButton = false; // render options only as Radio Button
        this.appearance = 'outline';
        this.questionLastChar = "?"; // last char to be added to questions
        this.types = QuestionType;
        this.Question = Question;
        this.QuestionGroup = QuestionGroup;
        this.AnswerGroup = AnswerGroup;
    }
    ngOnInit() {
    }
    createFormArrayGroup(parentGroup, item, answerItem) {
        this.editorService.createFormArrayGroup(parentGroup, item, answerItem);
    }
    removeFormArrayGroup(parentGroup, indexToRemove) {
        this.editorService.removeFormArrayGroup(parentGroup, indexToRemove);
    }
    asFormGroup(formControl) {
        return formControl;
    }
    asFormArray(formControl) {
        return formControl;
    }
    asFormArrayControls(formControl) {
        return formControl.controls;
    }
}
QuestionnaireSectionEditorGroupComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: QuestionnaireSectionEditorGroupComponent, deps: [{ token: QuestionSectionEditorService }], target: i0.ɵɵFactoryTarget.Component });
QuestionnaireSectionEditorGroupComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: QuestionnaireSectionEditorGroupComponent, selector: "heart-questionnaire-section-editor-group", inputs: { group: "group", form: "form", firstLevel: "firstLevel", firstLevelGroupFormat: "firstLevelGroupFormat", smallQuestionColumn: "smallQuestionColumn", maxValuesForRadio: "maxValuesForRadio", forceRadioButton: "forceRadioButton", appearance: "appearance", questionLastChar: "questionLastChar", lang: "lang" }, ngImport: i0, template: "<ng-container *ngIf=\"!group.repeated\" [formGroup]=\"form\">\n  <!-- mt-2 mb-2 -->\n  <div class=\"flex-1 d-flex flex-column \"\n    [ngClass]=\"{ 'group-box': !firstLevel || (firstLevel && firstLevelGroupFormat == 'box'), 'card': !firstLevel || (firstLevel && firstLevelGroupFormat == 'card'), 'p-3': !firstLevel || (firstLevel && firstLevelGroupFormat != 'none') }\"\n    [formGroupName]=\"group.groupId\">\n    <h3 class=\"mat-mdc-card-subtitle\" *ngIf=\"!firstLevel || (firstLevel && (firstLevelGroupFormat == 'box' || firstLevelGroupFormat == 'card'))\">\n      {{ group.text | translate }}\n    </h3>\n\n    <!-- per ogni domanda -->\n    <ng-container *ngFor=\"let item of group?.items\">\n      <ng-container *ngIf=\"item | instanceof: Question as q\">\n\n        <heart-questionnaire-section-editor-question\n          [questionLastChar]=\"questionLastChar\"\n          [smallQuestionColumn]=\"smallQuestionColumn\"\n          [maxValuesForRadio]=\"maxValuesForRadio\"\n          [forceRadioButton]=\"forceRadioButton\"\n          [appearance]=\"appearance\"\n          [lang]=\"lang\"\n          [nestedQuestion]=\"false\"\n          [form]=\"asFormGroup(form.get(group.groupId))\"\n          [question]=\"q\"></heart-questionnaire-section-editor-question>\n      </ng-container>\n\n      <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n        <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form.get(group.groupId), firstLevel: false }\"></ng-container> -->\n        <heart-questionnaire-section-editor-group\n          [questionLastChar]=\"questionLastChar\"\n          [smallQuestionColumn]=\"smallQuestionColumn\"\n          [maxValuesForRadio]=\"maxValuesForRadio\"\n          [forceRadioButton]=\"forceRadioButton\"\n          [appearance]=\"appearance\"\n          [lang]=\"lang\"\n          [form]=\"asFormGroup(form.get(group.groupId))\"\n          [firstLevel]=\"false\"\n          [group]=\"g\"></heart-questionnaire-section-editor-group>\n      </ng-container>\n    </ng-container>\n  </div>\n</ng-container>\n\n<!-- Manage editing for repeatable form groups -->\n<ng-container *ngIf=\"group.repeated\" [formGroup]=\"form\">\n  <div\n    class=\"flex-1 d-flex flex-column mt-2 mb-2\"\n    [ngClass]=\"{ 'group-box': !firstLevel || (firstLevel && firstLevelGroupFormat == 'box'), 'card': !firstLevel || (firstLevel && firstLevelGroupFormat == 'card'), 'p-3': !firstLevel || (firstLevel && firstLevelGroupFormat != 'none') }\"\n    [formArrayName]=\"group.groupId\">\n\n    <h3 class=\"mat-mdc-card-subtitle\" *ngIf=\"!firstLevel || (firstLevel && [ 'box', 'card', 'none'].includes(firstLevelGroupFormat))\">\n      {{ group.text | translate }}</h3>\n\n    <!-- per ogni domanda -->\n    <ng-container *ngFor=\"let control of asFormArrayControls(form.get(group.groupId)); index as i\">\n      <div class=\"group-box mb-2 p-3\">\n        <div class=\"d-flex flex-justify-end\">\n          <button mat-icon-button color=\"primary\" (click)=\"removeFormArrayGroup(asFormArray(form.get(group.groupId)), i)\"><mat-icon>delete</mat-icon></button>\n        </div>\n\n        <ng-container *ngFor=\"let item of group?.items\">\n          <ng-container *ngIf=\"item | instanceof: Question as q\">\n            <heart-questionnaire-section-editor-question\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [nestedQuestion]=\"false\"\n              [form]=\"asFormGroup(control)\"\n              [question]=\"q\"></heart-questionnaire-section-editor-question>\n          </ng-container>\n\n          <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n            <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form.get(group.groupId), firstLevel: false }\"></ng-container>  -->\n            <heart-questionnaire-section-editor-group\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [form]=\"asFormGroup(control)\"\n              [firstLevel]=\"false\"\n              [group]=\"g\"></heart-questionnaire-section-editor-group>\n          </ng-container>\n        </ng-container>\n      </div>\n    </ng-container>\n\n    <div class=\"d-flex flex-justify-end\">\n      <button mat-raised-button color=\"primary\" (click)=\"createFormArrayGroup(asFormArray(form.get(group.groupId)), group, undefined)\">{{ 'questionnaire.button.add.label' | subtranslate:lang }}</button>\n    </div>\n  </div>\n</ng-container>\n", styles: [".questionnaire{min-width:400px}.questionnaire .question{overflow-wrap:break-word;font-weight:bolder;opacity:.8}.group-box{border-style:solid;border-width:1px;border-color:#00000061;border-radius:4px}.responsive-row{flex-direction:row;align-items:baseline}.title{font-weight:600}@media screen and (max-width: 768px){.gutter{column-gap:0}.responsive-row{flex-direction:column;align-items:stretch;column-gap:0}}mat-radio-button{margin-right:16px!important}.child-required:after{content:\"*\";color:#0009;size:16px;font-weight:400}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: i10.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i10.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i10.FormGroupName, selector: "[formGroupName]", inputs: ["formGroupName"] }, { kind: "directive", type: i10.FormArrayName, selector: "[formArrayName]", inputs: ["formArrayName"] }, { kind: "component", type: i5$1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: i5$1.MatIconButton, selector: "button[mat-icon-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: QuestionnaireSectionEditorQuestionComponent, selector: "heart-questionnaire-section-editor-question", inputs: ["question", "form", "smallQuestionColumn", "maxValuesForRadio", "forceRadioButton", "appearance", "questionLastChar", "lang", "nestedQuestion"] }, { kind: "component", type: QuestionnaireSectionEditorGroupComponent, selector: "heart-questionnaire-section-editor-group", inputs: ["group", "form", "firstLevel", "firstLevelGroupFormat", "smallQuestionColumn", "maxValuesForRadio", "forceRadioButton", "appearance", "questionLastChar", "lang"] }, { kind: "pipe", type: i1$1.TranslatePipe, name: "translate" }, { kind: "pipe", type: i2$1.SubTranslatePipe, name: "subtranslate" }, { kind: "pipe", type: InstanceofPipe$1, name: "instanceof" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: QuestionnaireSectionEditorGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-questionnaire-section-editor-group', template: "<ng-container *ngIf=\"!group.repeated\" [formGroup]=\"form\">\n  <!-- mt-2 mb-2 -->\n  <div class=\"flex-1 d-flex flex-column \"\n    [ngClass]=\"{ 'group-box': !firstLevel || (firstLevel && firstLevelGroupFormat == 'box'), 'card': !firstLevel || (firstLevel && firstLevelGroupFormat == 'card'), 'p-3': !firstLevel || (firstLevel && firstLevelGroupFormat != 'none') }\"\n    [formGroupName]=\"group.groupId\">\n    <h3 class=\"mat-mdc-card-subtitle\" *ngIf=\"!firstLevel || (firstLevel && (firstLevelGroupFormat == 'box' || firstLevelGroupFormat == 'card'))\">\n      {{ group.text | translate }}\n    </h3>\n\n    <!-- per ogni domanda -->\n    <ng-container *ngFor=\"let item of group?.items\">\n      <ng-container *ngIf=\"item | instanceof: Question as q\">\n\n        <heart-questionnaire-section-editor-question\n          [questionLastChar]=\"questionLastChar\"\n          [smallQuestionColumn]=\"smallQuestionColumn\"\n          [maxValuesForRadio]=\"maxValuesForRadio\"\n          [forceRadioButton]=\"forceRadioButton\"\n          [appearance]=\"appearance\"\n          [lang]=\"lang\"\n          [nestedQuestion]=\"false\"\n          [form]=\"asFormGroup(form.get(group.groupId))\"\n          [question]=\"q\"></heart-questionnaire-section-editor-question>\n      </ng-container>\n\n      <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n        <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form.get(group.groupId), firstLevel: false }\"></ng-container> -->\n        <heart-questionnaire-section-editor-group\n          [questionLastChar]=\"questionLastChar\"\n          [smallQuestionColumn]=\"smallQuestionColumn\"\n          [maxValuesForRadio]=\"maxValuesForRadio\"\n          [forceRadioButton]=\"forceRadioButton\"\n          [appearance]=\"appearance\"\n          [lang]=\"lang\"\n          [form]=\"asFormGroup(form.get(group.groupId))\"\n          [firstLevel]=\"false\"\n          [group]=\"g\"></heart-questionnaire-section-editor-group>\n      </ng-container>\n    </ng-container>\n  </div>\n</ng-container>\n\n<!-- Manage editing for repeatable form groups -->\n<ng-container *ngIf=\"group.repeated\" [formGroup]=\"form\">\n  <div\n    class=\"flex-1 d-flex flex-column mt-2 mb-2\"\n    [ngClass]=\"{ 'group-box': !firstLevel || (firstLevel && firstLevelGroupFormat == 'box'), 'card': !firstLevel || (firstLevel && firstLevelGroupFormat == 'card'), 'p-3': !firstLevel || (firstLevel && firstLevelGroupFormat != 'none') }\"\n    [formArrayName]=\"group.groupId\">\n\n    <h3 class=\"mat-mdc-card-subtitle\" *ngIf=\"!firstLevel || (firstLevel && [ 'box', 'card', 'none'].includes(firstLevelGroupFormat))\">\n      {{ group.text | translate }}</h3>\n\n    <!-- per ogni domanda -->\n    <ng-container *ngFor=\"let control of asFormArrayControls(form.get(group.groupId)); index as i\">\n      <div class=\"group-box mb-2 p-3\">\n        <div class=\"d-flex flex-justify-end\">\n          <button mat-icon-button color=\"primary\" (click)=\"removeFormArrayGroup(asFormArray(form.get(group.groupId)), i)\"><mat-icon>delete</mat-icon></button>\n        </div>\n\n        <ng-container *ngFor=\"let item of group?.items\">\n          <ng-container *ngIf=\"item | instanceof: Question as q\">\n            <heart-questionnaire-section-editor-question\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [nestedQuestion]=\"false\"\n              [form]=\"asFormGroup(control)\"\n              [question]=\"q\"></heart-questionnaire-section-editor-question>\n          </ng-container>\n\n          <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n            <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form.get(group.groupId), firstLevel: false }\"></ng-container>  -->\n            <heart-questionnaire-section-editor-group\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [form]=\"asFormGroup(control)\"\n              [firstLevel]=\"false\"\n              [group]=\"g\"></heart-questionnaire-section-editor-group>\n          </ng-container>\n        </ng-container>\n      </div>\n    </ng-container>\n\n    <div class=\"d-flex flex-justify-end\">\n      <button mat-raised-button color=\"primary\" (click)=\"createFormArrayGroup(asFormArray(form.get(group.groupId)), group, undefined)\">{{ 'questionnaire.button.add.label' | subtranslate:lang }}</button>\n    </div>\n  </div>\n</ng-container>\n", styles: [".questionnaire{min-width:400px}.questionnaire .question{overflow-wrap:break-word;font-weight:bolder;opacity:.8}.group-box{border-style:solid;border-width:1px;border-color:#00000061;border-radius:4px}.responsive-row{flex-direction:row;align-items:baseline}.title{font-weight:600}@media screen and (max-width: 768px){.gutter{column-gap:0}.responsive-row{flex-direction:column;align-items:stretch;column-gap:0}}mat-radio-button{margin-right:16px!important}.child-required:after{content:\"*\";color:#0009;size:16px;font-weight:400}\n"] }]
        }], ctorParameters: function () { return [{ type: QuestionSectionEditorService }]; }, propDecorators: { group: [{
                type: Input
            }], form: [{
                type: Input
            }], firstLevel: [{
                type: Input
            }], firstLevelGroupFormat: [{
                type: Input
            }], smallQuestionColumn: [{
                type: Input
            }], maxValuesForRadio: [{
                type: Input
            }], forceRadioButton: [{
                type: Input
            }], appearance: [{
                type: Input
            }], questionLastChar: [{
                type: Input
            }], lang: [{
                type: Input
            }] } });

class QuestionnaireSectionEditorComponent {
    constructor(editorService) {
        this.editorService = editorService;
        this.questionnaireResponseChange = new EventEmitter();
        this.firstLevelGroupFormat = 'box';
        this.appearance = 'outline';
        this.questionLastChar = '?'; // last char to be added to questions
        this.smallQuestionColumn = false; // manage the width of the question column and the rendering of the overall questionnaire
        this.maxValuesForRadio = 5; // [GUIDELINE] max value for switching options from Radio to Select
        this.forceRadioButton = false; // render options only as Radio Button
        // @Output() public formChange = new EventEmitter<FormGroup>();
        this.validate = new EventEmitter();
        // supporting structure to track if a form group is pre-initialized
        this.rootGroupAvailabilities = {};
        // protected readonly types = QuestionType;
        this.Question = Question;
        this.QuestionGroup = QuestionGroup;
        this.AnswerGroup = AnswerGroup;
        // used to avoid the error 'Expression has changed after it was checked' on the Editor action buttons
        this.viewInitialized = false;
        this.numericQuestionPlaceholder = (question) => {
            return [question.min, question.max].filter((v) => v != undefined).join(' - ') || '';
        };
    }
    ngOnInit() {
        this.viewInitialized = false;
        const form = this.editorService.createForm(this.questionnaireResponse);
        // update the 'rootGroupAvailabilities' map
        this.rootGroupAvailabilities = this.createRootGroupAvailabilities(this.questionnaireResponse.answers);
        this.form = form;
        this.form.statusChanges.subscribe((status) => this.validate.emit(status));
    }
    ngAfterViewInit() {
        // this.formChange.emit(this.form);
        this.viewInitialized = true;
    }
    ngOnDestroy() {
        this.viewInitialized = false;
        this.rootGroupAvailabilities = {};
        this.form = undefined;
    }
    get formValid() {
        return this.form && this.viewInitialized && this.form.valid;
    }
    appendAnswerGroups(answersGroups, paths) {
        if (!(answersGroups?.length > 0)) {
            return;
        }
        const questionnaire = this.questionnaireResponse.questionnaire;
        // look for the QuestionGroup in the QuestionnaireResponse->Questionnaire
        let question = questionnaire;
        for (let index = 0; index < paths.length && question != undefined; index++) {
            const path = paths[index];
            question = question.items?.find((i) => i.questionId == path);
        }
        if (!question) {
            throw Error(`Question item not found in the questionnaire. Check the path '${paths.join('.')}'`);
        }
        else if (!(question instanceof QuestionGroup)) {
            throw Error(`You can append only to QuestionGroup while you are currently referring the Question at '${paths.join('.')}'`);
        }
        // look for the FormArray in the FormGroup
        // const parentFormGroup: FormArray;
        if (!this.form) {
            throw Error(`The FormGroup is not available so you can't append items.`);
        }
        const parentFormGroup = this.form.get(paths);
        if (!parentFormGroup) {
            throw Error(`FormArray not found in the FormGroup. Check the path ` + paths.join('.'));
        }
        else if (!(parentFormGroup instanceof FormArray)) {
            throw Error(`You can append only to FormArray while you are currently referring ${parentFormGroup}`);
        }
        answersGroups.forEach((answersGroup) => {
            this.editorService.createFormArrayGroup(parentFormGroup, question, answersGroup);
        });
        // force validation checks
        parentFormGroup.markAsTouched();
    }
    setEditFormGroup() {
        const form = this.editorService.createForm(this.questionnaireResponse);
        const questionItems = this.questionnaireResponse.questionnaire?.items;
        const answerItems = this.questionnaireResponse.answers;
        this._setEditFormGroup(questionItems, answerItems, form);
        // update the 'rootGroupAvailabilities' map
        this.rootGroupAvailabilities = this.createRootGroupAvailabilities(answerItems);
        this.form = form;
    }
    createRootGroupAvailabilities(answers) {
        const rootGroup = {};
        answers
            ?.filter((answer) => answer instanceof AnswerGroup)
            ?.forEach((answer) => {
            if (answer.answers?.length > 0)
                rootGroup[answer.groupId] = true;
        });
        return rootGroup;
    }
    _setEditFormGroup(questionItems, answerItems, form) {
        questionItems?.forEach((qItem) => {
            const answer = answerItems?.find((aItem) => this.editorService.matchQuestionAndAnswer(qItem, aItem));
            if (qItem instanceof Question) {
                // look for the 'answer/answerGroup' matching the question item to get its value and setup the form
                this._setEditFormControl(qItem, answer, form);
            }
            else if (qItem instanceof QuestionGroup && answer instanceof AnswerGroup) {
                // support group
                this._setEditFormGroup(qItem.items, answer.answers, form.get(qItem.groupId));
            }
        });
    }
    _setEditFormControl(question, answer, form) {
        if (answer) {
            if (answer instanceof Answer && question instanceof Question) {
                if (question.permittedAnswers?.length > 0) {
                    const c = question.permittedAnswers.find((pa) => {
                        if (pa.value instanceof CodedValue) {
                            return pa.value.code == answer.value.code;
                        }
                        else {
                            return pa.value == answer.value;
                        }
                    });
                    form.get(question.questionId).setValue(c);
                }
                else if (answer instanceof Answer && answer.answers?.length > 0 && question instanceof Question) {
                    const answerItems = answer.answers;
                    const nestedForm = form.get(question.questionId);
                    nestedForm.get(question.questionId).setValue(answer.value);
                    question.items?.forEach((qItem) => {
                        const answer = answerItems?.find((aItem) => this.editorService.matchQuestionAndAnswer(qItem, aItem));
                        this._setEditFormControl(qItem, answer, nestedForm);
                    });
                }
                else {
                    form.get(question.questionId).setValue(answer.value);
                }
            }
        }
        else {
            form.get(question.questionId)?.reset();
        }
    }
    /**
     * Legge le risposte fornite dall'utente e le salva
     * in una istanza di Response associata al Questionnaire
     */
    onSubmit(arg) {
        if (this.form?.valid) {
            const newQuestionnaireResponse = this.prepareQuestionnaireResponse();
            this.questionnaireResponse = newQuestionnaireResponse;
            this.questionnaireResponseChange.emit(this.questionnaireResponse);
            // FIXME: informare tutti gli utilizzatori del modulo che vorremmo modificare la logica dell'editMode per fare in modo che venga settato dall'esterno solo su successo dello store
            // this.editMode = false;
            // this.modeChange(this.editMode);
        }
    }
    /**
     * Provides a new instance of QuestionnaireResponse with the raw values available in the form.
     *
     * @returns
     */
    prepareQuestionnaireResponse() {
        // verifica tutte le risposte date dall'utente
        const answers = this.questionnaireResponse?.questionnaire?.items
            .flatMap((item) => {
            if (item instanceof QuestionGroup) {
                // add some sort of grouping for Anwsers to preserve the Questionnaire nesting
                return this.prepareAnswerGroup(this.form.get(item.groupId), item);
            }
            else {
                return this.prepareAnswer(this.form, item);
            }
        })
            // remove any 'undefined' answer
            .filter((a) => a != undefined);
        // ID in case of update
        const oldId = this.questionnaireResponse.id;
        const newQuestionnaireResponse = new QuestionnaireResponse(this.questionnaireResponse.questionnaire);
        newQuestionnaireResponse.answers = answers;
        newQuestionnaireResponse.status = ResponseStatus.completed;
        newQuestionnaireResponse.id = oldId;
        return newQuestionnaireResponse;
    }
    prepareAnswerGroup(currentForm, item) {
        if (currentForm instanceof FormArray) {
            const answers = currentForm.controls
                .flatMap((c) => this.prepareAnswerGroup(c, item))
                // remove any 'undefined' answer
                .filter((a) => a != undefined);
            // return a the RepeatedAnswerGroup only of it has at least 1 instance
            return answers?.length > 0 ? answers : undefined;
        }
        else {
            const answer = new AnswerGroup();
            answer.groupId = item.groupId;
            // manage recursion to support 'QuestionGroup' submit
            answer.answers = item?.items
                ?.flatMap((item) => {
                if (item instanceof QuestionGroup) {
                    // add some sort of grouping for Anwsers to preserve the Questionnaire nesting
                    return this.prepareAnswerGroup(currentForm.get(item.groupId), item);
                }
                else {
                    return this.prepareAnswer(currentForm, item);
                }
            })
                // remove any 'undefined' answer
                .filter((a) => a != undefined);
            return answer;
        }
    }
    prepareAnswer(currentForm, question) {
        if (question.type == QuestionType.display) {
            return undefined;
        }
        const questionPath = question.questionId;
        // if has nested items
        const hasNestedItems = question.items?.length > 0;
        if (hasNestedItems) {
            currentForm = currentForm.get(question.questionId);
        }
        let value = undefined;
        if (question.type === QuestionType.CodedValue || question.permittedAnswers?.length > 0) {
            // if 'question.multiChoice == true' then the expected value is a CodedValue array
            value = currentForm.get(questionPath)?.value;
        }
        else if (question.type === QuestionType.integer) {
            value = currentForm.get(questionPath)?.value;
            if (value != undefined) {
                // force rounding to integer
                value = +value.toFixed();
            }
        }
        else if (question.type === QuestionType.decimal) {
            value = currentForm.get(questionPath)?.value;
            // FIXME: ensure that a decimal number is not
            // if ( value != undefined ) {
            // }
        }
        else if (question.type === QuestionType.text || question.type === QuestionType.string) {
            value = currentForm.get(questionPath)?.value;
            if (value) {
                value = value.trim();
            }
        }
        else if (question.type === QuestionType.boolean) {
            value = currentForm.get(questionPath)?.value;
            if (value != undefined) {
                value = value == true;
            }
        }
        else if (question.type === QuestionType.date /*|| question.type === QuestionType.dateTime*/) {
            value = currentForm.get(questionPath)?.value;
            // } else {
            //   throw new Error(`Type ${question.type.toString()} not supported. Impossible to fetch the value.`);
        }
        if (value != undefined) {
            const a = new Answer();
            a.questionId = question.questionId;
            a.value = value;
            if (hasNestedItems) {
                a.answers = question.items?.map((nestedQuestion) => {
                    return this.prepareAnswer(currentForm, nestedQuestion);
                });
            }
            return a;
        }
        return undefined;
    }
}
QuestionnaireSectionEditorComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: QuestionnaireSectionEditorComponent, deps: [{ token: QuestionSectionEditorService }], target: i0.ɵɵFactoryTarget.Component });
QuestionnaireSectionEditorComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: QuestionnaireSectionEditorComponent, selector: "heart-questionnaire-section-editor", inputs: { questionnaireResponse: "questionnaireResponse", firstLevelGroupFormat: "firstLevelGroupFormat", appearance: "appearance", questionLastChar: "questionLastChar", lang: "lang", smallQuestionColumn: "smallQuestionColumn", maxValuesForRadio: "maxValuesForRadio", forceRadioButton: "forceRadioButton" }, outputs: { questionnaireResponseChange: "questionnaireResponseChange", validate: "validate" }, ngImport: i0, template: "<form *ngIf=\"form\" [formGroup]=\"form\" (ngSubmit)=\"form.valid && onSubmit($event)\" class=\"xcard\">\n  <div class=\"d-flex flex-column questions\">\n\n    <!-- Deafult rendering structure-->\n    <ng-container *ngIf=\"firstLevelGroupFormat == 'box' || firstLevelGroupFormat == 'none' || firstLevelGroupFormat == 'card'\">\n      <!-- per ogni domanda -->\n      <div *ngFor=\"let item of questionnaireResponse?.questionnaire?.items\">\n\n        <ng-container *ngIf=\"item | instanceof: Question as q\">\n          <heart-questionnaire-section-editor-question\n            [questionLastChar]=\"questionLastChar\"\n            [smallQuestionColumn]=\"smallQuestionColumn\"\n            [maxValuesForRadio]=\"maxValuesForRadio\"\n            [forceRadioButton]=\"forceRadioButton\"\n            [appearance]=\"appearance\"\n            [lang]=\"lang\"\n            [nestedQuestion]=\"false\"\n            [form]=\"form\"\n            [question]=\"q\"></heart-questionnaire-section-editor-question>\n        </ng-container>\n\n        <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n          <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form, firstLevel: true }\"></ng-container> -->\n          <heart-questionnaire-section-editor-group\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [firstLevelGroupFormat]=\"firstLevelGroupFormat\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [form]=\"form\"\n              [firstLevel]=\"true\"\n              [group]=\"g\"></heart-questionnaire-section-editor-group>\n        </ng-container>\n\n      </div>\n    </ng-container>\n\n    <!-- Render the first level question grups as tabs -->\n    <ng-container *ngIf=\"firstLevelGroupFormat == 'expansion'\">\n      <mat-accordion>\n        <!-- per ogni domanda -->\n        <!--IGNORES questions without a group-->\n        <!--ng-container *ngIf=\"item | instanceof: Question as q\">\n          <ng-container *ngTemplateOutlet=\"editquestion; context: { $implicit: q, form: form }\"></ng-container>\n          <heart-questionnaire-section-editor-question\n            [questionLastChar]=\"questionLastChar\"\n            [smallQuestionColumn]=\"smallQuestionColumn\"\n            [maxValuesForRadio]=\"maxValuesForRadio\"\n            [forceRadioButton]=\"forceRadioButton\"\n            [appearance]=\"appearance\"\n            [lang]=\"lang\"\n            [nestedQuestion]=\"false\"\n            [form]=\"form\"\n            [question]=\"q\"></heart-questionnaire-section-editor-question>\n        </ng-container-->\n\n        <ng-container *ngFor=\"let item of questionnaireResponse?.questionnaire?.items\">\n          <mat-expansion-panel *ngIf=\"item | instanceof: QuestionGroup as g\">\n            <mat-expansion-panel-header>\n              <mat-panel-title class=\"title\" [ngClass]=\"{ 'expansion-title-highlight': form.get(g.groupId).dirty}\">\n                <mat-icon *ngIf=\"form.get(g.groupId).dirty && !form.get(g.groupId).valid\" color=\"warn\">warning</mat-icon>\n                <span *ngIf=\"g.showSubStar && !g.required\"class=\"child-required\" ></span>\n                <span *ngIf=\"g.required\">*&nbsp;</span>{{ g?.text | translate }}\n                <span *ngIf=\"form.get(g.groupId).dirty\" color=\"accent\">&nbsp;({{( 'questionnaire.expansion.title.edited.label' ) | subtranslate:lang }})</span>\n              </mat-panel-title>\n              <mat-panel-description>\n                <mat-label *ngIf=\"rootGroupAvailabilities[g.groupId]\">{{( 'questionnaire.expansion.description.available.label' ) | subtranslate:lang }}</mat-label>\n              </mat-panel-description>\n            </mat-expansion-panel-header>\n\n            <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form, firstLevel: true }\"></ng-container> -->\n            <heart-questionnaire-section-editor-group\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [firstLevelGroupFormat]=\"firstLevelGroupFormat\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [form]=\"form\"\n              [firstLevel]=\"true\"\n              [group]=\"g\"></heart-questionnaire-section-editor-group>\n          </mat-expansion-panel>\n        </ng-container>\n      </mat-accordion>\n    </ng-container>\n\n    <!-- Render the first level question grups as tabs -->\n    <ng-container *ngIf=\"firstLevelGroupFormat == 'tab'\">\n      <mat-tab-group mat-stretch-tabs=\"false\" mat-align-tabs=\"start\">\n        <!-- per ogni domanda -->\n        <mat-tab *ngFor=\"let item of questionnaireResponse?.questionnaire?.items\">\n          <!--IGNORES questions without a group-->\n\n          <!--ng-container *ngIf=\"item | instanceof: Question as q\">\n            <ng-template mat-tab-label>{{ item?.name | translate }}</ng-template>\n\n\n            <heart-questionnaire-section-editor-question\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [nestedQuestion]=\"false\"\n              [form]=\"form\"\n              [question]=\"q\"></heart-questionnaire-section-editor-question>\n          </ng-container-->\n\n          <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n            <ng-template mat-tab-label>\n              <span *ngIf=\"g.showSubStar && !g.required\"class=\"child-required\" ></span>\n              <mat-icon *ngIf=\"form.get(g.groupId).dirty && !form.get(g.groupId).valid\" color=\"warn\">warning</mat-icon>\n              {{ g?.text | translate }}\n              <span *ngIf=\"form.get(g.groupId).dirty\" color=\"accent\">&nbsp;({{( 'questionnaire.expansion.title.edited.label' ) | subtranslate:lang }})</span>\n\n              <mat-label *ngIf=\"rootGroupAvailabilities[g.groupId]\">({{( 'questionnaire.expansion.description.available.label' ) | subtranslate:lang }})</mat-label>\n            </ng-template>\n\n            <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form, firstLevel: true }\"></ng-container> -->\n            <heart-questionnaire-section-editor-group\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [firstLevelGroupFormat]=\"firstLevelGroupFormat\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [form]=\"form\"\n              [firstLevel]=\"true\"\n              [group]=\"g\"></heart-questionnaire-section-editor-group>\n          </ng-container>\n        </mat-tab>\n      </mat-tab-group>\n    </ng-container>\n  </div>\n</form>\n\n\n", styles: [".questionnaire{min-width:400px}.questionnaire .question{overflow-wrap:break-word;font-weight:bolder;opacity:.8}.group-box{border-style:solid;border-width:1px;border-color:#00000061;border-radius:4px}.responsive-row{flex-direction:row;align-items:baseline}.title{font-weight:600}@media screen and (max-width: 768px){.gutter{column-gap:0}.responsive-row{flex-direction:column;align-items:stretch;column-gap:0}}mat-radio-button{margin-right:16px!important}.child-required:after{content:\"*\";color:#0009;size:16px;font-weight:400}.questionnaire .mat-mdc-radio-button .mdc-radio{padding:0!important}.expansion-title-highlight{font-style:italic;color:var(--title-highlight-color, orangered)}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i3$2.MatAccordion, selector: "mat-accordion", inputs: ["multi", "hideToggle", "displayMode", "togglePosition"], exportAs: ["matAccordion"] }, { kind: "component", type: i3$2.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["disabled", "expanded", "hideToggle", "togglePosition"], outputs: ["opened", "closed", "expandedChange", "afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }, { kind: "component", type: i3$2.MatExpansionPanelHeader, selector: "mat-expansion-panel-header", inputs: ["tabIndex", "expandedHeight", "collapsedHeight"] }, { kind: "directive", type: i3$2.MatExpansionPanelTitle, selector: "mat-panel-title" }, { kind: "directive", type: i3$2.MatExpansionPanelDescription, selector: "mat-panel-description" }, { kind: "directive", type: i4$1.MatTabLabel, selector: "[mat-tab-label], [matTabLabel]" }, { kind: "component", type: i4$1.MatTab, selector: "mat-tab", inputs: ["disabled"], exportAs: ["matTab"] }, { kind: "component", type: i4$1.MatTabGroup, selector: "mat-tab-group", inputs: ["color", "disableRipple", "fitInkBarToContent", "mat-stretch-tabs"], exportAs: ["matTabGroup"] }, { kind: "directive", type: i3.MatLabel, selector: "mat-label" }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: i10.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i10.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i10.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: QuestionnaireSectionEditorQuestionComponent, selector: "heart-questionnaire-section-editor-question", inputs: ["question", "form", "smallQuestionColumn", "maxValuesForRadio", "forceRadioButton", "appearance", "questionLastChar", "lang", "nestedQuestion"] }, { kind: "component", type: QuestionnaireSectionEditorGroupComponent, selector: "heart-questionnaire-section-editor-group", inputs: ["group", "form", "firstLevel", "firstLevelGroupFormat", "smallQuestionColumn", "maxValuesForRadio", "forceRadioButton", "appearance", "questionLastChar", "lang"] }, { kind: "pipe", type: i1$1.TranslatePipe, name: "translate" }, { kind: "pipe", type: i2$1.SubTranslatePipe, name: "subtranslate" }, { kind: "pipe", type: InstanceofPipe$1, name: "instanceof" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: QuestionnaireSectionEditorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-questionnaire-section-editor', template: "<form *ngIf=\"form\" [formGroup]=\"form\" (ngSubmit)=\"form.valid && onSubmit($event)\" class=\"xcard\">\n  <div class=\"d-flex flex-column questions\">\n\n    <!-- Deafult rendering structure-->\n    <ng-container *ngIf=\"firstLevelGroupFormat == 'box' || firstLevelGroupFormat == 'none' || firstLevelGroupFormat == 'card'\">\n      <!-- per ogni domanda -->\n      <div *ngFor=\"let item of questionnaireResponse?.questionnaire?.items\">\n\n        <ng-container *ngIf=\"item | instanceof: Question as q\">\n          <heart-questionnaire-section-editor-question\n            [questionLastChar]=\"questionLastChar\"\n            [smallQuestionColumn]=\"smallQuestionColumn\"\n            [maxValuesForRadio]=\"maxValuesForRadio\"\n            [forceRadioButton]=\"forceRadioButton\"\n            [appearance]=\"appearance\"\n            [lang]=\"lang\"\n            [nestedQuestion]=\"false\"\n            [form]=\"form\"\n            [question]=\"q\"></heart-questionnaire-section-editor-question>\n        </ng-container>\n\n        <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n          <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form, firstLevel: true }\"></ng-container> -->\n          <heart-questionnaire-section-editor-group\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [firstLevelGroupFormat]=\"firstLevelGroupFormat\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [form]=\"form\"\n              [firstLevel]=\"true\"\n              [group]=\"g\"></heart-questionnaire-section-editor-group>\n        </ng-container>\n\n      </div>\n    </ng-container>\n\n    <!-- Render the first level question grups as tabs -->\n    <ng-container *ngIf=\"firstLevelGroupFormat == 'expansion'\">\n      <mat-accordion>\n        <!-- per ogni domanda -->\n        <!--IGNORES questions without a group-->\n        <!--ng-container *ngIf=\"item | instanceof: Question as q\">\n          <ng-container *ngTemplateOutlet=\"editquestion; context: { $implicit: q, form: form }\"></ng-container>\n          <heart-questionnaire-section-editor-question\n            [questionLastChar]=\"questionLastChar\"\n            [smallQuestionColumn]=\"smallQuestionColumn\"\n            [maxValuesForRadio]=\"maxValuesForRadio\"\n            [forceRadioButton]=\"forceRadioButton\"\n            [appearance]=\"appearance\"\n            [lang]=\"lang\"\n            [nestedQuestion]=\"false\"\n            [form]=\"form\"\n            [question]=\"q\"></heart-questionnaire-section-editor-question>\n        </ng-container-->\n\n        <ng-container *ngFor=\"let item of questionnaireResponse?.questionnaire?.items\">\n          <mat-expansion-panel *ngIf=\"item | instanceof: QuestionGroup as g\">\n            <mat-expansion-panel-header>\n              <mat-panel-title class=\"title\" [ngClass]=\"{ 'expansion-title-highlight': form.get(g.groupId).dirty}\">\n                <mat-icon *ngIf=\"form.get(g.groupId).dirty && !form.get(g.groupId).valid\" color=\"warn\">warning</mat-icon>\n                <span *ngIf=\"g.showSubStar && !g.required\"class=\"child-required\" ></span>\n                <span *ngIf=\"g.required\">*&nbsp;</span>{{ g?.text | translate }}\n                <span *ngIf=\"form.get(g.groupId).dirty\" color=\"accent\">&nbsp;({{( 'questionnaire.expansion.title.edited.label' ) | subtranslate:lang }})</span>\n              </mat-panel-title>\n              <mat-panel-description>\n                <mat-label *ngIf=\"rootGroupAvailabilities[g.groupId]\">{{( 'questionnaire.expansion.description.available.label' ) | subtranslate:lang }}</mat-label>\n              </mat-panel-description>\n            </mat-expansion-panel-header>\n\n            <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form, firstLevel: true }\"></ng-container> -->\n            <heart-questionnaire-section-editor-group\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [firstLevelGroupFormat]=\"firstLevelGroupFormat\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [form]=\"form\"\n              [firstLevel]=\"true\"\n              [group]=\"g\"></heart-questionnaire-section-editor-group>\n          </mat-expansion-panel>\n        </ng-container>\n      </mat-accordion>\n    </ng-container>\n\n    <!-- Render the first level question grups as tabs -->\n    <ng-container *ngIf=\"firstLevelGroupFormat == 'tab'\">\n      <mat-tab-group mat-stretch-tabs=\"false\" mat-align-tabs=\"start\">\n        <!-- per ogni domanda -->\n        <mat-tab *ngFor=\"let item of questionnaireResponse?.questionnaire?.items\">\n          <!--IGNORES questions without a group-->\n\n          <!--ng-container *ngIf=\"item | instanceof: Question as q\">\n            <ng-template mat-tab-label>{{ item?.name | translate }}</ng-template>\n\n\n            <heart-questionnaire-section-editor-question\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [nestedQuestion]=\"false\"\n              [form]=\"form\"\n              [question]=\"q\"></heart-questionnaire-section-editor-question>\n          </ng-container-->\n\n          <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n            <ng-template mat-tab-label>\n              <span *ngIf=\"g.showSubStar && !g.required\"class=\"child-required\" ></span>\n              <mat-icon *ngIf=\"form.get(g.groupId).dirty && !form.get(g.groupId).valid\" color=\"warn\">warning</mat-icon>\n              {{ g?.text | translate }}\n              <span *ngIf=\"form.get(g.groupId).dirty\" color=\"accent\">&nbsp;({{( 'questionnaire.expansion.title.edited.label' ) | subtranslate:lang }})</span>\n\n              <mat-label *ngIf=\"rootGroupAvailabilities[g.groupId]\">({{( 'questionnaire.expansion.description.available.label' ) | subtranslate:lang }})</mat-label>\n            </ng-template>\n\n            <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form, firstLevel: true }\"></ng-container> -->\n            <heart-questionnaire-section-editor-group\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [firstLevelGroupFormat]=\"firstLevelGroupFormat\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [form]=\"form\"\n              [firstLevel]=\"true\"\n              [group]=\"g\"></heart-questionnaire-section-editor-group>\n          </ng-container>\n        </mat-tab>\n      </mat-tab-group>\n    </ng-container>\n  </div>\n</form>\n\n\n", styles: [".questionnaire{min-width:400px}.questionnaire .question{overflow-wrap:break-word;font-weight:bolder;opacity:.8}.group-box{border-style:solid;border-width:1px;border-color:#00000061;border-radius:4px}.responsive-row{flex-direction:row;align-items:baseline}.title{font-weight:600}@media screen and (max-width: 768px){.gutter{column-gap:0}.responsive-row{flex-direction:column;align-items:stretch;column-gap:0}}mat-radio-button{margin-right:16px!important}.child-required:after{content:\"*\";color:#0009;size:16px;font-weight:400}.questionnaire .mat-mdc-radio-button .mdc-radio{padding:0!important}.expansion-title-highlight{font-style:italic;color:var(--title-highlight-color, orangered)}\n"] }]
        }], ctorParameters: function () { return [{ type: QuestionSectionEditorService }]; }, propDecorators: { questionnaireResponse: [{
                type: Input
            }], questionnaireResponseChange: [{
                type: Output
            }], firstLevelGroupFormat: [{
                type: Input
            }], appearance: [{
                type: Input
            }], questionLastChar: [{
                type: Input
            }], lang: [{
                type: Input
            }], smallQuestionColumn: [{
                type: Input
            }], maxValuesForRadio: [{
                type: Input
            }], forceRadioButton: [{
                type: Input
            }], validate: [{
                type: Output
            }] } });

class QuestionnaireSectionViewerComponent {
    constructor(_translateService) {
        this._translateService = _translateService;
        this.appearance = 'outline';
        this.smallQuestionColumn = false; // manage the width of the question column and the rendering of the overall questionnaire
        this.emptyAnswerPlaceholder = '-'; // chars used for empty answers
        this.questionLastChar = '?'; // last char to be added to questions
        this.types = QuestionType;
        this.Question = Question;
        this.QuestionGroup = QuestionGroup;
        this.AnswerGroup = AnswerGroup;
    }
    ngOnInit() { }
    findAnswerByQuestion(answers, question) {
        if (!question) {
            return undefined;
        }
        return answers?.filter((a) => a instanceof Answer).find((a) => a.questionId == question.questionId);
    }
    findAnswerGroupByQuestionGroup(answers, questionGroup) {
        if (!questionGroup) {
            return undefined;
        }
        const ags = answers?.filter((a) => a instanceof AnswerGroup).filter((a) => a.groupId == questionGroup.groupId);
        return questionGroup.repeated ? ags : ags.pop();
    }
    extractAnswerValue(answer, question) {
        // TODO: gestire le risposte come Choice[]
        if (answer && answer.value != undefined) {
            if (Array.isArray(question.permittedAnswers) && question.permittedAnswers?.length > 0) {
                // qui è per forza array di Choice, il connector si prende in carico la trasformazione ValueSetUrl -> Choice[]
                if (Array.isArray(answer.value)) {
                    const answArray = answer.value;
                    const ret = [];
                    question.permittedAnswers.forEach((pa) => {
                        if (pa.value instanceof CodedValue) {
                            if (answArray.some((a) => pa.value.code == a.code)) {
                                const val = this._translateService.instant(pa.label);
                                ret.push(val);
                            }
                        }
                    });
                    return ret.length > 0 ? ret.join(', ') : this.emptyAnswerPlaceholder;
                }
                else {
                    const pa = question.permittedAnswers.find((pa) => {
                        if (pa.value instanceof CodedValue) {
                            return pa.value.code == answer.value.code;
                        }
                        else {
                            return pa.value == answer.value;
                        }
                    });
                    return pa?.label ?? this.emptyAnswerPlaceholder;
                }
            }
            else if (answer.value instanceof CodedValue) {
                return answer.value.display;
            }
            else {
                return answer.value;
            }
        }
        return this.emptyAnswerPlaceholder;
    }
    extractTextualAnswerValue(answer, question) {
        const value = this.extractAnswerValue(answer, question)?.toString();
        if (value) {
            if (typeof value == 'string' && value.length > 60) {
                return value.substring(0, 60) + '...';
            }
            else {
                return value + '';
            }
        }
        else {
            return this.emptyAnswerPlaceholder;
        }
    }
    extractDateAnswerValue(answer, question) {
        const value = this.extractAnswerValue(answer, question);
        if (value && value.toString() != this.emptyAnswerPlaceholder) {
            return value;
        }
        else {
            return '';
        }
    }
}
QuestionnaireSectionViewerComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: QuestionnaireSectionViewerComponent, deps: [{ token: i1$1.TranslateService }], target: i0.ɵɵFactoryTarget.Component });
QuestionnaireSectionViewerComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: QuestionnaireSectionViewerComponent, selector: "heart-questionnaire-section-viewer", inputs: { questionnaireResponse: "questionnaireResponse", appearance: "appearance", smallQuestionColumn: "smallQuestionColumn", emptyAnswerPlaceholder: "emptyAnswerPlaceholder", questionLastChar: "questionLastChar", lang: "lang" }, ngImport: i0, template: "<div class=\"d-flex flex-column\">\n  <div *ngFor=\"let item of questionnaireResponse?.questionnaire?.items; let i = index;\"\n    class=\"d-flex responsive-row display-mode-line-height\">\n    <ng-container *ngIf=\"item | instanceof: Question as q\">\n      <ng-container\n        *ngTemplateOutlet=\"viewquestion; context: { $implicit: q, answer: findAnswerByQuestion(questionnaireResponse?.answers, q), nested: false }\"></ng-container>\n    </ng-container>\n\n    <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n      <ng-container\n        *ngTemplateOutlet=\"viewgroup; context: { $implicit: g, answersGroup: findAnswerGroupByQuestionGroup(questionnaireResponse?.answers, g) }\"></ng-container>\n    </ng-container>\n  </div>\n</div>\n\n<ng-template #viewquestion let-question let-answer=\"answer\" let-nested=\"nested\">\n  <!-- domanda -->\n  <ng-container *ngIf=\"!question.readOnly && (question.type !== types.display)\">\n    <div *ngIf=\"!nested\" class=\"question\"\n      [ngClass]=\"{'emphasized-question' : (extractAnswerValue(answer, question) != emptyAnswerPlaceholder), 'flex-basis-50' : !smallQuestionColumn, 'flex-basis-25' : smallQuestionColumn }\">\n      <span *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>\n      {{ question.text | translate }}{{questionLastChar}}\n    </div>\n\n    <div class=\"answer flex-1 d-flex\"\n      [ngClass]=\"{'flex-column': !nested, 'flex-row mat-caption nested-question mt-2': nested}\">\n      <label *ngIf=\"nested\" class=\"question\">\n        <span *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>\n        {{ question.text | translate }}{{questionLastChar}}:&nbsp;\n      </label>\n\n      <!-- risposta multipla chiusa -->\n      <ng-container *ngIf=\"(question.permittedAnswers?.length > 0) else openAnswer\">{{ extractAnswerValue(answer,\n        question)?.toString() | translate }}</ng-container>\n\n      <!-- risposta aperta tipizzata -->\n      <ng-template #openAnswer>\n        <!-- risposta di tipo boolean -->\n        <label *ngIf=\"(question.type === types.boolean)\">{{ ( 'questionnaire.boolean.' + extractAnswerValue(answer,\n          question)?.toString() ) | translate }}</label>\n        <!-- risposta di tipo numerico -->\n        <label *ngIf=\"(question.type === types.integer) || (question.type === types.decimal)\">{{\n          extractAnswerValue(answer, question) }}</label>\n        <!-- risposta di tipo testuale (stringa corta) -->\n        <label *ngIf=\"(question.type === types.string)\">{{ extractTextualAnswerValue(answer, question) }}</label>\n        <!-- risposta di tipo testuale (stringa lunga)-->\n        <label *ngIf=\"(question.type === types.text)\">{{ extractAnswerValue(answer, question) }}</label>\n        <!-- risposta di tipo CodedValue -->\n        <label *ngIf=\"(question.type === types.CodedValue)\">{{ extractTextualAnswerValue(answer, question) }}</label>\n        <!-- risposta di tipo data -->\n        <label *ngIf=\"(question.type === types.date)\">{{ extractDateAnswerValue(answer, question) | date }}</label>\n      </ng-template>\n\n      <ng-container *ngFor=\"let item of question.items\">\n        <ng-container\n          *ngTemplateOutlet=\"viewquestion; context: { $implicit: item, answer: findAnswerByQuestion(answer?.answers, item), nested: true }\"></ng-container>\n      </ng-container>\n    </div>\n  </ng-container>\n\n  <!-- domanda di tipo 'display' -->\n  <span *ngIf=\"(question.type === types.display)\" class=\"mat-caption mb-2\">{{ question.text | translate }}</span>\n</ng-template>\n\n<ng-template #viewgroup let-group let-answersGroup=\"answersGroup\">\n  <div class=\"d-flex flex-column flex-1 xcard p-3 mt-2 mb-2 group-box\">\n    <h3 class=\"mat-mdc-card-subtitle\">{{ group.name | translate }}</h3>\n\n    <ng-container *ngIf=\"group.repeated\">\n      <!-- here answersGroup MUST be an array of repeteable items -->\n      <div *ngFor=\"let repeteableAnswersGroup of answersGroup?.answers\" class=\"group-box p-3 mb-2 mt-1\">\n        <div *ngFor=\"let item of group?.items; let i = index;\" class=\"d-flex responsive-row display-mode-line-height\">\n          <ng-container *ngIf=\"item | instanceof: Question as q\">\n            <ng-container\n              *ngTemplateOutlet=\"viewquestion; context: { $implicit: q, answer: findAnswerByQuestion(repeteableAnswersGroup?.answers, item), nested: false }\"></ng-container>\n          </ng-container>\n\n          <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n            <ng-container\n              *ngTemplateOutlet=\"viewgroup; context: { $implicit: g, answersGroup: findAnswerGroupByQuestionGroup(repeteableAnswersGroup?.answers, g) }\"></ng-container>\n          </ng-container>\n        </div>\n      </div>\n    </ng-container>\n\n    <ng-container *ngIf=\"!group.repeated\">\n      <div *ngFor=\"let item of group?.items; let i = index;\" class=\"d-flex responsive-row display-mode-line-height\">\n        <ng-container *ngIf=\"item | instanceof: Question as q\">\n          <ng-container\n            *ngTemplateOutlet=\"viewquestion; context: { $implicit: q, answer: findAnswerByQuestion(answersGroup?.answers, item), nested: false }\"></ng-container>\n        </ng-container>\n\n        <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n          <ng-container\n            *ngTemplateOutlet=\"viewgroup; context: { $implicit: g, answersGroup: findAnswerGroupByQuestionGroup(answersGroup?.answers, g) }\"></ng-container>\n        </ng-container>\n      </div>\n    </ng-container>\n  </div>\n</ng-template>", styles: [".questionnaire{min-width:400px}.questionnaire .question{overflow-wrap:break-word;font-weight:bolder;opacity:.8}.group-box{border-style:solid;border-width:1px;border-color:#00000061;border-radius:4px}.responsive-row{flex-direction:row;align-items:baseline}.title{font-weight:600}@media screen and (max-width: 768px){.gutter{column-gap:0}.responsive-row{flex-direction:column;align-items:stretch;column-gap:0}}mat-radio-button{margin-right:16px!important}.child-required:after{content:\"*\";color:#0009;size:16px;font-weight:400}.questionnaire .emphasized-question{opacity:1;font-weight:700!important}.questionnaire .display-mode-line-height{margin-bottom:12px}.nested-question{font-style:italic}.nested-question .question{font-weight:700}@media screen and (max-width: 768px){.questionnaire .display-mode-line-height{margin-bottom:20px}}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: i2.DatePipe, name: "date" }, { kind: "pipe", type: i1$1.TranslatePipe, name: "translate" }, { kind: "pipe", type: InstanceofPipe$1, name: "instanceof" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: QuestionnaireSectionViewerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-questionnaire-section-viewer', template: "<div class=\"d-flex flex-column\">\n  <div *ngFor=\"let item of questionnaireResponse?.questionnaire?.items; let i = index;\"\n    class=\"d-flex responsive-row display-mode-line-height\">\n    <ng-container *ngIf=\"item | instanceof: Question as q\">\n      <ng-container\n        *ngTemplateOutlet=\"viewquestion; context: { $implicit: q, answer: findAnswerByQuestion(questionnaireResponse?.answers, q), nested: false }\"></ng-container>\n    </ng-container>\n\n    <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n      <ng-container\n        *ngTemplateOutlet=\"viewgroup; context: { $implicit: g, answersGroup: findAnswerGroupByQuestionGroup(questionnaireResponse?.answers, g) }\"></ng-container>\n    </ng-container>\n  </div>\n</div>\n\n<ng-template #viewquestion let-question let-answer=\"answer\" let-nested=\"nested\">\n  <!-- domanda -->\n  <ng-container *ngIf=\"!question.readOnly && (question.type !== types.display)\">\n    <div *ngIf=\"!nested\" class=\"question\"\n      [ngClass]=\"{'emphasized-question' : (extractAnswerValue(answer, question) != emptyAnswerPlaceholder), 'flex-basis-50' : !smallQuestionColumn, 'flex-basis-25' : smallQuestionColumn }\">\n      <span *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>\n      {{ question.text | translate }}{{questionLastChar}}\n    </div>\n\n    <div class=\"answer flex-1 d-flex\"\n      [ngClass]=\"{'flex-column': !nested, 'flex-row mat-caption nested-question mt-2': nested}\">\n      <label *ngIf=\"nested\" class=\"question\">\n        <span *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>\n        {{ question.text | translate }}{{questionLastChar}}:&nbsp;\n      </label>\n\n      <!-- risposta multipla chiusa -->\n      <ng-container *ngIf=\"(question.permittedAnswers?.length > 0) else openAnswer\">{{ extractAnswerValue(answer,\n        question)?.toString() | translate }}</ng-container>\n\n      <!-- risposta aperta tipizzata -->\n      <ng-template #openAnswer>\n        <!-- risposta di tipo boolean -->\n        <label *ngIf=\"(question.type === types.boolean)\">{{ ( 'questionnaire.boolean.' + extractAnswerValue(answer,\n          question)?.toString() ) | translate }}</label>\n        <!-- risposta di tipo numerico -->\n        <label *ngIf=\"(question.type === types.integer) || (question.type === types.decimal)\">{{\n          extractAnswerValue(answer, question) }}</label>\n        <!-- risposta di tipo testuale (stringa corta) -->\n        <label *ngIf=\"(question.type === types.string)\">{{ extractTextualAnswerValue(answer, question) }}</label>\n        <!-- risposta di tipo testuale (stringa lunga)-->\n        <label *ngIf=\"(question.type === types.text)\">{{ extractAnswerValue(answer, question) }}</label>\n        <!-- risposta di tipo CodedValue -->\n        <label *ngIf=\"(question.type === types.CodedValue)\">{{ extractTextualAnswerValue(answer, question) }}</label>\n        <!-- risposta di tipo data -->\n        <label *ngIf=\"(question.type === types.date)\">{{ extractDateAnswerValue(answer, question) | date }}</label>\n      </ng-template>\n\n      <ng-container *ngFor=\"let item of question.items\">\n        <ng-container\n          *ngTemplateOutlet=\"viewquestion; context: { $implicit: item, answer: findAnswerByQuestion(answer?.answers, item), nested: true }\"></ng-container>\n      </ng-container>\n    </div>\n  </ng-container>\n\n  <!-- domanda di tipo 'display' -->\n  <span *ngIf=\"(question.type === types.display)\" class=\"mat-caption mb-2\">{{ question.text | translate }}</span>\n</ng-template>\n\n<ng-template #viewgroup let-group let-answersGroup=\"answersGroup\">\n  <div class=\"d-flex flex-column flex-1 xcard p-3 mt-2 mb-2 group-box\">\n    <h3 class=\"mat-mdc-card-subtitle\">{{ group.name | translate }}</h3>\n\n    <ng-container *ngIf=\"group.repeated\">\n      <!-- here answersGroup MUST be an array of repeteable items -->\n      <div *ngFor=\"let repeteableAnswersGroup of answersGroup?.answers\" class=\"group-box p-3 mb-2 mt-1\">\n        <div *ngFor=\"let item of group?.items; let i = index;\" class=\"d-flex responsive-row display-mode-line-height\">\n          <ng-container *ngIf=\"item | instanceof: Question as q\">\n            <ng-container\n              *ngTemplateOutlet=\"viewquestion; context: { $implicit: q, answer: findAnswerByQuestion(repeteableAnswersGroup?.answers, item), nested: false }\"></ng-container>\n          </ng-container>\n\n          <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n            <ng-container\n              *ngTemplateOutlet=\"viewgroup; context: { $implicit: g, answersGroup: findAnswerGroupByQuestionGroup(repeteableAnswersGroup?.answers, g) }\"></ng-container>\n          </ng-container>\n        </div>\n      </div>\n    </ng-container>\n\n    <ng-container *ngIf=\"!group.repeated\">\n      <div *ngFor=\"let item of group?.items; let i = index;\" class=\"d-flex responsive-row display-mode-line-height\">\n        <ng-container *ngIf=\"item | instanceof: Question as q\">\n          <ng-container\n            *ngTemplateOutlet=\"viewquestion; context: { $implicit: q, answer: findAnswerByQuestion(answersGroup?.answers, item), nested: false }\"></ng-container>\n        </ng-container>\n\n        <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n          <ng-container\n            *ngTemplateOutlet=\"viewgroup; context: { $implicit: g, answersGroup: findAnswerGroupByQuestionGroup(answersGroup?.answers, g) }\"></ng-container>\n        </ng-container>\n      </div>\n    </ng-container>\n  </div>\n</ng-template>", styles: [".questionnaire{min-width:400px}.questionnaire .question{overflow-wrap:break-word;font-weight:bolder;opacity:.8}.group-box{border-style:solid;border-width:1px;border-color:#00000061;border-radius:4px}.responsive-row{flex-direction:row;align-items:baseline}.title{font-weight:600}@media screen and (max-width: 768px){.gutter{column-gap:0}.responsive-row{flex-direction:column;align-items:stretch;column-gap:0}}mat-radio-button{margin-right:16px!important}.child-required:after{content:\"*\";color:#0009;size:16px;font-weight:400}.questionnaire .emphasized-question{opacity:1;font-weight:700!important}.questionnaire .display-mode-line-height{margin-bottom:12px}.nested-question{font-style:italic}.nested-question .question{font-weight:700}@media screen and (max-width: 768px){.questionnaire .display-mode-line-height{margin-bottom:20px}}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$1.TranslateService }]; }, propDecorators: { questionnaireResponse: [{
                type: Input
            }], appearance: [{
                type: Input
            }], smallQuestionColumn: [{
                type: Input
            }], emptyAnswerPlaceholder: [{
                type: Input
            }], questionLastChar: [{
                type: Input
            }], lang: [{
                type: Input
            }] } });

class QuestionnaireSectionComponent {
    constructor(_dateAdapter, _subTranslateService) {
        this._dateAdapter = _dateAdapter;
        this._subTranslateService = _subTranslateService;
        this.questionnaireResponseChange = new EventEmitter();
        /**
         * ASPECT SETTINGS
         */
        this.appearance = 'outline';
        // last char to be added to questions
        this.questionLastChar = '?';
        // if false hides the main header and the questionnaire title
        this.showHeader = true;
        // TODO (only box is working)
        this.firstLevelGroupFormat = 'box';
        /**
         * OPERATING MODE SETTINGS
         */
        // if the questionnaire cannot be modified (in this case the action buttons are not rendered)
        this.readOnly = false;
        // if the the action buttons have to be rendered (if 'false' use 'editMode' and/or 'questionnaireResponse' with bidirectional binding)
        this.enableActionButtons = true;
        // determine the mode that should be used when showing for the first time
        this.editMode = false;
        // notify that the component is in edit mode ('true') or view mode ('false')
        this.onModeChange = new EventEmitter();
        /**
         * EDIT FORM RENDERING SETTINGS
         */
        // render options only as Radio Button
        this.forceRadioButton = false;
        // [GUIDELINE] max value for switching options from Radio to Select
        this.maxValuesForRadio = 5;
        // manage the width of the question column and the rendering of the overall questionnaire
        this.smallQuestionColumn = false;
        // chars used for empty answers
        this.emptyAnswerPlaceholder = '-';
        this.onCancel = new EventEmitter();
        // @deprecated: left for retrocompatibility. use bidirectional binding (i.e. [(questionnaireResponse)])
        this.onSave = new EventEmitter();
        this.editorFormStatus = undefined;
        this.types = QuestionType;
        this.Question = Question;
        this.QuestionGroup = QuestionGroup;
        this.AnswerGroup = AnswerGroup;
        this.createDictionary();
    }
    ngOnChanges(changes) {
        const _lang = changes['lang'];
        if (_lang) {
            if (_lang.currentValue != _lang.previousValue) {
                const locale = this._subTranslateService.getFnsLocale(this.lang);
                if (locale)
                    this._dateAdapter.setLocale(locale);
            }
        }
    }
    // approccio per unificare il servizio di traduzione
    createDictionary() {
        const dictionary = new Map();
        dictionary.set('en', en$1);
        dictionary.set('it', it$1);
        this._subTranslateService.setLanguages(dictionary);
    }
    onCancelEdit() {
        this.setDisplayModeOn();
        // invoca il metodo fornito per notificare il salvataggio dei dati
        this.onCancel?.emit();
    }
    /**
     * Attiva la modalità DISPLAY
     */
    setDisplayModeOn() {
        this.editMode = false;
        this.onModeChange.emit(this.editMode);
    }
    /**
     * Attiva la modalità EDIT ed imposta nei campi del form
     * il valore della risposta precedentemente digitato (qualora vi sia).
     * Nel caso non sia mai stato inserito un valore, resetta il campo.
     */
    setEditModeOn() {
        // reset
        this.editorFormStatus = undefined;
        this.editMode = true;
        this.onModeChange.emit(this.editMode);
    }
    appendAnswerGroups(answersGroups, path) {
        this.editorComponent?.appendAnswerGroups(answersGroups, path);
    }
}
QuestionnaireSectionComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: QuestionnaireSectionComponent, deps: [{ token: i1.DateAdapter }, { token: i2$1.SubTranslateService }], target: i0.ɵɵFactoryTarget.Component });
QuestionnaireSectionComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: QuestionnaireSectionComponent, selector: "heart-questionnaire-section", inputs: { questionnaireResponse: "questionnaireResponse", appearance: "appearance", lang: "lang", questionLastChar: "questionLastChar", headerBackgroundColor: "headerBackgroundColor", showHeader: "showHeader", firstLevelGroupFormat: "firstLevelGroupFormat", readOnly: "readOnly", enableActionButtons: "enableActionButtons", editMode: "editMode", forceRadioButton: "forceRadioButton", maxValuesForRadio: "maxValuesForRadio", smallQuestionColumn: "smallQuestionColumn", emptyAnswerPlaceholder: "emptyAnswerPlaceholder" }, outputs: { questionnaireResponseChange: "questionnaireResponseChange", onModeChange: "onModeChange", onCancel: "onCancel", onSave: "onSave" }, viewQueries: [{ propertyName: "editorComponent", first: true, predicate: QuestionnaireSectionEditorComponent, descendants: true }], usesOnChanges: true, ngImport: i0, template: "<!-- ---------------------------------------\n  -\n  - Container in modalit\u00E0 DISPLAY\n  -\n  ----------------------------------------->\n\n<div class=\"container\" *ngIf=\"editMode === false; else input\">\n  <mat-card class=\"questionnaire\">\n    <mat-card-header *ngIf=\"showHeader\" [ngStyle]=\"{'background-color' : headerBackgroundColor}\">\n      <mat-card-title>{{ questionnaireResponse?.questionnaire?.name | translate }}</mat-card-title>\n    </mat-card-header>\n\n    <mat-card-content>\n\n      <heart-questionnaire-section-viewer\n        [questionnaireResponse]=\"questionnaireResponse\"\n        [lang]=\"lang\"\n        [appearance]=\"appearance\"\n        [questionLastChar]=\"questionLastChar\"\n        [emptyAnswerPlaceholder]=\"emptyAnswerPlaceholder\"\n        [smallQuestionColumn]=\"smallQuestionColumn\"></heart-questionnaire-section-viewer>\n\n    </mat-card-content>\n\n    <mat-card-actions align=\"end\" *ngIf=\"enableActionButtons && !readOnly\">\n      <button *ngIf=\"questionnaireResponse.answers == undefined || questionnaireResponse.answers.length == 0\" mat-raised-button color=\"accent\" (click)=\"setEditModeOn()\">{{\"questionnaire.button.compile.label\" | subtranslate:lang }}</button>\n      <button *ngIf=\"questionnaireResponse.answers && questionnaireResponse.answers.length > 0\" mat-raised-button color=\"accent\" (click)=\"setEditModeOn()\">{{\"questionnaire.button.edit.label\" | subtranslate:lang }}</button>\n    </mat-card-actions>\n  </mat-card>\n</div>\n\n\n<!-- ---------------------------------------\n  -\n  - Container in modalit\u00E0 EDIT\n  -\n  ----------------------------------------->\n<ng-template #input>\n  <div class=\"container\">\n    <mat-card class=\"questionnaire\">\n      <mat-card-header *ngIf=\"showHeader\" class=\"bg-primary text-white\">\n        <mat-card-title>{{ questionnaireResponse?.questionnaire?.name | translate }}</mat-card-title>\n      </mat-card-header>\n\n      <mat-card-content>\n        <p>{{ 'questionnaire.star.explanation.text' | subtranslate:lang}}</p>\n        <!-- (formChange)=\"editorFormReady = $event != undefined\" -->\n        <heart-questionnaire-section-editor\n          #editor\n          [(questionnaireResponse)]=\"questionnaireResponse\"\n          (questionnaireResponseChange)=\"onSave.emit($event)\"\n          [lang]=\"lang\"\n          [firstLevelGroupFormat]=\"firstLevelGroupFormat\"\n          [appearance]=\"appearance\"\n          [forceRadioButton]=\"forceRadioButton\"\n          [maxValuesForRadio]=\"maxValuesForRadio\"\n          [questionLastChar]=\"questionLastChar\"\n          [smallQuestionColumn]=\"smallQuestionColumn\"\n          (validate)=\"editorFormStatus = $event\"></heart-questionnaire-section-editor>\n\n      </mat-card-content>\n\n      <mat-card-actions align=\"end\" *ngIf=\"enableActionButtons && !readOnly\">\n        <!-- Disabled if the QuestionnaireResponse has not been saved, yet (i.e. id == undefined) -->\n        <button mat-raised-button color=\"basic\" (click)=\"onCancelEdit()\" [disabled]=\"questionnaireResponse?.id == undefined\" style=\"margin-right:6px\">{{\"questionnaire.button.cancel.label\" | subtranslate:lang}}</button>\n\n        <!-- <button mat-raised-button #save (click)=\"editor.onSubmit($event)\" color=\"accent\" [disabled]=\"editorFormStatus != 'VALID'\">{{\"questionnaire.button.save.label\" | subtranslate:lang}}</button> -->\n        <button mat-raised-button #save heartDebouncedButton (debounceClick)=\"editor.onSubmit($event)\" color=\"accent\" [disabled]=\"editorFormStatus != 'VALID'\">{{\"questionnaire.button.save.label\" | subtranslate:lang}}</button>\n      </mat-card-actions>\n    </mat-card>\n  </div>\n</ng-template>\n", styles: [""], dependencies: [{ kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: i4$2.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "directive", type: i4$2.MatCardActions, selector: "mat-card-actions", inputs: ["align"], exportAs: ["matCardActions"] }, { kind: "directive", type: i4$2.MatCardContent, selector: "mat-card-content" }, { kind: "component", type: i4$2.MatCardHeader, selector: "mat-card-header" }, { kind: "directive", type: i4$2.MatCardTitle, selector: "mat-card-title, [mat-card-title], [matCardTitle]" }, { kind: "component", type: i5$1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "directive", type: i2$1.DebouncedButtonDirective, selector: "[heartDebouncedButton]", inputs: ["debounceClickTime"], outputs: ["debounceClick"] }, { kind: "component", type: QuestionnaireSectionViewerComponent, selector: "heart-questionnaire-section-viewer", inputs: ["questionnaireResponse", "appearance", "smallQuestionColumn", "emptyAnswerPlaceholder", "questionLastChar", "lang"] }, { kind: "component", type: QuestionnaireSectionEditorComponent, selector: "heart-questionnaire-section-editor", inputs: ["questionnaireResponse", "firstLevelGroupFormat", "appearance", "questionLastChar", "lang", "smallQuestionColumn", "maxValuesForRadio", "forceRadioButton"], outputs: ["questionnaireResponseChange", "validate"] }, { kind: "pipe", type: i1$1.TranslatePipe, name: "translate" }, { kind: "pipe", type: i2$1.SubTranslatePipe, name: "subtranslate" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: QuestionnaireSectionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-questionnaire-section', template: "<!-- ---------------------------------------\n  -\n  - Container in modalit\u00E0 DISPLAY\n  -\n  ----------------------------------------->\n\n<div class=\"container\" *ngIf=\"editMode === false; else input\">\n  <mat-card class=\"questionnaire\">\n    <mat-card-header *ngIf=\"showHeader\" [ngStyle]=\"{'background-color' : headerBackgroundColor}\">\n      <mat-card-title>{{ questionnaireResponse?.questionnaire?.name | translate }}</mat-card-title>\n    </mat-card-header>\n\n    <mat-card-content>\n\n      <heart-questionnaire-section-viewer\n        [questionnaireResponse]=\"questionnaireResponse\"\n        [lang]=\"lang\"\n        [appearance]=\"appearance\"\n        [questionLastChar]=\"questionLastChar\"\n        [emptyAnswerPlaceholder]=\"emptyAnswerPlaceholder\"\n        [smallQuestionColumn]=\"smallQuestionColumn\"></heart-questionnaire-section-viewer>\n\n    </mat-card-content>\n\n    <mat-card-actions align=\"end\" *ngIf=\"enableActionButtons && !readOnly\">\n      <button *ngIf=\"questionnaireResponse.answers == undefined || questionnaireResponse.answers.length == 0\" mat-raised-button color=\"accent\" (click)=\"setEditModeOn()\">{{\"questionnaire.button.compile.label\" | subtranslate:lang }}</button>\n      <button *ngIf=\"questionnaireResponse.answers && questionnaireResponse.answers.length > 0\" mat-raised-button color=\"accent\" (click)=\"setEditModeOn()\">{{\"questionnaire.button.edit.label\" | subtranslate:lang }}</button>\n    </mat-card-actions>\n  </mat-card>\n</div>\n\n\n<!-- ---------------------------------------\n  -\n  - Container in modalit\u00E0 EDIT\n  -\n  ----------------------------------------->\n<ng-template #input>\n  <div class=\"container\">\n    <mat-card class=\"questionnaire\">\n      <mat-card-header *ngIf=\"showHeader\" class=\"bg-primary text-white\">\n        <mat-card-title>{{ questionnaireResponse?.questionnaire?.name | translate }}</mat-card-title>\n      </mat-card-header>\n\n      <mat-card-content>\n        <p>{{ 'questionnaire.star.explanation.text' | subtranslate:lang}}</p>\n        <!-- (formChange)=\"editorFormReady = $event != undefined\" -->\n        <heart-questionnaire-section-editor\n          #editor\n          [(questionnaireResponse)]=\"questionnaireResponse\"\n          (questionnaireResponseChange)=\"onSave.emit($event)\"\n          [lang]=\"lang\"\n          [firstLevelGroupFormat]=\"firstLevelGroupFormat\"\n          [appearance]=\"appearance\"\n          [forceRadioButton]=\"forceRadioButton\"\n          [maxValuesForRadio]=\"maxValuesForRadio\"\n          [questionLastChar]=\"questionLastChar\"\n          [smallQuestionColumn]=\"smallQuestionColumn\"\n          (validate)=\"editorFormStatus = $event\"></heart-questionnaire-section-editor>\n\n      </mat-card-content>\n\n      <mat-card-actions align=\"end\" *ngIf=\"enableActionButtons && !readOnly\">\n        <!-- Disabled if the QuestionnaireResponse has not been saved, yet (i.e. id == undefined) -->\n        <button mat-raised-button color=\"basic\" (click)=\"onCancelEdit()\" [disabled]=\"questionnaireResponse?.id == undefined\" style=\"margin-right:6px\">{{\"questionnaire.button.cancel.label\" | subtranslate:lang}}</button>\n\n        <!-- <button mat-raised-button #save (click)=\"editor.onSubmit($event)\" color=\"accent\" [disabled]=\"editorFormStatus != 'VALID'\">{{\"questionnaire.button.save.label\" | subtranslate:lang}}</button> -->\n        <button mat-raised-button #save heartDebouncedButton (debounceClick)=\"editor.onSubmit($event)\" color=\"accent\" [disabled]=\"editorFormStatus != 'VALID'\">{{\"questionnaire.button.save.label\" | subtranslate:lang}}</button>\n      </mat-card-actions>\n    </mat-card>\n  </div>\n</ng-template>\n" }]
        }], ctorParameters: function () { return [{ type: i1.DateAdapter }, { type: i2$1.SubTranslateService }]; }, propDecorators: { questionnaireResponse: [{
                type: Input
            }], questionnaireResponseChange: [{
                type: Output
            }], appearance: [{
                type: Input
            }], lang: [{
                type: Input
            }], questionLastChar: [{
                type: Input
            }], headerBackgroundColor: [{
                type: Input
            }], showHeader: [{
                type: Input
            }], firstLevelGroupFormat: [{
                type: Input
            }], readOnly: [{
                type: Input
            }], enableActionButtons: [{
                type: Input
            }], editMode: [{
                type: Input
            }], onModeChange: [{
                type: Output
            }], forceRadioButton: [{
                type: Input
            }], maxValuesForRadio: [{
                type: Input
            }], smallQuestionColumn: [{
                type: Input
            }], emptyAnswerPlaceholder: [{
                type: Input
            }], onCancel: [{
                type: Output
            }], onSave: [{
                type: Output
            }], editorComponent: [{
                type: ViewChild,
                args: [QuestionnaireSectionEditorComponent]
            }] } });

class QuestionnaireSectionTesterComponent {
    constructor() {
        /**
         * ASPECT SETTINGS
         */
        this.appearance = 'outline';
        this.appearanceOptions = [
            new CodedValue('fill', 'fill', 'Fill'),
            new CodedValue('outline', 'outline', 'Outline'),
        ];
        this.langOptions = [
            new CodedValue('it', 'it', 'Italian'),
            new CodedValue('en', 'en', 'English'),
        ];
        // last char to be added to questions
        this.questionLastChar = "?";
        this.questionLastCharOptions = [
            new CodedValue('', '', 'Nothing'),
            new CodedValue('?', '?', 'Question mark'),
            new CodedValue('.', '.', 'Dot'),
        ];
        // protected headerBackgroundColor: string;
        // if false hides the main header and the questionnaire title
        this.showHeader = true;
        // TODO (only box is working)
        this.firstLevelGroupFormat = 'box';
        this.firstLevelGroupFormatOptions = [
            new CodedValue('none', 'none', 'None'),
            new CodedValue('box', 'box', 'Boxes'),
            new CodedValue('card', 'card', 'Cards'),
            new CodedValue('tab', 'tab', 'Tabs'),
            new CodedValue('expansion', 'expansion', 'Expansion panels'),
        ];
        /**
         * OPERATING MODE SETTINGS
         */
        // if the questionnaire cannot be modified (in this case the action buttons are not rendered)
        this.readOnly = false;
        // if the the action buttons have to be rendered (if 'false' use 'editMode' and/or 'questionnaireResponse' with bidirectional binding)
        this.enableActionButtons = true;
        // determine the mode that should be used when showing for the first time
        this.editMode = true;
        /**
         * EDIT FORM RENDERING SETTINGS
         */
        // render options only as Radio Button
        this.forceRadioButton = false;
        // [GUIDELINE] max value for switching options from Radio to Select
        this.maxValuesForRadio = 5;
        this.maxValuesForRadioOptions = [1, 2, 3, 4, 5];
        // manage the width of the question column and the rendering of the overall questionnaire
        this.smallQuestionColumn = false;
        // chars used for empty answers
        this.emptyAnswerPlaceholder = "-";
        this.emptyAnswerPlaceholderOptions = [
            new CodedValue('-', '-', '-'),
            new CodedValue('', '', 'Nothing'),
            new CodedValue('Not answered', 'Not answered', 'Not answered'),
        ];
        this.questionnaireWithOnlyGroup = true;
    }
    ngOnInit() {
        this.form = new FormGroup({
            'appearance': new FormControl(this.appearanceOptions[1].code),
            'lang': new FormControl(this.langOptions[0].code),
            'firstLevelGroupFormat': new FormControl(this.firstLevelGroupFormatOptions[0].code),
            'questionLastChar': new FormControl(this.questionLastCharOptions[0].code),
            // 'headerBackgroundColor': new FormControl(string),
            'emptyAnswerPlaceholder': new FormControl(this.emptyAnswerPlaceholderOptions[0].code),
            'showHeader': new FormControl(this.showHeader),
            'readOnly': new FormControl(this.readOnly),
            'enableActionButtons': new FormControl(this.enableActionButtons),
            'editMode': new FormControl(this.editMode),
            'forceRadioButton': new FormControl(this.forceRadioButton),
            'maxValuesForRadio': new FormControl(this.maxValuesForRadioOptions[0]),
            'smallQuestionColumn': new FormControl(this.smallQuestionColumn),
            'questionnaireWithOnlyGroup': new FormControl(this.questionnaireWithOnlyGroup),
        });
        this.form.valueChanges.subscribe(changes => {
            this.appearance = changes['appearance'];
            this.lang = changes['lang'];
            this.firstLevelGroupFormat = changes['firstLevelGroupFormat'];
            this.questionLastChar = changes['questionLastChar'];
            this.emptyAnswerPlaceholder = changes['emptyAnswerPlaceholder'];
            this.showHeader = changes['showHeader'];
            this.readOnly = changes['readOnly'];
            this.enableActionButtons = changes['enableActionButtons'];
            this.editMode = changes['editMode'];
            this.forceRadioButton = changes['forceRadioButton'];
            this.maxValuesForRadio = changes['maxValuesForRadio'];
            this.smallQuestionColumn = changes['smallQuestionColumn'];
            this.questionnaireWithOnlyGroup = changes['questionnaireWithOnlyGroup'];
        });
        this.questionnaireResponseMixed = new QuestionnaireResponse(this.createQuestionnaire(false));
        this.questionnaireResponseWithOnlyGroups = new QuestionnaireResponse(this.createQuestionnaire(true));
    }
    createQuestionnaire(addOnlyGroups = false) {
        // Q multicoiche with codedvalues
        // Q notmulticoice with codedvalues
        const q = new Questionnaire('questionnaire' + (addOnlyGroups ? '_only_groups' : '_mixed'));
        q.title = "Questionnaire Title " + (addOnlyGroups ? '(Only groups)' : '(Mixed)');
        q.name = q.title;
        q.items = [];
        q.items.push(this.questionGroup());
        q.items.push(this.questionRepeatableGroup());
        q.items.push(this.questionMultiChoiceGroup());
        if (!addOnlyGroups) {
            q.items.push(this.questionString());
            q.items.push(this.questionText());
            // q.items.push(this.questionDate());
        }
        return q;
    }
    questionGroup() {
        const qg = new QuestionGroup();
        qg.groupId = "questions_" + random();
        qg.text = "Group of questions";
        qg.repeated = false;
        qg.items = [];
        qg.items.push(this.questionDisplay());
        qg.items.push(this.questionDate());
        // qg.items.push(this.questionDateTime());
        qg.items.push(this.questionText());
        qg.items.push(this.questionString());
        qg.items.push(this.questionInteger());
        qg.items.push(this.questionDecimal());
        qg.items.push(this.questionBoolean());
        qg.items.push(this.questionBoolean(true));
        qg.items.push(this.questionConditionedBoolean());
        return qg;
    }
    questionMultiChoiceGroup() {
        const qg = new QuestionGroup();
        qg.groupId = "multichoice_questions_" + random();
        qg.text = "Group of multichoice questions";
        qg.repeated = false;
        qg.items = [];
        qg.items.push(this.questionChoices(2));
        qg.items.push(this.questionChoices(3));
        qg.items.push(this.questionChoices(4));
        qg.items.push(this.questionChoices(5));
        qg.items.push(this.questionChoices(4, true));
        return qg;
    }
    questionRepeatableGroup() {
        const qg = new QuestionGroup();
        qg.groupId = "repeateble_questions_" + random();
        qg.text = "Repeatable group of questions";
        qg.repeated = true;
        qg.items = [];
        qg.items.push(this.questionString());
        return qg;
    }
    questionDisplay() {
        const q = new Question();
        q.questionId = "display_" + random();
        q.text = "Readonly text used to display some contents";
        q.type = QuestionType.display;
        return q;
    }
    questionChoices(choiceAmount, isMulti = false) {
        const q = new Question();
        q.questionId = "choice_" + random();
        q.text = "Question with choice";
        q.type = QuestionType.CodedValue;
        q.permittedAnswers = [];
        q.multiChoice = isMulti;
        for (let i = 0; i < choiceAmount; i++) {
            const answer = new Choice(new CodedValue(i + '', i + '', i + ''));
            q.permittedAnswers.push(answer);
        }
        return q;
    }
    questionInteger(min, max) {
        const q = new Question();
        q.questionId = "integer_" + random();
        q.text = "Question integer";
        q.type = QuestionType.integer;
        q.min = min;
        q.max = max;
        return q;
    }
    questionDecimal(min, max) {
        const q = new Question();
        q.questionId = "decimal_" + random();
        q.text = "Question decimal";
        q.type = QuestionType.decimal;
        q.min = min;
        q.max = max;
        return q;
    }
    questionText() {
        const q = new Question();
        q.questionId = "text_" + random();
        q.text = "Question text";
        q.type = QuestionType.text;
        return q;
    }
    questionString() {
        const q = new Question();
        q.questionId = "string_" + random();
        q.text = "Question string";
        q.type = QuestionType.string;
        return q;
    }
    questionDate() {
        const q = new Question();
        q.questionId = "date_" + random();
        q.text = "Question date";
        q.type = QuestionType.date;
        return q;
    }
    questionBoolean(isMandatory = false) {
        const q = new Question();
        q.questionId = "boolean_" + random();
        q.text = "Question boolean" + (isMandatory ? ' (required)' : '');
        q.type = QuestionType.boolean;
        q.required = isMandatory;
        return q;
    }
    questionConditionedBoolean() {
        const q = new Question();
        q.questionId = "conditioned_boolean_" + random();
        q.text = "Question conditioned boolean";
        q.type = QuestionType.boolean;
        const cq = new Question();
        cq.questionId = "more_string_" + random();
        cq.text = "Add more info";
        cq.type = QuestionType.string;
        cq.enableWhen = new QuestionEnableWhen();
        const condition = new QuestionEnableWhenCondition();
        condition.question = q.questionId;
        condition.operator = QuestionEnableWhenOperator.EQ;
        condition.answer = true;
        cq.enableWhen.conditions = [condition];
        q.items = [cq];
        return q;
    }
}
QuestionnaireSectionTesterComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: QuestionnaireSectionTesterComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
QuestionnaireSectionTesterComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: QuestionnaireSectionTesterComponent, selector: "heart-questionnaire-section-tester", ngImport: i0, template: "<div *ngIf=\"form\" class=\"d-flex flex-column\">\n  <h2>Questionnaire Section Testing view</h2>\n\n  <form [formGroup]=\"form\">\n    <div class=\"d-flex flex-row\">\n      <mat-form-field class=\"d-flex\">\n        <mat-label>Appearance</mat-label>\n        <mat-select formControlName=\"appearance\">\n          <mat-option *ngFor=\"let v of appearanceOptions\" [value]=\"v.code\">{{v.display}}</mat-option>\n        </mat-select>\n      </mat-form-field>\n\n      <mat-form-field class=\"d-flex\">\n        <mat-label>Lang</mat-label>\n        <mat-select formControlName=\"lang\">\n          <mat-option *ngFor=\"let v of langOptions\" [value]=\"v.code\">{{v.display}}</mat-option>\n        </mat-select>\n      </mat-form-field>\n\n      <mat-form-field class=\"d-flex\">\n        <mat-label>First level group format (requires only QuestionGroup at first level)</mat-label>\n        <mat-select formControlName=\"firstLevelGroupFormat\">\n          <mat-option *ngFor=\"let v of firstLevelGroupFormatOptions\" [value]=\"v.code\">{{v.display}}</mat-option>\n        </mat-select>\n      </mat-form-field>\n\n      <mat-form-field class=\"d-flex\">\n        <mat-label>Last character to append to questions</mat-label>\n        <mat-select formControlName=\"questionLastChar\">\n          <mat-option *ngFor=\"let v of questionLastCharOptions\" [value]=\"v.code\">{{v.display}}</mat-option>\n        </mat-select>\n      </mat-form-field>\n\n      <mat-form-field class=\"d-flex\">\n        <mat-label>Text for empty answers</mat-label>\n        <mat-select formControlName=\"emptyAnswerPlaceholder\">\n          <mat-option *ngFor=\"let v of emptyAnswerPlaceholderOptions\" [value]=\"v.code\">{{v.display}}</mat-option>\n        </mat-select>\n      </mat-form-field>\n\n      <mat-form-field class=\"d-flex\">\n        <mat-label>Number of max values for radio</mat-label>\n        <mat-select formControlName=\"maxValuesForRadio\">\n          <mat-option *ngFor=\"let v of maxValuesForRadioOptions\" [value]=\"v\">{{v}}</mat-option>\n        </mat-select>\n      </mat-form-field>\n    </div>\n\n    <div class=\"flex-1 d-flex flex-row\">\n      <mat-checkbox formControlName=\"questionnaireWithOnlyGroup\">Put only groups in the first level of the questionnaire</mat-checkbox>\n\n      <mat-checkbox formControlName=\"showHeader\">Show the header</mat-checkbox>\n      <mat-checkbox formControlName=\"enableActionButtons\">Enable action buttons</mat-checkbox>\n      <mat-checkbox formControlName=\"forceRadioButton\">Force radio button</mat-checkbox>\n      <mat-checkbox formControlName=\"smallQuestionColumn\">Use small question column</mat-checkbox>\n    </div>\n\n    <div class=\"flex-1 d-flex flex-row\">\n      <mat-checkbox formControlName=\"readOnly\">Read only mode</mat-checkbox>\n      <mat-checkbox formControlName=\"editMode\">Use in edit mode</mat-checkbox>\n    </div>\n  </form>\n</div>\n\n<div *ngIf=\"questionnaireWithOnlyGroup ? questionnaireResponseWithOnlyGroups : questionnaireResponseMixed\">\n  <!-- [readOnly]=\"readOnly\"\n  [editMode]=\"editMode\" -->\n  <heart-questionnaire-section\n      [questionnaireResponse]=\"questionnaireWithOnlyGroup ? questionnaireResponseWithOnlyGroups : questionnaireResponseMixed\"\n      [appearance]=\"appearance\"\n      [lang]=\"lang\"\n      [questionLastChar]=\"questionLastChar\"\n      [showHeader]=\"showHeader\"\n      [firstLevelGroupFormat]=\"firstLevelGroupFormat\"\n      [enableActionButtons]=\"enableActionButtons\"\n      [forceRadioButton]=\"forceRadioButton\"\n      [maxValuesForRadio]=\"maxValuesForRadio\"\n      [smallQuestionColumn]=\"smallQuestionColumn\"\n      [emptyAnswerPlaceholder]=\"emptyAnswerPlaceholder\"\n    ></heart-questionnaire-section>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i3.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i3.MatLabel, selector: "mat-label" }, { kind: "component", type: i6.MatSelect, selector: "mat-select", inputs: ["disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator"], exportAs: ["matSelect"] }, { kind: "component", type: i1.MatOption, selector: "mat-option", exportAs: ["matOption"] }, { kind: "component", type: i9.MatCheckbox, selector: "mat-checkbox", inputs: ["disableRipple", "color", "tabIndex"], exportAs: ["matCheckbox"] }, { kind: "directive", type: i10.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i10.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i10.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i10.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i10.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: QuestionnaireSectionComponent, selector: "heart-questionnaire-section", inputs: ["questionnaireResponse", "appearance", "lang", "questionLastChar", "headerBackgroundColor", "showHeader", "firstLevelGroupFormat", "readOnly", "enableActionButtons", "editMode", "forceRadioButton", "maxValuesForRadio", "smallQuestionColumn", "emptyAnswerPlaceholder"], outputs: ["questionnaireResponseChange", "onModeChange", "onCancel", "onSave"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: QuestionnaireSectionTesterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-questionnaire-section-tester', template: "<div *ngIf=\"form\" class=\"d-flex flex-column\">\n  <h2>Questionnaire Section Testing view</h2>\n\n  <form [formGroup]=\"form\">\n    <div class=\"d-flex flex-row\">\n      <mat-form-field class=\"d-flex\">\n        <mat-label>Appearance</mat-label>\n        <mat-select formControlName=\"appearance\">\n          <mat-option *ngFor=\"let v of appearanceOptions\" [value]=\"v.code\">{{v.display}}</mat-option>\n        </mat-select>\n      </mat-form-field>\n\n      <mat-form-field class=\"d-flex\">\n        <mat-label>Lang</mat-label>\n        <mat-select formControlName=\"lang\">\n          <mat-option *ngFor=\"let v of langOptions\" [value]=\"v.code\">{{v.display}}</mat-option>\n        </mat-select>\n      </mat-form-field>\n\n      <mat-form-field class=\"d-flex\">\n        <mat-label>First level group format (requires only QuestionGroup at first level)</mat-label>\n        <mat-select formControlName=\"firstLevelGroupFormat\">\n          <mat-option *ngFor=\"let v of firstLevelGroupFormatOptions\" [value]=\"v.code\">{{v.display}}</mat-option>\n        </mat-select>\n      </mat-form-field>\n\n      <mat-form-field class=\"d-flex\">\n        <mat-label>Last character to append to questions</mat-label>\n        <mat-select formControlName=\"questionLastChar\">\n          <mat-option *ngFor=\"let v of questionLastCharOptions\" [value]=\"v.code\">{{v.display}}</mat-option>\n        </mat-select>\n      </mat-form-field>\n\n      <mat-form-field class=\"d-flex\">\n        <mat-label>Text for empty answers</mat-label>\n        <mat-select formControlName=\"emptyAnswerPlaceholder\">\n          <mat-option *ngFor=\"let v of emptyAnswerPlaceholderOptions\" [value]=\"v.code\">{{v.display}}</mat-option>\n        </mat-select>\n      </mat-form-field>\n\n      <mat-form-field class=\"d-flex\">\n        <mat-label>Number of max values for radio</mat-label>\n        <mat-select formControlName=\"maxValuesForRadio\">\n          <mat-option *ngFor=\"let v of maxValuesForRadioOptions\" [value]=\"v\">{{v}}</mat-option>\n        </mat-select>\n      </mat-form-field>\n    </div>\n\n    <div class=\"flex-1 d-flex flex-row\">\n      <mat-checkbox formControlName=\"questionnaireWithOnlyGroup\">Put only groups in the first level of the questionnaire</mat-checkbox>\n\n      <mat-checkbox formControlName=\"showHeader\">Show the header</mat-checkbox>\n      <mat-checkbox formControlName=\"enableActionButtons\">Enable action buttons</mat-checkbox>\n      <mat-checkbox formControlName=\"forceRadioButton\">Force radio button</mat-checkbox>\n      <mat-checkbox formControlName=\"smallQuestionColumn\">Use small question column</mat-checkbox>\n    </div>\n\n    <div class=\"flex-1 d-flex flex-row\">\n      <mat-checkbox formControlName=\"readOnly\">Read only mode</mat-checkbox>\n      <mat-checkbox formControlName=\"editMode\">Use in edit mode</mat-checkbox>\n    </div>\n  </form>\n</div>\n\n<div *ngIf=\"questionnaireWithOnlyGroup ? questionnaireResponseWithOnlyGroups : questionnaireResponseMixed\">\n  <!-- [readOnly]=\"readOnly\"\n  [editMode]=\"editMode\" -->\n  <heart-questionnaire-section\n      [questionnaireResponse]=\"questionnaireWithOnlyGroup ? questionnaireResponseWithOnlyGroups : questionnaireResponseMixed\"\n      [appearance]=\"appearance\"\n      [lang]=\"lang\"\n      [questionLastChar]=\"questionLastChar\"\n      [showHeader]=\"showHeader\"\n      [firstLevelGroupFormat]=\"firstLevelGroupFormat\"\n      [enableActionButtons]=\"enableActionButtons\"\n      [forceRadioButton]=\"forceRadioButton\"\n      [maxValuesForRadio]=\"maxValuesForRadio\"\n      [smallQuestionColumn]=\"smallQuestionColumn\"\n      [emptyAnswerPlaceholder]=\"emptyAnswerPlaceholder\"\n    ></heart-questionnaire-section>\n</div>\n" }]
        }] });

// AoT requires an exported function for factories
function HttpLoaderFactoryQuestionnaire(http) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class QuestionnaireSectionModule {
    static forRoot(config) {
        return {
            ngModule: QuestionnaireSectionModule,
            providers: [
                { provide: MAT_DATE_FORMATS, useValue: MAT_DATE_FNS_FORMATS },
                { provide: DateAdapter, useClass: DateFnsAdapter, deps: [MAT_DATE_LOCALE] },
                {
                    provide: MAT_DATE_LOCALE,
                    useValue: config?.matDateLocale ?? enGB,
                },
            ],
        };
    }
}
QuestionnaireSectionModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: QuestionnaireSectionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
QuestionnaireSectionModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: QuestionnaireSectionModule, declarations: [QuestionnaireSectionComponent,
        QuestionnaireSectionViewerComponent,
        QuestionnaireSectionEditorComponent,
        QuestionnaireSectionEditorQuestionComponent,
        QuestionnaireSectionEditorGroupComponent,
        QuestionnaireSectionTesterComponent,
        InstanceofPipe$1,
        RadioGroupCompare$1], imports: [CommonModule, i1$1.TranslateModule, MatCardModule,
        MatExpansionModule,
        MatTabsModule,
        MatFormFieldModule,
        MatInputModule,
        MatIconModule,
        MatSelectModule,
        MatRadioModule,
        MatCheckboxModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatDatepickerModule,
        SubTranslateModule,
        PreventDoubleClickModule], exports: [QuestionnaireSectionComponent, QuestionnaireSectionTesterComponent] });
QuestionnaireSectionModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: QuestionnaireSectionModule, providers: [QuestionSectionEditorService], imports: [CommonModule,
        TranslateModule.forChild({
            defaultLanguage: 'en',
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactoryQuestionnaire,
                deps: [HttpClient],
            },
            isolate: true,
        }),
        MatCardModule,
        MatExpansionModule,
        MatTabsModule,
        MatFormFieldModule,
        MatInputModule,
        MatIconModule,
        MatSelectModule,
        MatRadioModule,
        MatCheckboxModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatDatepickerModule,
        SubTranslateModule,
        PreventDoubleClickModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: QuestionnaireSectionModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        QuestionnaireSectionComponent,
                        QuestionnaireSectionViewerComponent,
                        QuestionnaireSectionEditorComponent,
                        QuestionnaireSectionEditorQuestionComponent,
                        QuestionnaireSectionEditorGroupComponent,
                        QuestionnaireSectionTesterComponent,
                        InstanceofPipe$1,
                        RadioGroupCompare$1,
                    ],
                    providers: [QuestionSectionEditorService],
                    imports: [
                        CommonModule,
                        TranslateModule.forChild({
                            defaultLanguage: 'en',
                            loader: {
                                provide: TranslateLoader,
                                useFactory: HttpLoaderFactoryQuestionnaire,
                                deps: [HttpClient],
                            },
                            isolate: true,
                        }),
                        MatCardModule,
                        MatExpansionModule,
                        MatTabsModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatIconModule,
                        MatSelectModule,
                        MatRadioModule,
                        MatCheckboxModule,
                        ReactiveFormsModule,
                        MatButtonModule,
                        MatDatepickerModule,
                        SubTranslateModule,
                        PreventDoubleClickModule,
                    ],
                    exports: [QuestionnaireSectionComponent, QuestionnaireSectionTesterComponent],
                }]
        }] });

const en = {
    "questionnaire.button.compile.label": "Compile",
    "questionnaire.button.edit.label": "Edit",
    "questionnaire.button.cancel.label": "Cancel",
    "questionnaire.button.save.label": "Save",
    "questionnaire.button.add.label": "Add",
    "msg.invalid_range": "Error. Possible invalid range.",
    "msg.invalid_number_type": "Error. Invalid numeric type."
};

const it = {
    "questionnaire.button.compile.label": "Compila",
    "questionnaire.button.edit.label": "Modifica",
    "questionnaire.button.cancel.label": "Annulla",
    "questionnaire.button.save.label": "Salva",
    "questionnaire.button.add.label": "Aggiungi",
    "msg.invalid_range": "Errore. Possibile intervallo errato.",
    "msg.invalid_number_type": "Errore. Formato non valido."
};

class DynBuiltQuestionSectionEditorService {
    constructor() {
        this.DEFAULT_MAX_VALUE = 1000000000;
        /**
           *  Utility matcher of questions / answers in the Questionnaire and QuestionnaireResponse
           */
        this.matchQuestionAndAnswer = (q, a) => (a instanceof Answer && q instanceof Question && a.questionId == q.questionId) ||
            ((a instanceof AnswerGroup) && q instanceof QuestionGroup && a.groupId == q.groupId);
    }
    createForm(questionnaireResponse) {
        const group = new FormGroup([]);
        const relatedControlGroups = [];
        /*
         * Per ogni domanda del questionario:
         * 1. Crea l'istanza di FormControl
         * 2. Verifica se esista già una risposta data
         *    e nel caso valorizza il FormControl
         * 3. Qualora non esista una risposta già data
         *    in precedenza, verifica se c'è un valore di default
         *    da dare al FormControl
         */
        const questionnaireItems = questionnaireResponse.questionnaire?.items;
        questionnaireItems?.forEach(questionnaireItem => {
            const isRepeated = questionnaireItem instanceof QuestionGroup && questionnaireItem.repeated;
            const _answerItem = questionnaireResponse.answers?.filter(a => this.matchQuestionAndAnswer(questionnaireItem, a)) || [];
            const _answerItemWithOptionalRepeat = isRepeated ? _answerItem : _answerItem.pop();
            this.createFormControl(group, questionnaireItem, _answerItemWithOptionalRepeat, relatedControlGroups);
        });
        // once the form group has been created it adds all the logic to manage the identified 'enablingWhen'
        for (let index = 0; index < relatedControlGroups.length; index++) {
            const related = relatedControlGroups[index];
            const subscription = this.createEnableWhenSubscription(related.item, related.dependantControl);
            if (subscription == undefined) {
                throw new Error(`Missing subscription on enabling/disabling when event`);
            }
        }
        return group;
    }
    createEnableWhenSubscription(item, itemFormControl) {
        const when = item.enableWhen;
        if (!when) {
            return undefined;
        }
        const controls = [];
        for (const condition of when.conditions) {
            // look for nearest FormGroup with id == condition.linkId
            const linkedAnswerControl = this.lookForNearestFormControl(itemFormControl, condition.question);
            if (linkedAnswerControl) {
                controls.push({ formControl: linkedAnswerControl, condition: condition });
            }
            else {
                console.error(`FormControl for '${condition.question}' not found.`);
            }
        }
        const controlsCheck = (_controls, _when, _formControl) => {
            let enable = false;
            if (_when.behaviour == 'any' || (_when.behaviour == undefined && when.conditions.length == 1)) {
                // enable if behaviour is 'any'
                enable = _controls.some(c => this.evaluateCondition(c.formControl.value, c.condition.operator, c.condition.answer));
            }
            else {
                // enable if behaviour is 'all'
                enable = _controls.every(c => this.evaluateCondition(c.formControl.value, c.condition.operator, c.condition.answer));
            }
            if (enable) {
                _formControl.enable();
            }
            else {
                // FIX: bug #1485 to ensure that any nested question is not precompiled while 
                // preparing the QuestionnaireRespone to be sent to the server and, thus, incurr in a server validation error
                _formControl.reset();
                _formControl.disable();
            }
        };
        // check the status of dependant form control during the form setup
        controlsCheck(controls, when, itemFormControl);
        // now create subscriptions for value change events
        const subscriptions = [];
        for (const c of controls) {
            const s = c.formControl.valueChanges
                .subscribe((currentValue) => {
                // trigger control checks
                controlsCheck(controls, when, itemFormControl);
            });
            subscriptions.push(s);
        }
        // return subscriptions to value changes
        return subscriptions;
    }
    createFormControl(parentGroup, item, answerItem, relatedControlGroups) {
        let newControl;
        let newControlName;
        if (item instanceof QuestionGroup) {
            newControlName = item.groupId;
            // if it is a repeteabled element let's prepare the form as to support the cloning
            // note that the condition on the FormArray is needed as recursion terminal condition while rendering existing RepeatableAnswerGroup items
            if (item.repeated && !(parentGroup instanceof FormArray)) {
                // manage RepeatedAnswerGroup
                newControl = new FormArray([]);
                // no actual item is created right now as we do it by calling the 'createFormArrayGroup' method
                if (answerItem != undefined && !Array.isArray(answerItem)) {
                    throw new Error(`This code can be reached only if 'answerItem' is instanceof repeated 'AnswerGroup`);
                }
                if (item.required) {
                    newControl.addValidators(Validators.required);
                }
                answerItem?.forEach((answer => {
                    // in this case there is no need to look for repeated items
                    this.createFormControl(newControl, item, answer, relatedControlGroups);
                }));
            }
            else {
                newControl = new FormGroup([]);
                if (answerItem != undefined && !(answerItem instanceof AnswerGroup) && !(parentGroup instanceof FormArray)) {
                    throw new Error(`This code can be reached only if 'answerItem' is instanceof 'AnswerGroup'`);
                }
                if (item.required) {
                    newControl.addValidators(Validators.required);
                }
                item.items?.forEach(questionnaireItem => {
                    const isRepeated = questionnaireItem instanceof QuestionGroup && questionnaireItem.repeated;
                    const _answerItem = answerItem?.answers?.filter(a => this.matchQuestionAndAnswer(questionnaireItem, a)) || [];
                    const _answerItemWithOptionalRepeat = isRepeated ? _answerItem : _answerItem.pop();
                    this.createFormControl(newControl, questionnaireItem, _answerItemWithOptionalRepeat, relatedControlGroups);
                });
            }
            if (item.enableWhen) {
                relatedControlGroups.push({ item: item, dependantControl: newControl });
            }
        }
        else {
            // from this line it manages simple Question items
            if (item.type != QuestionType.display) {
                const hasNestedQuestions = item.items?.length > 0;
                newControl = new FormControl();
                newControlName = item.questionId;
                // Validator in case of 'required' item
                if (item.required) {
                    newControl.addValidators(Validators.required);
                }
                // Validator per range numerico
                if ((item.type === QuestionType.integer) || (item.type === QuestionType.decimal)) {
                    if (item.type === QuestionType.integer) {
                        newControl.addValidators(Validators.pattern("[+-]?\\d+"));
                    }
                    else if (item.type === QuestionType.decimal) {
                        newControl.addValidators(Validators.pattern("[+-]?\\d+((\\.|\\,)\d+)"));
                    }
                    if (item.min != undefined) {
                        newControl.addValidators(Validators.min(item.min));
                    }
                    if (item.max != undefined) {
                        item.max = item.max || this.DEFAULT_MAX_VALUE;
                        newControl.addValidators(Validators.max(item.max));
                    }
                }
                // Imposta il valore del FormControl
                const answer = answerItem;
                if (answer) {
                    // se esiste una risposta già data la usa come value del control
                    // console.log("imposto il valore del control: " + q.questionId + " a " + answer.value);
                    newControl.setValue(answer.value);
                    // console.log("RISPOSTA per " + item.questionId + ": " + answer.value);
                }
                /*
                else {
                  // preset delle risposte predefinite - if any
                  const defaultChoice : Choice = q.permittedAnswers?.find(ans => ans.initialSelected);
                  if (defaultChoice){
                    // console.log("imposto il valore di default del control: " + q.questionId + " a " + defaultChoice.value);
                    group[q.questionId].value = defaultChoice.value;
                  }
                }
                */
                if (hasNestedQuestions) { // it has nested Questions
                    // wrap the FormControl in a FormGroup by reusing the control name (i.e. questionId)
                    const newControlForm = newControl;
                    newControl = new FormGroup([]);
                    newControl.addControl(newControlName, newControlForm);
                    newControlName = item.questionId;
                    item.items?.forEach(questionnaireItem => {
                        const _answerItem = answerItem?.answers?.find(a => this.matchQuestionAndAnswer(questionnaireItem, a));
                        // in this case there is no need to look for repeated items (currently we do not support repeated Answer but only AnswerGroups)
                        this.createFormControl(newControl, questionnaireItem, _answerItem, relatedControlGroups);
                    });
                }
                // must be after 'hasNestedQuestions'!!!
                if (item.enableWhen) {
                    relatedControlGroups.push({ item: item, dependantControl: newControl });
                }
            }
        }
        // Disable the control if the item is 'readOnly'
        if (item.readOnly) {
            newControl.disable();
        }
        if (newControl) {
            // aggiunge il nuovo controllo al gruppo.
            if (parentGroup instanceof FormGroup) {
                parentGroup.addControl(newControlName, newControl);
            }
            else {
                parentGroup.push(newControl);
            }
        }
    }
    /**
     * Used to trigger the creation of a form group for repeteable question groups
     */
    createFormArrayGroup(parentGroup, item, answerItem) {
        const newControl = new FormGroup([]);
        const relatedControlGroups = [];
        item.items?.forEach(questionnaireItem => {
            const _answerItem = answerItem?.answers?.find(a => this.matchQuestionAndAnswer(questionnaireItem, a));
            // in this case there is no need to look for repeated items
            this.createFormControl(newControl, questionnaireItem, _answerItem, relatedControlGroups);
        });
        // once the form group has been created it adds all the logic to manage the identified 'enablingWhen'
        for (let index = 0; index < relatedControlGroups.length; index++) {
            const related = relatedControlGroups[index];
            const subscription = this.createEnableWhenSubscription(related.item, related.dependantControl);
            if (subscription == undefined) {
                throw new Error(`Missing subscription on enabling/disabling when event`);
            }
        }
        parentGroup.push(newControl);
    }
    removeFormArrayGroup(parentGroup, indexToRemove) {
        parentGroup.removeAt(indexToRemove);
    }
    /**
     * look for the nearest item as by FHIR Specification stating:
     * If multiple question occurrences are present for the same question (same linkId),
     * then this refers to the nearest question occurrence reachable by tracing first the "ancestor" axis
     * and then the "preceding" axis and then the "following" axis. If there are multiple items with the same
     * linkId and all are equadistant (e.g. a question references a question that appears in a separate repeating group), that is an error.
     *
     * (Consider using the enableWhenExpression extension to define logic to handle such a situation.)
     *
     * @param itemFormControl
     * @param linkId
     * @param direction
     * @returns
     */
    lookForNearestFormControl(itemFormControl, linkId, direction = 'up') {
        let formControl;
        if (direction == 'up') {
            const parent = itemFormControl.parent;
            if (!parent) {
                return undefined;
            }
            formControl = parent.get(linkId);
            if (formControl && formControl instanceof FormControl) { // the linked answer is a sibling of the current node
                return formControl;
            }
            else { // if not it starts looking in the 'ancestors' axis
                if (parent instanceof FormGroup) {
                    formControl = this.lookForNearestFormControl(parent, linkId);
                }
                else if (parent instanceof FormArray) {
                    // skip (as it can't refer a specific repeatable item) and look for its parent
                    formControl = this.lookForNearestFormControl(parent.parent, linkId);
                }
                if (!formControl) {
                    // look for 'preceding' axis ???
                    // look in the 'following' axis
                    if (itemFormControl instanceof FormGroup) {
                        const controls = itemFormControl.controls;
                        for (const controlName in controls) {
                            formControl = this.lookForNearestFormControl(controls[controlName], linkId, 'down');
                            if (formControl) {
                                continue;
                            }
                        }
                    }
                    else if (itemFormControl instanceof FormArray) {
                        // skip (as it can't refer a specific repeatable item)
                    }
                }
            }
        }
        if (direction == 'down') {
            const child = itemFormControl.get(linkId);
            if (child && child instanceof FormControl) {
                return child;
            }
            else {
                if (itemFormControl instanceof FormGroup) {
                    const controls = itemFormControl.controls;
                    for (const controlName in controls) {
                        formControl = this.lookForNearestFormControl(controls[controlName], linkId, 'down');
                        if (formControl) {
                            continue;
                        }
                    }
                }
                else if (itemFormControl instanceof FormArray) {
                    // skip (as it can't refer a specific repeatable item)
                }
            }
        }
        return formControl;
    }
    // evaluate condition
    evaluateCondition(currentValue, operator, answer) {
        switch (operator) {
            case QuestionEnableWhenOperator.EXISTS:
                return currentValue != undefined;
            case QuestionEnableWhenOperator.EQ: {
                if (currentValue instanceof Date) {
                    return isEqual(currentValue, answer);
                }
                else if (currentValue instanceof CodedValue) {
                    return currentValue?.code == answer?.code;
                }
                else {
                    return currentValue == answer;
                }
            }
            case QuestionEnableWhenOperator.NE:
                if (currentValue instanceof Date) {
                    return !isEqual(currentValue, answer);
                }
                else if (currentValue instanceof CodedValue) {
                    return currentValue?.code != answer?.code;
                }
                else {
                    return currentValue != answer;
                }
            case QuestionEnableWhenOperator.GT:
                if (currentValue instanceof Date) {
                    return isAfter(currentValue, answer);
                }
                else if (currentValue instanceof CodedValue) {
                    throw new Error(`Invalid comparision for GT of CodedValue`);
                }
                else {
                    return currentValue > answer;
                }
            case QuestionEnableWhenOperator.GE:
                if (currentValue instanceof Date) {
                    return isAfter(currentValue, answer) || isEqual(currentValue, answer);
                }
                else if (currentValue instanceof CodedValue) {
                    throw new Error(`Invalid comparision for GE of CodedValue`);
                }
                else {
                    return currentValue > answer;
                }
            case QuestionEnableWhenOperator.LT:
                if (currentValue instanceof Date) {
                    return isBefore(currentValue, answer);
                }
                else if (currentValue instanceof CodedValue) {
                    throw new Error(`Invalid comparision for BT of CodedValue`);
                }
                else {
                    return currentValue < answer;
                }
            case QuestionEnableWhenOperator.LE:
                if (currentValue instanceof Date) {
                    return isBefore(currentValue, answer) || isEqual(currentValue, answer);
                }
                else if (currentValue instanceof CodedValue) {
                    throw new Error(`Invalid comparision for LE of CodedValue`);
                }
                else {
                    return currentValue <= answer;
                }
        }
    }
}
DynBuiltQuestionSectionEditorService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DynBuiltQuestionSectionEditorService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
DynBuiltQuestionSectionEditorService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DynBuiltQuestionSectionEditorService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DynBuiltQuestionSectionEditorService, decorators: [{
            type: Injectable
        }] });

/**
 * Add 'compareWith' to mat-radio-group just like mat-select, because angular team didn't implement it
 * see https://github.com/angular/components/issues/10495
 */
class RadioGroupCompare {
    constructor(formControlName, cdr) {
        this.formControlName = formControlName;
        this.cdr = cdr;
    }
    ngAfterContentInit() {
        const control = this.formControl || this.formControlName;
        // Use ngAfterContentInit to make sure that radioButtons is initialized
        this.formControlSub = control.valueChanges
            .pipe(startWith(control.value))
            .subscribe((value) => {
            const foundRadioButton = this.radioButtons
                .toArray()
                .find((radioButton) => {
                // Find a radio button whose value compares to ngModel
                return this.compareWith(radioButton.value, value);
            });
            if (foundRadioButton) {
                foundRadioButton.checked = true;
                this.cdr.detectChanges();
            }
        });
    }
    ngOnDestroy() {
        if (this.formControlSub) {
            this.formControlSub.unsubscribe();
        }
    }
}
RadioGroupCompare.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RadioGroupCompare, deps: [{ token: i10.FormControlName, optional: true }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Directive });
RadioGroupCompare.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "15.2.10", type: RadioGroupCompare, selector: "mat-radio-group[compareWith]", inputs: { compareWith: "compareWith", formControl: "formControl" }, queries: [{ propertyName: "radioButtons", predicate: MatRadioButton, descendants: true }], ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RadioGroupCompare, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: 'mat-radio-group[compareWith]',
                }]
        }], ctorParameters: function () { return [{ type: i10.FormControlName, decorators: [{
                    type: Optional
                }] }, { type: i0.ChangeDetectorRef }]; }, propDecorators: { compareWith: [{
                type: Input
            }], formControl: [{
                type: Input
            }], radioButtons: [{
                type: ContentChildren,
                args: [MatRadioButton, { descendants: true }]
            }] } });

class DynBuiltQuestionnaireSectionEditorQuestionComponent {
    constructor(editorService) {
        this.editorService = editorService;
        this.smallQuestionColumn = false; // manage the width of the question column and the rendering of the overall questionnaire
        this.maxValuesForRadio = 5; // [GUIDELINE] max value for switching options from Radio to Select
        this.forceRadioButton = false; // render options only as Radio Button
        this.appearance = 'outline';
        this.questionLastChar = "?"; // last char to be added to questions
        // put to 'true' if you are rendering Questions nested in Questions (not in QuestionGroups)
        this.nestedQuestion = false;
        this.types = QuestionType;
        this.Question = Question;
        this.QuestionGroup = QuestionGroup;
        this.AnswerGroup = AnswerGroup;
        this.numericQuestionPlaceholder = (question) => {
            return [question.min, question.max].filter(v => v != undefined).join(' - ') || '';
        };
    }
    ngOnInit() {
    }
    get formGroup() {
        // if nested question
        if (this.nestedQuestion) {
            return this.form;
        }
        // if not nested but has nested questions
        if (this.question.items?.length > 0) {
            return this.form.get(this.question.questionId);
        }
        return this.form;
    }
    asFormGroup(formControl) {
        return formControl;
    }
    castAnswers(choices) {
        return choices;
    }
    compareCodedValues(c1, c2) {
        if (c1 == undefined || c2 == undefined) {
            return false;
        }
        if (c1.code != c2.code) {
            return false;
        }
        return true;
    }
    compareChoices(c1, c2) {
        const c1Value = c1?.value;
        const c2Value = c2?.value;
        if (c1Value == undefined || c2Value == undefined) {
            return false;
        }
        if (c1Value instanceof CodedValue && c2Value instanceof CodedValue) {
            return c1Value?.code == c2Value?.code;
        }
        return c1Value == c2Value;
    }
}
DynBuiltQuestionnaireSectionEditorQuestionComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DynBuiltQuestionnaireSectionEditorQuestionComponent, deps: [{ token: DynBuiltQuestionSectionEditorService }], target: i0.ɵɵFactoryTarget.Component });
DynBuiltQuestionnaireSectionEditorQuestionComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: DynBuiltQuestionnaireSectionEditorQuestionComponent, selector: "heart-dyn-built-questionnaire-section-editor-question", inputs: { question: "question", form: "form", smallQuestionColumn: "smallQuestionColumn", maxValuesForRadio: "maxValuesForRadio", forceRadioButton: "forceRadioButton", appearance: "appearance", questionLastChar: "questionLastChar", lang: "lang", nestedQuestion: "nestedQuestion" }, ngImport: i0, template: "<div *ngIf=\"form\" [formGroup]=\"formGroup\"\n  [ngClass]=\"{'d-flex': true, 'responsive-row': true, 'bottom-bordered-responsive-row' : !smallQuestionColumn}\">\n\n  <ng-container *ngIf=\"question.type !== types.display\">\n    <!--  domanda -->\n    <div class=\"question\" *ngIf=\"!nestedQuestion\"\n      [ngClass]=\"{'flex-basis-50' : !smallQuestionColumn, 'flex-basis-25' : smallQuestionColumn, 'question-highlight': question.required}\">\n      <span *ngIf=\"question.required\">*&nbsp;</span><span\n        *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text | translate}}{{questionLastChar}}\n    </div>\n\n    <div class=\"d-flex flex-1 flex-column\">\n\n      <!-- se la risposta \u00E8 chiusa verifica quante sono le possibili risposte -->\n      <!-- radiobutton se < 5 -->\n      <div class=\"flex-1\"\n        *ngIf=\"!question.multiChoice && ((question.permittedAnswers && question.permittedAnswers.length <= maxValuesForRadio) || forceRadioButton)\">\n        <mat-label class=\"mat-caption\" *ngIf=\"nestedQuestion\"><span *ngIf=\"question.required\">*&nbsp;</span><span\n            *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n          translate}}{{questionLastChar}}</mat-label>\n\n        <mat-radio-group [formControlName]=\"question.questionId\" [compareWith]=\"compareCodedValues\"\n          [ngClass]=\"{'vertical-radio-group' : !smallQuestionColumn}\">\n          <mat-radio-button *ngFor=\"let permittedAnswer of castAnswers(question.permittedAnswers)\"\n            [value]=\"permittedAnswer.value\">\n            {{permittedAnswer.label | translate}}\n          </mat-radio-button>\n        </mat-radio-group>\n      </div>\n\n      <!-- select se >= 5 -->\n      <!-- in ogni caso se la risposta \u00E8 chiusa e a risposta multipla mostra una combobox -->\n      <div class=\"flex-1\"\n        *ngIf=\"question.multiChoice || (question.permittedAnswers && question.permittedAnswers.length > maxValuesForRadio)\">\n        <mat-form-field [appearance]=\"appearance\">\n          <mat-select [formControlName]=\"question.questionId\" [compareWith]=\"compareCodedValues\"\n            [multiple]=\"question.multiChoice\">\n            <mat-label class=\"mat-caption\" *ngIf=\"nestedQuestion\"><span *ngIf=\"question.required\">*&nbsp;</span><span\n                *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n              translate}}{{questionLastChar}}</mat-label>\n\n            <mat-option *ngFor=\"let permittedAnswer of castAnswers(question.permittedAnswers)\"\n              [value]=\"permittedAnswer.value\">\n              {{permittedAnswer.label | translate}}\n            </mat-option>\n          </mat-select>\n        </mat-form-field>\n      </div>\n\n      <div class=\"flex-1\"\n        [ngClass]=\"{'d-flex flex-column': question.type === types.string || question.type === types.text}\"\n        *ngIf=\"!question.hasClosedAnswer()\">\n        <!-- risposta chiusa di tipo boolean -->\n        <ng-container *ngIf=\"question.type == types.boolean\">\n          <mat-label class=\"mat-caption\" *ngIf=\"nestedQuestion\"><span *ngIf=\"question.required\">*&nbsp;</span><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <section [ngClass]=\"{'vertical-radio-group' : !smallQuestionColumn}\">\n            <!-- if it is required we can't use a checkbox as it becomes mandatory to check it to valdiate the form -->\n            <mat-checkbox *ngIf=\"!question.required\" [formControlName]=\"question.questionId\"></mat-checkbox>\n\n            <!-- FORM: <small>{{ form.get(question.questionId) | json}}</small><br> -->\n            <mat-radio-group *ngIf=\"question.required\" [formControlName]=\"question.questionId\">\n              <mat-radio-button [value]=\"true\">{{ 'questionnaire.boolean.true' | translate}}</mat-radio-button>\n              <mat-radio-button [value]=\"false\">{{ 'questionnaire.boolean.false' | translate}}</mat-radio-button>\n            </mat-radio-group>\n          </section>\n        </ng-container>\n\n        <!-- risposta aperta di tipo number -->\n        <mat-form-field *ngIf=\"(question.type === types.integer) || (question.type === types.decimal)\"\n          [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <input matInput [formControlName]=\"question.questionId\" type=\"number\"\n            placeholder=\"{{ numericQuestionPlaceholder(question) }}\">\n          <mat-error\n            *ngIf=\"form.get(question.questionId)?.hasError('min') || form.get(question.questionId)?.hasError('max')\">{{('msg.invalid_range'\n            | subtranslate:lang) }} ({{ numericQuestionPlaceholder(question) }})</mat-error>\n          <mat-error *ngIf=\"form.get(question.questionId)?.hasError('pattern')\">{{ 'msg.invalid_number_type' |\n            subtranslate:lang }}</mat-error>\n        </mat-form-field>\n\n        <!-- risposta aperta di tipo text (long text) -->\n        <mat-form-field *ngIf=\"(question.type === types.text)\" [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <textarea matInput [formControlName]=\"question.questionId\" cdkTextareaAutosize cdkAutosizeMinRows=\"2\"\n            cdkAutosizeMaxRows=\"5\" [attr.maxlength]=\"question.maxLength\"></textarea>\n        </mat-form-field>\n\n        <!-- risposta aperta di tipo string (short text) -->\n        <mat-form-field *ngIf=\"(question.type === types.string)\" [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <input matInput [formControlName]=\"question.questionId\" type=\"text\">\n        </mat-form-field>\n\n        <!-- risposta aperta di tipo Date o DateTime -->\n        <mat-form-field *ngIf=\"(question.type === types.date)\" [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <input matInput readonly [matDatepicker]=\"picker\" [formControlName]=\"question.questionId\" />\n          <mat-datepicker-toggle matIconSuffix [for]=\"picker\"></mat-datepicker-toggle>\n          <mat-datepicker #picker></mat-datepicker>\n        </mat-form-field>\n\n        <!-- risposta aperta di tipo CodedValue senza permittedAnswer (serve solo se viene forzato un valore senza definire le possibili alternative) -->\n        <mat-form-field *ngIf=\"(question.type === types.CodedValue) && question.readOnly\" [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <input matInput [formControlName]=\"question.questionId\" type=\"string\">\n        </mat-form-field>\n      </div>\n\n      <div *ngFor=\"let item of question.items\">\n        <heart-dyn-built-questionnaire-section-editor-question [questionLastChar]=\"questionLastChar\"\n          [smallQuestionColumn]=\"smallQuestionColumn\" [maxValuesForRadio]=\"maxValuesForRadio\"\n          [forceRadioButton]=\"forceRadioButton\" [appearance]=\"appearance\" [lang]=\"lang\"\n          [form]=\"asFormGroup(form.get(question.questionId))\" [nestedQuestion]=\"true\"\n          [question]=\"item\"></heart-dyn-built-questionnaire-section-editor-question>\n      </div>\n\n    </div>\n\n  </ng-container>\n\n  <!-- domanda di tipo 'display' -->\n  <span *ngIf=\"(question.type === types.display)\" class=\"mat-caption mb-2\">{{ question.text | translate }}</span>\n</div>", styles: [".questionnaire{min-width:400px}.questionnaire .question{overflow-wrap:break-word;font-weight:bolder;opacity:.8}.group-box{border-style:solid;border-width:1px;border-color:#00000061;border-radius:4px}.responsive-row{flex-direction:row;align-items:baseline}.title{font-weight:600}@media screen and (max-width: 768px){.gutter{column-gap:0}.responsive-row{flex-direction:column;align-items:stretch;column-gap:0}}mat-radio-button{margin-right:16px!important}.question.question-highlight{font-weight:700}.vertical-radio-group{display:flex;flex-direction:column;align-items:flex-start}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i3.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i3.MatLabel, selector: "mat-label" }, { kind: "directive", type: i3.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i3.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "directive", type: i4.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "directive", type: i5.CdkTextareaAutosize, selector: "textarea[cdkTextareaAutosize]", inputs: ["cdkAutosizeMinRows", "cdkAutosizeMaxRows", "cdkTextareaAutosize", "placeholder"], exportAs: ["cdkTextareaAutosize"] }, { kind: "component", type: i6.MatSelect, selector: "mat-select", inputs: ["disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator"], exportAs: ["matSelect"] }, { kind: "component", type: i1.MatOption, selector: "mat-option", exportAs: ["matOption"] }, { kind: "directive", type: i8.MatRadioGroup, selector: "mat-radio-group", exportAs: ["matRadioGroup"] }, { kind: "component", type: i8.MatRadioButton, selector: "mat-radio-button", inputs: ["disableRipple", "tabIndex"], exportAs: ["matRadioButton"] }, { kind: "component", type: i9.MatCheckbox, selector: "mat-checkbox", inputs: ["disableRipple", "color", "tabIndex"], exportAs: ["matCheckbox"] }, { kind: "directive", type: i10.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i10.NumberValueAccessor, selector: "input[type=number][formControlName],input[type=number][formControl],input[type=number][ngModel]" }, { kind: "directive", type: i10.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i10.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i10.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i10.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i10.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i11.MatDatepicker, selector: "mat-datepicker", exportAs: ["matDatepicker"] }, { kind: "directive", type: i11.MatDatepickerInput, selector: "input[matDatepicker]", inputs: ["matDatepicker", "min", "max", "matDatepickerFilter"], exportAs: ["matDatepickerInput"] }, { kind: "component", type: i11.MatDatepickerToggle, selector: "mat-datepicker-toggle", inputs: ["for", "tabIndex", "aria-label", "disabled", "disableRipple"], exportAs: ["matDatepickerToggle"] }, { kind: "component", type: DynBuiltQuestionnaireSectionEditorQuestionComponent, selector: "heart-dyn-built-questionnaire-section-editor-question", inputs: ["question", "form", "smallQuestionColumn", "maxValuesForRadio", "forceRadioButton", "appearance", "questionLastChar", "lang", "nestedQuestion"] }, { kind: "directive", type: RadioGroupCompare, selector: "mat-radio-group[compareWith]", inputs: ["compareWith", "formControl"] }, { kind: "pipe", type: i1$1.TranslatePipe, name: "translate" }, { kind: "pipe", type: i2$1.SubTranslatePipe, name: "subtranslate" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DynBuiltQuestionnaireSectionEditorQuestionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-dyn-built-questionnaire-section-editor-question', template: "<div *ngIf=\"form\" [formGroup]=\"formGroup\"\n  [ngClass]=\"{'d-flex': true, 'responsive-row': true, 'bottom-bordered-responsive-row' : !smallQuestionColumn}\">\n\n  <ng-container *ngIf=\"question.type !== types.display\">\n    <!--  domanda -->\n    <div class=\"question\" *ngIf=\"!nestedQuestion\"\n      [ngClass]=\"{'flex-basis-50' : !smallQuestionColumn, 'flex-basis-25' : smallQuestionColumn, 'question-highlight': question.required}\">\n      <span *ngIf=\"question.required\">*&nbsp;</span><span\n        *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text | translate}}{{questionLastChar}}\n    </div>\n\n    <div class=\"d-flex flex-1 flex-column\">\n\n      <!-- se la risposta \u00E8 chiusa verifica quante sono le possibili risposte -->\n      <!-- radiobutton se < 5 -->\n      <div class=\"flex-1\"\n        *ngIf=\"!question.multiChoice && ((question.permittedAnswers && question.permittedAnswers.length <= maxValuesForRadio) || forceRadioButton)\">\n        <mat-label class=\"mat-caption\" *ngIf=\"nestedQuestion\"><span *ngIf=\"question.required\">*&nbsp;</span><span\n            *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n          translate}}{{questionLastChar}}</mat-label>\n\n        <mat-radio-group [formControlName]=\"question.questionId\" [compareWith]=\"compareCodedValues\"\n          [ngClass]=\"{'vertical-radio-group' : !smallQuestionColumn}\">\n          <mat-radio-button *ngFor=\"let permittedAnswer of castAnswers(question.permittedAnswers)\"\n            [value]=\"permittedAnswer.value\">\n            {{permittedAnswer.label | translate}}\n          </mat-radio-button>\n        </mat-radio-group>\n      </div>\n\n      <!-- select se >= 5 -->\n      <!-- in ogni caso se la risposta \u00E8 chiusa e a risposta multipla mostra una combobox -->\n      <div class=\"flex-1\"\n        *ngIf=\"question.multiChoice || (question.permittedAnswers && question.permittedAnswers.length > maxValuesForRadio)\">\n        <mat-form-field [appearance]=\"appearance\">\n          <mat-select [formControlName]=\"question.questionId\" [compareWith]=\"compareCodedValues\"\n            [multiple]=\"question.multiChoice\">\n            <mat-label class=\"mat-caption\" *ngIf=\"nestedQuestion\"><span *ngIf=\"question.required\">*&nbsp;</span><span\n                *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n              translate}}{{questionLastChar}}</mat-label>\n\n            <mat-option *ngFor=\"let permittedAnswer of castAnswers(question.permittedAnswers)\"\n              [value]=\"permittedAnswer.value\">\n              {{permittedAnswer.label | translate}}\n            </mat-option>\n          </mat-select>\n        </mat-form-field>\n      </div>\n\n      <div class=\"flex-1\"\n        [ngClass]=\"{'d-flex flex-column': question.type === types.string || question.type === types.text}\"\n        *ngIf=\"!question.hasClosedAnswer()\">\n        <!-- risposta chiusa di tipo boolean -->\n        <ng-container *ngIf=\"question.type == types.boolean\">\n          <mat-label class=\"mat-caption\" *ngIf=\"nestedQuestion\"><span *ngIf=\"question.required\">*&nbsp;</span><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <section [ngClass]=\"{'vertical-radio-group' : !smallQuestionColumn}\">\n            <!-- if it is required we can't use a checkbox as it becomes mandatory to check it to valdiate the form -->\n            <mat-checkbox *ngIf=\"!question.required\" [formControlName]=\"question.questionId\"></mat-checkbox>\n\n            <!-- FORM: <small>{{ form.get(question.questionId) | json}}</small><br> -->\n            <mat-radio-group *ngIf=\"question.required\" [formControlName]=\"question.questionId\">\n              <mat-radio-button [value]=\"true\">{{ 'questionnaire.boolean.true' | translate}}</mat-radio-button>\n              <mat-radio-button [value]=\"false\">{{ 'questionnaire.boolean.false' | translate}}</mat-radio-button>\n            </mat-radio-group>\n          </section>\n        </ng-container>\n\n        <!-- risposta aperta di tipo number -->\n        <mat-form-field *ngIf=\"(question.type === types.integer) || (question.type === types.decimal)\"\n          [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <input matInput [formControlName]=\"question.questionId\" type=\"number\"\n            placeholder=\"{{ numericQuestionPlaceholder(question) }}\">\n          <mat-error\n            *ngIf=\"form.get(question.questionId)?.hasError('min') || form.get(question.questionId)?.hasError('max')\">{{('msg.invalid_range'\n            | subtranslate:lang) }} ({{ numericQuestionPlaceholder(question) }})</mat-error>\n          <mat-error *ngIf=\"form.get(question.questionId)?.hasError('pattern')\">{{ 'msg.invalid_number_type' |\n            subtranslate:lang }}</mat-error>\n        </mat-form-field>\n\n        <!-- risposta aperta di tipo text (long text) -->\n        <mat-form-field *ngIf=\"(question.type === types.text)\" [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <textarea matInput [formControlName]=\"question.questionId\" cdkTextareaAutosize cdkAutosizeMinRows=\"2\"\n            cdkAutosizeMaxRows=\"5\" [attr.maxlength]=\"question.maxLength\"></textarea>\n        </mat-form-field>\n\n        <!-- risposta aperta di tipo string (short text) -->\n        <mat-form-field *ngIf=\"(question.type === types.string)\" [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <input matInput [formControlName]=\"question.questionId\" type=\"text\">\n        </mat-form-field>\n\n        <!-- risposta aperta di tipo Date o DateTime -->\n        <mat-form-field *ngIf=\"(question.type === types.date)\" [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <input matInput readonly [matDatepicker]=\"picker\" [formControlName]=\"question.questionId\" />\n          <mat-datepicker-toggle matIconSuffix [for]=\"picker\"></mat-datepicker-toggle>\n          <mat-datepicker #picker></mat-datepicker>\n        </mat-form-field>\n\n        <!-- risposta aperta di tipo CodedValue senza permittedAnswer (serve solo se viene forzato un valore senza definire le possibili alternative) -->\n        <mat-form-field *ngIf=\"(question.type === types.CodedValue) && question.readOnly\" [appearance]=\"appearance\">\n          <mat-label *ngIf=\"nestedQuestion\"><span\n              *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>{{question.text |\n            translate}}{{questionLastChar}}</mat-label>\n\n          <input matInput [formControlName]=\"question.questionId\" type=\"string\">\n        </mat-form-field>\n      </div>\n\n      <div *ngFor=\"let item of question.items\">\n        <heart-dyn-built-questionnaire-section-editor-question [questionLastChar]=\"questionLastChar\"\n          [smallQuestionColumn]=\"smallQuestionColumn\" [maxValuesForRadio]=\"maxValuesForRadio\"\n          [forceRadioButton]=\"forceRadioButton\" [appearance]=\"appearance\" [lang]=\"lang\"\n          [form]=\"asFormGroup(form.get(question.questionId))\" [nestedQuestion]=\"true\"\n          [question]=\"item\"></heart-dyn-built-questionnaire-section-editor-question>\n      </div>\n\n    </div>\n\n  </ng-container>\n\n  <!-- domanda di tipo 'display' -->\n  <span *ngIf=\"(question.type === types.display)\" class=\"mat-caption mb-2\">{{ question.text | translate }}</span>\n</div>", styles: [".questionnaire{min-width:400px}.questionnaire .question{overflow-wrap:break-word;font-weight:bolder;opacity:.8}.group-box{border-style:solid;border-width:1px;border-color:#00000061;border-radius:4px}.responsive-row{flex-direction:row;align-items:baseline}.title{font-weight:600}@media screen and (max-width: 768px){.gutter{column-gap:0}.responsive-row{flex-direction:column;align-items:stretch;column-gap:0}}mat-radio-button{margin-right:16px!important}.question.question-highlight{font-weight:700}.vertical-radio-group{display:flex;flex-direction:column;align-items:flex-start}\n"] }]
        }], ctorParameters: function () { return [{ type: DynBuiltQuestionSectionEditorService }]; }, propDecorators: { question: [{
                type: Input
            }], form: [{
                type: Input
            }], smallQuestionColumn: [{
                type: Input
            }], maxValuesForRadio: [{
                type: Input
            }], forceRadioButton: [{
                type: Input
            }], appearance: [{
                type: Input
            }], questionLastChar: [{
                type: Input
            }], lang: [{
                type: Input
            }], nestedQuestion: [{
                type: Input
            }] } });

class InstanceofPipe {
    transform(value, type) {
        return value instanceof type ? value : undefined;
    }
}
InstanceofPipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: InstanceofPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
InstanceofPipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: InstanceofPipe, name: "instanceof" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: InstanceofPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'instanceof',
                    pure: true,
                }]
        }] });

class DynBuiltQuestionnaireSectionEditorGroupComponent {
    constructor(editorService) {
        this.editorService = editorService;
        this.firstLevel = false;
        this.firstLevelGroupFormat = 'box';
        this.smallQuestionColumn = false; // manage the width of the question column and the rendering of the overall questionnaire
        this.maxValuesForRadio = 5; // [GUIDELINE] max value for switching options from Radio to Select
        this.forceRadioButton = false; // render options only as Radio Button
        this.appearance = 'outline';
        this.questionLastChar = "?"; // last char to be added to questions
        this.types = QuestionType;
        this.Question = Question;
        this.QuestionGroup = QuestionGroup;
        this.AnswerGroup = AnswerGroup;
    }
    ngOnInit() {
    }
    createFormArrayGroup(parentGroup, item, answerItem) {
        this.editorService.createFormArrayGroup(parentGroup, item, answerItem);
    }
    removeFormArrayGroup(parentGroup, indexToRemove) {
        this.editorService.removeFormArrayGroup(parentGroup, indexToRemove);
    }
    asFormGroup(formControl) {
        return formControl;
    }
    asFormArray(formControl) {
        return formControl;
    }
    asFormArrayControls(formControl) {
        return formControl.controls;
    }
    addAnswers(item, answerItems) {
        const parentGroup = this.asFormArray(this.form?.controls[0]);
        // item è sempre fisso per questo scenario
        answerItems.forEach(answerItem => {
            this.editorService.createFormArrayGroup(parentGroup, item, answerItem);
        });
        console.log(this.form);
    }
}
DynBuiltQuestionnaireSectionEditorGroupComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DynBuiltQuestionnaireSectionEditorGroupComponent, deps: [{ token: DynBuiltQuestionSectionEditorService }], target: i0.ɵɵFactoryTarget.Component });
DynBuiltQuestionnaireSectionEditorGroupComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: DynBuiltQuestionnaireSectionEditorGroupComponent, selector: "heart-dyn-built-questionnaire-section-editor-group", inputs: { group: "group", form: "form", firstLevel: "firstLevel", firstLevelGroupFormat: "firstLevelGroupFormat", smallQuestionColumn: "smallQuestionColumn", maxValuesForRadio: "maxValuesForRadio", forceRadioButton: "forceRadioButton", appearance: "appearance", questionLastChar: "questionLastChar", lang: "lang" }, ngImport: i0, template: "<ng-container *ngIf=\"!group.repeated\" [formGroup]=\"form\">\n\n  <!-- [ngClass]=\"{ 'group-box': !firstLevel || (firstLevel && firstLevelGroupFormat == 'box'), 'card': !firstLevel || (firstLevel && firstLevelGroupFormat == 'card'), 'p-3': !firstLevel || (firstLevel && firstLevelGroupFormat != 'none') }\" -->\n  <div class=\"flex-1 d-flex flex-column mt-2 mb-2\"\n\n    [formGroupName]=\"group.groupId\">\n\n    <!-- <h3 class=\"mat-mdc-card-subtitle\" *ngIf=\"!firstLevel || (firstLevel && (firstLevelGroupFormat == 'box' || firstLevelGroupFormat == 'card'))\">{{ group.text | translate }}</h3> -->\n\n    <!-- per ogni domanda -->\n    <ng-container *ngFor=\"let item of group?.items\">\n      <ng-container *ngIf=\"item | instanceof: Question as q\">\n\n        <heart-dyn-built-questionnaire-section-editor-question\n          [questionLastChar]=\"questionLastChar\"\n          [smallQuestionColumn]=\"smallQuestionColumn\"\n          [maxValuesForRadio]=\"maxValuesForRadio\"\n          [forceRadioButton]=\"forceRadioButton\"\n          [appearance]=\"appearance\"\n          [lang]=\"lang\"\n          [nestedQuestion]=\"false\"\n          [form]=\"asFormGroup(form.get(group.groupId))\"\n          [question]=\"q\"></heart-dyn-built-questionnaire-section-editor-question>\n      </ng-container>\n\n      <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n        <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form.get(group.groupId), firstLevel: false }\"></ng-container> -->\n        <heart-dyn-built-questionnaire-section-editor-group\n          [questionLastChar]=\"questionLastChar\"\n          [smallQuestionColumn]=\"smallQuestionColumn\"\n          [maxValuesForRadio]=\"maxValuesForRadio\"\n          [forceRadioButton]=\"forceRadioButton\"\n          [appearance]=\"appearance\"\n          [lang]=\"lang\"\n          [form]=\"asFormGroup(form.get(group.groupId))\"\n          [firstLevel]=\"false\"\n          [group]=\"g\"></heart-dyn-built-questionnaire-section-editor-group>\n      </ng-container>\n    </ng-container>\n  </div>\n</ng-container>\n\n<!-- Manage editing for repeatable form groups -->\n<ng-container *ngIf=\"group.repeated\" [formGroup]=\"form\">\n  <!-- TODO: NB rimosso per questo componente ridisegnato -->\n  <!-- [ngClass]=\"{ 'group-box': !firstLevel || (firstLevel && firstLevelGroupFormat == 'box'), 'card': !firstLevel || (firstLevel && firstLevelGroupFormat == 'card'), 'p-3': !firstLevel || (firstLevel && firstLevelGroupFormat != 'none') }\" -->\n  <!-- mt-2 mb-2 -->\n  <div\n    class=\"flex-1 d-flex flex-column\"\n    [formArrayName]=\"group.groupId\">\n\n    <!-- TODO: NB rimosso per questo componente ridisegnato -->\n    <!-- <h3 class=\"mat-mdc-card-subtitle\" *ngIf=\"!firstLevel || (firstLevel && [ 'box', 'card', 'none'].includes(firstLevelGroupFormat))\">{{ group.text | translate }}</h3> -->\n\n    <!-- per ogni domanda -->\n    <ng-container *ngFor=\"let control of asFormArrayControls(form.get(group.groupId)); index as i\">\n      <div class=\"group-box mb-2 p-1\">\n        <!-- <div class=\"d-flex flex-justify-end\">\n          <button mat-icon-button color=\"primary\" (click)=\"removeFormArrayGroup(asFormArray(form.get(group.groupId)), i)\"><mat-icon>delete</mat-icon></button>\n        </div> -->\n\n        <ng-container *ngFor=\"let item of group?.items; let j = index\">\n          <ng-container *ngIf=\"j == 0 && item | instanceof: Question as q\">\n            <!-- TODO: NB rimosso per questo componente ridisegnato -->\n            <!-- mt-2 mb-2 -->\n\n            <div class=\"d-flex flex-row flex-justify-between flex-content-center\">\n              <span class=\"title flex-self-center\">{{asFormGroup(control).get(q.questionId)?.value?.display | translate}}</span>\n              <button mat-icon-button color=\"primary\" (click)=\"removeFormArrayGroup(asFormArray(form.get(group.groupId)), i)\"><mat-icon>delete</mat-icon></button>\n            </div>\n          </ng-container>\n\n          <ng-container *ngIf=\"j > 0 && item | instanceof: Question as q\">\n            <heart-dyn-built-questionnaire-section-editor-question\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [nestedQuestion]=\"false\"\n              [form]=\"asFormGroup(control)\"\n              [question]=\"q\"></heart-dyn-built-questionnaire-section-editor-question>\n          </ng-container>\n\n          <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n            <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form.get(group.groupId), firstLevel: false }\"></ng-container>  -->\n            <heart-dyn-built-questionnaire-section-editor-group\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [form]=\"asFormGroup(control)\"\n              [firstLevel]=\"false\"\n              [group]=\"g\"></heart-dyn-built-questionnaire-section-editor-group>\n          </ng-container>\n        </ng-container>\n      </div>\n    </ng-container>\n\n    <div class=\"d-flex flex-justify-end\">\n      <!-- L'utente qui non pu\u00F2 aggiungerle da pulsante, ma deve passare per un altro componente (e.g. il TreeView) -->\n      <!-- <button mat-raised-button color=\"primary\" (click)=\"createFormArrayGroup(asFormArray(form.get(group.groupId)), group, undefined)\">{{ 'questionnaire.button.add.label' | subtranslate:lang }}</button> -->\n    </div>\n  </div>\n</ng-container>\n", styles: [".questionnaire{min-width:400px}.questionnaire .question{overflow-wrap:break-word;font-weight:bolder;opacity:.8}.group-box{border-style:solid;border-width:1px;border-color:#00000061;border-radius:4px}.responsive-row{flex-direction:row;align-items:baseline}.title{font-weight:600}@media screen and (max-width: 768px){.gutter{column-gap:0}.responsive-row{flex-direction:column;align-items:stretch;column-gap:0}}mat-radio-button{margin-right:16px!important}\n"], dependencies: [{ kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: i10.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i10.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i10.FormGroupName, selector: "[formGroupName]", inputs: ["formGroupName"] }, { kind: "directive", type: i10.FormArrayName, selector: "[formArrayName]", inputs: ["formArrayName"] }, { kind: "component", type: i5$1.MatIconButton, selector: "button[mat-icon-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: DynBuiltQuestionnaireSectionEditorQuestionComponent, selector: "heart-dyn-built-questionnaire-section-editor-question", inputs: ["question", "form", "smallQuestionColumn", "maxValuesForRadio", "forceRadioButton", "appearance", "questionLastChar", "lang", "nestedQuestion"] }, { kind: "component", type: DynBuiltQuestionnaireSectionEditorGroupComponent, selector: "heart-dyn-built-questionnaire-section-editor-group", inputs: ["group", "form", "firstLevel", "firstLevelGroupFormat", "smallQuestionColumn", "maxValuesForRadio", "forceRadioButton", "appearance", "questionLastChar", "lang"] }, { kind: "pipe", type: i1$1.TranslatePipe, name: "translate" }, { kind: "pipe", type: InstanceofPipe, name: "instanceof" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DynBuiltQuestionnaireSectionEditorGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-dyn-built-questionnaire-section-editor-group', template: "<ng-container *ngIf=\"!group.repeated\" [formGroup]=\"form\">\n\n  <!-- [ngClass]=\"{ 'group-box': !firstLevel || (firstLevel && firstLevelGroupFormat == 'box'), 'card': !firstLevel || (firstLevel && firstLevelGroupFormat == 'card'), 'p-3': !firstLevel || (firstLevel && firstLevelGroupFormat != 'none') }\" -->\n  <div class=\"flex-1 d-flex flex-column mt-2 mb-2\"\n\n    [formGroupName]=\"group.groupId\">\n\n    <!-- <h3 class=\"mat-mdc-card-subtitle\" *ngIf=\"!firstLevel || (firstLevel && (firstLevelGroupFormat == 'box' || firstLevelGroupFormat == 'card'))\">{{ group.text | translate }}</h3> -->\n\n    <!-- per ogni domanda -->\n    <ng-container *ngFor=\"let item of group?.items\">\n      <ng-container *ngIf=\"item | instanceof: Question as q\">\n\n        <heart-dyn-built-questionnaire-section-editor-question\n          [questionLastChar]=\"questionLastChar\"\n          [smallQuestionColumn]=\"smallQuestionColumn\"\n          [maxValuesForRadio]=\"maxValuesForRadio\"\n          [forceRadioButton]=\"forceRadioButton\"\n          [appearance]=\"appearance\"\n          [lang]=\"lang\"\n          [nestedQuestion]=\"false\"\n          [form]=\"asFormGroup(form.get(group.groupId))\"\n          [question]=\"q\"></heart-dyn-built-questionnaire-section-editor-question>\n      </ng-container>\n\n      <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n        <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form.get(group.groupId), firstLevel: false }\"></ng-container> -->\n        <heart-dyn-built-questionnaire-section-editor-group\n          [questionLastChar]=\"questionLastChar\"\n          [smallQuestionColumn]=\"smallQuestionColumn\"\n          [maxValuesForRadio]=\"maxValuesForRadio\"\n          [forceRadioButton]=\"forceRadioButton\"\n          [appearance]=\"appearance\"\n          [lang]=\"lang\"\n          [form]=\"asFormGroup(form.get(group.groupId))\"\n          [firstLevel]=\"false\"\n          [group]=\"g\"></heart-dyn-built-questionnaire-section-editor-group>\n      </ng-container>\n    </ng-container>\n  </div>\n</ng-container>\n\n<!-- Manage editing for repeatable form groups -->\n<ng-container *ngIf=\"group.repeated\" [formGroup]=\"form\">\n  <!-- TODO: NB rimosso per questo componente ridisegnato -->\n  <!-- [ngClass]=\"{ 'group-box': !firstLevel || (firstLevel && firstLevelGroupFormat == 'box'), 'card': !firstLevel || (firstLevel && firstLevelGroupFormat == 'card'), 'p-3': !firstLevel || (firstLevel && firstLevelGroupFormat != 'none') }\" -->\n  <!-- mt-2 mb-2 -->\n  <div\n    class=\"flex-1 d-flex flex-column\"\n    [formArrayName]=\"group.groupId\">\n\n    <!-- TODO: NB rimosso per questo componente ridisegnato -->\n    <!-- <h3 class=\"mat-mdc-card-subtitle\" *ngIf=\"!firstLevel || (firstLevel && [ 'box', 'card', 'none'].includes(firstLevelGroupFormat))\">{{ group.text | translate }}</h3> -->\n\n    <!-- per ogni domanda -->\n    <ng-container *ngFor=\"let control of asFormArrayControls(form.get(group.groupId)); index as i\">\n      <div class=\"group-box mb-2 p-1\">\n        <!-- <div class=\"d-flex flex-justify-end\">\n          <button mat-icon-button color=\"primary\" (click)=\"removeFormArrayGroup(asFormArray(form.get(group.groupId)), i)\"><mat-icon>delete</mat-icon></button>\n        </div> -->\n\n        <ng-container *ngFor=\"let item of group?.items; let j = index\">\n          <ng-container *ngIf=\"j == 0 && item | instanceof: Question as q\">\n            <!-- TODO: NB rimosso per questo componente ridisegnato -->\n            <!-- mt-2 mb-2 -->\n\n            <div class=\"d-flex flex-row flex-justify-between flex-content-center\">\n              <span class=\"title flex-self-center\">{{asFormGroup(control).get(q.questionId)?.value?.display | translate}}</span>\n              <button mat-icon-button color=\"primary\" (click)=\"removeFormArrayGroup(asFormArray(form.get(group.groupId)), i)\"><mat-icon>delete</mat-icon></button>\n            </div>\n          </ng-container>\n\n          <ng-container *ngIf=\"j > 0 && item | instanceof: Question as q\">\n            <heart-dyn-built-questionnaire-section-editor-question\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [nestedQuestion]=\"false\"\n              [form]=\"asFormGroup(control)\"\n              [question]=\"q\"></heart-dyn-built-questionnaire-section-editor-question>\n          </ng-container>\n\n          <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n            <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form.get(group.groupId), firstLevel: false }\"></ng-container>  -->\n            <heart-dyn-built-questionnaire-section-editor-group\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [form]=\"asFormGroup(control)\"\n              [firstLevel]=\"false\"\n              [group]=\"g\"></heart-dyn-built-questionnaire-section-editor-group>\n          </ng-container>\n        </ng-container>\n      </div>\n    </ng-container>\n\n    <div class=\"d-flex flex-justify-end\">\n      <!-- L'utente qui non pu\u00F2 aggiungerle da pulsante, ma deve passare per un altro componente (e.g. il TreeView) -->\n      <!-- <button mat-raised-button color=\"primary\" (click)=\"createFormArrayGroup(asFormArray(form.get(group.groupId)), group, undefined)\">{{ 'questionnaire.button.add.label' | subtranslate:lang }}</button> -->\n    </div>\n  </div>\n</ng-container>\n", styles: [".questionnaire{min-width:400px}.questionnaire .question{overflow-wrap:break-word;font-weight:bolder;opacity:.8}.group-box{border-style:solid;border-width:1px;border-color:#00000061;border-radius:4px}.responsive-row{flex-direction:row;align-items:baseline}.title{font-weight:600}@media screen and (max-width: 768px){.gutter{column-gap:0}.responsive-row{flex-direction:column;align-items:stretch;column-gap:0}}mat-radio-button{margin-right:16px!important}\n"] }]
        }], ctorParameters: function () { return [{ type: DynBuiltQuestionSectionEditorService }]; }, propDecorators: { group: [{
                type: Input
            }], form: [{
                type: Input
            }], firstLevel: [{
                type: Input
            }], firstLevelGroupFormat: [{
                type: Input
            }], smallQuestionColumn: [{
                type: Input
            }], maxValuesForRadio: [{
                type: Input
            }], forceRadioButton: [{
                type: Input
            }], appearance: [{
                type: Input
            }], questionLastChar: [{
                type: Input
            }], lang: [{
                type: Input
            }] } });

class DynBuiltQuestionnaireSectionEditorComponent {
    constructor(editorService) {
        this.editorService = editorService;
        this.questionnaireResponseChange = new EventEmitter();
        this.firstLevelGroupFormat = 'box';
        this.appearance = 'outline';
        this.questionLastChar = "?"; // last char to be added to questions
        this.smallQuestionColumn = false; // manage the width of the question column and the rendering of the overall questionnaire
        this.maxValuesForRadio = 5; // [GUIDELINE] max value for switching options from Radio to Select
        this.forceRadioButton = false; // render options only as Radio Button
        // @Output() public formChange = new EventEmitter<FormGroup>();
        this.validate = new EventEmitter();
        // supporting structure to track if a form group is pre-initialized
        this.rootGroupAvailabilities = {};
        // protected readonly types = QuestionType;
        this.Question = Question;
        this.QuestionGroup = QuestionGroup;
        this.AnswerGroup = AnswerGroup;
        // used to avoid the error 'Expression has changed after it was checked' on the Editor action buttons
        this.viewInitialized = false;
        this.numericQuestionPlaceholder = (question) => {
            return [question.min, question.max].filter(v => v != undefined).join(' - ') || '';
        };
    }
    ngOnInit() {
        this.viewInitialized = false;
        const form = this.editorService.createForm(this.questionnaireResponse);
        // update the 'rootGroupAvailabilities' map
        this.rootGroupAvailabilities = this.createRootGroupAvailabilities(this.questionnaireResponse.answers);
        this.form = form;
        this.form.statusChanges.subscribe((status) => this.validate.emit(status));
    }
    ngAfterViewInit() {
        // this.formChange.emit(this.form);
        this.viewInitialized = true;
    }
    ngOnDestroy() {
        this.viewInitialized = false;
        this.rootGroupAvailabilities = {};
        this.form = undefined;
    }
    get formValid() {
        return this.form && this.viewInitialized && this.form.valid;
    }
    appendAnswerGroups(answersGroups, paths) {
        if (!(answersGroups?.length > 0)) {
            return;
        }
        const questionnaire = this.questionnaireResponse.questionnaire;
        // look for the QuestionGroup in the QuestionnaireResponse->Questionnaire
        let question = questionnaire;
        for (let index = 0; index < paths.length && question != undefined; index++) {
            const path = paths[index];
            question = question.items?.find(i => i.questionId == path);
        }
        if (!question) {
            throw Error(`Question item not found in the questionnaire. Check the path '${paths.join('.')}'`);
        }
        else if (!(question instanceof QuestionGroup)) {
            throw Error(`You can append only to QuestionGroup while you are currently referring the Question at '${paths.join('.')}'`);
        }
        // look for the FormArray in the FormGroup
        // const parentFormGroup: FormArray;
        if (!this.form) {
            throw Error(`The FormGroup is not available so you can't append items.`);
        }
        const parentFormGroup = this.form.get(paths);
        if (!parentFormGroup) {
            throw Error(`FormArray not found in the FormGroup. Check the path ` + paths.join('.'));
        }
        else if (!(parentFormGroup instanceof FormArray)) {
            throw Error(`You can append only to FormArray while you are currently referring ${parentFormGroup}`);
        }
        answersGroups.forEach((answersGroup) => {
            this.editorService.createFormArrayGroup(parentFormGroup, question, answersGroup);
        });
        // force validation checks
        parentFormGroup.markAsTouched();
    }
    setEditFormGroup() {
        const form = this.editorService.createForm(this.questionnaireResponse);
        const questionItems = this.questionnaireResponse.questionnaire?.items;
        const answerItems = this.questionnaireResponse.answers;
        this._setEditFormGroup(questionItems, answerItems, form);
        // update the 'rootGroupAvailabilities' map
        this.rootGroupAvailabilities = this.createRootGroupAvailabilities(answerItems);
        this.form = form;
    }
    createRootGroupAvailabilities(answers) {
        const rootGroup = {};
        answers
            ?.filter(answer => answer instanceof AnswerGroup)
            ?.forEach(answer => {
            if (answer.answers?.length > 0)
                rootGroup[answer.groupId] = true;
        });
        return rootGroup;
    }
    _setEditFormGroup(questionItems, answerItems, form) {
        questionItems?.forEach(qItem => {
            const answer = answerItems?.find(aItem => this.editorService.matchQuestionAndAnswer(qItem, aItem));
            if (qItem instanceof Question) {
                // look for the 'answer/answerGroup' matching the question item to get its value and setup the form
                this._setEditFormControl(qItem, answer, form);
            }
            else if (qItem instanceof QuestionGroup && (answer instanceof AnswerGroup)) {
                // support group
                this._setEditFormGroup(qItem.items, answer.answers, form.get(qItem.groupId));
            }
        });
    }
    _setEditFormControl(question, answer, form) {
        if (answer) {
            if (answer instanceof Answer && question instanceof Question) {
                if (question.permittedAnswers?.length > 0) {
                    const c = question.permittedAnswers.find(pa => {
                        if (pa.value instanceof CodedValue) {
                            return pa.value.code == answer.value.code;
                        }
                        else {
                            return pa.value == answer.value;
                        }
                    });
                    form.get(question.questionId).setValue(c);
                }
                else if (answer instanceof Answer && answer.answers?.length > 0 && question instanceof Question) {
                    const answerItems = answer.answers;
                    const nestedForm = form.get(question.questionId);
                    nestedForm.get(question.questionId).setValue(answer.value);
                    question.items?.forEach(qItem => {
                        const answer = answerItems?.find(aItem => this.editorService.matchQuestionAndAnswer(qItem, aItem));
                        this._setEditFormControl(qItem, answer, nestedForm);
                    });
                }
                else {
                    form.get(question.questionId).setValue(answer.value);
                }
            }
        }
        else {
            form.get(question.questionId)?.reset();
        }
    }
    /**
     * Legge le risposte fornite dall'utente e le salva
     * in una istanza di Response associata al Questionnaire
     */
    onSubmit(arg) {
        if (this.form?.valid) {
            const newQuestionnaireResponse = this.prepareQuestionnaireResponse();
            this.questionnaireResponse = newQuestionnaireResponse;
            this.questionnaireResponseChange.emit(this.questionnaireResponse);
            // FIXME: informare tutti gli utilizzatori del modulo che vorremmo modificare la logica dell'editMode per fare in modo che venga settato dall'esterno solo su successo dello store
            // this.editMode = false;
            // this.modeChange(this.editMode);
        }
    }
    /**
     * Provides a new instance of QuestionnaireResponse with the raw values available in the form.
     *
     * @returns
     */
    prepareQuestionnaireResponse() {
        // verifica tutte le risposte date dall'utente
        const answers = this.questionnaireResponse?.questionnaire
            ?.items
            .flatMap(item => {
            if (item instanceof QuestionGroup) {
                // add some sort of grouping for Anwsers to preserve the Questionnaire nesting
                return this.prepareAnswerGroup(this.form.get(item.groupId), item);
            }
            else {
                return this.prepareAnswer(this.form, item);
            }
        })
            // remove any 'undefined' answer
            .filter(a => a != undefined);
        // ID in case of update
        const oldId = this.questionnaireResponse.id;
        const newQuestionnaireResponse = new QuestionnaireResponse(this.questionnaireResponse.questionnaire);
        newQuestionnaireResponse.answers = answers;
        newQuestionnaireResponse.status = ResponseStatus.completed;
        newQuestionnaireResponse.id = oldId;
        return newQuestionnaireResponse;
    }
    prepareAnswerGroup(currentForm, item) {
        if (currentForm instanceof FormArray) {
            const answers = currentForm.controls
                .flatMap(c => this.prepareAnswerGroup(c, item))
                // remove any 'undefined' answer
                .filter(a => a != undefined);
            // return a the RepeatedAnswerGroup only of it has at least 1 instance
            return answers?.length > 0 ? answers : undefined;
        }
        else {
            const answer = new AnswerGroup();
            answer.groupId = item.groupId;
            // manage recursion to support 'QuestionGroup' submit
            answer.answers = item?.items?.flatMap(item => {
                if (item instanceof QuestionGroup) {
                    // add some sort of grouping for Anwsers to preserve the Questionnaire nesting
                    return this.prepareAnswerGroup(currentForm.get(item.groupId), item);
                }
                else {
                    return this.prepareAnswer(currentForm, item);
                }
            })
                // remove any 'undefined' answer
                .filter(a => a != undefined);
            ;
            return answer;
        }
    }
    prepareAnswer(currentForm, question) {
        if (question.type == QuestionType.display) {
            return undefined;
        }
        const questionPath = question.questionId;
        // if has nested items
        const hasNestedItems = question.items?.length > 0;
        if (hasNestedItems) {
            currentForm = currentForm.get(question.questionId);
        }
        let value = undefined;
        if (question.type === QuestionType.CodedValue || question.permittedAnswers?.length > 0) {
            // if 'question.multiChoice == true' then the expected value is a CodedValue array
            value = currentForm.get(questionPath)?.value;
        }
        else if (question.type === QuestionType.integer) {
            value = currentForm.get(questionPath)?.value;
            if (value != undefined) {
                // force rounding to integer
                value = +(value.toFixed());
            }
        }
        else if (question.type === QuestionType.decimal) {
            value = currentForm.get(questionPath)?.value;
            // FIXME: ensure that a decimal number is not
            // if ( value != undefined ) {
            // }
        }
        else if (question.type === QuestionType.text || question.type === QuestionType.string) {
            value = currentForm.get(questionPath)?.value;
            if (value) {
                value = value.trim();
            }
        }
        else if (question.type === QuestionType.boolean) {
            value = currentForm.get(questionPath)?.value == true;
        }
        else if (question.type === QuestionType.date /*|| question.type === QuestionType.dateTime*/) {
            value = currentForm.get(questionPath)?.value;
            // } else {
            //   throw new Error(`Type ${question.type.toString()} not supported. Impossible to fetch the value.`);
        }
        if (value != undefined) {
            const a = new Answer();
            a.questionId = question.questionId;
            a.value = value;
            if (hasNestedItems) {
                a.answers = question.items?.map((nestedQuestion) => {
                    return this.prepareAnswer(currentForm, nestedQuestion);
                });
            }
            return a;
        }
        return undefined;
    }
}
DynBuiltQuestionnaireSectionEditorComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DynBuiltQuestionnaireSectionEditorComponent, deps: [{ token: DynBuiltQuestionSectionEditorService }], target: i0.ɵɵFactoryTarget.Component });
DynBuiltQuestionnaireSectionEditorComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: DynBuiltQuestionnaireSectionEditorComponent, selector: "heart-dyn-built-questionnaire-section-editor", inputs: { questionnaireResponse: "questionnaireResponse", firstLevelGroupFormat: "firstLevelGroupFormat", appearance: "appearance", questionLastChar: "questionLastChar", lang: "lang", smallQuestionColumn: "smallQuestionColumn", maxValuesForRadio: "maxValuesForRadio", forceRadioButton: "forceRadioButton" }, outputs: { questionnaireResponseChange: "questionnaireResponseChange", validate: "validate" }, ngImport: i0, template: "<form *ngIf=\"form\" [formGroup]=\"form\" (ngSubmit)=\"form.valid && onSubmit($event)\" class=\"xcard\">\n  <div class=\"d-flex flex-column questions\">\n\n    <!-- Deafult rendering structure-->\n    <ng-container *ngIf=\"firstLevelGroupFormat == 'box' || firstLevelGroupFormat == 'none' || firstLevelGroupFormat == 'card'\">\n      <!-- per ogni domanda -->\n      <div *ngFor=\"let item of questionnaireResponse?.questionnaire?.items\">\n\n        <ng-container *ngIf=\"item | instanceof: Question as q\">\n          <heart-dyn-built-questionnaire-section-editor-question\n            [questionLastChar]=\"questionLastChar\"\n            [smallQuestionColumn]=\"smallQuestionColumn\"\n            [maxValuesForRadio]=\"maxValuesForRadio\"\n            [forceRadioButton]=\"forceRadioButton\"\n            [appearance]=\"appearance\"\n            [lang]=\"lang\"\n            [nestedQuestion]=\"false\"\n            [form]=\"form\"\n            [question]=\"q\"></heart-dyn-built-questionnaire-section-editor-question>\n        </ng-container>\n\n        <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n          <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form, firstLevel: true }\"></ng-container> -->\n          <heart-dyn-built-questionnaire-section-editor-group\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [firstLevelGroupFormat]=\"firstLevelGroupFormat\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [form]=\"form\"\n              [firstLevel]=\"true\"\n              [group]=\"g\"></heart-dyn-built-questionnaire-section-editor-group>\n        </ng-container>\n\n      </div>\n    </ng-container>\n\n    <!-- Render the first level question grups as tabs -->\n    <ng-container *ngIf=\"firstLevelGroupFormat == 'expansion'\">\n      <mat-accordion>\n        <!-- per ogni domanda -->\n        <!--IGNORES questions without a group-->\n        <!--ng-container *ngIf=\"item | instanceof: Question as q\">\n          <ng-container *ngTemplateOutlet=\"editquestion; context: { $implicit: q, form: form }\"></ng-container>\n          <heart-dyn-built-questionnaire-section-editor-question\n            [questionLastChar]=\"questionLastChar\"\n            [smallQuestionColumn]=\"smallQuestionColumn\"\n            [maxValuesForRadio]=\"maxValuesForRadio\"\n            [forceRadioButton]=\"forceRadioButton\"\n            [appearance]=\"appearance\"\n            [lang]=\"lang\"\n            [nestedQuestion]=\"false\"\n            [form]=\"form\"\n            [question]=\"q\"></heart-dyn-built-questionnaire-section-editor-question>\n        </ng-container-->\n\n        <ng-container *ngFor=\"let item of questionnaireResponse?.questionnaire?.items\">\n          <mat-expansion-panel *ngIf=\"item | instanceof: QuestionGroup as g\">\n            <mat-expansion-panel-header>\n              <mat-panel-title class=\"title\" [ngClass]=\"{ 'expansion-title-highlight': form.get(g.groupId).dirty}\">\n                <mat-icon *ngIf=\"form.get(g.groupId).dirty && !form.get(g.groupId).valid\" color=\"warn\">warning</mat-icon>\n                {{ g?.text | translate }}\n                <span *ngIf=\"form.get(g.groupId).dirty\" color=\"accent\">&nbsp;({{( 'questionnaire.expansion.title.edited.label' ) | subtranslate:lang }})</span>\n              </mat-panel-title>\n              <mat-panel-description>\n                <mat-label *ngIf=\"rootGroupAvailabilities[g.groupId]\">{{( 'questionnaire.expansion.description.available.label' ) | subtranslate:lang }}</mat-label>\n              </mat-panel-description>\n            </mat-expansion-panel-header>\n\n            <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form, firstLevel: true }\"></ng-container> -->\n            <heart-dyn-built-questionnaire-section-editor-group\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [firstLevelGroupFormat]=\"firstLevelGroupFormat\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [form]=\"form\"\n              [firstLevel]=\"true\"\n              [group]=\"g\"></heart-dyn-built-questionnaire-section-editor-group>\n          </mat-expansion-panel>\n        </ng-container>\n      </mat-accordion>\n    </ng-container>\n\n    <!-- Render the first level question grups as tabs -->\n    <ng-container *ngIf=\"firstLevelGroupFormat == 'tab'\">\n      <mat-tab-group mat-stretch-tabs=\"false\" mat-align-tabs=\"start\">\n        <!-- per ogni domanda -->\n        <mat-tab *ngFor=\"let item of questionnaireResponse?.questionnaire?.items\">\n          <!--IGNORES questions without a group-->\n\n          <!--ng-container *ngIf=\"item | instanceof: Question as q\">\n            <ng-template mat-tab-label>{{ item?.name | translate }}</ng-template>\n\n\n            <heart-dyn-built-questionnaire-section-editor-question\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [nestedQuestion]=\"false\"\n              [form]=\"form\"\n              [question]=\"q\"></heart-dyn-built-questionnaire-section-editor-question>\n          </ng-container-->\n\n          <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n            <ng-template mat-tab-label>\n              <mat-icon *ngIf=\"form.get(g.groupId).dirty && !form.get(g.groupId).valid\" color=\"warn\">warning</mat-icon>\n              {{ g?.text | translate }}\n              <span *ngIf=\"form.get(g.groupId).dirty\" color=\"accent\">&nbsp;({{( 'questionnaire.expansion.title.edited.label' ) | subtranslate:lang }})</span>\n\n              <mat-label *ngIf=\"rootGroupAvailabilities[g.groupId]\">({{( 'questionnaire.expansion.description.available.label' ) | subtranslate:lang }})</mat-label>\n            </ng-template>\n\n            <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form, firstLevel: true }\"></ng-container> -->\n            <heart-dyn-built-questionnaire-section-editor-group\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [firstLevelGroupFormat]=\"firstLevelGroupFormat\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [form]=\"form\"\n              [firstLevel]=\"true\"\n              [group]=\"g\"></heart-dyn-built-questionnaire-section-editor-group>\n          </ng-container>\n        </mat-tab>\n      </mat-tab-group>\n    </ng-container>\n  </div>\n</form>\n\n\n", styles: [".questionnaire{min-width:400px}.questionnaire .question{overflow-wrap:break-word;font-weight:bolder;opacity:.8}.group-box{border-style:solid;border-width:1px;border-color:#00000061;border-radius:4px}.responsive-row{flex-direction:row;align-items:baseline}.title{font-weight:600}@media screen and (max-width: 768px){.gutter{column-gap:0}.responsive-row{flex-direction:column;align-items:stretch;column-gap:0}}mat-radio-button{margin-right:16px!important}.questionnaire .mat-mdc-radio-button .mdc-radio{padding:0!important}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i3.MatLabel, selector: "mat-label" }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: i10.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i10.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i10.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i3$2.MatAccordion, selector: "mat-accordion", inputs: ["multi", "hideToggle", "displayMode", "togglePosition"], exportAs: ["matAccordion"] }, { kind: "component", type: i3$2.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["disabled", "expanded", "hideToggle", "togglePosition"], outputs: ["opened", "closed", "expandedChange", "afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }, { kind: "component", type: i3$2.MatExpansionPanelHeader, selector: "mat-expansion-panel-header", inputs: ["tabIndex", "expandedHeight", "collapsedHeight"] }, { kind: "directive", type: i3$2.MatExpansionPanelTitle, selector: "mat-panel-title" }, { kind: "directive", type: i3$2.MatExpansionPanelDescription, selector: "mat-panel-description" }, { kind: "directive", type: i4$1.MatTabLabel, selector: "[mat-tab-label], [matTabLabel]" }, { kind: "component", type: i4$1.MatTab, selector: "mat-tab", inputs: ["disabled"], exportAs: ["matTab"] }, { kind: "component", type: i4$1.MatTabGroup, selector: "mat-tab-group", inputs: ["color", "disableRipple", "fitInkBarToContent", "mat-stretch-tabs"], exportAs: ["matTabGroup"] }, { kind: "component", type: DynBuiltQuestionnaireSectionEditorQuestionComponent, selector: "heart-dyn-built-questionnaire-section-editor-question", inputs: ["question", "form", "smallQuestionColumn", "maxValuesForRadio", "forceRadioButton", "appearance", "questionLastChar", "lang", "nestedQuestion"] }, { kind: "component", type: DynBuiltQuestionnaireSectionEditorGroupComponent, selector: "heart-dyn-built-questionnaire-section-editor-group", inputs: ["group", "form", "firstLevel", "firstLevelGroupFormat", "smallQuestionColumn", "maxValuesForRadio", "forceRadioButton", "appearance", "questionLastChar", "lang"] }, { kind: "pipe", type: i1$1.TranslatePipe, name: "translate" }, { kind: "pipe", type: i2$1.SubTranslatePipe, name: "subtranslate" }, { kind: "pipe", type: InstanceofPipe, name: "instanceof" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DynBuiltQuestionnaireSectionEditorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-dyn-built-questionnaire-section-editor', template: "<form *ngIf=\"form\" [formGroup]=\"form\" (ngSubmit)=\"form.valid && onSubmit($event)\" class=\"xcard\">\n  <div class=\"d-flex flex-column questions\">\n\n    <!-- Deafult rendering structure-->\n    <ng-container *ngIf=\"firstLevelGroupFormat == 'box' || firstLevelGroupFormat == 'none' || firstLevelGroupFormat == 'card'\">\n      <!-- per ogni domanda -->\n      <div *ngFor=\"let item of questionnaireResponse?.questionnaire?.items\">\n\n        <ng-container *ngIf=\"item | instanceof: Question as q\">\n          <heart-dyn-built-questionnaire-section-editor-question\n            [questionLastChar]=\"questionLastChar\"\n            [smallQuestionColumn]=\"smallQuestionColumn\"\n            [maxValuesForRadio]=\"maxValuesForRadio\"\n            [forceRadioButton]=\"forceRadioButton\"\n            [appearance]=\"appearance\"\n            [lang]=\"lang\"\n            [nestedQuestion]=\"false\"\n            [form]=\"form\"\n            [question]=\"q\"></heart-dyn-built-questionnaire-section-editor-question>\n        </ng-container>\n\n        <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n          <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form, firstLevel: true }\"></ng-container> -->\n          <heart-dyn-built-questionnaire-section-editor-group\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [firstLevelGroupFormat]=\"firstLevelGroupFormat\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [form]=\"form\"\n              [firstLevel]=\"true\"\n              [group]=\"g\"></heart-dyn-built-questionnaire-section-editor-group>\n        </ng-container>\n\n      </div>\n    </ng-container>\n\n    <!-- Render the first level question grups as tabs -->\n    <ng-container *ngIf=\"firstLevelGroupFormat == 'expansion'\">\n      <mat-accordion>\n        <!-- per ogni domanda -->\n        <!--IGNORES questions without a group-->\n        <!--ng-container *ngIf=\"item | instanceof: Question as q\">\n          <ng-container *ngTemplateOutlet=\"editquestion; context: { $implicit: q, form: form }\"></ng-container>\n          <heart-dyn-built-questionnaire-section-editor-question\n            [questionLastChar]=\"questionLastChar\"\n            [smallQuestionColumn]=\"smallQuestionColumn\"\n            [maxValuesForRadio]=\"maxValuesForRadio\"\n            [forceRadioButton]=\"forceRadioButton\"\n            [appearance]=\"appearance\"\n            [lang]=\"lang\"\n            [nestedQuestion]=\"false\"\n            [form]=\"form\"\n            [question]=\"q\"></heart-dyn-built-questionnaire-section-editor-question>\n        </ng-container-->\n\n        <ng-container *ngFor=\"let item of questionnaireResponse?.questionnaire?.items\">\n          <mat-expansion-panel *ngIf=\"item | instanceof: QuestionGroup as g\">\n            <mat-expansion-panel-header>\n              <mat-panel-title class=\"title\" [ngClass]=\"{ 'expansion-title-highlight': form.get(g.groupId).dirty}\">\n                <mat-icon *ngIf=\"form.get(g.groupId).dirty && !form.get(g.groupId).valid\" color=\"warn\">warning</mat-icon>\n                {{ g?.text | translate }}\n                <span *ngIf=\"form.get(g.groupId).dirty\" color=\"accent\">&nbsp;({{( 'questionnaire.expansion.title.edited.label' ) | subtranslate:lang }})</span>\n              </mat-panel-title>\n              <mat-panel-description>\n                <mat-label *ngIf=\"rootGroupAvailabilities[g.groupId]\">{{( 'questionnaire.expansion.description.available.label' ) | subtranslate:lang }}</mat-label>\n              </mat-panel-description>\n            </mat-expansion-panel-header>\n\n            <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form, firstLevel: true }\"></ng-container> -->\n            <heart-dyn-built-questionnaire-section-editor-group\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [firstLevelGroupFormat]=\"firstLevelGroupFormat\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [form]=\"form\"\n              [firstLevel]=\"true\"\n              [group]=\"g\"></heart-dyn-built-questionnaire-section-editor-group>\n          </mat-expansion-panel>\n        </ng-container>\n      </mat-accordion>\n    </ng-container>\n\n    <!-- Render the first level question grups as tabs -->\n    <ng-container *ngIf=\"firstLevelGroupFormat == 'tab'\">\n      <mat-tab-group mat-stretch-tabs=\"false\" mat-align-tabs=\"start\">\n        <!-- per ogni domanda -->\n        <mat-tab *ngFor=\"let item of questionnaireResponse?.questionnaire?.items\">\n          <!--IGNORES questions without a group-->\n\n          <!--ng-container *ngIf=\"item | instanceof: Question as q\">\n            <ng-template mat-tab-label>{{ item?.name | translate }}</ng-template>\n\n\n            <heart-dyn-built-questionnaire-section-editor-question\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [nestedQuestion]=\"false\"\n              [form]=\"form\"\n              [question]=\"q\"></heart-dyn-built-questionnaire-section-editor-question>\n          </ng-container-->\n\n          <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n            <ng-template mat-tab-label>\n              <mat-icon *ngIf=\"form.get(g.groupId).dirty && !form.get(g.groupId).valid\" color=\"warn\">warning</mat-icon>\n              {{ g?.text | translate }}\n              <span *ngIf=\"form.get(g.groupId).dirty\" color=\"accent\">&nbsp;({{( 'questionnaire.expansion.title.edited.label' ) | subtranslate:lang }})</span>\n\n              <mat-label *ngIf=\"rootGroupAvailabilities[g.groupId]\">({{( 'questionnaire.expansion.description.available.label' ) | subtranslate:lang }})</mat-label>\n            </ng-template>\n\n            <!-- <ng-container *ngTemplateOutlet=\"editgroup; context: { $implicit: g, form: form, firstLevel: true }\"></ng-container> -->\n            <heart-dyn-built-questionnaire-section-editor-group\n              [questionLastChar]=\"questionLastChar\"\n              [smallQuestionColumn]=\"smallQuestionColumn\"\n              [maxValuesForRadio]=\"maxValuesForRadio\"\n              [forceRadioButton]=\"forceRadioButton\"\n              [firstLevelGroupFormat]=\"firstLevelGroupFormat\"\n              [appearance]=\"appearance\"\n              [lang]=\"lang\"\n              [form]=\"form\"\n              [firstLevel]=\"true\"\n              [group]=\"g\"></heart-dyn-built-questionnaire-section-editor-group>\n          </ng-container>\n        </mat-tab>\n      </mat-tab-group>\n    </ng-container>\n  </div>\n</form>\n\n\n", styles: [".questionnaire{min-width:400px}.questionnaire .question{overflow-wrap:break-word;font-weight:bolder;opacity:.8}.group-box{border-style:solid;border-width:1px;border-color:#00000061;border-radius:4px}.responsive-row{flex-direction:row;align-items:baseline}.title{font-weight:600}@media screen and (max-width: 768px){.gutter{column-gap:0}.responsive-row{flex-direction:column;align-items:stretch;column-gap:0}}mat-radio-button{margin-right:16px!important}.questionnaire .mat-mdc-radio-button .mdc-radio{padding:0!important}\n"] }]
        }], ctorParameters: function () { return [{ type: DynBuiltQuestionSectionEditorService }]; }, propDecorators: { questionnaireResponse: [{
                type: Input
            }], questionnaireResponseChange: [{
                type: Output
            }], firstLevelGroupFormat: [{
                type: Input
            }], appearance: [{
                type: Input
            }], questionLastChar: [{
                type: Input
            }], lang: [{
                type: Input
            }], smallQuestionColumn: [{
                type: Input
            }], maxValuesForRadio: [{
                type: Input
            }], forceRadioButton: [{
                type: Input
            }], validate: [{
                type: Output
            }] } });

class DynBuiltQuestionnaireSectionViewerComponent {
    constructor() {
        this.appearance = 'outline';
        this.smallQuestionColumn = false; // manage the width of the question column and the rendering of the overall questionnaire
        this.emptyAnswerPlaceholder = "-"; // chars used for empty answers
        this.questionLastChar = "?"; // last char to be added to questions
        this.types = QuestionType;
        this.Question = Question;
        this.QuestionGroup = QuestionGroup;
        this.AnswerGroup = AnswerGroup;
    }
    ngOnInit() {
    }
    findAnswerByQuestion(answers, question) {
        if (!question) {
            return undefined;
        }
        return answers?.filter(a => a instanceof Answer).find(a => a.questionId == question.questionId);
    }
    findAnswerGroupByQuestionGroup(answers, questionGroup) {
        if (!questionGroup) {
            return undefined;
        }
        const ags = answers?.filter(a => a instanceof AnswerGroup)
            .filter(a => a.groupId == questionGroup.groupId);
        return questionGroup.repeated ? ags : ags.pop();
    }
    extractAnswerValue(answer, question) {
        // TODO: gestire le risposte come Choice[]
        if (answer && answer.value != undefined) {
            if (Array.isArray(question.permittedAnswers) && question.permittedAnswers?.length > 0) { // qui è per forza array di Choice, il connector si prende in carico la trasformazione ValueSetUrl -> Choice[]
                const pa = question.permittedAnswers.find(pa => {
                    if (pa.value instanceof CodedValue) {
                        return pa.value.code == answer.value.code;
                    }
                    else {
                        return pa.value == answer.value;
                    }
                });
                return pa.label;
            }
            else if ((answer.value instanceof CodedValue)) {
                return answer.value.display;
            }
            else {
                return answer.value;
            }
        }
        return this.emptyAnswerPlaceholder;
    }
    extractTextualAnswerValue(answer, question) {
        const value = this.extractAnswerValue(answer, question)?.toString();
        if (value) {
            if (typeof value == 'string' && value.length > 60) {
                return value.substring(0, 60) + "...";
            }
            else {
                return value + '';
            }
        }
        else {
            return this.emptyAnswerPlaceholder;
        }
    }
    extractDateAnswerValue(answer, question) {
        const value = this.extractAnswerValue(answer, question);
        if (value && ((value.toString()) != this.emptyAnswerPlaceholder)) {
            return value;
        }
        else {
            return '';
        }
    }
}
DynBuiltQuestionnaireSectionViewerComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DynBuiltQuestionnaireSectionViewerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
DynBuiltQuestionnaireSectionViewerComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: DynBuiltQuestionnaireSectionViewerComponent, selector: "heart-dyn-built-questionnaire-section-viewer", inputs: { questionnaireResponse: "questionnaireResponse", appearance: "appearance", smallQuestionColumn: "smallQuestionColumn", emptyAnswerPlaceholder: "emptyAnswerPlaceholder", questionLastChar: "questionLastChar", lang: "lang" }, ngImport: i0, template: "<div class=\"d-flex flex-column\" *ngIf=\"questionnaireResponse?.answers\">\n  <!-- responsive-row -->\n  <div *ngFor=\"let item of questionnaireResponse?.questionnaire?.items; let i = index;\" class=\"d-flex  display-mode-line-height\">\n    <ng-container *ngIf=\"item | instanceof: Question as q\">\n      <ng-container *ngTemplateOutlet=\"viewquestion; context: { $implicit: q, answer: findAnswerByQuestion(questionnaireResponse?.answers, q), nested: false }\"></ng-container>\n    </ng-container>\n\n    <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n      <ng-container *ngTemplateOutlet=\"viewgroup; context: { $implicit: g, answersGroup: findAnswerGroupByQuestionGroup(questionnaireResponse?.answers, g) }\"></ng-container>\n    </ng-container>\n  </div>\n</div>\n\n<ng-template #viewquestion let-question let-answer=\"answer\" let-nested=\"nested\" let-pos=\"position\">\n  <!-- domanda -->\n  <ng-container *ngIf=\"(question.type !== types.display)\">\n\n    <h2 *ngIf=\"pos == 0 && !nested \" class=\"title\">{{ extractAnswerValue(answer, question)?.toString() | translate }}</h2>\n\n    <div *ngIf=\"pos > 0 && !nested\" class=\"question\" [ngClass]=\"{'emphasized-question' : (extractAnswerValue(answer, question) != emptyAnswerPlaceholder), 'flex-basis-50' : !smallQuestionColumn, 'flex-basis-25' : smallQuestionColumn }\">\n      <span *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>\n      {{ question.text | translate }}{{questionLastChar}}\n    </div>\n\n    <div class=\"answer flex-1 d-flex\" [ngClass]=\"{'flex-column': !nested, 'flex-row mat-caption nested-question': nested}\">\n      <ng-container >\n        <label *ngIf=\"pos > 0 && nested\" class=\"question\" >\n          <span *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>\n          {{ question.text | translate }}{{questionLastChar}}:&nbsp;\n        </label>\n\n        <!-- risposta multipla chiusa -->\n        <ng-container *ngIf=\"(question.permittedAnswers?.length > 0) else openAnswer\">{{ extractAnswerValue(answer, question)?.toString() | translate }}</ng-container>\n\n        <!-- risposta aperta tipizzata -->\n        <ng-template #openAnswer>\n          <!-- risposta di tipo boolean -->\n          <label *ngIf=\"(question.type === types.boolean)\">{{ ( 'questionnaire.boolean.' + extractAnswerValue(answer, question)?.toString() ) | translate }}</label>\n          <!-- risposta di tipo numerico -->\n          <label *ngIf=\"(question.type === types.integer) || (question.type === types.decimal)\">{{ extractAnswerValue(answer, question) }}</label>\n          <!-- risposta di tipo testuale (stringa corta) -->\n          <label *ngIf=\"(question.type === types.string)\">{{ extractTextualAnswerValue(answer, question) }}</label>\n          <!-- risposta di tipo testuale (stringa lunga)-->\n          <label *ngIf=\"(question.type === types.text)\">{{ extractAnswerValue(answer, question) }}</label>\n          <!-- risposta di tipo CodedValue -->\n          <label [ngClass]=\"{'title': !nested && pos == 0}\" *ngIf=\"pos > 0 && (question.type === types.CodedValue)\">{{ extractTextualAnswerValue(answer, question) }}</label>\n          <!-- risposta di tipo data -->\n          <label *ngIf=\"(question.type === types.date)\">{{ extractDateAnswerValue(answer, question) | date }}</label>\n        </ng-template>\n\n        <ng-container *ngFor=\"let item of question.items, let pos = index\">\n          <ng-container *ngTemplateOutlet=\"viewquestion; context: { $implicit: item, answer: findAnswerByQuestion(answer?.answers, item), nested: true, position: pos }\"></ng-container>\n        </ng-container>\n      </ng-container>\n    </div>\n  </ng-container>\n\n  <!-- domanda di tipo 'display' -->\n  <span *ngIf=\"(question.type === types.display)\" class=\"mat-caption mb-2\">{{ question.text | translate }}</span>\n</ng-template>\n\n<ng-template #viewgroup let-group let-answersGroup=\"answersGroup\">\n  <!-- p-3 mt-2 mb-2 group-box -->\n  <div class=\"d-flex flex-column flex-1 xcard \">\n    <!-- <h3 class=\"mat-mdc-card-subtitle\">{{ group.name | translate }}</h3> -->\n\n    <ng-container *ngIf=\"group.repeated\">\n      <!-- here answersGroup MUST be an array of repeteable items -->\n      <div *ngFor=\"let repeteableAnswersGroup of answersGroup\" class=\"group-box p-3 mb-2 mt-1\">\n        <!-- responsive-row -->\n        <div *ngFor=\"let item of group?.items; let i = index;\" class=\"d-flex display-mode-line-height\">\n          <ng-container *ngIf=\"item | instanceof: Question as q\">\n            <ng-container *ngTemplateOutlet=\"viewquestion; context: { $implicit: q, answer: findAnswerByQuestion(repeteableAnswersGroup?.answers, item), nested: false, position: i  }\"></ng-container>\n          </ng-container>\n\n          <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n            <ng-container *ngTemplateOutlet=\"viewgroup; context: { $implicit: g, answersGroup: findAnswerGroupByQuestionGroup(repeteableAnswersGroup?.answers, g) }\"></ng-container>\n          </ng-container>\n        </div>\n      </div>\n    </ng-container>\n\n    <ng-container *ngIf=\"!group.repeated\">\n      <!-- responsive-row -->\n      <div *ngFor=\"let item of group?.items; let i = index;\" class=\"d-flex display-mode-line-height\">\n        <ng-container *ngIf=\"item | instanceof: Question as q\">\n          <ng-container *ngTemplateOutlet=\"viewquestion; context: { $implicit: q, answer: findAnswerByQuestion(answersGroup?.answers, item), nested: false, position: i }\"></ng-container>\n        </ng-container>\n\n        <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n          <ng-container *ngTemplateOutlet=\"viewgroup; context: { $implicit: g, answersGroup: findAnswerGroupByQuestionGroup(answersGroup?.answers, g) }\"></ng-container>\n        </ng-container>\n      </div>\n    </ng-container>\n  </div>\n</ng-template>\n", styles: [".questionnaire{min-width:400px}.questionnaire .question{overflow-wrap:break-word;font-weight:bolder;opacity:.8}.group-box{border-style:solid;border-width:1px;border-color:#00000061;border-radius:4px}.responsive-row{flex-direction:row;align-items:baseline}.title{font-weight:600}@media screen and (max-width: 768px){.gutter{column-gap:0}.responsive-row{flex-direction:column;align-items:stretch;column-gap:0}}mat-radio-button{margin-right:16px!important}.questionnaire .emphasized-question{opacity:1;font-weight:700!important}.questionnaire .display-mode-line-height{margin-bottom:12px}.nested-question{font-style:italic}.nested-question .question{font-weight:700}@media screen and (max-width: 768px){.questionnaire .display-mode-line-height{margin-bottom:20px}}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: i2.DatePipe, name: "date" }, { kind: "pipe", type: i1$1.TranslatePipe, name: "translate" }, { kind: "pipe", type: InstanceofPipe, name: "instanceof" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DynBuiltQuestionnaireSectionViewerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-dyn-built-questionnaire-section-viewer', template: "<div class=\"d-flex flex-column\" *ngIf=\"questionnaireResponse?.answers\">\n  <!-- responsive-row -->\n  <div *ngFor=\"let item of questionnaireResponse?.questionnaire?.items; let i = index;\" class=\"d-flex  display-mode-line-height\">\n    <ng-container *ngIf=\"item | instanceof: Question as q\">\n      <ng-container *ngTemplateOutlet=\"viewquestion; context: { $implicit: q, answer: findAnswerByQuestion(questionnaireResponse?.answers, q), nested: false }\"></ng-container>\n    </ng-container>\n\n    <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n      <ng-container *ngTemplateOutlet=\"viewgroup; context: { $implicit: g, answersGroup: findAnswerGroupByQuestionGroup(questionnaireResponse?.answers, g) }\"></ng-container>\n    </ng-container>\n  </div>\n</div>\n\n<ng-template #viewquestion let-question let-answer=\"answer\" let-nested=\"nested\" let-pos=\"position\">\n  <!-- domanda -->\n  <ng-container *ngIf=\"(question.type !== types.display)\">\n\n    <h2 *ngIf=\"pos == 0 && !nested \" class=\"title\">{{ extractAnswerValue(answer, question)?.toString() | translate }}</h2>\n\n    <div *ngIf=\"pos > 0 && !nested\" class=\"question\" [ngClass]=\"{'emphasized-question' : (extractAnswerValue(answer, question) != emptyAnswerPlaceholder), 'flex-basis-50' : !smallQuestionColumn, 'flex-basis-25' : smallQuestionColumn }\">\n      <span *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>\n      {{ question.text | translate }}{{questionLastChar}}\n    </div>\n\n    <div class=\"answer flex-1 d-flex\" [ngClass]=\"{'flex-column': !nested, 'flex-row mat-caption nested-question': nested}\">\n      <ng-container >\n        <label *ngIf=\"pos > 0 && nested\" class=\"question\" >\n          <span *ngIf=\"question.prefix\">{{question.prefix}}&nbsp;</span>\n          {{ question.text | translate }}{{questionLastChar}}:&nbsp;\n        </label>\n\n        <!-- risposta multipla chiusa -->\n        <ng-container *ngIf=\"(question.permittedAnswers?.length > 0) else openAnswer\">{{ extractAnswerValue(answer, question)?.toString() | translate }}</ng-container>\n\n        <!-- risposta aperta tipizzata -->\n        <ng-template #openAnswer>\n          <!-- risposta di tipo boolean -->\n          <label *ngIf=\"(question.type === types.boolean)\">{{ ( 'questionnaire.boolean.' + extractAnswerValue(answer, question)?.toString() ) | translate }}</label>\n          <!-- risposta di tipo numerico -->\n          <label *ngIf=\"(question.type === types.integer) || (question.type === types.decimal)\">{{ extractAnswerValue(answer, question) }}</label>\n          <!-- risposta di tipo testuale (stringa corta) -->\n          <label *ngIf=\"(question.type === types.string)\">{{ extractTextualAnswerValue(answer, question) }}</label>\n          <!-- risposta di tipo testuale (stringa lunga)-->\n          <label *ngIf=\"(question.type === types.text)\">{{ extractAnswerValue(answer, question) }}</label>\n          <!-- risposta di tipo CodedValue -->\n          <label [ngClass]=\"{'title': !nested && pos == 0}\" *ngIf=\"pos > 0 && (question.type === types.CodedValue)\">{{ extractTextualAnswerValue(answer, question) }}</label>\n          <!-- risposta di tipo data -->\n          <label *ngIf=\"(question.type === types.date)\">{{ extractDateAnswerValue(answer, question) | date }}</label>\n        </ng-template>\n\n        <ng-container *ngFor=\"let item of question.items, let pos = index\">\n          <ng-container *ngTemplateOutlet=\"viewquestion; context: { $implicit: item, answer: findAnswerByQuestion(answer?.answers, item), nested: true, position: pos }\"></ng-container>\n        </ng-container>\n      </ng-container>\n    </div>\n  </ng-container>\n\n  <!-- domanda di tipo 'display' -->\n  <span *ngIf=\"(question.type === types.display)\" class=\"mat-caption mb-2\">{{ question.text | translate }}</span>\n</ng-template>\n\n<ng-template #viewgroup let-group let-answersGroup=\"answersGroup\">\n  <!-- p-3 mt-2 mb-2 group-box -->\n  <div class=\"d-flex flex-column flex-1 xcard \">\n    <!-- <h3 class=\"mat-mdc-card-subtitle\">{{ group.name | translate }}</h3> -->\n\n    <ng-container *ngIf=\"group.repeated\">\n      <!-- here answersGroup MUST be an array of repeteable items -->\n      <div *ngFor=\"let repeteableAnswersGroup of answersGroup\" class=\"group-box p-3 mb-2 mt-1\">\n        <!-- responsive-row -->\n        <div *ngFor=\"let item of group?.items; let i = index;\" class=\"d-flex display-mode-line-height\">\n          <ng-container *ngIf=\"item | instanceof: Question as q\">\n            <ng-container *ngTemplateOutlet=\"viewquestion; context: { $implicit: q, answer: findAnswerByQuestion(repeteableAnswersGroup?.answers, item), nested: false, position: i  }\"></ng-container>\n          </ng-container>\n\n          <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n            <ng-container *ngTemplateOutlet=\"viewgroup; context: { $implicit: g, answersGroup: findAnswerGroupByQuestionGroup(repeteableAnswersGroup?.answers, g) }\"></ng-container>\n          </ng-container>\n        </div>\n      </div>\n    </ng-container>\n\n    <ng-container *ngIf=\"!group.repeated\">\n      <!-- responsive-row -->\n      <div *ngFor=\"let item of group?.items; let i = index;\" class=\"d-flex display-mode-line-height\">\n        <ng-container *ngIf=\"item | instanceof: Question as q\">\n          <ng-container *ngTemplateOutlet=\"viewquestion; context: { $implicit: q, answer: findAnswerByQuestion(answersGroup?.answers, item), nested: false, position: i }\"></ng-container>\n        </ng-container>\n\n        <ng-container *ngIf=\"item | instanceof: QuestionGroup as g\">\n          <ng-container *ngTemplateOutlet=\"viewgroup; context: { $implicit: g, answersGroup: findAnswerGroupByQuestionGroup(answersGroup?.answers, g) }\"></ng-container>\n        </ng-container>\n      </div>\n    </ng-container>\n  </div>\n</ng-template>\n", styles: [".questionnaire{min-width:400px}.questionnaire .question{overflow-wrap:break-word;font-weight:bolder;opacity:.8}.group-box{border-style:solid;border-width:1px;border-color:#00000061;border-radius:4px}.responsive-row{flex-direction:row;align-items:baseline}.title{font-weight:600}@media screen and (max-width: 768px){.gutter{column-gap:0}.responsive-row{flex-direction:column;align-items:stretch;column-gap:0}}mat-radio-button{margin-right:16px!important}.questionnaire .emphasized-question{opacity:1;font-weight:700!important}.questionnaire .display-mode-line-height{margin-bottom:12px}.nested-question{font-style:italic}.nested-question .question{font-weight:700}@media screen and (max-width: 768px){.questionnaire .display-mode-line-height{margin-bottom:20px}}\n"] }]
        }], ctorParameters: function () { return []; }, propDecorators: { questionnaireResponse: [{
                type: Input
            }], appearance: [{
                type: Input
            }], smallQuestionColumn: [{
                type: Input
            }], emptyAnswerPlaceholder: [{
                type: Input
            }], questionLastChar: [{
                type: Input
            }], lang: [{
                type: Input
            }] } });

class DynBuiltQuestionnaireComponent {
    constructor(_dateAdapter, _subTranslateService) {
        this._dateAdapter = _dateAdapter;
        this._subTranslateService = _subTranslateService;
        this.debug = true;
        this.questionnaireResponseChange = new EventEmitter();
        /**
         * ASPECT SETTINGS
         */
        this.appearance = 'outline';
        // last char to be added to questions
        this.questionLastChar = '?';
        // if false hides the main header and the questionnaire title
        this.showHeader = true;
        // TODO (only box is working)
        this.firstLevelGroupFormat = 'box';
        /**
         * OPERATING MODE SETTINGS
         */
        // if the questionnaire cannot be modified (in this case the action buttons are not rendered)
        this.readOnly = false;
        // if the the action buttons have to be rendered (if 'false' use 'editMode' and/or 'questionnaireResponse' with bidirectional binding)
        this.enableActionButtons = true;
        // determine the mode that should be used when showing for the first time
        this.editMode = false;
        // notify that the component is in edit mode ('true') or view mode ('false')
        this.onModeChange = new EventEmitter();
        /**
         * EDIT FORM RENDERING SETTINGS
         */
        // render options only as Radio Button
        this.forceRadioButton = false;
        // [GUIDELINE] max value for switching options from Radio to Select
        this.maxValuesForRadio = 5;
        // manage the width of the question column and the rendering of the overall questionnaire
        this.smallQuestionColumn = false;
        // chars used for empty answers
        this.emptyAnswerPlaceholder = '-';
        this.onCancel = new EventEmitter();
        // @deprecated: left for retrocompatibility. use bidirectional binding (i.e. [(questionnaireResponse)])
        this.onSave = new EventEmitter();
        this.editorFormStatus = undefined;
        this.types = QuestionType;
        this.Question = Question;
        this.QuestionGroup = QuestionGroup;
        this.AnswerGroup = AnswerGroup;
        this.createDictionary();
    }
    ngOnChanges(changes) {
        const _lang = changes['lang'];
        if (_lang) {
            if (_lang.currentValue != _lang.previousValue) {
                const locale = this._subTranslateService.getFnsLocale(this.lang);
                if (locale)
                    this._dateAdapter.setLocale(locale);
            }
        }
    }
    // approccio per unificare il servizio di traduzione
    createDictionary() {
        const dictionary = new Map();
        dictionary.set('en', en);
        dictionary.set('it', it);
        this._subTranslateService.setLanguages(dictionary);
    }
    onCancelEdit() {
        this.setDisplayModeOn();
        // invoca il metodo fornito per notificare il salvataggio dei dati
        this.onCancel?.emit();
    }
    /**
     * Attiva la modalità DISPLAY
     */
    setDisplayModeOn() {
        this.editMode = false;
        this.onModeChange.emit(this.editMode);
    }
    /**
     * Attiva la modalità EDIT ed imposta nei campi del form
     * il valore della risposta precedentemente digitato (qualora vi sia).
     * Nel caso non sia mai stato inserito un valore, resetta il campo.
     */
    setEditModeOn() {
        // reset
        this.editorFormStatus = undefined;
        this.editMode = true;
        this.onModeChange.emit(this.editMode);
    }
    appendAnswerGroups(answersGroups, path) {
        this.editorComponent?.appendAnswerGroups(answersGroups, path);
    }
}
DynBuiltQuestionnaireComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DynBuiltQuestionnaireComponent, deps: [{ token: i1.DateAdapter }, { token: i2$1.SubTranslateService }], target: i0.ɵɵFactoryTarget.Component });
DynBuiltQuestionnaireComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: DynBuiltQuestionnaireComponent, selector: "heart-dyn-built-questionnaire", inputs: { questionnaireResponse: "questionnaireResponse", appearance: "appearance", lang: "lang", questionLastChar: "questionLastChar", headerBackgroundColor: "headerBackgroundColor", showHeader: "showHeader", firstLevelGroupFormat: "firstLevelGroupFormat", readOnly: "readOnly", enableActionButtons: "enableActionButtons", editMode: "editMode", forceRadioButton: "forceRadioButton", maxValuesForRadio: "maxValuesForRadio", smallQuestionColumn: "smallQuestionColumn", emptyAnswerPlaceholder: "emptyAnswerPlaceholder" }, outputs: { questionnaireResponseChange: "questionnaireResponseChange", onModeChange: "onModeChange", onCancel: "onCancel", onSave: "onSave" }, viewQueries: [{ propertyName: "editorComponent", first: true, predicate: DynBuiltQuestionnaireSectionEditorComponent, descendants: true }], usesOnChanges: true, ngImport: i0, template: "<!-- {{ questionnaireResponse | json }} -->\n\n\n<!-- ---------------------------------------\n  -\n  - Container in modalit\u00E0 DISPLAY\n  -\n  ----------------------------------------->\n\n  <div class=\"container\" *ngIf=\"editMode === false; else input\">\n    <mat-card class=\"questionnaire\" >\n      <mat-card-header *ngIf=\"showHeader\" [ngStyle]=\"{'background-color' : headerBackgroundColor}\">\n        <mat-card-title>{{ questionnaireResponse?.questionnaire?.name | translate }}</mat-card-title>\n      </mat-card-header>\n  \n      <mat-card-content>\n        <heart-dyn-built-questionnaire-section-viewer\n          [questionnaireResponse]=\"questionnaireResponse\"\n          [lang]=\"lang\"\n          [appearance]=\"appearance\"\n          [questionLastChar]=\"questionLastChar\"\n          [emptyAnswerPlaceholder]=\"emptyAnswerPlaceholder\"\n          [smallQuestionColumn]=\"smallQuestionColumn\"></heart-dyn-built-questionnaire-section-viewer>\n  \n      </mat-card-content>\n  \n      <mat-card-actions align=\"end\" *ngIf=\"enableActionButtons && !readOnly\">\n        <button *ngIf=\"questionnaireResponse.answers == undefined || questionnaireResponse.answers.length == 0\" mat-raised-button color=\"accent\" (click)=\"setEditModeOn()\">{{\"questionnaire.button.compile.label\" | subtranslate:lang }}</button>\n        <button *ngIf=\"questionnaireResponse.answers && questionnaireResponse.answers.length > 0\" mat-raised-button color=\"accent\" (click)=\"setEditModeOn()\">{{\"questionnaire.button.edit.label\" | subtranslate:lang }}</button>\n      </mat-card-actions>\n    </mat-card>\n  </div>\n  \n  \n  <!-- ---------------------------------------\n    -\n    - Container in modalit\u00E0 EDIT\n    -\n    ----------------------------------------->\n  <ng-template #input>\n    <div class=\"container\">\n      <!-- INPUT CARD -->\n      <!-- se non c'\u00E8 almeno una risposta prepopolata NON DOVREBBE ESSERE VISIBILE -->\n      <!-- ma cos\u00EC facendo il viewchild non pu\u00F2 funzionare -->\n      <!-- *ngIf = \"firstAdd\" -->\n      <mat-card class=\"questionnaire\" >\n        <mat-card-header *ngIf=\"showHeader\" class=\"bg-primary text-white\">\n          <mat-card-title>{{ questionnaireResponse?.questionnaire?.name | translate }}</mat-card-title>\n        </mat-card-header>\n  \n        <mat-card-content>\n  \n          <heart-dyn-built-questionnaire-section-editor\n            #editor\n            [(questionnaireResponse)]=\"questionnaireResponse\"\n            (questionnaireResponseChange)=\"onSave.emit($event)\"\n            [lang]=\"lang\"\n            [firstLevelGroupFormat]=\"firstLevelGroupFormat\"\n            [appearance]=\"appearance\"\n            [forceRadioButton]=\"forceRadioButton\"\n            [maxValuesForRadio]=\"maxValuesForRadio\"\n            [questionLastChar]=\"questionLastChar\"\n            [smallQuestionColumn]=\"smallQuestionColumn\"\n            (validate)=\"editorFormStatus = $event\"></heart-dyn-built-questionnaire-section-editor>\n  \n        </mat-card-content>\n  \n        <mat-card-actions align=\"end\" *ngIf=\"enableActionButtons && !readOnly\">\n          <button mat-raised-button color=\"basic\" (click)=\"onCancelEdit()\" [disabled]=\"questionnaireResponse?.id == undefined\" style=\"margin-right:6px\">{{\"questionnaire.button.cancel.label\" | subtranslate:lang}}</button>\n          <button mat-raised-button #save color=\"accent\" heartDebouncedButton (debounceClick)=\"editor.onSubmit($event)\" [disabled]=\"editorFormStatus != 'VALID'\">{{\"questionnaire.button.save.label\" | subtranslate:lang}}</button>\n        </mat-card-actions>\n      </mat-card>\n    </div>\n  </ng-template>\n  ", styles: [".container{width:100%}\n"], dependencies: [{ kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: i4$2.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "directive", type: i4$2.MatCardActions, selector: "mat-card-actions", inputs: ["align"], exportAs: ["matCardActions"] }, { kind: "directive", type: i4$2.MatCardContent, selector: "mat-card-content" }, { kind: "component", type: i4$2.MatCardHeader, selector: "mat-card-header" }, { kind: "directive", type: i4$2.MatCardTitle, selector: "mat-card-title, [mat-card-title], [matCardTitle]" }, { kind: "component", type: i5$1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "directive", type: i2$1.DebouncedButtonDirective, selector: "[heartDebouncedButton]", inputs: ["debounceClickTime"], outputs: ["debounceClick"] }, { kind: "component", type: DynBuiltQuestionnaireSectionViewerComponent, selector: "heart-dyn-built-questionnaire-section-viewer", inputs: ["questionnaireResponse", "appearance", "smallQuestionColumn", "emptyAnswerPlaceholder", "questionLastChar", "lang"] }, { kind: "component", type: DynBuiltQuestionnaireSectionEditorComponent, selector: "heart-dyn-built-questionnaire-section-editor", inputs: ["questionnaireResponse", "firstLevelGroupFormat", "appearance", "questionLastChar", "lang", "smallQuestionColumn", "maxValuesForRadio", "forceRadioButton"], outputs: ["questionnaireResponseChange", "validate"] }, { kind: "pipe", type: i1$1.TranslatePipe, name: "translate" }, { kind: "pipe", type: i2$1.SubTranslatePipe, name: "subtranslate" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DynBuiltQuestionnaireComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-dyn-built-questionnaire', template: "<!-- {{ questionnaireResponse | json }} -->\n\n\n<!-- ---------------------------------------\n  -\n  - Container in modalit\u00E0 DISPLAY\n  -\n  ----------------------------------------->\n\n  <div class=\"container\" *ngIf=\"editMode === false; else input\">\n    <mat-card class=\"questionnaire\" >\n      <mat-card-header *ngIf=\"showHeader\" [ngStyle]=\"{'background-color' : headerBackgroundColor}\">\n        <mat-card-title>{{ questionnaireResponse?.questionnaire?.name | translate }}</mat-card-title>\n      </mat-card-header>\n  \n      <mat-card-content>\n        <heart-dyn-built-questionnaire-section-viewer\n          [questionnaireResponse]=\"questionnaireResponse\"\n          [lang]=\"lang\"\n          [appearance]=\"appearance\"\n          [questionLastChar]=\"questionLastChar\"\n          [emptyAnswerPlaceholder]=\"emptyAnswerPlaceholder\"\n          [smallQuestionColumn]=\"smallQuestionColumn\"></heart-dyn-built-questionnaire-section-viewer>\n  \n      </mat-card-content>\n  \n      <mat-card-actions align=\"end\" *ngIf=\"enableActionButtons && !readOnly\">\n        <button *ngIf=\"questionnaireResponse.answers == undefined || questionnaireResponse.answers.length == 0\" mat-raised-button color=\"accent\" (click)=\"setEditModeOn()\">{{\"questionnaire.button.compile.label\" | subtranslate:lang }}</button>\n        <button *ngIf=\"questionnaireResponse.answers && questionnaireResponse.answers.length > 0\" mat-raised-button color=\"accent\" (click)=\"setEditModeOn()\">{{\"questionnaire.button.edit.label\" | subtranslate:lang }}</button>\n      </mat-card-actions>\n    </mat-card>\n  </div>\n  \n  \n  <!-- ---------------------------------------\n    -\n    - Container in modalit\u00E0 EDIT\n    -\n    ----------------------------------------->\n  <ng-template #input>\n    <div class=\"container\">\n      <!-- INPUT CARD -->\n      <!-- se non c'\u00E8 almeno una risposta prepopolata NON DOVREBBE ESSERE VISIBILE -->\n      <!-- ma cos\u00EC facendo il viewchild non pu\u00F2 funzionare -->\n      <!-- *ngIf = \"firstAdd\" -->\n      <mat-card class=\"questionnaire\" >\n        <mat-card-header *ngIf=\"showHeader\" class=\"bg-primary text-white\">\n          <mat-card-title>{{ questionnaireResponse?.questionnaire?.name | translate }}</mat-card-title>\n        </mat-card-header>\n  \n        <mat-card-content>\n  \n          <heart-dyn-built-questionnaire-section-editor\n            #editor\n            [(questionnaireResponse)]=\"questionnaireResponse\"\n            (questionnaireResponseChange)=\"onSave.emit($event)\"\n            [lang]=\"lang\"\n            [firstLevelGroupFormat]=\"firstLevelGroupFormat\"\n            [appearance]=\"appearance\"\n            [forceRadioButton]=\"forceRadioButton\"\n            [maxValuesForRadio]=\"maxValuesForRadio\"\n            [questionLastChar]=\"questionLastChar\"\n            [smallQuestionColumn]=\"smallQuestionColumn\"\n            (validate)=\"editorFormStatus = $event\"></heart-dyn-built-questionnaire-section-editor>\n  \n        </mat-card-content>\n  \n        <mat-card-actions align=\"end\" *ngIf=\"enableActionButtons && !readOnly\">\n          <button mat-raised-button color=\"basic\" (click)=\"onCancelEdit()\" [disabled]=\"questionnaireResponse?.id == undefined\" style=\"margin-right:6px\">{{\"questionnaire.button.cancel.label\" | subtranslate:lang}}</button>\n          <button mat-raised-button #save color=\"accent\" heartDebouncedButton (debounceClick)=\"editor.onSubmit($event)\" [disabled]=\"editorFormStatus != 'VALID'\">{{\"questionnaire.button.save.label\" | subtranslate:lang}}</button>\n        </mat-card-actions>\n      </mat-card>\n    </div>\n  </ng-template>\n  ", styles: [".container{width:100%}\n"] }]
        }], ctorParameters: function () { return [{ type: i1.DateAdapter }, { type: i2$1.SubTranslateService }]; }, propDecorators: { questionnaireResponse: [{
                type: Input
            }], questionnaireResponseChange: [{
                type: Output
            }], appearance: [{
                type: Input
            }], lang: [{
                type: Input
            }], questionLastChar: [{
                type: Input
            }], headerBackgroundColor: [{
                type: Input
            }], showHeader: [{
                type: Input
            }], firstLevelGroupFormat: [{
                type: Input
            }], readOnly: [{
                type: Input
            }], enableActionButtons: [{
                type: Input
            }], editMode: [{
                type: Input
            }], onModeChange: [{
                type: Output
            }], forceRadioButton: [{
                type: Input
            }], maxValuesForRadio: [{
                type: Input
            }], smallQuestionColumn: [{
                type: Input
            }], emptyAnswerPlaceholder: [{
                type: Input
            }], onCancel: [{
                type: Output
            }], onSave: [{
                type: Output
            }], editorComponent: [{
                type: ViewChild,
                args: [DynBuiltQuestionnaireSectionEditorComponent]
            }] } });

// AoT requires an exported function for factories
function HttpLoaderFactoryDynQuestionnaire(http) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class DynBuiltQuestionnaireModule {
}
DynBuiltQuestionnaireModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DynBuiltQuestionnaireModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
DynBuiltQuestionnaireModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: DynBuiltQuestionnaireModule, declarations: [DynBuiltQuestionnaireComponent,
        DynBuiltQuestionnaireSectionViewerComponent,
        DynBuiltQuestionnaireSectionEditorComponent,
        DynBuiltQuestionnaireSectionEditorQuestionComponent,
        DynBuiltQuestionnaireSectionEditorGroupComponent,
        InstanceofPipe,
        RadioGroupCompare], imports: [CommonModule, i1$1.TranslateModule, MatCardModule,
        MatFormFieldModule,
        MatInputModule,
        MatIconModule,
        MatSelectModule,
        MatRadioModule,
        MatCheckboxModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatDatepickerModule,
        MatExpansionModule,
        MatTabsModule,
        SubTranslateModule,
        PreventDoubleClickModule], exports: [DynBuiltQuestionnaireComponent] });
DynBuiltQuestionnaireModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DynBuiltQuestionnaireModule, providers: [
        DynBuiltQuestionSectionEditorService,
        { provide: MAT_DATE_FORMATS, useValue: MAT_DATE_FNS_FORMATS },
        { provide: DateAdapter, useClass: DateFnsAdapter, deps: [MAT_DATE_LOCALE] },
        { provide: MAT_DATE_LOCALE, useValue: enGB },
    ], imports: [CommonModule,
        TranslateModule.forChild({
            defaultLanguage: 'en',
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactoryDynQuestionnaire,
                deps: [HttpClient],
            },
            isolate: true,
        }),
        MatCardModule,
        MatFormFieldModule,
        MatInputModule,
        MatIconModule,
        MatSelectModule,
        MatRadioModule,
        MatCheckboxModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatDatepickerModule,
        MatExpansionModule,
        MatTabsModule,
        SubTranslateModule,
        PreventDoubleClickModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DynBuiltQuestionnaireModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DynBuiltQuestionnaireComponent,
                        DynBuiltQuestionnaireSectionViewerComponent,
                        DynBuiltQuestionnaireSectionEditorComponent,
                        DynBuiltQuestionnaireSectionEditorQuestionComponent,
                        DynBuiltQuestionnaireSectionEditorGroupComponent,
                        InstanceofPipe,
                        RadioGroupCompare,
                    ],
                    imports: [
                        CommonModule,
                        TranslateModule.forChild({
                            defaultLanguage: 'en',
                            loader: {
                                provide: TranslateLoader,
                                useFactory: HttpLoaderFactoryDynQuestionnaire,
                                deps: [HttpClient],
                            },
                            isolate: true,
                        }),
                        MatCardModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatIconModule,
                        MatSelectModule,
                        MatRadioModule,
                        MatCheckboxModule,
                        ReactiveFormsModule,
                        MatButtonModule,
                        MatDatepickerModule,
                        MatExpansionModule,
                        MatTabsModule,
                        SubTranslateModule,
                        PreventDoubleClickModule,
                    ],
                    exports: [DynBuiltQuestionnaireComponent],
                    providers: [
                        DynBuiltQuestionSectionEditorService,
                        { provide: MAT_DATE_FORMATS, useValue: MAT_DATE_FNS_FORMATS },
                        { provide: DateAdapter, useClass: DateFnsAdapter, deps: [MAT_DATE_LOCALE] },
                        { provide: MAT_DATE_LOCALE, useValue: enGB },
                    ],
                }]
        }] });

/*
 * Public API Surface of heart-ui-questionnaire
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DynBuiltQuestionnaireComponent, DynBuiltQuestionnaireModule, HttpLoaderFactoryDynQuestionnaire, HttpLoaderFactoryQuestionnaire, QuestionnaireSectionComponent, QuestionnaireSectionModule, QuestionnaireSectionTesterComponent };
//# sourceMappingURL=eng-it4h-heart-ui-questionnaire.mjs.map
