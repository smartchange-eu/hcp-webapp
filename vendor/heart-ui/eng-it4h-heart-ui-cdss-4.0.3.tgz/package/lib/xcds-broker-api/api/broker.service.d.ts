import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CDSServiceRequestDTO } from '../model/cDSServiceRequestDTO';
import { XCDSCard } from '../model/xCDSCard';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class BrokerService {
    protected httpClient: HttpClient;
    basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     * Update all the cards by triggering the CDS Services supporting a given &#x27;hook&#x27;
     *
     * @param body
     * @param authorization
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateCards(body: CDSServiceRequestDTO, authorization?: string, observe?: 'body', reportProgress?: boolean): Observable<Array<XCDSCard>>;
    updateCards(body: CDSServiceRequestDTO, authorization?: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<XCDSCard>>>;
    updateCards(body: CDSServiceRequestDTO, authorization?: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<XCDSCard>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrokerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BrokerService>;
}
