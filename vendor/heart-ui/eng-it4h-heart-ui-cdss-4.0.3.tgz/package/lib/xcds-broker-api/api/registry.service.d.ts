import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CDSServiceDTO } from '../model/cDSServiceDTO';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class RegistryService {
    protected httpClient: HttpClient;
    basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getServices(observe?: 'body', reportProgress?: boolean): Observable<Array<CDSServiceDTO>>;
    getServices(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<CDSServiceDTO>>>;
    getServices(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<CDSServiceDTO>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    registerService(body: CDSServiceDTO, observe?: 'body', reportProgress?: boolean): Observable<any>;
    registerService(body: CDSServiceDTO, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    registerService(body: CDSServiceDTO, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RegistryService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RegistryService>;
}
