import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class HEARTBaseAPIsService {
    protected httpClient: HttpClient;
    basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     * Return an empty string in case of success
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    emptyTestService(observe?: 'body', reportProgress?: boolean): Observable<string>;
    emptyTestService(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<string>>;
    emptyTestService(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<string>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<HEARTBaseAPIsService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HEARTBaseAPIsService>;
}
