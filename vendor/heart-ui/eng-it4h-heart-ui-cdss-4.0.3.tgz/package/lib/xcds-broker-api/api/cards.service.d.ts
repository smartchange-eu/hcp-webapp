import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ChangeCardStatusDto } from '../model/changeCardStatusDto';
import { XCDSCard } from '../model/xCDSCard';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class CardsService {
    protected httpClient: HttpClient;
    basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param patientId
     * @param cardUuid
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    changeCardStatus(body: ChangeCardStatusDto, patientId: string, cardUuid: string, observe?: 'body', reportProgress?: boolean): Observable<any>;
    changeCardStatus(body: ChangeCardStatusDto, patientId: string, cardUuid: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    changeCardStatus(body: ChangeCardStatusDto, patientId: string, cardUuid: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param patientId
     * @param cardUuid
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getCardByUuid(patientId: string, cardUuid: string, observe?: 'body', reportProgress?: boolean): Observable<XCDSCard>;
    getCardByUuid(patientId: string, cardUuid: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<XCDSCard>>;
    getCardByUuid(patientId: string, cardUuid: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<XCDSCard>>;
    /**
     *
     *
     * @param patientId
     * @param status
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getCardsByPatient(patientId: string, status?: string, observe?: 'body', reportProgress?: boolean): Observable<Array<XCDSCard>>;
    getCardsByPatient(patientId: string, status?: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<XCDSCard>>>;
    getCardsByPatient(patientId: string, status?: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<XCDSCard>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardsService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CardsService>;
}
