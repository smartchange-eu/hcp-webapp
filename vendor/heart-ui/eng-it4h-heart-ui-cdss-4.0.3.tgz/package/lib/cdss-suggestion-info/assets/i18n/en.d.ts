export declare const en: {
    "cdss.info.strength.label": string;
    "cdss.info.qoe.label": string;
    "suggestion.card.action.label": string;
};
