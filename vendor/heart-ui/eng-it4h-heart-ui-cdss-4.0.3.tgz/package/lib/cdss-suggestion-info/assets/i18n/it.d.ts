export declare const it: {
    "cdss.info.strength.label": string;
    "cdss.info.qoe.label": string;
    "suggestion.card.action.label": string;
    "cdss.no-action.label": string;
    "suggestion.card.managed-by.label": string;
    "suggestion.card.managed-at.label": string;
    "cdss.info.confidence.label": string;
    "cdss.info.precision.label": string;
    "cdss.suggestion-info.more-details.label": string;
};
