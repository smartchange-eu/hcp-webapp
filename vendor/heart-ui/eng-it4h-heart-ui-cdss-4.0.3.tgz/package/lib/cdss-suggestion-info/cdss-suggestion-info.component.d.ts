import { EventEmitter, OnInit } from '@angular/core';
import { SubTranslateService } from '@eng-it4h/heart-ui-utils';
import { Suggestion } from '../model';
import * as i0 from "@angular/core";
export declare class CdssSuggestionInfoComponent implements OnInit {
    private _subTranslateService;
    lang: string;
    suggestion: Suggestion;
    accepted: EventEmitter<Suggestion>;
    explanation: EventEmitter<Suggestion>;
    readonly: boolean;
    showPrecision: boolean;
    protected displayDetails: boolean;
    constructor(_subTranslateService: SubTranslateService);
    createDictionary(): void;
    ngOnInit(): void;
    protected acceptSuggestion(event: any): void;
    protected showExplanation(s: Suggestion): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdssSuggestionInfoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CdssSuggestionInfoComponent, "heart-cdss-suggestion-info", never, { "lang": "lang"; "suggestion": "suggestion"; "readonly": "readonly"; "showPrecision": "showPrecision"; }, { "accepted": "accepted"; "explanation": "explanation"; }, never, never, false, never>;
}
