import { CodedValue, HealthCareProfessional } from '@eng-it4h/heart-ui-model';
import { Action } from './action.model';
import { Shap } from './shap.model';
import { GuideLineExplanation } from './explanation/guide-line-explanation.model';
import { CounterfactualExplanation } from './explanation/counterfactual-explanation.model';
import { ModelFeature } from './public-api';
import { ExplanationNode } from './explanation/explanation-node';
export declare class Suggestion {
    uuid?: string;
    label?: string;
    summary?: string;
    actions?: Action[];
    qoe?: CodedValue;
    strength?: CodedValue;
    accepted: boolean;
    acceptancePerformer?: HealthCareProfessional;
    acceptedOn?: Date;
    classIRI?: string;
    confidence?: number;
    precision?: number;
    features?: Shap[];
    riskScores?: ModelFeature[];
    compliance?: ModelFeature[];
    guideLineExplanation?: GuideLineExplanation;
    counterfactualExplanation?: CounterfactualExplanation;
    treeExplanation?: ExplanationNode;
}
