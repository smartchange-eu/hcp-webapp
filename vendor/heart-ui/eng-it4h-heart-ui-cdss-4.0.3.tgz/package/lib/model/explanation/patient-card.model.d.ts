import { RiskLevel } from '@eng-it4h/heart-ui-model';
import { ModelFeature } from './model-feature.model';
export declare class PatientCard {
    risk?: number;
    risk_uncertainty?: number;
    level?: RiskLevel;
    age: number;
    features: ModelFeature[];
}
