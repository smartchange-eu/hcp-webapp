export declare class DatasetReference {
    title: string;
    date: Date;
    constructor(title: string, date: Date);
}
