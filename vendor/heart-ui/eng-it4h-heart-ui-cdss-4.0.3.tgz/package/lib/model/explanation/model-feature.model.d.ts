import { CodedValue } from '@eng-it4h/heart-ui-model';
export declare class ModelFeature {
    key: CodedValue;
    value: any;
    valueType: 'string' | 'number' | 'boolean' | 'code';
    valuesetCodes?: CodedValue[];
    unit?: string;
    constructor(k: CodedValue, value: any, unit?: string);
}
