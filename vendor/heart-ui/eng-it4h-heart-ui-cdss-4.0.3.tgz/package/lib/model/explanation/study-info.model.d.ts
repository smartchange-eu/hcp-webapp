export declare class StudyInfo {
    tripod_ai?: Map<string, string>;
}
