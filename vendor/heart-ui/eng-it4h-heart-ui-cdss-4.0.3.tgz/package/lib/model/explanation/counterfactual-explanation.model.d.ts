import { PatientCard } from './patient-card.model';
import { Counterfactual } from './counterfactual.model';
export declare class CounterfactualExplanation {
    current: PatientCard;
    forecasting: PatientCard[];
    counterfactuals: Counterfactual[];
}
