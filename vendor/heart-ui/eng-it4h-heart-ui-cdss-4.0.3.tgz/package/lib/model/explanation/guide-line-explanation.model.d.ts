export declare class GuideLineExplanation {
    explanationTexts: ExplanationText[];
    constructor(explanationTexts?: ExplanationText[]);
}
export declare class ExplanationText {
    text: string;
    value?: any;
    resourceId?: any;
    features?: string[];
    nestedExplanations?: ExplanationText[];
}
