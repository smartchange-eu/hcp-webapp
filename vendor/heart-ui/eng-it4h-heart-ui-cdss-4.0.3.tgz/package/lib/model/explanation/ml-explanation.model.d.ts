import { ModelDescriptor } from "./model-descriptor.model";
export declare class MlExplanation {
    description?: string;
    algType?: string;
    modelDescriptor?: ModelDescriptor;
}
