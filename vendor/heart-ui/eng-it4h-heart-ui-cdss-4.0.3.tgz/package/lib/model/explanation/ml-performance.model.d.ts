export declare class MlPerformance {
    accuracy?: number;
    sensitivity?: number;
    specificity?: number;
    precision?: number;
    f1Score?: number;
    constructor(accuracy?: number, sensitivity?: number, specificity?: number, precision?: number, f1Score?: number);
}
