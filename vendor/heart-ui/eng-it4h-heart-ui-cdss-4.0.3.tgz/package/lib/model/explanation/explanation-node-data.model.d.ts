import { Bound } from "../shap.model";
export declare type BRANCH = 'THEN' | 'ELSE';
export declare class ExplanationNodeData {
    root: boolean;
    condition?: Bound;
    value?: number;
    text?: string;
    resourceId?: string;
    branch?: BRANCH;
    parentData?: ExplanationNodeData;
    url?: string;
    constructor(root?: boolean, condition?: Bound, value?: number, text?: string, resourceId?: string, branch?: BRANCH, parentData?: ExplanationNodeData, url?: string);
}
