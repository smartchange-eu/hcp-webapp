import { DatasetReference } from "./dataset-reference.model";
export declare class DatasetDescriptor {
    accessRight?: string;
    collectionDate?: Date;
    creators?: string[];
    description?: string;
    title?: string;
    version?: string;
    referencedBy?: DatasetReference[];
}
