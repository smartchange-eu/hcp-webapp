export declare class ModelFile {
    id?: string;
    title?: string;
    url?: string;
    format?: string;
}
