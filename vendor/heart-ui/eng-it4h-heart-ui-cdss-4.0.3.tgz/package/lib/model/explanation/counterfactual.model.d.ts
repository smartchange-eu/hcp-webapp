import { PatientCard } from './patient-card.model';
export declare class Counterfactual {
    overall: PatientCard;
    forecasting: PatientCard[];
}
