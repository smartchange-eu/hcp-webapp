import { Shap } from "../shap.model";
import { DatasetDescriptor } from "./dataset-descriptor.model";
import { MlPerformance } from "./ml-performance.model";
import { ModelFile } from "./model-file.model";
import { StudyInfo } from "./study-info.model";
export declare class ModelDescriptor {
    created?: Date;
    creators?: string[];
    providers?: string;
    references?: string[];
    outputFile?: ModelFile;
    intendedUse?: string;
    limitations?: string;
    name?: string;
    trainedOns?: DatasetDescriptor[];
    trainingProcess?: string;
    testedOns?: DatasetDescriptor[];
    validatedOns?: DatasetDescriptor[];
    version?: string;
    evaluationResult?: string;
    performance?: MlPerformance;
    featuresContribution?: Shap[];
    clinicalStudyInfo?: StudyInfo;
    bias?: string;
    risks?: RiskDescriptor[];
}
export declare class RiskDescriptor {
    title: string;
    description: string;
    constructor(title: string, description: string);
}
