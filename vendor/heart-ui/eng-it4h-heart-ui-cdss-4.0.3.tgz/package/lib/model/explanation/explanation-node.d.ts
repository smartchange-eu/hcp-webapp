import { ExplanationNodeData } from "./explanation-node-data.model";
export declare class ExplanationNode {
    label?: string;
    data?: ExplanationNodeData;
    children?: ExplanationNode[];
}
