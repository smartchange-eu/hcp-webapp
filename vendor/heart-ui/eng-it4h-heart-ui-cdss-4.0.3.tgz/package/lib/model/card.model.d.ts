import { CodedValue, HealthCareProfessional } from '@eng-it4h/heart-ui-model';
import { Suggestion } from './suggestion.model';
import { Source } from './source.model';
import { MlModel } from './ml-model.model';
export declare type Level = 'info' | 'warning' | 'severe';
export declare class Card {
    uuid?: string;
    label?: string;
    summary?: string;
    specialties?: CodedValue[];
    source?: Source;
    suggestions?: Suggestion[];
    level?: CodedValue;
    selected: boolean;
    rightSection: boolean;
    unseen: boolean;
    status: 'new' | 'hidden' | 'accepting' | 'accepted' | 'overridden' | 'read' | 'stale';
    maxSelection: number;
    possibleOverrideReasons?: CodedValue[];
    overrideReason?: CodedValue;
    overrideNote?: string;
    createdOn?: Date;
    completedOn?: Date;
    completionPerformer?: string;
    completePerformer?: HealthCareProfessional;
    model?: MlModel;
}
