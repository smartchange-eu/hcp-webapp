import { CodedValue } from "@eng-it4h/heart-ui-model";
import { Shap } from "./shap.model";
import { MlPerformance } from "./explanation/ml-performance.model";
export declare class MlClass {
    cvLabel?: CodedValue;
    performance?: MlPerformance;
    featuresContribution?: Shap[];
}
