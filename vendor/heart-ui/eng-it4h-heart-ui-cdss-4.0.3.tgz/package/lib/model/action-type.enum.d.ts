import { CodedValue } from "@eng-it4h/heart-ui-model";
export declare enum ActionType {
    create = "create",
    update = "update",
    delete = "delete"
}
export declare namespace ActionType {
    function toCodedValue(actionType: ActionType): CodedValue;
    function values(): ActionType[];
    function convertFromString(string: string): ActionType;
}
