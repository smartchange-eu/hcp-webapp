import { CodedValue } from "@eng-it4h/heart-ui-model";
export declare class Source {
    label?: string;
    url?: string;
    citation?: string;
    topic?: CodedValue;
}
