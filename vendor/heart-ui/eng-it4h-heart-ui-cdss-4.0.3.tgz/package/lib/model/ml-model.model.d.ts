import { MlExplanation } from "./explanation/ml-explanation.model";
import { MlClass } from "./ml-class.model";
export declare class MlModel {
    modelName?: string;
    author?: string;
    decisionType?: string;
    classes?: MlClass[];
    explanation?: MlExplanation;
}
