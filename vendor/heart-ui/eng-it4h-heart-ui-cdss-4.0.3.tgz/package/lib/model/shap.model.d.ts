import { CodedValue } from '@eng-it4h/heart-ui-model';
export declare class Shap {
    key: CodedValue;
    contribution: number;
    value?: any;
    errorRange?: number;
    lowerBound?: Bound;
    upperBound?: Bound;
    intervalSign?: string;
    intervalValue?: string;
    constructor(key: CodedValue, contribution: number, value?: any);
}
export declare class Bound {
    sign: string;
    value: number;
    constructor(sign: string, value: number);
    getOppositeSign(): string;
    getOppositeCondition(): string;
}
