import { CodedValue } from '@eng-it4h/heart-ui-model';
export declare class Action {
    label?: string;
    resource?: any;
    toPerform?: CodedValue;
    constructor(label: string);
}
