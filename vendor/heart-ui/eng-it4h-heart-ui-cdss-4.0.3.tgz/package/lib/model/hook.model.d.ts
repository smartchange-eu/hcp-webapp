/**
 * The Hook must be subclassed to define the expected context stucture for a given 'hook'.
 *
 * As hook are project specific
 */
export declare abstract class Hook {
    protected context?: any;
    constructor(context?: any);
    /**
     * Name of the CDS Hook to be triggered
     */
    abstract get hook(): string;
    /**
     * JSON object representing the context.
     *
     * In case the hook doesn't support the context parameter it must return undefined
     */
    abstract contextToJSON(): unknown | undefined;
}
