import { InjectionToken, ModuleWithProviders, Provider } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "./xcds-broker-api/api.module";
import * as i2 from "ngx-markdown";
export interface CdssConfig {
    cdssUrl: string;
    converterService?: Provider;
}
export declare const CdssServiceConfig: InjectionToken<CdssConfig>;
export declare class HeartUiCdssModule {
    static forRoot(config: CdssConfig): ModuleWithProviders<HeartUiCdssModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<HeartUiCdssModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HeartUiCdssModule, never, [typeof i1.ApiModule, typeof i2.MarkdownModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HeartUiCdssModule>;
}
