export declare const it: {
    "cdss.card.manage-suggestion.button.label": string;
    "cdss.card.hide.button.tooltip": string;
    "cdss.card.unhide.button.tooltip": string;
    accepting: string;
    accepted: string;
    read: string;
    overridden: string;
    stale: string;
    hidden: string;
    "cdss.card.override-reason.label": string;
    "cdss.card.override-note.label": string;
};
