import { EventEmitter, OnInit } from '@angular/core';
import { Card } from '../model';
import { SubTranslateService } from '@eng-it4h/heart-ui-utils';
import * as i0 from "@angular/core";
export declare class CdssCardComponent implements OnInit {
    private _subTranslateService;
    lang: string;
    card: Card;
    showVisibilityButton: boolean;
    showDetailsButton: boolean;
    manageSuggestions: EventEmitter<Card>;
    hideCard: EventEmitter<{
        card: Card;
        hidden: boolean;
    }>;
    wider: boolean;
    constructor(_subTranslateService: SubTranslateService);
    createDictionary(): void;
    ngOnInit(): void;
    openCard(card: Card): void;
    toggleCardVisibility(card: Card): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdssCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CdssCardComponent, "heart-cdss-card", never, { "lang": "lang"; "card": "card"; "showVisibilityButton": "showVisibilityButton"; "showDetailsButton": "showDetailsButton"; "wider": "wider"; }, { "manageSuggestions": "manageSuggestions"; "hideCard": "hideCard"; }, never, never, false, never>;
}
