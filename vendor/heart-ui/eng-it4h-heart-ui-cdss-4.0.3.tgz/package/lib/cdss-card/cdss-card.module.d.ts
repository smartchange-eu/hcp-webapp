import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as i0 from "@angular/core";
import * as i1 from "./cdss-card.component";
import * as i2 from "@angular/common";
import * as i3 from "@eng-it4h/heart-ui-utils";
import * as i4 from "@ngx-translate/core";
import * as i5 from "@angular/material/icon";
import * as i6 from "@angular/material/button";
import * as i7 from "@angular/material/divider";
import * as i8 from "@angular/material/badge";
import * as i9 from "@angular/material/tooltip";
export declare function HttpLoaderFactoryCdssCard(http: HttpClient): TranslateHttpLoader;
export declare class CdssCardModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CdssCardModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CdssCardModule, [typeof i1.CdssCardComponent], [typeof i2.CommonModule, typeof i3.SubTranslateModule, typeof i4.TranslateModule, typeof i5.MatIconModule, typeof i6.MatButtonModule, typeof i7.MatDividerModule, typeof i8.MatBadgeModule, typeof i9.MatTooltipModule], [typeof i1.CdssCardComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CdssCardModule>;
}
