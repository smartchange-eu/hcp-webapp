import { Observable } from 'rxjs';
import { CdssConfig } from './heart-ui-cdss.module';
import { CodedValue } from '@eng-it4h/heart-ui-model';
import { BrokerService, CardsService, SuggestionsService, RegistryService } from './xcds-broker-api';
import { Card, Hook, ModelFeature, Suggestion } from './model';
import * as i0 from "@angular/core";
export declare class HeartUiCdssService {
    private _brokerApi;
    private _cardsApi;
    private _suggestionsApi;
    private _registryApi;
    private loremInfos?;
    private _converter;
    constructor(cdssConfig: CdssConfig, _brokerApi: BrokerService, _cardsApi: CardsService, _suggestionsApi: SuggestionsService, _registryApi: RegistryService);
    /**
     * Invoke the broker to trigger the evaluation of the new cards whenever
     * a new resource has been created or an event has been raised
     */
    updateCards(patientId: string, hook: Hook): Observable<Card[]>;
    getCardsByPatient(patientId: string): Observable<Card[]>;
    /**
     * IMPORTANT: this method has the side effect of updating the received inputs.
     *
     * For this reason it is mandatory that the 'suggestion' item is the one referred by 'card'
     *
     * @param patientId
     * @param card
     * @param suggestion
     * @returns
     */
    acceptSuggestion(patientId: string, card: Card, suggestion: Suggestion): Observable<void>;
    /**
     * IMPORTANT: this method has the side effect of updating the received inputs.
     *
     * @param patientId
     * @param card
     * @returns
     */
    closeCard(patientId: string, card: Card): Observable<void>;
    hideShowCard(patientId: string, card: Card, show: boolean): Observable<void>;
    /**
     * Call the XCDS Broker and update the status of the (easy model) 'card' object
     *
     * @param patientId
     * @param card
     * @param motivation
     * @param comment
     * @returns
     */
    refuseCard(patientId: string, card: Card, motivation?: CodedValue, comment?: string): Observable<void>;
    /*************************************
     * STUBBED (FAKE) METHODS
     *************************************/
    fakeGeneratedCards(): Card[];
    private getRandomInt;
    private fakeMarkdown;
    private fakeGenerateNewCard;
    private fakeGenerateRiskCard;
    getRandomFeatureSet(count?: number): ModelFeature[];
    static ɵfac: i0.ɵɵFactoryDeclaration<HeartUiCdssService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HeartUiCdssService>;
}
