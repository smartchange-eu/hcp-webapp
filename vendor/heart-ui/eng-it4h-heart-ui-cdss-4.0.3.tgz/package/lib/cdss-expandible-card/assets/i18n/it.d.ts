export declare const it: {
    "cdss.expandible-card.actions-count.label": string;
    "cdss.expandible-card.action-count.label": string;
};
