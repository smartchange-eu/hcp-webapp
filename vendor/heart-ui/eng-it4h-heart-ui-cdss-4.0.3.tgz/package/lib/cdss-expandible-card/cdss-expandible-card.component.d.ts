import { Card } from '../model';
import { SubTranslateService } from '@eng-it4h/heart-ui-utils';
import * as i0 from "@angular/core";
export declare class CdssExpandibleCardComponent {
    private _subTranslateService;
    lang: string;
    card: Card;
    constructor(_subTranslateService: SubTranslateService);
    createDictionary(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdssExpandibleCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CdssExpandibleCardComponent, "heart-cdss-expandible-card", never, { "lang": "lang"; "card": "card"; }, {}, never, never, false, never>;
}
