export declare const it: {
    "cdss.performance.accuracy.label": string;
    "cdss.performance.precision.label": string;
    "cdss.performance.sensitivity.label": string;
    "cdss.performance.specificity.label": string;
    "cdss.performance.f1Score.label": string;
    "cdss.performance.title.label": string;
};
