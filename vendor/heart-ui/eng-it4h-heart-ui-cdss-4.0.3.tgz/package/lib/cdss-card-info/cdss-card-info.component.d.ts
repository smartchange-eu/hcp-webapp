import { EventEmitter } from '@angular/core';
import { Card } from '../model';
import { SubTranslateService } from '@eng-it4h/heart-ui-utils';
import { MatDialog } from '@angular/material/dialog';
import * as i0 from "@angular/core";
export declare class CdssCardInfoComponent {
    private _subTranslateService;
    private _dialogService;
    lang: string;
    card: Card;
    openMlDetails: EventEmitter<Card>;
    private DIALOG_WIDTH;
    protected showMore: boolean;
    chars: number;
    constructor(_subTranslateService: SubTranslateService, _dialogService: MatDialog);
    createDictionary(): void;
    protected showCitationDetails(): void;
    protected openMlGlobalDetails(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdssCardInfoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CdssCardInfoComponent, "heart-cdss-card-info", never, { "lang": "lang"; "card": "card"; "chars": "chars"; }, { "openMlDetails": "openMlDetails"; }, never, never, false, never>;
}
