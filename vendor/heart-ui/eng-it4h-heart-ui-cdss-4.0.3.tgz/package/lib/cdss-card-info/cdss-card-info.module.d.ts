import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as i0 from "@angular/core";
import * as i1 from "./cdss-card-info.component";
import * as i2 from "./cdss-card-info-citation-dialog/cdss-card-info-citation-dialog.component";
import * as i3 from "@angular/common";
import * as i4 from "@eng-it4h/heart-ui-utils";
import * as i5 from "@ngx-translate/core";
import * as i6 from "@angular/material/icon";
import * as i7 from "@angular/material/button";
import * as i8 from "@angular/material/divider";
import * as i9 from "@angular/material/expansion";
import * as i10 from "@angular/material/dialog";
import * as i11 from "ngx-markdown";
export declare function HttpLoaderFactoryCdssCardInfo(http: HttpClient): TranslateHttpLoader;
export declare class CdssCardInfoModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CdssCardInfoModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CdssCardInfoModule, [typeof i1.CdssCardInfoComponent, typeof i2.CdssCardInfoCitationDialogComponent], [typeof i3.CommonModule, typeof i4.SubTranslateModule, typeof i5.TranslateModule, typeof i6.MatIconModule, typeof i7.MatButtonModule, typeof i8.MatDividerModule, typeof i9.MatExpansionModule, typeof i10.MatDialogModule, typeof i11.MarkdownModule], [typeof i1.CdssCardInfoComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CdssCardInfoModule>;
}
