export declare const it: {
    "cdss.card.info.citation.title.label": string;
    "cdss.card.info.citation.button.label": string;
    "cdss.card.info.citation.close.button.label": string;
    "cdss.card.info.global.model.button.label": string;
    "cdss.card.show-less.label": string;
    "cdss.card.show-more.label": string;
};
