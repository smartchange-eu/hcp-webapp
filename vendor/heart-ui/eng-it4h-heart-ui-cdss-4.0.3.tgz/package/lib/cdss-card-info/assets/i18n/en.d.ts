export declare const en: {
    "cdss.card.info.citation.title.label": string;
    "cdss.card.info.citation.button.label": string;
};
