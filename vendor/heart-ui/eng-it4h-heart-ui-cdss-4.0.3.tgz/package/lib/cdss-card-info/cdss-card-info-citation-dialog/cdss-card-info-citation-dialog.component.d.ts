import { MatDialogRef } from "@angular/material/dialog";
import { CdssCardInfoCitationDialog } from "./cdss-card-info-citation-dialog.model";
import * as i0 from "@angular/core";
export declare class CdssCardInfoCitationDialogComponent {
    private dialogRef;
    protected data: CdssCardInfoCitationDialog;
    constructor(dialogRef: MatDialogRef<CdssCardInfoCitationDialogComponent>, data: CdssCardInfoCitationDialog);
    static ɵfac: i0.ɵɵFactoryDeclaration<CdssCardInfoCitationDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CdssCardInfoCitationDialogComponent, "heart-cdss-card-info-citation-dialog", never, {}, {}, never, never, false, never>;
}
