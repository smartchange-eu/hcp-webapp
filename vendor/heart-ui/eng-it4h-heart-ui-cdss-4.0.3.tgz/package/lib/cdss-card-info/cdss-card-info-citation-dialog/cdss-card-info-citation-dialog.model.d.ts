export interface CdssCardInfoCitationDialog {
    citation: string;
    lang: string;
}
