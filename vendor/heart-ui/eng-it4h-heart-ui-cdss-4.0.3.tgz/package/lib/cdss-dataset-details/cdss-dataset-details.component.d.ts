import { OnInit } from '@angular/core';
import { DatasetDescriptor } from '../model';
import { SubTranslateService } from '@eng-it4h/heart-ui-utils';
import { TranslateService } from '@ngx-translate/core';
import * as i0 from "@angular/core";
export declare class CdssDatasetDetailsComponent implements OnInit {
    private _subTranslateService;
    private _translate;
    datasetDescriptor: DatasetDescriptor;
    lang: string;
    customTitle: string;
    constructor(_subTranslateService: SubTranslateService, _translate: TranslateService);
    createDictionary(): void;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdssDatasetDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CdssDatasetDetailsComponent, "heart-cdss-dataset-details", never, { "datasetDescriptor": "datasetDescriptor"; "lang": "lang"; "customTitle": "customTitle"; }, {}, never, never, false, never>;
}
