export declare const it: {
    "cdss.dataset.collectionDate.title": string;
    "cdss.dataset.accessRight.title": string;
    "cdss.dataset.creators.title": string;
    "cdss.dataset.description.title": string;
    "cdss.dataset.referencedBy.title": string;
};
