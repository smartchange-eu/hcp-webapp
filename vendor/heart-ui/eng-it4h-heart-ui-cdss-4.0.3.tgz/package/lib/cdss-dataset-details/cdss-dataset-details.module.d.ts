import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as i0 from "@angular/core";
import * as i1 from "./cdss-dataset-details.component";
import * as i2 from "@angular/common";
import * as i3 from "@eng-it4h/heart-ui-utils";
import * as i4 from "@ngx-translate/core";
import * as i5 from "@angular/material/icon";
import * as i6 from "@angular/material/button";
import * as i7 from "@angular/material/divider";
import * as i8 from "@angular/material/expansion";
import * as i9 from "@angular/material/list";
import * as i10 from "@swimlane/ngx-charts";
import * as i11 from "@angular/material/tooltip";
export declare function HttpLoaderFactoryCdssDataset(http: HttpClient): TranslateHttpLoader;
export declare class CdssDatasetDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CdssDatasetDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CdssDatasetDetailsModule, [typeof i1.CdssDatasetDetailsComponent], [typeof i2.CommonModule, typeof i3.SubTranslateModule, typeof i4.TranslateModule, typeof i5.MatIconModule, typeof i6.MatButtonModule, typeof i7.MatDividerModule, typeof i8.MatExpansionModule, typeof i9.MatListModule, typeof i3.PreventDoubleClickModule, typeof i4.TranslateModule, typeof i5.MatIconModule, typeof i6.MatButtonModule, typeof i7.MatDividerModule, typeof i8.MatExpansionModule, typeof i10.NgxChartsModule, typeof i11.MatTooltipModule], [typeof i1.CdssDatasetDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CdssDatasetDetailsModule>;
}
