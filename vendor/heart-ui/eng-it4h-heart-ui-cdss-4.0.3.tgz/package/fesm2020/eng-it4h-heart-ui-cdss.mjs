import * as i0 from '@angular/core';
import { InjectionToken, Injectable, Optional, Inject, NgModule, SkipSelf, EventEmitter, Component, Input, Output } from '@angular/core';
import { of } from 'rxjs';
import { map } from 'rxjs/operators';
import { LoremIpsum } from 'lorem-ipsum';
import * as i1 from '@angular/common/http';
import { HttpHeaders, HttpUrlEncodingCodec, HttpParams, HttpClient } from '@angular/common/http';
import * as i1$1 from 'ngx-markdown';
import { MarkdownModule } from 'ngx-markdown';
import { CodedValue, HealthCareProfessional, RiskLevel, Diagnosis, ConditionClinicalStatus, Risk } from '@eng-it4h/heart-ui-model';
import { FhirConverter } from '@eng-it4h/heart-ui-converter';
import { FhirLoaderUtils, Bundle } from '@eng-it4h/fhir-r5';
import { keys } from 'lodash-es';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i1$2 from '@eng-it4h/heart-ui-utils';
import { SubTranslateModule, PreventDoubleClickModule } from '@eng-it4h/heart-ui-utils';
import * as i3 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i4 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i5 from '@angular/material/divider';
import { MatDividerModule } from '@angular/material/divider';
import * as i6 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i1$3 from '@ngx-translate/core';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { MatBadgeModule } from '@angular/material/badge';
import * as i1$4 from '@angular/material/dialog';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import * as i4$1 from '@angular/material/expansion';
import { MatExpansionModule } from '@angular/material/expansion';
import * as i6$1 from '@angular/material/list';
import { MatListModule } from '@angular/material/list';
import * as i6$2 from '@swimlane/ngx-charts';
import { NgxChartsModule } from '@swimlane/ngx-charts';

const BASE_PATH = new InjectionToken('basePath');
const COLLECTION_FORMATS = {
    'csv': ',',
    'tsv': '   ',
    'ssv': ' ',
    'pipes': '|'
};

class Configuration {
    constructor(configurationParameters = {}) {
        this.apiKeys = configurationParameters.apiKeys;
        this.username = configurationParameters.username;
        this.password = configurationParameters.password;
        this.accessToken = configurationParameters.accessToken;
        this.basePath = configurationParameters.basePath;
        this.withCredentials = configurationParameters.withCredentials;
    }
    /**
     * Select the correct content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param contentTypes - the array of content types that are available for selection
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderContentType(contentTypes) {
        if (contentTypes.length == 0) {
            return undefined;
        }
        let type = contentTypes.find(x => this.isJsonMime(x));
        if (type === undefined) {
            return contentTypes[0];
        }
        return type;
    }
    /**
     * Select the correct accept content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct accept content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param accepts - the array of content types that are available for selection.
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderAccept(accepts) {
        if (accepts.length == 0) {
            return undefined;
        }
        let type = accepts.find(x => this.isJsonMime(x));
        if (type === undefined) {
            return accepts[0];
        }
        return type;
    }
    /**
     * Check if the given MIME is a JSON MIME.
     * JSON MIME examples:
     *   application/json
     *   application/json; charset=UTF8
     *   APPLICATION/JSON
     *   application/vnd.company+json
     * @param mime - MIME (Multipurpose Internet Mail Extensions)
     * @return True if the given MIME is JSON, false otherwise.
     */
    isJsonMime(mime) {
        const jsonMime = new RegExp('^(application\/json|[^;/ \t]+\/[^;/ \t]+[+]json)[ \t]*(;.*)?$', 'i');
        return mime != null && (jsonMime.test(mime) || mime.toLowerCase() === 'application/json-patch+json');
    }
}

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */ /* tslint:disable:no-unused-variable member-ordering */
class BrokerService {
    constructor(httpClient, basePath, configuration) {
        this.httpClient = httpClient;
        this.basePath = 'http://localhost:8080/xcdsbroker';
        this.defaultHeaders = new HttpHeaders();
        this.configuration = new Configuration();
        if (basePath) {
            this.basePath = basePath;
        }
        if (configuration) {
            this.configuration = configuration;
            this.basePath = basePath || configuration.basePath || this.basePath;
        }
    }
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    canConsumeForm(consumes) {
        const form = 'multipart/form-data';
        for (const consume of consumes) {
            if (form === consume) {
                return true;
            }
        }
        return false;
    }
    updateCards(body, authorization, observe = 'body', reportProgress = false) {
        if (body === null || body === undefined) {
            throw new Error('Required parameter body was null or undefined when calling updateCards.');
        }
        let headers = this.defaultHeaders;
        if (authorization !== undefined && authorization !== null) {
            headers = headers.set('Authorization', String(authorization));
        }
        // to determine the Accept header
        let httpHeaderAccepts = [
            'application/json'
        ];
        const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(httpHeaderAccepts);
        if (httpHeaderAcceptSelected != undefined) {
            headers = headers.set('Accept', httpHeaderAcceptSelected);
        }
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected != undefined) {
            headers = headers.set('Content-Type', httpContentTypeSelected);
        }
        return this.httpClient.request('post', `${this.basePath}/cds-services`, {
            body: body,
            withCredentials: this.configuration.withCredentials,
            headers: headers,
            observe: observe,
            reportProgress: reportProgress
        });
    }
}
BrokerService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: BrokerService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
BrokerService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: BrokerService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: BrokerService, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }]; } });

/**
* CustomHttpUrlEncodingCodec
* Fix plus sign (+) not encoding, so sent as blank space
* See: https://github.com/angular/angular/issues/11058#issuecomment-247367318
*/
class CustomHttpUrlEncodingCodec extends HttpUrlEncodingCodec {
    encodeKey(k) {
        k = super.encodeKey(k);
        return k.replace(/\+/gi, '%2B');
    }
    encodeValue(v) {
        v = super.encodeValue(v);
        return v.replace(/\+/gi, '%2B');
    }
}

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */ /* tslint:disable:no-unused-variable member-ordering */
class CardsService {
    constructor(httpClient, basePath, configuration) {
        this.httpClient = httpClient;
        this.basePath = 'http://localhost:8080/xcdsbroker';
        this.defaultHeaders = new HttpHeaders();
        this.configuration = new Configuration();
        if (basePath) {
            this.basePath = basePath;
        }
        if (configuration) {
            this.configuration = configuration;
            this.basePath = basePath || configuration.basePath || this.basePath;
        }
    }
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    canConsumeForm(consumes) {
        const form = 'multipart/form-data';
        for (const consume of consumes) {
            if (form === consume) {
                return true;
            }
        }
        return false;
    }
    changeCardStatus(body, patientId, cardUuid, observe = 'body', reportProgress = false) {
        if (body === null || body === undefined) {
            throw new Error('Required parameter body was null or undefined when calling changeCardStatus.');
        }
        if (patientId === null || patientId === undefined) {
            throw new Error('Required parameter patientId was null or undefined when calling changeCardStatus.');
        }
        if (cardUuid === null || cardUuid === undefined) {
            throw new Error('Required parameter cardUuid was null or undefined when calling changeCardStatus.');
        }
        let headers = this.defaultHeaders;
        // to determine the Accept header
        let httpHeaderAccepts = [];
        const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(httpHeaderAccepts);
        if (httpHeaderAcceptSelected != undefined) {
            headers = headers.set('Accept', httpHeaderAcceptSelected);
        }
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected != undefined) {
            headers = headers.set('Content-Type', httpContentTypeSelected);
        }
        return this.httpClient.request('put', `${this.basePath}/cds-services/${encodeURIComponent(String(patientId))}/cards/${encodeURIComponent(String(cardUuid))}`, {
            body: body,
            withCredentials: this.configuration.withCredentials,
            headers: headers,
            observe: observe,
            reportProgress: reportProgress
        });
    }
    getCardByUuid(patientId, cardUuid, observe = 'body', reportProgress = false) {
        if (patientId === null || patientId === undefined) {
            throw new Error('Required parameter patientId was null or undefined when calling getCardByUuid.');
        }
        if (cardUuid === null || cardUuid === undefined) {
            throw new Error('Required parameter cardUuid was null or undefined when calling getCardByUuid.');
        }
        let headers = this.defaultHeaders;
        // to determine the Accept header
        let httpHeaderAccepts = [
            'application/json'
        ];
        const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(httpHeaderAccepts);
        if (httpHeaderAcceptSelected != undefined) {
            headers = headers.set('Accept', httpHeaderAcceptSelected);
        }
        // to determine the Content-Type header
        const consumes = [];
        return this.httpClient.request('get', `${this.basePath}/cds-services/${encodeURIComponent(String(patientId))}/cards/${encodeURIComponent(String(cardUuid))}`, {
            withCredentials: this.configuration.withCredentials,
            headers: headers,
            observe: observe,
            reportProgress: reportProgress
        });
    }
    getCardsByPatient(patientId, status, observe = 'body', reportProgress = false) {
        if (patientId === null || patientId === undefined) {
            throw new Error('Required parameter patientId was null or undefined when calling getCardsByPatient.');
        }
        let queryParameters = new HttpParams({ encoder: new CustomHttpUrlEncodingCodec() });
        if (status !== undefined && status !== null) {
            queryParameters = queryParameters.set('status', status);
        }
        let headers = this.defaultHeaders;
        // to determine the Accept header
        let httpHeaderAccepts = [
            'application/json'
        ];
        const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(httpHeaderAccepts);
        if (httpHeaderAcceptSelected != undefined) {
            headers = headers.set('Accept', httpHeaderAcceptSelected);
        }
        // to determine the Content-Type header
        const consumes = [];
        return this.httpClient.request('get', `${this.basePath}/cds-services/${encodeURIComponent(String(patientId))}/cards`, {
            params: queryParameters,
            withCredentials: this.configuration.withCredentials,
            headers: headers,
            observe: observe,
            reportProgress: reportProgress
        });
    }
}
CardsService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CardsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
CardsService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CardsService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CardsService, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }]; } });

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */ /* tslint:disable:no-unused-variable member-ordering */
class HEARTBaseAPIsService {
    constructor(httpClient, basePath, configuration) {
        this.httpClient = httpClient;
        this.basePath = 'http://localhost:8080/xcdsbroker';
        this.defaultHeaders = new HttpHeaders();
        this.configuration = new Configuration();
        if (basePath) {
            this.basePath = basePath;
        }
        if (configuration) {
            this.configuration = configuration;
            this.basePath = basePath || configuration.basePath || this.basePath;
        }
    }
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    canConsumeForm(consumes) {
        const form = 'multipart/form-data';
        for (const consume of consumes) {
            if (form === consume) {
                return true;
            }
        }
        return false;
    }
    emptyTestService(observe = 'body', reportProgress = false) {
        let headers = this.defaultHeaders;
        // to determine the Accept header
        let httpHeaderAccepts = [
            'application/json'
        ];
        const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(httpHeaderAccepts);
        if (httpHeaderAcceptSelected != undefined) {
            headers = headers.set('Accept', httpHeaderAcceptSelected);
        }
        // to determine the Content-Type header
        const consumes = [];
        return this.httpClient.request('get', `${this.basePath}/rest`, {
            withCredentials: this.configuration.withCredentials,
            headers: headers,
            observe: observe,
            reportProgress: reportProgress
        });
    }
}
HEARTBaseAPIsService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HEARTBaseAPIsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
HEARTBaseAPIsService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HEARTBaseAPIsService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HEARTBaseAPIsService, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }]; } });

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */ /* tslint:disable:no-unused-variable member-ordering */
class RegistryService {
    constructor(httpClient, basePath, configuration) {
        this.httpClient = httpClient;
        this.basePath = 'http://localhost:8080/xcdsbroker';
        this.defaultHeaders = new HttpHeaders();
        this.configuration = new Configuration();
        if (basePath) {
            this.basePath = basePath;
        }
        if (configuration) {
            this.configuration = configuration;
            this.basePath = basePath || configuration.basePath || this.basePath;
        }
    }
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    canConsumeForm(consumes) {
        const form = 'multipart/form-data';
        for (const consume of consumes) {
            if (form === consume) {
                return true;
            }
        }
        return false;
    }
    getServices(observe = 'body', reportProgress = false) {
        let headers = this.defaultHeaders;
        // to determine the Accept header
        let httpHeaderAccepts = [
            'application/json'
        ];
        const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(httpHeaderAccepts);
        if (httpHeaderAcceptSelected != undefined) {
            headers = headers.set('Accept', httpHeaderAcceptSelected);
        }
        // to determine the Content-Type header
        const consumes = [];
        return this.httpClient.request('get', `${this.basePath}/registry`, {
            withCredentials: this.configuration.withCredentials,
            headers: headers,
            observe: observe,
            reportProgress: reportProgress
        });
    }
    registerService(body, observe = 'body', reportProgress = false) {
        if (body === null || body === undefined) {
            throw new Error('Required parameter body was null or undefined when calling registerService.');
        }
        let headers = this.defaultHeaders;
        // to determine the Accept header
        let httpHeaderAccepts = [];
        const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(httpHeaderAccepts);
        if (httpHeaderAcceptSelected != undefined) {
            headers = headers.set('Accept', httpHeaderAcceptSelected);
        }
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected != undefined) {
            headers = headers.set('Content-Type', httpContentTypeSelected);
        }
        return this.httpClient.request('post', `${this.basePath}/registry`, {
            body: body,
            withCredentials: this.configuration.withCredentials,
            headers: headers,
            observe: observe,
            reportProgress: reportProgress
        });
    }
}
RegistryService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RegistryService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
RegistryService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RegistryService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RegistryService, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }]; } });

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */ /* tslint:disable:no-unused-variable member-ordering */
class SuggestionsService {
    constructor(httpClient, basePath, configuration) {
        this.httpClient = httpClient;
        this.basePath = 'http://localhost:8080/xcdsbroker';
        this.defaultHeaders = new HttpHeaders();
        this.configuration = new Configuration();
        if (basePath) {
            this.basePath = basePath;
        }
        if (configuration) {
            this.configuration = configuration;
            this.basePath = basePath || configuration.basePath || this.basePath;
        }
    }
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    canConsumeForm(consumes) {
        const form = 'multipart/form-data';
        for (const consume of consumes) {
            if (form === consume) {
                return true;
            }
        }
        return false;
    }
    acceptSuggestion(patientId, cardUuid, suggestionUuid, body, observe = 'body', reportProgress = false) {
        if (patientId === null || patientId === undefined) {
            throw new Error('Required parameter patientId was null or undefined when calling acceptSuggestion.');
        }
        if (cardUuid === null || cardUuid === undefined) {
            throw new Error('Required parameter cardUuid was null or undefined when calling acceptSuggestion.');
        }
        if (suggestionUuid === null || suggestionUuid === undefined) {
            throw new Error('Required parameter suggestionUuid was null or undefined when calling acceptSuggestion.');
        }
        let headers = this.defaultHeaders;
        // to determine the Accept header
        let httpHeaderAccepts = [];
        const httpHeaderAcceptSelected = this.configuration.selectHeaderAccept(httpHeaderAccepts);
        if (httpHeaderAcceptSelected != undefined) {
            headers = headers.set('Accept', httpHeaderAcceptSelected);
        }
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected != undefined) {
            headers = headers.set('Content-Type', httpContentTypeSelected);
        }
        return this.httpClient.request('put', `${this.basePath}/cds-services/${encodeURIComponent(String(patientId))}/cards/${encodeURIComponent(String(cardUuid))}/suggestions/${encodeURIComponent(String(suggestionUuid))}`, {
            body: body,
            withCredentials: this.configuration.withCredentials,
            headers: headers,
            observe: observe,
            reportProgress: reportProgress
        });
    }
}
SuggestionsService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: SuggestionsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
SuggestionsService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: SuggestionsService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: SuggestionsService, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }]; } });

const APIS = [BrokerService, CardsService, HEARTBaseAPIsService, RegistryService, SuggestionsService];

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */

var CdsServiceResponseCard;
(function (CdsServiceResponseCard) {
    CdsServiceResponseCard.IndicatorEnum = {
        Info: 'info',
        Warning: 'warning',
        Critical: 'critical'
    };
    CdsServiceResponseCard.SelectionBehaviorEnum = {
        AtMostOne: 'at-most-one',
        Any: 'any'
    };
})(CdsServiceResponseCard || (CdsServiceResponseCard = {}));

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */

var ChangeCardStatusDto;
(function (ChangeCardStatusDto) {
    ChangeCardStatusDto.StatusEnum = {
        NEW: 'NEW',
        ACCEPTING: 'ACCEPTING',
        HIDDEN: 'HIDDEN',
        ACCEPTED: 'ACCEPTED',
        OVERRIDDEN: 'OVERRIDDEN',
        READ: 'READ',
        STALE: 'STALE'
    };
})(ChangeCardStatusDto || (ChangeCardStatusDto = {}));

var XCDSCard;
(function (XCDSCard) {
    XCDSCard.StatusEnum = {
        NEW: 'NEW',
        ACCEPTING: 'ACCEPTING',
        HIDDEN: 'HIDDEN',
        ACCEPTED: 'ACCEPTED',
        OVERRIDDEN: 'OVERRIDDEN',
        READ: 'READ',
        STALE: 'STALE',
    };
})(XCDSCard || (XCDSCard = {}));

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */

/**
 * REST API
 * This API are meant for internal usage.
 *
 * OpenAPI spec version: 1.0
 *
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */
var XCDSSuggestion;
(function (XCDSSuggestion) {
    XCDSSuggestion.StatusEnum = {
        SUGGESTED: 'SUGGESTED',
        ACCEPTED: 'ACCEPTED',
        IGNORED: 'IGNORED',
        OVERRIDDEN: 'OVERRIDDEN',
        STALE: 'STALE'
    };
})(XCDSSuggestion || (XCDSSuggestion = {}));

class ApiModule {
    constructor(parentModule, http) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
                'See also https://github.com/angular/angular/issues/20575');
        }
    }
    static forRoot(configurationFactory) {
        return {
            ngModule: ApiModule,
            providers: [{ provide: Configuration, useFactory: configurationFactory }]
        };
    }
}
ApiModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ApiModule, deps: [{ token: ApiModule, optional: true, skipSelf: true }, { token: i1.HttpClient, optional: true }], target: i0.ɵɵFactoryTarget.NgModule });
ApiModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: ApiModule });
ApiModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ApiModule, providers: [
        BrokerService,
        CardsService,
        HEARTBaseAPIsService,
        RegistryService,
        SuggestionsService
    ] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ApiModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    declarations: [],
                    exports: [],
                    providers: [
                        BrokerService,
                        CardsService,
                        HEARTBaseAPIsService,
                        RegistryService,
                        SuggestionsService
                    ]
                }]
        }], ctorParameters: function () { return [{ type: ApiModule, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.HttpClient, decorators: [{
                    type: Optional
                }] }]; } });

const CdssServiceConfig = new InjectionToken('CdssConfig');
class HeartUiCdssModule {
    static forRoot(config) {
        return {
            ngModule: HeartUiCdssModule,
            providers: [
                HeartUiCdssService,
                {
                    provide: CdssServiceConfig,
                    useValue: config,
                }
            ],
        };
    }
}
HeartUiCdssModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartUiCdssModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
HeartUiCdssModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: HeartUiCdssModule, imports: [ApiModule, i1$1.MarkdownModule] });
HeartUiCdssModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartUiCdssModule, imports: [ApiModule,
        MarkdownModule.forRoot()] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartUiCdssModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [
                        ApiModule,
                        MarkdownModule.forRoot(),
                    ],
                    exports: [],
                    providers: []
                }]
        }] });

class Action {
    constructor(label) {
        this.label = label;
    }
}

var ActionType;
(function (ActionType) {
    ActionType["create"] = "create";
    ActionType["update"] = "update";
    ActionType["delete"] = "delete";
})(ActionType || (ActionType = {}));
(function (ActionType) {
    function toCodedValue(actionType) {
        let label;
        if (actionType == ActionType.create) {
            label = 'Create';
        }
        else if (actionType == ActionType.update) {
            label = 'Update';
        }
        else {
            label = 'Delete';
        }
        return new CodedValue('', actionType.toString(), label);
    }
    ActionType.toCodedValue = toCodedValue;
    function values() {
        return Object.values(ActionType);
    }
    ActionType.values = values;
    function convertFromString(string) {
        return this.values().find(v => v == string);
    }
    ActionType.convertFromString = convertFromString;
})(ActionType || (ActionType = {}));

class Card {
    constructor() {
        this.selected = false;
        this.rightSection = false; // simulating the match between the section and something in the card related to that section
        this.unseen = true; // FORMER KNOWN AS new
        this.status = 'new';
        this.maxSelection = 100;
    }
}

class Suggestion {
    constructor() {
        this.accepted = false;
    }
}

/**
 * The Hook must be subclassed to define the expected context stucture for a given 'hook'.
 *
 * As hook are project specific
 */
class Hook {
    constructor(context) {
        this.context = context;
    }
}

class MlModel {
}

class MlClass {
}

class Shap {
    constructor(key, contribution, value) {
        this.key = key;
        this.contribution = contribution;
        this.value = value;
    }
}
class Bound {
    constructor(sign, value) {
        this.sign = sign;
        this.value = value;
    }
    getOppositeSign() {
        let toRet = '';
        if (this.sign) {
            switch (this.sign) {
                case '<':
                    toRet = '>';
                    break;
                case '≤':
                    toRet = '≥';
                    break;
                case '>':
                    toRet = '<';
                    break;
                case '≥':
                    toRet = '≤';
                    break;
                default:
                    break;
            }
        }
        return toRet;
    }
    getOppositeCondition() {
        let toRet = '';
        if (this.sign) {
            switch (this.sign) {
                case '<':
                    toRet = '≥';
                    break;
                case '≤':
                    toRet = '>';
                    break;
                case '>':
                    toRet = '≤';
                    break;
                case '≥':
                    toRet = '<';
                    break;
                default:
                    break;
            }
        }
        return toRet;
    }
}

class DatasetDescriptor {
}

class MlExplanation {
}

class MlPerformance {
    constructor(accuracy, sensitivity, specificity, precision, f1Score) {
        this.accuracy = accuracy;
        this.sensitivity = sensitivity;
        this.specificity = specificity;
        this.precision = precision;
        this.f1Score = f1Score;
    }
}

class ModelDescriptor {
}
class RiskDescriptor {
    constructor(title, description) {
        this.title = title;
        this.description = description;
    }
}

class ModelFile {
}

class StudyInfo {
}

class ModelFeature {
    constructor(k, value, unit) {
        this.key = k;
        let valueType = typeof value;
        switch (valueType) {
            case 'string':
                this.valueType = 'string';
                break;
            case 'number':
            case 'bigint':
                this.valueType = 'number';
                break;
            case 'boolean':
                this.valueType = 'boolean';
                break;
            case 'object':
                if (value instanceof CodedValue) {
                    this.valueType = 'code';
                    break;
                }
                else {
                    throw new Error('unsupported value type');
                }
            default:
                throw new Error('unsupported value type');
        }
        this.value = value;
        this.unit = unit;
    }
}

class Counterfactual {
}

class PatientCard {
}

class CounterfactualExplanation {
}

class Source {
}

class DatasetReference {
    constructor(title, date) {
        this.title = title;
        this.date = date;
    }
}

class GuideLineExplanation {
    constructor(explanationTexts) {
        this.explanationTexts = explanationTexts ?? [];
    }
}
class ExplanationText {
}

class ExplanationNode {
}

class ExplanationNodeData {
    constructor(root = false, condition, value, text, resourceId, branch, parentData, url) {
        this.root = root;
        this.condition = condition;
        this.value = value;
        this.text = text;
        this.resourceId = resourceId;
        this.branch = branch;
        this.parentData = parentData;
        this.url = url;
    }
}

class HeartUICdssConverter {
    constructor(_fhirConverter) {
        this._fhirConverter = _fhirConverter;
    }
    toDataModelXCDSCard(xcdsCard) {
        const res = new Card();
        const card = xcdsCard.card;
        res.uuid = xcdsCard.uuid;
        res.label = card.summary; // short string
        res.summary = card.detail; // long string
        if (typeof xcdsCard.createdOn == 'number') {
            res.createdOn = new Date(xcdsCard.createdOn);
        }
        else
            res.createdOn = xcdsCard.createdOn;
        res.completedOn = xcdsCard.completedOn;
        res.completionPerformer = xcdsCard.completionPerformer;
        switch (xcdsCard.status) {
            // "NEW" | "ACCEPTING" | "HIDDEN" | "ACCEPTED" | "OVERRIDDEN" | "READ" | "STALE"
            case 'NEW':
                res.unseen = true;
                res.status = 'new';
                break;
            case 'HIDDEN':
                res.unseen = false;
                res.status = 'hidden';
                break;
            case 'ACCEPTING':
                res.unseen = false;
                res.status = 'accepting';
                break;
            case 'ACCEPTED':
                res.unseen = false;
                res.status = 'accepted';
                break;
            case 'OVERRIDDEN':
                res.unseen = false;
                res.status = 'overridden';
                break;
            case 'READ':
                res.unseen = false;
                res.status = 'read';
                break;
            case 'STALE':
                res.unseen = false;
                res.status = 'stale';
                break;
        }
        // card.selectionBehavior
        if (card.selectionBehavior) {
            // at-most-one [0,1] OR any [0+]
            switch (card.selectionBehavior) {
                case 'at-most-one':
                    res.maxSelection = 1;
                    break;
                default:
                    break;
            }
        }
        // Extension management
        if (card.extension) {
            // Model management
            const model = new MlModel();
            model.modelName = card.extension['name'] ?? undefined;
            // const langKey = '@language';
            if (card.extension['@context'] != undefined) {
                const context = card.extension['@context'];
                const subItem = card.extension['outputClasses'];
                model.classes = [];
                for (var key in subItem) {
                    // if (subItem[key][langKey] == undefined) { // TODO: i18n
                    const c = new MlClass();
                    c.cvLabel = new CodedValue('', context[subItem[key]], subItem[key]);
                    model.classes.push(c);
                    // } // TODO: i18n
                }
            }
            // prepares the list of shortcuts for the explanations
            const context = card.extension['@context'];
            this.contextClasses = new Map();
            for (var key in context) {
                const value = context[key];
                if (typeof value == 'string') {
                    this.contextClasses.set(value, key);
                }
            }
            if (card.extension['globalExplaination'] != undefined) {
                // featuresImportance
                const ge = card.extension['globalExplaination'];
                // const i18n = this.prepareCodedValuesTranslated(feats) // TODO: i18n
                model.classes.forEach((c) => {
                    // const shaps = feats[c.cvLabel!.display];
                    const cl = ge[key];
                    c.featuresContribution = [];
                    for (var shapName in cl) {
                        // const shap = new Shap(i18n.get(shapName)!, c[shapName].shap); // TODO: i18n
                        const shap = new Shap(new CodedValue('', shapName, shapName), c[shapName].shap);
                        c.featuresContribution.push(shap);
                    }
                    this.sortShaps(c.featuresContribution);
                });
            }
            if (card.extension['baseModelDescription'] != undefined) {
                // eplanation MLDCAT-AP
                const md = card.extension['baseModelDescription'];
                let exp = new MlExplanation();
                exp.description = md['description'];
                exp.algType = card.extension['algorithmType'];
                let desc = new ModelDescriptor();
                desc.created = md['craeted'] ?? undefined;
                desc.creators = md['creator']?.map((e) => e['name']?.join(', '));
                desc.references = md['hasBibliographicReference']?.map((e) => e['bibliographicCitation']);
                if (md['hasOutputFilePrediction'] != undefined) {
                    const f = md['hasOutputFilePrediction'];
                    desc.outputFile = this.getFileDescriptor(f);
                }
                desc.intendedUse = md['intendedUse'];
                desc.limitations = md['limitations'];
                desc.evaluationResult = md['evaluationResults'];
                desc.providers = md['hasProvider']?.map((e) => e['name']?.join(', '));
                if (md['trainedOn'] != undefined) {
                    //  Array.isArray(md['trainedOn']) ?
                    desc.trainedOns = Array.isArray(md['trainedOn']) ? md['trainedOn']?.map((jsonSection) => this.getDatasetDescriptor(jsonSection)) : undefined;
                }
                if (md['testedOn'] != undefined) {
                    desc.testedOns = md['testedOn']?.map((jsonSection) => this.getDatasetDescriptor(jsonSection));
                }
                if (md['validatedOn'] != undefined) {
                    desc.validatedOns = md['validatedOn']?.map((jsonSection) => this.getDatasetDescriptor(jsonSection));
                }
                desc.trainingProcess = md['trainingProcess'];
                desc.version = md['version'];
                desc.bias = md['bias'];
                if (md['hasRisk']) {
                    // desc.risks = md['hasRisk']?.map((e) => new RiskDescriptor(e['title'], e['description']));
                    try {
                        desc.risks = md.hasRisk?.map((e) => new RiskDescriptor(e['title'], e['description']));
                    }
                    catch (e) {
                        console.error('[CDSS CONVERTER#toDataModelXCDSCard] RCV a STRING instead of an ARRAY. Trying to parsing using JSON.parse');
                        // console.warn(e)
                        const parsed = JSON.parse(md.hasRisk);
                        desc.risks = parsed?.map((e) => new RiskDescriptor(e['title'], e['description']));
                    }
                }
                // TO REMOVE - FROM HERE
                // desc.featuresContribution = [];
                // for (let i = 0; i < 12; i++) {
                //   const shap = new Shap( new CodedValue('system',"http://feature_"+i,"feature_"+i), i*(i-2))
                //   desc.featuresContribution.push(shap)
                // }
                // TO REMOVE - TO HERE
                exp.modelDescriptor = desc;
                model.explanation = exp;
            }
            if (card.extension['clinicalModelStudy'] != undefined) {
                // eplanation TRIPOD_AI
                const tripodSection = card.extension['clinicalModelStudy'];
                let tripod = new StudyInfo();
                if (!model.explanation) {
                    model.explanation = new MlExplanation();
                }
                if (!model.explanation.modelDescriptor) {
                    model.explanation.modelDescriptor = new ModelDescriptor();
                }
                model.explanation.modelDescriptor.clinicalStudyInfo = this.getStudyInfo(tripodSection);
            }
            // Classes performance
            if (card.extension['performance'] != undefined) {
                const perfs = card.extension['performance'];
                model.classes.forEach((c) => {
                    const perf = perfs[c.cvLabel.display];
                    if (perf) {
                        const classP = new MlPerformance(perf['accuracy'], perf['sensitivity'], perf['specificity'], perf['precision'], perf['f1-score']);
                        c.performance = classP;
                    }
                });
                // nel modelDescriptor
                // TODO => diventerà .avg [22/10/2024 telco con giovanni]
                if (perfs['weighted avg'] != undefined) {
                    if (!model.explanation) {
                        model.explanation = new MlExplanation();
                    }
                    if (!model.explanation.modelDescriptor) {
                        model.explanation.modelDescriptor = new ModelDescriptor();
                    }
                    const perf = perfs['weighted avg'];
                    model.explanation.modelDescriptor.performance = new MlPerformance(perf['accuracy'], perf['sensitivity'], perf['specificity'], perf['precision'], perf['f1-score']);
                }
            }
            res.model = model;
        }
        // IMPORTANT: this piece of code needs that the xcdsCard.suggestions and card.suggestions to have the same order
        // as we can't use the UUID to match the respective items because the (nested) card suggestions may not have one
        // while the XCDSCARD ones is mandatory.
        // This is valid as it is based on a CDS modelling assumption yet it is risky
        if (xcdsCard.suggestions) {
            // extract the keys (i.e. the suggestion UUID) from the 'suggestions' map.
            // the returned array prevers the original map order
            var suggestionsUUIDs = keys(xcdsCard.suggestions);
            res.suggestions = suggestionsUUIDs.map((suggestionUuid, index) => {
                var xcdsCardSuggestion = xcdsCard.suggestions[suggestionUuid];
                var cardSuggestion = card.suggestions[index];
                const suggestion = this.toDataModelXCDSSuggestion(cardSuggestion, xcdsCardSuggestion);
                // copying the precision of the class into each suggestion
                suggestion.precision = this.getClassPrecision(cardSuggestion, res.model);
                return suggestion;
            });
            this.sortSuggestions(res.suggestions);
        }
        // xcdsCard.suggestionStatuses
        //   ?.map((xcdsCardSuggestionStatus, index) => {
        //     var cardSuggestion = card.suggestions[index];
        //     const suggestion = this.toDataModelXCDSSuggestion(cardSuggestion);
        //     suggestion.accepted = xcdsCardSuggestionStatus.status == 'ACCEPTED';
        //     return suggestion;
        //   });
        if (card.source) {
            const xcdsSource = card.source;
            const source = new Source();
            source.label = xcdsSource.label;
            source.url = xcdsSource.url;
            if (xcdsSource.topic) {
                const t = xcdsSource.topic;
                source.topic = new CodedValue(t.system, t.code, t.display);
            }
            if (xcdsSource.extension) {
                source.citation = xcdsSource.extension['citation'];
            }
            res.source = source;
        }
        // info | warning | severe
        res.level = HeartUICdssConverter.levels.find((l) => l.code == card.indicator);
        // card.links
        // convert the set of override reasons to pick from while refusing the card
        res.possibleOverrideReasons = card.overrideReasons?.map((coding) => new CodedValue(coding.system, coding.code, coding.display));
        res.possibleOverrideReasons = res.possibleOverrideReasons?.length > 0 ? res.possibleOverrideReasons : undefined;
        // convert the existing override reason. It can be valorized only for 'refused' cards
        const xcdsOverrideReason = xcdsCard.overrideReasons[0];
        if (xcdsOverrideReason && xcdsOverrideReason.code) {
            const xcdsOverrideReasonTuple = this.toDataModelXCDSOverrideReason(xcdsOverrideReason);
            res.overrideReason = xcdsOverrideReasonTuple?.codedValue;
            res.overrideNote = xcdsOverrideReasonTuple?.note;
        }
        return res;
    }
    getFileDescriptor(jsonSection) {
        const file = new ModelFile();
        file.id = jsonSection['id'];
        file.title = jsonSection['title'];
        file.format = jsonSection['format'];
        file.url = jsonSection['url'];
        return file;
    }
    getDatasetDescriptor(jsonSection) {
        const dd = new DatasetDescriptor();
        dd.accessRight = jsonSection['accessRights'];
        dd.collectionDate = jsonSection['collectionDate'];
        dd.creators = jsonSection['creator']?.map((e) => e['name']?.join(', '));
        dd.description = jsonSection['description']?.join(', ');
        dd.title = jsonSection['title']?.join(', ');
        dd.version = jsonSection['versionLabel'];
        dd.referencedBy = jsonSection['isReferencedBy']?.map((e) => new DatasetReference(e['title'], e['date']));
        if (dd.accessRight || dd.collectionDate || dd.creators || dd.description || dd.title || dd.version || dd.referencedBy) {
            return dd;
        }
        return undefined;
    }
    getStudyInfo(jsonSection) {
        const si = new StudyInfo();
        si.tripod_ai = new Map();
        for (var key in jsonSection) {
            si.tripod_ai.set(key, jsonSection[key]);
        }
        return si;
    }
    getClassPrecision(cardSuggestion, model) {
        if (model && cardSuggestion?.extension['class']) {
            const toSearch = cardSuggestion?.extension['class'];
            const mlClass = model.classes.find((c) => c.cvLabel.code == toSearch);
            return mlClass?.performance?.precision ?? 0;
        }
        else if (model && model.classes && model.classes.length > 0) {
            // guideline - prendo il primo elemento
            const mlClass = model.classes[0];
            return mlClass?.performance?.precision ?? 0;
        }
        return 0;
    }
    sortShaps(shaps, reverseOrder = true) {
        shaps.sort((a, b) => (reverseOrder ? b.contribution - a.contribution : a.contribution - b.contribution));
    }
    //sort forecast
    sortForecasting(fd, reverseOrder = true) {
        fd.sort((a, b) => (reverseOrder ? b.risk - a.risk : a.risk - b.risk));
    }
    sortSuggestions(suggestions, reverseOrder = true) {
        suggestions.sort((a, b) => (reverseOrder ? (b.confidence ?? 0) - (a.confidence ?? 0) : (a.confidence ?? 0) - (b.confidence ?? 0)));
    }
    sortPatientCard(p, reverseOrder = true) {
        p.features.sort((a, b) => (reverseOrder ? b.key.code.localeCompare(a.key.code) : a.key.code.localeCompare(b.key.code)));
    }
    toDataModelXCDSOverrideReason(overrideReason) {
        const xcdsCode = overrideReason.code;
        const xcdsUserComment = overrideReason.userComment;
        const codedValue = new CodedValue(xcdsCode.system, xcdsCode.code, xcdsCode.display);
        return {
            codedValue,
            note: xcdsUserComment,
        };
    }
    toDataModelXCDSSuggestion(xcdsSuggestion, xcdsCardSuggestion) {
        const suggestion = new Suggestion();
        suggestion.label = xcdsSuggestion.label;
        // we need the ID in case we want to notify the XCDS which suggestion has been accepted/refused
        suggestion.uuid = xcdsCardSuggestion.uuid || xcdsSuggestion.uuid;
        suggestion.accepted = xcdsCardSuggestion.status == 'ACCEPTED';
        if (xcdsCardSuggestion.acceptancePerformer) {
            const hcpRefString = xcdsCardSuggestion.acceptancePerformer;
            const index = hcpRefString.lastIndexOf('/');
            if (index >= 0) {
                var perfId = hcpRefString.substring(index + 1);
                suggestion.acceptancePerformer = new HealthCareProfessional(+perfId);
            }
        }
        suggestion.acceptedOn = xcdsCardSuggestion?.acceptedOn;
        suggestion.actions = xcdsSuggestion.actions?.filter((a) => a != undefined).map((a) => this.toDataModelXCDSAction(a));
        suggestion.confidence = xcdsSuggestion.extension ? xcdsSuggestion.extension['confidence'] ?? undefined : undefined;
        suggestion.classIRI = xcdsSuggestion.extension ? xcdsSuggestion.extension['class'] ?? undefined : undefined;
        if (xcdsSuggestion.extension && xcdsSuggestion.extension['featuresImportance']) {
            const context = xcdsSuggestion.extension['featuresImportance']['@context'];
            this.contextFix(context);
            if ((xcdsSuggestion.extension && xcdsSuggestion.extension['forecasting']) || (xcdsSuggestion.extension && xcdsSuggestion.extension['counterfactuals'])) {
                suggestion.counterfactualExplanation = new CounterfactualExplanation();
                suggestion.counterfactualExplanation.current = new PatientCard();
                // Forecasting
                if (xcdsSuggestion.extension && xcdsSuggestion.extension['forecasting']) {
                    // Inizializzo l'array per memorizzare i dati di forecasting
                    suggestion.counterfactualExplanation.forecasting = [];
                    // Ottengo i dati di forecasting
                    const indexesForecast = xcdsSuggestion.extension['forecasting'];
                    // Itero su tutte le chiavi del forecasting
                    for (const key in indexesForecast) {
                        if (key != '@context') {
                            const data = indexesForecast[key];
                            // Creo un oggetto PatientCard
                            const ptIndexes = new PatientCard();
                            // inizio a prelevare i primi 4 parametri caratterizzanti il forecasting
                            ptIndexes.risk = data.risk;
                            ptIndexes.risk_uncertainty = data.risk_uncertainty;
                            // THIS IS A HACK TO INCLUDE UNCERTAINTY MANUALLY
                            this.includeUncertainty(suggestion, ptIndexes.risk_uncertainty);
                            ptIndexes.level = this.getLevel(data.level);
                            // Assegno l'età prevista per il forecasting
                            ptIndexes.age = data.age_of_forecast;
                            // Raggruppo i parametri misurati come ModelFeature[]
                            ptIndexes.features = [];
                            for (const paramKey in data) {
                                // Escludo i parametri principali già assegnati (risk, risk_uncertainty, level, age_of_forecast)
                                if (paramKey != 'risk' && paramKey != 'risk_uncertainty' && paramKey != 'level' && paramKey != 'age_of_forecast') {
                                    const paramValue = data[paramKey];
                                    // Verifico che il valore non sia una stringa (?) e che la chiave esista nel contesto
                                    if (typeof paramValue != 'string' && context[paramKey]) {
                                        // Creo un oggetto ModelFeature con i dati restanti recuperati e lo aggiungo all'array
                                        try {
                                            const modFeat = new ModelFeature(new CodedValue('', context[paramKey], paramKey), paramValue);
                                            ptIndexes.features.push(modFeat);
                                        }
                                        catch (error) { }
                                    }
                                }
                            }
                            this.sortPatientCard(ptIndexes);
                            // Aggiungo il PatientCard completo all'array forecasting
                            suggestion.counterfactualExplanation.forecasting.push(ptIndexes);
                        }
                    }
                    // Ordino i dati di forecasting?
                    this.sortForecasting(suggestion.counterfactualExplanation.forecasting);
                }
                //counterfactuals
                if (xcdsSuggestion.extension && xcdsSuggestion.extension['counterfactuals']) {
                    // Recupero il contesto da featuresImportance
                    const context = xcdsSuggestion.extension['featuresImportance']['@context'];
                    this.contextFix(context);
                    // Inizializzo l'array per memorizzare i dati di counterfactuals
                    suggestion.counterfactualExplanation.counterfactuals = [];
                    // Ottengo i dati di counterfactuals
                    const counterfactualsData = xcdsSuggestion.extension['counterfactuals'];
                    //eseguo l'iterazione sui dati counterfactuals
                    for (const key in counterfactualsData) {
                        //escludo il context
                        if (key != '@context') {
                            const cfData = counterfactualsData[key];
                            // Creo un oggetto Counterfactual per inserire i dati della sezione del json extension.counterfactuals
                            const counterfactual = new Counterfactual();
                            /* 1. counterfactual.overall:
                            1.1. vanno recuperati i dati della sezione counterfactual.overall
                            1.2. i dati recuperati vanno messi nel campo 'overall' del Counterfactual*/
                            const overall = new PatientCard();
                            overall.risk = cfData.overall.risk;
                            overall.risk_uncertainty = cfData.overall.risk_uncertainty;
                            overall.level = this.getLevel(cfData.overall.level);
                            overall.age = cfData.overall.age_of_counterfactual;
                            // Inizializzo 'modelFeature'
                            overall.features = [];
                            // eseguo l'iterazione sui parametri del 'overall'
                            for (const paramKey in cfData.overall) {
                                // Escludo i parametri già assegnati (risk, risk_uncertainty, level, age_of_counterfactual)
                                if (paramKey != 'risk' && paramKey != 'risk_uncertainty' && paramKey != 'level' && paramKey != 'age_of_counterfactual') {
                                    const paramValue = cfData.overall[paramKey];
                                    // Verifico che il valore non sia una stringa (?) e che la chiave esista nel contesto
                                    if (typeof paramValue != 'string' && context[paramKey]) {
                                        // Creo un oggetto ModelFeature con i dati recuperati e lo aggiungo all'array
                                        try {
                                            const modFeat = new ModelFeature(new CodedValue('', context[paramKey], paramKey), paramValue);
                                            overall.features.push(modFeat);
                                        }
                                        catch (error) { }
                                    }
                                }
                            }
                            this.sortPatientCard(overall);
                            // Assegno 'overall' al Counterfactual.overall
                            counterfactual.overall = overall;
                            /* 2. counterfactual.forecasting:
                            2.1. vanno recuperati i dati della sezione counterfactual.forecasting
                            2.2. i dati recuperati vanno messi nel campo 'forecasting' del Counterfactual che è un array*/
                            counterfactual.forecasting = [];
                            for (const forecastData of cfData.forecasting) {
                                const forecastIndex = new PatientCard();
                                forecastIndex.risk = forecastData.risk;
                                forecastIndex.risk_uncertainty = forecastData.risk_uncertainty;
                                forecastIndex.level = this.getLevel(forecastData.level);
                                forecastIndex.age = forecastData.age_of_forecast;
                                // Inizializzo 'modelFeature'
                                forecastIndex.features = [];
                                // Itero sui parametri del 'forecasting'
                                for (const paramKey in forecastData) {
                                    // Escludo i parametri già assegnati (risk, risk_uncertainty, level, age_of_forecast)
                                    if (paramKey != 'risk' && paramKey != 'risk_uncertainty' && paramKey != 'level' && paramKey != 'age_of_forecast') {
                                        const paramValue = forecastData[paramKey];
                                        // Verifico che il valore non sia una stringa (?) e che la chiave esista nel contesto
                                        if (typeof paramValue != 'string' && context[paramKey]) {
                                            try {
                                                // Creo un oggetto ModelFeature con i dati recuperati e lo aggiungo all'array
                                                const modFeat = new ModelFeature(new CodedValue('', context[paramKey], paramKey), paramValue);
                                                forecastIndex.features.push(modFeat);
                                            }
                                            catch (error) { }
                                        }
                                    }
                                }
                                this.sortPatientCard(forecastIndex);
                                // Aggiungo l'oggetto PatientCard all'array 'forecasting'
                                counterfactual.forecasting.push(forecastIndex);
                            }
                            // console.log('Counterfactuals data processed:', suggestion.counterfactuals);
                            // Aggiungo tutto l'oggetto Counterfactual all'array di suggestion.counterfactuals
                            suggestion.counterfactualExplanation.counterfactuals.push(counterfactual);
                        }
                    }
                    if (suggestion.counterfactualExplanation.counterfactuals.length > 0) {
                        suggestion.counterfactualExplanation.current.age = suggestion.counterfactualExplanation.counterfactuals[0].overall.age;
                    }
                }
            }
            suggestion.features = [];
            const shaps = xcdsSuggestion.extension['featuresImportance'];
            // const i18n = this.prepareCodedValuesTranslated(shaps) // TODO: i18n
            for (var key in shaps) {
                if (key != '@context' && key != '.otherFeatures') {
                    const c = shaps[key];
                    if (typeof c != 'string' && context[key]) {
                        // console.log(c);
                        // for (let shapName in c) {
                        // const shap = new Shap(i18n.get(shapName)!, c[shapName].shap, c[shapName].value);
                        const shap = new Shap(new CodedValue('', context[key], key), c['importance'], c['value']);
                        shap.errorRange = c.sigma_weight;
                        if (c.interval) {
                            const interval = c.interval;
                            if (interval.minValue) {
                                shap.lowerBound = new Bound('≥', interval.minValue);
                            }
                            else if (interval.valueMinorant) {
                                shap.lowerBound = new Bound('>', interval.valueMinorant);
                            }
                            if (interval.maxValue) {
                                shap.upperBound = new Bound('≤', interval.maxValue);
                            }
                            else if (interval.valueMajorant) {
                                shap.upperBound = new Bound('<', interval.valueMajorant);
                            }
                        }
                        suggestion.features.push(shap);
                    }
                }
            }
            this.sortShaps(suggestion.features);
            if (suggestion.counterfactualExplanation.current) {
                suggestion.counterfactualExplanation.current.features = suggestion.features
                    .filter((s) => {
                    if (s.key && s.key instanceof CodedValue && s.value != undefined)
                        return true;
                    return false;
                })
                    .map((s) => {
                    try {
                        const m = new ModelFeature(s.key, s.value);
                        return m;
                    }
                    catch (error) {
                        return undefined;
                    }
                })
                    .filter((ss) => ss != undefined);
                this.sortPatientCard(suggestion.counterfactualExplanation.current);
            }
        }
        //riskScores
        if (xcdsSuggestion.extension && xcdsSuggestion.extension['riskFactors']) {
            // Recupero il contesto da featuresImportance
            const context = xcdsSuggestion.extension['riskFactors']['@context'];
            // Inizializzo l'array per memorizzare i dati di counterfactuals
            suggestion.riskScores = [];
            // Ottengo i dati di counterfactuals
            const riskScoresData = xcdsSuggestion.extension['riskFactors'];
            //eseguo l'iterazione sui dati counterfactuals
            for (const key in riskScoresData) {
                if (key != '@context' && key != '.otherFeatures' && context[key]) {
                    const c = riskScoresData[key];
                    if (typeof c != 'string') {
                        try {
                            const score = new ModelFeature(new CodedValue('', context[key], key), c['value']);
                            suggestion.riskScores.push(score);
                        }
                        catch (e) { }
                    }
                }
            }
        }
        //compliance
        if (xcdsSuggestion.extension && xcdsSuggestion.extension['compliance']) {
            // Recupero il contesto da featuresImportance
            const context = xcdsSuggestion.extension['compliance']['@context'];
            // Inizializzo l'array per memorizzare i dati di counterfactuals
            suggestion.compliance = [];
            // Ottengo i dati di counterfactuals
            const complianceData = xcdsSuggestion.extension['compliance']['values'];
            if (context && complianceData) {
                //eseguo l'iterazione sui dati
                for (const paramKey in complianceData) {
                    // Escludo il context
                    if (paramKey != '@context') {
                        const paramValue = complianceData[paramKey];
                        // Verifico che il valore non sia una stringa (?) e che la chiave esista nel contesto
                        if (typeof paramValue != 'string' && context[paramKey]) {
                            try {
                                // Creo un oggetto ModelFeature con i dati recuperati e lo aggiungo all'array
                                const modFeat = new ModelFeature(new CodedValue('', context[paramKey], paramKey), paramValue);
                                suggestion.compliance.push(modFeat);
                            }
                            catch (error) { }
                        }
                    }
                }
            }
        }
        // guideline explanation
        if (xcdsSuggestion.extension && xcdsSuggestion.extension['explainationTexts']) {
            const glExp = new GuideLineExplanation();
            const jsonSection = xcdsSuggestion.extension['explainationTexts'];
            jsonSection.forEach((item) => {
                glExp.explanationTexts.push(this.getExplanationText(item));
            });
            suggestion.guideLineExplanation = glExp;
        }
        // DECISION TREE
        if (xcdsSuggestion.extension && xcdsSuggestion.extension['explanationItems']) {
            const jsonNode = xcdsSuggestion.extension['explanationItems'][0];
            if (jsonNode) {
                const treeNode = this.getExplanationNode(jsonNode);
                treeNode.data.root = true;
                suggestion.treeExplanation = treeNode;
            }
        }
        return suggestion;
    }
    includeUncertainty(suggestion, risk_uncertainty) {
        const risk = suggestion.actions?.find((a) => a.resource.resourceType == 'Risk')?.resource;
        risk?.predictions?.forEach((p) => {
            const percent = p.probability;
            p.range = { min: percent - risk_uncertainty, max: percent + risk_uncertainty };
        });
    }
    getLevel(level) {
        switch (level) {
            case 'low':
                return RiskLevel.LOW;
            case 'moderate':
                return RiskLevel.MODERATE;
            case 'high':
                return RiskLevel.HIGH;
            default:
                return undefined;
        }
    }
    getExplanationNode(jsonNode, branch, parentData) {
        const node = new ExplanationNode();
        const data = new ExplanationNodeData();
        let bound;
        if (jsonNode['maxValue']) {
            bound = new Bound('≤', jsonNode['maxValue']);
        }
        else if (jsonNode['valueMajorant']) {
            bound = new Bound('<', jsonNode['valueMajorant']);
        }
        else if (jsonNode['minValue']) {
            bound = new Bound('≥', jsonNode['minValue']);
        }
        else if (jsonNode['valueMajorant']) {
            bound = new Bound('>', jsonNode['valueMinorant']);
        }
        else {
            // it should not reach this for the intermediate nodes
            console.debug('IMPOSSIBLE TO DETERMINE THE SIGN OF THIS NODE: ' + JSON.stringify(jsonNode));
            // throw new Error("IMPOSSIBLE TO DETERMINE THE SIGN OF THIS NODE: "+ jsonNode );
        }
        data.condition = bound;
        data.value = jsonNode['value'];
        data.text = jsonNode['text'];
        data.branch = branch;
        data.resourceId = jsonNode['resourceId'];
        if (parentData) {
            data.parentData = parentData;
        }
        node.data = data;
        // reverseMap for getting the contextString (if available)
        node.label = jsonNode['feature'];
        if (this.contextClasses) {
            // const shortcut = this.contextClasses.find(cv => cv.code==node.label)
            const shortcut = this.contextClasses.get(node.label);
            if (shortcut) {
                node.data.url = node.label;
                node.label = shortcut;
            }
        }
        if (jsonNode['then'] || jsonNode['else']) {
            node.children = [];
            if (jsonNode['then']) {
                node.children.push(this.getExplanationNode(jsonNode['then'], 'THEN', node.data));
            }
            if (jsonNode['else']) {
                node.children.push(this.getExplanationNode(jsonNode['else'], 'ELSE', node.data));
            }
        }
        return node;
    }
    getExplanationText(jsonSection, parent) {
        const glText = new ExplanationText();
        glText.text = jsonSection['text'];
        glText.value = jsonSection['value'];
        glText.features = jsonSection['feature'];
        glText.resourceId = jsonSection['resourceId'];
        if (jsonSection['explainationTexts']) {
            const subSection = jsonSection['explainationTexts'];
            if (!glText.nestedExplanations) {
                glText.nestedExplanations = [];
            }
            subSection.forEach((sub) => {
                glText.nestedExplanations.push(this.getExplanationText(sub, glText));
            });
        }
        return glText;
    }
    // FIXME: this is a workaround to fix the context placeholder
    contextFix(context) {
        for (const key in context) {
            if (context[key] == 'PLACEHOLDER') {
                context[key] = 'http://tmp-system/' + key;
            }
        }
    }
    prepareCodedValuesTranslated(section) {
        let i18n = new Map();
        // const cards: any = fakeCard.cards;
        const cards = section;
        cards.forEach((item) => {
            // if (item.extension['featuresImportance']) {
            const i18nClasses = this.geti18nForSubsection(item.extension);
            const i18nShaps = this.geti18nForSubsection(item.extension['featuresImportance']);
            i18n = new Map([...i18nClasses, ...i18nShaps]);
            // }
        });
        return i18n;
    }
    geti18nForSubsection(section) {
        const i18n = new Map();
        const translated = [];
        const contextLabel = '@context';
        const idKey = '@id';
        const langKey = '@language';
        const ctxs = section[contextLabel];
        for (let key in ctxs) {
            // console.log(key + '=> ' + ctxs[key]);
            section = ctxs[key];
            const iri = section[idKey];
            if (section[langKey]) {
                const tr = section[key];
                translated.push(new CodedValue('', iri, tr));
            }
            else {
                i18n.set(key, new CodedValue('', iri));
            }
            const itemInMap = this.findInMap(i18n, iri);
            const findInTranslated = translated.find((cv) => cv.code == iri);
            if (itemInMap && findInTranslated) {
                let filled = { ...itemInMap, ...findInTranslated };
                const universalKey = this.getKey(i18n, itemInMap);
                if (universalKey) {
                    i18n.set(universalKey, filled);
                }
            }
        }
        return i18n;
    }
    findInMap(map, code) {
        return [...map.values()].find((entry) => entry.code == code);
    }
    getKey(map, cv) {
        for (let [key, value] of map.entries()) {
            if (value === cv)
                return key;
        }
        return undefined;
    }
    toDataModelXCDSAction(xcdsAction) {
        const action = new Action(xcdsAction.description);
        // TODO: uncomment once the FHIR Converter has been injected
        if (xcdsAction.resource && this._fhirConverter) {
            try {
                const rawResource = xcdsAction.resource;
                const fhirResource = FhirLoaderUtils.attributeRevive(rawResource, Bundle._resourceRevive);
                if (xcdsAction.type == 'create') {
                    fhirResource.id = undefined;
                }
                const convertedResource = this._fhirConverter.toDataModel(fhirResource);
                action.resource = convertedResource;
            }
            catch (err) {
                console.error('Suggested resource conversion error', err);
            }
        }
        action.toPerform = HeartUICdssConverter.toPerforms?.find((tp) => tp.code == xcdsAction.type);
        return action;
    }
}
HeartUICdssConverter.levels = [new CodedValue('system', 'info', 'info'), new CodedValue('system', 'warning', 'Warning'), new CodedValue('system', 'severe', 'Severe')];
HeartUICdssConverter.qoes = [new CodedValue('system', 'high', 'High'), new CodedValue('system', 'mid', 'Medium'), new CodedValue('system', 'low', 'Low')];
HeartUICdssConverter.strengths = [new CodedValue('system', 'strong', 'Strong'), new CodedValue('system', 'mid', 'Medium'), new CodedValue('system', 'weak', 'Weak')];
HeartUICdssConverter.toPerforms = [ActionType.toCodedValue(ActionType.create), ActionType.toCodedValue(ActionType.update), ActionType.toCodedValue(ActionType.delete)];

class HeartUiCdssService {
    constructor(cdssConfig, _brokerApi, _cardsApi, _suggestionsApi, _registryApi) {
        this._brokerApi = _brokerApi;
        this._cardsApi = _cardsApi;
        this._suggestionsApi = _suggestionsApi;
        this._registryApi = _registryApi;
        this._brokerApi.basePath = cdssConfig.cdssUrl;
        this._cardsApi.basePath = cdssConfig.cdssUrl;
        this._suggestionsApi.basePath = cdssConfig.cdssUrl;
        this._registryApi.basePath = cdssConfig.cdssUrl;
        this._converter = new HeartUICdssConverter(new FhirConverter());
        if (cdssConfig.cdssUrl == undefined || cdssConfig.cdssUrl == '') {
            this.loremInfos = new LoremIpsum({
                sentencesPerParagraph: {
                    max: 8,
                    min: 4,
                },
                wordsPerSentence: {
                    max: 16,
                    min: 4,
                },
            });
        }
    }
    /**
     * Invoke the broker to trigger the evaluation of the new cards whenever
     * a new resource has been created or an event has been raised
     */
    updateCards(patientId, hook) {
        const request = {
            patientId: patientId,
            context: hook.contextToJSON(),
            hook: hook.hook,
            hookInstance: self.crypto.randomUUID(),
        };
        return this._brokerApi.updateCards(request).pipe(map((cards) => cards?.map((c) => this._converter.toDataModelXCDSCard(c)) || []));
    }
    getCardsByPatient(patientId) {
        if (this.loremInfos) {
            return of(this.fakeGeneratedCards());
        }
        else {
            let card$ = this._cardsApi.getCardsByPatient(patientId).pipe(map((cards) => cards?.map((c) => this._converter.toDataModelXCDSCard(c)) || []));
            return card$;
        }
    }
    /**
     * IMPORTANT: this method has the side effect of updating the received inputs.
     *
     * For this reason it is mandatory that the 'suggestion' item is the one referred by 'card'
     *
     * @param patientId
     * @param card
     * @param suggestion
     * @returns
     */
    acceptSuggestion(patientId, card, suggestion) {
        let request;
        if (this.loremInfos) {
            request = of();
        }
        else {
            request = this._suggestionsApi.acceptSuggestion(patientId, card.uuid, suggestion.uuid);
        }
        return request.pipe(map(() => {
            // change the (easy model) suggestion status after the successful invocation of the XCDS server
            suggestion.accepted = true;
            // set the card status to 'accepted' (if it is the last acceptable suggestion) or 'accepting'
            if (card.maxSelection == 1 || !(card.suggestions?.filter((s) => !s.accepted).length > 0)) {
                card.status = 'accepted';
            }
            else {
                card.status = 'accepting';
            }
            card.unseen = false;
        }));
    }
    /**
     * IMPORTANT: this method has the side effect of updating the received inputs.
     *
     * @param patientId
     * @param card
     * @returns
     */
    closeCard(patientId, card) {
        let request;
        const hasSuggestions = card.suggestions?.length > 0;
        const hasAcceptedSuggestions = card.suggestions?.filter((s) => s.accepted).length > 0;
        if (hasSuggestions && !(hasAcceptedSuggestions && card.status == 'accepting')) {
            throw new Error(`Require to accept at least 1 suggestion and to close only card with 'ACCEPTING' status`);
        }
        if (this.loremInfos) {
            request = of();
        }
        else {
            const isAcceptable = hasSuggestions && hasAcceptedSuggestions;
            const _body = { status: isAcceptable ? ChangeCardStatusDto.StatusEnum.ACCEPTED : ChangeCardStatusDto.StatusEnum.READ };
            request = this._cardsApi.changeCardStatus(_body, patientId, card.uuid);
        }
        return request.pipe(map(() => {
            // change the (easy model) card status after the successful invocation of the XCDS server
            card.status = hasSuggestions && hasAcceptedSuggestions ? 'accepted' : 'read';
            card.unseen = false;
        }));
    }
    hideShowCard(patientId, card, show) {
        let request;
        if (this.loremInfos) {
            request = of();
        }
        else {
            const _body = { status: show ? ChangeCardStatusDto.StatusEnum.NEW : ChangeCardStatusDto.StatusEnum.HIDDEN };
            request = this._cardsApi.changeCardStatus(_body, patientId, card.uuid);
        }
        return request.pipe(map(() => {
            // change the (easy model) card status after the successful invocation of the XCDS server
            card.status = show ? 'new' : 'hidden';
            card.unseen = false;
        }));
    }
    /**
     * Call the XCDS Broker and update the status of the (easy model) 'card' object
     *
     * @param patientId
     * @param card
     * @param motivation
     * @param comment
     * @returns
     */
    refuseCard(patientId, card, motivation, comment) {
        let request;
        if (this.loremInfos) {
            request = of();
        }
        else {
            const motivationAsCoding = motivation ? { system: motivation.system, code: motivation.code, display: motivation.display } : undefined;
            const _body = { status: ChangeCardStatusDto.StatusEnum.OVERRIDDEN, motivations: [motivationAsCoding], comment: comment };
            request = this._cardsApi.changeCardStatus(_body, patientId, card.uuid);
        }
        return request.pipe(map(() => {
            // change the (easy model) card status after the successful invocation of the XCDS server
            card.status = 'overridden';
            card.unseen = false;
            // set in the easy model the motivation and comment so that the UI is aligned with the broker
            card.overrideReason = motivation;
            card.overrideNote = comment;
        }));
    }
    /*************************************
     * STUBBED (FAKE) METHODS
     *************************************/
    fakeGeneratedCards() {
        const fake = [];
        const tot = this.getRandomInt(3) + 1;
        console.log(`generating [${tot}] fake cards`);
        for (let i = 0; i < tot; i++) {
            fake.push(this.fakeGenerateRiskCard());
        }
        return fake;
    }
    getRandomInt(max) {
        return Math.round(Math.random() * max);
    }
    fakeMarkdown() {
        // IMPORTANT: gli spazi sono importanti per questo non ci sono ad inizio riga
        const msg = `Questo è un riassunto della card.
# questo potrebbe essere un titolo di primo livello
## questo potrebbe essere un titolo di secondo livello
### questo potrebbe essere un titolo di terzo livello

E questo un elenco: 
- elemento
- elemento
- questo ha una parte in **grassetto**
- questo ha una parte in *corsivo*

Questo è del testo discorsivo.

E qui vorrei andare a capo.

1. elenco numerato
1. elenco numerato
1. elenco numerato

_ciao_`;
        return msg;
    }
    fakeGenerateNewCard() {
        const m = new MlModel();
        m.modelName = 'IIT Decision Model';
        m.author = 'Istituto italiano di tecnologia';
        m.decisionType = 'Diagnosi - febbri ricorrenti';
        // FIXME in subobject
        // m.modelType = new CodedValue("that.system","machine-learning", "Machine Learning")
        // m.externalLink = "https://www.eng.it/case-studies/she-piattaforma-cloud-per-la-diagnostica-avanzata-basata-su-dati-clinico-omici"
        // m.performance = new MlPerformance(Math.random(),Math.random(),Math.random())
        m.classes = [];
        for (let i = 0; i < 3; i++) {
            const mlClass = new MlClass();
            mlClass.cvLabel = new CodedValue('', 'http://code_' + i, 'class_' + i);
            mlClass.performance = new MlPerformance(Math.random(), Math.random(), Math.random());
            mlClass.featuresContribution = [];
            for (let j = 0; j < 10; j++) {
                const shap = new Shap(new CodedValue('', 'http://feature_' + j, 'feature_' + j), this.getRandomInt(100), this.getRandomInt(500));
                mlClass.featuresContribution.push(shap);
            }
            m.classes.push(mlClass);
        }
        const c = new Card();
        c.model = m;
        c.label = this.loremInfos.generateWords(this.getRandomInt(3));
        // c.summary = this.loremInfos.generateParagraphs(this.getRandomInt(3));
        c.summary = this.fakeMarkdown();
        c.level = HeartUICdssConverter.levels[this.getRandomInt(2)];
        c.specialties = [new CodedValue(undefined, this.loremInfos.generateWords(2))];
        c.source = new Source();
        c.source.url = 'http://www.eng.it';
        c.source.label = 'linee guida sdadsa';
        c.suggestions = [];
        if (this.getRandomInt(2) / 2 == 1) {
            c.possibleOverrideReasons = [
                new CodedValue('that.system', 'no_meaning', 'non significa niente'),
                new CodedValue('that.system', 'unclear', 'non è chiaro cosa farebbe se accettassi'),
                new CodedValue('that.system', 'no_for_this_patient', 'non si applica al paziente'),
            ];
        }
        c.uuid = self.crypto.randomUUID();
        c.maxSelection = this.getRandomInt(2);
        switch (this.getRandomInt(6)) {
            // "NEW" | "ACCEPTING" | "HIDDEN" | "ACCEPTED" | "OVERRIDDEN" | "READ" | "STALE"
            case 0:
                c.unseen = true;
                c.status = 'new';
                break;
            case 1:
                c.unseen = false;
                c.status = 'hidden';
                break;
            case 2:
                c.unseen = false;
                c.status = 'accepting';
                break;
            case 3:
                c.unseen = false;
                c.status = 'accepted';
                break;
            case 4:
                c.unseen = false;
                c.status = 'overridden';
                break;
            case 5:
                c.unseen = false;
                c.status = 'read';
                break;
            case 6:
                c.unseen = false;
                c.status = 'stale';
                break;
        }
        let sugs = this.getRandomInt(5);
        for (let j = 0; j < sugs; j++) {
            const s = new Suggestion();
            s.uuid = self.crypto.randomUUID();
            s.label = this.loremInfos.generateWords(this.getRandomInt(5));
            s.summary = this.loremInfos.generateParagraphs(this.getRandomInt(4));
            s.qoe = HeartUICdssConverter.qoes[this.getRandomInt(2)];
            s.strength = HeartUICdssConverter.strengths[this.getRandomInt(2)];
            s.actions = [];
            s.uuid = this.getRandomInt(1000) + '';
            s.acceptancePerformer = new HealthCareProfessional(this.getRandomInt(120));
            s.acceptedOn = new Date();
            const acts = this.getRandomInt(5);
            for (let k = 0; k < acts; k++) {
                // crea un'Action che fa una redirect verso l'inserimento diagnosi
                const a = new Action(this.loremInfos.generateWords(this.getRandomInt(5)));
                const res = new Diagnosis();
                res.code = new CodedValue('thisSystem', 'thisCode', 'DISPLAY THIS');
                res.clinicalStatus = ConditionClinicalStatus.ACTIVE;
                a.resource = res;
                a.toPerform = ActionType.toCodedValue(ActionType.create);
                s.actions.push(a);
            }
            s.features = [];
            for (let j = 0; j < 10; j++) {
                const shap = new Shap(new CodedValue('', 'http://feature_' + j, 'feature_' + j), this.getRandomInt(100), this.getRandomInt(500));
                s.features.push(shap);
            }
            s.confidence = Math.random();
            s.precision = Math.random();
            c.suggestions.push(s);
        }
        return c;
    }
    fakeGenerateRiskCard() {
        const c = new Card();
        c.label = this.loremInfos.generateWords(this.getRandomInt(3));
        // c.summary = this.loremInfos.generateParagraphs(this.getRandomInt(3));
        c.summary = this.fakeMarkdown();
        c.level = HeartUICdssConverter.levels[this.getRandomInt(2)];
        c.specialties = [new CodedValue(undefined, this.loremInfos.generateWords(2))];
        c.source = new Source();
        c.source.url = 'http://www.eng.it';
        c.source.label = 'linee guida sdadsa';
        c.suggestions = [];
        if (this.getRandomInt(2) / 2 == 1) {
            c.possibleOverrideReasons = [
                new CodedValue('that.system', 'no_meaning', 'non significa niente'),
                new CodedValue('that.system', 'unclear', 'non è chiaro cosa farebbe se accettassi'),
                new CodedValue('that.system', 'no_for_this_patient', 'non si applica al paziente'),
            ];
        }
        c.uuid = self.crypto.randomUUID();
        c.maxSelection = 100;
        switch (this.getRandomInt(6)) {
            // "NEW" | "ACCEPTING" | "HIDDEN" | "ACCEPTED" | "OVERRIDDEN" | "READ" | "STALE"
            case 0:
                c.unseen = true;
                c.status = 'new';
                break;
            case 1:
                c.unseen = false;
                c.status = 'hidden';
                break;
            case 2:
                c.unseen = false;
                c.status = 'accepting';
                break;
            case 3:
                c.unseen = false;
                c.status = 'accepted';
                break;
            case 4:
                c.unseen = false;
                c.status = 'overridden';
                break;
            case 5:
                c.unseen = false;
                c.status = 'read';
                break;
            case 6:
                c.unseen = false;
                c.status = 'stale';
                break;
        }
        const s = new Suggestion();
        s.features = [];
        s.counterfactualExplanation = new CounterfactualExplanation();
        s.counterfactualExplanation.forecasting = [];
        s.counterfactualExplanation.counterfactuals = [];
        s.counterfactualExplanation.current = new PatientCard();
        s.counterfactualExplanation.current.age = 6 + this.getRandomInt(8);
        s.counterfactualExplanation.current.features = [];
        for (let j = 0; j < 10; j++) {
            const shap = new Shap(new CodedValue('', 'http://feature_' + j, 'feature_' + j), this.getRandomInt(100), this.getRandomInt(500));
            s.features.push(shap);
            const m = new ModelFeature(shap.key, shap.value);
            s.counterfactualExplanation.current.features.push(m);
        }
        s.uuid = self.crypto.randomUUID();
        s.label = this.loremInfos.generateWords(this.getRandomInt(5));
        s.summary = this.loremInfos.generateParagraphs(this.getRandomInt(4));
        s.qoe = HeartUICdssConverter.qoes[this.getRandomInt(2)];
        s.strength = HeartUICdssConverter.strengths[this.getRandomInt(2)];
        s.actions = [];
        s.uuid = this.getRandomInt(1000) + '';
        s.acceptancePerformer = new HealthCareProfessional(this.getRandomInt(120));
        s.acceptedOn = new Date();
        // crea un'Action che fa una redirect verso l'inserimento rischio
        const a = new Action(this.loremInfos.generateWords(this.getRandomInt(5)));
        const res = new Risk();
        res.date = new Date();
        res.predictions = [];
        for (let l = 0; l < 2; l++) {
            const p = new Risk.Prediction();
            p.maxAge = s.counterfactualExplanation.current.age + this.getRandomInt(40);
            p.minAge = p.maxAge;
            p.probability = Math.random();
            p.code = new CodedValue('thisSystem', 'thisCode', 'DISPLAY THIS');
            p.level = this.getRandomInt(100) > 50 ? RiskLevel.LOW : RiskLevel.MODERATE;
            res.predictions.push(p);
            const card = new PatientCard();
            card.age = p.minAge;
            card.risk = p.probability;
            card.level = p.level;
            card.risk_uncertainty = 0;
            card.features = this.getRandomFeatureSet();
            s.counterfactualExplanation.forecasting.push(card);
        }
        for (let l = 0; l < 2; l++) {
            const cf = new Counterfactual();
            cf.overall = new PatientCard();
            cf.overall.age = s.counterfactualExplanation.current.age;
            cf.overall.features = this.getRandomFeatureSet();
            const counts = s.counterfactualExplanation.forecasting.map((f) => {
                f.features = this.getRandomFeatureSet();
                return f;
            });
            cf.forecasting = counts;
            s.counterfactualExplanation.counterfactuals.push(cf);
        }
        a.resource = res;
        a.toPerform = ActionType.toCodedValue(ActionType.create);
        s.actions.push(a);
        s.confidence = Math.random();
        s.precision = Math.random();
        c.suggestions.push(s);
        return c;
    }
    getRandomFeatureSet(count = 10) {
        const features = [];
        for (let i = 0; i < count; i++) {
            const mf = new ModelFeature(new CodedValue('', 'http://feature_' + i, 'feature_' + i), this.getRandomInt(100));
            features.push(mf);
        }
        return features;
    }
}
HeartUiCdssService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartUiCdssService, deps: [{ token: CdssServiceConfig }, { token: BrokerService }, { token: CardsService }, { token: SuggestionsService }, { token: RegistryService }], target: i0.ɵɵFactoryTarget.Injectable });
HeartUiCdssService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartUiCdssService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: HeartUiCdssService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [CdssServiceConfig]
                }] }, { type: BrokerService }, { type: CardsService }, { type: SuggestionsService }, { type: RegistryService }]; } });

const en$5 = {};

const it$5 = {
    "cdss.card.manage-suggestion.button.label": "Vedi suggerimenti",
    "cdss.card.hide.button.tooltip": "Nascondi",
    "cdss.card.unhide.button.tooltip": "Scopri",
    "accepting": "Accettato parzialmente",
    "accepted": "Accettato",
    "read": "Letto",
    "overridden": "Rifiutato",
    "stale": "Scaduto",
    "hidden": "Nascosto",
    "cdss.card.override-reason.label": "Motivazione del rifiuto",
    "cdss.card.override-note.label": "Note aggiuntive",
};

class CdssCardComponent {
    constructor(_subTranslateService) {
        this._subTranslateService = _subTranslateService;
        this.showVisibilityButton = true; // shows the button to show/hide the card [the EYE]
        this.showDetailsButton = true; // shows the button to show the details [the Open Detail button]
        this.manageSuggestions = new EventEmitter(); // emits when the button "show details" is clicked
        this.hideCard = new EventEmitter(); // emits when the button "hide" is clicked
        this.wider = false;
        this.createDictionary();
    }
    // approccio per unificare il servizio di traduzione
    createDictionary() {
        const dictionary = new Map();
        dictionary.set('en', en$5);
        dictionary.set('it', it$5);
        this._subTranslateService.setLanguages(dictionary);
    }
    ngOnInit() { }
    openCard(card) {
        card.selected = true;
        this.manageSuggestions.emit(card);
    }
    toggleCardVisibility(card) {
        card.status == 'hidden' ? card.status = 'new' : card.status = 'hidden';
        this.hideCard.emit({ card: card, hidden: card.status == 'hidden' });
    }
}
CdssCardComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssCardComponent, deps: [{ token: i1$2.SubTranslateService }], target: i0.ɵɵFactoryTarget.Component });
CdssCardComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: CdssCardComponent, selector: "heart-cdss-card", inputs: { lang: "lang", card: "card", showVisibilityButton: "showVisibilityButton", showDetailsButton: "showDetailsButton", wider: "wider" }, outputs: { manageSuggestions: "manageSuggestions", hideCard: "hideCard" }, ngImport: i0, template: "<div class=\"card\" [ngClass]=\"{ 'selected':card.selected, 'new-card': card.unseen, 'wider' : wider, 'hidden' : card.status=='hidden'}\">\n  <div class=\"d-flex flex-column p-2\">\n    <!-- STATO -->\n    <div class=\"d-flex flex-row flex-gap-2 pl-1\"  *ngIf=\"card.status != 'new'\">\n      <container_element [ngSwitch]=\"card.status\" [className]=\"'status-' + card.status\">\n        <!-- <span>\n          <mat-icon *ngSwitchCase=\"'hidden'\">visibility_off</mat-icon>\n        </span> -->\n        <span>\n          <mat-icon *ngSwitchCase=\"'accepting'\">done</mat-icon>\n        </span>\n        <span>\n          <mat-icon *ngSwitchCase=\"'accepted'\">check_circle</mat-icon>\n        </span>\n        <span>\n          <mat-icon *ngSwitchCase=\"'read'\">beenhere</mat-icon> </span>\n        <span>\n          <mat-icon *ngSwitchCase=\"'overridden'\">cancel</mat-icon></span>\n        <span>\n          <mat-icon *ngSwitchCase=\"'stale'\">disabled_by_default</mat-icon></span>\n      </container_element>\n      <span [className]=\"'status-' + card.status\">{{card.status | subtranslate:lang}}</span>\n    </div>\n    <!-- TITOLO -->\n    <div class=\"d-flex flex-row flex-justify-between flex-content-center flex-items-center pl-2\">\n      <!-- <div *ngIf=\"card.unseen; else defaultTitle\" matBadge=\"N\" matBadgePosition=\"before\" matBadgeOverlap=\"false\" matBadgeColor=\"accent\" [ngClass]=\"{'ml-3': card.unseen}\"> -->\n      <span class=\"card-title\">{{card.label}}</span>\n      <!-- <div *ngIf=\"card.unseen; else defaultTitle\">\n        <span class=\"card-title\">{{card.label}}</span>\n      </div>\n      <ng-template #defaultTitle>\n        <span class=\"card-title\">{{card.label}}</span>\n      </ng-template> -->\n\n\n      <div *ngIf=\"showVisibilityButton && (card.status == 'new' || card.status == 'hidden') \">\n        <ng-container *ngIf=\"card.status != 'hidden'; else showCard \">\n          <button mat-icon-button (click)=\"toggleCardVisibility(card)\"\n            matTooltip=\"{{'cdss.card.hide.button.tooltip' | subtranslate:lang }}\" matTooltipPosition=\"left\">\n            <mat-icon>visibility_off</mat-icon>\n          </button>\n        </ng-container>\n        <ng-template #showCard>\n          <button mat-icon-button (click)=\"toggleCardVisibility(card)\"\n            matTooltip=\"{{'cdss.card.unhide.button.tooltip' | subtranslate:lang }}\" matTooltipPosition=\"left\">\n            <mat-icon>visibility</mat-icon>\n          </button>\n        </ng-template>\n      </div>\n\n    </div>\n\n    <!-- Specialty e livello -->\n    <div class=\"d-flex flex-row flex-justify-start flex-content-center flex-items-center pl-1 flex-gap-2\">\n      <span [className]=\"'chip-' + card.level?.code\">{{card.level?.display}}</span>\n\n      <span class=\"specialty\" *ngFor=\"let specialty of card.specialties; last as isLast\">\n        {{ ( 'card.' + (specialty.system ? specialty.system + '|' : '') + specialty.code + '.label' ) | translate }}\n        <span *ngIf=\"!isLast\">,</span>\n      </span>\n    </div>\n\n    <!-- separatore -->\n    <mat-divider class=\"mt-1 \"></mat-divider>\n    <!-- link -->\n    <div class=\" d-flex flex-row flex-justify-start flex-content-center flex-items-center pl-1 flex-gap-2\">\n      <a href=\"{{card.source?.url}}\" target=\"_blank\">{{card.source?.label}}</a>\n    </div>\n\n    <!-- pulsanti -->\n    <div class=\"d-flex flex-row flex-justify-end flex-content-center flex-items-center mt-1 mb-1 p-2 flex-gap-2\" *ngIf=\"showDetailsButton\">\n      <!-- <button mat-stroked-button>{{'suggestion.card.more-info.button.label' | translate}}</button> -->\n      <button mat-stroked-button color=\"accent\" (click)=\"openCard(card)\">{{'cdss.card.manage-suggestion.button.label' | subtranslate:lang}}</button>\n    </div>\n\n\n    <div class=\"d-flex flex-column mt-2 mb-1 p-2 flex-gap-2 details-box\" *ngIf=\"card.overrideReason\">\n      <div class=\"d-flex flex-column\">\n        <span class=\"reason-title\"> {{'cdss.card.override-reason.label' | subtranslate:lang}}</span>\n          <span class=\"reason\">{{ card.overrideReason.display | translate}}</span>\n      </div>\n      <div class=\"d-flex flex-column\" *ngIf=\"card.overrideNote\">\n        <span class=\"note-title\"> {{'cdss.card.override-note.label' | subtranslate:lang}}</span>\n          <span class=\"note\">{{ card.overrideNote}}</span>\n      </div>\n      <!-- <span class=\"practitioner\">\n        {{'suggestion.card.managed-by.label' | subtranslate:lang}}{{ card.refusedBy }} {{ card.refusedOn | date:'dd/MM/yyyy' }}\n      </span> -->\n    </div>\n\n  </div>\n</div>", styles: [".card{width:300px}.card-title{font-weight:600}.specialty{font-weight:100}a{font-size:smaller}.selected{background-color:var(--selected-color, rgb(255, 255, 244))}.chip,.chip-severe,.chip-warning,.chip-info{border-radius:25px;padding:4px 8px}.chip-info{background-color:var(--primary-color, lightcyan)}.chip-warning{background-color:var(--warning-color, lightpink);color:var(--light-text-color, #ccc)}.chip-severe{background-color:var(--critical-color, lightcoral);color:var(--light-text-color, #ccc)}.new-card-icon{border-radius:50%;width:36px;height:36px;padding:8px;background:#fff;border:2px solid #666;color:#666;text-align:center;font-size:32px}.new-card{box-shadow:0 3px 1px -2px rgba(var(--shadow-color, lightcoral),.4),0 2px 2px 0 rgba(var(--shadow-color, lightcoral),.2),0 1px 5px 0 rgba(var(--shadow-color, lightcoral),.2)}.status,.status-stale,.status-read,.status-overridden,.status-accepted,.status-accepting,.status-hidden,.status-new{font-weight:100}.status-new{color:#00368d}.status-hidden{color:gray}.status-accepting{color:#009600}.status-accepted{color:#008542}.status-overridden{color:brown}.status-read{color:#20b2aa}.status-stale{color:#b0c4de}.reason,.reason-title{color:brown}.reason-title{font-weight:700}.note,.note-title{font-weight:300}.note-title{font-weight:700}.details-box{background-color:#f5f5f5;border:var(--primary-color, lightcyan);border-radius:5px;border-width:thin;border-style:dotted}.practitioner{font-weight:100;font-size:small;font-style:italic}.wider{width:200%}.hidden{background-color:#dcdada3d}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "directive", type: i2.NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i4.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: i5.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "directive", type: i6.MatTooltip, selector: "[matTooltip]", exportAs: ["matTooltip"] }, { kind: "pipe", type: i1$2.SubTranslatePipe, name: "subtranslate" }, { kind: "pipe", type: i1$3.TranslatePipe, name: "translate" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-cdss-card', template: "<div class=\"card\" [ngClass]=\"{ 'selected':card.selected, 'new-card': card.unseen, 'wider' : wider, 'hidden' : card.status=='hidden'}\">\n  <div class=\"d-flex flex-column p-2\">\n    <!-- STATO -->\n    <div class=\"d-flex flex-row flex-gap-2 pl-1\"  *ngIf=\"card.status != 'new'\">\n      <container_element [ngSwitch]=\"card.status\" [className]=\"'status-' + card.status\">\n        <!-- <span>\n          <mat-icon *ngSwitchCase=\"'hidden'\">visibility_off</mat-icon>\n        </span> -->\n        <span>\n          <mat-icon *ngSwitchCase=\"'accepting'\">done</mat-icon>\n        </span>\n        <span>\n          <mat-icon *ngSwitchCase=\"'accepted'\">check_circle</mat-icon>\n        </span>\n        <span>\n          <mat-icon *ngSwitchCase=\"'read'\">beenhere</mat-icon> </span>\n        <span>\n          <mat-icon *ngSwitchCase=\"'overridden'\">cancel</mat-icon></span>\n        <span>\n          <mat-icon *ngSwitchCase=\"'stale'\">disabled_by_default</mat-icon></span>\n      </container_element>\n      <span [className]=\"'status-' + card.status\">{{card.status | subtranslate:lang}}</span>\n    </div>\n    <!-- TITOLO -->\n    <div class=\"d-flex flex-row flex-justify-between flex-content-center flex-items-center pl-2\">\n      <!-- <div *ngIf=\"card.unseen; else defaultTitle\" matBadge=\"N\" matBadgePosition=\"before\" matBadgeOverlap=\"false\" matBadgeColor=\"accent\" [ngClass]=\"{'ml-3': card.unseen}\"> -->\n      <span class=\"card-title\">{{card.label}}</span>\n      <!-- <div *ngIf=\"card.unseen; else defaultTitle\">\n        <span class=\"card-title\">{{card.label}}</span>\n      </div>\n      <ng-template #defaultTitle>\n        <span class=\"card-title\">{{card.label}}</span>\n      </ng-template> -->\n\n\n      <div *ngIf=\"showVisibilityButton && (card.status == 'new' || card.status == 'hidden') \">\n        <ng-container *ngIf=\"card.status != 'hidden'; else showCard \">\n          <button mat-icon-button (click)=\"toggleCardVisibility(card)\"\n            matTooltip=\"{{'cdss.card.hide.button.tooltip' | subtranslate:lang }}\" matTooltipPosition=\"left\">\n            <mat-icon>visibility_off</mat-icon>\n          </button>\n        </ng-container>\n        <ng-template #showCard>\n          <button mat-icon-button (click)=\"toggleCardVisibility(card)\"\n            matTooltip=\"{{'cdss.card.unhide.button.tooltip' | subtranslate:lang }}\" matTooltipPosition=\"left\">\n            <mat-icon>visibility</mat-icon>\n          </button>\n        </ng-template>\n      </div>\n\n    </div>\n\n    <!-- Specialty e livello -->\n    <div class=\"d-flex flex-row flex-justify-start flex-content-center flex-items-center pl-1 flex-gap-2\">\n      <span [className]=\"'chip-' + card.level?.code\">{{card.level?.display}}</span>\n\n      <span class=\"specialty\" *ngFor=\"let specialty of card.specialties; last as isLast\">\n        {{ ( 'card.' + (specialty.system ? specialty.system + '|' : '') + specialty.code + '.label' ) | translate }}\n        <span *ngIf=\"!isLast\">,</span>\n      </span>\n    </div>\n\n    <!-- separatore -->\n    <mat-divider class=\"mt-1 \"></mat-divider>\n    <!-- link -->\n    <div class=\" d-flex flex-row flex-justify-start flex-content-center flex-items-center pl-1 flex-gap-2\">\n      <a href=\"{{card.source?.url}}\" target=\"_blank\">{{card.source?.label}}</a>\n    </div>\n\n    <!-- pulsanti -->\n    <div class=\"d-flex flex-row flex-justify-end flex-content-center flex-items-center mt-1 mb-1 p-2 flex-gap-2\" *ngIf=\"showDetailsButton\">\n      <!-- <button mat-stroked-button>{{'suggestion.card.more-info.button.label' | translate}}</button> -->\n      <button mat-stroked-button color=\"accent\" (click)=\"openCard(card)\">{{'cdss.card.manage-suggestion.button.label' | subtranslate:lang}}</button>\n    </div>\n\n\n    <div class=\"d-flex flex-column mt-2 mb-1 p-2 flex-gap-2 details-box\" *ngIf=\"card.overrideReason\">\n      <div class=\"d-flex flex-column\">\n        <span class=\"reason-title\"> {{'cdss.card.override-reason.label' | subtranslate:lang}}</span>\n          <span class=\"reason\">{{ card.overrideReason.display | translate}}</span>\n      </div>\n      <div class=\"d-flex flex-column\" *ngIf=\"card.overrideNote\">\n        <span class=\"note-title\"> {{'cdss.card.override-note.label' | subtranslate:lang}}</span>\n          <span class=\"note\">{{ card.overrideNote}}</span>\n      </div>\n      <!-- <span class=\"practitioner\">\n        {{'suggestion.card.managed-by.label' | subtranslate:lang}}{{ card.refusedBy }} {{ card.refusedOn | date:'dd/MM/yyyy' }}\n      </span> -->\n    </div>\n\n  </div>\n</div>", styles: [".card{width:300px}.card-title{font-weight:600}.specialty{font-weight:100}a{font-size:smaller}.selected{background-color:var(--selected-color, rgb(255, 255, 244))}.chip,.chip-severe,.chip-warning,.chip-info{border-radius:25px;padding:4px 8px}.chip-info{background-color:var(--primary-color, lightcyan)}.chip-warning{background-color:var(--warning-color, lightpink);color:var(--light-text-color, #ccc)}.chip-severe{background-color:var(--critical-color, lightcoral);color:var(--light-text-color, #ccc)}.new-card-icon{border-radius:50%;width:36px;height:36px;padding:8px;background:#fff;border:2px solid #666;color:#666;text-align:center;font-size:32px}.new-card{box-shadow:0 3px 1px -2px rgba(var(--shadow-color, lightcoral),.4),0 2px 2px 0 rgba(var(--shadow-color, lightcoral),.2),0 1px 5px 0 rgba(var(--shadow-color, lightcoral),.2)}.status,.status-stale,.status-read,.status-overridden,.status-accepted,.status-accepting,.status-hidden,.status-new{font-weight:100}.status-new{color:#00368d}.status-hidden{color:gray}.status-accepting{color:#009600}.status-accepted{color:#008542}.status-overridden{color:brown}.status-read{color:#20b2aa}.status-stale{color:#b0c4de}.reason,.reason-title{color:brown}.reason-title{font-weight:700}.note,.note-title{font-weight:300}.note-title{font-weight:700}.details-box{background-color:#f5f5f5;border:var(--primary-color, lightcyan);border-radius:5px;border-width:thin;border-style:dotted}.practitioner{font-weight:100;font-size:small;font-style:italic}.wider{width:200%}.hidden{background-color:#dcdada3d}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$2.SubTranslateService }]; }, propDecorators: { lang: [{
                type: Input
            }], card: [{
                type: Input
            }], showVisibilityButton: [{
                type: Input
            }], showDetailsButton: [{
                type: Input
            }], manageSuggestions: [{
                type: Output
            }], hideCard: [{
                type: Output
            }], wider: [{
                type: Input
            }] } });

// AoT requires an exported function for factories
function HttpLoaderFactoryCdssCard(http) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class CdssCardModule {
}
CdssCardModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssCardModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
CdssCardModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: CdssCardModule, declarations: [CdssCardComponent], imports: [CommonModule,
        SubTranslateModule, i1$3.TranslateModule, MatIconModule,
        MatButtonModule,
        MatDividerModule,
        MatBadgeModule,
        MatTooltipModule], exports: [CdssCardComponent] });
CdssCardModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssCardModule, imports: [CommonModule,
        SubTranslateModule,
        TranslateModule.forChild({
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactoryCdssCard,
                deps: [HttpClient],
            },
            isolate: true,
        }),
        MatIconModule,
        MatButtonModule,
        MatDividerModule,
        MatBadgeModule,
        MatTooltipModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssCardModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        CdssCardComponent
                    ],
                    imports: [
                        CommonModule,
                        SubTranslateModule,
                        TranslateModule.forChild({
                            loader: {
                                provide: TranslateLoader,
                                useFactory: HttpLoaderFactoryCdssCard,
                                deps: [HttpClient],
                            },
                            isolate: true,
                        }),
                        MatIconModule,
                        MatButtonModule,
                        MatDividerModule,
                        MatBadgeModule,
                        MatTooltipModule
                    ],
                    exports: [CdssCardComponent]
                }]
        }] });

const en$4 = {
    "cdss.card.info.citation.title.label": "Citation",
    "cdss.card.info.citation.button.label": "Citation",
};

const it$4 = {
    "cdss.card.info.citation.title.label": "Citazione",
    "cdss.card.info.citation.button.label": "Citazione",
    "cdss.card.info.citation.close.button.label": "OK",
    "cdss.card.info.global.model.button.label": "Leggi dettagli sul modello di supporto decisionale",
    "cdss.card.show-less.label": "[Mostra meno]",
    "cdss.card.show-more.label": "[Mostra di più]",
};

class CdssCardInfoCitationDialogComponent {
    constructor(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
    }
}
CdssCardInfoCitationDialogComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssCardInfoCitationDialogComponent, deps: [{ token: i1$4.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
CdssCardInfoCitationDialogComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: CdssCardInfoCitationDialogComponent, selector: "heart-cdss-card-info-citation-dialog", ngImport: i0, template: "<h1 mat-dialog-title>{{ 'cdss.card.info.citation.title.label' | subtranslate:data.lang }}</h1>\n\n<div mat-dialog-content>\n  {{ data.citation }}\n</div>\n\n<div mat-dialog-actions class=\"d-flex flex-justify-end\">\n  <button mat-button mat-dialog-close color=\"primary\" cdkFocusInitial>{{ 'cdss.card.info.citation.close.button.label' | subtranslate:data.lang}}</button>\n</div>", styles: [""], dependencies: [{ kind: "component", type: i4.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "directive", type: i1$4.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$4.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$4.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "directive", type: i1$4.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "pipe", type: i1$2.SubTranslatePipe, name: "subtranslate" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssCardInfoCitationDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-cdss-card-info-citation-dialog', template: "<h1 mat-dialog-title>{{ 'cdss.card.info.citation.title.label' | subtranslate:data.lang }}</h1>\n\n<div mat-dialog-content>\n  {{ data.citation }}\n</div>\n\n<div mat-dialog-actions class=\"d-flex flex-justify-end\">\n  <button mat-button mat-dialog-close color=\"primary\" cdkFocusInitial>{{ 'cdss.card.info.citation.close.button.label' | subtranslate:data.lang}}</button>\n</div>" }]
        }], ctorParameters: function () { return [{ type: i1$4.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }]; } });

class CdssCardInfoComponent {
    constructor(_subTranslateService, _dialogService) {
        this._subTranslateService = _subTranslateService;
        this._dialogService = _dialogService;
        this.openMlDetails = new EventEmitter(); // emits when the button "show global details" is clicked
        this.DIALOG_WIDTH = '800px';
        this.showMore = true;
        this.chars = 120;
        this.createDictionary();
    }
    // approccio per unificare il servizio di traduzione
    createDictionary() {
        const dictionary = new Map();
        dictionary.set('en', en$4);
        dictionary.set('it', it$4);
        this._subTranslateService.setLanguages(dictionary);
    }
    showCitationDetails() {
        // open the dialog only while disabling the credentials
        this._dialogService
            .open(CdssCardInfoCitationDialogComponent, {
            width: this.DIALOG_WIDTH,
            data: {
                lang: this.lang,
                citation: this.card.source.citation
            },
        });
    }
    openMlGlobalDetails() {
        this.openMlDetails.emit();
    }
}
CdssCardInfoComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssCardInfoComponent, deps: [{ token: i1$2.SubTranslateService }, { token: i1$4.MatDialog }], target: i0.ɵɵFactoryTarget.Component });
CdssCardInfoComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: CdssCardInfoComponent, selector: "heart-cdss-card-info", inputs: { lang: "lang", card: "card", chars: "chars" }, outputs: { openMlDetails: "openMlDetails" }, ngImport: i0, template: "<div class=\"clearfix card p-2 m-2\">\n\n  <div class=\"col-12\">\n    <h1>\n      {{card.label}}\n    </h1>\n\n    <!-- Specialty e livello -->\n    <div class=\"d-flex flex-row flex-justify-start flex-content-center flex-items-center pl-1 flex-gap-2\">\n      <!-- Badge: info | warn | error -->\n      <span [className]=\"'chip-' + card.level?.code\">{{card.level?.display}}</span>\n      \n      <span class=\"specialty\" *ngFor=\"let specialty of card.specialties; last as isLast\">\n        {{ ( 'card.' + (specialty.system ? specialty.system + '|' : '') + specialty.code + '.label' ) | translate }}\n        <span *ngIf=\"!isLast\">,</span>\n      </span>\n    </div>\n  </div>\n\n  <mat-divider class=\"mt-1\"></mat-divider>\n\n  <!-- pulsanti -->\n  <div *ngIf=\"card.source?.citation\" class=\"float-right mt-1 mb-1 p-2\">\n    <button mat-stroked-button color=\"accent\" (click)=\"showCitationDetails()\">{{'cdss.card.info.citation.button.label' | subtranslate:lang}}</button>\n  </div>\n\n  <!-- Source (link) -->\n  <div class=\"pl-1 py-2\">\n    <a href=\"{{card.source?.url}}\" target=\"_blank\">{{card.source?.label}}</a>\n  </div>\n\n  <!-- Summary: Long Description as markdown -->\n  <div class=\"col-12 float-left markdown-offset-fix markdown-body\">\n    <div *ngIf=\"card.summary; else modelDesc\" >\n      <div *ngIf=\"showMore; else showAll\" [innerHTML]=\"(card.summary | slice: 0:chars) + '...' | markdown\">...\n      </div>\n      <ng-template #showAll>\n        <div [innerHTML]=\"card.summary | markdown\">\n        </div>\n      </ng-template>\n      <a class=\"primary\" (click)=\"showMore=!showMore\">{{showMore ? ('cdss.card.show-more.label' | subtranslate:lang) : ('cdss.card.show-less.label' | subtranslate:lang) }}</a>\n    </div>\n    <ng-template #modelDesc>\n      <div *ngIf=\"card.model?.explanation?.description\" class=\"col-12 float-left\">\n        <span>{{!showMore ? card.model.explanation.description : (card.model.explanation.description | slice: 0:chars) }}</span><span *ngIf=\"!showMore\">...</span>\n        <a class=\"primary\" (click)=\"showMore= !showMore\">{{showMore ? ('cdss.card.show-more.label' | subtranslate:lang) : ('cdss.card.show-less.label' | subtranslate:lang) }}</a>\n      </div>\n    </ng-template>\n\n  </div>\n\n  <div *ngIf=\"card.model != undefined\" class=\"col-12 float-left mt-2\">\n    <a class=\"accent\" (click)=\"openMlGlobalDetails()\">{{'cdss.card.info.global.model.button.label' | subtranslate:lang}}</a>\n  </div>\n</div>", styles: [".markdown-offset-fix{margin-left:1em!important;padding-right:1em!important}.specialty{font-weight:100}a{font-size:smaller;cursor:pointer}a.accent{color:var(--accent-color, lightcoral);font-style:italic;cursor:pointer;font-weight:300}a.primary{color:var(--primary-color, lightcyan)}.markdown-body{font-family:unset!important}.chip,.chip-severe,.chip-warning,.chip-info{border-radius:25px;padding:4px 8px}.chip-info{background-color:var(--primary-color, lightcyan)}.chip-warning{background-color:var(--warning-color, lightpink);color:var(--light-text-color, #ccc)}.chip-severe{background-color:var(--critical-color, lightcoral);color:var(--light-text-color, #ccc)}\n"], dependencies: [{ kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i4.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: i5.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "pipe", type: i2.SlicePipe, name: "slice" }, { kind: "pipe", type: i1$2.SubTranslatePipe, name: "subtranslate" }, { kind: "pipe", type: i1$3.TranslatePipe, name: "translate" }, { kind: "pipe", type: i1$1.MarkdownPipe, name: "markdown" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssCardInfoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-cdss-card-info', template: "<div class=\"clearfix card p-2 m-2\">\n\n  <div class=\"col-12\">\n    <h1>\n      {{card.label}}\n    </h1>\n\n    <!-- Specialty e livello -->\n    <div class=\"d-flex flex-row flex-justify-start flex-content-center flex-items-center pl-1 flex-gap-2\">\n      <!-- Badge: info | warn | error -->\n      <span [className]=\"'chip-' + card.level?.code\">{{card.level?.display}}</span>\n      \n      <span class=\"specialty\" *ngFor=\"let specialty of card.specialties; last as isLast\">\n        {{ ( 'card.' + (specialty.system ? specialty.system + '|' : '') + specialty.code + '.label' ) | translate }}\n        <span *ngIf=\"!isLast\">,</span>\n      </span>\n    </div>\n  </div>\n\n  <mat-divider class=\"mt-1\"></mat-divider>\n\n  <!-- pulsanti -->\n  <div *ngIf=\"card.source?.citation\" class=\"float-right mt-1 mb-1 p-2\">\n    <button mat-stroked-button color=\"accent\" (click)=\"showCitationDetails()\">{{'cdss.card.info.citation.button.label' | subtranslate:lang}}</button>\n  </div>\n\n  <!-- Source (link) -->\n  <div class=\"pl-1 py-2\">\n    <a href=\"{{card.source?.url}}\" target=\"_blank\">{{card.source?.label}}</a>\n  </div>\n\n  <!-- Summary: Long Description as markdown -->\n  <div class=\"col-12 float-left markdown-offset-fix markdown-body\">\n    <div *ngIf=\"card.summary; else modelDesc\" >\n      <div *ngIf=\"showMore; else showAll\" [innerHTML]=\"(card.summary | slice: 0:chars) + '...' | markdown\">...\n      </div>\n      <ng-template #showAll>\n        <div [innerHTML]=\"card.summary | markdown\">\n        </div>\n      </ng-template>\n      <a class=\"primary\" (click)=\"showMore=!showMore\">{{showMore ? ('cdss.card.show-more.label' | subtranslate:lang) : ('cdss.card.show-less.label' | subtranslate:lang) }}</a>\n    </div>\n    <ng-template #modelDesc>\n      <div *ngIf=\"card.model?.explanation?.description\" class=\"col-12 float-left\">\n        <span>{{!showMore ? card.model.explanation.description : (card.model.explanation.description | slice: 0:chars) }}</span><span *ngIf=\"!showMore\">...</span>\n        <a class=\"primary\" (click)=\"showMore= !showMore\">{{showMore ? ('cdss.card.show-more.label' | subtranslate:lang) : ('cdss.card.show-less.label' | subtranslate:lang) }}</a>\n      </div>\n    </ng-template>\n\n  </div>\n\n  <div *ngIf=\"card.model != undefined\" class=\"col-12 float-left mt-2\">\n    <a class=\"accent\" (click)=\"openMlGlobalDetails()\">{{'cdss.card.info.global.model.button.label' | subtranslate:lang}}</a>\n  </div>\n</div>", styles: [".markdown-offset-fix{margin-left:1em!important;padding-right:1em!important}.specialty{font-weight:100}a{font-size:smaller;cursor:pointer}a.accent{color:var(--accent-color, lightcoral);font-style:italic;cursor:pointer;font-weight:300}a.primary{color:var(--primary-color, lightcyan)}.markdown-body{font-family:unset!important}.chip,.chip-severe,.chip-warning,.chip-info{border-radius:25px;padding:4px 8px}.chip-info{background-color:var(--primary-color, lightcyan)}.chip-warning{background-color:var(--warning-color, lightpink);color:var(--light-text-color, #ccc)}.chip-severe{background-color:var(--critical-color, lightcoral);color:var(--light-text-color, #ccc)}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$2.SubTranslateService }, { type: i1$4.MatDialog }]; }, propDecorators: { lang: [{
                type: Input
            }], card: [{
                type: Input
            }], openMlDetails: [{
                type: Output
            }], chars: [{
                type: Input
            }] } });

// AoT requires an exported function for factories
function HttpLoaderFactoryCdssCardInfo(http) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class CdssCardInfoModule {
}
CdssCardInfoModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssCardInfoModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
CdssCardInfoModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: CdssCardInfoModule, declarations: [CdssCardInfoComponent,
        CdssCardInfoCitationDialogComponent], imports: [CommonModule,
        SubTranslateModule, i1$3.TranslateModule, MatIconModule,
        MatButtonModule,
        MatDividerModule,
        MatExpansionModule,
        MatDialogModule, i1$1.MarkdownModule], exports: [CdssCardInfoComponent] });
CdssCardInfoModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssCardInfoModule, imports: [CommonModule,
        SubTranslateModule,
        TranslateModule.forChild({
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactoryCdssCardInfo,
                deps: [HttpClient],
            },
            isolate: true,
        }),
        MatIconModule,
        MatButtonModule,
        MatDividerModule,
        MatExpansionModule,
        MatDialogModule,
        MarkdownModule.forChild()] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssCardInfoModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        CdssCardInfoComponent,
                        CdssCardInfoCitationDialogComponent,
                    ],
                    imports: [
                        CommonModule,
                        SubTranslateModule,
                        TranslateModule.forChild({
                            loader: {
                                provide: TranslateLoader,
                                useFactory: HttpLoaderFactoryCdssCardInfo,
                                deps: [HttpClient],
                            },
                            isolate: true,
                        }),
                        MatIconModule,
                        MatButtonModule,
                        MatDividerModule,
                        MatExpansionModule,
                        MatDialogModule,
                        MarkdownModule.forChild(),
                    ],
                    exports: [CdssCardInfoComponent]
                }]
        }] });

const en$3 = {};

const it$3 = {
    "cdss.expandible-card.actions-count.label": " Azioni",
    "cdss.expandible-card.action-count.label": " Azione"
};

class CdssExpandibleCardComponent {
    constructor(_subTranslateService) {
        this._subTranslateService = _subTranslateService;
        this.createDictionary();
    }
    // approccio per unificare il servizio di traduzione
    createDictionary() {
        const dictionary = new Map();
        dictionary.set('en', en$3);
        dictionary.set('it', it$3);
        this._subTranslateService.setLanguages(dictionary);
    }
}
CdssExpandibleCardComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssExpandibleCardComponent, deps: [{ token: i1$2.SubTranslateService }], target: i0.ɵɵFactoryTarget.Component });
CdssExpandibleCardComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: CdssExpandibleCardComponent, selector: "heart-cdss-expandible-card", inputs: { lang: "lang", card: "card" }, ngImport: i0, template: "<div class=\"card\" [ngClass]=\"{ 'selected':card.selected }\">\n  <div class=\"d-flex flex-column \">\n    <!-- TITOLO -->\n    <div class=\"d-flex flex-row flex-justify-between flex-content-center flex-items-center pl-2\">\n      <span class=\"card-title\">{{card.label}}</span>\n    </div>\n\n    <!-- Specialty e livello -->\n    <div class=\"d-flex flex-row flex-justify-start flex-content-center flex-items-center pl-1 flex-gap-2\">\n      <span [className]=\"'chip-' + card.level?.code\">{{card.level?.display}}</span>\n      \n      <span class=\"specialty\" *ngFor=\"let specialty of card.specialties; last as isLast\">\n        {{ ( 'card.' + (specialty.system ? specialty.system + '|' : '') + specialty.code + '.label' ) | translate }}\n        <span *ngIf=\"!isLast\">,</span>\n      </span>\n    </div>\n\n    <!-- separatore -->\n    <mat-divider class=\"mt-1 \"></mat-divider>\n    <!-- link -->\n    <div class=\" d-flex flex-column flex-justify-start flex-content-center flex-items-center pl-1 flex-gap-2\">\n      <a href=\"{{card.source?.url}}\" target=\"_blank\">{{card.source?.label}}</a>\n\n      <!-- extra details available -->\n      <!-- <span *ngIf=\"card.source?.citation\">{{card.source?.citation}}</span>\n      <span *ngIf=\"card.source?.topic\">{{card.source?.topic}}</span> -->\n    </div>\n\n    <!-- suggerimenti -->\n    <!-- <ng-container *ngFor=\"let suggestion of card.suggestions\">\n      <span class=\"suggestion-title\">{{suggestion.label}}</span>\n      <ng-container *ngFor=\"let action of suggestion.actions\">\n        <span>{{action.label}}</span>\n      </ng-container>\n    </ng-container> -->\n    <mat-accordion>\n      <ng-container *ngFor=\"let suggestion of card.suggestions\">\n        <span class=\"suggestion-title\">{{suggestion.label}}</span>\n\n        <div *ngIf=\"suggestion && suggestion.actions && suggestion.actions.length > 0\">\n          <mat-expansion-panel>\n            <mat-expansion-panel-header>\n              <mat-panel-title *ngIf=\"suggestion && suggestion.actions\">\n                <span *ngIf=\"suggestion.actions!.length > 1; else single\">\n                  {{suggestion?.actions?.length}} {{ 'cdss.expandible-card.actions-count.label' | subtranslate:lang}}\n                </span>\n                <ng-template #single>\n                  {{suggestion?.actions?.length}} {{ 'cdss.expandible-card.action-count.label' | subtranslate:lang}}\n                </ng-template>\n              </mat-panel-title>\n            </mat-expansion-panel-header>\n            <ul>\n              <ng-container *ngFor=\" let action of suggestion.actions\" class=\"d-flex flex-column \">\n                <!-- <div>\n                  <span>{{action.label}}</span>\n                </div> -->\n                <li>\n                  <span>{{action.label}}</span>\n                </li>\n              </ng-container>\n            </ul>\n          </mat-expansion-panel>\n        </div>\n\n      </ng-container>\n    </mat-accordion>\n\n  </div>\n</div>", styles: [".card{width:300px}.card-title{font-weight:600}.specialty{font-weight:100}a{font-size:smaller}.suggestion-title{font-weight:600;font-size:medium}.action{font-weight:500;font-size:medium}.inner-title{font-weight:100;font-size:small}.important-value{font-weight:600}.selected{background-color:var(--selected-color, rgb(255, 255, 244))}.chip,.chip-severe,.chip-warning,.chip-info{border-radius:25px;padding:4px 8px}.chip-info{background-color:var(--primary-color, lightcyan);color:lig}.chip-warning{background-color:var(--warning-color, lightpink);color:var(--light-text-color, #ccc)}.chip-severe{background-color:var(--critical-color, lightcoral);color:var(--light-text-color, #ccc)}mat-accordion{padding:8px}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i5.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "directive", type: i4$1.MatAccordion, selector: "mat-accordion", inputs: ["multi", "hideToggle", "displayMode", "togglePosition"], exportAs: ["matAccordion"] }, { kind: "component", type: i4$1.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["disabled", "expanded", "hideToggle", "togglePosition"], outputs: ["opened", "closed", "expandedChange", "afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }, { kind: "component", type: i4$1.MatExpansionPanelHeader, selector: "mat-expansion-panel-header", inputs: ["tabIndex", "expandedHeight", "collapsedHeight"] }, { kind: "directive", type: i4$1.MatExpansionPanelTitle, selector: "mat-panel-title" }, { kind: "pipe", type: i1$2.SubTranslatePipe, name: "subtranslate" }, { kind: "pipe", type: i1$3.TranslatePipe, name: "translate" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssExpandibleCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-cdss-expandible-card', template: "<div class=\"card\" [ngClass]=\"{ 'selected':card.selected }\">\n  <div class=\"d-flex flex-column \">\n    <!-- TITOLO -->\n    <div class=\"d-flex flex-row flex-justify-between flex-content-center flex-items-center pl-2\">\n      <span class=\"card-title\">{{card.label}}</span>\n    </div>\n\n    <!-- Specialty e livello -->\n    <div class=\"d-flex flex-row flex-justify-start flex-content-center flex-items-center pl-1 flex-gap-2\">\n      <span [className]=\"'chip-' + card.level?.code\">{{card.level?.display}}</span>\n      \n      <span class=\"specialty\" *ngFor=\"let specialty of card.specialties; last as isLast\">\n        {{ ( 'card.' + (specialty.system ? specialty.system + '|' : '') + specialty.code + '.label' ) | translate }}\n        <span *ngIf=\"!isLast\">,</span>\n      </span>\n    </div>\n\n    <!-- separatore -->\n    <mat-divider class=\"mt-1 \"></mat-divider>\n    <!-- link -->\n    <div class=\" d-flex flex-column flex-justify-start flex-content-center flex-items-center pl-1 flex-gap-2\">\n      <a href=\"{{card.source?.url}}\" target=\"_blank\">{{card.source?.label}}</a>\n\n      <!-- extra details available -->\n      <!-- <span *ngIf=\"card.source?.citation\">{{card.source?.citation}}</span>\n      <span *ngIf=\"card.source?.topic\">{{card.source?.topic}}</span> -->\n    </div>\n\n    <!-- suggerimenti -->\n    <!-- <ng-container *ngFor=\"let suggestion of card.suggestions\">\n      <span class=\"suggestion-title\">{{suggestion.label}}</span>\n      <ng-container *ngFor=\"let action of suggestion.actions\">\n        <span>{{action.label}}</span>\n      </ng-container>\n    </ng-container> -->\n    <mat-accordion>\n      <ng-container *ngFor=\"let suggestion of card.suggestions\">\n        <span class=\"suggestion-title\">{{suggestion.label}}</span>\n\n        <div *ngIf=\"suggestion && suggestion.actions && suggestion.actions.length > 0\">\n          <mat-expansion-panel>\n            <mat-expansion-panel-header>\n              <mat-panel-title *ngIf=\"suggestion && suggestion.actions\">\n                <span *ngIf=\"suggestion.actions!.length > 1; else single\">\n                  {{suggestion?.actions?.length}} {{ 'cdss.expandible-card.actions-count.label' | subtranslate:lang}}\n                </span>\n                <ng-template #single>\n                  {{suggestion?.actions?.length}} {{ 'cdss.expandible-card.action-count.label' | subtranslate:lang}}\n                </ng-template>\n              </mat-panel-title>\n            </mat-expansion-panel-header>\n            <ul>\n              <ng-container *ngFor=\" let action of suggestion.actions\" class=\"d-flex flex-column \">\n                <!-- <div>\n                  <span>{{action.label}}</span>\n                </div> -->\n                <li>\n                  <span>{{action.label}}</span>\n                </li>\n              </ng-container>\n            </ul>\n          </mat-expansion-panel>\n        </div>\n\n      </ng-container>\n    </mat-accordion>\n\n  </div>\n</div>", styles: [".card{width:300px}.card-title{font-weight:600}.specialty{font-weight:100}a{font-size:smaller}.suggestion-title{font-weight:600;font-size:medium}.action{font-weight:500;font-size:medium}.inner-title{font-weight:100;font-size:small}.important-value{font-weight:600}.selected{background-color:var(--selected-color, rgb(255, 255, 244))}.chip,.chip-severe,.chip-warning,.chip-info{border-radius:25px;padding:4px 8px}.chip-info{background-color:var(--primary-color, lightcyan);color:lig}.chip-warning{background-color:var(--warning-color, lightpink);color:var(--light-text-color, #ccc)}.chip-severe{background-color:var(--critical-color, lightcoral);color:var(--light-text-color, #ccc)}mat-accordion{padding:8px}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$2.SubTranslateService }]; }, propDecorators: { lang: [{
                type: Input
            }], card: [{
                type: Input
            }] } });

// AoT requires an exported function for factories
function HttpLoaderFactoryCdssExpCard(http) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class CdssExpandibleCardModule {
}
CdssExpandibleCardModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssExpandibleCardModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
CdssExpandibleCardModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: CdssExpandibleCardModule, declarations: [CdssExpandibleCardComponent], imports: [CommonModule,
        SubTranslateModule, i1$3.TranslateModule, MatIconModule,
        MatButtonModule,
        MatDividerModule,
        MatExpansionModule,
        MatBadgeModule], exports: [CdssExpandibleCardComponent] });
CdssExpandibleCardModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssExpandibleCardModule, imports: [CommonModule,
        SubTranslateModule,
        TranslateModule.forChild({
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactoryCdssExpCard,
                deps: [HttpClient],
            },
            isolate: true,
        }),
        MatIconModule,
        MatButtonModule,
        MatDividerModule,
        MatExpansionModule,
        MatBadgeModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssExpandibleCardModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        CdssExpandibleCardComponent
                    ],
                    imports: [
                        CommonModule,
                        SubTranslateModule,
                        TranslateModule.forChild({
                            loader: {
                                provide: TranslateLoader,
                                useFactory: HttpLoaderFactoryCdssExpCard,
                                deps: [HttpClient],
                            },
                            isolate: true,
                        }),
                        MatIconModule,
                        MatButtonModule,
                        MatDividerModule,
                        MatExpansionModule,
                        MatBadgeModule
                    ],
                    exports: [CdssExpandibleCardComponent]
                }]
        }] });

const en$2 = {
    "cdss.info.strength.label": "Strength: ",
    "cdss.info.qoe.label": "Quality: ",
    "suggestion.card.action.label": "Actions"
};

const it$2 = {
    "cdss.info.strength.label": "Forza: ",
    "cdss.info.qoe.label": "Qualità: ",
    "suggestion.card.action.label": "Azioni",
    "cdss.no-action.label": "Nessuna azione esplicita per questo suggerimento",
    "suggestion.card.managed-by.label": "Gestito da: ",
    "suggestion.card.managed-at.label": "Il: ",
    "cdss.info.confidence.label": "Confidenza: ",
    "cdss.info.precision.label": "Precisione: ",
    "cdss.suggestion-info.more-details.label": "Perchè ho ricevuto questo suggerimento?",
};

class CdssSuggestionInfoComponent {
    constructor(_subTranslateService) {
        this._subTranslateService = _subTranslateService;
        this.accepted = new EventEmitter();
        this.explanation = new EventEmitter();
        this.readonly = false;
        this.showPrecision = false; // if the card has not the highest value of confidence, this should be false. In this case we can also hide the "Explanation of the suggestion"
        this.displayDetails = false; // Actions visible by default only for the most precise suggestion
        this.createDictionary();
    }
    // approccio per unificare il servizio di traduzione
    createDictionary() {
        const dictionary = new Map();
        dictionary.set('en', en$2);
        dictionary.set('it', it$2);
        this._subTranslateService.setLanguages(dictionary);
    }
    ngOnInit() {
        this.displayDetails = this.showPrecision; // Actions visible by default only for the most precise suggestion
    }
    // protected manageChange(event: MatSlideToggleChange) {
    //   this.suggestion.accepted = event.checked;
    //   if (event.checked) {
    //     this.accepted.emit(this.suggestion);
    //   } else {
    //     this.refused.emit(this.suggestion);
    //   }
    // }
    acceptSuggestion(event) {
        this.accepted.emit(this.suggestion);
    }
    showExplanation(s) {
        this.explanation.emit(this.suggestion);
    }
}
CdssSuggestionInfoComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssSuggestionInfoComponent, deps: [{ token: i1$2.SubTranslateService }], target: i0.ɵɵFactoryTarget.Component });
CdssSuggestionInfoComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: CdssSuggestionInfoComponent, selector: "heart-cdss-suggestion-info", inputs: { lang: "lang", suggestion: "suggestion", readonly: "readonly", showPrecision: "showPrecision" }, outputs: { accepted: "accepted", explanation: "explanation" }, ngImport: i0, template: "<div class=\"card m-2 d-flex flex-column\">\n  <!-- label del suggerimento -->\n  <div class=\"d-flex flex-row flex-justify-between flex-content-center flex-items-center pl-2\">\n    <div class=\"d-flex flex-column\">\n    <span class=\"suggestion-title pt-2\">{{suggestion.label}}</span>\n    <div class=\"py-1\" *ngIf=\"showPrecision && suggestion.confidence != undefined || suggestion.guideLineExplanation != undefined || suggestion.treeExplanation != undefined\">\n      <a (click)=\"showExplanation(suggestion)\">{{'cdss.suggestion-info.more-details.label' | subtranslate:lang}}</a>\n    </div>\n  </div>\n    <button mat-icon-button (click)=\"displayDetails = !displayDetails\">\n      <mat-icon *ngIf=\"!displayDetails; else up\">expand_more</mat-icon>\n      <ng-template #up>\n        <mat-icon>expand_less</mat-icon>\n      </ng-template>\n    </button>\n  </div>\n\n    <!-- Render the \"confidence\" info -->\n    <div class=\"d-flex flex-row flex-gap-1 flex-content-center flex-items-center pl-2\"\n    *ngIf=\"suggestion.confidence != undefined\">\n    <span class=\"important-value\">\n      {{ 'cdss.info.confidence.label' | subtranslate:lang}}\n    </span>\n    <span class=\"important-value d-flex flex-row flex-gap-1 flex-content-center flex-items-center\">\n      {{suggestion.confidence | percent}}\n    </span>\n  </div>\n      <!-- Render the \"precision\" info -->\n      <!-- && suggestion.confidence != undefined -->\n      <div class=\"d-flex flex-row flex-gap-1 flex-content-center flex-items-center pl-2\"\n      *ngIf=\"showPrecision && suggestion.precision != undefined && suggestion.precision > 0\">\n      <span class=\"inner-title\">\n        {{ 'cdss.info.precision.label' | subtranslate:lang}}\n      </span>\n      <span class=\"inner-title d-flex flex-row flex-gap-1 flex-content-center flex-items-center\">\n        {{suggestion.precision | percent}}\n      </span>\n      </div>\n\n  <mat-divider></mat-divider>\n\n  <div *ngIf=\"displayDetails\">\n    <!-- azioni -->\n    <!-- <div *ngFor=\"let a of suggestion?.actions\" class=\"action-list d-flex flex-column pl-2\">\n      <span class=\"action\">\n        {{a}}\n      </span>\n    </div> -->\n    <mat-list *ngIf=\"suggestion?.actions?.length > 0 ; else noActions\" role=\"list\" class=\"action-list\">\n      <ng-container *ngFor=\"let a of suggestion?.actions\">\n        <mat-list-item role=\"listitem\" class=\"action\" >\n          <span matTooltip=\"{{a.label}}\" matTooltipPosition=\"above\" matTooltipShowDelay=\"250\">{{a.label}}</span></mat-list-item>\n      </ng-container>\n    </mat-list>\n    <ng-template #noActions>\n      <mat-list-item role=\"listitem\" class=\"no-action\"> {{ 'cdss.no-action.label' | subtranslate:lang}}</mat-list-item>\n    </ng-template>\n\n    <mat-divider></mat-divider>\n    <!-- Render the \"quality of evidence\" info -->\n    <div class=\"d-flex flex-row flex-gap-1 flex-content-center flex-items-center pl-2\"\n      *ngIf=\"suggestion.qoe != undefined\">\n      <span class=\"inner-title\">\n        {{ 'cdss.info.qoe.label' | subtranslate:lang}}\n      </span>\n      <span class=\"important-value\">\n        {{suggestion.qoe?.display}}\n      </span>\n    </div>\n  </div>\n\n  <!-- Render the \"strength\" info -->\n  <div class=\"d-flex flex-row flex-gap-1 flex-content-center flex-items-center pl-2\"\n    *ngIf=\"suggestion.strength != undefined\">\n    <span class=\"inner-title\">\n      {{ 'cdss.info.strength.label' | subtranslate:lang}}\n    </span>\n    <span class=\"important-value d-flex flex-row flex-gap-1 flex-content-center flex-items-center\">\n      <mat-icon *ngIf=\"suggestion.strength.code == 'weak'\">gpp_bad</mat-icon>\n      <mat-icon *ngIf=\"suggestion.strength.code == 'strong'\">verified_user</mat-icon>\n      {{suggestion.strength?.display}}\n    </span>\n  </div>\n\n  <!-- Render the \"practitioner\" info -->\n  <div *ngIf=\"suggestion.acceptancePerformer?.id != undefined\"\n    class=\"d-flex flex-row-reverse flex-content-center flex-items-center flex-gap-2 pr-3\">\n    <span class=\"practitioner\">\n      {{'suggestion.card.managed-by.label' | subtranslate:lang}}{{ suggestion.acceptancePerformer?.id }}\n    </span>\n  </div>\n\n  <!-- Render the \"date\" info -->\n  <div *ngIf=\"suggestion.acceptedOn != undefined\"\n    class=\"d-flex flex-row-reverse flex-content-center flex-items-center flex-gap-2 pr-3\">\n    <span class=\"practitioner\">\n      {{'suggestion.card.managed-at.label' | subtranslate:lang}}{{ suggestion.acceptedOn | date:'dd/MM/yyyy' }}\n    </span>\n  </div>\n\n  <!-- pulsanti -->\n  <div class=\"d-flex flex-row-reverse flex-justify-between flex-content-center flex-items-center mt-1 mb-1 p-2 flex-gap-2\">\n    <!-- [ngClass]=\"{'flex-row-reverse': suggestion && suggestion.actions && suggestion.actions.length == 0}\" -->\n    <!-- <mat-slide-toggle *ngIf=\"!readonly\" (change)=\"manageChange($event)\">{{'suggestion.card.accept.button.label' | translate}}</mat-slide-toggle> -->\n    <button mat-stroked-button color=\"primary\" *ngIf=\"!readonly && !suggestion.accepted\"\n    (click)=\"acceptSuggestion($event)\">{{'suggestion.card.accept.button.label' | translate}}</button>\n    <div *ngIf=\"suggestion && suggestion.actions && suggestion!.actions!.length > 0 && !displayDetails\">\n      <span class=\"action-count\">\n        {{'suggestion.card.action.label' | subtranslate:lang}}: {{suggestion!.actions!.length}}\n      </span>\n    </div>\n  </div>\n</div>", styles: [".suggestion-title{font-weight:600;font-size:large}.card{border-radius:5px}.action{font-weight:500;font-size:medium}.inner-title{font-weight:100;font-size:small}.important-value{font-weight:600}.action-list{background-color:var(--action-list-color, lightyellow)}.action-count{color:var(--accent-color, lightcoral);font-size:small;font-style:italic}.no-action{font-weight:100;font-style:italic;margin:8px}.practitioner{font-weight:100;font-size:small;font-style:italic}mat-list-item{height:32px!important}a{font-style:italic;cursor:pointer;font-weight:300;color:var(--accent-color, lightcoral)}\n"], dependencies: [{ kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i4.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: i5.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "component", type: i6$1.MatList, selector: "mat-list", exportAs: ["matList"] }, { kind: "component", type: i6$1.MatListItem, selector: "mat-list-item, a[mat-list-item], button[mat-list-item]", inputs: ["activated"], exportAs: ["matListItem"] }, { kind: "directive", type: i6.MatTooltip, selector: "[matTooltip]", exportAs: ["matTooltip"] }, { kind: "pipe", type: i2.PercentPipe, name: "percent" }, { kind: "pipe", type: i2.DatePipe, name: "date" }, { kind: "pipe", type: i1$2.SubTranslatePipe, name: "subtranslate" }, { kind: "pipe", type: i1$3.TranslatePipe, name: "translate" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssSuggestionInfoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-cdss-suggestion-info', template: "<div class=\"card m-2 d-flex flex-column\">\n  <!-- label del suggerimento -->\n  <div class=\"d-flex flex-row flex-justify-between flex-content-center flex-items-center pl-2\">\n    <div class=\"d-flex flex-column\">\n    <span class=\"suggestion-title pt-2\">{{suggestion.label}}</span>\n    <div class=\"py-1\" *ngIf=\"showPrecision && suggestion.confidence != undefined || suggestion.guideLineExplanation != undefined || suggestion.treeExplanation != undefined\">\n      <a (click)=\"showExplanation(suggestion)\">{{'cdss.suggestion-info.more-details.label' | subtranslate:lang}}</a>\n    </div>\n  </div>\n    <button mat-icon-button (click)=\"displayDetails = !displayDetails\">\n      <mat-icon *ngIf=\"!displayDetails; else up\">expand_more</mat-icon>\n      <ng-template #up>\n        <mat-icon>expand_less</mat-icon>\n      </ng-template>\n    </button>\n  </div>\n\n    <!-- Render the \"confidence\" info -->\n    <div class=\"d-flex flex-row flex-gap-1 flex-content-center flex-items-center pl-2\"\n    *ngIf=\"suggestion.confidence != undefined\">\n    <span class=\"important-value\">\n      {{ 'cdss.info.confidence.label' | subtranslate:lang}}\n    </span>\n    <span class=\"important-value d-flex flex-row flex-gap-1 flex-content-center flex-items-center\">\n      {{suggestion.confidence | percent}}\n    </span>\n  </div>\n      <!-- Render the \"precision\" info -->\n      <!-- && suggestion.confidence != undefined -->\n      <div class=\"d-flex flex-row flex-gap-1 flex-content-center flex-items-center pl-2\"\n      *ngIf=\"showPrecision && suggestion.precision != undefined && suggestion.precision > 0\">\n      <span class=\"inner-title\">\n        {{ 'cdss.info.precision.label' | subtranslate:lang}}\n      </span>\n      <span class=\"inner-title d-flex flex-row flex-gap-1 flex-content-center flex-items-center\">\n        {{suggestion.precision | percent}}\n      </span>\n      </div>\n\n  <mat-divider></mat-divider>\n\n  <div *ngIf=\"displayDetails\">\n    <!-- azioni -->\n    <!-- <div *ngFor=\"let a of suggestion?.actions\" class=\"action-list d-flex flex-column pl-2\">\n      <span class=\"action\">\n        {{a}}\n      </span>\n    </div> -->\n    <mat-list *ngIf=\"suggestion?.actions?.length > 0 ; else noActions\" role=\"list\" class=\"action-list\">\n      <ng-container *ngFor=\"let a of suggestion?.actions\">\n        <mat-list-item role=\"listitem\" class=\"action\" >\n          <span matTooltip=\"{{a.label}}\" matTooltipPosition=\"above\" matTooltipShowDelay=\"250\">{{a.label}}</span></mat-list-item>\n      </ng-container>\n    </mat-list>\n    <ng-template #noActions>\n      <mat-list-item role=\"listitem\" class=\"no-action\"> {{ 'cdss.no-action.label' | subtranslate:lang}}</mat-list-item>\n    </ng-template>\n\n    <mat-divider></mat-divider>\n    <!-- Render the \"quality of evidence\" info -->\n    <div class=\"d-flex flex-row flex-gap-1 flex-content-center flex-items-center pl-2\"\n      *ngIf=\"suggestion.qoe != undefined\">\n      <span class=\"inner-title\">\n        {{ 'cdss.info.qoe.label' | subtranslate:lang}}\n      </span>\n      <span class=\"important-value\">\n        {{suggestion.qoe?.display}}\n      </span>\n    </div>\n  </div>\n\n  <!-- Render the \"strength\" info -->\n  <div class=\"d-flex flex-row flex-gap-1 flex-content-center flex-items-center pl-2\"\n    *ngIf=\"suggestion.strength != undefined\">\n    <span class=\"inner-title\">\n      {{ 'cdss.info.strength.label' | subtranslate:lang}}\n    </span>\n    <span class=\"important-value d-flex flex-row flex-gap-1 flex-content-center flex-items-center\">\n      <mat-icon *ngIf=\"suggestion.strength.code == 'weak'\">gpp_bad</mat-icon>\n      <mat-icon *ngIf=\"suggestion.strength.code == 'strong'\">verified_user</mat-icon>\n      {{suggestion.strength?.display}}\n    </span>\n  </div>\n\n  <!-- Render the \"practitioner\" info -->\n  <div *ngIf=\"suggestion.acceptancePerformer?.id != undefined\"\n    class=\"d-flex flex-row-reverse flex-content-center flex-items-center flex-gap-2 pr-3\">\n    <span class=\"practitioner\">\n      {{'suggestion.card.managed-by.label' | subtranslate:lang}}{{ suggestion.acceptancePerformer?.id }}\n    </span>\n  </div>\n\n  <!-- Render the \"date\" info -->\n  <div *ngIf=\"suggestion.acceptedOn != undefined\"\n    class=\"d-flex flex-row-reverse flex-content-center flex-items-center flex-gap-2 pr-3\">\n    <span class=\"practitioner\">\n      {{'suggestion.card.managed-at.label' | subtranslate:lang}}{{ suggestion.acceptedOn | date:'dd/MM/yyyy' }}\n    </span>\n  </div>\n\n  <!-- pulsanti -->\n  <div class=\"d-flex flex-row-reverse flex-justify-between flex-content-center flex-items-center mt-1 mb-1 p-2 flex-gap-2\">\n    <!-- [ngClass]=\"{'flex-row-reverse': suggestion && suggestion.actions && suggestion.actions.length == 0}\" -->\n    <!-- <mat-slide-toggle *ngIf=\"!readonly\" (change)=\"manageChange($event)\">{{'suggestion.card.accept.button.label' | translate}}</mat-slide-toggle> -->\n    <button mat-stroked-button color=\"primary\" *ngIf=\"!readonly && !suggestion.accepted\"\n    (click)=\"acceptSuggestion($event)\">{{'suggestion.card.accept.button.label' | translate}}</button>\n    <div *ngIf=\"suggestion && suggestion.actions && suggestion!.actions!.length > 0 && !displayDetails\">\n      <span class=\"action-count\">\n        {{'suggestion.card.action.label' | subtranslate:lang}}: {{suggestion!.actions!.length}}\n      </span>\n    </div>\n  </div>\n</div>", styles: [".suggestion-title{font-weight:600;font-size:large}.card{border-radius:5px}.action{font-weight:500;font-size:medium}.inner-title{font-weight:100;font-size:small}.important-value{font-weight:600}.action-list{background-color:var(--action-list-color, lightyellow)}.action-count{color:var(--accent-color, lightcoral);font-size:small;font-style:italic}.no-action{font-weight:100;font-style:italic;margin:8px}.practitioner{font-weight:100;font-size:small;font-style:italic}mat-list-item{height:32px!important}a{font-style:italic;cursor:pointer;font-weight:300;color:var(--accent-color, lightcoral)}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$2.SubTranslateService }]; }, propDecorators: { lang: [{
                type: Input
            }], suggestion: [{
                type: Input
            }], accepted: [{
                type: Output
            }], explanation: [{
                type: Output
            }], readonly: [{
                type: Input
            }], showPrecision: [{
                type: Input
            }] } });

// AoT requires an exported function for factories
function HttpLoaderFactoryCdssInfo(http) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class CdssSuggestionInfoModule {
}
CdssSuggestionInfoModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssSuggestionInfoModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
CdssSuggestionInfoModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: CdssSuggestionInfoModule, declarations: [CdssSuggestionInfoComponent], imports: [CommonModule,
        SubTranslateModule, i1$3.TranslateModule, MatIconModule,
        MatButtonModule,
        MatDividerModule,
        MatExpansionModule,
        // MatSlideToggleModule,
        MatListModule,
        MatTooltipModule], exports: [CdssSuggestionInfoComponent] });
CdssSuggestionInfoModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssSuggestionInfoModule, imports: [CommonModule,
        SubTranslateModule,
        TranslateModule.forChild({
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactoryCdssInfo,
                deps: [HttpClient],
            },
            isolate: true,
        }),
        MatIconModule,
        MatButtonModule,
        MatDividerModule,
        MatExpansionModule,
        // MatSlideToggleModule,
        MatListModule,
        MatTooltipModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssSuggestionInfoModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        CdssSuggestionInfoComponent
                    ],
                    imports: [
                        CommonModule,
                        SubTranslateModule,
                        TranslateModule.forChild({
                            loader: {
                                provide: TranslateLoader,
                                useFactory: HttpLoaderFactoryCdssInfo,
                                deps: [HttpClient],
                            },
                            isolate: true,
                        }),
                        MatIconModule,
                        MatButtonModule,
                        MatDividerModule,
                        MatExpansionModule,
                        // MatSlideToggleModule,
                        MatListModule,
                        MatTooltipModule
                    ],
                    exports: [CdssSuggestionInfoComponent]
                }]
        }] });

const it$1 = {
    "cdss.performance.accuracy.label": "Accuratezza",
    "cdss.performance.precision.label": "Precisione",
    "cdss.performance.sensitivity.label": "Sensibilità",
    "cdss.performance.specificity.label": "Specificità",
    "cdss.performance.f1Score.label": "F1 Score",
    "cdss.performance.title.label": "Performance sulla predizione: ",
};

const en$1 = {};

class CdssPerformanceChartComponent {
    constructor(_subTranslateService, _translate) {
        this._subTranslateService = _subTranslateService;
        this._translate = _translate;
        this.showDialog = false;
        this.showInfoButton = true;
        this.showXAxis = true;
        this.showYAxis = true;
        this.gradient = true;
        this.showLegend = false;
        this.showXAxisLabel = false;
        this.showYAxisLabel = false;
        this.yScaleMax = 1;
        this.openInfoClicked = new EventEmitter();
        this.lang = this.lang;
        this.createDictionary();
    }
    // approccio per unificare il servizio di traduzione
    createDictionary() {
        const dictionary = new Map();
        dictionary.set('en', en$1);
        dictionary.set('it', it$1);
        this._subTranslateService.setLanguages(dictionary);
    }
    ngOnInit() {
        if (this.class && !this.perf) {
            this.perf = this.class.performance;
        }
        // this._subTranslateService.getTranslation('cdss.performance.title.label', this.lang) + 
        this.title = this.customTitle ?? this.class?.cvLabel?.display?.toUpperCase();
        this.prepareChart();
    }
    prepareChart() {
        if (this.perf) {
            this.perfs = [];
            if (this.perf.accuracy != undefined) {
                this.perfs.push({ "name": this._subTranslateService.getTranslation('cdss.performance.accuracy.label', this.lang), "value": this.perf.accuracy });
            }
            if (this.perf.sensitivity != undefined) {
                this.perfs.push({ "name": this._subTranslateService.getTranslation('cdss.performance.sensitivity.label', this.lang), "value": this.perf.sensitivity });
            }
            if (this.perf.specificity != undefined) {
                this.perfs.push({ "name": this._subTranslateService.getTranslation('cdss.performance.specificity.label', this.lang), "value": this.perf.specificity });
            }
            if (this.perf.precision != undefined) {
                this.perfs.push({ "name": this._subTranslateService.getTranslation('cdss.performance.precision.label', this.lang), "value": this.perf.precision });
            }
            if (this.perf.f1Score != undefined) {
                this.perfs.push({ "name": this._subTranslateService.getTranslation('cdss.performance.f1Score.label', this.lang), "value": this.perf.f1Score });
            }
        }
    }
    infoClicked() {
        this.openInfoClicked.emit(this.perf);
    }
}
CdssPerformanceChartComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssPerformanceChartComponent, deps: [{ token: i1$2.SubTranslateService }, { token: i1$3.TranslateService }], target: i0.ɵɵFactoryTarget.Component });
CdssPerformanceChartComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: CdssPerformanceChartComponent, selector: "heart-cdss-performance-chart", inputs: { class: "class", perf: "perf", lang: "lang", customTitle: "customTitle", palette: "palette", showDialog: "showDialog", showInfoButton: "showInfoButton", showXAxis: "showXAxis", showYAxis: "showYAxis", gradient: "gradient", showLegend: "showLegend", showXAxisLabel: "showXAxisLabel", xAxisLabel: "xAxisLabel", showYAxisLabel: "showYAxisLabel", yAxisLabel: "yAxisLabel", yScaleMax: "yScaleMax" }, outputs: { openInfoClicked: "openInfoClicked" }, ngImport: i0, template: "<div class=\"d-flex flex-row flex-justify-between flex-items-center\">\n  <h2 *ngIf=\"title\">{{title | translate}}</h2>\n  <button *ngIf=\"showInfoButton\" mat-icon-button  (click)=\"infoClicked()\">\n    <mat-icon>info_outline</mat-icon>\n  </button>\n</div>\n<div class=\"chart-wrapper\">\n  <ngx-charts-bar-vertical\n  [scheme]=\"palette\"\n  [results]=\"perfs\"\n  [gradient]=\"gradient\"\n  [xAxis]=\"showXAxis\"\n  [yAxis]=\"showYAxis\"\n  [legend]=\"showLegend\"\n  [showXAxisLabel]=\"showXAxisLabel\"\n  [showYAxisLabel]=\"showYAxisLabel\"\n  [xAxisLabel]=\"xAxisLabel\"\n  [yAxisLabel]=\"yAxisLabel\"\n  [yScaleMax]=\"yScaleMax\"\n  >\n</ngx-charts-bar-vertical>\n</div>", styles: [".chart-wrapper{width:100%;height:200px;display:flex;flex-flow:column;justify-content:center;align-items:center;box-sizing:border-box;padding-top:16px}h2{margin-bottom:0}\n"], dependencies: [{ kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: i6$2.BarVerticalComponent, selector: "ngx-charts-bar-vertical", inputs: ["legend", "legendTitle", "legendPosition", "xAxis", "yAxis", "showXAxisLabel", "showYAxisLabel", "xAxisLabel", "yAxisLabel", "tooltipDisabled", "gradient", "showGridLines", "activeEntries", "schemeType", "trimXAxisTicks", "trimYAxisTicks", "rotateXAxisTicks", "maxXAxisTickLength", "maxYAxisTickLength", "xAxisTickFormatting", "yAxisTickFormatting", "xAxisTicks", "yAxisTicks", "barPadding", "roundDomains", "roundEdges", "yScaleMax", "yScaleMin", "showDataLabel", "dataLabelFormatting", "noBarWhenZero", "wrapTicks"], outputs: ["activate", "deactivate"] }, { kind: "pipe", type: i1$3.TranslatePipe, name: "translate" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssPerformanceChartComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-cdss-performance-chart', template: "<div class=\"d-flex flex-row flex-justify-between flex-items-center\">\n  <h2 *ngIf=\"title\">{{title | translate}}</h2>\n  <button *ngIf=\"showInfoButton\" mat-icon-button  (click)=\"infoClicked()\">\n    <mat-icon>info_outline</mat-icon>\n  </button>\n</div>\n<div class=\"chart-wrapper\">\n  <ngx-charts-bar-vertical\n  [scheme]=\"palette\"\n  [results]=\"perfs\"\n  [gradient]=\"gradient\"\n  [xAxis]=\"showXAxis\"\n  [yAxis]=\"showYAxis\"\n  [legend]=\"showLegend\"\n  [showXAxisLabel]=\"showXAxisLabel\"\n  [showYAxisLabel]=\"showYAxisLabel\"\n  [xAxisLabel]=\"xAxisLabel\"\n  [yAxisLabel]=\"yAxisLabel\"\n  [yScaleMax]=\"yScaleMax\"\n  >\n</ngx-charts-bar-vertical>\n</div>", styles: [".chart-wrapper{width:100%;height:200px;display:flex;flex-flow:column;justify-content:center;align-items:center;box-sizing:border-box;padding-top:16px}h2{margin-bottom:0}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$2.SubTranslateService }, { type: i1$3.TranslateService }]; }, propDecorators: { class: [{
                type: Input
            }], perf: [{
                type: Input
            }], lang: [{
                type: Input
            }], customTitle: [{
                type: Input
            }], palette: [{
                type: Input
            }], showDialog: [{
                type: Input
            }], showInfoButton: [{
                type: Input
            }], showXAxis: [{
                type: Input
            }], showYAxis: [{
                type: Input
            }], gradient: [{
                type: Input
            }], showLegend: [{
                type: Input
            }], showXAxisLabel: [{
                type: Input
            }], xAxisLabel: [{
                type: Input
            }], showYAxisLabel: [{
                type: Input
            }], yAxisLabel: [{
                type: Input
            }], yScaleMax: [{
                type: Input
            }], openInfoClicked: [{
                type: Output
            }] } });

// AoT requires an exported function for factories
function HttpLoaderFactoryCdssPerformance(http) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class CdssPerformanceChartModule {
}
CdssPerformanceChartModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssPerformanceChartModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
CdssPerformanceChartModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: CdssPerformanceChartModule, declarations: [CdssPerformanceChartComponent], imports: [CommonModule,
        SubTranslateModule, i1$3.TranslateModule, MatIconModule,
        MatButtonModule,
        MatDividerModule,
        MatExpansionModule,
        MatListModule,
        PreventDoubleClickModule, i1$3.TranslateModule, MatIconModule,
        MatButtonModule,
        MatDividerModule,
        MatExpansionModule,
        NgxChartsModule,
        MatTooltipModule], exports: [CdssPerformanceChartComponent] });
CdssPerformanceChartModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssPerformanceChartModule, imports: [CommonModule,
        SubTranslateModule,
        TranslateModule.forChild({
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactoryCdssPerformance,
                deps: [HttpClient],
            },
            isolate: true,
        }),
        MatIconModule,
        MatButtonModule,
        MatDividerModule,
        MatExpansionModule,
        MatListModule,
        PreventDoubleClickModule,
        TranslateModule.forChild(),
        MatIconModule,
        MatButtonModule,
        MatDividerModule,
        MatExpansionModule,
        NgxChartsModule,
        MatTooltipModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssPerformanceChartModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        CdssPerformanceChartComponent
                    ],
                    imports: [
                        CommonModule,
                        SubTranslateModule,
                        TranslateModule.forChild({
                            loader: {
                                provide: TranslateLoader,
                                useFactory: HttpLoaderFactoryCdssPerformance,
                                deps: [HttpClient],
                            },
                            isolate: true,
                        }),
                        MatIconModule,
                        MatButtonModule,
                        MatDividerModule,
                        MatExpansionModule,
                        MatListModule,
                        PreventDoubleClickModule,
                        TranslateModule.forChild(),
                        MatIconModule,
                        MatButtonModule,
                        MatDividerModule,
                        MatExpansionModule,
                        NgxChartsModule,
                        MatTooltipModule,
                    ], exports: [CdssPerformanceChartComponent]
                }]
        }] });

const en = {};

const it = {
    "cdss.dataset.collectionDate.title": "Prodotto il",
    "cdss.dataset.accessRight.title": "Accesso",
    "cdss.dataset.creators.title": "Prodotto da",
    "cdss.dataset.description.title": "Descrizione",
    "cdss.dataset.referencedBy.title": "Riferimenti bibliografici",
};

class CdssDatasetDetailsComponent {
    constructor(_subTranslateService, _translate) {
        this._subTranslateService = _subTranslateService;
        this._translate = _translate;
        this.lang = this.lang;
        this.createDictionary();
    }
    // approccio per unificare il servizio di traduzione
    createDictionary() {
        const dictionary = new Map();
        dictionary.set('en', en);
        dictionary.set('it', it);
        this._subTranslateService.setLanguages(dictionary);
    }
    ngOnInit() {
        console.log(this.datasetDescriptor);
    }
}
CdssDatasetDetailsComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssDatasetDetailsComponent, deps: [{ token: i1$2.SubTranslateService }, { token: i1$3.TranslateService }], target: i0.ɵɵFactoryTarget.Component });
CdssDatasetDetailsComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: CdssDatasetDetailsComponent, selector: "heart-cdss-dataset-details", inputs: { datasetDescriptor: "datasetDescriptor", lang: "lang", customTitle: "customTitle" }, ngImport: i0, template: "<!-- flex-gap-2 -->\n<div class=\"d-flex flex-column \">\n  <h2>{{customTitle | translate}}</h2>\n\n  <div class=\"d-flex flex-row flex-gap-1\" *ngIf=\"datasetDescriptor?.title\">\n    <!-- <span class=\"title\">{{'cdss.dataset.explanation.title' | subtranslate:lang}}:</span> -->\n    <span class=\"content\">{{datasetDescriptor.title}}</span>\n  </div>\n  <div class=\"d-flex flex-row flex-gap-1\" *ngIf=\"datasetDescriptor?.version\">\n    <!-- <span class=\"title\">{{'cdss.dataset.explanation.title' | subtranslate:lang}}:</span> -->\n    <span class=\"content version\">{{datasetDescriptor!.version}}</span>\n  </div>\n  <div class=\"d-flex flex-row flex-gap-1\" *ngIf=\"datasetDescriptor?.collectionDate\">\n    <span class=\"title\">{{'cdss.dataset.collectionDate.title' | subtranslate:lang}}:</span>\n    <span class=\"content\">{{datasetDescriptor.collectionDate | date:'dd/MM/yyyy'}}</span>\n  </div>\n\n  <div class=\"d-flex flex-row flex-gap-1\" *ngIf=\"datasetDescriptor?.accessRight\">\n    <span class=\"title\">{{'cdss.dataset.accessRight.title' | subtranslate:lang}}:</span>\n    <span class=\"title\">{{datasetDescriptor.accessRight}}</span>\n  </div>\n  <div class=\"d-flex flex-row flex-gap-1\" *ngIf=\"datasetDescriptor?.creators && datasetDescriptor?.creators.length > 0\">\n    <span class=\"title\">{{'cdss.dataset.creators.title' | subtranslate:lang}}:</span>\n    <span class=\"content\">{{datasetDescriptor.creators?.join(', ')}}</span>\n  </div>\n  <div class=\"d-flex flex-row flex-gap-1\" *ngIf=\"datasetDescriptor?.description\">\n    <span class=\"title\">{{'cdss.dataset.description.title' | subtranslate:lang}}:</span>\n    <span class=\"content\">{{datasetDescriptor.description}}</span>\n  </div>\n  \n\n  <ng-container *ngFor=\"let item of datasetDescriptor.referencedBy\">\n    <mat-expansion-panel  class=\"mt-1 mb-2\">\n      <mat-expansion-panel-header>\n        <mat-panel-title>\n          <span class=\"title\">{{'cdss.dataset.referencedBy.title' | subtranslate:lang}}</span>\n        </mat-panel-title>\n      </mat-expansion-panel-header>\n      <div class=\"d-flex flex-column flex-gap-1\" *ngIf=\"datasetDescriptor?.description\">\n        <span class=\"title\">{{item.title}}</span>\n        <span class=\"content\" *ngIf=\"item.date\">{{item.date | date:'dd/MM/yyyy'}}</span>\n      </div>\n      \n    </mat-expansion-panel>\n  </ng-container>\n\n</div>", styles: ["h2{margin:0}.title{font-weight:600}.content{font-weight:300}.version{font-style:italic}.version:before{content:\"v.\"}\n"], dependencies: [{ kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i4$1.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["disabled", "expanded", "hideToggle", "togglePosition"], outputs: ["opened", "closed", "expandedChange", "afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }, { kind: "component", type: i4$1.MatExpansionPanelHeader, selector: "mat-expansion-panel-header", inputs: ["tabIndex", "expandedHeight", "collapsedHeight"] }, { kind: "directive", type: i4$1.MatExpansionPanelTitle, selector: "mat-panel-title" }, { kind: "pipe", type: i2.DatePipe, name: "date" }, { kind: "pipe", type: i1$2.SubTranslatePipe, name: "subtranslate" }, { kind: "pipe", type: i1$3.TranslatePipe, name: "translate" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssDatasetDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-cdss-dataset-details', template: "<!-- flex-gap-2 -->\n<div class=\"d-flex flex-column \">\n  <h2>{{customTitle | translate}}</h2>\n\n  <div class=\"d-flex flex-row flex-gap-1\" *ngIf=\"datasetDescriptor?.title\">\n    <!-- <span class=\"title\">{{'cdss.dataset.explanation.title' | subtranslate:lang}}:</span> -->\n    <span class=\"content\">{{datasetDescriptor.title}}</span>\n  </div>\n  <div class=\"d-flex flex-row flex-gap-1\" *ngIf=\"datasetDescriptor?.version\">\n    <!-- <span class=\"title\">{{'cdss.dataset.explanation.title' | subtranslate:lang}}:</span> -->\n    <span class=\"content version\">{{datasetDescriptor!.version}}</span>\n  </div>\n  <div class=\"d-flex flex-row flex-gap-1\" *ngIf=\"datasetDescriptor?.collectionDate\">\n    <span class=\"title\">{{'cdss.dataset.collectionDate.title' | subtranslate:lang}}:</span>\n    <span class=\"content\">{{datasetDescriptor.collectionDate | date:'dd/MM/yyyy'}}</span>\n  </div>\n\n  <div class=\"d-flex flex-row flex-gap-1\" *ngIf=\"datasetDescriptor?.accessRight\">\n    <span class=\"title\">{{'cdss.dataset.accessRight.title' | subtranslate:lang}}:</span>\n    <span class=\"title\">{{datasetDescriptor.accessRight}}</span>\n  </div>\n  <div class=\"d-flex flex-row flex-gap-1\" *ngIf=\"datasetDescriptor?.creators && datasetDescriptor?.creators.length > 0\">\n    <span class=\"title\">{{'cdss.dataset.creators.title' | subtranslate:lang}}:</span>\n    <span class=\"content\">{{datasetDescriptor.creators?.join(', ')}}</span>\n  </div>\n  <div class=\"d-flex flex-row flex-gap-1\" *ngIf=\"datasetDescriptor?.description\">\n    <span class=\"title\">{{'cdss.dataset.description.title' | subtranslate:lang}}:</span>\n    <span class=\"content\">{{datasetDescriptor.description}}</span>\n  </div>\n  \n\n  <ng-container *ngFor=\"let item of datasetDescriptor.referencedBy\">\n    <mat-expansion-panel  class=\"mt-1 mb-2\">\n      <mat-expansion-panel-header>\n        <mat-panel-title>\n          <span class=\"title\">{{'cdss.dataset.referencedBy.title' | subtranslate:lang}}</span>\n        </mat-panel-title>\n      </mat-expansion-panel-header>\n      <div class=\"d-flex flex-column flex-gap-1\" *ngIf=\"datasetDescriptor?.description\">\n        <span class=\"title\">{{item.title}}</span>\n        <span class=\"content\" *ngIf=\"item.date\">{{item.date | date:'dd/MM/yyyy'}}</span>\n      </div>\n      \n    </mat-expansion-panel>\n  </ng-container>\n\n</div>", styles: ["h2{margin:0}.title{font-weight:600}.content{font-weight:300}.version{font-style:italic}.version:before{content:\"v.\"}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$2.SubTranslateService }, { type: i1$3.TranslateService }]; }, propDecorators: { datasetDescriptor: [{
                type: Input
            }], lang: [{
                type: Input
            }], customTitle: [{
                type: Input
            }] } });

// AoT requires an exported function for factories
function HttpLoaderFactoryCdssDataset(http) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class CdssDatasetDetailsModule {
}
CdssDatasetDetailsModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssDatasetDetailsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
CdssDatasetDetailsModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: CdssDatasetDetailsModule, declarations: [CdssDatasetDetailsComponent], imports: [CommonModule,
        SubTranslateModule, i1$3.TranslateModule, MatIconModule,
        MatButtonModule,
        MatDividerModule,
        MatExpansionModule,
        MatListModule,
        PreventDoubleClickModule, i1$3.TranslateModule, MatIconModule,
        MatButtonModule,
        MatDividerModule,
        MatExpansionModule,
        NgxChartsModule,
        MatTooltipModule], exports: [CdssDatasetDetailsComponent] });
CdssDatasetDetailsModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssDatasetDetailsModule, imports: [CommonModule,
        SubTranslateModule,
        TranslateModule.forChild({
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactoryCdssDataset,
                deps: [HttpClient],
            },
            isolate: true,
        }),
        MatIconModule,
        MatButtonModule,
        MatDividerModule,
        MatExpansionModule,
        MatListModule,
        PreventDoubleClickModule,
        TranslateModule.forChild(),
        MatIconModule,
        MatButtonModule,
        MatDividerModule,
        MatExpansionModule,
        NgxChartsModule,
        MatTooltipModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CdssDatasetDetailsModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        CdssDatasetDetailsComponent
                    ],
                    imports: [
                        CommonModule,
                        SubTranslateModule,
                        TranslateModule.forChild({
                            loader: {
                                provide: TranslateLoader,
                                useFactory: HttpLoaderFactoryCdssDataset,
                                deps: [HttpClient],
                            },
                            isolate: true,
                        }),
                        MatIconModule,
                        MatButtonModule,
                        MatDividerModule,
                        MatExpansionModule,
                        MatListModule,
                        PreventDoubleClickModule,
                        TranslateModule.forChild(),
                        MatIconModule,
                        MatButtonModule,
                        MatDividerModule,
                        MatExpansionModule,
                        NgxChartsModule,
                        MatTooltipModule,
                    ],
                    exports: [CdssDatasetDetailsComponent]
                }]
        }] });

/*
 * Public API Surface of heart-ui-cdss
 */

/**
 * Generated bundle index. Do not edit.
 */

export { Action, ActionType, Bound, Card, CdssCardComponent, CdssCardInfoComponent, CdssCardInfoModule, CdssCardModule, CdssDatasetDetailsComponent, CdssDatasetDetailsModule, CdssExpandibleCardComponent, CdssExpandibleCardModule, CdssPerformanceChartComponent, CdssPerformanceChartModule, CdssServiceConfig, CdssSuggestionInfoComponent, CdssSuggestionInfoModule, Counterfactual, CounterfactualExplanation, DatasetDescriptor, HeartUiCdssModule, HeartUiCdssService, Hook, HttpLoaderFactoryCdssCard, HttpLoaderFactoryCdssCardInfo, HttpLoaderFactoryCdssDataset, HttpLoaderFactoryCdssExpCard, HttpLoaderFactoryCdssInfo, HttpLoaderFactoryCdssPerformance, MlClass, MlExplanation, MlModel, MlPerformance, ModelDescriptor, ModelFeature, ModelFile, PatientCard, RiskDescriptor, Shap, StudyInfo, Suggestion };
//# sourceMappingURL=eng-it4h-heart-ui-cdss.mjs.map
