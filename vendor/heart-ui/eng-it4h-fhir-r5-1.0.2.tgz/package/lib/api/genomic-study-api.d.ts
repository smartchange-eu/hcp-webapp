import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class GenomicStudyApi extends AbstractApi<model.GenomicStudy> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param status - The status of the study
     * @param focus - What the genomic study analysis is about, when it is not about the subject of record
     * @param subject - Who the study is about
     * @param patient - Who the study is about
     * @param identifier - Identifiers for the Study
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(status?: string, focus?: datatype.Reference, subject?: datatype.Reference, patient?: datatype.Reference, identifier?: string, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: GenomicStudyApi.SearchParameterGenomicStudy, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace GenomicStudyApi {
    interface SearchParameterGenomicStudy {
        status?: string;
        focus?: datatype.Reference;
        subject?: datatype.Reference;
        patient?: datatype.Reference;
        identifier?: string;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
