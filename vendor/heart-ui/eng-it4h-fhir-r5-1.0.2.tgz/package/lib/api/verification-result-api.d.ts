import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class VerificationResultApi extends AbstractApi<model.VerificationResult> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param attestation_onbehalfof - Select validation information for data that was attested to on behalf of the specified source
     * @param attestation_who - Select validation information for data that was attested to by the specified source
     * @param primarysource_who - Select validation information for data that was validated against the specified primary source
     * @param validator_organization - Select validation information for data that was validated by the specified organization
     * @param attestation_method - Select validation information for data that was attested to using the specified method
     * @param status_date - Select validation information with a validation status that occurred at the specified date/time
     * @param primarysource_type - Select validation information for data that was validated against the specified type of primary source organization
     * @param target - A resource that was validated
     * @param status - Select validation information with the specified status
     * @param primarysource_date - Select validation information for data that was validated against a primary source on the specified date
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(attestation_onbehalfof?: datatype.Reference, attestation_who?: datatype.Reference, primarysource_who?: datatype.Reference, validator_organization?: datatype.Reference, attestation_method?: string, status_date?: Date, primarysource_type?: string, target?: datatype.Reference, status?: string, primarysource_date?: Date, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: VerificationResultApi.SearchParameterVerificationResult, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace VerificationResultApi {
    interface SearchParameterVerificationResult {
        attestation_onbehalfof?: datatype.Reference;
        attestation_who?: datatype.Reference;
        primarysource_who?: datatype.Reference;
        validator_organization?: datatype.Reference;
        attestation_method?: string;
        status_date?: Date;
        primarysource_type?: string;
        target?: datatype.Reference;
        status?: string;
        primarysource_date?: Date;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
