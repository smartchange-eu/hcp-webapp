import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class GroupApi extends AbstractApi<model.Group> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param member - Reference to the group member
     * @param code - The kind of resources contained
     * @param membership - Definitional or enumerated group
     * @param managing_entity - Entity that is the custodian of the Group's definition
     * @param type - The type of resources the group contains
     * @param characteristic_value - A composite of both characteristic and value
     * @param exclude - Group includes or excludes
     * @param name - A portion of the Group's name
     * @param identifier - Unique id
     * @param value - Value held by characteristic
     * @param characteristic_reference - An entity referenced in a characteristic
     * @param characteristic - Kind of characteristic
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(member?: datatype.Reference, code?: string, membership?: string, managing_entity?: datatype.Reference, type?: string, characteristic_value?: any, exclude?: string, name?: string, identifier?: string, value?: string, characteristic_reference?: datatype.Reference, characteristic?: string, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: GroupApi.SearchParameterGroup, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace GroupApi {
    interface SearchParameterGroup {
        member?: datatype.Reference;
        code?: string;
        membership?: string;
        managing_entity?: datatype.Reference;
        type?: string;
        characteristic_value?: any;
        exclude?: string;
        name?: string;
        identifier?: string;
        value?: string;
        characteristic_reference?: datatype.Reference;
        characteristic?: string;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
