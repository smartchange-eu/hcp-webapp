import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class EndpointApi extends AbstractApi<model.Endpoint> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param organization - The organization that is managing the endpoint
     * @param payload_type - The type of content that may be used at this endpoint (e.g. XDS Discharge summaries)
     * @param identifier - Identifies this endpoint across multiple systems
     * @param connection_type - Protocol/Profile/Standard to be used with this endpoint connection
     * @param name - A name that this endpoint can be identified by
     * @param status - The current status of the Endpoint (usually expected to be active)
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(organization?: datatype.Reference, payload_type?: string, identifier?: string, connection_type?: string, name?: string, status?: string, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: EndpointApi.SearchParameterEndpoint, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace EndpointApi {
    interface SearchParameterEndpoint {
        organization?: datatype.Reference;
        payload_type?: string;
        identifier?: string;
        connection_type?: string;
        name?: string;
        status?: string;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
