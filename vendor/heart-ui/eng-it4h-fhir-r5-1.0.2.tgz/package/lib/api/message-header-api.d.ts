import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class MessageHeaderApi extends AbstractApi<model.MessageHeader> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param focus - The actual content of the message
     * @param responsible - Final responsibility for event
     * @param code - ok | transient-error | fatal-error
     * @param destination - Name of system
     * @param event - Code for the event this message represents or link to event definition
     * @param source - Name of system
     * @param target - Particular delivery destination within the destination
     * @param response_id - Id of original message
     * @param author - The source of the decision
     * @param receiver - Intended "real-world" recipient for the data
     * @param sender - Real world sender of the message
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(focus?: datatype.Reference, responsible?: datatype.Reference, code?: string, destination?: string, event?: string, source?: string, target?: datatype.Reference, response_id?: string, author?: datatype.Reference, receiver?: datatype.Reference, sender?: datatype.Reference, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: MessageHeaderApi.SearchParameterMessageHeader, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace MessageHeaderApi {
    interface SearchParameterMessageHeader {
        focus?: datatype.Reference;
        responsible?: datatype.Reference;
        code?: string;
        destination?: string;
        event?: string;
        source?: string;
        target?: datatype.Reference;
        response_id?: string;
        author?: datatype.Reference;
        receiver?: datatype.Reference;
        sender?: datatype.Reference;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
