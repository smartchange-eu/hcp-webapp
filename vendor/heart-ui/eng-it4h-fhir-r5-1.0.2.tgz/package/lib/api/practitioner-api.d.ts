import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class PractitionerApi extends AbstractApi<model.Practitioner> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param email - Multiple Resources:

* [Patient](patient.html): A value in an email contact
* [Person](person.html): A value in an email contact
* [Practitioner](practitioner.html): A value in an email contact
* [PractitionerRole](practitionerrole.html): A value in an email contact
* [RelatedPerson](relatedperson.html): A value in an email contact

     * @param death_date - The date of death has been provided and satisfies this search value
     * @param address_city - Multiple Resources:

* [Patient](patient.html): A city specified in an address
* [Person](person.html): A city specified in an address
* [Practitioner](practitioner.html): A city specified in an address
* [RelatedPerson](relatedperson.html): A city specified in an address

     * @param gender - Multiple Resources:

* [Patient](patient.html): Gender of the patient
* [Person](person.html): The gender of the person
* [Practitioner](practitioner.html): Gender of the practitioner
* [RelatedPerson](relatedperson.html): Gender of the related person

     * @param phone - Multiple Resources:

* [Patient](patient.html): A value in a phone contact
* [Person](person.html): A value in a phone contact
* [Practitioner](practitioner.html): A value in a phone contact
* [PractitionerRole](practitionerrole.html): A value in a phone contact
* [RelatedPerson](relatedperson.html): A value in a phone contact

     * @param phonetic - Multiple Resources:

* [Patient](patient.html): A portion of either family or given name using some kind of phonetic matching algorithm
* [Person](person.html): A portion of name using some kind of phonetic matching algorithm
* [Practitioner](practitioner.html): A portion of either family or given name using some kind of phonetic matching algorithm
* [RelatedPerson](relatedperson.html): A portion of name using some kind of phonetic matching algorithm

     * @param address_state - Multiple Resources:

* [Patient](patient.html): A state specified in an address
* [Person](person.html): A state specified in an address
* [Practitioner](practitioner.html): A state specified in an address
* [RelatedPerson](relatedperson.html): A state specified in an address

     * @param address - Multiple Resources:

* [Patient](patient.html): A server defined search that may match any of the string fields in the Address, including line, city, district, state, country, postalCode, and/or text
* [Person](person.html): A server defined search that may match any of the string fields in the Address, including line, city, district, state, country, postalCode, and/or text
* [Practitioner](practitioner.html): A server defined search that may match any of the string fields in the Address, including line, city, district, state, country, postalCode, and/or text
* [RelatedPerson](relatedperson.html): A server defined search that may match any of the string fields in the Address, including line, city, district, state, country, postalCode, and/or text

     * @param active - Whether the practitioner record is active
     * @param deceased - This Practitioner has been marked as deceased, or has a death date entered
     * @param qualification_period - The date(s) a qualification is valid for
     * @param address_use - Multiple Resources:

* [Patient](patient.html): A use code specified in an address
* [Person](person.html): A use code specified in an address
* [Practitioner](practitioner.html): A use code specified in an address
* [RelatedPerson](relatedperson.html): A use code specified in an address

     * @param telecom - Multiple Resources:

* [Patient](patient.html): The value in any kind of telecom details of the patient
* [Person](person.html): The value in any kind of contact
* [Practitioner](practitioner.html): The value in any kind of contact
* [PractitionerRole](practitionerrole.html): The value in any kind of contact
* [RelatedPerson](relatedperson.html): The value in any kind of contact

     * @param family - Multiple Resources:

* [Patient](patient.html): A portion of the family name of the patient
* [Practitioner](practitioner.html): A portion of the family name

     * @param given - Multiple Resources:

* [Patient](patient.html): A portion of the given name of the patient
* [Practitioner](practitioner.html): A portion of the given name

     * @param address_postalcode - Multiple Resources:

* [Patient](patient.html): A postalCode specified in an address
* [Person](person.html): A postal code specified in an address
* [Practitioner](practitioner.html): A postalCode specified in an address
* [RelatedPerson](relatedperson.html): A postal code specified in an address

     * @param identifier - A practitioner's Identifier
     * @param address_country - Multiple Resources:

* [Patient](patient.html): A country specified in an address
* [Person](person.html): A country specified in an address
* [Practitioner](practitioner.html): A country specified in an address
* [RelatedPerson](relatedperson.html): A country specified in an address

     * @param name - A server defined search that may match any of the string fields in the HumanName, including family, give, prefix, suffix, suffix, and/or text
     * @param communication - A language to communicate with the practitioner
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(email?: string, death_date?: Date, address_city?: string, gender?: string, phone?: string, phonetic?: string, address_state?: string, address?: string, active?: string, deceased?: string, qualification_period?: Date, address_use?: string, telecom?: string, family?: string, given?: string, address_postalcode?: string, identifier?: string, address_country?: string, name?: string, communication?: string, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: PractitionerApi.SearchParameterPractitioner, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace PractitionerApi {
    interface SearchParameterPractitioner {
        email?: string;
        death_date?: Date;
        address_city?: string;
        gender?: string;
        phone?: string;
        phonetic?: string;
        address_state?: string;
        address?: string;
        active?: string;
        deceased?: string;
        qualification_period?: Date;
        address_use?: string;
        telecom?: string;
        family?: string;
        given?: string;
        address_postalcode?: string;
        identifier?: string;
        address_country?: string;
        name?: string;
        communication?: string;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
