import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class RegulatedAuthorizationApi extends AbstractApi<model.RegulatedAuthorization> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param identifier - Business identifier for the authorization, typically assigned by the authorizing body
     * @param case - The case or procedure number
     * @param region - The territory (e.g., country, jurisdiction etc.) in which the authorization has been granted
     * @param subject - The type of regulated product, treatment, facility or activity that is being authorized
     * @param case_type - The defining type of case
     * @param status - The status that is authorised e.g. approved. Intermediate states can be tracked with cases and applications
     * @param holder - The organization that holds the granted authorization
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(identifier?: string, case_name?: string, region?: string, subject?: datatype.Reference, case_type?: string, status?: string, holder?: datatype.Reference, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: RegulatedAuthorizationApi.SearchParameterRegulatedAuthorization, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace RegulatedAuthorizationApi {
    interface SearchParameterRegulatedAuthorization {
        identifier?: string;
        case?: string;
        region?: string;
        subject?: datatype.Reference;
        case_type?: string;
        status?: string;
        holder?: datatype.Reference;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
