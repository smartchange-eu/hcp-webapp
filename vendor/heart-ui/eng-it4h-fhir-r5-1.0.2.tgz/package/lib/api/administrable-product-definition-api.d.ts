import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class AdministrableProductDefinitionApi extends AbstractApi<model.AdministrableProductDefinition> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param device - A device that is integral to the medicinal product, in effect being considered as an "ingredient" of the medicinal product. This is not intended for devices that are just co-packaged
     * @param identifier - An identifier for the administrable product
     * @param manufactured_item - The manufactured item(s) that this administrable product is produced from. Either a single item, or several that are mixed before administration (e.g. a power item and a solution item). Note that these are not raw ingredients
     * @param ingredient - The ingredients of this administrable medicinal product
     * @param status - The status of this administrable product. Enables tracking the life-cycle of the content.
     * @param target_species - Coded expression for the species
     * @param dose_form - The administrable dose form, i.e. the dose form of the final product after necessary reconstitution or processing
     * @param route - Coded expression for the route
     * @param form_of - The medicinal product that this is an administrable form of. This is not a reference to the item(s) that make up this administrable form - it is the whole product
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(device?: datatype.Reference, identifier?: string, manufactured_item?: datatype.Reference, ingredient?: string, status?: string, target_species?: string, dose_form?: string, route?: string, form_of?: datatype.Reference, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: AdministrableProductDefinitionApi.SearchParameterAdministrableProductDefinition, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace AdministrableProductDefinitionApi {
    interface SearchParameterAdministrableProductDefinition {
        device?: datatype.Reference;
        identifier?: string;
        manufactured_item?: datatype.Reference;
        ingredient?: string;
        status?: string;
        target_species?: string;
        dose_form?: string;
        route?: string;
        form_of?: datatype.Reference;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
