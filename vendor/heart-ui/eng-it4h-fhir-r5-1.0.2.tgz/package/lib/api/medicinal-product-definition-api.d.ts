import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class MedicinalProductDefinitionApi extends AbstractApi<model.MedicinalProductDefinition> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param characteristic - Allows the key product features to be recorded, such as "sugar free", "modified release", "parallel import"
     * @param domain - If this medicine applies to human or veterinary uses
     * @param name - The full product name
     * @param identifier - Business identifier for this product. Could be an MPID
     * @param type - Regulatory type, e.g. Investigational or Authorized
     * @param name_language - Language code for this name
     * @param characteristic_type - A category for the characteristic
     * @param master_file - A master file for to the medicinal product (e.g. Pharmacovigilance System Master File)
     * @param contact - A product specific contact, person (in a role), or an organization
     * @param ingredient - An ingredient of this product
     * @param status - The status within the lifecycle of this product record. A high-level status, this is not intended to duplicate details carried elsewhere such as legal status, or authorization status
     * @param product_classification - Allows the product to be classified by various systems
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(characteristic?: string, domain?: string, name?: string, identifier?: string, type?: string, name_language?: string, characteristic_type?: string, master_file?: datatype.Reference, contact?: datatype.Reference, ingredient?: string, status?: string, product_classification?: string, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: MedicinalProductDefinitionApi.SearchParameterMedicinalProductDefinition, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace MedicinalProductDefinitionApi {
    interface SearchParameterMedicinalProductDefinition {
        characteristic?: string;
        domain?: string;
        name?: string;
        identifier?: string;
        type?: string;
        name_language?: string;
        characteristic_type?: string;
        master_file?: datatype.Reference;
        contact?: datatype.Reference;
        ingredient?: string;
        status?: string;
        product_classification?: string;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
