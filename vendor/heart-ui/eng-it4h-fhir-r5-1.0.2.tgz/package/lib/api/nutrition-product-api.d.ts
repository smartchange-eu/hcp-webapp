import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class NutritionProductApi extends AbstractApi<model.NutritionProduct> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param code - The code identifying a specific nutrition product
     * @param serial_number - The serial number
     * @param lot_number - The lot number
     * @param status - The broad product group or category of the nutrition product
     * @param identifier - The identifier for the physical instance, typically a serial number
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(code?: string, serial_number?: string, lot_number?: string, status?: string, identifier?: string, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: NutritionProductApi.SearchParameterNutritionProduct, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace NutritionProductApi {
    interface SearchParameterNutritionProduct {
        code?: string;
        serial_number?: string;
        lot_number?: string;
        status?: string;
        identifier?: string;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
