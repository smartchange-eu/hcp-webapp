import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class SubscriptionApi extends AbstractApi<model.Subscription> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param identifier - A subscription identifier
     * @param name - A human-readable name
     * @param payload - The mime-type of notifications
     * @param type - The type of channel for the sent notifications
     * @param owner - The managing entity
     * @param content_level - Content level included in notifications
     * @param topic - The canonical topic url that triggers notifications
     * @param filter_value - Filter value used to narrow notifications
     * @param contact - Contact details for the subscription
     * @param status - The current state of the subscription
     * @param url - The uri that will receive the notifications
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(identifier?: string, name?: string, payload?: string, type?: string, owner?: datatype.Reference, content_level?: string, topic?: string, filter_value?: string, contact?: string, status?: string, url?: string, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: SubscriptionApi.SearchParameterSubscription, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace SubscriptionApi {
    interface SearchParameterSubscription {
        identifier?: string;
        name?: string;
        payload?: string;
        type?: string;
        owner?: datatype.Reference;
        content_level?: string;
        topic?: string;
        filter_value?: string;
        contact?: string;
        status?: string;
        url?: string;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
