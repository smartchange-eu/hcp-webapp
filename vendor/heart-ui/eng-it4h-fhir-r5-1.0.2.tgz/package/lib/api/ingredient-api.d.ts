import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class IngredientApi extends AbstractApi<model.Ingredient> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param for - The product which this ingredient is a constituent part of
     * @param role - A classification of the ingredient identifying its purpose within the product, e.g. active, inactive
     * @param strength_concentration_quantity - Ingredient concentration strength as quantity
     * @param identifier - An identifier or code by which the ingredient can be referenced
     * @param substance_definition - Reference to a resource (by instance)
     * @param status - The status of this ingredient. Enables tracking the life-cycle of the content
     * @param strength_presentation_quantity - Ingredient presentation strength as quantity
     * @param function - A classification of the ingredient identifying its precise purpose(s) in the drug product. This extends the Ingredient.role to add more detail. Example: Antioxidant, Alkalizing Agent
     * @param substance - Reference to a resource (by instance)
     * @param substance_code - Reference to a concept (by class)
     * @param manufacturer - The organization that manufactures this ingredient
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(forW?: datatype.Reference, role?: string, strength_concentration_quantity?: datatype.Quantity, identifier?: string, substance_definition?: datatype.Reference, status?: string, strength_presentation_quantity?: datatype.Quantity, func?: string, substance?: datatype.Reference, substance_code?: string, manufacturer?: datatype.Reference, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: IngredientApi.SearchParameterIngredient, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace IngredientApi {
    interface SearchParameterIngredient {
        for?: datatype.Reference;
        role?: string;
        strength_concentration_quantity?: datatype.Quantity;
        identifier?: string;
        substance_definition?: datatype.Reference;
        status?: string;
        strength_presentation_quantity?: datatype.Quantity;
        function?: string;
        substance?: datatype.Reference;
        substance_code?: string;
        manufacturer?: datatype.Reference;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
