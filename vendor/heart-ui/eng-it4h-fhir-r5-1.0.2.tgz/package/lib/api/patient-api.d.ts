import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class PatientApi extends AbstractApi<model.Patient> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param death_date - The date of death has been provided and satisfies this search value
     * @param link - All patients/related persons linked to the given patient
     * @param email - Multiple Resources:

* [Patient](patient.html): A value in an email contact
* [Person](person.html): A value in an email contact
* [Practitioner](practitioner.html): A value in an email contact
* [PractitionerRole](practitionerrole.html): A value in an email contact
* [RelatedPerson](relatedperson.html): A value in an email contact

     * @param birthdate - Multiple Resources:

* [Patient](patient.html): The patient's date of birth
* [Person](person.html): The person's date of birth
* [RelatedPerson](relatedperson.html): The Related Person's date of birth

     * @param address - Multiple Resources:

* [Patient](patient.html): A server defined search that may match any of the string fields in the Address, including line, city, district, state, country, postalCode, and/or text
* [Person](person.html): A server defined search that may match any of the string fields in the Address, including line, city, district, state, country, postalCode, and/or text
* [Practitioner](practitioner.html): A server defined search that may match any of the string fields in the Address, including line, city, district, state, country, postalCode, and/or text
* [RelatedPerson](relatedperson.html): A server defined search that may match any of the string fields in the Address, including line, city, district, state, country, postalCode, and/or text

     * @param address_state - Multiple Resources:

* [Patient](patient.html): A state specified in an address
* [Person](person.html): A state specified in an address
* [Practitioner](practitioner.html): A state specified in an address
* [RelatedPerson](relatedperson.html): A state specified in an address

     * @param gender - Multiple Resources:

* [Patient](patient.html): Gender of the patient
* [Person](person.html): The gender of the person
* [Practitioner](practitioner.html): Gender of the practitioner
* [RelatedPerson](relatedperson.html): Gender of the related person

     * @param phone - Multiple Resources:

* [Patient](patient.html): A value in a phone contact
* [Person](person.html): A value in a phone contact
* [Practitioner](practitioner.html): A value in a phone contact
* [PractitionerRole](practitionerrole.html): A value in a phone contact
* [RelatedPerson](relatedperson.html): A value in a phone contact

     * @param phonetic - Multiple Resources:

* [Patient](patient.html): A portion of either family or given name using some kind of phonetic matching algorithm
* [Person](person.html): A portion of name using some kind of phonetic matching algorithm
* [Practitioner](practitioner.html): A portion of either family or given name using some kind of phonetic matching algorithm
* [RelatedPerson](relatedperson.html): A portion of name using some kind of phonetic matching algorithm

     * @param address_city - Multiple Resources:

* [Patient](patient.html): A city specified in an address
* [Person](person.html): A city specified in an address
* [Practitioner](practitioner.html): A city specified in an address
* [RelatedPerson](relatedperson.html): A city specified in an address

     * @param deceased - This patient has been marked as deceased, or has a death date entered
     * @param active - Whether the patient record is active
     * @param family - Multiple Resources:

* [Patient](patient.html): A portion of the family name of the patient
* [Practitioner](practitioner.html): A portion of the family name

     * @param telecom - Multiple Resources:

* [Patient](patient.html): The value in any kind of telecom details of the patient
* [Person](person.html): The value in any kind of contact
* [Practitioner](practitioner.html): The value in any kind of contact
* [PractitionerRole](practitionerrole.html): The value in any kind of contact
* [RelatedPerson](relatedperson.html): The value in any kind of contact

     * @param language_ - Language code (irrespective of use value)
     * @param part_agree - Search by url for a participation agreement, which is stored as an extension referencing a DocumentReference
     * @param address_use - Multiple Resources:

* [Patient](patient.html): A use code specified in an address
* [Person](person.html): A use code specified in an address
* [Practitioner](practitioner.html): A use code specified in an address
* [RelatedPerson](relatedperson.html): A use code specified in an address

     * @param address_postalcode - Multiple Resources:

* [Patient](patient.html): A postalCode specified in an address
* [Person](person.html): A postal code specified in an address
* [Practitioner](practitioner.html): A postalCode specified in an address
* [RelatedPerson](relatedperson.html): A postal code specified in an address

     * @param general_practitioner - Patient's nominated general practitioner, not the organization that manages the record
     * @param organization - The organization that is the custodian of the patient record
     * @param given - Multiple Resources:

* [Patient](patient.html): A portion of the given name of the patient
* [Practitioner](practitioner.html): A portion of the given name

     * @param name - A server defined search that may match any of the string fields in the HumanName, including family, given, prefix, suffix, and/or text
     * @param identifier - A patient identifier
     * @param address_country - Multiple Resources:

* [Patient](patient.html): A country specified in an address
* [Person](person.html): A country specified in an address
* [Practitioner](practitioner.html): A country specified in an address
* [RelatedPerson](relatedperson.html): A country specified in an address

     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(death_date?: Date, link?: datatype.Reference, email?: string, birthdate?: Date, address?: string, address_state?: string, gender?: string, phone?: string, phonetic?: string, address_city?: string, deceased?: string, active?: string, family?: string, telecom?: string, language_?: string, part_agree?: datatype.Reference, address_use?: string, address_postalcode?: string, general_practitioner?: datatype.Reference, organization?: datatype.Reference, given?: string, name?: string, identifier?: string, address_country?: string, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: PatientApi.SearchParameterPatient, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace PatientApi {
    interface SearchParameterPatient {
        death_date?: Date;
        link?: datatype.Reference;
        email?: string;
        birthdate?: Date;
        address?: string;
        address_state?: string;
        gender?: string;
        phone?: string;
        phonetic?: string;
        address_city?: string;
        deceased?: string;
        active?: string;
        family?: string;
        telecom?: string;
        language_?: string;
        part_agree?: datatype.Reference;
        address_use?: string;
        address_postalcode?: string;
        general_practitioner?: datatype.Reference;
        organization?: datatype.Reference;
        given?: string;
        name?: string;
        identifier?: string;
        address_country?: string;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
