import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class OrganizationAffiliationApi extends AbstractApi<model.OrganizationAffiliation> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param phone - A value in a phone contact
     * @param date - The period during which the participatingOrganization is affiliated with the primary organization
     * @param role - Definition of the role the participatingOrganization plays
     * @param endpoint - Technical endpoints providing access to services operated for this role
     * @param primary_organization - The organization that receives the services from the participating organization
     * @param email - A value in an email contact
     * @param specialty - Specific specialty of the participatingOrganization in the context of the role
     * @param identifier - An organization affiliation's Identifier
     * @param location - The location(s) at which the role occurs
     * @param network - Health insurance provider network in which the participatingOrganization provides the role's services (if defined) at the indicated locations (if defined)
     * @param service - Healthcare services provided through the role
     * @param telecom - The value in any kind of contact
     * @param active - Whether this organization affiliation record is in active use
     * @param participating_organization - The organization that provides services to the primary organization
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(phone?: string, date?: Date, role?: string, endpoint?: datatype.Reference, primary_organization?: datatype.Reference, email?: string, specialty?: string, identifier?: string, location?: datatype.Reference, network?: datatype.Reference, service?: datatype.Reference, telecom?: string, active?: string, participating_organization?: datatype.Reference, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: OrganizationAffiliationApi.SearchParameterOrganizationAffiliation, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace OrganizationAffiliationApi {
    interface SearchParameterOrganizationAffiliation {
        phone?: string;
        date?: Date;
        role?: string;
        endpoint?: datatype.Reference;
        primary_organization?: datatype.Reference;
        email?: string;
        specialty?: string;
        identifier?: string;
        location?: datatype.Reference;
        network?: datatype.Reference;
        service?: datatype.Reference;
        telecom?: string;
        active?: string;
        participating_organization?: datatype.Reference;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
