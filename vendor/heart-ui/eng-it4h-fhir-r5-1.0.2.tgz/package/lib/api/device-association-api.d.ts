import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class DeviceAssociationApi extends AbstractApi<model.DeviceAssociation> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param subject - The identity of a patient for whom to list associations
     * @param operator - The identity of a operator for whom to list associations
     * @param status - The status of the device associations
     * @param device - Search for products that match this code
     * @param identifier - The identifier of the device association
     * @param patient - The identity of a patient for whom to list associations
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(subject?: datatype.Reference, operator?: datatype.Reference, status?: string, device?: datatype.Reference, identifier?: string, patient?: datatype.Reference, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: DeviceAssociationApi.SearchParameterDeviceAssociation, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace DeviceAssociationApi {
    interface SearchParameterDeviceAssociation {
        subject?: datatype.Reference;
        operator?: datatype.Reference;
        status?: string;
        device?: datatype.Reference;
        identifier?: string;
        patient?: datatype.Reference;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
