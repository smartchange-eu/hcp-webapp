import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class DeviceApi extends AbstractApi<model.Device> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param device_name - A server defined search that may match any of the string fields in Device.name or Device.type.
     * @param udi_carrier - UDI Barcode (RFID or other technology) string in *HRF* format.
     * @param specification - The standards, specifications, or formal guidances.
     * @param model - The model of the device
     * @param version - The specific version of the device
     * @param parent - The parent device
     * @param type - The type of the device
     * @param code_value_concept - Code and value parameter pair
     * @param biological_source_event - The biological source for the device
     * @param manufacture_date - The manufacture date of the device
     * @param url - Network address to contact device
     * @param manufacturer - The manufacturer of the device
     * @param serial_number - The serial number of the device
     * @param lot_number - The lot number of the device
     * @param organization - The organization responsible for the device
     * @param location - A location, where the resource is found
     * @param definition - The definition / type of the device
     * @param identifier - Instance id from manufacturer, owner, and others
     * @param udi_di - The udi Device Identifier (DI)
     * @param specification_version - A composite of both specification and version
     * @param status - active | inactive | entered-in-error | unknown
     * @param code - The definition / type of the device (code)
     * @param expiration_date - The expiration date of the device
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(device_name?: string, udi_carrier?: string, specification?: string, model?: string, version?: string, parent?: datatype.Reference, type?: string, code_value_concept?: any, biological_source_event?: string, manufacture_date?: Date, url?: string, manufacturer?: string, serial_number?: string, lot_number?: string, organization?: datatype.Reference, location?: datatype.Reference, definition?: datatype.Reference, identifier?: string, udi_di?: string, specification_version?: any, status?: string, code?: string, expiration_date?: Date, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: DeviceApi.SearchParameterDevice, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace DeviceApi {
    interface SearchParameterDevice {
        device_name?: string;
        udi_carrier?: string;
        specification?: string;
        model?: string;
        version?: string;
        parent?: datatype.Reference;
        type?: string;
        code_value_concept?: any;
        biological_source_event?: string;
        manufacture_date?: Date;
        url?: string;
        manufacturer?: string;
        serial_number?: string;
        lot_number?: string;
        organization?: datatype.Reference;
        location?: datatype.Reference;
        definition?: datatype.Reference;
        identifier?: string;
        udi_di?: string;
        specification_version?: any;
        status?: string;
        code?: string;
        expiration_date?: Date;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
