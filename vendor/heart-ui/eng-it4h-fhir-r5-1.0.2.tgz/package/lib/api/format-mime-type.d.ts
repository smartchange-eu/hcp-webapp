export declare enum FormatMimeType {
    JSON = 0,
    XML = 1
}
export declare module FormatMimeType {
    function fromString(str: string): FormatMimeType;
    function toString(mt: FormatMimeType): string;
}
