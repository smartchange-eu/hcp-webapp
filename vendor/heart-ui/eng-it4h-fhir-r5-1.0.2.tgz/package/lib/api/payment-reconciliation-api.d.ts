import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class PaymentReconciliationApi extends AbstractApi<model.PaymentReconciliation> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param allocation_encounter - The encounter to which payment or adjustment was applied.
     * @param requestor - The reference to the provider who submitted the claim
     * @param disposition - The contents of the disposition message
     * @param allocation_account - The account to which payment or adjustment was applied.
     * @param identifier - The business identifier of the ExplanationOfBenefit
     * @param payment_issuer - The organization which generated this resource
     * @param request - The reference to the claim
     * @param created - The creation date
     * @param status - The status of the payment reconciliation
     * @param outcome - The processing outcome
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(allocation_encounter?: datatype.Reference, requestor?: datatype.Reference, disposition?: string, allocation_account?: datatype.Reference, identifier?: string, payment_issuer?: datatype.Reference, request?: datatype.Reference, created?: Date, status?: string, outcome?: string, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: PaymentReconciliationApi.SearchParameterPaymentReconciliation, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace PaymentReconciliationApi {
    interface SearchParameterPaymentReconciliation {
        allocation_encounter?: datatype.Reference;
        requestor?: datatype.Reference;
        disposition?: string;
        allocation_account?: datatype.Reference;
        identifier?: string;
        payment_issuer?: datatype.Reference;
        request?: datatype.Reference;
        created?: Date;
        status?: string;
        outcome?: string;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
