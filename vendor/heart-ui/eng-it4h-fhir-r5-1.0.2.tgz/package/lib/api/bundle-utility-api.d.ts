import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AbstractApi } from './abstract-api';
import { ExceptionHandler } from '../exception-handler.model';
import { Bundle } from '../datatype/bundle';
import { Reference } from '../datatype/reference';
import { DomainResource } from '../model/domain-resource';
export declare class BundleUtilityApi extends AbstractApi<Bundle> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    search(_parameter: any, _extraHttpRequestParams?: any): Observable<Bundle>;
    /**
     * @param link
     */
    getPages(link: string, extraHttpRequestParams?: Map<string, any>): Observable<Bundle>;
    /**
     * Unify all the paged entries returning a new un-paged Bundle
     * @param bundle
     */
    mergeBundle(bundle: Bundle): Promise<Bundle>;
    mergeBundleIncrementally(bundle: Bundle, callback: (allItems: (DomainResource | Reference)[], newItems?: (DomainResource | Reference)[]) => void): Promise<void>;
    nextBundlePage(bundle: Bundle): Observable<Bundle>;
    prevBundlePage(bundle: Bundle): Observable<Bundle>;
}
