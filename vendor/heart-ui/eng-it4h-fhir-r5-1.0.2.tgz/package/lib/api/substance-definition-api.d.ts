import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class SubstanceDefinitionApi extends AbstractApi<model.SubstanceDefinition> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param identifier - Identifier by which this substance is known
     * @param name - The actual name
     * @param domain - If the substance applies to only human or veterinary use
     * @param code - The specific code
     * @param classification - High or low level categorization, e.g. polymer vs. nucleic acid or linear vs. branch chain
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(identifier?: string, name?: string, domain?: string, code?: string, classification?: string, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: SubstanceDefinitionApi.SearchParameterSubstanceDefinition, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace SubstanceDefinitionApi {
    interface SearchParameterSubstanceDefinition {
        identifier?: string;
        name?: string;
        domain?: string;
        code?: string;
        classification?: string;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
