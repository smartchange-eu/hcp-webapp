import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class PractitionerRoleApi extends AbstractApi<model.PractitionerRole> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param practitioner - Practitioner that is able to provide the defined services for the organization
     * @param telecom - Multiple Resources:

* [Patient](patient.html): The value in any kind of telecom details of the patient
* [Person](person.html): The value in any kind of contact
* [Practitioner](practitioner.html): The value in any kind of contact
* [PractitionerRole](practitionerrole.html): The value in any kind of contact
* [RelatedPerson](relatedperson.html): The value in any kind of contact

     * @param active - Whether this practitioner role record is in active use
     * @param identifier - A practitioner's Identifier
     * @param communication - One of the languages that the practitioner can communicate with
     * @param organization - The identity of the organization the practitioner represents / acts on behalf of
     * @param service - The list of healthcare services that this worker provides for this role's Organization/Location(s)
     * @param location - One of the locations at which this practitioner provides care
     * @param endpoint - Technical endpoints providing access to services operated for the practitioner with this role
     * @param specialty - The practitioner has this specialty at an organization
     * @param email - Multiple Resources:

* [Patient](patient.html): A value in an email contact
* [Person](person.html): A value in an email contact
* [Practitioner](practitioner.html): A value in an email contact
* [PractitionerRole](practitionerrole.html): A value in an email contact
* [RelatedPerson](relatedperson.html): A value in an email contact

     * @param phone - Multiple Resources:

* [Patient](patient.html): A value in a phone contact
* [Person](person.html): A value in a phone contact
* [Practitioner](practitioner.html): A value in a phone contact
* [PractitionerRole](practitionerrole.html): A value in a phone contact
* [RelatedPerson](relatedperson.html): A value in a phone contact

     * @param characteristic - One of the PractitionerRole's characteristics
     * @param role - The practitioner can perform this role at for the organization
     * @param date - The period during which the practitioner is authorized to perform in these role(s)
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(practitioner?: datatype.Reference, telecom?: string, active?: string, identifier?: string, communication?: string, organization?: datatype.Reference, service?: datatype.Reference, location?: datatype.Reference, endpoint?: datatype.Reference, specialty?: string, email?: string, phone?: string, characteristic?: string, role?: string, date?: Date, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: PractitionerRoleApi.SearchParameterPractitionerRole, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace PractitionerRoleApi {
    interface SearchParameterPractitionerRole {
        practitioner?: datatype.Reference;
        telecom?: string;
        active?: string;
        identifier?: string;
        communication?: string;
        organization?: datatype.Reference;
        service?: datatype.Reference;
        location?: datatype.Reference;
        endpoint?: datatype.Reference;
        specialty?: string;
        email?: string;
        phone?: string;
        characteristic?: string;
        role?: string;
        date?: Date;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
