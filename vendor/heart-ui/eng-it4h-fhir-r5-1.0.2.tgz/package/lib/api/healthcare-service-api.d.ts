import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class HealthcareServiceApi extends AbstractApi<model.HealthcareService> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param active - The Healthcare Service is currently marked as active
     * @param service_type - The type of service provided by this healthcare service
     * @param organization - The organization that provides this Healthcare Service
     * @param location - The location of the Healthcare Service
     * @param identifier - External identifiers for this item
     * @param name - A portion of the Healthcare service name
     * @param communication - Languages that are available at this service
     * @param specialty - The specialty of the service provided by this healthcare service
     * @param endpoint - Technical endpoints providing access to electronic services operated for the healthcare service
     * @param offered_in - The service within which this service is offered
     * @param service_category - Service Category of the Healthcare Service
     * @param program - One of the Programs supported by this HealthcareService
     * @param characteristic - One of the HealthcareService's characteristics
     * @param coverage_area - Location(s) service is intended for/available to
     * @param eligibility - One of the HealthcareService's eligibility requirements
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(active?: string, service_type?: string, organization?: datatype.Reference, location?: datatype.Reference, identifier?: string, name?: string, communication?: string, specialty?: string, endpoint?: datatype.Reference, offered_in?: datatype.Reference, service_category?: string, program?: string, characteristic?: string, coverage_area?: datatype.Reference, eligibility?: string, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: HealthcareServiceApi.SearchParameterHealthcareService, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace HealthcareServiceApi {
    interface SearchParameterHealthcareService {
        active?: string;
        service_type?: string;
        organization?: datatype.Reference;
        location?: datatype.Reference;
        identifier?: string;
        name?: string;
        communication?: string;
        specialty?: string;
        endpoint?: datatype.Reference;
        offered_in?: datatype.Reference;
        service_category?: string;
        program?: string;
        characteristic?: string;
        coverage_area?: datatype.Reference;
        eligibility?: string;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
