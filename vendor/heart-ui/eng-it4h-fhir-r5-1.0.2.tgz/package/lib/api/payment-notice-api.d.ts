import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class PaymentNoticeApi extends AbstractApi<model.PaymentNotice> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param identifier - The business identifier of the notice
     * @param payment_status - The type of payment notice
     * @param request - The Claim
     * @param reporter - The reference to the reporter
     * @param response - The ClaimResponse
     * @param created - Creation date for the notice
     * @param status - The status of the payment notice
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(identifier?: string, payment_status?: string, request?: datatype.Reference, reporter?: datatype.Reference, response?: datatype.Reference, created?: Date, status?: string, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: PaymentNoticeApi.SearchParameterPaymentNotice, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace PaymentNoticeApi {
    interface SearchParameterPaymentNotice {
        identifier?: string;
        payment_status?: string;
        request?: datatype.Reference;
        reporter?: datatype.Reference;
        response?: datatype.Reference;
        created?: Date;
        status?: string;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
