import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class SubstanceApi extends AbstractApi<model.Substance> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param identifier - Unique identifier for the substance
     * @param substance_reference - A component of the substance
     * @param category - The category of the substance
     * @param quantity - Amount of substance in the package
     * @param code_reference - A reference to the defining substance
     * @param code - The code of the substance or ingredient
     * @param expiry - Expiry date of package or container of substance
     * @param status - active | inactive | entered-in-error
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(identifier?: string, substance_reference?: datatype.Reference, category?: string, quantity?: datatype.Quantity, code_reference?: datatype.Reference, code?: string, expiry?: Date, status?: string, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: SubstanceApi.SearchParameterSubstance, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace SubstanceApi {
    interface SearchParameterSubstance {
        identifier?: string;
        substance_reference?: datatype.Reference;
        category?: string;
        quantity?: datatype.Quantity;
        code_reference?: datatype.Reference;
        code?: string;
        expiry?: Date;
        status?: string;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
