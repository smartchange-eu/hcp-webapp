import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class TestReportApi extends AbstractApi<model.TestReport> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param participant - The reference to a participant in the test execution
     * @param tester - The name of the testing organization
     * @param status - The current status of the test report
     * @param result - The result disposition of the test execution
     * @param testscript - The test script executed to produce this report
     * @param identifier - An external identifier for the test report
     * @param issued - The test report generation date
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(participant?: string, tester?: string, status?: string, result?: string, testscript?: datatype.Reference, identifier?: string, issued?: Date, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: TestReportApi.SearchParameterTestReport, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace TestReportApi {
    interface SearchParameterTestReport {
        participant?: string;
        tester?: string;
        status?: string;
        result?: string;
        testscript?: datatype.Reference;
        identifier?: string;
        issued?: Date;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
