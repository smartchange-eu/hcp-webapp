import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class ResearchStudyApi extends AbstractApi<model.ResearchStudy> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param description - Detailed narrative of the study
     * @param eligibility - Inclusion and exclusion criteria
     * @param protocol - Steps followed in executing study
     * @param focus_reference - Drugs, devices, etc. under study, as a reference
     * @param date - When the study began and ended
     * @param objective_description - Free text description of the objective of the study
     * @param recruitment_actual - Actual number of participants enrolled in study across all groups
     * @param focus_code - Drugs, devices, etc. under study, as a code
     * @param keyword - Used to search for the study
     * @param name - Name for this study
     * @param identifier - Business Identifier for study
     * @param objective_type - The kind of study objective
     * @param title - The human readable name of the research study
     * @param phase - The stage in the progression of a study
     * @param classifier - Classification for the study
     * @param site - Facility where study activities are conducted
     * @param recruitment_target - Target number of participants enrolled in study across all groups
     * @param study_design - Classifications of the study design characteristics
     * @param region - Geographic area for the study
     * @param condition - Condition being studied
     * @param part_of - Part of larger study
     * @param status - active | active-but-not-recruiting | administratively-completed | approved | closed-to-accrual | closed-to-accrual-and-intervention | completed | disapproved | enrolling-by-invitation | in-review | not-yet-recruiting | recruiting | temporarily-closed-to-accrual | temporarily-closed-to-accrual-and-intervention | terminated | withdrawn
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(description?: string, eligibility?: datatype.Reference, protocol?: datatype.Reference, focus_reference?: datatype.Reference, date?: Date, objective_description?: string, recruitment_actual?: number, focus_code?: string, keyword?: string, name?: string, identifier?: string, objective_type?: string, title?: string, phase?: string, classifier?: string, site?: datatype.Reference, recruitment_target?: number, study_design?: string, region?: string, condition?: string, part_of?: datatype.Reference, status?: string, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: ResearchStudyApi.SearchParameterResearchStudy, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace ResearchStudyApi {
    interface SearchParameterResearchStudy {
        description?: string;
        eligibility?: datatype.Reference;
        protocol?: datatype.Reference;
        focus_reference?: datatype.Reference;
        date?: Date;
        objective_description?: string;
        recruitment_actual?: number;
        focus_code?: string;
        keyword?: string;
        name?: string;
        identifier?: string;
        objective_type?: string;
        title?: string;
        phase?: string;
        classifier?: string;
        site?: datatype.Reference;
        recruitment_target?: number;
        study_design?: string;
        region?: string;
        condition?: string;
        part_of?: datatype.Reference;
        status?: string;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
