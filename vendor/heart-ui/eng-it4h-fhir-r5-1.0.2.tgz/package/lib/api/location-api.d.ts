import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class LocationApi extends AbstractApi<model.Location> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param endpoint - Technical endpoints providing access to services operated for the location
     * @param contains - Select locations that contain the specified co-ordinates
     * @param partof - A location of which this location is a part
     * @param characteristic - One of the Location's characteristics
     * @param address_city - A city specified in an address
     * @param address - A (part of the) address of the location
     * @param type - A code for the type of location
     * @param address_state - A state specified in an address
     * @param status - Searches for locations with a specific kind of status
     * @param operational_status - Searches for locations (typically bed/room) that have an operational status (e.g. contaminated, housekeeping)
     * @param address_use - A use code specified in an address
     * @param organization - Searches for locations that are managed by the provided organization
     * @param address_postalcode - A postal code specified in an address
     * @param near - Search for locations where the location.position is near to, or within a specified distance of, the provided coordinates expressed as [latitude]|[longitude]|[distance]|[units] (using the WGS84 datum, see notes).

Servers which support the near parameter SHALL support the unit string 'km' for kilometers and SHOULD support '[mi_us]' for miles, support for other units is optional. If the units are omitted, then kms should be assumed. If the distance is omitted, then the server can use its own discretion as to what distances should be considered near (and units are irrelevant).

If the server is unable to understand the units (and does support the near search parameter), it MIGHT return an OperationOutcome and fail the search with a http status 400 BadRequest. If the server does not support the near parameter, the parameter MIGHT report the unused parameter in a bundled OperationOutcome and still perform the search ignoring the near parameter.

Note: The algorithm to determine the distance is not defined by the specification, and systems might have different engines that calculate things differently. They could consider geographic point to point, or path via road, or including current traffic conditions, or just simple neighboring postcodes/localities if that's all it had access to.
     * @param name - A portion of the location's name or alias
     * @param address_country - A country specified in an address
     * @param identifier - An identifier for the location
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(endpoint?: datatype.Reference, contains?: string, partof?: datatype.Reference, characteristic?: string, address_city?: string, address?: string, type?: string, address_state?: string, status?: string, operational_status?: string, address_use?: string, organization?: datatype.Reference, address_postalcode?: string, near?: string, name?: string, address_country?: string, identifier?: string, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: LocationApi.SearchParameterLocation, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace LocationApi {
    interface SearchParameterLocation {
        endpoint?: datatype.Reference;
        contains?: string;
        partof?: datatype.Reference;
        characteristic?: string;
        address_city?: string;
        address?: string;
        type?: string;
        address_state?: string;
        status?: string;
        operational_status?: string;
        address_use?: string;
        organization?: datatype.Reference;
        address_postalcode?: string;
        near?: string;
        name?: string;
        address_country?: string;
        identifier?: string;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
