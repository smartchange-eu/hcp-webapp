import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class SlotApi extends AbstractApi<model.Slot> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param status - The free/busy status of the appointment
     * @param specialty - The specialty of a practitioner that would be required to perform the service requested in this appointment
     * @param start - Appointment date/time.
     * @param service_type - The type (by coding) of appointments that can be booked into the slot
     * @param service_category - A broad categorization of the service that is to be performed during this appointment
     * @param schedule - The Schedule Resource that we are seeking a slot within
     * @param service_type_reference - The type (by HealthcareService) of appointments that can be booked into the slot
     * @param appointment_type - The style of appointment or patient that may be booked in the slot (not service type)
     * @param identifier - A Slot Identifier
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(status?: string, specialty?: string, start?: Date, service_type?: string, service_category?: string, schedule?: datatype.Reference, service_type_reference?: datatype.Reference, appointment_type?: string, identifier?: string, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: SlotApi.SearchParameterSlot, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace SlotApi {
    interface SearchParameterSlot {
        status?: string;
        specialty?: string;
        start?: Date;
        service_type?: string;
        service_category?: string;
        schedule?: datatype.Reference;
        service_type_reference?: datatype.Reference;
        appointment_type?: string;
        identifier?: string;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
