import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class BiologicallyDerivedProductApi extends AbstractApi<model.BiologicallyDerivedProduct> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param product_status - Whether the product is currently available.
     * @param biological_source_event - The biological source for the biologically derived product
     * @param code - A code that identifies the kind of this biologically derived product (SNOMED CT code).
     * @param serial_number - Identifier
     * @param request - Procedure request to obtain this biologically derived product.
     * @param identifier - Identifier
     * @param product_category - Broad category of this product.
     * @param collector - Procedure request to obtain this biologically derived product.
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(product_status?: string, biological_source_event?: string, code?: string, serial_number?: string, request?: datatype.Reference, identifier?: string, product_category?: string, collector?: datatype.Reference, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: BiologicallyDerivedProductApi.SearchParameterBiologicallyDerivedProduct, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace BiologicallyDerivedProductApi {
    interface SearchParameterBiologicallyDerivedProduct {
        product_status?: string;
        biological_source_event?: string;
        code?: string;
        serial_number?: string;
        request?: datatype.Reference;
        identifier?: string;
        product_category?: string;
        collector?: datatype.Reference;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
