import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class ScheduleApi extends AbstractApi<model.Schedule> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param service_type - The type (by coding) of appointments that can be booked into associated slot(s)
     * @param service_category - High-level category
     * @param active - Is the schedule in active use
     * @param specialty - Type of specialty needed
     * @param identifier - A Schedule Identifier
     * @param name - A portion of the Schedule name
     * @param actor - The individual(HealthcareService, Practitioner, Location, ...) to find a Schedule for
     * @param service_type_reference - The type (by HealthcareService) of appointments that can be booked into associated slot(s)
     * @param date - Search for Schedule resources that have a period that contains this date specified
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(service_type?: string, service_category?: string, active?: string, specialty?: string, identifier?: string, name?: string, actor?: datatype.Reference, service_type_reference?: datatype.Reference, date?: Date, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: ScheduleApi.SearchParameterSchedule, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace ScheduleApi {
    interface SearchParameterSchedule {
        service_type?: string;
        service_category?: string;
        active?: string;
        specialty?: string;
        identifier?: string;
        name?: string;
        actor?: datatype.Reference;
        service_type_reference?: datatype.Reference;
        date?: Date;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
