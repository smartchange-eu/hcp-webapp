import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class InsurancePlanApi extends AbstractApi<model.InsurancePlan> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param address_city - A city specified in an address
     * @param phonetic - A portion of the organization's name using some kind of phonetic matching algorithm
     * @param address_state - A state specified in an address
     * @param address - A server defined search that may match any of the string fields in the Address, including line, city, district, state, country, postalCode, and/or text
     * @param type - A code for the type of organization
     * @param owned_by - An organization of which this organization forms a part
     * @param endpoint - Technical endpoint
     * @param address_country - A country specified in an address
     * @param identifier - Any identifier for the organization (not the accreditation issuer's identifier)
     * @param name - A portion of the organization's name or alias
     * @param address_postalcode - A postal code specified in an address
     * @param administered_by - Product administrator
     * @param address_use - A use code specified in an address
     * @param status - Is the Organization record active
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(address_city?: string, phonetic?: string, address_state?: string, address?: string, type?: string, owned_by?: datatype.Reference, endpoint?: datatype.Reference, address_country?: string, identifier?: string, name?: string, address_postalcode?: string, administered_by?: datatype.Reference, address_use?: string, status?: string, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: InsurancePlanApi.SearchParameterInsurancePlan, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace InsurancePlanApi {
    interface SearchParameterInsurancePlan {
        address_city?: string;
        phonetic?: string;
        address_state?: string;
        address?: string;
        type?: string;
        owned_by?: datatype.Reference;
        endpoint?: datatype.Reference;
        address_country?: string;
        identifier?: string;
        name?: string;
        address_postalcode?: string;
        administered_by?: datatype.Reference;
        address_use?: string;
        status?: string;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
