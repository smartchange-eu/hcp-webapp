import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class PackagedProductDefinitionApi extends AbstractApi<model.PackagedProductDefinition> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param biological - A biologically derived product within this packaged product
     * @param medication - A manufactured item of medication within this packaged product
     * @param status - The status within the lifecycle of this item. A high level status, this is not intended to duplicate details carried elsewhere such as legal status, or authorization or marketing status
     * @param device - A device within this packaged product
     * @param identifier - Unique identifier
     * @param manufactured_item - A manufactured item of medication within this packaged product
     * @param contained_item - Any of the contained items within this packaged product
     * @param name - A name for this package. Typically what it would be listed as in a drug formulary or catalogue, inventory etc.
     * @param package_for - The product that this is a pack for
     * @param package - A complete packaged product within this packaged product
     * @param nutrition - A nutrition product within this packaged product
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(biological?: datatype.Reference, medication?: datatype.Reference, status?: string, device?: datatype.Reference, identifier?: string, manufactured_item?: datatype.Reference, contained_item?: datatype.Reference, name?: string, package_for?: datatype.Reference, pkg?: datatype.Reference, nutrition?: datatype.Reference, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: PackagedProductDefinitionApi.SearchParameterPackagedProductDefinition, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace PackagedProductDefinitionApi {
    interface SearchParameterPackagedProductDefinition {
        biological?: datatype.Reference;
        medication?: datatype.Reference;
        status?: string;
        device?: datatype.Reference;
        identifier?: string;
        manufactured_item?: datatype.Reference;
        contained_item?: datatype.Reference;
        name?: string;
        package_for?: datatype.Reference;
        package?: datatype.Reference;
        nutrition?: datatype.Reference;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
