import * as datatype from './../datatype';
import * as model from './../model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExceptionHandler } from '../exception-handler.model';
import { AbstractApi } from './abstract-api';
import { FormatMimeType } from './format-mime-type';
export declare class ClinicalUseDefinitionApi extends AbstractApi<model.ClinicalUseDefinition> {
    protected http: HttpClient;
    constructor(http: HttpClient, basePath?: string, token?: string, exceptionHandler?: ExceptionHandler);
    /**
     * @param contraindication - The situation that is being documented as contraindicating against this item, as a code
     * @param indication - The situation that is being documented as an indicaton for this item, as a code
     * @param indication_reference - The situation that is being documented as an indicaton for this item, as a reference
     * @param type - indication | contraindication | interaction | undesirable-effect | warning
     * @param product - The medicinal product for which this is a clinical usage issue
     * @param contraindication_reference - The situation that is being documented as contraindicating against this item, as a reference
     * @param interaction - The type of the interaction e.g. drug-drug interaction, drug-food interaction, drug-lab test interaction
     * @param effect - The situation in which the undesirable effect may manifest, as a code
     * @param identifier - Business identifier for this issue
     * @param status - Whether this is a current issue or one that has been retired etc.
     * @param effect_reference - The situation in which the undesirable effect may manifest, as a reference
     * @param subject - The resource for which this is a clinical usage issue
     * @param id The ID of the resource (not a full URL)
     * @param _lastUpdated (Date[]) Date last updated. Server has discretion on the boundary precision. It can be used to select resources based on the last time they were changed. It is used to express the period for which the result are expected to have been edited
     * @param _includes (string[])
     * @param _includes_recurse (string[])
     * @param _revinclude (string[])
     * @param format (string)
     * @param extraHttpRequestParams: e.g. '_query: string', '_text: string', '_content: string', '_list: string', '_profile: string', '_security: string', '_tag: string'
     */
    searchWithParams(contraindication?: string, indication?: string, indication_reference?: datatype.Reference, type?: string, product?: datatype.Reference, contraindication_reference?: datatype.Reference, interaction?: string, effect?: string, identifier?: string, status?: string, effect_reference?: datatype.Reference, subject?: datatype.Reference, id?: string, _lastUpdated?: Date[], _includes?: string[], _includes_recurse?: string[], _revinclude?: string[], format?: FormatMimeType, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
    search(parameter: ClinicalUseDefinitionApi.SearchParameterClinicalUseDefinition, extraHttpRequestParams?: Map<string, any>): Observable<datatype.Bundle>;
}
export declare namespace ClinicalUseDefinitionApi {
    interface SearchParameterClinicalUseDefinition {
        contraindication?: string;
        indication?: string;
        indication_reference?: datatype.Reference;
        type?: string;
        product?: datatype.Reference;
        contraindication_reference?: datatype.Reference;
        interaction?: string;
        effect?: string;
        identifier?: string;
        status?: string;
        effect_reference?: datatype.Reference;
        subject?: datatype.Reference;
        id?: string;
        _lastUpdated?: Date[];
        format?: FormatMimeType;
        _includes?: string[];
        _includes_recurse?: string[];
        _revinclude?: string[];
    }
}
