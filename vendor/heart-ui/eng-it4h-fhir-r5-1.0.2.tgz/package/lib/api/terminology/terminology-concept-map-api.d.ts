import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { Bundle, CodeableConcept, Coding, Quantity } from "../../datatype";
import { ConceptMap } from "../../model";
import { ConceptMapApi } from "../../api";
import { TerminologySearchParams } from "./terminology-search-params.model";
import { Parameters } from "./parameters.model";
import { ExceptionHandler } from "../../exception-handler.model";
export declare class TerminologyConceptMapApi {
    private http;
    private basePath;
    private api;
    private exceptionHandler?;
    constructor(http: HttpClient, basePath: string, api: ConceptMapApi, exceptionHandler?: ExceptionHandler);
    read(id: string): Observable<ConceptMap>;
    search(params?: TerminologySearchParams): Observable<Bundle>;
    translate(params: {
        url?: string;
        conceptMap?: ConceptMap;
        conceptMapVersion?: string;
        sourceCode?: string;
        system?: string;
        version?: string;
        sourceScope?: string;
        sourceCoding?: Coding;
        sourceCodeableConcept?: CodeableConcept;
        targetCode?: string;
        targetCoding?: string;
        targetCodeableConcept?: string;
        targetScope?: string;
        targetSystem?: string;
        dependency?: any[];
        dependencyAttribute?: string;
        dependencyValue?: Coding | string | boolean | Quantity;
    }): Observable<TerminologyConceptMapApi.TranslateResult>;
    translateByInstance(id: string, params: {
        sourceCode?: string;
        system?: string;
        version?: string;
        sourceScope?: string;
        sourceCoding?: Coding;
        sourceCodeableConcept?: CodeableConcept;
        targetCode?: string;
        targetCoding?: string;
        targetCodeableConcept?: string;
        targetScope?: string;
        targetSystem?: string;
        dependency?: any[];
        dependencyAttribute?: string;
        dependencyValue?: Coding | string | boolean | Quantity;
    }): Observable<TerminologyConceptMapApi.TranslateResult>;
    /***********************************************
     * PRIVATE METHODS
     ***********************************************/
    _translate(params: {
        url?: string;
        conceptMap?: ConceptMap;
        conceptMapVersion?: string;
        sourceCode?: string;
        system?: string;
        version?: string;
        sourceScope?: string;
        sourceCoding?: Coding;
        sourceCodeableConcept?: CodeableConcept;
        targetCode?: string;
        targetCoding?: string;
        targetCodeableConcept?: string;
        targetScope?: string;
        targetSystem?: string;
        dependency?: any[];
        dependencyAttribute?: string;
        dependencyValue?: Coding | string | boolean | Quantity;
    }, id?: string): Observable<TerminologyConceptMapApi.TranslateResult>;
}
export declare namespace TerminologyConceptMapApi {
    interface TranslateResult {
        result: boolean;
        message?: string;
        match?: {
            relationship?: string;
            concept?: Coding;
            property?: {
                uri?: string;
                value?: Coding | string | number | boolean | Date;
            }[];
            product?: {
                attribute: string;
                value: Coding | string | boolean | Quantity;
            }[];
            dependsOn: {
                attribute: string;
                value: Coding | string | boolean | Date | number;
            }[];
            originMap?: string;
        }[];
    }
    namespace TranslateResult {
        function deserialize(parameters: Parameters): TerminologyConceptMapApi.TranslateResult;
    }
}
