import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { Bundle, CodeableConcept, Coding } from "../../datatype";
import { OperationOutcome, ValueSet } from "../../model";
import { ValueSetApi } from "../../api";
import { ExceptionHandler } from "../../exception-handler.model";
import { TerminologySearchParams } from "./terminology-search-params.model";
import { Parameters } from "./parameters.model";
export declare class TerminologyValueSetApi {
    private http;
    private basePath;
    private api;
    private exceptionHandler?;
    constructor(http: HttpClient, basePath: string, api: ValueSetApi, exceptionHandler?: ExceptionHandler);
    read(id: string): Observable<ValueSet>;
    search(params?: TerminologySearchParams): Observable<Bundle>;
    expand(params: {
        url?: string;
        valueSet?: ValueSet;
        valueSetVersion?: string;
        context?: string;
        contextDirection?: string;
        filter?: string;
        date?: Date;
        offset?: number;
        count?: number;
        includeDesignations?: boolean;
        designation?: string[];
        includeDefinition?: boolean;
        activeOnly?: boolean;
        useSupplement?: string[];
        excludeNested?: boolean;
        excludeNotForUI?: boolean;
        excludePostCoordinated?: boolean;
        displayLanguage?: string;
        property?: string[];
        excludeSystem?: string[];
        systemVersion?: string[];
        checkSystemVersion?: string[];
        forceSystemVersion?: string[];
    }): Observable<ValueSet>;
    expandByInstance(id: string, params: {
        context?: string;
        contextDirection?: string;
        filter?: string;
        date?: Date;
        offset?: number;
        count?: number;
        includeDesignations?: boolean;
        designation?: string[];
        includeDefinition?: boolean;
        activeOnly?: boolean;
        useSupplement?: string[];
        excludeNested?: boolean;
        excludeNotForUI?: boolean;
        excludePostCoordinated?: boolean;
        displayLanguage?: string;
        property?: string[];
        excludeSystem?: string[];
        systemVersion?: string[];
        checkSystemVersion?: string[];
        forceSystemVersion?: string[];
    }): Observable<ValueSet>;
    validateCode(params: {
        url?: string;
        context?: string;
        valueSet?: ValueSet;
        valueSetVersion?: string;
        code?: string;
        system?: string;
        systemVersion?: string;
        display?: string;
        coding?: Coding;
        codeableConcept?: CodeableConcept;
        date?: Date;
        abstract?: boolean;
        displayLanguage?: string;
        useSupplement?: string[];
    }): Observable<TerminologyValueSetApi.ValidateCodeResult>;
    validateCodeByInstance(id: string, params: {
        context?: string;
        code?: string;
        system?: string;
        systemVersion?: string;
        display?: string;
        coding?: Coding;
        codeableConcept?: CodeableConcept;
        date?: Date;
        abstract?: boolean;
        displayLanguage?: string;
        useSupplement?: string[];
    }): Observable<TerminologyValueSetApi.ValidateCodeResult>;
    /***********************************************
     * PRIVATE METHODS
     ***********************************************/
    private _expand;
    private _validateCode;
}
export declare namespace TerminologyValueSetApi {
    namespace ExpandResult {
    }
    interface ValidateCodeResult {
        result: boolean;
        message?: string;
        display?: string;
        code?: string;
        system?: string;
        version?: string;
        codeableConcept?: CodeableConcept;
        issues?: OperationOutcome;
    }
    namespace ValidateCodeResult {
        function deserialize(parameters: Parameters): TerminologyValueSetApi.ValidateCodeResult;
    }
}
