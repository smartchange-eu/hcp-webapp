import { HttpClient } from "@angular/common/http";
import { ExceptionHandler } from "../../exception-handler.model";
import { TerminologyCodeSystemApi } from "./terminology-code-system-api";
import { TerminologyConceptMapApi } from "./terminology-concept-map-api";
import { TerminologyValueSetApi } from "./terminology-valueset-api";
export declare class TerminologyServiceApi {
    private http;
    private basePath;
    private exceptionHandler;
    readonly codeSystem: TerminologyCodeSystemApi;
    readonly valueSet: TerminologyValueSetApi;
    readonly conceptMap: TerminologyConceptMapApi;
    constructor(http: HttpClient, basePath: string, exceptionHandler?: ExceptionHandler);
    private static handleError;
}
