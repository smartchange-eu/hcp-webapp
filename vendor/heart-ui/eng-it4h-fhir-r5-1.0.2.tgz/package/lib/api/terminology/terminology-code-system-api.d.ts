import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { Bundle, CodeableConcept, Coding } from "../../datatype";
import { CodeSystem, OperationOutcome } from "../../model";
import { CodeSystemApi } from "../../api";
import { TerminologySearchParams } from "./terminology-search-params.model";
import { ExceptionHandler } from "../../exception-handler.model";
import { Parameters } from "./parameters.model";
export declare class TerminologyCodeSystemApi {
    private http;
    private basePath;
    private api;
    private exceptionHandler?;
    constructor(http: HttpClient, basePath: string, api: CodeSystemApi, exceptionHandler?: ExceptionHandler);
    read(id: string): Observable<CodeSystem>;
    search(params?: TerminologySearchParams): Observable<Bundle>;
    lookup(params: {
        code?: string;
        system: string;
        version?: string;
        coding?: Coding;
        date?: Date;
        displayLanguage?: string;
        property?: string[];
        useSupplement?: string[];
    }): Observable<TerminologyCodeSystemApi.LookupResult>;
    lookupByInstance(id: string, params: {
        code?: string;
        coding?: Coding;
        date?: Date;
        displayLanguage?: string;
        property?: string[];
        useSupplement?: string[];
    }): Observable<TerminologyCodeSystemApi.LookupResult>;
    validateCode(params: {
        url?: string;
        codeSystem: CodeSystem;
        code?: string;
        version?: string;
        display?: string;
        coding?: Coding;
        codeableConcept?: CodeableConcept;
        date?: Date;
        abstract?: boolean;
        displayLanguage?: string;
    }): Observable<TerminologyCodeSystemApi.ValidateCodeResult>;
    validateCodeByInstance(id: string, params: {
        code?: string;
        display?: string;
        coding?: Coding;
        codeableConcept?: CodeableConcept;
        date?: Date;
        abstract?: boolean;
        displayLanguage?: string;
    }): Observable<TerminologyCodeSystemApi.ValidateCodeResult>;
    /**
     * return: The subsumption relationship between code/Coding "A" and code/Coding "B". There are 4 possible codes to be returned (equivalent, subsumes, subsumed-by, and not-subsumed) as defined in the concept-subsumption-outcome value set. If the server is unable to determine the relationship between the codes/Codings, then it returns an error response with an OperationOutcome.
     */
    subsumes(params: {
        codeA?: string;
        codeB?: string;
        system: string;
        version?: string;
        codingA?: Coding;
        codingB?: Coding;
    }): Observable<string>;
    subsumesByInstance(id: string, params: {
        codeA?: string;
        codeB?: string;
        codingA?: Coding;
        codingB?: Coding;
    }): Observable<string>;
    /***********************************************
     * PRIVATE METHODS
     ***********************************************/
    private _lookup;
    private _validateCode;
    private _subsumes;
}
export declare namespace TerminologyCodeSystemApi {
    interface LookupResult {
        name: string;
        version?: string;
        display: string;
        definition?: string;
        designation?: LookupResult.LookupResultDesignation[];
        property?: LookupResult.LookupResultProperty[];
    }
    namespace LookupResult {
        interface LookupResultDesignation {
            language?: string;
            use?: Coding;
            additionalUse?: Coding[];
            value: string;
        }
        interface LookupResultProperty {
            code: string;
            value?: Coding | boolean | Date | number | string;
            description?: string;
            source?: string;
            subproperty?: {
                code: string;
                value: Coding | boolean | Date | number | string;
                description?: string;
                source?: string;
            }[];
        }
        function deserialize(parameters: Parameters): TerminologyCodeSystemApi.LookupResult;
        function revive(json: any): TerminologyCodeSystemApi.LookupResult;
    }
    interface ValidateCodeResult {
        result: boolean;
        message?: string;
        display?: string;
        code?: string;
        system?: string;
        version?: string;
        codeableConcept?: CodeableConcept;
        issues?: OperationOutcome;
    }
    namespace ValidateCodeResult {
        function deserialize(parameters: Parameters): TerminologyCodeSystemApi.ValidateCodeResult;
    }
}
