export interface TerminologySearchParams {
    url?: string;
    version?: string;
    name?: string;
    title?: string;
    status?: string;
}
