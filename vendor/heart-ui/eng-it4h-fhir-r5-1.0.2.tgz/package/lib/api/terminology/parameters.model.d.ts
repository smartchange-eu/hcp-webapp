import { BackboneElement, CodeableConcept, Coding, Meta, Reference } from "../../datatype";
import { DomainResource, OperationOutcome } from "../../model";
export declare class Parameters {
    static readonly resourceType = "Parameters";
    /**
       * Logical id of this artifact
       */
    id?: string;
    /**
     * Metadata about the resource
     */
    meta?: Meta;
    /**
     * Operation Parameter
     */
    parameter: Parameter[];
    getFirst(paramName: string): Parameter | undefined;
    get(paramName: string): Parameter[];
    toJSON(): any;
    static revive(json: any): Parameters;
}
export declare class Parameter extends BackboneElement {
    /**
     * Name from the definition
     */
    name: string;
    /**
     * If parameter is a data type
     */
    value?: number | string | Reference | Date | boolean | Coding | CodeableConcept | OperationOutcome;
    /**
     * If parameter is a whole resource
     */
    resource?: DomainResource;
    part?: Parameter[];
    getFirst(partName: string): Parameter | undefined;
    get(partName: string): Parameter[];
    toJSON(): any;
    static revive(json: any): Parameter;
}
