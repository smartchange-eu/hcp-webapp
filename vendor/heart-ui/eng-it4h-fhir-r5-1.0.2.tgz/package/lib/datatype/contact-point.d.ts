import { DataType } from '../datatype/data-type';
import { Period } from '../datatype/period';
/**
 * HAPI/FHIR <b>ContactPoint</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class ContactPoint extends DataType {
    /**
     * Specifies a preferred order in which to use a set of contacts. ContactPoints with lower rank values are more preferred than those with higher rank values.
     *
     * Specify preferred order of use (1 = highest)
     */
    rank?: number;
    /**
     * The actual contact point details, in a form that is meaningful to the designated communication system (i.e. phone number or email address).
     *
     * The actual contact point details
     */
    value?: string;
    /**
     * Time period when the contact point was/is in use.
     *
     * Time period when the contact point was/is in use
     */
    period?: Period;
    /**
     * Telecommunications form for contact point - what communications system is required to make use of the contact.
     *
     * phone | fax | email | pager | url | sms | other
     */
    system?: string;
    /**
     * Identifies the purpose for the contact point.
     *
     * home | work | temp | old | mobile - purpose of this contact point
     */
    use?: string;
    readonly dataType: string;
    static revive(json: any): ContactPoint;
    toJSON(): any;
}
export declare namespace ContactPoint {
    enum ContactPointUse {
        TEMP,
        NULL,
        OLD,
        WORK,
        HOME,
        MOBILE
    }
    enum ContactPointSystem {
        OTHER,
        NULL,
        PAGER,
        PHONE,
        SMS,
        FAX,
        EMAIL,
        URL
    }
}
