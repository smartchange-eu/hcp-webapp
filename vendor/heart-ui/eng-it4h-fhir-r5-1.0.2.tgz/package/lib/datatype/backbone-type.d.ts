import { DataType } from '../datatype/data-type';
import { Extension } from '../datatype/extension';
/**
 * HAPI/FHIR <b>BackboneType</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class BackboneType extends DataType {
    /**
     * May be used to represent additional information that is not part of the basic definition of the element and that modifies the understanding of the element in which it is contained and/or the understanding of the containing element's descendants. Usually modifier elements provide negation or qualification. To make the use of extensions safe and managable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension. Applications processing a resource are required to check for modifier extensions.

Modifier extensions SHALL NOT change the meaning of any elements on Resource or DomainResource (including cannot change the meaning of modifierExtension itself).
     *
     * Extensions that cannot be ignored even if unrecognized
     */
    modifierExtension?: Extension[];
    readonly dataType: string;
    static revive(json: any): BackboneType;
    toJSON(): any;
}
