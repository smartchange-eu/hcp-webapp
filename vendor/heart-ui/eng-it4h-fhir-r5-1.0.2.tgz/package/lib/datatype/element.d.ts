import { Extension } from '../datatype/extension';
/**
 * HAPI/FHIR <b>Element</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare abstract class Element {
    /**
     * Unique id for the element within a resource (for internal references). This may be any string value that does not contain spaces.
     *
     * Unique id for inter-element referencing
     */
    id?: string;
    /**
     * May be used to represent additional information that is not part of the basic definition of the element. To make the use of extensions safe and managable, there is a strict set of governance  applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.
     *
     * Additional content defined by implementations
     */
    extension?: Extension[];
    toJSON(): any;
}
