import { DataType } from '../datatype/data-type';
/**
 * HAPI/FHIR <b>PrimitiveType</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export interface PrimitiveType extends DataType {
}
