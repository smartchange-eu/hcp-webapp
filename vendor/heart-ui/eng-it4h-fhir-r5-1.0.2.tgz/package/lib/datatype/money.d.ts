import { DataType } from '../datatype/data-type';
/**
 * HAPI/FHIR <b>Money</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Money extends DataType {
    /**
     * ISO 4217 Currency Code.
     *
     * ISO 4217 Currency Code
     */
    currency?: string;
    /**
     * Numerical value (with implicit precision).
     *
     * Numerical value (with implicit precision)
     */
    value?: number;
    readonly dataType: string;
    static revive(json: any): Money;
    toJSON(): any;
}
