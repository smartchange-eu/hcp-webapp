import { Reference } from '../datatype/reference';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { DataType } from '../datatype/data-type';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { InsurancePlan } from '../model/insurance-plan';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
import { PlanDefinition } from '../model/plan-definition';
import { ResearchStudy } from '../model/research-study';
/**
 * HAPI/FHIR <b>UsageContext</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class UsageContext extends DataType {
    /**
     * A code that identifies the type of context being specified by this usage context.
     *
     * Type of context being specified
     */
    code: Coding;
    /**
     * A value that defines the context specified in this context of use. The interpretation of the value is defined by the code.
     *
     * Value that defines the context
     */
    value: CodeableConcept | Quantity | Range | PlanDefinition | ResearchStudy | InsurancePlan | HealthcareService | Group | Location | Organization | Reference;
    readonly dataType: string;
    static revive(json: any): UsageContext;
    toJSON(): any;
}
