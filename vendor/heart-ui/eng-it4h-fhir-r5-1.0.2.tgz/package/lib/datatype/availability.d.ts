import { BackboneElement } from '../datatype/backbone-element';
import { DataType } from '../datatype/data-type';
import { Period } from '../datatype/period';
/**
 * HAPI/FHIR <b>Availability</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Availability extends DataType {
    /**
     * Not available during this time due to provided reason.
     *
     * Not available during this time due to provided reason
     */
    notAvailableTime?: Availability.AvailabilityNotAvailableTimeComponent[];
    /**
     * Times the {item} is available.
     *
     * Times the {item} is available
     */
    availableTime?: Availability.AvailabilityAvailableTimeComponent[];
    readonly dataType: string;
    static revive(json: any): Availability;
    toJSON(): any;
}
export declare namespace Availability {
    class AvailabilityNotAvailableTimeComponent extends BackboneElement {
        /**
         * Service not available during this period.
         *
         * Service not available during this period
         */
        during?: Period;
        /**
         * Reason presented to the user explaining why time not available.
         *
         * Reason presented to the user explaining why time not available
         */
        description?: string;
        static revive(json: any): AvailabilityNotAvailableTimeComponent;
        toJSON(): any;
    }
    class AvailabilityAvailableTimeComponent extends BackboneElement {
        /**
         * Always available? i.e. 24 hour service.
         *
         * Always available? i.e. 24 hour service
         */
        allDay?: boolean;
        /**
         * mon | tue | wed | thu | fri | sat | sun.
         *
         * mon | tue | wed | thu | fri | sat | sun
         */
        daysOfWeek?: string[];
        /**
         * Opening time of day (ignored if allDay = true).
         *
         * Opening time of day (ignored if allDay = true)
         */
        availableStartTime?: Date;
        /**
         * Closing time of day (ignored if allDay = true).
         *
         * Closing time of day (ignored if allDay = true)
         */
        availableEndTime?: Date;
        static revive(json: any): AvailabilityAvailableTimeComponent;
        toJSON(): any;
    }
}
