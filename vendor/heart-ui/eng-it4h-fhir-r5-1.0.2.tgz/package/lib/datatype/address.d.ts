import { DataType } from '../datatype/data-type';
import { Period } from '../datatype/period';
/**
 * HAPI/FHIR <b>Address</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Address extends DataType {
    /**
     * Specifies the entire address as it should be displayed e.g. on a postal label. This may be provided instead of or as well as the specific parts.
     *
     * Text representation of the address
     */
    text?: string;
    /**
     * Sub-unit of a country with limited sovereignty in a federally organized country. A code may be used if codes are in common use (e.g. US 2 letter state codes).
     *
     * Sub-unit of country (abbreviations ok)
     */
    state?: string;
    /**
     * Distinguishes between physical addresses (those you can visit) and mailing addresses (e.g. PO Boxes and care-of addresses). Most addresses are both.
     *
     * postal | physical | both
     */
    type?: string;
    /**
     * Country - a nation as commonly understood or generally accepted.
     *
     * Country (e.g. may be ISO 3166 2 or 3 letter code)
     */
    country?: string;
    /**
     * Time period when address was/is in use.
     *
     * Time period when address was/is in use
     */
    period?: Period;
    /**
     * The name of the city, town, suburb, village or other community or delivery center.
     *
     * Name of city, town etc.
     */
    city?: string;
    /**
     * The name of the administrative area (county).
     *
     * District name (aka county)
     */
    district?: string;
    /**
     * A postal code designating a region defined by the postal service.
     *
     * Postal code for area
     */
    postalCode?: string;
    /**
     * The purpose of this address.
     *
     * home | work | temp | old | billing - purpose of this address
     */
    use?: string;
    /**
     * This component contains the house number, apartment number, street name, street direction,  P.O. Box number, delivery hints, and similar address information.
     *
     * Street name, number, direction & P.O. Box etc.
     */
    line?: string[];
    readonly dataType: string;
    static revive(json: any): Address;
    toJSON(): any;
}
export declare namespace Address {
    enum AddressUse {
        TEMP,
        NULL,
        BILLING,
        OLD,
        WORK,
        HOME
    }
    enum AddressType {
        NULL,
        PHYSICAL,
        POSTAL,
        BOTH
    }
}
