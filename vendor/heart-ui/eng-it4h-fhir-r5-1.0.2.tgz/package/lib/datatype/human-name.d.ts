import { DataType } from '../datatype/data-type';
import { Period } from '../datatype/period';
/**
 * HAPI/FHIR <b>HumanName</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class HumanName extends DataType {
    /**
     * The part of a name that links to the genealogy. In some cultures (e.g. Eritrea) the family name of a son is the first name of his father.
     *
     * Family name (often called 'Surname')
     */
    family?: string;
    /**
     * Part of the name that is acquired as a title due to academic, legal, employment or nobility status, etc. and that appears at the end of the name.
     *
     * Parts that come after the name
     */
    suffix?: string[];
    /**
     * Specifies the entire name as it should be displayed e.g. on an application UI. This may be provided instead of or as well as the specific parts.
     *
     * Text representation of the full name
     */
    text?: string;
    /**
     * Identifies the purpose for this name.
     *
     * usual | official | temp | nickname | anonymous | old | maiden
     */
    use?: string;
    /**
     * Part of the name that is acquired as a title due to academic, legal, employment or nobility status, etc. and that appears at the start of the name.
     *
     * Parts that come before the name
     */
    prefix?: string[];
    /**
     * Indicates the period of time when this name was valid for the named person.
     *
     * Time period when name was/is in use
     */
    period?: Period;
    /**
     * Given name.
     *
     * Given names (not always 'first'). Includes middle names
     */
    given?: string[];
    readonly dataType: string;
    static revive(json: any): HumanName;
    toJSON(): any;
}
export declare namespace HumanName {
    enum NameUse {
        ANONYMOUS,
        NICKNAME,
        OFFICIAL,
        TEMP,
        MAIDEN,
        NULL,
        USUAL,
        OLD
    }
}
