import { Quantity } from '../datatype/quantity';
/**
 * HAPI/FHIR <b>Age</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Age extends Quantity {
    readonly dataType: string;
    static revive(json: any): Age;
    toJSON(): any;
}
