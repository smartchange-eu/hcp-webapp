import { Reference } from '../datatype/reference';
import { DataType } from '../datatype/data-type';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Annotation</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Annotation extends DataType {
    /**
     * Indicates when this particular annotation was made.
     *
     * When the annotation was made
     */
    time?: Date;
    /**
     * The text of the annotation in markdown format.
     *
     * The annotation  - text content (as markdown)
     */
    text: string;
    /**
     * The individual responsible for making the annotation.
     *
     * Individual responsible for the annotation
     */
    author?: Practitioner | PractitionerRole | Patient | RelatedPerson | Organization | string | Reference;
    readonly dataType: string;
    static revive(json: any): Annotation;
    toJSON(): any;
}
