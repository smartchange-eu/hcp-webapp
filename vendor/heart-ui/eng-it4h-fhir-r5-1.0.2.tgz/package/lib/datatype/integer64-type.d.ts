import { PrimitiveType } from '../datatype/primitive-type';
/**
 * HAPI/FHIR <b>Integer64Type</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export interface Integer64Type extends PrimitiveType {
}
