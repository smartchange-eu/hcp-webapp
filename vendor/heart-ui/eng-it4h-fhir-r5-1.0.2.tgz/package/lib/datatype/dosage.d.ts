import { BackboneElement } from '../datatype/backbone-element';
import { BackboneType } from '../datatype/backbone-type';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { Ratio } from '../datatype/ratio';
import { Timing } from '../datatype/timing';
/**
 * HAPI/FHIR <b>Dosage</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Dosage extends BackboneType {
    /**
     * Indicates whether the Medication is only taken based on a precondition for taking the Medication (CodeableConcept).
     *
     * Take "as needed" (for x)
     */
    asNeededFor?: CodeableConcept[];
    /**
     * Depending on the resource,this is the amount of medication administered, to  be administered or typical amount to be administered.
     *
     * Amount of medication administered, to be administered or typical amount to be administered
     */
    doseAndRate?: Dosage.DosageDoseAndRateComponent[];
    /**
     * Technique for administering medication.
     *
     * Technique for administering medication
     */
    method?: CodeableConcept;
    /**
     * When medication should be administered.
     *
     * When medication should be administered
     */
    timing?: Timing;
    /**
     * Supplemental instructions to the patient on how to take the medication  (e.g. "with meals" or"take half to one hour before food") or warnings for the patient about the medication (e.g. "may cause drowsiness" or "avoid exposure of skin to direct sunlight or sunlamps").
     *
     * Supplemental instruction or warnings to the patient - e.g. "with meals", "may cause drowsiness"
     */
    additionalInstruction?: CodeableConcept[];
    /**
     * Upper limit on medication per lifetime of the patient.
     *
     * Upper limit on medication per lifetime of the patient
     */
    maxDosePerLifetime?: Quantity;
    /**
     * Instructions in terms that are understood by the patient or consumer.
     *
     * Patient or consumer oriented instructions
     */
    patientInstruction?: string;
    /**
     * Free text dosage instructions e.g. SIG.
     *
     * Free text dosage instructions e.g. SIG
     */
    text?: string;
    /**
     * Upper limit on medication per unit of time.
     *
     * Upper limit on medication per unit of time
     */
    maxDosePerPeriod?: Ratio[];
    /**
     * Upper limit on medication per administration.
     *
     * Upper limit on medication per administration
     */
    maxDosePerAdministration?: Quantity;
    /**
     * Indicates the order in which the dosage instructions should be applied or interpreted.
     *
     * The order of the dosage instructions
     */
    sequence?: number;
    /**
     * Indicates whether the Medication is only taken when needed within a specific dosing schedule (Boolean option).
     *
     * Take "as needed"
     */
    asNeeded?: boolean;
    /**
     * How drug should enter body.
     *
     * How drug should enter body
     */
    route?: CodeableConcept;
    /**
     * Body site to administer to.
     *
     * Body site to administer to
     */
    site?: CodeableConcept;
    readonly dataType: string;
    static revive(json: any): Dosage;
    toJSON(): any;
}
export declare namespace Dosage {
    class DosageDoseAndRateComponent extends BackboneElement {
        /**
         * The kind of dose or rate specified, for example, ordered or calculated.
         *
         * The kind of dose or rate specified
         */
        type?: CodeableConcept;
        /**
         * Amount of medication per unit of time.
         *
         * Amount of medication per unit of time
         */
        rate?: Ratio | Range | Quantity;
        /**
         * Amount of medication per dose.
         *
         * Amount of medication per dose
         */
        dose?: Range | Quantity;
        static revive(json: any): DosageDoseAndRateComponent;
        toJSON(): any;
    }
}
