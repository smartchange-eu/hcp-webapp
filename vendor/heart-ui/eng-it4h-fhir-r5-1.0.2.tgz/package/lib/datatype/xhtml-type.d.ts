import { PrimitiveType } from '../datatype/primitive-type';
/**
 * HAPI/FHIR <b>XhtmlType</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export interface XhtmlType extends PrimitiveType {
}
