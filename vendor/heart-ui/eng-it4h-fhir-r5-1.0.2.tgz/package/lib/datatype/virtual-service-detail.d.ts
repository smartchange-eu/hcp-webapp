import { Coding } from '../datatype/coding';
import { ContactPoint } from '../datatype/contact-point';
import { DataType } from '../datatype/data-type';
import { ExtendedContactDetail } from '../datatype/extended-contact-detail';
/**
 * HAPI/FHIR <b>VirtualServiceDetail</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class VirtualServiceDetail extends DataType {
    /**
     * What address or number needs to be used for a user to connect to the virtual service to join. The channelType informs as to which datatype is appropriate to use (requires knowledge of the specific type).
     *
     * Contact address/number
     */
    address?: string | ContactPoint | ExtendedContactDetail;
    /**
     * Session Key required by the virtual service.
     *
     * Session Key required by the virtual service
     */
    sessionKey?: string;
    /**
     * Address to see alternative connection details.
     *
     * Address to see alternative connection details
     */
    additionalInfo?: string[];
    /**
     * The type of virtual service to connect to (i.e. Teams, Zoom, Specific VMR technology, WhatsApp).
     *
     * Channel Type
     */
    channelType?: Coding;
    /**
     * Maximum number of participants supported by the virtual service.
     *
     * Maximum number of participants supported by the virtual service
     */
    maxParticipants?: number;
    readonly dataType: string;
    static revive(json: any): VirtualServiceDetail;
    toJSON(): any;
}
