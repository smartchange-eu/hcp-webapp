import { DataType } from '../datatype/data-type';
/**
 * HAPI/FHIR <b>ParameterDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class ParameterDefinition extends DataType {
    /**
     * The type of the parameter.
     *
     * What type of value
     */
    type: string;
    /**
     * The name of the parameter used to allow access to the value of the parameter in evaluation contexts.
     *
     * Name used to access the parameter value
     */
    name?: string;
    /**
     * The maximum number of times this element is permitted to appear in the request or response.
     *
     * Maximum cardinality (a number of *)
     */
    max?: string;
    /**
     * Whether the parameter is input or output for the module.
     *
     * in | out
     */
    use: string;
    /**
     * A brief discussion of what the parameter is for and how it is used by the module.
     *
     * A brief description of the parameter
     */
    documentation?: string;
    /**
     * If specified, this indicates a profile that the input data must conform to, or that the output data will conform to.
     *
     * What profile the value is expected to be
     */
    profile?: string;
    /**
     * The minimum number of times this parameter SHALL appear in the request or response.
     *
     * Minimum cardinality
     */
    min?: number;
    readonly dataType: string;
    static revive(json: any): ParameterDefinition;
    toJSON(): any;
}
export declare namespace ParameterDefinition {
    enum OperationParameterUse {
        NULL,
        IN,
        OUT
    }
    enum FHIRTypes {
        STRUCTUREMAP,
        RELATEDPERSON,
        MARKETINGSTATUS,
        MEDICINALPRODUCTDEFINITION,
        USAGECONTEXT,
        BIOLOGICALLYDERIVEDPRODUCT,
        REQUESTORCHESTRATION,
        SUBSTANCEPOLYMER,
        META,
        DISTANCE,
        MANUFACTUREDITEMDEFINITION,
        METADATARESOURCE,
        LIBRARY,
        UNSIGNEDINT,
        SUPPLYREQUEST,
        VISIONPRESCRIPTION,
        CONDITION,
        DOSAGE,
        IMAGINGSTUDY,
        NARRATIVE,
        CITATION,
        LOCATION,
        COVERAGE,
        NAMINGSYSTEM,
        CONTACTPOINT,
        COMPARTMENTDEFINITION,
        CONDITIONDEFINITION,
        MEDICATIONADMINISTRATION,
        TESTSCRIPT,
        HEALTHCARESERVICE,
        GROUP,
        RESOURCE,
        PROCEDURE,
        PRIMITIVETYPE,
        INSURANCEPLAN,
        MESSAGEDEFINITION,
        DEVICEREQUEST,
        AVAILABILITY,
        CONCEPTMAP,
        CONSENT,
        STRING,
        DURATION,
        DEVICEDEFINITION,
        PAYMENTRECONCILIATION,
        HUMANNAME,
        QUANTITY,
        ARTIFACTASSESSMENT,
        FAMILYMEMBERHISTORY,
        SPECIMEN,
        SIGNATURE,
        ACCOUNT,
        DATAREQUIREMENT,
        INVENTORYITEM,
        NUTRITIONPRODUCT,
        SUBSTANCEPROTEIN,
        ADVERSEEVENT,
        APPOINTMENTRESPONSE,
        EPISODEOFCARE,
        QUESTIONNAIRE,
        INTEGER,
        SERVICEREQUEST,
        CLAIMRESPONSE,
        RELATEDARTIFACT,
        ACTIVITYDEFINITION,
        CARETEAM,
        EVIDENCEVARIABLE,
        INVOICE,
        BOOLEAN,
        ACTORDEFINITION,
        BACKBONETYPE,
        DATATYPE,
        CAPABILITYSTATEMENT,
        INSTANT,
        CODESYSTEM,
        CHARGEITEM,
        LIST,
        MEDICATION,
        ATTACHMENT,
        MONEY,
        BINARY,
        RESEARCHSTUDY,
        SEARCHPARAMETER,
        BASE,
        ORGANIZATIONAFFILIATION,
        IMMUNIZATION,
        GENOMICSTUDY,
        ADMINISTRABLEPRODUCTDEFINITION,
        EVENTDEFINITION,
        IDENTIFIER,
        REGULATEDAUTHORIZATION,
        MESSAGEHEADER,
        AGE,
        IMPLEMENTATIONGUIDE,
        TESTPLAN,
        MEDICATIONREQUEST,
        PAYMENTNOTICE,
        CONTACTDETAIL,
        TIME,
        EXAMPLESCENARIO,
        OBSERVATIONDEFINITION,
        ELEMENTDEFINITION,
        DATETIME,
        MONETARYCOMPONENT,
        XHTML,
        PROVENANCE,
        SUBSTANCE,
        MEASUREREPORT,
        REQUIREMENTS,
        BIOLOGICALLYDERIVEDPRODUCTDISPENSE,
        ENCOUNTERHISTORY,
        MOLECULARSEQUENCE,
        MEDICATIONSTATEMENT,
        ANNOTATION,
        APPOINTMENT,
        ID,
        PERSON,
        DOMAINRESOURCE,
        INTEGER64,
        EVIDENCE,
        TERMINOLOGYCAPABILITIES,
        SAMPLEDDATA,
        PRACTITIONERROLE,
        GOAL,
        VIRTUALSERVICEDETAIL,
        TIMING,
        SUBSTANCEDEFINITION,
        COUNT,
        BASE64BINARY,
        VERIFICATIONRESULT,
        BACKBONEELEMENT,
        IMMUNIZATIONEVALUATION,
        STRUCTUREDEFINITION,
        PRACTITIONER,
        DOCUMENTREFERENCE,
        RATIO,
        FLAG,
        URI,
        INGREDIENT,
        PLANDEFINITION,
        URL,
        QUESTIONNAIRERESPONSE,
        ORGANIZATION,
        NUTRITIONORDER,
        ALLERGYINTOLERANCE,
        PRODUCTSHELFLIFE,
        FORMULARYITEM,
        SUPPLYDELIVERY,
        COMMUNICATIONREQUEST,
        CANONICALRESOURCE,
        BODYSTRUCTURE,
        SUBSCRIPTION,
        ELEMENT,
        GRAPHDEFINITION,
        MEDICATIONKNOWLEDGE,
        CODEABLEREFERENCE,
        DEVICEUSAGE,
        NUTRITIONINTAKE,
        PATIENT,
        SUBSCRIPTIONSTATUS,
        EXPRESSION,
        COVERAGEELIGIBILITYRESPONSE,
        MEASURE,
        PARAMETERDEFINITION,
        DECIMAL,
        EXTENSION,
        INVENTORYREPORT,
        OBSERVATION,
        SPECIMENDEFINITION,
        SCHEDULE,
        UUID,
        TRIGGERDEFINITION,
        TASK,
        CANONICAL,
        OPERATIONDEFINITION,
        NULL,
        RESEARCHSUBJECT,
        CODING,
        SUBSTANCEREFERENCEINFORMATION,
        DEVICE,
        CODEABLECONCEPT,
        OID,
        PARAMETERS,
        DATE,
        TESTREPORT,
        MARKDOWN,
        PACKAGEDPRODUCTDEFINITION,
        SUBSTANCESOURCEMATERIAL,
        GUIDANCERESPONSE,
        ADDRESS,
        PERIOD,
        POSITIVEINT,
        COMMUNICATION,
        RANGE,
        AUDITEVENT,
        CLINICALUSEDEFINITION,
        ENROLLMENTRESPONSE,
        PERMISSION,
        CONTRACT,
        VALUESET,
        BASIC,
        CLAIM,
        SUBSTANCENUCLEICACID,
        TRANSPORT,
        REFERENCE,
        COMPOSITION,
        SLOT,
        DEVICEDISPENSE,
        MEDICATIONDISPENSE,
        DIAGNOSTICREPORT,
        DEVICEMETRIC,
        EXPLANATIONOFBENEFIT,
        CONTRIBUTOR,
        DETECTEDISSUE,
        ENCOUNTER,
        EXTENDEDCONTACTDETAIL,
        DEVICEASSOCIATION,
        ENROLLMENTREQUEST,
        RISKASSESSMENT,
        IMMUNIZATIONRECOMMENDATION,
        CLINICALIMPRESSION,
        BUNDLE,
        CODE,
        RATIORANGE,
        CHARGEITEMDEFINITION,
        IMAGINGSELECTION,
        OPERATIONOUTCOME,
        ENDPOINT,
        CAREPLAN,
        COVERAGEELIGIBILITYREQUEST,
        LINKAGE,
        SUBSCRIPTIONTOPIC,
        EVIDENCEREPORT
    }
}
