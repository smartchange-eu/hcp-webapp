import { ContactPoint } from '../datatype/contact-point';
import { DataType } from '../datatype/data-type';
/**
 * HAPI/FHIR <b>ContactDetail</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class ContactDetail extends DataType {
    /**
     * The name of an individual to contact.
     *
     * Name of an individual to contact
     */
    name?: string;
    /**
     * The contact details for the individual (if a name was provided) or the organization.
     *
     * Contact details for individual or organization
     */
    telecom?: ContactPoint[];
    readonly dataType: string;
    static revive(json: any): ContactDetail;
    toJSON(): any;
}
