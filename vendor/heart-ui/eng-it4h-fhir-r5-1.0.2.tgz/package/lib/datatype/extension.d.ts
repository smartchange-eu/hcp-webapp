import { Reference } from '../datatype/reference';
import { Address } from '../datatype/address';
import { Annotation } from '../datatype/annotation';
import { Attachment } from '../datatype/attachment';
import { BaseExtension } from '../datatype/base-extension';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactPoint } from '../datatype/contact-point';
import { Duration } from '../datatype/duration';
import { HumanName } from '../datatype/human-name';
import { Identifier } from '../datatype/identifier';
import { Meta } from '../datatype/meta';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { Ratio } from '../datatype/ratio';
import { SampledData } from '../datatype/sampled-data';
import { Signature } from '../datatype/signature';
import { Timing } from '../datatype/timing';
/**
 * HAPI/FHIR <b>Extension</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Extension extends BaseExtension {
    /**
     * Value of extension - must be one of a constrained set of the data types (see [Extensibility](extensibility.html) for a list).
     *
     * Value of extension
     */
    value?: number | number | number | number | Date | Date | Date | string | boolean | Coding | CodeableConcept | Attachment | Duration | Period | Identifier | Quantity | SampledData | Range | Ratio | HumanName | Address | ContactPoint | Timing | Reference | Annotation | Signature | Meta;
    /**
     * Source of the definition for the extension code - a logical name or a URL.
     *
     * identifies the meaning of the extension
     */
    url: string;
    readonly dataType: string;
    static revive(json: any): Extension;
    toJSON(): any;
}
