import { PrimitiveType } from '../datatype/primitive-type';
/**
 * HAPI/FHIR <b>BaseDateTimeType</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export interface BaseDateTimeType extends PrimitiveType {
}
