import { CodeableConcept } from '../datatype/codeable-concept';
import { DataType } from '../datatype/data-type';
import { Money } from '../datatype/money';
/**
 * HAPI/FHIR <b>MonetaryComponent</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class MonetaryComponent extends DataType {
    /**
     * Explicit value amount to be used.
     *
     * Explicit value amount to be used
     */
    amount?: Money;
    /**
     * Codes may be used to differentiate between kinds of taxes, surcharges, discounts etc.
     *
     * Codes may be used to differentiate between kinds of taxes, surcharges, discounts etc.
     */
    code?: CodeableConcept;
    /**
     * base | surcharge | deduction | discount | tax | informational.
     *
     * base | surcharge | deduction | discount | tax | informational
     */
    type: string;
    /**
     * Factor used for calculating this component.
     *
     * Factor used for calculating this component
     */
    factor?: number;
    readonly dataType: string;
    static revive(json: any): MonetaryComponent;
    toJSON(): any;
}
export declare namespace MonetaryComponent {
    enum PriceComponentType {
        NULL,
        SURCHARGE,
        TAX,
        DEDUCTION,
        INFORMATIONAL,
        BASE,
        DISCOUNT
    }
}
