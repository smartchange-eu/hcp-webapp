import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { DataType } from '../datatype/data-type';
import { Duration } from '../datatype/duration';
import { Period } from '../datatype/period';
import { Group } from '../model/group';
/**
 * HAPI/FHIR <b>DataRequirement</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class DataRequirement extends DataType {
    /**
     * Specifies the order of the results to be returned.
     *
     * Order of the results
     */
    sort?: DataRequirement.DataRequirementSortComponent[];
    /**
     * Specifies a maximum number of results that are required (uses the _count search parameter).
     *
     * Number of results
     */
    limit?: number;
    /**
     * Code filters specify additional constraints on the data, specifying the value set of interest for a particular element of the data. Each code filter defines an additional constraint on the data, i.e. code filters are AND'ed, not OR'ed.
     *
     * What codes are expected
     */
    codeFilter?: DataRequirement.DataRequirementCodeFilterComponent[];
    /**
     * Date filters specify additional constraints on the data in terms of the applicable date range for specific elements. Each date filter specifies an additional constraint on the data, i.e. date filters are AND'ed, not OR'ed.
     *
     * What dates/date ranges are expected
     */
    dateFilter?: DataRequirement.DataRequirementDateFilterComponent[];
    /**
     * The type of the required data, specified as the type name of a resource. For profiles, this value is set to the type of the base resource of the profile.
     *
     * The type of the required data
     */
    type: string;
    /**
     * Value filters specify additional constraints on the data for elements other than code-valued or date-valued. Each value filter specifies an additional constraint on the data (i.e. valueFilters are AND'ed, not OR'ed).
     *
     * What values are expected
     */
    valueFilter?: DataRequirement.DataRequirementValueFilterComponent[];
    /**
     * The intended subjects of the data requirement. If this element is not provided, a Patient subject is assumed.
     *
     * E.g. Patient, Practitioner, RelatedPerson, Organization, Location, Device
     */
    subject?: CodeableConcept | Group | Reference;
    /**
     * The profile of the required data, specified as the uri of the profile definition.
     *
     * The profile of the required data
     */
    profile?: string[];
    /**
     * Indicates that specific elements of the type are referenced by the knowledge module and must be supported by the consumer in order to obtain an effective evaluation. This does not mean that a value is required for this element, only that the consuming system must understand the element and be able to provide values for it if they are available.

The value of mustSupport SHALL be a FHIRPath resolvable on the type of the DataRequirement. The path SHALL consist only of identifiers, constant indexers, and .resolve() (see the [Simple FHIRPath Profile](fhirpath.html#simple) for full details).
     *
     * Indicates specific structure elements that are referenced by the knowledge module
     */
    mustSupport?: string[];
    readonly dataType: string;
    static revive(json: any): DataRequirement;
    toJSON(): any;
}
export declare namespace DataRequirement {
    enum ValueFilterComparator {
        NULL,
        LT,
        LE,
        EQ,
        GT,
        EB,
        GE,
        SA
    }
    enum SortDirection {
        NULL,
        ASCENDING,
        DESCENDING
    }
    enum FHIRTypes {
        STRUCTUREMAP,
        RELATEDPERSON,
        MARKETINGSTATUS,
        MEDICINALPRODUCTDEFINITION,
        USAGECONTEXT,
        BIOLOGICALLYDERIVEDPRODUCT,
        REQUESTORCHESTRATION,
        SUBSTANCEPOLYMER,
        META,
        DISTANCE,
        MANUFACTUREDITEMDEFINITION,
        METADATARESOURCE,
        LIBRARY,
        UNSIGNEDINT,
        SUPPLYREQUEST,
        VISIONPRESCRIPTION,
        CONDITION,
        DOSAGE,
        IMAGINGSTUDY,
        NARRATIVE,
        CITATION,
        LOCATION,
        COVERAGE,
        NAMINGSYSTEM,
        CONTACTPOINT,
        COMPARTMENTDEFINITION,
        CONDITIONDEFINITION,
        MEDICATIONADMINISTRATION,
        TESTSCRIPT,
        HEALTHCARESERVICE,
        GROUP,
        RESOURCE,
        PROCEDURE,
        PRIMITIVETYPE,
        INSURANCEPLAN,
        MESSAGEDEFINITION,
        DEVICEREQUEST,
        AVAILABILITY,
        CONCEPTMAP,
        CONSENT,
        STRING,
        DURATION,
        DEVICEDEFINITION,
        PAYMENTRECONCILIATION,
        HUMANNAME,
        QUANTITY,
        ARTIFACTASSESSMENT,
        FAMILYMEMBERHISTORY,
        SPECIMEN,
        SIGNATURE,
        ACCOUNT,
        DATAREQUIREMENT,
        INVENTORYITEM,
        NUTRITIONPRODUCT,
        SUBSTANCEPROTEIN,
        ADVERSEEVENT,
        APPOINTMENTRESPONSE,
        EPISODEOFCARE,
        QUESTIONNAIRE,
        INTEGER,
        SERVICEREQUEST,
        CLAIMRESPONSE,
        RELATEDARTIFACT,
        ACTIVITYDEFINITION,
        CARETEAM,
        EVIDENCEVARIABLE,
        INVOICE,
        BOOLEAN,
        ACTORDEFINITION,
        BACKBONETYPE,
        DATATYPE,
        CAPABILITYSTATEMENT,
        INSTANT,
        CODESYSTEM,
        CHARGEITEM,
        LIST,
        MEDICATION,
        ATTACHMENT,
        MONEY,
        BINARY,
        RESEARCHSTUDY,
        SEARCHPARAMETER,
        BASE,
        ORGANIZATIONAFFILIATION,
        IMMUNIZATION,
        GENOMICSTUDY,
        ADMINISTRABLEPRODUCTDEFINITION,
        EVENTDEFINITION,
        IDENTIFIER,
        REGULATEDAUTHORIZATION,
        MESSAGEHEADER,
        AGE,
        IMPLEMENTATIONGUIDE,
        TESTPLAN,
        MEDICATIONREQUEST,
        PAYMENTNOTICE,
        CONTACTDETAIL,
        TIME,
        EXAMPLESCENARIO,
        OBSERVATIONDEFINITION,
        ELEMENTDEFINITION,
        DATETIME,
        MONETARYCOMPONENT,
        XHTML,
        PROVENANCE,
        SUBSTANCE,
        MEASUREREPORT,
        REQUIREMENTS,
        BIOLOGICALLYDERIVEDPRODUCTDISPENSE,
        ENCOUNTERHISTORY,
        MOLECULARSEQUENCE,
        MEDICATIONSTATEMENT,
        ANNOTATION,
        APPOINTMENT,
        ID,
        PERSON,
        DOMAINRESOURCE,
        INTEGER64,
        EVIDENCE,
        TERMINOLOGYCAPABILITIES,
        SAMPLEDDATA,
        PRACTITIONERROLE,
        GOAL,
        VIRTUALSERVICEDETAIL,
        TIMING,
        SUBSTANCEDEFINITION,
        COUNT,
        BASE64BINARY,
        VERIFICATIONRESULT,
        BACKBONEELEMENT,
        IMMUNIZATIONEVALUATION,
        STRUCTUREDEFINITION,
        PRACTITIONER,
        DOCUMENTREFERENCE,
        RATIO,
        FLAG,
        URI,
        INGREDIENT,
        PLANDEFINITION,
        URL,
        QUESTIONNAIRERESPONSE,
        ORGANIZATION,
        NUTRITIONORDER,
        ALLERGYINTOLERANCE,
        PRODUCTSHELFLIFE,
        FORMULARYITEM,
        SUPPLYDELIVERY,
        COMMUNICATIONREQUEST,
        CANONICALRESOURCE,
        BODYSTRUCTURE,
        SUBSCRIPTION,
        ELEMENT,
        GRAPHDEFINITION,
        MEDICATIONKNOWLEDGE,
        CODEABLEREFERENCE,
        DEVICEUSAGE,
        NUTRITIONINTAKE,
        PATIENT,
        SUBSCRIPTIONSTATUS,
        EXPRESSION,
        COVERAGEELIGIBILITYRESPONSE,
        MEASURE,
        PARAMETERDEFINITION,
        DECIMAL,
        EXTENSION,
        INVENTORYREPORT,
        OBSERVATION,
        SPECIMENDEFINITION,
        SCHEDULE,
        UUID,
        TRIGGERDEFINITION,
        TASK,
        CANONICAL,
        OPERATIONDEFINITION,
        NULL,
        RESEARCHSUBJECT,
        CODING,
        SUBSTANCEREFERENCEINFORMATION,
        DEVICE,
        CODEABLECONCEPT,
        OID,
        PARAMETERS,
        DATE,
        TESTREPORT,
        MARKDOWN,
        PACKAGEDPRODUCTDEFINITION,
        SUBSTANCESOURCEMATERIAL,
        GUIDANCERESPONSE,
        ADDRESS,
        PERIOD,
        POSITIVEINT,
        COMMUNICATION,
        RANGE,
        AUDITEVENT,
        CLINICALUSEDEFINITION,
        ENROLLMENTRESPONSE,
        PERMISSION,
        CONTRACT,
        VALUESET,
        BASIC,
        CLAIM,
        SUBSTANCENUCLEICACID,
        TRANSPORT,
        REFERENCE,
        COMPOSITION,
        SLOT,
        DEVICEDISPENSE,
        MEDICATIONDISPENSE,
        DIAGNOSTICREPORT,
        DEVICEMETRIC,
        EXPLANATIONOFBENEFIT,
        CONTRIBUTOR,
        DETECTEDISSUE,
        ENCOUNTER,
        EXTENDEDCONTACTDETAIL,
        DEVICEASSOCIATION,
        ENROLLMENTREQUEST,
        RISKASSESSMENT,
        IMMUNIZATIONRECOMMENDATION,
        CLINICALIMPRESSION,
        BUNDLE,
        CODE,
        RATIORANGE,
        CHARGEITEMDEFINITION,
        IMAGINGSELECTION,
        OPERATIONOUTCOME,
        ENDPOINT,
        CAREPLAN,
        COVERAGEELIGIBILITYREQUEST,
        LINKAGE,
        SUBSCRIPTIONTOPIC,
        EVIDENCEREPORT
    }
    class DataRequirementSortComponent extends BackboneElement {
        /**
         * The direction of the sort, ascending or descending.
         *
         * ascending | descending
         */
        direction: string;
        /**
         * The attribute of the sort. The specified path must be resolvable from the type of the required data. The path is allowed to contain qualifiers (.) to traverse sub-elements, as well as indexers ([x]) to traverse multiple-cardinality sub-elements. Note that the index must be an integer constant.
         *
         * The name of the attribute to perform the sort
         */
        path: string;
        static revive(json: any): DataRequirementSortComponent;
        toJSON(): any;
    }
    class DataRequirementValueFilterComponent extends BackboneElement {
        /**
         * A search parameter defined on the specified type of the DataRequirement, and which searches on elements of a type compatible with the type of the valueFilter.value[x] for the filter.
         *
         * A parameter to search on
         */
        searchParam?: string;
        /**
         * The attribute of the filter. The specified path SHALL be a FHIRPath resolvable on the specified type of the DataRequirement, and SHALL consist only of identifiers, constant indexers, and .resolve(). The path is allowed to contain qualifiers (.) to traverse sub-elements, as well as indexers ([x]) to traverse multiple-cardinality sub-elements (see the [Simple FHIRPath Profile](fhirpath.html#simple) for full details). Note that the index must be an integer constant. The path must resolve to an element of a type that is comparable to the valueFilter.value[x] element for the filter.
         *
         * An attribute to filter on
         */
        path?: string;
        /**
         * The comparator to be used to determine whether the value is matching.
         *
         * eq | gt | lt | ge | le | sa | eb
         */
        comparator?: string;
        /**
         * The value of the filter.
         *
         * The value of the filter, as a Period, DateTime, or Duration value
         */
        value?: Date | Period | Duration;
        static revive(json: any): DataRequirementValueFilterComponent;
        toJSON(): any;
    }
    class DataRequirementDateFilterComponent extends BackboneElement {
        /**
         * The value of the filter. If period is specified, the filter will return only those data items that fall within the bounds determined by the Period, inclusive of the period boundaries. If dateTime is specified, the filter will return only those data items that are equal to the specified dateTime. If a Duration is specified, the filter will return only those data items that fall within Duration before now.
         *
         * The value of the filter, as a Period, DateTime, or Duration value
         */
        value?: Date | Period | Duration;
        /**
         * The date-valued attribute of the filter. The specified path SHALL be a FHIRPath resolvable on the specified type of the DataRequirement, and SHALL consist only of identifiers, constant indexers, and .resolve(). The path is allowed to contain qualifiers (.) to traverse sub-elements, as well as indexers ([x]) to traverse multiple-cardinality sub-elements (see the [Simple FHIRPath Profile](fhirpath.html#simple) for full details). Note that the index must be an integer constant. The path must resolve to an element of type date, dateTime, Period, Schedule, or Timing.
         *
         * A date-valued attribute to filter on
         */
        path?: string;
        /**
         * A date parameter that refers to a search parameter defined on the specified type of the DataRequirement, and which searches on elements of type date, dateTime, Period, Schedule, or Timing.
         *
         * A date valued parameter to search on
         */
        searchParam?: string;
        static revive(json: any): DataRequirementDateFilterComponent;
        toJSON(): any;
    }
    class DataRequirementCodeFilterComponent extends BackboneElement {
        /**
         * A token parameter that refers to a search parameter defined on the specified type of the DataRequirement, and which searches on elements of type code, Coding, or CodeableConcept.
         *
         * A coded (token) parameter to search on
         */
        searchParam?: string;
        /**
         * The valueset for the code filter. The valueSet and code elements are additive. If valueSet is specified, the filter will return only those data items for which the value of the code-valued element specified in the path is a member of the specified valueset.
         *
         * ValueSet for the filter
         */
        valueSet?: string;
        /**
         * The codes for the code filter. If values are given, the filter will return only those data items for which the code-valued attribute specified by the path has a value that is one of the specified codes. If codes are specified in addition to a value set, the filter returns items matching a code in the value set or one of the specified codes.
         *
         * What code is expected
         */
        code?: Coding[];
        /**
         * The code-valued attribute of the filter. The specified path SHALL be a FHIRPath resolvable on the specified type of the DataRequirement, and SHALL consist only of identifiers, constant indexers, and .resolve(). The path is allowed to contain qualifiers (.) to traverse sub-elements, as well as indexers ([x]) to traverse multiple-cardinality sub-elements (see the [Simple FHIRPath Profile](fhirpath.html#simple) for full details). Note that the index must be an integer constant. The path must resolve to an element of type code, Coding, or CodeableConcept.
         *
         * A code-valued attribute to filter on
         */
        path?: string;
        static revive(json: any): DataRequirementCodeFilterComponent;
        toJSON(): any;
    }
}
