import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Identifier } from '../datatype/identifier';
import { Signature } from '../datatype/signature';
import { DomainResource } from '../model/domain-resource';
/**
 * HAPI/FHIR <b>Bundle</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Bundle">http://hl7.org/fhir/StructureDefinition/Bundle</a>
 * </p>
 *
 */
export declare class Bundle {
    /**
     * A series of links that provide context to this bundle.
     *
     * Links related to this Bundle
     */
    link?: Bundle.BundleLinkComponent[];
    /**
     * Captures issues and warnings that relate to the construction of the Bundle and the content within it.
     *
     * Issues with the Bundle
     */
    issues?: DomainResource | Reference;
    /**
     * Indicates the purpose of this bundle - how it is intended to be used.
     *
     * document | message | transaction | transaction-response | batch | batch-response | history | searchset | collection | subscription-notification
     */
    type: string;
    /**
     * The date/time that the bundle was assembled - i.e. when the resources were placed in the bundle.
     *
     * When the bundle was assembled
     */
    timestamp?: Date;
    /**
     * A persistent identifier for the bundle that won't change as a bundle is copied from server to server.
     *
     * Persistent identifier for the bundle
     */
    identifier?: Identifier;
    /**
     * An entry in a bundle resource - will either contain a resource or information about a resource (transactions and history only).
     *
     * Entry in the bundle - will have a resource or information
     */
    entry?: Bundle.BundleEntryComponent[];
    /**
     * If a set of search matches, this is the (potentially estimated) total number of entries of type 'match' across all pages in the search.  It does not include search.mode = 'include' or 'outcome' entries and it does not provide a count of the number of entries in the Bundle.
     *
     * If search, the total number of matches
     */
    total?: number;
    /**
     * Digital Signature - base64 encoded. XML-DSig or a JWS.
     *
     * Digital Signature
     */
    signature?: Signature;
    readonly resourceType: string;
    isSingleResult(): boolean;
    isLastPage(): boolean;
    isFirstPage(): boolean;
    isEmpty(): boolean;
    findResourceInBundle(ref: Reference | string): DomainResource;
    static revive(json: any): Bundle;
    toJSON(): any;
    static _resourceRevive(json: any): (Bundle | DomainResource | Reference);
}
export declare namespace Bundle {
    enum SearchEntryMode {
        NULL,
        OUTCOME,
        INCLUDE,
        MATCH
    }
    enum LinkRelationTypes {
        TERMSOFSERVICE,
        PAYMENT,
        BLOCKEDBY,
        PUBLICATION,
        INTERVALMETBY,
        ORIGINAL,
        WORKINGCOPY,
        INTERVALDISJOINT,
        INTERVALOVERLAPPEDBY,
        PREV,
        STYLESHEET,
        BOOKMARK,
        TYPE,
        INTERVALMEETS,
        OPENER,
        PREFETCH,
        SEARCH,
        DNSPREFETCH,
        PRELOAD,
        INTERVALIN,
        EDIT,
        NOFOLLOW,
        VERSIONHISTORY,
        INTERVALBEFORE,
        AMPHTML,
        ENCLOSURE,
        CONVERTEDFROM,
        PREDECESSORVERSION,
        INTERVALFINISHEDBY,
        ITEM,
        INTERVALSTARTEDBY,
        OPENID2_PROVIDER,
        TIMEMAP,
        MANIFEST,
        MEMENTO,
        INTERVALDURING,
        MONITOR,
        PREVARCHIVE,
        OPENID2_LOCALID,
        CITEAS,
        GLOSSARY,
        AUTHOR,
        DESCRIBEDBY,
        CREATEFORM,
        PREVIOUS,
        LINKSET,
        APPLETOUCHSTARTUPIMAGE,
        DUPLICATE,
        P3PV1,
        APPLETOUCHICON,
        NEXTARCHIVE,
        APPENDIX,
        ICON,
        HELP,
        EDITMEDIA,
        ACL,
        SELF,
        FIRST,
        ALTERNATE,
        MASKICON,
        SPONSORED,
        SERVICEMETA,
        SUBSECTION,
        RESTCONF,
        COPYRIGHT,
        TAG,
        PREVIEW,
        PINGBACK,
        SERVICEDOC,
        COLLECTION,
        NOOPENER,
        PRIVACYPOLICY,
        STATUS,
        DISCLOSURE,
        DESCRIBES,
        SERVICE,
        INDEX,
        UP,
        LICENSE,
        SUCCESSORVERSION,
        CANONICAL,
        NULL,
        INTERVALOVERLAPS,
        LRDD,
        ARCHIVES,
        INTERVALAFTER,
        CURRENT,
        HOSTS,
        WORKINGCOPYOF,
        MONITORGROUP,
        LAST,
        PRERENDER,
        INTERVALEQUALS,
        RELATED,
        TIMEGATE,
        CONTENTS,
        SERVICEDESC,
        MODULEPRELOAD,
        PROFILE,
        EXTERNAL,
        HUB,
        INTERVALSTARTS,
        MEDIAFEED,
        NEXT,
        ABOUT,
        RULEINPUT,
        REPLIES,
        SUNSET,
        EDITFORM,
        MICROPUB,
        INTERVALCONTAINS,
        VIA,
        UGC,
        NOREFERRER,
        WEBMENTION,
        CHAPTER,
        PRECONNECT,
        START,
        LATESTVERSION,
        SECTION,
        INTERVALFINISHES
    }
    enum HTTPVerb {
        HEAD,
        DELETE,
        NULL,
        POST,
        GET,
        PUT,
        PATCH
    }
    enum BundleType {
        MESSAGE,
        COLLECTION,
        NULL,
        SUBSCRIPTIONNOTIFICATION,
        DOCUMENT,
        BATCHRESPONSE,
        TRANSACTION,
        TRANSACTIONRESPONSE,
        BATCH,
        HISTORY,
        SEARCHSET
    }
    class BundleEntryResponseComponent extends BackboneElement {
        /**
         * The date/time that the resource was modified on the server.
         *
         * Server's date time modified
         */
        lastModified?: Date;
        /**
         * The location header created by processing this operation, populated if the operation returns a location.
         *
         * The location (if the operation returns a location)
         */
        location?: string;
        /**
         * The Etag for the resource, if the operation for the entry produced a versioned resource (see [Resource Metadata and Versioning](http.html#versioning) and [Managing Resource Contention](http.html#concurrency)).
         *
         * The Etag for the resource (if relevant)
         */
        etag?: string;
        /**
         * The status code returned by processing this entry. The status SHALL start with a 3 digit HTTP code (e.g. 404) and may contain the standard HTTP description associated with the status code.
         *
         * Status response code (text optional)
         */
        status: string;
        /**
         * An OperationOutcome containing hints and warnings produced as part of processing this entry in a batch or transaction.
         *
         * OperationOutcome with hints and warnings (for batch/transaction)
         */
        outcome?: DomainResource | Reference;
        static revive(json: any): BundleEntryResponseComponent;
        toJSON(): any;
    }
    class BundleEntryRequestComponent extends BackboneElement {
        /**
         * In a transaction or batch, this is the HTTP action to be executed for this entry. In a history bundle, this indicates the HTTP action that occurred.
         *
         * GET | HEAD | POST | PUT | DELETE | PATCH
         */
        method: string;
        /**
         * Only perform the operation if the last updated date matches. See the API documentation for ["Conditional Read"](http.html#cread).
         *
         * For managing cache currency
         */
        ifModifiedSince?: Date;
        /**
         * Instruct the server not to perform the create if a specified resource already exists. For further information, see the API documentation for ["Conditional Create"](http.html#ccreate). This is just the query portion of the URL - what follows the "?" (not including the "?").
         *
         * For conditional creates
         */
        ifNoneExist?: string;
        /**
         * Only perform the operation if the Etag value matches. For more information, see the API section ["Managing Resource Contention"](http.html#concurrency).
         *
         * For managing update contention
         */
        ifMatch?: string;
        /**
         * The URL for this entry, relative to the root (the address to which the request is posted).
         *
         * URL for HTTP equivalent of this entry
         */
        url: string;
        /**
         * If the ETag values match, return a 304 Not Modified status. See the API documentation for ["Conditional Read"](http.html#cread).
         *
         * For managing cache validation
         */
        ifNoneMatch?: string;
        static revive(json: any): BundleEntryRequestComponent;
        toJSON(): any;
    }
    class BundleEntrySearchComponent extends BackboneElement {
        /**
         * When searching, the server's search ranking score for the entry.
         *
         * Search ranking (between 0 and 1)
         */
        score?: number;
        /**
         * Why this entry is in the result set - whether it's included as a match or because of an _include requirement, or to convey information or warning information about the search process.
         *
         * match | include - why this is in the result set
         */
        mode?: string;
        static revive(json: any): BundleEntrySearchComponent;
        toJSON(): any;
    }
    class BundleEntryComponent extends BackboneElement {
        /**
         * Additional information about how this entry should be processed as part of a transaction or batch.  For history, it shows how the entry was processed to create the version contained in the entry.
         *
         * Additional execution information (transaction/batch/history)
         */
        request?: Bundle.BundleEntryRequestComponent;
        /**
         * Information about the search process that lead to the creation of this entry.
         *
         * Search related information
         */
        search?: Bundle.BundleEntrySearchComponent;
        /**
         * The Resource for the entry. The purpose/meaning of the resource is determined by the Bundle.type. This is allowed to be a Parameters resource if and only if it is referenced by something else within the Bundle that provides context/meaning.
         *
         * A resource in the bundle
         */
        resource?: DomainResource | Reference;
        /**
         * The Absolute URL for the resource. Except for transactions and batches, each entry in a Bundle must have a fullUrl. The fullUrl SHALL NOT disagree with the id in the resource - i.e. if the fullUrl is not a urn:uuid, the URL shall be version-independent URL consistent with the Resource.id. The fullUrl is a version independent reference to the resource. Even when not required, fullUrl MAY be set to a urn:uuid to allow referencing entries in a transaction. The fullUrl can be an arbitrary URI and is not limited to urn:uuid, urn:oid, http, and https. The fullUrl element SHALL have a value except when:
* invoking a create
* invoking or responding to an operation where the body is not a single identified resource
* invoking or returning the results of a search or history operation.
         *
         * URI for resource (e.g. the absolute URL server address, URI for UUID/OID, etc.)
         */
        fullUrl?: string;
        /**
         * Indicates the results of processing the corresponding 'request' entry in the batch or transaction being responded to or what the results of an operation where when returning history.
         *
         * Results of execution (transaction/batch/history)
         */
        response?: Bundle.BundleEntryResponseComponent;
        /**
         * A series of links that provide context to this entry.
         *
         * Links related to this entry
         */
        link?: Bundle.BundleLinkComponent[];
        static revive(json: any): BundleEntryComponent;
        toJSON(): any;
    }
    class BundleLinkComponent extends BackboneElement {
        /**
         * The reference details for the link.
         *
         * Reference details for the link
         */
        url: string;
        /**
         * A name which details the functional use for this link - see [http://www.iana.org/assignments/link-relations/link-relations.xhtml#link-relations-1](http://www.iana.org/assignments/link-relations/link-relations.xhtml#link-relations-1).
         *
         * See http://www.iana.org/assignments/link-relations/link-relations.xhtml#link-relations-1
         */
        relation: string;
        static revive(json: any): BundleLinkComponent;
        toJSON(): any;
    }
}
