import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { BackboneType } from '../datatype/backbone-type';
import { Quantity } from '../datatype/quantity';
import { Statistic } from '../datatype/statistic';
/**
 * HAPI/FHIR <b>OrderedDistribution</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class OrderedDistribution extends BackboneType {
    /**
     * Number of intervals in an array, eg 4 for quartiles.
     *
     * Number of intervals in an array, eg 4 for quartiles
     */
    numberOfIntervals: number;
    /**
     * Footnotes and/or explanatory notes.
     *
     * Footnotes and/or explanatory notes
     */
    note?: Annotation[];
    /**
     * Bottom of first interval.
     *
     * Bottom of first interval
     */
    bottomOfFirstInterval?: Quantity;
    /**
     * Interval.
     *
     * Interval
     */
    interval: OrderedDistribution.OrderedDistributionIntervalComponent[];
    /**
     * A description of the content and value of the statistic.
     *
     * A description of the content and value of the statistic
     */
    description?: string;
    /**
     * Singular value of the statistic at the upper bound of the interval.
     *
     * Singular value of the statistic at the upper bound of the interval
     */
    topOfInterval?: Quantity;
    readonly dataType: string;
    static revive(json: any): OrderedDistribution;
    toJSON(): any;
}
export declare namespace OrderedDistribution {
    class OrderedDistributionIntervalComponent extends BackboneElement {
        /**
         * Values and parameters for a single statistic related to the interval.
         *
         * Values and parameters for a single statistic related to the interval
         */
        intervalStatistic?: Statistic[];
        /**
         * Relative order of interval.
         *
         * Relative order of interval
         */
        rankOrder: number;
        static revive(json: any): OrderedDistributionIntervalComponent;
        toJSON(): any;
    }
}
