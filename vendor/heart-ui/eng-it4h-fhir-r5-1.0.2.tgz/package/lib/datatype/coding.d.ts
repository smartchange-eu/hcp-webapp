import { DataType } from '../datatype/data-type';
/**
 * HAPI/FHIR <b>Coding</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Coding extends DataType {
    /**
     * A representation of the meaning of the code in the system, following the rules of the system.
     *
     * Representation defined by the system
     */
    display?: string;
    /**
     * Indicates that this coding was chosen by a user directly - e.g. off a pick list of available items (codes or displays).
     *
     * If this coding was chosen directly by the user
     */
    userSelected?: boolean;
    /**
     * The identification of the code system that defines the meaning of the symbol in the code.
     *
     * Identity of the terminology system
     */
    system?: string;
    /**
     * A symbol in syntax defined by the system. The symbol may be a predefined code or an expression in a syntax defined by the coding system (e.g. post-coordination).
     *
     * Symbol in syntax defined by the system
     */
    code?: string;
    /**
     * The version of the code system which was used when choosing this code. Note that a well-maintained code system does not need the version reported, because the meaning of codes is consistent across versions. However this cannot consistently be assured, and when the meaning is not guaranteed to be consistent, the version SHOULD be exchanged.
     *
     * Version of the system - if relevant
     */
    version?: string;
    readonly dataType: string;
    constructor(tpl?: Coding);
    static revive(json: any): Coding;
    toJSON(): any;
}
