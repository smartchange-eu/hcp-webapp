import { DataType } from '../datatype/data-type';
import { Quantity } from '../datatype/quantity';
/**
 * HAPI/FHIR <b>Range</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Range extends DataType {
    /**
     * The low limit. The boundary is inclusive.
     *
     * Low limit
     */
    low?: Quantity;
    /**
     * The high limit. The boundary is inclusive.
     *
     * High limit
     */
    high?: Quantity;
    readonly dataType: string;
    static revive(json: any): Range;
    toJSON(): any;
}
