import { DataType } from '../datatype/data-type';
/**
 * HAPI/FHIR <b>BaseExtension</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class BaseExtension extends DataType {
    readonly dataType: string;
    static revive(json: any): BaseExtension;
    toJSON(): any;
}
