import { DataType } from '../datatype/data-type';
/**
 * HAPI/FHIR <b>BaseReference</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class BaseReference extends DataType {
    readonly dataType: string;
    static revive(json: any): BaseReference;
    toJSON(): any;
}
