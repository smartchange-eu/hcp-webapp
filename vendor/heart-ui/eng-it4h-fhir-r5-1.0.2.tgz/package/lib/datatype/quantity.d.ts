import { DataType } from '../datatype/data-type';
/**
 * HAPI/FHIR <b>Quantity</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Quantity extends DataType {
    /**
     * The value of the measured amount. The value includes an implicit precision in the presentation of the value.
     *
     * Numerical value (with implicit precision)
     */
    value?: number;
    /**
     * The identification of the system that provides the coded form of the unit.
     *
     * System that defines coded unit form
     */
    system?: string;
    /**
     * A computer processable form of the unit in some unit representation system.
     *
     * Coded form of the unit
     */
    code?: string;
    /**
     * A human-readable form of the unit.
     *
     * Unit representation
     */
    unit?: string;
    /**
     * How the value should be understood and represented - whether the actual value is greater or less than the stated value due to measurement issues; e.g. if the comparator is "<" , then the real value is < stated value.
     *
     * < | <= | >= | > | ad - how to understand the value
     */
    comparator?: string;
    readonly dataType: string;
    static revive(json: any): Quantity;
    toJSON(): any;
}
export declare namespace Quantity {
    enum QuantityComparator {
        GREATER_OR_EQUAL,
        LESS_OR_EQUAL,
        AD,
        NULL,
        GREATER_THAN,
        LESS_THAN
    }
}
