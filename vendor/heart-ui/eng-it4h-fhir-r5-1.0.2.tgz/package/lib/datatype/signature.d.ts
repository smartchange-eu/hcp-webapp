import { Reference } from '../datatype/reference';
import { Coding } from '../datatype/coding';
import { DataType } from '../datatype/data-type';
import { Device } from '../model/device';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Signature</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Signature extends DataType {
    /**
     * The base64 encoding of the Signature content. When signature is not recorded electronically this element would be empty.
     *
     * The actual signature content (XML DigSig. JWS, picture, etc.)
     */
    data?: string;
    /**
     * A reference to an application-usable description of the identity that signed  (e.g. the signature used their private key).
     *
     * Who signed
     */
    who?: Practitioner | PractitionerRole | RelatedPerson | Patient | Device | Organization | Reference;
    /**
     * An indication of the reason that the entity signed this document. This may be explicitly included as part of the signature information and can be used when determining accountability for various actions concerning the document.
     *
     * Indication of the reason the entity signed the object(s)
     */
    type?: Coding[];
    /**
     * When the digital signature was signed.
     *
     * When the signature was created
     */
    when?: Date;
    /**
     * A mime type that indicates the technical format of the target resources signed by the signature.
     *
     * The technical format of the signed resources
     */
    targetFormat?: string;
    /**
     * A reference to an application-usable description of the identity that is represented by the signature.
     *
     * The party represented
     */
    onBehalfOf?: Practitioner | PractitionerRole | RelatedPerson | Patient | Device | Organization | Reference;
    /**
     * A mime type that indicates the technical format of the signature. Important mime types are application/signature+xml for X ML DigSig, application/jose for JWS, and image/* for a graphical image of a signature, etc.
     *
     * The technical format of the signature
     */
    sigFormat?: string;
    readonly dataType: string;
    static revive(json: any): Signature;
    toJSON(): any;
}
