import { Quantity } from '../datatype/quantity';
/**
 * HAPI/FHIR <b>SimpleQuantity</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class SimpleQuantity extends Quantity {
    readonly dataType: string;
    static revive(json: any): SimpleQuantity;
    toJSON(): any;
}
