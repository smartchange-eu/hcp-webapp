import { BaseReference } from '../datatype/base-reference';
import { Identifier } from '../datatype/identifier';
/**
 * HAPI/FHIR <b>Reference</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Reference extends BaseReference {
    /**
     * Plain text narrative that identifies the resource in addition to the resource reference.
     *
     * Text alternative for the resource
     */
    display?: string;
    /**
     * An identifier for the target resource. This is used when there is no way to reference the other resource directly, either because the entity it represents is not available through a FHIR server, or because there is no way for the author of the resource to convert a known identifier to an actual location. There is no requirement that a Reference.identifier point to something that is actually exposed as a FHIR instance, but it SHALL point to a business concept that would be expected to be exposed as a FHIR instance, and that instance would need to be of a FHIR resource type allowed by the reference.
     *
     * Logical reference, when literal reference is not known
     */
    identifier?: Identifier;
    /**
     * A reference to a location at which the other resource is found. The reference may be a relative reference, in which case it is relative to the service base URL, or an absolute URL that resolves to the location where the resource is found. The reference may be version specific or not. If the reference is not to a FHIR RESTful server, then it should be assumed to be version specific. Internal fragment references (start with '#') refer to contained resources.
     *
     * Literal reference, Relative, internal or absolute URL
     */
    reference?: string;
    /**
     * The expected type of the target of the reference. If both Reference.type and Reference.reference are populated and Reference.reference is a FHIR URL, both SHALL be consistent.

The type is the Canonical URL of Resource Definition that is the type this reference refers to. References are URLs that are relative to http://hl7.org/fhir/StructureDefinition/ e.g. "Patient" is a reference to http://hl7.org/fhir/StructureDefinition/Patient. Absolute URLs are only allowed for logical models (and can only be used in references in logical models, not resources).
     *
     * Type the reference refers to (e.g. "Patient") - must be a resource in resources
     */
    type?: string;
    readonly dataType: string;
    constructor(value?: {
        reference?: string;
        type?: string;
        id?: string | number;
        version?: number;
    });
    /**
     * Check if the reference is pointing to a "contained" resource
     */
    isContainedResource(): boolean;
    getReferenceIdPart(): number;
    static fromReference(reference: string, resourceType?: string, addVersion?: boolean): Reference;
    static revive(json: any): Reference;
    toJSON(): any;
}
