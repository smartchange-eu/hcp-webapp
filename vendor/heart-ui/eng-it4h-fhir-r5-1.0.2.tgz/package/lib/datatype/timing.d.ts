import { BackboneElement } from '../datatype/backbone-element';
import { BackboneType } from '../datatype/backbone-type';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Duration } from '../datatype/duration';
import { Period } from '../datatype/period';
import { Range } from '../datatype/range';
/**
 * HAPI/FHIR <b>Timing</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Timing extends BackboneType {
    /**
     * A set of rules that describe when the event is scheduled.
     *
     * When the event is to occur
     */
    repeat?: Timing.TimingRepeatComponent;
    /**
     * A code for the timing schedule (or just text in code.text). Some codes such as BID are ubiquitous, but many institutions define their own additional codes. If a code is provided, the code is understood to be a complete statement of whatever is specified in the structured timing data, and either the code or the data may be used to interpret the Timing, with the exception that .repeat.bounds still applies over the code (and is not contained in the code).
     *
     * C | BID | TID | QID | AM | PM | QD | QOD | +
     */
    code?: CodeableConcept;
    /**
     * Identifies specific times when the event occurs.
     *
     * When the event occurs
     */
    event?: Date[];
    readonly dataType: string;
    static revive(json: any): Timing;
    toJSON(): any;
}
export declare namespace Timing {
    enum UnitsOfTime {
        A,
        MO,
        S,
        MIN,
        NULL,
        D,
        WK,
        H
    }
    enum EventTiming {
        PCV,
        AFT_LATE,
        C,
        NOON,
        HS,
        WAKE,
        AFT,
        EVE_EARLY,
        NIGHT,
        AFT_EARLY,
        PHS,
        MORN_EARLY,
        IMD,
        CD,
        AC,
        ACD,
        NULL,
        CM,
        ACM,
        MORN_LATE,
        PCD,
        CV,
        PC,
        EVE_LATE,
        ACV,
        EVE,
        MORN,
        PCM
    }
    class TimingRepeatComponent extends BackboneElement {
        /**
         * The units of time for the duration, in UCUM units
Normal practice is to use the 'mo' code as a calendar month when calculating the next occurrence.
         *
         * s | min | h | d | wk | mo | a - unit of time (UCUM)
         */
        durationUnit?: string;
        /**
         * Either a duration for the length of the timing schedule, a range of possible length, or outer bounds for start and/or end limits of the timing schedule.
         *
         * Length/Range of lengths, or (Start and/or end) limits
         */
        bounds?: Duration | Range | Period;
        /**
         * Specified time of day for action to take place.
         *
         * Time of day for action
         */
        timeOfDay?: Date[];
        /**
         * If one or more days of week is provided, then the action happens only on the specified day(s).
         *
         * mon | tue | wed | thu | fri | sat | sun
         */
        dayOfWeek?: string[];
        /**
         * If present, indicates that the duration is a range - so to perform the action between [duration] and [durationMax] time length.
         *
         * How long when it happens (Max)
         */
        durationMax?: number;
        /**
         * How long this thing happens for when it happens. If durationMax is present, this element indicates the lower bound of the allowed range of the duration.
         *
         * How long when it happens
         */
        duration?: number;
        /**
         * A total count of the desired number of repetitions across the duration of the entire timing specification. If countMax is present, this element indicates the lower bound of the allowed range of count values.
         *
         * Number of times to repeat
         */
        count?: number;
        /**
         * The number of times to repeat the action within the specified period. If frequencyMax is present, this element indicates the lower bound of the allowed range of the frequency.
         *
         * Indicates the number of repetitions that should occur within a period. I.e. Event occurs frequency times per period
         */
        frequency?: number;
        /**
         * The units of time for the period in UCUM units
Normal practice is to use the 'mo' code as a calendar month when calculating the next occurrence.
         *
         * s | min | h | d | wk | mo | a - unit of time (UCUM)
         */
        periodUnit?: string;
        /**
         * An approximate time period during the day, potentially linked to an event of daily living that indicates when the action should occur.
         *
         * Code for time period of occurrence
         */
        when?: string[];
        /**
         * Indicates the duration of time over which repetitions are to occur; e.g. to express "3 times per day", 3 would be the frequency and "1 day" would be the period. If periodMax is present, this element indicates the lower bound of the allowed range of the period length.
         *
         * The duration to which the frequency applies. I.e. Event occurs frequency times per period
         */
        period?: number;
        /**
         * If present, indicates that the count is a range - so to perform the action between [count] and [countMax] times.
         *
         * Maximum number of times to repeat
         */
        countMax?: number;
        /**
         * If present, indicates that the period is a range from [period] to [periodMax], allowing expressing concepts such as "do this once every 3-5 days.
         *
         * Upper limit of period (3-4 hours)
         */
        periodMax?: number;
        /**
         * If present, indicates that the frequency is a range - so to repeat between [frequency] and [frequencyMax] times within the period or period range.
         *
         * Event occurs up to frequencyMax times per period
         */
        frequencyMax?: number;
        /**
         * The number of minutes from the event. If the event code does not indicate whether the minutes is before or after the event, then the offset is assumed to be after the event.
         *
         * Minutes from event (before or after)
         */
        offset?: number;
        static revive(json: any): TimingRepeatComponent;
        toJSON(): any;
    }
}
