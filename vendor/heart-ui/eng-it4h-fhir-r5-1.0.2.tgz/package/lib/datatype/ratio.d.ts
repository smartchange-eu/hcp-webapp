import { DataType } from '../datatype/data-type';
import { Quantity } from '../datatype/quantity';
/**
 * HAPI/FHIR <b>Ratio</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Ratio extends DataType {
    /**
     * The value of the numerator.
     *
     * Numerator value
     */
    numerator?: Quantity;
    /**
     * The value of the denominator.
     *
     * Denominator value
     */
    denominator?: Quantity;
    readonly dataType: string;
    static revive(json: any): Ratio;
    toJSON(): any;
}
