import { Coding } from '../datatype/coding';
import { DataType } from '../datatype/data-type';
/**
 * HAPI/FHIR <b>Meta</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Meta extends DataType {
    /**
     * When the resource last changed - e.g. when the version changed.
     *
     * When the resource version last changed
     */
    lastUpdated?: Date;
    /**
     * The version specific identifier, as it appears in the version portion of the URL. This value changes when the resource is created, updated, or deleted.
     *
     * Version specific identifier
     */
    versionId?: string;
    /**
     * Security labels applied to this resource. These tags connect specific resources to the overall security policy and infrastructure.
     *
     * Security Labels applied to this resource
     */
    security?: Coding[];
    /**
     * A list of profiles (references to [StructureDefinition](structuredefinition.html#) resources) that this resource claims to conform to. The URL is a reference to [StructureDefinition.url](structuredefinition-definitions.html#StructureDefinition.url).
     *
     * Profiles this resource claims to conform to
     */
    profile?: string[];
    /**
     * A uri that identifies the source system of the resource. This provides a minimal amount of [Provenance](provenance.html#) information that can be used to track or differentiate the source of information in the resource. The source may identify another FHIR server, document, message, database, etc.
     *
     * Identifies where the resource comes from
     */
    source?: string;
    /**
     * Tags applied to this resource. Tags are intended to be used to identify and relate resources to process and workflow, and applications are not required to consider the tags when interpreting the meaning of a resource.
     *
     * Tags applied to this resource
     */
    tag?: Coding[];
    readonly dataType: string;
    static revive(json: any): Meta;
    toJSON(): any;
}
