import { DataType } from '../datatype/data-type';
/**
 * HAPI/FHIR <b>BaseNarrative</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class BaseNarrative extends DataType {
    readonly dataType: string;
    static revive(json: any): BaseNarrative;
    toJSON(): any;
}
