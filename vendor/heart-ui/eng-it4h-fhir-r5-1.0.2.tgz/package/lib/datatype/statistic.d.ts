import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { BackboneType } from '../datatype/backbone-type';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { EvidenceVariable } from '../model/evidence-variable';
import { Group } from '../model/group';
/**
 * HAPI/FHIR <b>Statistic</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Statistic extends BackboneType {
    /**
     * A description of the content value of the statistic.
     *
     * Description of content
     */
    description?: string;
    /**
     * The number of participants affected where the unit of analysis is the same as sampleSize.knownDataCount and sampleSize.numberOfParticipants.
     *
     * The number of participants affected
     */
    numberAffected?: number;
    /**
     * The number of events associated with the statistic, where the unit of analysis is different from numberAffected, sampleSize.knownDataCount and sampleSize.numberOfParticipants.
     *
     * The number of events associated with the statistic
     */
    numberOfEvents?: number;
    /**
     * A statistical attribute of the statistic such as a measure of heterogeneity.
     *
     * An attribute of the Statistic
     */
    attributeEstimate?: Statistic.StatisticAttributeEstimateComponent[];
    /**
     * When the measured variable is handled categorically, the category element is used to define which category the statistic is reporting.
     *
     * Associated category for categorical variable"
     */
    category?: CodeableConcept;
    /**
     * Number of samples in the statistic.
     *
     * Number of samples in the statistic
     */
    sampleSize?: Statistic.StatisticSampleSizeComponent;
    /**
     * Statistic value.
     *
     * Statistic value
     */
    quantity?: Quantity;
    /**
     * Footnotes and/or explanatory notes.
     *
     * Footnotes and/or explanatory notes
     */
    note?: Annotation[];
    /**
     * Type of statistic, eg relative risk.
     *
     * Type of statistic, eg relative risk
     */
    statisticType?: CodeableConcept;
    /**
     * A component of the method to generate the statistic.
     *
     * Model characteristic
     */
    modelCharacteristic?: Statistic.StatisticModelCharacteristicComponent[];
    readonly dataType: string;
    static revive(json: any): Statistic;
    toJSON(): any;
}
export declare namespace Statistic {
    class StatisticModelCharacteristicVariableComponent extends BackboneElement {
        /**
         * Discrete value for grouping of ordinal or polychotomous variables.
         *
         * Discrete value for grouping of ordinal or polychotomous variables
         */
        valueQuantity?: Quantity[];
        /**
         * How the variable is classified for use in adjusted analysis.
         *
         * continuous | dichotomous | ordinal | polychotomous
         */
        handling?: string;
        /**
         * Description of the variable.
         *
         * Description of the variable
         */
        variableDefinition: Group | EvidenceVariable | Reference;
        /**
         * Range of values for grouping of ordinal or polychotomous variables.
         *
         * Range of values for grouping of ordinal or polychotomous variables
         */
        valueRange?: Range[];
        /**
         * Description for grouping of ordinal or polychotomous variables.
         *
         * Description for grouping of ordinal or polychotomous variables
         */
        valueCategory?: CodeableConcept[];
        static revive(json: any): StatisticModelCharacteristicVariableComponent;
        toJSON(): any;
    }
    class StatisticModelCharacteristicComponent extends BackboneElement {
        /**
         * A variable adjusted for in the adjusted analysis.
         *
         * A variable adjusted for in the adjusted analysis
         */
        variable?: Statistic.StatisticModelCharacteristicVariableComponent[];
        /**
         * Further specification of the quantified value of the component of the method to generate the statistic.
         *
         * Numerical value to complete model specification
         */
        value?: Quantity;
        /**
         * Description of a component of the method to generate the statistic.
         *
         * Model specification
         */
        code: CodeableConcept;
        static revive(json: any): StatisticModelCharacteristicComponent;
        toJSON(): any;
    }
    class StatisticAttributeEstimateAttributeEstimateComponent extends BackboneElement {
        /**
         * The singular quantity of the attribute estimate, for attribute estimates represented as single values; also used to report unit of measure.
         *
         * The singular quantity of the attribute estimate, for attribute estimates represented as single values; also used to report unit of measure
         */
        quantity?: Quantity;
        /**
         * Footnote or explanatory note about the estimate.
         *
         * Footnote or explanatory note about the estimate
         */
        note?: Annotation[];
        /**
         * Use 95 for a 95% confidence interval.
         *
         * Level of confidence interval, eg 0.95 for 95% confidence interval
         */
        level?: number;
        /**
         * Human-readable summary of the estimate.
         *
         * Textual description of the attribute estimate
         */
        description?: string;
        /**
         * Lower bound of confidence interval.
         *
         * Lower and upper bound values of the attribute estimate
         */
        range?: Range;
        /**
         * The type of attribute estimate, eg confidence interval or p value.
         *
         * The type of attribute estimate, eg confidence interval or p value
         */
        type?: CodeableConcept;
        static revive(json: any): StatisticAttributeEstimateAttributeEstimateComponent;
        toJSON(): any;
    }
    class StatisticAttributeEstimateComponent extends BackboneElement {
        /**
         * Human-readable summary of the estimate.
         *
         * Textual description of the attribute estimate
         */
        description?: string;
        /**
         * Lower bound of confidence interval.
         *
         * Lower and upper bound values of the attribute estimate
         */
        range?: Range;
        /**
         * A nested attribute estimate; which is the attribute estimate of an attribute estimate.
         *
         * A nested attribute estimate; which is the attribute estimate of an attribute estimate
         */
        attributeEstimate?: Statistic.StatisticAttributeEstimateAttributeEstimateComponent[];
        /**
         * The type of attribute estimate, eg confidence interval or p value.
         *
         * The type of attribute estimate, eg confidence interval or p value
         */
        type?: CodeableConcept;
        /**
         * The singular quantity of the attribute estimate, for attribute estimates represented as single values; also used to report unit of measure.
         *
         * The singular quantity of the attribute estimate, for attribute estimates represented as single values; also used to report unit of measure
         */
        quantity?: Quantity;
        /**
         * Footnote or explanatory note about the estimate.
         *
         * Footnote or explanatory note about the estimate
         */
        note?: Annotation[];
        /**
         * Use 95 for a 95% confidence interval.
         *
         * Level of confidence interval, eg 0.95 for 95% confidence interval
         */
        level?: number;
        static revive(json: any): StatisticAttributeEstimateComponent;
        toJSON(): any;
    }
    class StatisticSampleSizeComponent extends BackboneElement {
        /**
         * A human-readable string to clarify or explain concepts about the sample size.
         *
         * Cumulative number of participants
         */
        numberOfParticipants?: number;
        /**
         * Footnote or explanatory note about the sample size.
         *
         * Footnote or explanatory note about the sample size
         */
        note?: Annotation[];
        /**
         * Number of participants with known results for measured variables.
         *
         * Number of participants with known results for measured variables
         */
        knownDataCount?: number;
        /**
         * Human-readable summary of population sample size.
         *
         * Textual description of sample size for statistic
         */
        description?: string;
        /**
         * Number of participants in the population.
         *
         * Number of contributing studies
         */
        numberOfStudies?: number;
        static revive(json: any): StatisticSampleSizeComponent;
        toJSON(): any;
    }
}
