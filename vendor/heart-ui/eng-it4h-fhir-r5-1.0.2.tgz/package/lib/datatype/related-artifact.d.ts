import { Reference } from '../datatype/reference';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { DataType } from '../datatype/data-type';
/**
 * HAPI/FHIR <b>RelatedArtifact</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class RelatedArtifact extends DataType {
    /**
     * The publication status of the artifact being referred to.
     *
     * draft | active | retired | unknown
     */
    publicationStatus?: string;
    /**
     * A bibliographic citation for the related artifact. This text SHOULD be formatted according to an accepted citation format.
     *
     * Bibliographic citation for the artifact
     */
    citation?: string;
    /**
     * The related artifact, such as a library, value set, profile, or other knowledge resource.
     *
     * What artifact is being referenced
     */
    resource?: string;
    /**
     * A brief description of the document or knowledge resource being referenced, suitable for display to a consumer.
     *
     * Brief description of the related artifact
     */
    display?: string;
    /**
     * The document being referenced, represented as an attachment. This is exclusive with the resource element.
     *
     * What document is being referenced
     */
    document?: Attachment;
    /**
     * Provides additional classifiers of the related artifact.
     *
     * Additional classifiers
     */
    classifier?: CodeableConcept[];
    /**
     * A short label that can be used to reference the citation from elsewhere in the containing artifact, such as a footnote index.
     *
     * Short label
     */
    label?: string;
    /**
     * The type of relationship to the related artifact.
     *
     * documentation | justification | citation | predecessor | successor | derived-from | depends-on | composed-of | part-of | amends | amended-with | appends | appended-with | cites | cited-by | comments-on | comment-in | contains | contained-in | corrects | correction-in | replaces | replaced-with | retracts | retracted-by | signs | similar-to | supports | supported-with | transforms | transformed-into | transformed-with | documents | specification-of | created-with | cite-as
     */
    type: string;
    /**
     * The date of publication of the artifact being referred to.
     *
     * Date of publication of the artifact being referred to
     */
    publicationDate?: Date;
    /**
     * The related artifact, if the artifact is not a canonical resource, or a resource reference to a canonical resource.
     *
     * What artifact, if not a conformance resource
     */
    resourceReference?: Reference;
    readonly dataType: string;
    static revive(json: any): RelatedArtifact;
    toJSON(): any;
}
export declare namespace RelatedArtifact {
    enum RelatedArtifactType {
        CITATION,
        REPLACES,
        DOCUMENTATION,
        SIMILARTO,
        CORRECTS,
        SIGNS,
        SUPPORTEDWITH,
        DERIVEDFROM,
        SUPPORTS,
        CITEAS,
        CONTAINEDIN,
        CONTAINS,
        TRANSFORMEDINTO,
        DOCUMENTS,
        CITES,
        SPECIFICATIONOF,
        COMMENTSON,
        REPLACEDWITH,
        APPENDEDWITH,
        COMMENTIN,
        NULL,
        AMENDS,
        COMPOSEDOF,
        PARTOF,
        JUSTIFICATION,
        CORRECTIONIN,
        RETRACTS,
        AMENDEDWITH,
        CITEDBY,
        APPENDS,
        SUCCESSOR,
        PREDECESSOR,
        DEPENDSON,
        RETRACTEDBY,
        TRANSFORMEDWITH,
        CREATEDWITH,
        TRANSFORMS
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
}
