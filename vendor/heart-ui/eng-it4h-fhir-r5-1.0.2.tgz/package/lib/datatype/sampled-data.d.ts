import { DataType } from '../datatype/data-type';
import { Quantity } from '../datatype/quantity';
/**
 * HAPI/FHIR <b>SampledData</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class SampledData extends DataType {
    /**
     * The lower limit of detection of the measured points. This is needed if any of the data points have the value "L" (lower than detection limit).
     *
     * Lower limit of detection
     */
    lowerLimit?: number;
    /**
     * Amount of intervalUnits between samples, e.g. milliseconds for time-based sampling.
     *
     * Number of intervalUnits between samples
     */
    interval?: number;
    /**
     * The upper limit of detection of the measured points. This is needed if any of the data points have the value "U" (higher than detection limit).
     *
     * Upper limit of detection
     */
    upperLimit?: number;
    /**
     * The number of sample points at each time point. If this value is greater than one, then the dimensions will be interlaced - all the sample points for a point in time will be recorded at once.
     *
     * Number of sample points at each time point
     */
    dimensions: number;
    /**
     * A correction factor that is applied to the sampled data points before they are added to the origin.
     *
     * Multiply data by this before adding to origin
     */
    factor?: number;
    /**
     * Reference to ConceptMap that defines the codes used in the data.
     *
     * Defines the codes used in the data
     */
    codeMap?: string;
    /**
     * The base quantity that a measured value of zero represents. In addition, this provides the units of the entire measurement series.
     *
     * Zero value and units
     */
    origin: Quantity;
    /**
     * The measurement unit in which the sample interval is expressed.
     *
     * The measurement unit of the interval between samples
     */
    intervalUnit: string;
    /**
     * A series of data points which are decimal values separated by a single space (character u20).  The units in which the offsets are expressed are found in intervalUnit.  The absolute point at which the measurements begin SHALL be conveyed outside the scope of this datatype, e.g. Observation.effectiveDateTime for a timing offset.
     *
     * Offsets, typically in time, at which data values were taken
     */
    offsets?: string;
    /**
     * A series of data points which are decimal values or codes separated by a single space (character u20). The special codes "E" (error), "L" (below detection limit) and "U" (above detection limit) are also defined for used in place of decimal values.
     *
     * Decimal values with spaces, or "E" | "U" | "L", or another code
     */
    data?: string;
    readonly dataType: string;
    dataToArray(): any[];
    static revive(json: any): SampledData;
    toJSON(): any;
}
