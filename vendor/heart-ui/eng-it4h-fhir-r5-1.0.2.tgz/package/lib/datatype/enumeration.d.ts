import { PrimitiveType } from '../datatype/primitive-type';
/**
 * HAPI/FHIR <b>Enumeration</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export interface Enumeration extends PrimitiveType {
}
