import { Extension } from '../datatype/extension';
import { DataType } from '../datatype/data-type';
/**
 * HAPI/FHIR <b>Attachment</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Attachment extends DataType {
    /**
     * CUSTOM for externalized data contents
     */
    _data?: {
        extension: Extension[];
    };
    /**
     * The actual data of the attachment - a sequence of bytes, base64 encoded.
     *
     * Data inline, base64ed
     */
    data?: string;
    /**
     * The number of frames in a photo. This is used with a multi-page fax, or an imaging acquisition context that takes multiple slices in a single image, or an animated gif. If there is more than one frame, this SHALL have a value in order to alert interface software that a multi-frame capable rendering widget is required.
     *
     * Number of frames if > 1 (photo)
     */
    frames?: number;
    /**
     * The human language of the content. The value can be any valid value according to BCP 47.
     *
     * Human language of the content (BCP-47)
     */
    language?: string;
    /**
     * A label or set of text to display in place of the data.
     *
     * Label to display in place of the data
     */
    title?: string;
    /**
     * A location where the data can be accessed.
     *
     * Uri where the data can be found
     */
    url?: string;
    /**
     * The duration of the recording in seconds - for audio and video.
     *
     * Length in seconds (audio / video)
     */
    duration?: number;
    /**
     * The number of pages when printed.
     *
     * Number of printed pages
     */
    pages?: number;
    /**
     * The number of bytes of data that make up this attachment (before base64 encoding, if that is done).
     *
     * Number of bytes of content (if url provided)
     */
    size?: any;
    /**
     * Width of the image in pixels (photo/video).
     *
     * Width of the image in pixels (photo/video)
     */
    width?: number;
    /**
     * Identifies the type of the data in the attachment and allows a method to be chosen to interpret or render the data. Includes mime type parameters such as charset where appropriate.
     *
     * Mime type of the content, with charset etc.
     */
    contentType?: string;
    /**
     * The calculated hash of the data using SHA-1. Represented using base64.
     *
     * Hash of the data (sha-1, base64ed)
     */
    hash?: string;
    /**
     * The date that the attachment was first created.
     *
     * Date attachment was first created
     */
    creation?: Date;
    /**
     * Height of the image in pixels (photo/video).
     *
     * Height of the image in pixels (photo/video)
     */
    height?: number;
    readonly dataType: string;
    static revive(json: any): Attachment;
    toJSON(): any;
}
