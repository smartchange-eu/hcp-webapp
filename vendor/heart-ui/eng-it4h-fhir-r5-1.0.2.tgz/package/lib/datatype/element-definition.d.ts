import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Address } from '../datatype/address';
import { Age } from '../datatype/age';
import { Annotation } from '../datatype/annotation';
import { Attachment } from '../datatype/attachment';
import { Availability } from '../datatype/availability';
import { BackboneType } from '../datatype/backbone-type';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { ContactPoint } from '../datatype/contact-point';
import { Count } from '../datatype/count';
import { DataRequirement } from '../datatype/data-requirement';
import { Distance } from '../datatype/distance';
import { Dosage } from '../datatype/dosage';
import { Duration } from '../datatype/duration';
import { Expression } from '../datatype/expression';
import { ExtendedContactDetail } from '../datatype/extended-contact-detail';
import { HumanName } from '../datatype/human-name';
import { Identifier } from '../datatype/identifier';
import { Meta } from '../datatype/meta';
import { Money } from '../datatype/money';
import { ParameterDefinition } from '../datatype/parameter-definition';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { Ratio } from '../datatype/ratio';
import { RatioRange } from '../datatype/ratio-range';
import { RelatedArtifact } from '../datatype/related-artifact';
import { SampledData } from '../datatype/sampled-data';
import { Signature } from '../datatype/signature';
import { Timing } from '../datatype/timing';
import { TriggerDefinition } from '../datatype/trigger-definition';
import { UsageContext } from '../datatype/usage-context';
/**
 * HAPI/FHIR <b>ElementDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class ElementDefinition extends BackboneType {
    /**
     * A single preferred label which is the text to display beside the element indicating its meaning or to use to prompt for the element in a user display or form.
     *
     * Name for element to display with or prompt for element
     */
    label?: string;
    /**
     * Specifies a list of extensions that can appear in place of a primitive value.
     *
     * Extensions that are allowed to replace a primitive value
     */
    valueAlternatives?: string[];
    /**
     * Whether the element should be included if a client requests a search with the parameter _summary=true.
     *
     * Include when _summary = true?
     */
    isSummary?: boolean;
    /**
     * The maximum number of times this element is permitted to appear in the instance.
     *
     * Maximum Cardinality (a number or *)
     */
    max?: string;
    /**
     * If true, implementations that produce or consume resources SHALL provide "support" for the element in some meaningful way. Note that this is being phased out and replaced by obligations (see below).  If false, the element may be ignored and not supported. If false, whether to populate or use the data element in any way is at the discretion of the implementation.
     *
     * If the element must be supported (discouraged - see obligations)
     */
    mustSupport?: boolean;
    /**
     * The maximum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.
     *
     * Maximum Allowed Value (for some types)
     */
    maxValue?: Date | Date | Date | number | number | number | number | Quantity;
    /**
     * If true, the value of this element affects the interpretation of the element or resource that contains it, and the value of the element cannot be ignored. Typically, this is used for status, negation and qualification codes. The effect of this is that the element cannot be ignored by systems: they SHALL either recognize the element and process it, and/or a pre-determination has been made that it is not relevant to their particular system. When used on the root element in an extension definition, this indicates whether or not the extension is a modifier extension.
     *
     * If this modifies the meaning of other elements
     */
    isModifier?: boolean;
    /**
     * Indicates that the element is sliced into a set of alternative definitions (i.e. in a structure definition, there are multiple different constraints on a single element in the base resource). Slicing can be used in any resource that has cardinality ..* on the base resource, or any resource with a choice of types. The set of slices is any elements that come after this in the element sequence that have the same path, until a shorter path occurs (the shorter path terminates the set).
     *
     * This element is sliced - slices follow
     */
    slicing?: ElementDefinition.ElementDefinitionSlicingComponent;
    /**
     * This element is for traceability of why the element was created and why the constraints exist as they do. This may be used to point to source materials or specifications that drove the structure of this element.
     *
     * Why this resource has been created
     */
    requirements?: string;
    /**
     * Identifies a concept from an external specification that roughly corresponds to this element.
     *
     * Map element to another set of definitions
     */
    mapping?: ElementDefinition.ElementDefinitionMappingComponent[];
    /**
     * Explains how that element affects the interpretation of the resource or element that contains it.
     *
     * Reason that this element is marked as a modifier
     */
    isModifierReason?: string;
    /**
     * The Implicit meaning that is to be understood when this element is missing (e.g. 'when this element is missing, the period is ongoing').
     *
     * Implicit meaning when this element is missing
     */
    meaningWhenMissing?: string;
    /**
     * Information about the base definition of the element, provided to make it unnecessary for tools to trace the deviation of the element through the derived and related profiles. When the element definition is not the original definition of an element - e.g. either in a constraint on another type, or for elements from a super type in a snap shot - then the information in provided in the element definition may be different to the base definition. On the original definition of the element, it will be same.
     *
     * Base definition information for tools
     */
    base?: ElementDefinition.ElementDefinitionBaseComponent;
    /**
     * Indicates the maximum length in characters that is permitted to be present in conformant instances and which is expected to be supported by conformant consumers that support the element. ```maxLength``` SHOULD only be used on primitive data types that have a string representation (see [http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics](https://build.fhir.org/ig/HL7/fhir-extensions/StructureDefinition-structuredefinition-type-characteristics.html)).
     *
     * Max length for string type data
     */
    maxLength?: number;
    /**
     * Explanatory notes and implementation guidance about the data element, including notes about how to use the data properly, exceptions to proper use, etc. (Note: The text you are reading is specified in ElementDefinition.comment).
     *
     * Comments about the use of this element
     */
    comment?: string;
    /**
     * Specifies a value that SHALL be exactly the value  for this element in the instance, if present. For purposes of comparison, non-significant whitespace is ignored, and all values must be an exact match (case and accent sensitive). Missing elements/attributes must also be missing.
     *
     * Value must be exactly this
     */
    fixed?: string | boolean | Date | Date | number | number | number | Date | number | Address | Age | Annotation | Attachment | CodeableConcept | CodeableReference | Coding | ContactPoint | Count | Distance | Duration | HumanName | Identifier | Money | Period | Quantity | Range | Ratio | RatioRange | Reference | SampledData | Signature | Timing | ContactDetail | DataRequirement | Expression | ParameterDefinition | RelatedArtifact | TriggerDefinition | UsageContext | Availability | ExtendedContactDetail | Dosage | Meta;
    /**
     * Formal constraints such as co-occurrence and other constraints that can be computationally evaluated within the context of the instance.
     *
     * Condition that must evaluate to true
     */
    constraint?: ElementDefinition.ElementDefinitionConstraintComponent[];
    /**
     * Identifies an element defined elsewhere in the definition whose content rules should be applied to the current element. ContentReferences bring across all the rules that are in the ElementDefinition for the element, including definitions, cardinality constraints, bindings, invariants etc.
     *
     * Reference to definition of content for the element
     */
    contentReference?: string;
    /**
     * If present, indicates that the order of the repeating element has meaning and describes what that meaning is.  If absent, it means that the order of the element has no meaning.
     *
     * What the order of the elements means
     */
    orderMeaning?: string;
    /**
     * The name of this element definition slice, when slicing is working. The name must be a token with no dots or spaces. This is a unique name referring to a specific set of constraints applied to this element, used to provide a name to different slices of the same element.
     *
     * Name for this particular element (in a set of slices)
     */
    sliceName?: string;
    /**
     * A reference to an invariant that may make additional statements about the cardinality or value in the instance.
     *
     * Reference to invariant about presence
     */
    condition?: string[];
    /**
     * Codes that define how this element is represented in instances, when the deviation varies from the normal case. No extensions are allowed on elements with a representation of 'xmlAttr', no matter what FHIR serialization format is used.
     *
     * xmlAttr | xmlText | typeAttr | cdaText | xhtml
     */
    representation?: string[];
    /**
     * The data type or resource that the value of this element is permitted to be.
     *
     * Data type and Profile for this element
     */
    type?: ElementDefinition.TypeRefComponent[];
    /**
     * A sample value for this element demonstrating the type of information that would typically be found in the element.
     *
     * Example value (as defined for type)
     */
    example?: ElementDefinition.ElementDefinitionExampleComponent[];
    /**
     * Binds to a value set if this element is coded (code, Coding, CodeableConcept, Quantity), or the data types (string, uri).
     *
     * ValueSet details if this is coded
     */
    binding?: ElementDefinition.ElementDefinitionBindingComponent;
    /**
     * A concise description of what this element means (e.g. for use in autogenerated summaries).
     *
     * Concise definition for space-constrained presentation
     */
    short?: string;
    /**
     * Specifies a value that each occurrence of the element in the instance SHALL follow - that is, any value in the pattern must be found in the instance, if the element has a value. Other additional values may be found too. This is effectively constraint by example.

When pattern[x] is used to constrain a primitive, it means that the value provided in the pattern[x] must match the instance value exactly.

When an element within a pattern[x] is used to constrain an array, it means that each element provided in the pattern[x] must (recursively) match at least one element from the instance array.

When pattern[x] is used to constrain a complex object, it means that each property in the pattern must be present in the complex object, and its value must recursively match -- i.e.,

1. If primitive: it must match exactly the pattern value
2. If a complex object: it must match (recursively) the pattern value
3. If an array: it must match (recursively) the pattern value

If a pattern[x] is declared on a repeating element, the pattern applies to all repetitions.  If the desire is for a pattern to apply to only one element or a subset of elements, slicing must be used. See [Examples of Patterns](elementdefinition-examples.html#pattern-examples) for examples of pattern usage and the effect it will have.
     *
     * Value must have at least these property values
     */
    pattern?: string | boolean | Date | Date | number | number | number | Date | number | Address | Age | Annotation | Attachment | CodeableConcept | CodeableReference | Coding | ContactPoint | Count | Distance | Duration | HumanName | Identifier | Money | Period | Quantity | Range | Ratio | RatioRange | Reference | SampledData | Signature | Timing | ContactDetail | DataRequirement | Expression | ParameterDefinition | RelatedArtifact | TriggerDefinition | UsageContext | Availability | ExtendedContactDetail | Dosage | Meta;
    /**
     * The value that should be used if there is no value stated in the instance (e.g. 'if not otherwise specified, the abstract is false').
     *
     * Specified value if missing from instance
     */
    defaultValue?: string | boolean | Date | Date | number | number | number | Date | number | Address | Age | Annotation | Attachment | CodeableConcept | CodeableReference | Coding | ContactPoint | Count | Distance | Duration | HumanName | Identifier | Money | Period | Quantity | Range | Ratio | RatioRange | Reference | SampledData | Signature | Timing | ContactDetail | DataRequirement | Expression | ParameterDefinition | RelatedArtifact | TriggerDefinition | UsageContext | Availability | ExtendedContactDetail | Dosage | Meta;
    /**
     * A code that has the same meaning as the element in a particular terminology.
     *
     * Corresponding codes in terminologies
     */
    code?: Coding[];
    /**
     * If true, indicates that this slice definition is constraining a slice definition with the same name in an inherited profile. If false, the slice is not overriding any slice in an inherited profile. If missing, the slice might or might not be overriding a slice in an inherited profile, depending on the sliceName.
     *
     * If this slice definition constrains an inherited slice definition (or not)
     */
    sliceIsConstraining?: boolean;
    /**
     * Identifies additional names by which this element might also be known.
     *
     * Other names
     */
    alias?: string[];
    /**
     * Provides a complete explanation of the meaning of the data element for human readability.  For the case of elements derived from existing elements (e.g. constraints), the definition SHALL be consistent with the base definition, but convey the meaning of the element in the particular context of use of the resource. (Note: The text you are reading is specified in ElementDefinition.definition).
     *
     * Full formal definition as narrative text
     */
    definition?: string;
    /**
     * The path identifies the element and is expressed as a "."-separated list of ancestor elements, beginning with the name of the resource or extension.
     *
     * Path of the element in the hierarchy of elements
     */
    path: string;
    /**
     * Specifies for a primitive data type that the value of the data type cannot be replaced by an extension.
     *
     * For primitives, that a value must be present - not replaced by an extension
     */
    mustHaveValue?: boolean;
    /**
     * The minimum number of times this element SHALL appear in the instance.
     *
     * Minimum Cardinality
     */
    min?: number;
    /**
     * The minimum allowed value for the element. The value is inclusive. This is allowed for the types date, dateTime, instant, time, decimal, integer, and Quantity.
     *
     * Minimum Allowed Value (for some types)
     */
    minValue?: Date | Date | Date | number | number | number | number | Quantity;
    readonly dataType: string;
    static revive(json: any): ElementDefinition;
    toJSON(): any;
}
export declare namespace ElementDefinition {
    enum SlicingRules {
        OPENATEND,
        NULL,
        CLOSED,
        OPEN
    }
    enum ReferenceVersionRules {
        NULL,
        SPECIFIC,
        INDEPENDENT,
        EITHER
    }
    enum PropertyRepresentation {
        NULL,
        TYPEATTR,
        XHTML,
        XMLTEXT,
        CDATEXT,
        XMLATTR
    }
    enum DiscriminatorType {
        POSITION,
        PROFILE,
        NULL,
        EXISTS,
        PATTERN,
        VALUE,
        TYPE
    }
    enum ConstraintSeverity {
        NULL,
        ERROR,
        WARNING
    }
    enum AggregationMode {
        BUNDLED,
        NULL,
        CONTAINED,
        REFERENCED
    }
    enum AdditionalBindingPurposeVS {
        MINIMUM,
        NULL,
        UI,
        MAXIMUM,
        PREFERRED,
        REQUIRED,
        STARTER,
        CANDIDATE,
        COMPONENT,
        EXTENSIBLE,
        CURRENT
    }
    class ElementDefinitionMappingComponent extends BackboneElement {
        /**
         * An internal reference to the definition of a mapping.
         *
         * Reference to mapping declaration
         */
        identity: string;
        /**
         * Expresses what part of the target specification corresponds to this element.
         *
         * Details of the mapping
         */
        map: string;
        /**
         * Identifies the computable language in which mapping.map is expressed.
         *
         * Computable language of mapping
         */
        language?: string;
        /**
         * Comments that provide information about the mapping or its use.
         *
         * Comments about the mapping or its use
         */
        comment?: string;
        static revive(json: any): ElementDefinitionMappingComponent;
        toJSON(): any;
    }
    class ElementDefinitionBindingAdditionalComponent extends BackboneElement {
        /**
         * Whether the binding applies to all repeats, or just to any one of them. This is only relevant for elements that can repeat.
         *
         * Whether binding can applies to all repeats, or just one
         */
        any?: boolean;
        /**
         * The valueSet that is being bound for the purpose.
         *
         * The value set for the additional binding
         */
        valueSet: string;
        /**
         * Concise documentation - for summary tables.
         *
         * Concise documentation - for summary tables
         */
        shortDoco?: string;
        /**
         * The use of this additional binding.
         *
         * maximum | minimum | required | extensible | candidate | current | preferred | ui | starter | component
         */
        purpose: string;
        /**
         * Documentation of the purpose of use of the bindingproviding additional information about how it is intended to be used.
         *
         * Documentation of the purpose of use of the binding
         */
        documentation?: string;
        /**
         * Qualifies the usage of the binding. Typically bindings are qualified by jurisdiction, but they may also be qualified by gender, workflow status, clinical domain etc. The information to decide whether a usege context applies is usually outside the resource, determined by context, and this might present challenges for validation tooling.
         *
         * Qualifies the usage - jurisdiction, gender, workflow status etc.
         */
        usage?: UsageContext[];
        static revive(json: any): ElementDefinitionBindingAdditionalComponent;
        toJSON(): any;
    }
    class ElementDefinitionBindingComponent extends BackboneElement {
        /**
         * Describes the intended use of this particular set of codes.
         *
         * Intended use of codes in the bound value set
         */
        description?: string;
        /**
         * Refers to the value set that identifies the set of codes the binding refers to.
         *
         * Source of value set
         */
        valueSet?: string;
        /**
         * Indicates the degree of conformance expectations associated with this binding - that is, the degree to which the provided value set must be adhered to in the instances.
         *
         * required | extensible | preferred | example
         */
        strength: string;
        /**
         * Additional bindings that help applications implementing this element. Additional bindings do not replace the main binding but provide more information and/or context.
         *
         * Additional Bindings - more rules about the binding
         */
        additional?: ElementDefinition.ElementDefinitionBindingAdditionalComponent[];
        static revive(json: any): ElementDefinitionBindingComponent;
        toJSON(): any;
    }
    class ElementDefinitionConstraintComponent extends BackboneElement {
        /**
         * If true, indicates that the warning or best practice guideline should be suppressed.
         *
         * Suppress warning or hint in profile
         */
        suppress?: boolean;
        /**
         * A reference to the original source of the constraint, for traceability purposes.
         *
         * Reference to original source of constraint
         */
        source?: string;
        /**
         * Allows identification of which elements have their cardinalities impacted by the constraint.  Will not be referenced for constraints that do not affect cardinality.
         *
         * Target of 'condition' reference above
         */
        key: string;
        /**
         * Text that can be used to describe the constraint in messages identifying that the constraint has been violated.
         *
         * Human description of constraint
         */
        human: string;
        /**
         * Description of why this constraint is necessary or appropriate.
         *
         * Why this constraint is necessary or appropriate
         */
        requirements?: string;
        /**
         * A [FHIRPath](fhirpath.html) expression of constraint that can be executed to see if this constraint is met.
         *
         * FHIRPath expression of constraint
         */
        expression?: string;
        /**
         * Identifies the impact constraint violation has on the conformance of the instance.
         *
         * error | warning
         */
        severity: string;
        static revive(json: any): ElementDefinitionConstraintComponent;
        toJSON(): any;
    }
    class ElementDefinitionExampleComponent extends BackboneElement {
        /**
         * Describes the purpose of this example among the set of examples.
         *
         * Describes the purpose of this example
         */
        label: string;
        /**
         * The actual value for the element, which must be one of the types allowed for this element.
         *
         * Value of Example (one of allowed types)
         */
        value: string | boolean | Date | Date | number | number | number | Date | number | Address | Age | Annotation | Attachment | CodeableConcept | CodeableReference | Coding | ContactPoint | Count | Distance | Duration | HumanName | Identifier | Money | Period | Quantity | Range | Ratio | RatioRange | Reference | SampledData | Signature | Timing | ContactDetail | DataRequirement | Expression | ParameterDefinition | RelatedArtifact | TriggerDefinition | UsageContext | Availability | ExtendedContactDetail | Dosage | Meta;
        static revive(json: any): ElementDefinitionExampleComponent;
        toJSON(): any;
    }
    class TypeRefComponent extends BackboneElement {
        /**
         * URL of Data type or Resource that is a(or the) type used for this element. References are URLs that are relative to http://hl7.org/fhir/StructureDefinition e.g. "string" is a reference to http://hl7.org/fhir/StructureDefinition/string. Absolute URLs are only allowed in logical models.
         *
         * Data type or Resource (reference to definition)
         */
        code: string;
        /**
         * Whether this reference needs to be version specific or version independent, or whether either can be used.
         *
         * either | independent | specific
         */
        versioning?: string;
        /**
         * Identifies a profile structure or implementation Guide that applies to the datatype this element refers to. If any profiles are specified, then the content must conform to at least one of them. The URL can be a local reference - to a contained StructureDefinition, or a reference to another StructureDefinition or Implementation Guide by a canonical URL. When an implementation guide is specified, the type SHALL conform to at least one profile defined in the implementation guide.
         *
         * Profiles (StructureDefinition or IG) - one must apply
         */
        profile?: string[];
        /**
         * If the type is a reference to another resource, how the resource is or can be aggregated - is it a contained resource, or a reference, and if the context is a bundle, is it included in the bundle.
         *
         * contained | referenced | bundled - how aggregated
         */
        aggregation?: string[];
        /**
         * Used when the type is "Reference" or "canonical", and identifies a profile structure or implementation Guide that applies to the target of the reference this element refers to. If any profiles are specified, then the content must conform to at least one of them. The URL can be a local reference - to a contained StructureDefinition, or a reference to another StructureDefinition or Implementation Guide by a canonical URL. When an implementation guide is specified, the target resource SHALL conform to at least one profile defined in the implementation guide.
         *
         * Profile (StructureDefinition or IG) on the Reference/canonical target - one must apply
         */
        targetProfile?: string[];
        static revive(json: any): TypeRefComponent;
        toJSON(): any;
    }
    class ElementDefinitionBaseComponent extends BackboneElement {
        /**
         * Maximum cardinality of the base element identified by the path.
         *
         * Max cardinality of the base element
         */
        max: string;
        /**
         * The Path that identifies the base element - this matches the ElementDefinition.path for that element. Across FHIR, there is only one base definition of any element - that is, an element definition on a [StructureDefinition](structuredefinition.html#) without a StructureDefinition.base.
         *
         * Path that identifies the base element
         */
        path: string;
        /**
         * Minimum cardinality of the base element identified by the path.
         *
         * Min cardinality of the base element
         */
        min: number;
        static revive(json: any): ElementDefinitionBaseComponent;
        toJSON(): any;
    }
    class ElementDefinitionSlicingDiscriminatorComponent extends BackboneElement {
        /**
         * A FHIRPath expression, using [the simple subset of FHIRPath](fhirpath.html#simple), that is used to identify the element on which discrimination is based.
         *
         * Path to element value
         */
        path: string;
        /**
         * How the element value is interpreted when discrimination is evaluated.
         *
         * value | exists | type | profile | position
         */
        type: string;
        static revive(json: any): ElementDefinitionSlicingDiscriminatorComponent;
        toJSON(): any;
    }
    class ElementDefinitionSlicingComponent extends BackboneElement {
        /**
         * If the matching elements have to occur in the same order as defined in the profile.
         *
         * If elements must be in same order as slices
         */
        ordered?: boolean;
        /**
         * Designates which child elements are used to discriminate between the slices when processing an instance. If one or more discriminators are provided, the value of the child elements in the instance data SHALL completely distinguish which slice the element in the resource matches based on the allowed values for those elements in each of the slices.
         *
         * Element values that are used to distinguish the slices
         */
        discriminator?: ElementDefinition.ElementDefinitionSlicingDiscriminatorComponent[];
        /**
         * A human-readable text description of how the slicing works. If there is no discriminator, this is required to be present to provide whatever information is possible about how the slices can be differentiated.
         *
         * Text description of how slicing works (or not)
         */
        description?: string;
        /**
         * Whether additional slices are allowed or not. When the slices are ordered, profile authors can also say that additional slices are only allowed at the end.
         *
         * closed | open | openAtEnd
         */
        rules: string;
        static revive(json: any): ElementDefinitionSlicingComponent;
        toJSON(): any;
    }
}
