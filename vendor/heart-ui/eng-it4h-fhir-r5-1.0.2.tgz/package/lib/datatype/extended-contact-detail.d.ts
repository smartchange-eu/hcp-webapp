import { Reference } from '../datatype/reference';
import { Address } from '../datatype/address';
import { CodeableConcept } from '../datatype/codeable-concept';
import { ContactPoint } from '../datatype/contact-point';
import { DataType } from '../datatype/data-type';
import { HumanName } from '../datatype/human-name';
import { Period } from '../datatype/period';
import { Organization } from '../model/organization';
/**
 * HAPI/FHIR <b>ExtendedContactDetail</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class ExtendedContactDetail extends DataType {
    /**
     * This contact detail is handled/monitored by a specific organization. If the name is provided in the contact, then it is referring to the named individual within this organization.
     *
     * This contact detail is handled/monitored by a specific organization
     */
    organization?: Organization | Reference;
    /**
     * The purpose/type of contact.
     *
     * The type of contact
     */
    purpose?: CodeableConcept;
    /**
     * Period that this contact was valid for usage.
     *
     * Period that this contact was valid for usage
     */
    period?: Period;
    /**
     * Address for the contact.
     *
     * Address for the contact
     */
    address?: Address;
    /**
     * The contact details application for the purpose defined.
     *
     * Contact details (e.g.phone/fax/url)
     */
    telecom?: ContactPoint[];
    /**
     * The name of an individual to contact, some types of contact detail are usually blank.
     *
     * Name of an individual to contact
     */
    name?: HumanName[];
    readonly dataType: string;
    static revive(json: any): ExtendedContactDetail;
    toJSON(): any;
}
