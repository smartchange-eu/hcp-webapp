import { BaseNarrative } from '../datatype/base-narrative';
/**
 * HAPI/FHIR <b>Narrative</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Narrative extends BaseNarrative {
    /**
     * The status of the narrative - whether it's entirely generated (from just the defined data or the extensions too), or whether a human authored it and it may contain additional data.
     *
     * generated | extensions | additional | empty
     */
    status: string;
    /**
     * The actual narrative content, a stripped down version of XHTML.
     *
     * Limited xhtml content
     */
    div: any;
    readonly dataType: string;
    static revive(json: any): Narrative;
    toJSON(): any;
}
export declare namespace Narrative {
    enum NarrativeStatus {
        NULL,
        EXTENSIONS,
        GENERATED,
        ADDITIONAL,
        EMPTY
    }
}
