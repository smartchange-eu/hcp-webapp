import { DataType } from '../datatype/data-type';
import { Quantity } from '../datatype/quantity';
/**
 * HAPI/FHIR <b>RatioRange</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class RatioRange extends DataType {
    /**
     * The value of the low limit numerator.
     *
     * Low Numerator limit
     */
    lowNumerator?: Quantity;
    /**
     * The value of the high limit numerator.
     *
     * High Numerator limit
     */
    highNumerator?: Quantity;
    /**
     * The value of the denominator.
     *
     * Denominator value
     */
    denominator?: Quantity;
    readonly dataType: string;
    static revive(json: any): RatioRange;
    toJSON(): any;
}
