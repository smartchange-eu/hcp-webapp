import { Coding } from '../datatype/coding';
import { DataType } from '../datatype/data-type';
/**
 * HAPI/FHIR <b>CodeableConcept</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class CodeableConcept extends DataType {
    /**
     * A reference to a code defined by a terminology system.
     *
     * Code defined by a terminology system
     */
    coding?: Coding[];
    /**
     * A human language representation of the concept as seen/selected/uttered by the user who entered the data and/or which represents the intended meaning of the user.
     *
     * Plain text representation of the concept
     */
    text?: string;
    readonly dataType: string;
    static revive(json: any): CodeableConcept;
    toJSON(): any;
}
