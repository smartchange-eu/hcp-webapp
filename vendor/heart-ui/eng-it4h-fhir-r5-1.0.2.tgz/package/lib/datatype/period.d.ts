import { DataType } from '../datatype/data-type';
/**
 * HAPI/FHIR <b>Period</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Period extends DataType {
    /**
     * The end of the period. If the end of the period is missing, it means no end was known or planned at the time the instance was created. The start may be in the past, and the end date in the future, which means that period is expected/planned to end at that time.
     *
     * End time with inclusive boundary, if not ongoing
     */
    end?: Date;
    /**
     * The start of the period. The boundary is inclusive.
     *
     * Starting time with inclusive boundary
     */
    start?: Date;
    readonly dataType: string;
    static revive(json: any): Period;
    toJSON(): any;
}
