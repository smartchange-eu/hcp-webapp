import { DataType } from '../datatype/data-type';
/**
 * HAPI/FHIR <b>Expression</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Expression extends DataType {
    /**
     * An expression in the specified language that returns a value.
     *
     * Expression in specified language
     */
    expression?: string;
    /**
     * A URI that defines where the expression is found.
     *
     * Where the expression is found
     */
    reference?: string;
    /**
     * The media type of the language for the expression.
     *
     * text/cql | text/fhirpath | application/x-fhir-query | etc.
     */
    language?: string;
    /**
     * A brief, natural language description of the condition that effectively communicates the intended semantics.
     *
     * Natural language description of the condition
     */
    description?: string;
    /**
     * A short name assigned to the expression to allow for multiple reuse of the expression in the context where it is defined.
     *
     * Short name assigned to expression for reuse
     */
    name?: string;
    readonly dataType: string;
    static revive(json: any): Expression;
    toJSON(): any;
}
