import { Quantity } from '../datatype/quantity';
/**
 * HAPI/FHIR <b>Count</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Count extends Quantity {
    readonly dataType: string;
    static revive(json: any): Count;
    toJSON(): any;
}
