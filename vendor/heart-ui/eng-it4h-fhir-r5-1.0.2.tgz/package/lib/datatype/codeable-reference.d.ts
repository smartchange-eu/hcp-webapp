import { Reference } from '../datatype/reference';
import { CodeableConcept } from '../datatype/codeable-concept';
import { DataType } from '../datatype/data-type';
/**
 * HAPI/FHIR <b>CodeableReference</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class CodeableReference extends DataType {
    /**
     * A reference to a concept - e.g. the information is identified by its general class to the degree of precision found in the terminology.
     *
     * Reference to a concept (by class)
     */
    concept?: CodeableConcept;
    /**
     * A reference to a resource the provides exact details about the information being referenced.
     *
     * Reference to a resource (by instance)
     */
    reference?: Reference;
    readonly dataType: string;
    static revive(json: any): CodeableReference;
    toJSON(): any;
}
