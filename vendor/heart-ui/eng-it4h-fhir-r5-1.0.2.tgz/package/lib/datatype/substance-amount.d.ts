import { BackboneElement } from '../datatype/backbone-element';
import { BackboneType } from '../datatype/backbone-type';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
/**
 * HAPI/FHIR <b>SubstanceAmount</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class SubstanceAmount extends BackboneType {
    /**
     * Most elements that require a quantitative value will also have a field called amount type. Amount type should always be specified because the actual value of the amount is often dependent on it. EXAMPLE: In capturing the actual relative amounts of substances or molecular fragments it is essential to indicate whether the amount refers to a mole ratio or weight ratio. For any given element an effort should be made to use same the amount type for all related definitional elements.
     *
     * Most elements that require a quantitative value will also have a field called amount type. Amount type should always be specified because the actual value of the amount is often dependent on it. EXAMPLE: In capturing the actual relative amounts of substances or molecular fragments it is essential to indicate whether the amount refers to a mole ratio or weight ratio. For any given element an effort should be made to use same the amount type for all related definitional elements
     */
    amountType?: CodeableConcept;
    /**
     * Used to capture quantitative values for a variety of elements. If only limits are given, the arithmetic mean would be the average. If only a single definite value for a given element is given, it would be captured in this field.
     *
     * Used to capture quantitative values for a variety of elements. If only limits are given, the arithmetic mean would be the average. If only a single definite value for a given element is given, it would be captured in this field
     */
    amount?: Quantity | Range | string;
    /**
     * Reference range of possible or expected values.
     *
     * Reference range of possible or expected values
     */
    referenceRange?: SubstanceAmount.SubstanceAmountReferenceRangeComponent;
    /**
     * A textual comment on a numeric value.
     *
     * A textual comment on a numeric value
     */
    amountText?: string;
    readonly dataType: string;
    static revive(json: any): SubstanceAmount;
    toJSON(): any;
}
export declare namespace SubstanceAmount {
    class SubstanceAmountReferenceRangeComponent extends BackboneElement {
        /**
         * Upper limit possible or expected.
         *
         * Upper limit possible or expected
         */
        highLimit?: Quantity;
        /**
         * Lower limit possible or expected.
         *
         * Lower limit possible or expected
         */
        lowLimit?: Quantity;
        static revive(json: any): SubstanceAmountReferenceRangeComponent;
        toJSON(): any;
    }
}
