import { Reference } from '../datatype/reference';
import { CodeableConcept } from '../datatype/codeable-concept';
import { DataRequirement } from '../datatype/data-requirement';
import { DataType } from '../datatype/data-type';
import { Expression } from '../datatype/expression';
import { Timing } from '../datatype/timing';
import { Schedule } from '../model/schedule';
/**
 * HAPI/FHIR <b>TriggerDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class TriggerDefinition extends DataType {
    /**
     * A code that identifies the event.
     *
     * Coded definition of the event
     */
    code?: CodeableConcept;
    /**
     * A boolean-valued expression that is evaluated in the context of the container of the trigger definition and returns whether or not the trigger fires.
     *
     * Whether the event triggers (boolean expression)
     */
    condition?: Expression;
    /**
     * The triggering data of the event (if this is a data trigger). If more than one data is requirement is specified, then all the data requirements must be true.
     *
     * Triggering data of the event (multiple = 'and')
     */
    data?: DataRequirement[];
    /**
     * The timing of the event (if this is a periodic trigger).
     *
     * Timing of the event
     */
    timing?: Timing | Schedule | Date | Date | Reference;
    /**
     * A formal name for the event. This may be an absolute URI that identifies the event formally (e.g. from a trigger registry), or a simple relative URI that identifies the event in a local context.
     *
     * Name or URI that identifies the event
     */
    name?: string;
    /**
     * A reference to a SubscriptionTopic resource that defines the event. If this element is provided, no other information about the trigger definition may be supplied.
     *
     * What event
     */
    subscriptionTopic?: string;
    /**
     * The type of triggering event.
     *
     * named-event | periodic | data-changed | data-added | data-modified | data-removed | data-accessed | data-access-ended
     */
    type: string;
    readonly dataType: string;
    static revive(json: any): TriggerDefinition;
    toJSON(): any;
}
export declare namespace TriggerDefinition {
    enum TriggerType {
        DATAACCESSENDED,
        DATAADDED,
        DATAMODIFIED,
        DATAREMOVED,
        NULL,
        NAMEDEVENT,
        DATACHANGED,
        PERIODIC,
        DATAACCESSED
    }
}
