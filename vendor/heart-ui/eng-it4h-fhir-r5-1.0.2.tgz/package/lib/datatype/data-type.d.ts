import { Element } from '../datatype/element';
/**
 * HAPI/FHIR <b>DataType</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class DataType extends Element {
    readonly dataType: string;
    static revive(json: any): DataType;
    toJSON(): any;
}
