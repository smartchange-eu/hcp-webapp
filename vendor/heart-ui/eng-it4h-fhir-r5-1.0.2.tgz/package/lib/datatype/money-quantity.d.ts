import { Quantity } from '../datatype/quantity';
/**
 * HAPI/FHIR <b>MoneyQuantity</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class MoneyQuantity extends Quantity {
    readonly dataType: string;
    static revive(json: any): MoneyQuantity;
    toJSON(): any;
}
