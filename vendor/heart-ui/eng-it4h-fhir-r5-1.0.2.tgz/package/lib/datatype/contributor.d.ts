import { ContactDetail } from '../datatype/contact-detail';
import { DataType } from '../datatype/data-type';
/**
 * HAPI/FHIR <b>Contributor</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Contributor extends DataType {
    /**
     * Contact details to assist a user in finding and communicating with the contributor.
     *
     * Contact details of the contributor
     */
    contact?: ContactDetail[];
    /**
     * The type of contributor.
     *
     * author | editor | reviewer | endorser
     */
    type: string;
    /**
     * The name of the individual or organization responsible for the contribution.
     *
     * Who contributed the content
     */
    name: string;
    readonly dataType: string;
    static revive(json: any): Contributor;
    toJSON(): any;
}
export declare namespace Contributor {
    enum ContributorType {
        REVIEWER,
        EDITOR,
        ENDORSER,
        NULL,
        AUTHOR
    }
}
