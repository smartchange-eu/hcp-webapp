import { Quantity } from '../datatype/quantity';
/**
 * HAPI/FHIR <b>Duration</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Duration extends Quantity {
    readonly dataType: string;
    static revive(json: any): Duration;
    toJSON(): any;
}
