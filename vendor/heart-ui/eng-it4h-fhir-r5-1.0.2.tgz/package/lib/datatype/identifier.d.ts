import { Reference } from '../datatype/reference';
import { CodeableConcept } from '../datatype/codeable-concept';
import { DataType } from '../datatype/data-type';
import { Period } from '../datatype/period';
import { Organization } from '../model/organization';
/**
 * HAPI/FHIR <b>Identifier</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Identifier extends DataType {
    /**
     * The portion of the identifier typically relevant to the user and which is unique within the context of the system.
     *
     * The value that is unique
     */
    value?: string;
    /**
     * A coded type for the identifier that can be used to determine which identifier to use for a specific purpose.
     *
     * Description of identifier
     */
    type?: CodeableConcept;
    /**
     * Organization that issued/manages the identifier.
     *
     * Organization that issued id (may be just text)
     */
    assigner?: Organization | Reference;
    /**
     * The purpose of this identifier.
     *
     * usual | official | temp | secondary | old (If known)
     */
    use?: string;
    /**
     * Establishes the namespace for the value - that is, an absolute URL that describes a set values that are unique.
     *
     * The namespace for the identifier value
     */
    system?: string;
    /**
     * Time period during which identifier is/was valid for use.
     *
     * Time period when id is/was valid for use
     */
    period?: Period;
    readonly dataType: string;
    static revive(json: any): Identifier;
    toJSON(): any;
}
export declare namespace Identifier {
    enum IdentifierUse {
        OFFICIAL,
        TEMP,
        NULL,
        USUAL,
        OLD,
        SECONDARY
    }
}
