import { Quantity } from '../datatype/quantity';
/**
 * HAPI/FHIR <b>Distance</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class Distance extends Quantity {
    readonly dataType: string;
    static revive(json: any): Distance;
    toJSON(): any;
}
