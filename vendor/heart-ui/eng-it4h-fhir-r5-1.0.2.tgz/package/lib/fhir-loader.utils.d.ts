/*****************************************************
 * Classloading utilities
 *****************************************************/
export declare class FhirLoaderUtils {
    static attributeRemove(obj: any, field: string, funct?: (value: any) => any): any;
    static attributeRevive(item: any, reviveCallback: (o: any) => any | any[]): any | any[];
    static dataTypeAttributeToJSON(property: string, value: any, mapping: {
        key: string;
        value: any;
    }[]): {
        key: string;
        value: any;
    };
    static loadClassByTypeName(modelTypeName: string): any;
}
