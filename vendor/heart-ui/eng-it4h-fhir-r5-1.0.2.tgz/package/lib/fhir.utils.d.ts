import { RelatedPerson } from './model/related-person';
import { DataType, Timing, Period, Identifier, Extension, Reference, Quantity, CodeableConcept, Coding } from './datatype';
import { DomainResource } from './model/domain-resource';
export declare class FhirUtils {
    static createCodeableConcept(system: string, code: string, display: string, text?: string): CodeableConcept;
    static createCodeableConceptWithOnlyText(text: string): CodeableConcept;
    static createExtension(url: string, value: DataType): Extension;
    static createExtensionCodeableConcept(url: string, value: CodeableConcept): Extension;
    static createExtensionCoding(url: string, value: Coding): Extension;
    static createExtensionResource(url: string, value: DomainResource): Extension;
    static createExtensionString(url: string, value: string): Extension;
    static createExtensionBoolean(url: string, value: boolean): Extension;
    static createExtensionNumber(url: string, value: number): Extension;
    static createExtensionDate(url: string, value: Date): Extension;
    static createExtensionQuantity(url: string, value: Quantity): Extension;
    static createExtensionReference(url: string, value: Reference): Extension;
    static createTimingMax(duration: number, unit: string): Timing;
    static createPeriodStartEnd(start: Date, end?: Date): Period;
    static createIdentifier(system: string, value: string): Identifier;
    static filterIdentifierBySystem(identifiers: Identifier[], system: string): Identifier;
    static filterIdentifierByTypeSystem(identifiers: Identifier[], typeSystem: string): Identifier;
    static createQuantity(value?: number, system?: string, code?: string, unit?: string): Quantity;
    /**
     * Use in this way:
     * <code> DemoData.createRandomSeries(0, 70, 30).join(' ');</code>
     *
     * @param min - included
     * @param max - included
     * @param samples - amount of samples in the series
     */
    static createRandomSeries(min?: number, max?: number, samples?: number): string[];
    /**
     * Create RelatedPerson
     *
     * @param patient - Patient who the RelatedPerson is related to
     * @param relationship - The type of the relationShip
     * @param name - Name of the related person
     *
     */
    static createRelatedPerson(patientRef: Reference, relationship: string, name: string): RelatedPerson;
    static createCommunicationLocale(locale: string): CodeableConcept;
}
