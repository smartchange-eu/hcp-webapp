import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Address } from '../datatype/address';
import { Availability } from '../datatype/availability';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ExtendedContactDetail } from '../datatype/extended-contact-detail';
import { Identifier } from '../datatype/identifier';
import { VirtualServiceDetail } from '../datatype/virtual-service-detail';
import { DomainResource } from '../model/domain-resource';
import { Endpoint } from '../model/endpoint';
import { Organization } from '../model/organization';
/**
 * HAPI/FHIR <b>Location</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Location">http://hl7.org/fhir/StructureDefinition/Location</a>
 * </p>
 *
 */
export declare class Location extends DomainResource {
    /**
     * A list of alternate names that the location is known as, or was known as, in the past.
     *
     * A list of alternate names that the location is known as, or was known as, in the past
     */
    alias?: string[];
    /**
     * Name of the location as used by humans. Does not need to be unique.
     *
     * Name of the location as used by humans
     */
    name?: string;
    /**
     * The absolute geographic location of the Location, expressed using the WGS84 datum (This is the same co-ordinate system used in KML).
     *
     * The absolute geographic location
     */
    position?: Location.LocationPositionComponent;
    /**
     * The status property covers the general availability of the resource, not the current value which may be covered by the operationStatus, or by a schedule/slots if they are configured for the location.
     *
     * active | suspended | inactive
     */
    status?: string;
    /**
     * Indicates whether a resource instance represents a specific location or a class of locations.
     *
     * instance | kind
     */
    mode?: string;
    /**
     * The organization responsible for the provisioning and upkeep of the location.
     *
     * Organization responsible for provisioning and upkeep
     */
    managingOrganization?: Organization | Reference;
    /**
     * Technical endpoints providing access to services operated for the location.
     *
     * Technical endpoints providing access to services operated for the location
     */
    endpoint?: Endpoint[] | Reference[];
    /**
     * Physical form of the location, e.g. building, room, vehicle, road, virtual.
     *
     * Physical form of the location
     */
    form?: CodeableConcept;
    /**
     * The contact details of communication devices available at the location. This can include addresses, phone numbers, fax numbers, mobile numbers, email addresses and web sites.
     *
     * Official contact details for the location
     */
    contact?: ExtendedContactDetail[];
    /**
     * Description of the Location, which helps in finding or referencing the place.
     *
     * Additional details about the location that could be displayed as further information to identify the location beyond its name
     */
    description?: string;
    /**
     * What days/times during a week is this location usually open, and any exceptions where the location is not available.
     *
     * What days/times during a week is this location usually open (including exceptions)
     */
    hoursOfOperation?: Availability[];
    /**
     * Indicates the type of function performed at the location.
     *
     * Type of function performed
     */
    type?: CodeableConcept[];
    /**
     * Collection of characteristics (attributes).
     *
     * Collection of characteristics (attributes)
     */
    characteristic?: CodeableConcept[];
    /**
     * Unique code or number identifying the location to its users.
     *
     * Unique code or number identifying the location to its users
     */
    identifier?: Identifier[];
    /**
     * Another Location of which this Location is physically a part of.
     *
     * Another Location this one is physically a part of
     */
    partOf?: Location | Reference;
    /**
     * The operational status covers operation values most relevant to beds (but can also apply to rooms/units/chairs/etc. such as an isolation unit/dialysis chair). This typically covers concepts such as contamination, housekeeping, and other activities like maintenance.
     *
     * The operational status of the location (typically only for a bed/room)
     */
    operationalStatus?: Coding;
    /**
     * Physical location.
     *
     * Physical location
     */
    address?: Address;
    /**
     * Connection details of a virtual service (e.g. shared conference call facility with dedicated number/details).
     *
     * Connection details of a virtual service (e.g. conference call)
     */
    virtualService?: VirtualServiceDetail[];
    readonly resourceType: string;
    static revive(json: any): Location;
    toJSON(): any;
}
export declare namespace Location {
    enum LocationStatus {
        NULL,
        ACTIVE,
        INACTIVE,
        SUSPENDED
    }
    enum LocationMode {
        NULL,
        KIND,
        INSTANCE
    }
    class LocationPositionComponent extends BackboneElement {
        /**
         * Longitude. The value domain and the interpretation are the same as for the text of the longitude element in KML (see notes on Location main page).
         *
         * Longitude with WGS84 datum
         */
        longitude: number;
        /**
         * Latitude. The value domain and the interpretation are the same as for the text of the latitude element in KML (see notes on Location main page).
         *
         * Latitude with WGS84 datum
         */
        latitude: number;
        /**
         * Altitude. The value domain and the interpretation are the same as for the text of the altitude element in KML (see notes on Location main page).
         *
         * Altitude with WGS84 datum
         */
        altitude?: number;
        static revive(json: any): LocationPositionComponent;
        toJSON(): any;
    }
}
