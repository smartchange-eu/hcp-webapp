import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Narrative } from '../datatype/narrative';
import { Period } from '../datatype/period';
import { RelatedArtifact } from '../datatype/related-artifact';
import { UsageContext } from '../datatype/usage-context';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Composition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Composition">http://hl7.org/fhir/StructureDefinition/Composition</a>
 * </p>
 *
 */
export declare class Composition extends DomainResource {
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate Composition instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * A categorization for the type of the composition - helps for indexing and searching. This may be implied by or derived from the code specified in the Composition Type.
     *
     * Categorization of Composition
     */
    category?: CodeableConcept[];
    /**
     * Relationships that this composition has with other compositions or documents that already exist.
     *
     * Relationships to other compositions/documents
     */
    relatesTo?: RelatedArtifact[];
    /**
     * The clinical service, such as a colonoscopy or an appendectomy, being documented.
     *
     * The clinical service(s) being documented
     */
    event?: Composition.CompositionEventComponent[];
    /**
     * The workflow/clinical status of this composition. The status is a marker for the clinical standing of the document.
     *
     * registered | partial | preliminary | final | amended | corrected | appended | cancelled | entered-in-error | deprecated | unknown
     */
    status: string;
    /**
     * A natural language name identifying the composition. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this Composition (computer friendly)
     */
    name?: string;
    /**
     * An explicitly assigned identifer of a variation of the content in the Composition.
     *
     * An explicitly assigned identifer of a variation of the content in the Composition
     */
    version?: string;
    /**
     * Specifies the particular kind of composition (e.g. History and Physical, Discharge Summary, Progress Note). This usually equates to the purpose of making the composition.
     *
     * Kind of composition (LOINC if possible)
     */
    type: CodeableConcept;
    /**
     * Official human-readable label for the composition.
     *
     * Human Readable name/title
     */
    title: string;
    /**
     * An absolute URI that is used to identify this Composition when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this Composition is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the Composition is stored on different servers.
     *
     * Canonical identifier for this Composition, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * A participant who has attested to the accuracy of the composition/document.
     *
     * Attests to accuracy of composition
     */
    attester?: Composition.CompositionAttesterComponent[];
    /**
     * Describes the clinical encounter or type of care this documentation is associated with.
     *
     * Context of the Composition
     */
    encounter?: Encounter | Reference;
    /**
     * The root of the sections that make up the composition.
     *
     * Composition is broken into sections
     */
    section?: Composition.SectionComponent[];
    /**
     * Identifies the organization or group who is responsible for ongoing maintenance of and access to the composition/document information.
     *
     * Organization which maintains the composition
     */
    custodian?: Organization | Reference;
    /**
     * Who or what the composition is about. The composition can be about a person, (patient or healthcare practitioner), a device (e.g. a machine) or even a group of subjects (such as a document about a herd of livestock, or a set of patients that share a common exposure).
     *
     * Who and/or what the composition is about
     */
    subject?: Reference[];
    /**
     * Identifies who is responsible for the information in the composition, not necessarily who typed it in.
     *
     * Who and/or what authored the composition
     */
    author: Practitioner[] | PractitionerRole[] | Device[] | Patient[] | RelatedPerson[] | Organization[] | Reference[];
    /**
     * A version-independent identifier for the Composition. This identifier stays constant as the composition is changed over time.
     *
     * Version-independent identifier for the Composition
     */
    identifier?: Identifier[];
    /**
     * For any additional notes.
     *
     * For any additional notes
     */
    note?: Annotation[];
    /**
     * The composition editing time, when the composition was last logically changed by the author.
     *
     * Composition editing time
     */
    date: Date;
    readonly resourceType: string;
    static revive(json: any): Composition;
    toJSON(): any;
}
export declare namespace Composition {
    enum CompositionStatus {
        CANCELLED,
        ENTEREDINERROR,
        NULL,
        AMENDED,
        REGISTERED,
        CORRECTED,
        PRELIMINARY,
        PARTIAL,
        FINAL,
        APPENDED,
        UNKNOWN,
        DEPRECATED
    }
    class SectionComponent extends BackboneElement {
        /**
         * The label for this particular section.  This will be part of the rendered content for the document, and is often used to build a table of contents.
         *
         * Label for section (e.g. for ToC)
         */
        title?: string;
        /**
         * The actual focus of the section when it is not the subject of the composition, but instead represents something or someone associated with the subject such as (for a patient subject) a spouse, parent, fetus, or donor. If not focus is specified, the focus is assumed to be focus of the parent section, or, for a section in the Composition itself, the subject of the composition. Sections with a focus SHALL only include resources where the logical subject (patient, subject, focus, etc.) matches the section focus, or the resources have no logical subject (few resources).
         *
         * Who/what the section is about, when it is not about the subject of composition
         */
        focus?: Reference;
        /**
         * A nested sub-section within this section.
         *
         * Nested Section
         */
        section?: Composition.SectionComponent[];
        /**
         * A human-readable narrative that contains the attested content of the section, used to represent the content of the resource to a human. The narrative need not encode all the structured data, but is required to contain sufficient detail to make it "clinically safe" for a human to just read the narrative.
         *
         * Text summary of the section, for human interpretation
         */
        text?: Narrative;
        /**
         * Specifies the order applied to the items in the section entries.
         *
         * Order of section entries
         */
        orderedBy?: CodeableConcept;
        /**
         * If the section is empty, why the list is empty. An empty section typically has some text explaining the empty reason.
         *
         * Why the section is empty
         */
        emptyReason?: CodeableConcept;
        /**
         * Identifies who is responsible for the information in this section, not necessarily who typed it in.
         *
         * Who and/or what authored the section
         */
        author?: Practitioner[] | PractitionerRole[] | Device[] | Patient[] | RelatedPerson[] | Organization[] | Reference[];
        /**
         * A reference to the actual resource from which the narrative in the section is derived.
         *
         * A reference to data that supports this section
         */
        entry?: Reference[];
        /**
         * A code identifying the kind of content contained within the section. This must be consistent with the section title.
         *
         * Classification of section (recommended)
         */
        code?: CodeableConcept;
        static revive(json: any): SectionComponent;
        toJSON(): any;
    }
    class CompositionEventComponent extends BackboneElement {
        /**
         * Represents the main clinical acts, such as a colonoscopy or an appendectomy, being documented. In some cases, the event is inherent in the typeCode, such as a "History and Physical Report" in which case the procedure being documented is necessarily a "History and Physical" act. The events may be included as a code or as a reference to an other resource.
         *
         * The event(s) being documented, as code(s), reference(s), or both
         */
        detail?: CodeableReference[];
        /**
         * The period of time covered by the documentation. There is no assertion that the documentation is a complete representation for this period, only that it documents events during this time.
         *
         * The period covered by the documentation
         */
        period?: Period;
        static revive(json: any): CompositionEventComponent;
        toJSON(): any;
    }
    class CompositionAttesterComponent extends BackboneElement {
        /**
         * Who attested the composition in the specified way.
         *
         * Who attested the composition
         */
        party?: Patient | RelatedPerson | Practitioner | PractitionerRole | Organization | Reference;
        /**
         * When the composition was attested by the party.
         *
         * When the composition was attested
         */
        time?: Date;
        /**
         * The type of attestation the authenticator offers.
         *
         * personal | professional | legal | official
         */
        mode: CodeableConcept;
        static revive(json: any): CompositionAttesterComponent;
        toJSON(): any;
    }
}
