import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Address } from '../datatype/address';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { ContactPoint } from '../datatype/contact-point';
import { HumanName } from '../datatype/human-name';
import { Identifier } from '../datatype/identifier';
import { DomainResource } from '../model/domain-resource';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Person</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Person">http://hl7.org/fhir/StructureDefinition/Person</a>
 * </p>
 *
 */
export declare class Person extends DomainResource {
    /**
     * The organization that is the custodian of the person record.
     *
     * The organization that is the custodian of the person record
     */
    managingOrganization?: Organization | Reference;
    /**
     * This field contains a person's most recent marital (civil) status.
     *
     * Marital (civil) status of a person
     */
    maritalStatus?: CodeableConcept;
    /**
     * A language which may be used to communicate with the person about his or her health.
     *
     * A language which may be used to communicate with the person about his or her health
     */
    communication?: Person.PersonCommunicationComponent[];
    /**
     * A contact detail for the person, e.g. a telephone number or an email address.
     *
     * A contact detail for the person
     */
    telecom?: ContactPoint[];
    /**
     * A name associated with the person.
     *
     * A name associated with the person
     */
    name?: HumanName[];
    /**
     * Administrative Gender.
     *
     * male | female | other | unknown
     */
    gender?: string;
    /**
     * Indicates if the individual is deceased or not.
     *
     * Indicates if the individual is deceased or not
     */
    deceased?: boolean | Date;
    /**
     * One or more addresses for the person.
     *
     * One or more addresses for the person
     */
    address?: Address[];
    /**
     * Identifier for a person within a particular scope.
     *
     * A human identifier for this person
     */
    identifier?: Identifier[];
    /**
     * The birth date for the person.
     *
     * The date on which the person was born
     */
    birthDate?: Date;
    /**
     * Link to a resource that concerns the same actual person.
     *
     * Link to a resource that concerns the same actual person
     */
    link?: Person.PersonLinkComponent[];
    /**
     * Whether this person's record is in active use.
     *
     * This person's record is in active use
     */
    active?: boolean;
    /**
     * An image that can be displayed as a thumbnail of the person to enhance the identification of the individual.
     *
     * Image of the person
     */
    photo?: Attachment[];
    readonly resourceType: string;
    static revive(json: any): Person;
    toJSON(): any;
}
export declare namespace Person {
    enum IdentityAssuranceLevel {
        NULL,
        LEVEL4,
        LEVEL1,
        LEVEL2,
        LEVEL3
    }
    enum AdministrativeGender {
        OTHER,
        NULL,
        UNKNOWN,
        MALE,
        FEMALE
    }
    class PersonLinkComponent extends BackboneElement {
        /**
         * Level of assurance that this link is associated with the target resource.
         *
         * level1 | level2 | level3 | level4
         */
        assurance?: string;
        /**
         * The resource to which this actual person is associated.
         *
         * The resource to which this actual person is associated
         */
        target: Patient | Practitioner | RelatedPerson | Person | Reference;
        static revive(json: any): PersonLinkComponent;
        toJSON(): any;
    }
    class PersonCommunicationComponent extends BackboneElement {
        /**
         * The ISO-639-1 alpha 2 code in lower case for the language, optionally followed by a hyphen and the ISO-3166-1 alpha 2 code for the region in upper case; e.g. "en" for English, or "en-US" for American English versus "en-AU" for Australian English.
         *
         * The language which can be used to communicate with the person about his or her health
         */
        language: CodeableConcept;
        /**
         * Indicates whether or not the person prefers this language (over other languages he masters up a certain level).
         *
         * Language preference indicator
         */
        preferred?: boolean;
        static revive(json: any): PersonCommunicationComponent;
        toJSON(): any;
    }
}
