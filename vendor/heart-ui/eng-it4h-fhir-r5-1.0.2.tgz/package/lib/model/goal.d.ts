import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Duration } from '../datatype/duration';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { Ratio } from '../datatype/ratio';
import { CareTeam } from '../model/care-team';
import { Condition } from '../model/condition';
import { DomainResource } from '../model/domain-resource';
import { Group } from '../model/group';
import { MedicationRequest } from '../model/medication-request';
import { MedicationStatement } from '../model/medication-statement';
import { NutritionOrder } from '../model/nutrition-order';
import { Observation } from '../model/observation';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Procedure } from '../model/procedure';
import { RelatedPerson } from '../model/related-person';
import { RiskAssessment } from '../model/risk-assessment';
import { ServiceRequest } from '../model/service-request';
/**
 * HAPI/FHIR <b>Goal</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Goal">http://hl7.org/fhir/StructureDefinition/Goal</a>
 * </p>
 *
 */
export declare class Goal extends DomainResource {
    /**
     * Captures the reason for the current status.
     *
     * Reason for current status
     */
    statusReason?: string;
    /**
     * After meeting the goal, ongoing activity is needed to sustain the goal objective.
     *
     * After meeting the goal, ongoing activity is needed to sustain the goal objective
     */
    continuous?: boolean;
    /**
     * Describes the progression, or lack thereof, towards the goal against the target.
     *
     * in-progress | improving | worsening | no-change | achieved | sustaining | not-achieved | no-progress | not-attainable
     */
    achievementStatus?: CodeableConcept;
    /**
     * Indicates a category the goal falls within.
     *
     * E.g. Treatment, dietary, behavioral, etc
     */
    category?: CodeableConcept[];
    /**
     * Identifies the change (or lack of change) at the point when the status of the goal is assessed.
     *
     * What result was achieved regarding the goal?
     */
    outcome?: CodeableReference[];
    /**
     * Identifies when the current status.  I.e. When initially created, when achieved, when cancelled, etc.
     *
     * When goal status took effect
     */
    statusDate?: Date;
    /**
     * Business identifiers assigned to this goal by the performer or other systems which remain constant as the resource is updated and propagates from server to server.
     *
     * External Ids for this goal
     */
    identifier?: Identifier[];
    /**
     * Any comments related to the goal.
     *
     * Comments about the goal
     */
    note?: Annotation[];
    /**
     * The identified conditions and other health record elements that are intended to be addressed by the goal.
     *
     * Issues addressed by this goal
     */
    addresses?: Condition[] | Observation[] | MedicationStatement[] | MedicationRequest[] | NutritionOrder[] | ServiceRequest[] | RiskAssessment[] | Procedure[] | Reference[];
    /**
     * The state of the goal throughout its lifecycle.
     *
     * proposed | planned | accepted | active | on-hold | completed | cancelled | entered-in-error | rejected
     */
    lifecycleStatus: string;
    /**
     * Identifies the patient, group or organization for whom the goal is being established.
     *
     * Who this goal is intended for
     */
    subject: Patient | Group | Organization | Reference;
    /**
     * The date or event after which the goal should begin being pursued.
     *
     * When goal pursuit begins
     */
    start?: Date | CodeableConcept;
    /**
     * Human-readable and/or coded description of a specific desired objective of care, such as "control blood pressure" or "negotiate an obstacle course" or "dance with child at wedding".
     *
     * Code or text describing goal
     */
    description: CodeableConcept;
    /**
     * Indicates whose goal this is - patient goal, practitioner goal, etc.
     *
     * Who's responsible for creating Goal?
     */
    source?: Patient | Practitioner | PractitionerRole | RelatedPerson | CareTeam | Reference;
    /**
     * Identifies the mutually agreed level of importance associated with reaching/sustaining the goal.
     *
     * high-priority | medium-priority | low-priority
     */
    priority?: CodeableConcept;
    /**
     * Indicates what should be done by when.
     *
     * Target outcome for the goal
     */
    target?: Goal.GoalTargetComponent[];
    readonly resourceType: string;
    static revive(json: any): Goal;
    toJSON(): any;
}
export declare namespace Goal {
    enum GoalLifecycleStatus {
        CANCELLED,
        ENTEREDINERROR,
        COMPLETED,
        ACCEPTED,
        NULL,
        ACTIVE,
        ONHOLD,
        PROPOSED,
        PLANNED,
        REJECTED
    }
    class GoalTargetComponent extends BackboneElement {
        /**
         * The target value of the focus to be achieved to signify the fulfillment of the goal, e.g. 150 pounds, 7.0%. Either the high or low or both values of the range can be specified. When a low value is missing, it indicates that the goal is achieved at any focus value at or below the high value. Similarly, if the high value is missing, it indicates that the goal is achieved at any focus value at or above the low value.
         *
         * The target value to be achieved
         */
        detail?: Quantity | Range | CodeableConcept | string | boolean | number | Ratio;
        /**
         * The parameter whose value is being tracked, e.g. body weight, blood pressure, or hemoglobin A1c level.
         *
         * The parameter whose value is being tracked
         */
        measure?: CodeableConcept;
        /**
         * Indicates either the date or the duration after start by which the goal should be met.
         *
         * Reach goal on or before
         */
        due?: Date | Duration;
        static revive(json: any): GoalTargetComponent;
        toJSON(): any;
    }
}
