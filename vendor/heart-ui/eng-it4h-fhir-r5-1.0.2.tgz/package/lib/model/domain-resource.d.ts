import { Reference } from '../datatype/reference';
import { Meta } from '../datatype/meta';
import { Extension } from '../datatype/extension';
import { Narrative } from '../datatype/narrative';
/**
 * HAPI/FHIR <b>DomainResource</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare abstract class DomainResource {
    /**
     * Logical id of this artifact
     */
    id?: string;
    /**
     * Metadata about the resource
     */
    meta?: Meta;
    /**
     * These resources do not have an independent existence apart from the resource that contains them - they cannot be identified independently, nor can they have their own independent transaction scope. This is allowed to be a Parameters resource if and only if it is referenced by a resource that provides context/meaning.
     *
     * Contained, inline Resources
     */
    contained?: DomainResource[] | Reference[];
    /**
     * May be used to represent additional information that is not part of the basic definition of the resource. To make the use of extensions safe and managable, there is a strict set of governance  applied to the definition and use of extensions. Though any implementer can define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension.
     *
     * Additional content defined by implementations
     */
    extension?: Extension[];
    /**
     * May be used to represent additional information that is not part of the basic definition of the resource and that modifies the understanding of the element that contains it and/or the understanding of the containing element's descendants. Usually modifier elements provide negation or qualification. To make the use of extensions safe and managable, there is a strict set of governance applied to the definition and use of extensions. Though any implementer is allowed to define an extension, there is a set of requirements that SHALL be met as part of the definition of the extension. Applications processing a resource are required to check for modifier extensions.

Modifier extensions SHALL NOT change the meaning of any elements on Resource or DomainResource (including cannot change the meaning of modifierExtension itself).
     *
     * Extensions that cannot be ignored
     */
    modifierExtension?: Extension[];
    /**
     * A human-readable narrative that contains a summary of the resource and can be used to represent the content of the resource to a human. The narrative need not encode all the structured data, but is required to contain sufficient detail to make it "clinically safe" for a human to just read the narrative. Resource definitions may define what content should be represented in the narrative to ensure clinical safety.
     *
     * Text summary of the resource, for human interpretation
     */
    text?: Narrative;
    abstract resourceType?: string;
    findContainedResource(ref: Reference | string): DomainResource;
    getReference(): Reference;
    toJSON(): any;
    static revive(json: any): DomainResource;
    /**
     * Take into accoutn nested references wrongly referred in the datamodel (i.e. put as value of an attribute instead of using the 'contained' property)
     * @param prop
     * @param destinationJson
     */
    protected stringifyProp(prop: string, destinationJson: any): Reference | Reference[];
    /**
     * Create a random ID usable in (batch/transaction) bundles
     */
    private generateRandomID;
}
