import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Address } from '../datatype/address';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { ContactPoint } from '../datatype/contact-point';
import { HumanName } from '../datatype/human-name';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { DomainResource } from '../model/domain-resource';
import { Organization } from '../model/organization';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Patient</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Patient">http://hl7.org/fhir/StructureDefinition/Patient</a>
 * </p>
 *
 */
export declare class Patient extends DomainResource {
    /**
     * A contact detail (e.g. a telephone number or an email address) by which the individual may be contacted.
     *
     * A contact detail for the individual
     */
    telecom?: ContactPoint[];
    /**
     * A name associated with the individual.
     *
     * A name associated with the patient
     */
    name?: HumanName[];
    /**
     * This field contains a patient's most recent marital (civil) status.
     *
     * Marital (civil) status of a patient
     */
    maritalStatus?: CodeableConcept;
    /**
     * A language which may be used to communicate with the patient about his or her health.
     *
     * A language which may be used to communicate with the patient about his or her health
     */
    communication?: Patient.PatientCommunicationComponent[];
    /**
     * Organization that is the custodian of the patient record.
     *
     * Organization that is the custodian of the patient record
     */
    managingOrganization?: Organization | Reference;
    /**
     * A contact party (e.g. guardian, partner, friend) for the patient.
     *
     * A contact party (e.g. guardian, partner, friend) for the patient
     */
    contact?: Patient.ContactComponent[];
    /**
     * Patient's nominated care provider.
     *
     * Patient's nominated primary care provider
     */
    generalPractitioner?: Organization[] | Practitioner[] | PractitionerRole[] | Reference[];
    /**
     * Whether this patient record is in active use.
Many systems use this property to mark as non-current patients, such as those that have not been seen for a period of time based on an organization's business rules.

It is often used to filter patient lists to exclude inactive patients

Deceased patients may also be marked as inactive for the same reasons, but may be active for some time after death.
     *
     * Whether this patient's record is in active use
     */
    active?: boolean;
    /**
     * Image of the patient.
     *
     * Image of the patient
     */
    photo?: Attachment[];
    /**
     * Link to a Patient or RelatedPerson resource that concerns the same actual individual.
     *
     * Link to a Patient or RelatedPerson resource that concerns the same actual individual
     */
    link?: Patient.PatientLinkComponent[];
    /**
     * Indicates whether the patient is part of a multiple (boolean) or indicates the actual birth order (integer).
     *
     * Whether patient is part of a multiple birth
     */
    multipleBirth?: boolean | number;
    /**
     * The date of birth for the individual.
     *
     * The date of birth for the individual
     */
    birthDate?: Date;
    /**
     * Indicates if the individual is deceased or not.
     *
     * Indicates if the individual is deceased or not
     */
    deceased?: boolean | Date;
    /**
     * An address for the individual.
     *
     * An address for the individual
     */
    address?: Address[];
    /**
     * An identifier for this patient.
     *
     * An identifier for this patient
     */
    identifier?: Identifier[];
    /**
     * Administrative Gender - the gender that the patient is considered to have for administration and record keeping purposes.
     *
     * male | female | other | unknown
     */
    gender?: string;
    readonly resourceType: string;
    static revive(json: any): Patient;
    toJSON(): any;
}
export declare namespace Patient {
    enum LinkType {
        REPLACES,
        REFER,
        NULL,
        SEEALSO,
        REPLACEDBY
    }
    enum AdministrativeGender {
        OTHER,
        NULL,
        UNKNOWN,
        MALE,
        FEMALE
    }
    class PatientLinkComponent extends BackboneElement {
        /**
         * Link to a Patient or RelatedPerson resource that concerns the same actual individual.
         *
         * The other patient or related person resource that the link refers to
         */
        other: Patient | RelatedPerson | Reference;
        /**
         * The type of link between this patient resource and another patient resource.
         *
         * replaced-by | replaces | refer | seealso
         */
        type: string;
        static revive(json: any): PatientLinkComponent;
        toJSON(): any;
    }
    class PatientCommunicationComponent extends BackboneElement {
        /**
         * The ISO-639-1 alpha 2 code in lower case for the language, optionally followed by a hyphen and the ISO-3166-1 alpha 2 code for the region in upper case; e.g. "en" for English, or "en-US" for American English versus "en-AU" for Australian English.
         *
         * The language which can be used to communicate with the patient about his or her health
         */
        language: CodeableConcept;
        /**
         * Indicates whether or not the patient prefers this language (over other languages he masters up a certain level).
         *
         * Language preference indicator
         */
        preferred?: boolean;
        static revive(json: any): PatientCommunicationComponent;
        toJSON(): any;
    }
    class ContactComponent extends BackboneElement {
        /**
         * A contact detail for the person, e.g. a telephone number or an email address.
         *
         * A contact detail for the person
         */
        telecom?: ContactPoint[];
        /**
         * A name associated with the contact person.
         *
         * A name associated with the contact person
         */
        name?: HumanName;
        /**
         * The nature of the relationship between the patient and the contact person.
         *
         * The kind of relationship
         */
        relationship?: CodeableConcept[];
        /**
         * The period during which this contact person or organization is valid to be contacted relating to this patient.
         *
         * The period during which this contact person or organization is valid to be contacted relating to this patient
         */
        period?: Period;
        /**
         * Address for the contact person.
         *
         * Address for the contact person
         */
        address?: Address;
        /**
         * Organization on behalf of which the contact is acting or for which the contact is working.
         *
         * Organization that is associated with the contact
         */
        organization?: Organization | Reference;
        /**
         * Administrative Gender - the gender that the contact person is considered to have for administration and record keeping purposes.
         *
         * male | female | other | unknown
         */
        gender?: string;
        static revive(json: any): ContactComponent;
        toJSON(): any;
    }
}
