import { Reference } from '../datatype/reference';
import { Availability } from '../datatype/availability';
import { CodeableConcept } from '../datatype/codeable-concept';
import { ExtendedContactDetail } from '../datatype/extended-contact-detail';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { DomainResource } from '../model/domain-resource';
import { Endpoint } from '../model/endpoint';
import { HealthcareService } from '../model/healthcare-service';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
import { Practitioner } from '../model/practitioner';
/**
 * HAPI/FHIR <b>PractitionerRole</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/PractitionerRole">http://hl7.org/fhir/StructureDefinition/PractitionerRole</a>
 * </p>
 *
 */
export declare class PractitionerRole extends DomainResource {
    /**
     * Collection of characteristics (attributes).
     *
     * Collection of characteristics (attributes)
     */
    characteristic?: CodeableConcept[];
    /**
     *  Whether this practitioner role record is in active use. Some systems may use this property to mark non-active practitioners, such as those that are not currently employed.
     *
     * Whether this practitioner role record is in active use
     */
    active?: boolean;
    /**
     * A collection of times the practitioner is available or performing this role at the location and/or healthcareservice.
     *
     * Times the Practitioner is available at this location and/or healthcare service (including exceptions)
     */
    availability?: Availability[];
    /**
     * Practitioner that is able to provide the defined services for the organization.
     *
     * Practitioner that provides services for the organization
     */
    practitioner?: Practitioner | Reference;
    /**
     * Business Identifiers that are specific to a role/location.
     *
     * Identifiers for a role/location
     */
    identifier?: Identifier[];
    /**
     * The period during which the person is authorized to act as a practitioner in these role(s) for the organization.
     *
     * The period during which the practitioner is authorized to perform in these role(s)
     */
    period?: Period;
    /**
     * The specialty of a practitioner that describes the functional role they are practicing at a given organization or location.
     *
     * Specific specialty of the practitioner
     */
    specialty?: CodeableConcept[];
    /**
     * Roles which this practitioner is authorized to perform for the organization.
     *
     * Roles which this practitioner may perform
     */
    code?: CodeableConcept[];
    /**
     * A language the practitioner can use in patient communication. The practitioner may know several languages (listed in practitioner.communication), however these are the languages that could be advertised in a directory for a patient to search.
     *
     * A language the practitioner (in this role) can use in patient communication
     */
    communication?: CodeableConcept[];
    /**
     * The location(s) at which this practitioner provides care.
     *
     * Location(s) where the practitioner provides care
     */
    location?: Location[] | Reference[];
    /**
     * The list of healthcare services that this worker provides for this role's Organization/Location(s).
     *
     * Healthcare services provided for this role's Organization/Location(s)
     */
    healthcareService?: HealthcareService[] | Reference[];
    /**
     * The organization where the Practitioner performs the roles associated.
     *
     * Organization where the roles are available
     */
    organization?: Organization | Reference;
    /**
     * The contact details of communication devices available relevant to the specific PractitionerRole. This can include addresses, phone numbers, fax numbers, mobile numbers, email addresses and web sites.
     *
     * Official contact details relating to this PractitionerRole
     */
    contact?: ExtendedContactDetail[];
    /**
     *  Technical endpoints providing access to services operated for the practitioner with this role. Commonly used for locating scheduling services, or identifying where to send referrals electronically.
     *
     * Endpoints for interacting with the practitioner in this role
     */
    endpoint?: Endpoint[] | Reference[];
    readonly resourceType: string;
    static revive(json: any): PractitionerRole;
    toJSON(): any;
}
