import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Timing } from '../datatype/timing';
import { CarePlan } from '../model/care-plan';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { Location } from '../model/location';
import { NutritionOrder } from '../model/nutrition-order';
import { Observation } from '../model/observation';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Procedure } from '../model/procedure';
import { RelatedPerson } from '../model/related-person';
import { ServiceRequest } from '../model/service-request';
/**
 * HAPI/FHIR <b>NutritionIntake</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/NutritionIntake">http://hl7.org/fhir/StructureDefinition/NutritionIntake</a>
 * </p>
 *
 */
export declare class NutritionIntake extends DomainResource {
    /**
     * The encounter that establishes the context for this NutritionIntake.
     *
     * Encounter associated with NutritionIntake
     */
    encounter?: Encounter | Reference;
    /**
     * The interval of time during which it is being asserted that the patient is/was consuming the food or fluid.
     *
     * The date/time or interval when the food or fluid is/was consumed
     */
    occurrence?: Date | Period;
    /**
     * Instantiates external protocol or definition.
     *
     * Instantiates external protocol or definition
     */
    instantiatesUri?: string[];
    /**
     * Total nutrient amounts for the whole meal, product, serving, etc.
     *
     * Total nutrient for the whole meal, product, serving
     */
    ingredientLabel?: NutritionIntake.NutritionIntakeIngredientLabelComponent[];
    /**
     * Instantiates FHIR protocol or definition.
     *
     * Instantiates FHIR protocol or definition
     */
    instantiatesCanonical?: string[];
    /**
     * The date when the Nutrition Intake was asserted by the information source.
     *
     * When the intake was recorded
     */
    recorded?: Date;
    /**
     * What food or fluid product or item was consumed.
     *
     * What food or fluid product or item was consumed
     */
    consumedItem: NutritionIntake.NutritionIntakeConsumedItemComponent[];
    /**
     * Overall type of nutrition intake.
     *
     * Code representing an overall type of nutrition intake
     */
    code?: CodeableConcept;
    /**
     * Who performed the intake and how they were involved.
     *
     * Who was performed in the intake
     */
    performer?: NutritionIntake.NutritionIntakePerformerComponent[];
    /**
     * Identifiers associated with this Nutrition Intake that are defined by business processes and/or used to refer to it when a direct URL reference to the resource itself is not appropriate. They are business identifiers assigned to this resource by the performer or other systems and remain constant as the resource is updated and propagates from server to server.
     *
     * External identifier
     */
    identifier?: Identifier[];
    /**
     * A larger event of which this particular event is a component or step.
     *
     * Part of referenced event
     */
    partOf?: NutritionIntake[] | Procedure[] | Observation[] | Reference[];
    /**
     * A reason, Condition or observation for why the food or fluid is /was consumed.
     *
     * Reason for why the food or fluid is /was consumed
     */
    reason?: CodeableReference[];
    /**
     * Provides extra information about the Nutrition Intake that is not conveyed by the other attributes.
     *
     * Further information about the consumption
     */
    note?: Annotation[];
    /**
     * The person, animal or group who is/was consuming the food or fluid.
     *
     * Who is/was consuming the food or fluid
     */
    subject: Patient | Group | Reference;
    /**
     * Where the intake occurred.
     *
     * Where the intake occurred
     */
    location?: Location | Reference;
    /**
     * The person or organization that provided the information about the consumption of this food or fluid. Note: Use derivedFrom when a NutritionIntake is derived from other resources.
     *
     * Person or organization that provided the information about the consumption of this food or fluid
     */
    reported?: boolean | Patient | RelatedPerson | Practitioner | PractitionerRole | Organization | Reference;
    /**
     * Allows linking the NutritionIntake to the underlying NutritionOrder, or to other information, such as AllergyIntolerance, that supports or is used to derive the NutritionIntake.
     *
     * Additional supporting information
     */
    derivedFrom?: Reference[];
    /**
     * A plan, proposal or order that is fulfilled in whole or in part by this event.
     *
     * Fulfils plan, proposal or order
     */
    basedOn?: NutritionOrder[] | CarePlan[] | ServiceRequest[] | Reference[];
    /**
     * A code representing the patient or other source's judgment about the state of the intake that this assertion is about.  Generally, this will be active or completed.
     *
     * preparation | in-progress | not-done | on-hold | stopped | completed | entered-in-error | unknown
     */
    status: string;
    /**
     * Captures the reason for the current state of the NutritionIntake.
     *
     * Reason for current status
     */
    statusReason?: CodeableConcept[];
    readonly resourceType: string;
    static revive(json: any): NutritionIntake;
    toJSON(): any;
}
export declare namespace NutritionIntake {
    enum EventStatus {
        NOTDONE,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ONHOLD,
        STOPPED,
        INPROGRESS,
        UNKNOWN,
        PREPARATION
    }
    class NutritionIntakePerformerComponent extends BackboneElement {
        /**
         * Type of performer.
         *
         * Type of performer
         */
        function?: CodeableConcept;
        /**
         * Who performed the intake.
         *
         * Who performed the intake
         */
        actor: Practitioner | PractitionerRole | Organization | CareTeam | Patient | Device | RelatedPerson | Reference;
        static revive(json: any): NutritionIntakePerformerComponent;
        toJSON(): any;
    }
    class NutritionIntakeIngredientLabelComponent extends BackboneElement {
        /**
         * Total amount of nutrient consumed.
         *
         * Total amount of nutrient consumed
         */
        amount: Quantity;
        /**
         * Total nutrient consumed. This could be a macronutrient (protein, fat, carbohydrate), or a vitamin and mineral.
         *
         * Total nutrient consumed
         */
        nutrient: CodeableReference;
        static revive(json: any): NutritionIntakeIngredientLabelComponent;
        toJSON(): any;
    }
    class NutritionIntakeConsumedItemComponent extends BackboneElement {
        /**
         * Scheduled frequency of consumption.
         *
         * Scheduled frequency of consumption
         */
        schedule?: Timing;
        /**
         * Quantity of the specified food.
         *
         * Quantity of the specified food
         */
        amount?: Quantity;
        /**
         * Rate at which enteral feeding was administered.
         *
         * Rate at which enteral feeding was administered
         */
        rate?: Quantity;
        /**
         * Document the reason the food or fluid was not consumed, such as refused, held, etc.
         *
         * Reason food or fluid was not consumed
         */
        notConsumedReason?: CodeableConcept;
        /**
         * Identifies the food or fluid product that was consumed. This is potentially a link to a resource representing the details of the food product (TBD) or a simple attribute carrying a code that identifies the food from a known list of foods.
         *
         * Code that identifies the food or fluid product that was consumed
         */
        nutritionProduct: CodeableReference;
        /**
         * Indicator when a patient is in a setting where it is helpful to know if food was not consumed, such as it was refused, held (as in tube feedings), or otherwise not provided. If a consumption is being recorded from an app, such as MyFitnessPal, this indicator will likely not be used.
         *
         * Flag to indicate if the food or fluid item was refused or otherwise not consumed
         */
        notConsumed?: boolean;
        /**
         * Indicates what a category of item that was consumed: e.g., food, fluid, enteral, etc.
         *
         * The type of food or fluid product
         */
        type: CodeableConcept;
        static revive(json: any): NutritionIntakeConsumedItemComponent;
        toJSON(): any;
    }
}
