import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { UsageContext } from '../datatype/usage-context';
import { CanonicalResource } from '../model/canonical-resource';
/**
 * HAPI/FHIR <b>ExampleScenario</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ExampleScenario">http://hl7.org/fhir/StructureDefinition/ExampleScenario</a>
 * </p>
 *
 */
export declare class ExampleScenario extends CanonicalResource {
    /**
     * An absolute URI that is used to identify this example scenario when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this example scenario is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the example scenario is stored on different servers.
     *
     * Canonical identifier for this example scenario, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * The identifier that is used to identify this version of the example scenario when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the example scenario author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the example scenario
     */
    version?: string;
    /**
     * A short, descriptive, user-friendly title for the ExampleScenario.
     *
     * Name for this example scenario (human friendly)
     */
    title?: string;
    /**
     * A Boolean value to indicate that this example scenario is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A free text natural language description of the ExampleScenario from a consumer's perspective.
     *
     * Natural language description of the ExampleScenario
     */
    description?: string;
    /**
     * A legal or geographic region in which the example scenario is intended to be used.
     *
     * Intended jurisdiction for example scenario (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * What the example scenario resource is created for. This should not be used to show the business purpose of the scenario itself, but the purpose of documenting a scenario.
     *
     * The purpose of the example, e.g. to illustrate a scenario
     */
    purpose?: string;
    /**
     * A single data collection that is shared as part of the scenario.
     *
     * Data used in the scenario
     */
    instance?: ExampleScenario.ExampleScenarioInstanceComponent[];
    /**
     * A copyright statement relating to the example scenario and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the example scenario.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * A group of operations that represents a significant step within a scenario.
     *
     * Major process within scenario
     */
    process?: ExampleScenario.ExampleScenarioProcessComponent[];
    /**
     * A formal identifier that is used to identify this example scenario when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the example scenario
     */
    identifier?: Identifier[];
    /**
     * The date  (and optionally time) when the example scenario was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the example scenario changes. (e.g. the 'content logical definition').
     *
     * Date last changed
     */
    date?: Date;
    /**
     * The status of this example scenario. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate example scenario instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the example scenario.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * Temporarily retained for tooling purposes.
     *
     * To be removed?
     */
    name?: string;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * A system or person who shares or receives an instance within the scenario.
     *
     * Individual involved in exchange
     */
    actor?: ExampleScenario.ExampleScenarioActorComponent[];
    readonly resourceType: string;
    static revive(json: any): ExampleScenario;
    toJSON(): any;
}
export declare namespace ExampleScenario {
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class ExampleScenarioProcessStepAlternativeComponent extends BackboneElement {
        /**
         * A human-readable description of the alternative explaining when the alternative should occur rather than the base step.
         *
         * Human-readable description of option
         */
        description?: string;
        /**
         * Indicates the operation, sub-process or scenario that happens if the alternative option is selected.
         *
         * Alternative action(s)
         */
        step?: ExampleScenario.ExampleScenarioProcessStepComponent[];
        /**
         * The label to display for the alternative that gives a sense of the circumstance in which the alternative should be invoked.
         *
         * Label for alternative
         */
        title: string;
        static revive(json: any): ExampleScenarioProcessStepAlternativeComponent;
        toJSON(): any;
    }
    class ExampleScenarioProcessStepOperationComponent extends BackboneElement {
        /**
         * A reference to the instance that is transmitted from requester to receiver as part of the invocation of the operation.
         *
         * Instance transmitted on invocation
         */
        request?: ExampleScenario.ExampleScenarioInstanceContainedInstanceComponent;
        /**
         * The system on which the action is invoked/receives the data.
         *
         * Who receives the operation
         */
        receiver?: string;
        /**
         * A reference to the instance that is transmitted from receiver to requester as part of the operation's synchronous response (if any).
         *
         * Instance transmitted on invocation response
         */
        response?: ExampleScenario.ExampleScenarioInstanceContainedInstanceComponent;
        /**
         * The system that invokes the action/transmits the data.
         *
         * Who starts the operation
         */
        initiator?: string;
        /**
         * An explanation of what the operation represents and what it does.
         *
         * Human-friendly description of the operation
         */
        description?: string;
        /**
         * If false, the receiver is deactivated right after the operation.
         *
         * Receiver stays active?
         */
        receiverActive?: boolean;
        /**
         * The standardized type of action (FHIR or otherwise).
         *
         * Kind of action
         */
        type?: Coding;
        /**
         * A short descriptive label the step to be used in tables or diagrams.
         *
         * Label for step
         */
        title: string;
        /**
         * If false, the initiator is deactivated right after the operation.
         *
         * Initiator stays active?
         */
        initiatorActive?: boolean;
        static revive(json: any): ExampleScenarioProcessStepOperationComponent;
        toJSON(): any;
    }
    class ExampleScenarioProcessStepComponent extends BackboneElement {
        /**
         * Indicates an alternative step that can be taken instead of the sub-process, scenario or operation.  E.g. to represent non-happy-path/exceptional/atypical circumstances.
         *
         * Alternate non-typical step action
         */
        alternative?: ExampleScenario.ExampleScenarioProcessStepAlternativeComponent[];
        /**
         * The step represents a single operation invoked on receiver by sender.
         *
         * Step is simple action
         */
        operation?: ExampleScenario.ExampleScenarioProcessStepOperationComponent;
        /**
         * If true, indicates that, following this step, there is a pause in the flow and the subsequent step will occur at some later time (triggered by some event).
         *
         * Pause in the flow?
         */
        pause?: boolean;
        /**
         * The sequential number of the step, e.g. 1.2.5.
         *
         * Sequential number of the step
         */
        number?: string;
        /**
         * Indicates that the step is a complex sub-process with its own steps.
         *
         * Step is nested process
         */
        process?: ExampleScenario.ExampleScenarioProcessComponent;
        /**
         * Indicates that the step is defined by a seaparate scenario instance.
         *
         * Step is nested workflow
         */
        workflow?: string;
        static revive(json: any): ExampleScenarioProcessStepComponent;
        toJSON(): any;
    }
    class ExampleScenarioProcessComponent extends BackboneElement {
        /**
         * A short descriptive label the process to be used in tables or diagrams.
         *
         * Label for procss
         */
        title: string;
        /**
         * A significant action that occurs as part of the process.
         *
         * Event within of the process
         */
        step?: ExampleScenario.ExampleScenarioProcessStepComponent[];
        /**
         * An explanation of what the process represents and what it does.
         *
         * Human-friendly description of the process
         */
        description?: string;
        /**
         * Description of the initial state of the actors, environment and data before the process starts.
         *
         * Status before process starts
         */
        preConditions?: string;
        /**
         * Description of the final state of the actors, environment and data after the process has been successfully completed.
         *
         * Status after successful completion
         */
        postConditions?: string;
        static revive(json: any): ExampleScenarioProcessComponent;
        toJSON(): any;
    }
    class ExampleScenarioInstanceContainedInstanceComponent extends BackboneElement {
        /**
         * A reference to the key of an instance found within this one.
         *
         * Key of contained instance
         */
        instanceReference: string;
        /**
         * A reference to the key of a specific version of an instance in this instance.
         *
         * Key of contained instance version
         */
        versionReference?: string;
        static revive(json: any): ExampleScenarioInstanceContainedInstanceComponent;
        toJSON(): any;
    }
    class ExampleScenarioInstanceVersionComponent extends BackboneElement {
        /**
         * A short descriptive label the version to be used in tables or diagrams.
         *
         * Label for instance version
         */
        title: string;
        /**
         * A unique string within the instance that is used to reference the version of the instance.
         *
         * ID or acronym of the version
         */
        key: string;
        /**
         * Points to an instance (typically an example) that shows the data that would flow at this point in the scenario.
         *
         * Example instance version data
         */
        content?: Reference;
        /**
         * An explanation of what this specific version of the instance contains and represents.
         *
         * Details about version
         */
        description?: string;
        static revive(json: any): ExampleScenarioInstanceVersionComponent;
        toJSON(): any;
    }
    class ExampleScenarioInstanceComponent extends BackboneElement {
        /**
         * A code indicating the kind of data structure (FHIR resource or some other standard) this is an instance of.
         *
         * Data structure for example
         */
        structureType: Coding;
        /**
         * Refers to a profile, template or other ruleset the instance adheres to.
         *
         * Rules instance adheres to
         */
        structureProfile?: string;
        /**
         * A unique string within the scenario that is used to reference the instance.
         *
         * ID or acronym of the instance
         */
        key: string;
        /**
         * Conveys the version of the data structure instantiated.  I.e. what release of FHIR, X12, OpenEHR, etc. is instance compliant with.
         *
         * E.g. 4.0.1
         */
        structureVersion?: string;
        /**
         * Points to an instance (typically an example) that shows the data that would corespond to this instance.
         *
         * Example instance data
         */
        content?: Reference;
        /**
         * A short descriptive label the instance to be used in tables or diagrams.
         *
         * Label for instance
         */
        title: string;
        /**
         * References to other instances that can be found within this instance (e.g. the observations contained in a bundle).
         *
         * Resources contained in the instance
         */
        containedInstance?: ExampleScenario.ExampleScenarioInstanceContainedInstanceComponent[];
        /**
         * Represents the instance as it was at a specific time-point.
         *
         * Snapshot of instance that changes
         */
        version?: ExampleScenario.ExampleScenarioInstanceVersionComponent[];
        /**
         * An explanation of what the instance contains and what it's for.
         *
         * Human-friendly description of the instance
         */
        description?: string;
        static revive(json: any): ExampleScenarioInstanceComponent;
        toJSON(): any;
    }
    class ExampleScenarioActorComponent extends BackboneElement {
        /**
         * An explanation of who/what the actor is and its role in the scenario.
         *
         * Details about actor
         */
        description?: string;
        /**
         * A unique string within the scenario that is used to reference the actor.
         *
         * ID or acronym of the actor
         */
        key: string;
        /**
         * The category of actor - person or system.
         *
         * person | system
         */
        type: string;
        /**
         * The human-readable name for the actor used when rendering the scenario.
         *
         * Label for actor when rendering
         */
        title: string;
        static revive(json: any): ExampleScenarioActorComponent;
        toJSON(): any;
    }
}
