import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Address } from '../datatype/address';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { ContactPoint } from '../datatype/contact-point';
import { HumanName } from '../datatype/human-name';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { DomainResource } from '../model/domain-resource';
import { Organization } from '../model/organization';
/**
 * HAPI/FHIR <b>Practitioner</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Practitioner">http://hl7.org/fhir/StructureDefinition/Practitioner</a>
 * </p>
 *
 */
export declare class Practitioner extends DomainResource {
    /**
     * The name(s) associated with the practitioner.
     *
     * The name(s) associated with the practitioner
     */
    name?: HumanName[];
    /**
     * Whether this practitioner's record is in active use.
     *
     * Whether this practitioner's record is in active use
     */
    active?: boolean;
    /**
     * Image of the person.
     *
     * Image of the person
     */
    photo?: Attachment[];
    /**
     * A contact detail for the practitioner, e.g. a telephone number or an email address.
     *
     * A contact detail for the practitioner (that apply to all roles)
     */
    telecom?: ContactPoint[];
    /**
     * A language which may be used to communicate with the practitioner, often for correspondence/administrative purposes.

The `PractitionerRole.communication` property should be used for publishing the languages that a practitioner is able to communicate with patients (on a per Organization/Role basis).
     *
     * A language which may be used to communicate with the practitioner
     */
    communication?: Practitioner.PractitionerCommunicationComponent[];
    /**
     * The date of birth for the practitioner.
     *
     * The date  on which the practitioner was born
     */
    birthDate?: Date;
    /**
     * An identifier that applies to this person in this role.
     *
     * An identifier for the person as this agent
     */
    identifier?: Identifier[];
    /**
     * The official qualifications, certifications, accreditations, training, licenses (and other types of educations/skills/capabilities) that authorize or otherwise pertain to the provision of care by the practitioner.

For example, a medical license issued by a medical board of licensure authorizing the practitioner to practice medicine within a certain locality.
     *
     * Qualifications, certifications, accreditations, licenses, training, etc. pertaining to the provision of care
     */
    qualification?: Practitioner.PractitionerQualificationComponent[];
    /**
     * Indicates if the practitioner is deceased or not.
     *
     * Indicates if the practitioner is deceased or not
     */
    deceased?: boolean | Date;
    /**
     * Address(es) of the practitioner that are not role specific (typically home address).
Work addresses are not typically entered in this property as they are usually role dependent.
     *
     * Address(es) of the practitioner that are not role specific (typically home address)
     */
    address?: Address[];
    /**
     * Administrative Gender - the gender that the person is considered to have for administration and record keeping purposes.
     *
     * male | female | other | unknown
     */
    gender?: string;
    readonly resourceType: string;
    static revive(json: any): Practitioner;
    toJSON(): any;
}
export declare namespace Practitioner {
    enum AdministrativeGender {
        OTHER,
        NULL,
        UNKNOWN,
        MALE,
        FEMALE
    }
    class PractitionerCommunicationComponent extends BackboneElement {
        /**
         * The ISO-639-1 alpha 2 code in lower case for the language, optionally followed by a hyphen and the ISO-3166-1 alpha 2 code for the region in upper case; e.g. "en" for English, or "en-US" for American English versus "en-AU" for Australian English.
         *
         * The language code used to communicate with the practitioner
         */
        language: CodeableConcept;
        /**
         * Indicates whether or not the person prefers this language (over other languages he masters up a certain level).
         *
         * Language preference indicator
         */
        preferred?: boolean;
        static revive(json: any): PractitionerCommunicationComponent;
        toJSON(): any;
    }
    class PractitionerQualificationComponent extends BackboneElement {
        /**
         * Organization that regulates and issues the qualification.
         *
         * Organization that regulates and issues the qualification
         */
        issuer?: Organization | Reference;
        /**
         * Coded representation of the qualification.
         *
         * Coded representation of the qualification
         */
        code: CodeableConcept;
        /**
         * Period during which the qualification is valid.
         *
         * Period during which the qualification is valid
         */
        period?: Period;
        /**
         * An identifier that applies to this person's qualification.
         *
         * An identifier for this qualification for the practitioner
         */
        identifier?: Identifier[];
        static revive(json: any): PractitionerQualificationComponent;
        toJSON(): any;
    }
}
