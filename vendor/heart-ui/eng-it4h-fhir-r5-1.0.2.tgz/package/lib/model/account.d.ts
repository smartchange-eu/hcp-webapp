import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Money } from '../datatype/money';
import { Period } from '../datatype/period';
import { Coverage } from '../model/coverage';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { HealthcareService } from '../model/healthcare-service';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Account</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Account">http://hl7.org/fhir/StructureDefinition/Account</a>
 * </p>
 *
 */
export declare class Account extends DomainResource {
    /**
     * Time the balance amount was calculated.
     *
     * Time the balance amount was calculated
     */
    calculatedAt?: Date;
    /**
     * Indicates whether the account is presently used/usable or not.
     *
     * active | inactive | entered-in-error | on-hold | unknown
     */
    status: string;
    /**
     * Name used for the account when displaying it to humans in reports, etc.
     *
     * Human-readable label
     */
    name?: string;
    /**
     * The default currency for the account.
     *
     * The base or default currency
     */
    currency?: CodeableConcept;
    /**
     * The calculated account balances - these are calculated and processed by the finance system.

The balances with a `term` that is not current are usually generated/updated by an invoicing or similar process.
     *
     * Calculated account balance(s)
     */
    balance?: Account.AccountBalanceComponent[];
    /**
     * Other associated accounts related to this account.
     *
     * Other associated accounts related to this account
     */
    relatedAccount?: Account.AccountRelatedAccountComponent[];
    /**
     * The date range of services associated with this account.
     *
     * Transaction window
     */
    servicePeriod?: Period;
    /**
     * Categorizes the account for reporting and searching purposes.
     *
     * E.g. patient, expense, depreciation
     */
    type?: CodeableConcept;
    /**
     * The BillingStatus tracks the lifecycle of the account through the billing process. It indicates how transactions are treated when they are allocated to the account.
     *
     * Tracks the lifecycle of the account through the billing process
     */
    billingStatus?: CodeableConcept;
    /**
     * Provides additional information about what the account tracks and how it is used.
     *
     * Explanation of purpose/use
     */
    description?: string;
    /**
     * When using an account for billing a specific Encounter the set of diagnoses that are relevant for billing are stored here on the account where they are able to be sequenced appropriately prior to processing to produce claim(s).
     *
     * The list of diagnoses relevant to this account
     */
    diagnosis?: Account.AccountDiagnosisComponent[];
    /**
     * The parties responsible for balancing the account if other payment options fall short.
     *
     * The parties ultimately responsible for balancing the Account
     */
    guarantor?: Account.GuarantorComponent[];
    /**
     * When using an account for billing a specific Encounter the set of procedures that are relevant for billing are stored here on the account where they are able to be sequenced appropriately prior to processing to produce claim(s).
     *
     * The list of procedures relevant to this account
     */
    procedure?: Account.AccountProcedureComponent[];
    /**
     * Identifies the entity which incurs the expenses. While the immediate recipients of services or goods might be entities related to the subject, the expenses were ultimately incurred by the subject of the Account.
     *
     * The entity that caused the expenses
     */
    subject?: Patient[] | Device[] | Practitioner[] | PractitionerRole[] | Location[] | HealthcareService[] | Organization[] | Reference[];
    /**
     * The party(s) that are responsible for covering the payment of this account, and what order should they be applied to the account.
     *
     * The party(s) that are responsible for covering the payment of this account, and what order should they be applied to the account
     */
    coverage?: Account.CoverageComponent[];
    /**
     * Indicates the service area, hospital, department, etc. with responsibility for managing the Account.
     *
     * Entity managing the Account
     */
    owner?: Organization | Reference;
    /**
     * Unique identifier used to reference the account.  Might or might not be intended for human use (e.g. credit card number).
     *
     * Account number
     */
    identifier?: Identifier[];
    readonly resourceType: string;
    static revive(json: any): Account;
    toJSON(): any;
}
export declare namespace Account {
    enum AccountStatus {
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        INACTIVE,
        ONHOLD,
        UNKNOWN
    }
    class AccountBalanceComponent extends BackboneElement {
        /**
         * The actual balance value calculated for the age defined in the term property.
         *
         * Calculated amount
         */
        amount: Money;
        /**
         * Who is expected to pay this part of the balance.
         *
         * Who is expected to pay this part of the balance
         */
        aggregate?: CodeableConcept;
        /**
         * The term of the account balances - The balance value is the amount that was outstanding for this age.
         *
         * current | 30 | 60 | 90 | 120
         */
        term?: CodeableConcept;
        /**
         * The amount is only an estimated value - this is likely common for `current` term balances, but not with known terms (that were generated by a backend process).
         *
         * Estimated balance
         */
        estimate?: boolean;
        static revive(json: any): AccountBalanceComponent;
        toJSON(): any;
    }
    class AccountRelatedAccountComponent extends BackboneElement {
        /**
         * Reference to an associated Account.
         *
         * Reference to an associated Account
         */
        account: Account | Reference;
        /**
         * Relationship of the associated Account.
         *
         * Relationship of the associated Account
         */
        relationship?: CodeableConcept;
        static revive(json: any): AccountRelatedAccountComponent;
        toJSON(): any;
    }
    class AccountProcedureComponent extends BackboneElement {
        /**
         * How this procedure value should be used in charging the account.
         *
         * How this procedure value should be used in charging the account
         */
        type?: CodeableConcept[];
        /**
         * Any devices that were associated with the procedure relevant to the account.
         *
         * Any devices that were associated with the procedure
         */
        device?: Device[] | Reference[];
        /**
         * Date of the procedure when using a coded procedure. If using a reference to a procedure, then the date on the procedure should be used.
         *
         * Date of the procedure (when coded procedure)
         */
        dateOfService?: Date;
        /**
         * The package code can be used to group procedures that may be priced or delivered as a single product. Such as DRGs.
         *
         * Package Code specific for billing
         */
        packageCode?: CodeableConcept[];
        /**
         * Ranking of the procedure (for each type).
         *
         * Ranking of the procedure (for each type)
         */
        sequence?: number;
        /**
         * The procedure relevant to the account.
         *
         * The procedure relevant to the account
         */
        code: CodeableReference;
        static revive(json: any): AccountProcedureComponent;
        toJSON(): any;
    }
    class AccountDiagnosisComponent extends BackboneElement {
        /**
         * Ranking of the diagnosis (for each type).
         *
         * Date of the diagnosis (when coded diagnosis)
         */
        dateOfDiagnosis?: Date;
        /**
         * Type that this diagnosis has relevant to the account (e.g. admission, billing, discharge …).
         *
         * Type that this diagnosis has relevant to the account (e.g. admission, billing, discharge …)
         */
        type?: CodeableConcept[];
        /**
         * The diagnosis relevant to the account.
         *
         * The diagnosis relevant to the account
         */
        condition: CodeableReference;
        /**
         * Ranking of the diagnosis (for each type).
         *
         * Ranking of the diagnosis (for each type)
         */
        sequence?: number;
        /**
         * Was the Diagnosis present on Admission in the related Encounter.
         *
         * Diagnosis present on Admission
         */
        onAdmission?: boolean;
        /**
         * The package code can be used to group diagnoses that may be priced or delivered as a single product. Such as DRGs.
         *
         * Package Code specific for billing
         */
        packageCode?: CodeableConcept[];
        static revive(json: any): AccountDiagnosisComponent;
        toJSON(): any;
    }
    class GuarantorComponent extends BackboneElement {
        /**
         * The entity who is responsible.
         *
         * Responsible entity
         */
        party: Patient | RelatedPerson | Organization | Reference;
        /**
         * A guarantor may be placed on credit hold or otherwise have their role temporarily suspended.
         *
         * Credit or other hold applied
         */
        onHold?: boolean;
        /**
         * The timeframe during which the guarantor accepts responsibility for the account.
         *
         * Guarantee account during
         */
        period?: Period;
        static revive(json: any): GuarantorComponent;
        toJSON(): any;
    }
    class CoverageComponent extends BackboneElement {
        /**
         * The priority of the coverage in the context of this account.
         *
         * The priority of the coverage in the context of this account
         */
        priority?: number;
        /**
         * The party(s) that contribute to payment (or part of) of the charges applied to this account (including self-pay).

A coverage may only be responsible for specific types of charges, and the sequence of the coverages in the account could be important when processing billing.
         *
         * The party(s), such as insurances, that may contribute to the payment of this account
         */
        coverage: Coverage | Reference;
        static revive(json: any): CoverageComponent;
        toJSON(): any;
    }
}
