import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Timing } from '../datatype/timing';
import { BiologicallyDerivedProduct } from '../model/biologically-derived-product';
import { Contract } from '../model/contract';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { InventoryItem } from '../model/inventory-item';
import { Location } from '../model/location';
import { Medication } from '../model/medication';
import { NutritionProduct } from '../model/nutrition-product';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Substance } from '../model/substance';
import { SupplyRequest } from '../model/supply-request';
/**
 * HAPI/FHIR <b>SupplyDelivery</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/SupplyDelivery">http://hl7.org/fhir/StructureDefinition/SupplyDelivery</a>
 * </p>
 *
 */
export declare class SupplyDelivery extends DomainResource {
    /**
     * Indicates the type of supply being provided.  Examples include: Medication, Device, Biologically Derived Product.
     *
     * Category of supply event
     */
    type?: CodeableConcept;
    /**
     * A code specifying the state of the dispense event.
     *
     * in-progress | completed | abandoned | entered-in-error
     */
    status?: string;
    /**
     * A plan, proposal or order that is fulfilled in whole or in part by this event.
     *
     * Fulfills plan, proposal or order
     */
    basedOn?: SupplyRequest[] | Reference[];
    /**
     * The item that is being delivered or has been supplied.
     *
     * The item that is delivered or supplied
     */
    suppliedItem?: SupplyDelivery.SupplyDeliverySuppliedItemComponent[];
    /**
     * Identification of the facility/location where the delivery was shipped to.
     *
     * Where the delivery was sent
     */
    destination?: Location | Reference;
    /**
     * The date or time(s) the activity occurred.
     *
     * When event occurred
     */
    occurrence?: Date | Period | Timing;
    /**
     * Identifies the individual or organization that received the delivery.
     *
     * Who received the delivery
     */
    receiver?: Practitioner[] | PractitionerRole[] | Organization[] | Reference[];
    /**
     * The individual or organization responsible for supplying the delivery.
     *
     * The item supplier
     */
    supplier?: Practitioner | PractitionerRole | Organization | Reference;
    /**
     * A link to a resource representing the person whom the delivered item is for.
     *
     * Patient for whom the item is supplied
     */
    patient?: Patient | Reference;
    /**
     * Identifier for the supply delivery event that is used to identify it across multiple disparate systems.
     *
     * External identifier
     */
    identifier?: Identifier[];
    /**
     * A larger event of which this particular event is a component or step.
     *
     * Part of referenced event
     */
    partOf?: SupplyDelivery[] | Contract[] | Reference[];
    readonly resourceType: string;
    static revive(json: any): SupplyDelivery;
    toJSON(): any;
}
export declare namespace SupplyDelivery {
    enum SupplyDeliveryStatus {
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ABANDONED,
        INPROGRESS
    }
    class SupplyDeliverySuppliedItemComponent extends BackboneElement {
        /**
         * Identifies the medication, substance, device or biologically derived product being supplied. This is either a link to a resource representing the details of the item or a code that identifies the item from a known list.
         *
         * Medication, Substance, Device or Biologically Derived Product supplied
         */
        item?: CodeableConcept | Medication | Substance | Device | BiologicallyDerivedProduct | NutritionProduct | InventoryItem | Reference;
        /**
         * The amount of the item that has been supplied.  Unit of measure may be included.
         *
         * Amount supplied
         */
        quantity?: Quantity;
        static revive(json: any): SupplyDeliverySuppliedItemComponent;
        toJSON(): any;
    }
}
