import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { Expression } from '../datatype/expression';
import { Period } from '../datatype/period';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Permission</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Permission">http://hl7.org/fhir/StructureDefinition/Permission</a>
 * </p>
 *
 */
export declare class Permission extends DomainResource {
    /**
     * The person or entity that asserts the permission.
     *
     * The person or entity that asserts the permission
     */
    asserter?: Practitioner | PractitionerRole | Organization | CareTeam | Patient | RelatedPerson | HealthcareService | Reference;
    /**
     * The date that permission was asserted.
     *
     * The date that permission was asserted
     */
    date?: Date[];
    /**
     * Defines a procedure for arriving at an access decision given the set of rules.
     *
     * deny-overrides | permit-overrides | ordered-deny-overrides | ordered-permit-overrides | deny-unless-permit | permit-unless-deny
     */
    combining: string;
    /**
     * The period in which the permission is active.
     *
     * The period in which the permission is active
     */
    validity?: Period;
    /**
     * The asserted justification for using the data.
     *
     * The asserted justification for using the data
     */
    justification?: Permission.PermissionJustificationComponent;
    /**
     * A set of rules.
     *
     * Constraints to the Permission
     */
    rule?: Permission.RuleComponent[];
    /**
     * Status.
     *
     * active | entered-in-error | draft | rejected
     */
    status: string;
    readonly resourceType: string;
    static revive(json: any): Permission;
    toJSON(): any;
}
export declare namespace Permission {
    enum PermissionStatus {
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        DRAFT,
        REJECTED
    }
    enum PermissionRuleCombining {
        ORDEREDDENYOVERRIDES,
        DENYOVERRIDES,
        DENYUNLESSPERMIT,
        NULL,
        ORDEREDPERMITOVERRIDES,
        PERMITOVERRIDES,
        PERMITUNLESSDENY
    }
    class RuleActivityComponent extends BackboneElement {
        /**
         * The purpose for which the permission is given.
         *
         * The purpose for which the permission is given
         */
        purpose?: CodeableConcept[];
        /**
         * The actor(s) authorized for the defined activity.
         *
         * Authorized actor(s)
         */
        actor?: Device[] | Group[] | CareTeam[] | Organization[] | Patient[] | Practitioner[] | RelatedPerson[] | PractitionerRole[] | Reference[];
        /**
         * Actions controlled by this Rule.
         *
         * Actions controlled by this rule
         */
        action?: CodeableConcept[];
        static revive(json: any): RuleActivityComponent;
        toJSON(): any;
    }
    class RuleDataResourceComponent extends BackboneElement {
        /**
         * A reference to a specific resource that defines which resources are covered by this consent.
         *
         * The actual data reference
         */
        reference: Reference;
        /**
         * How the resource reference is interpreted when testing consent restrictions.
         *
         * instance | related | dependents | authoredby
         */
        meaning: string;
        static revive(json: any): RuleDataResourceComponent;
        toJSON(): any;
    }
    class RuleDataComponent extends BackboneElement {
        /**
         * Explicit FHIR Resource references.
         *
         * Explicit FHIR Resource references
         */
        resource?: Permission.RuleDataResourceComponent[];
        /**
         * The data in scope are those with the given codes present in that data .meta.security element.
         *
         * Security tag code on .meta.security
         */
        security?: Coding[];
        /**
         * Clinical or Operational Relevant period of time that bounds the data controlled by this rule.
         *
         * Timeframe encompasing data create/update
         */
        period?: Period[];
        /**
         * Used when other data selection elements are insufficient.
         *
         * Expression identifying the data
         */
        expression?: Expression;
        static revive(json: any): RuleDataComponent;
        toJSON(): any;
    }
    class RuleComponent extends BackboneElement {
        /**
         * What limits apply to the use of the data.
         *
         * What limits apply to the use of the data
         */
        limit?: CodeableConcept[];
        /**
         * deny | permit.
         *
         * deny | permit
         */
        type?: string;
        /**
         * A description or definition of which activities are allowed to be done on the data.
         *
         * The selection criteria to identify data that is within scope of this provision
         */
        data?: Permission.RuleDataComponent[];
        /**
         * A description or definition of which activities are allowed to be done on the data.
         *
         * A description or definition of which activities are allowed to be done on the data
         */
        activity?: Permission.RuleActivityComponent[];
        static revive(json: any): RuleComponent;
        toJSON(): any;
    }
    class PermissionJustificationComponent extends BackboneElement {
        /**
         * This would be a codeableconcept, or a coding, which can be constrained to , for example, the 6 grounds for processing in GDPR.
         *
         * The regulatory grounds upon which this Permission builds
         */
        basis?: CodeableConcept[];
        /**
         * Justifing rational.
         *
         * Justifing rational
         */
        evidence?: Reference[];
        static revive(json: any): PermissionJustificationComponent;
        toJSON(): any;
    }
}
