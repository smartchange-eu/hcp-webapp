import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { RelatedArtifact } from '../datatype/related-artifact';
import { UsageContext } from '../datatype/usage-context';
import { MetadataResource } from '../model/metadata-resource';
/**
 * HAPI/FHIR <b>ValueSet</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ValueSet">http://hl7.org/fhir/StructureDefinition/ValueSet</a>
 * </p>
 *
 */
export declare class ValueSet extends MetadataResource {
    /**
     * The date on which the resource content was approved by the publisher. Approval happens once when the content is officially approved for usage.
     *
     * When the ValueSet was approved by publisher
     */
    approvalDate?: Date;
    /**
     * A copyright statement relating to the value set and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the value set.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * The date (and optionally time) when the value set metadata or content logical definition (.compose) was created or revised.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * A legal or geographic region in which the value set is intended to be used.
     *
     * Intended jurisdiction for value set (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * Explanation of why this value set is needed and why it has been designed as it has.
     *
     * Why this value set is defined
     */
    purpose?: string;
    /**
     * A Boolean value to indicate that this value set is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A free text natural language description of the value set from a consumer's perspective. The textual description specifies the span of meanings for concepts to be included within the Value Set Expansion, and also may specify the intended use and limitations of the Value Set.
     *
     * Natural language description of the value set
     */
    description?: string;
    /**
     * A short, descriptive, user-friendly title for the value set.
     *
     * Name for this value set (human friendly)
     */
    title?: string;
    /**
     * Indicates the mechanism used to compare versions to determine which ValueSet is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * Description of the semantic space the Value Set Expansion is intended to cover and should further clarify the text in ValueSet.description.
     *
     * Description of the semantic space the Value Set Expansion is intended to cover and should further clarify the text in ValueSet.description
     */
    scope?: ValueSet.ValueSetScopeComponent;
    /**
     * An individual or organization asserted by the publisher to be responsible for officially endorsing the ValueSet for use in some setting.
     *
     * Who endorsed the ValueSet
     */
    endorser?: ContactDetail[];
    /**
     * Related artifacts such as additional documentation, justification, dependencies, bibliographic references, and predecessor and successor artifacts.
     *
     * Additional documentation, citations, etc
     */
    relatedArtifact?: RelatedArtifact[];
    /**
     * A formal identifier that is used to identify this value set when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the value set (business identifier)
     */
    identifier?: Identifier[];
    /**
     * An individual or organization primarily responsible for internal coherence of the ValueSet.
     *
     * Who edited the ValueSet
     */
    editor?: ContactDetail[];
    /**
     * An individiual or organization primarily involved in the creation and maintenance of the ValueSet.
     *
     * Who authored the ValueSet
     */
    author?: ContactDetail[];
    /**
     * The period during which the ValueSet content was or is planned to be in active use.
     *
     * When the ValueSet is expected to be used
     */
    effectivePeriod?: Period;
    /**
     * An individual or organization asserted by the publisher to be primarily responsible for review of some aspect of the ValueSet.
     *
     * Who reviewed the ValueSet
     */
    reviewer?: ContactDetail[];
    /**
     * A value set can also be "expanded", where the value set is turned into a simple collection of enumerated codes. This element holds the expansion, if it has been performed.
     *
     * Used when the value set is "expanded"
     */
    expansion?: ValueSet.ValueSetExpansionComponent;
    /**
     * An absolute URI that is used to identify this value set when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this value set is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the value set is stored on different servers.
     *
     * Canonical identifier for this value set, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * The identifier that is used to identify this version of the value set when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the value set author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the value set
     */
    version?: string;
    /**
     * If this is set to 'true', then no new versions of the content logical definition can be created.  Note: Other metadata might still change.
     *
     * Indicates whether or not any change to the content logical definition may occur
     */
    immutable?: boolean;
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * The date on which the resource content was last reviewed. Review happens periodically after approval but does not change the original approval date.
     *
     * When the ValueSet was last reviewed by the publisher
     */
    lastReviewDate?: Date;
    /**
     * A set of criteria that define the contents of the value set by including or excluding codes selected from the specified code system(s) that the value set draws from. This is also known as the Content Logical Definition (CLD).
     *
     * Content logical definition of the value set (CLD)
     */
    compose?: ValueSet.ValueSetComposeComponent;
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the value set.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * Descriptions related to the content of the ValueSet. Topics provide a high-level categorization as well as keywords for the ValueSet that can be useful for filtering and searching.
     *
     * E.g. Education, Treatment, Assessment, etc
     */
    topic?: CodeableConcept[];
    /**
     * A natural language name identifying the value set. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this value set (computer friendly)
     */
    name?: string;
    /**
     * The status of this value set. Enables tracking the life-cycle of the content. The status of the value set applies to the value set definition (ValueSet.compose) and the associated ValueSet metadata. Expansions do not have a state.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate value set instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    readonly resourceType: string;
    static revive(json: any): ValueSet;
    toJSON(): any;
}
export declare namespace ValueSet {
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class ValueSetScopeComponent extends BackboneElement {
        /**
         * Criteria describing which concepts or codes should be included and why.
         *
         * Criteria describing which concepts or codes should be included and why
         */
        inclusionCriteria?: string;
        /**
         * Criteria describing which concepts or codes should be excluded and why.
         *
         * Criteria describing which concepts or codes should be excluded and why
         */
        exclusionCriteria?: string;
        static revive(json: any): ValueSetScopeComponent;
        toJSON(): any;
    }
    class ConceptSubPropertyComponent extends BackboneElement {
        /**
         * A code that is a reference to ValueSet.expansion.property.code.
         *
         * Reference to ValueSet.expansion.property.code
         */
        code: string;
        /**
         * The value of this subproperty.
         *
         * Value of the subproperty for this concept
         */
        value: string | Coding | number | boolean | Date | number;
        static revive(json: any): ConceptSubPropertyComponent;
        toJSON(): any;
    }
    class ConceptPropertyComponent extends BackboneElement {
        /**
         * A code that is a reference to ValueSet.expansion.property.code.
         *
         * Reference to ValueSet.expansion.property.code
         */
        code: string;
        /**
         * A subproperty value for this concept.
         *
         * SubProperty value for the concept
         */
        subProperty?: ValueSet.ConceptSubPropertyComponent[];
        /**
         * The value of this property.
         *
         * Value of the property for this concept
         */
        value: string | Coding | number | boolean | Date | number;
        static revive(json: any): ConceptPropertyComponent;
        toJSON(): any;
    }
    class ValueSetExpansionContainsComponent extends BackboneElement {
        /**
         * An absolute URI which is the code system in which the code for this item in the expansion is defined.
         *
         * System value for the code
         */
        system?: string;
        /**
         * If the concept is inactive in the code system that defines it. Inactive codes are those that are no longer to be used, but are maintained by the code system for understanding legacy data. It might not be known or specified whether a concept is inactive (and it may depend on the context of use).
         *
         * If concept is inactive in the code system
         */
        inactive?: boolean;
        /**
         * The code for this item in the expansion hierarchy. If this code is missing the entry in the hierarchy is a place holder (abstract) and does not represent a valid code in the value set.
         *
         * Code - if blank, this is not a selectable code
         */
        code?: string;
        /**
         * Other codes and entries contained under this entry in the hierarchy.
         *
         * Codes contained under this entry
         */
        contains?: ValueSet.ValueSetExpansionContainsComponent[];
        /**
         * The recommended display for this item in the expansion.
         *
         * User display for the concept
         */
        display?: string;
        /**
         * Additional representations for this item - other languages, aliases, specialized purposes, used for particular purposes, etc. These are relevant when the conditions of the expansion do not fix to a single correct representation.
         *
         * Additional representations for this item
         */
        designation?: ValueSet.ConceptReferenceDesignationComponent[];
        /**
         * If true, this entry is included in the expansion for navigational purposes, and the user cannot select the code directly as a proper value.
         *
         * If user cannot select this entry
         */
        abstract?: boolean;
        /**
         * A property value for this concept.
         *
         * Property value for the concept
         */
        property?: ValueSet.ConceptPropertyComponent[];
        /**
         * The version of the code system from this code was taken. Note that a well-maintained code system does not need the version reported, because the meaning of codes is consistent across versions. However this cannot consistently be assured, and when the meaning is not guaranteed to be consistent, the version SHOULD be exchanged.
         *
         * Version in which this code/display is defined
         */
        version?: string;
        static revive(json: any): ValueSetExpansionContainsComponent;
        toJSON(): any;
    }
    class ValueSetExpansionPropertyComponent extends BackboneElement {
        /**
         * A code that is used to identify the property. The code is used in ValueSet.expansion.contains.property.code.
         *
         * Identifies the property on the concepts, and when referred to in operations
         */
        code: string;
        /**
         * Reference to the formal meaning of the property. One possible source of meaning is the [Concept Properties](codesystem-concept-properties.html) code system.
         *
         * Formal identifier for the property
         */
        uri?: string;
        static revive(json: any): ValueSetExpansionPropertyComponent;
        toJSON(): any;
    }
    class ValueSetExpansionParameterComponent extends BackboneElement {
        /**
         * Name of the input parameter to the $expand operation; may be a server-assigned name for additional default or other server-supplied parameters used to control the expansion process.
         *
         * Name as assigned by the client or server
         */
        name: string;
        /**
         * The value of the parameter.
         *
         * Value of the named parameter
         */
        value?: string | boolean | number | number | Date;
        static revive(json: any): ValueSetExpansionParameterComponent;
        toJSON(): any;
    }
    class ValueSetExpansionComponent extends BackboneElement {
        /**
         * A property defines an additional slot through which additional information can be provided about a concept.
         *
         * Additional information supplied about each concept
         */
        property?: ValueSet.ValueSetExpansionPropertyComponent[];
        /**
         * The time at which the expansion was produced by the expanding system.
         *
         * Time ValueSet expansion happened
         */
        timestamp: Date;
        /**
         * As per paging Search results, the next URLs are opaque to the client, have no dictated structure, and only the server understands them.
         *
         * Opaque urls for paging through expansion results
         */
        next?: string;
        /**
         * An identifier that uniquely identifies this expansion of the valueset, based on a unique combination of the provided parameters, the system default parameters, and the underlying system code system versions etc. Systems may re-use the same identifier as long as those factors remain the same, and the expansion is the same, but are not required to do so. This is a business identifier.
         *
         * Identifies the value set expansion (business identifier)
         */
        identifier?: string;
        /**
         * The total number of concepts in the expansion. If the number of concept nodes in this resource is less than the stated number, then the server can return more using the offset parameter.
         *
         * Total number of codes in the expansion
         */
        total?: number;
        /**
         * The codes that are contained in the value set expansion.
         *
         * Codes in the value set
         */
        contains?: ValueSet.ValueSetExpansionContainsComponent[];
        /**
         * If paging is being used, the offset at which this resource starts.  I.e. this resource is a partial view into the expansion. If paging is not being used, this element SHALL NOT be present.
         *
         * Offset at which this resource starts
         */
        offset?: number;
        /**
         * A parameter that controlled the expansion process. These parameters may be used by users of expanded value sets to check whether the expansion is suitable for a particular purpose, or to pick the correct expansion.
         *
         * Parameter that controlled the expansion process
         */
        parameter?: ValueSet.ValueSetExpansionParameterComponent[];
        static revive(json: any): ValueSetExpansionComponent;
        toJSON(): any;
    }
    class ConceptSetFilterComponent extends BackboneElement {
        /**
         * The kind of operation to perform as a part of the filter criteria.
         *
         * = | is-a | descendent-of | is-not-a | regex | in | not-in | generalizes | child-of | descendent-leaf | exists
         */
        op: string;
        /**
         * A code that identifies a property or a filter defined in the code system.
         *
         * A property/filter defined by the code system
         */
        property: string;
        /**
         * The match value may be either a code defined by the system, or a string value, which is a regex match on the literal string of the property value  (if the filter represents a property defined in CodeSystem) or of the system filter value (if the filter represents a filter defined in CodeSystem) when the operation is 'regex', or one of the values (true and false), when the operation is 'exists'.
         *
         * Code from the system, or regex criteria, or boolean value for exists
         */
        value: string;
        static revive(json: any): ConceptSetFilterComponent;
        toJSON(): any;
    }
    class ConceptReferenceDesignationComponent extends BackboneElement {
        /**
         * The text value for this designation.
         *
         * The text value for this designation
         */
        value: string;
        /**
         * Additional codes that detail how this designation would be used, if there is more than one use.
         *
         * Additional ways how this designation would be used
         */
        additionalUse?: Coding[];
        /**
         * The language this designation is defined for.
         *
         * Human language of the designation
         */
        language?: string;
        /**
         * A code that represents types of uses of designations.
         *
         * Types of uses of designations
         */
        use?: Coding;
        static revive(json: any): ConceptReferenceDesignationComponent;
        toJSON(): any;
    }
    class ConceptReferenceComponent extends BackboneElement {
        /**
         * Specifies a code for the concept to be included or excluded.
         *
         * Code or expression from system
         */
        code: string;
        /**
         * The text to display to the user for this concept in the context of this valueset. If no display is provided, then applications using the value set use the display specified for the code by the system.
         *
         * Text to display for this code for this value set in this valueset
         */
        display?: string;
        /**
         * Additional representations for this concept when used in this value set - other languages, aliases, specialized purposes, used for particular purposes, etc.
         *
         * Additional representations for this concept
         */
        designation?: ValueSet.ConceptReferenceDesignationComponent[];
        static revive(json: any): ConceptReferenceComponent;
        toJSON(): any;
    }
    class ConceptSetComponent extends BackboneElement {
        /**
         * Specifies a concept to be included or excluded.
         *
         * A concept defined in the system
         */
        concept?: ValueSet.ConceptReferenceComponent[];
        /**
         * Select concepts by specifying a matching criterion based on the properties (including relationships) defined by the system, or on filters defined by the system. If multiple filters are specified within the include, they SHALL all be true.
         *
         * Select codes/concepts by their properties (including relationships)
         */
        filter?: ValueSet.ConceptSetFilterComponent[];
        /**
         * A copyright statement for the specific code system asserted by the containing ValueSet.compose.include element's system value (if the associated ValueSet.compose.include.version element is not present); or the code system and version combination (if the associated ValueSet.compose.include.version element is present).
         *
         * A copyright statement for the specific code system included in the value set
         */
        copyright?: string;
        /**
         * An absolute URI which is the code system from which the selected codes come from.
         *
         * The system the codes come from
         */
        system?: string;
        /**
         * Selects the concepts found in this value set (based on its value set definition). This is an absolute URI that is a reference to ValueSet.url.  If multiple value sets are specified this includes the intersection of the contents of all of the referenced value sets.
         *
         * Select the contents included in this value set
         */
        valueSet?: string[];
        /**
         * The version of the code system that the codes are selected from, or the special version '*' for all versions.
         *
         * Specific version of the code system referred to
         */
        version?: string;
        static revive(json: any): ConceptSetComponent;
        toJSON(): any;
    }
    class ValueSetComposeComponent extends BackboneElement {
        /**
         * The Locked Date is  the effective date that is used to determine the version of all referenced Code Systems and Value Set Definitions included in the compose that are not already tied to a specific version.
         *
         * Fixed date for references with no specified version (transitive)
         */
        lockedDate?: Date;
        /**
         * Exclude one or more codes from the value set based on code system filters and/or other value sets.
         *
         * Explicitly exclude codes from a code system or other value sets
         */
        exclude?: ValueSet.ConceptSetComponent[];
        /**
         * A property to return in the expansion, if the client doesn't ask for any particular properties. May be either a code from the code system definition (convenient) or a the formal URI that refers to the property. The special value '*' means all properties known to the server.
         *
         * Property to return if client doesn't override
         */
        property?: string[];
        /**
         * Whether inactive codes - codes that are not approved for current use - are in the value set. If inactive = true, inactive codes are to be included in the expansion, if inactive = false, the inactive codes will not be included in the expansion. If absent, the behavior is determined by the implementation, or by the applicable $expand parameters (but generally, inactive codes would be expected to be included).
         *
         * Whether inactive codes are in the value set
         */
        inactive?: boolean;
        /**
         * Include one or more codes from a code system or other value set(s).
         *
         * Include one or more codes from a code system or other value set(s)
         */
        include: ValueSet.ConceptSetComponent[];
        static revive(json: any): ValueSetComposeComponent;
        toJSON(): any;
    }
}
