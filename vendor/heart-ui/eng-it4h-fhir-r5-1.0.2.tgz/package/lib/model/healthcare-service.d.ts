import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Attachment } from '../datatype/attachment';
import { Availability } from '../datatype/availability';
import { CodeableConcept } from '../datatype/codeable-concept';
import { ExtendedContactDetail } from '../datatype/extended-contact-detail';
import { Identifier } from '../datatype/identifier';
import { DomainResource } from '../model/domain-resource';
import { Endpoint } from '../model/endpoint';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
/**
 * HAPI/FHIR <b>HealthcareService</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/HealthcareService">http://hl7.org/fhir/StructureDefinition/HealthcareService</a>
 * </p>
 *
 */
export declare class HealthcareService extends DomainResource {
    /**
     * Indicates whether or not a prospective consumer will require an appointment for a particular service at a site to be provided by the Organization. Indicates if an appointment is required for access to this service.
     *
     * If an appointment is required for access to this service
     */
    appointmentRequired?: boolean;
    /**
     * This flag is used to mark the record to not be used. This is not used when a center is closed for maintenance, or for holidays, the notAvailable period is to be used for this.
     *
     * Whether this HealthcareService record is in active use
     */
    active?: boolean;
    /**
     * If there is a photo/symbol associated with this HealthcareService, it may be included here to facilitate quick identification of the service in a list.
     *
     * Facilitates quick identification of the service
     */
    photo?: Attachment;
    /**
     * Does this service have specific eligibility requirements that need to be met in order to use the service?
     *
     * Specific eligibility requirements required to use the service
     */
    eligibility?: HealthcareService.HealthcareServiceEligibilityComponent[];
    /**
     * Programs that this service is applicable to.
     *
     * Programs that this service is applicable to
     */
    program?: CodeableConcept[];
    /**
     * A collection of times that the healthcare service is available.
     *
     * Times the healthcare service is available (including exceptions)
     */
    availability?: Availability[];
    /**
     * The specific type of service that may be delivered or performed.
     *
     * Type of service that may be delivered or performed
     */
    type?: CodeableConcept[];
    /**
     * When the HealthcareService is representing a specific, schedulable service, the availableIn property can refer to a generic service.
     *
     * The service within which this service is offered
     */
    offeredIn?: HealthcareService[] | Reference[];
    /**
     * Collection of characteristics (attributes).
     *
     * Collection of characteristics (attributes)
     */
    characteristic?: CodeableConcept[];
    /**
     * The organization that provides this healthcare service.
     *
     * Organization that provides this service
     */
    providedBy?: Organization | Reference;
    /**
     * The code(s) that detail the conditions under which the healthcare service is available/offered.
     *
     * Conditions under which service is available/offered
     */
    serviceProvisionCode?: CodeableConcept[];
    /**
     * External identifiers for this item.
     *
     * External identifiers for this item
     */
    identifier?: Identifier[];
    /**
     * Collection of specialties handled by the Healthcare service. This is more of a medical term.
     *
     * Specialties handled by the HealthcareService
     */
    specialty?: CodeableConcept[];
    /**
     * Further description of the service as it would be presented to a consumer while searching.
     *
     * Description of service as presented to a consumer while searching
     */
    name?: string;
    /**
     * The location(s) where this healthcare service may be provided.
     *
     * Location(s) where service may be provided
     */
    location?: Location[] | Reference[];
    /**
     * Any additional description of the service and/or any specific issues not covered by the other attributes, which can be displayed as further detail under the serviceName.
     *
     * Additional description and/or any specific issues not covered elsewhere
     */
    comment?: string;
    /**
     * Identifies the broad category of service being performed or delivered.
     *
     * Broad category of service being performed or delivered
     */
    category?: CodeableConcept[];
    /**
     * Extra details about the service that can't be placed in the other fields.
     *
     * Extra details about the service that can't be placed in the other fields
     */
    extraDetails?: string;
    /**
     * Some services are specifically made available in multiple languages, this property permits a directory to declare the languages this is offered in. Typically this is only provided where a service operates in communities with mixed languages used.
     *
     * The language that this service is offered in
     */
    communication?: CodeableConcept[];
    /**
     * Ways that the service accepts referrals, if this is not provided then it is implied that no referral is required.
     *
     * Ways that the service accepts referrals
     */
    referralMethod?: CodeableConcept[];
    /**
     * The location(s) that this service is available to (not where the service is provided).
     *
     * Location(s) service is intended for/available to
     */
    coverageArea?: Location[] | Reference[];
    /**
     * Technical endpoints providing access to services operated for the specific healthcare services defined at this resource.
     *
     * Technical endpoints providing access to electronic services operated for the healthcare service
     */
    endpoint?: Endpoint[] | Reference[];
    /**
     * The contact details of communication devices available relevant to the specific HealthcareService. This can include addresses, phone numbers, fax numbers, mobile numbers, email addresses and web sites.
     *
     * Official contact details for the HealthcareService
     */
    contact?: ExtendedContactDetail[];
    readonly resourceType: string;
    static revive(json: any): HealthcareService;
    toJSON(): any;
}
export declare namespace HealthcareService {
    class HealthcareServiceEligibilityComponent extends BackboneElement {
        /**
         * Coded value for the eligibility.
         *
         * Coded value for the eligibility
         */
        code?: CodeableConcept;
        /**
         * Describes the eligibility conditions for the service.
         *
         * Describes the eligibility conditions for the service
         */
        comment?: string;
        static revive(json: any): HealthcareServiceEligibilityComponent;
        toJSON(): any;
    }
}
