import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { UsageContext } from '../datatype/usage-context';
import { CanonicalResource } from '../model/canonical-resource';
/**
 * HAPI/FHIR <b>MessageDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/MessageDefinition">http://hl7.org/fhir/StructureDefinition/MessageDefinition</a>
 * </p>
 *
 */
export declare class MessageDefinition extends CanonicalResource {
    /**
     * A short, descriptive, user-friendly title for the message definition.
     *
     * Name for this message definition (human friendly)
     */
    title?: string;
    /**
     * A Boolean value to indicate that this message definition is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A free text natural language description of the message definition from a consumer's perspective.
     *
     * Natural language description of the message definition
     */
    description?: string;
    /**
     * Identifies the resource (or resources) that are being addressed by the event.  For example, the Encounter for an admit message or two Account records for a merge.
     *
     * Resource(s) that are the subject of the event
     */
    focus?: MessageDefinition.MessageDefinitionFocusComponent[];
    /**
     * A legal or geographic region in which the message definition is intended to be used.
     *
     * Intended jurisdiction for message definition (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * Explanation of why this message definition is needed and why it has been designed as it has.
     *
     * Why this message definition is defined
     */
    purpose?: string;
    /**
     * A copyright statement relating to the message definition and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the message definition.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * The date  (and optionally time) when the message definition was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the message definition changes.
     *
     * Date last changed
     */
    date: Date;
    /**
     * Identifies a protocol or workflow that this MessageDefinition represents a step in.
     *
     * Protocol/workflow this is part of
     */
    parent?: string[];
    /**
     * Indicates what types of messages may be sent as an application-level response to this message.
     *
     * Responses to this message
     */
    allowedResponse?: MessageDefinition.MessageDefinitionAllowedResponseComponent[];
    /**
     * Event code or link to the EventDefinition.
     *
     * Event code  or link to the EventDefinition
     */
    event: Coding | string;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * The business identifier that is used to reference the MessageDefinition and *is* expected to be consistent from server to server.
     *
     * The cannonical URL for a given MessageDefinition
     */
    url?: string;
    /**
     * Declare at a message definition level whether a response is required or only upon error or success, or never.
     *
     * always | on-error | never | on-success
     */
    responseRequired?: string;
    /**
     * Graph is Canonical reference to a GraphDefinition. If a URL is provided, it is the canonical reference to a GraphDefinition that it controls what additional resources are to be added to the Bundle when building the message. The GraphDefinition can also specify profiles that apply to the various resources.
     *
     * Canonical reference to a GraphDefinition
     */
    graph?: string;
    /**
     * The identifier that is used to identify this version of the message definition when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the message definition author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the message definition
     */
    version?: string;
    /**
     * A MessageDefinition that is superseded by this definition.
     *
     * Takes the place of
     */
    replaces?: string[];
    /**
     * A formal identifier that is used to identify this message definition when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Business Identifier for a given MessageDefinition
     */
    identifier?: Identifier[];
    /**
     * The status of this message definition. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The MessageDefinition that is the basis for the contents of this resource.
     *
     * Definition this one is based on
     */
    base?: string;
    /**
     * The impact of the content of the message.
     *
     * consequence | currency | notification
     */
    category?: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate message definition instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * A natural language name identifying the message definition. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this message definition (computer friendly)
     */
    name?: string;
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the message definition.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    readonly resourceType: string;
    static revive(json: any): MessageDefinition;
    toJSON(): any;
}
export declare namespace MessageDefinition {
    enum MessageheaderResponseRequest {
        ONERROR,
        NULL,
        NEVER,
        ALWAYS,
        ONSUCCESS
    }
    enum MessageSignificanceCategory {
        CURRENCY,
        NOTIFICATION,
        NULL,
        CONSEQUENCE
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class MessageDefinitionAllowedResponseComponent extends BackboneElement {
        /**
         * A reference to the message definition that must be adhered to by this supported response.
         *
         * Reference to allowed message definition response
         */
        message: string;
        /**
         * Provides a description of the circumstances in which this response should be used (as opposed to one of the alternative responses).
         *
         * When should this response be used
         */
        situation?: string;
        static revive(json: any): MessageDefinitionAllowedResponseComponent;
        toJSON(): any;
    }
    class MessageDefinitionFocusComponent extends BackboneElement {
        /**
         * Identifies the maximum number of resources of this type that must be pointed to by a message in order for it to be valid against this MessageDefinition.
         *
         * Maximum number of focuses of this type
         */
        max?: string;
        /**
         * A profile that reflects constraints for the focal resource (and potentially for related resources).
         *
         * Profile that must be adhered to by focus
         */
        profile?: string;
        /**
         * The kind of resource that must be the focus for this message.
         *
         * Type of resource
         */
        code: string;
        /**
         * Identifies the minimum number of resources of this type that must be pointed to by a message in order for it to be valid against this MessageDefinition.
         *
         * Minimum number of focuses of this type
         */
        min: number;
        static revive(json: any): MessageDefinitionFocusComponent;
        toJSON(): any;
    }
}
