import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Appointment } from '../model/appointment';
import { CareTeam } from '../model/care-team';
import { CommunicationRequest } from '../model/communication-request';
import { Device } from '../model/device';
import { DeviceRequest } from '../model/device-request';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Goal } from '../model/goal';
import { Group } from '../model/group';
import { ImmunizationRecommendation } from '../model/immunization-recommendation';
import { MedicationRequest } from '../model/medication-request';
import { NutritionOrder } from '../model/nutrition-order';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
import { RequestOrchestration } from '../model/request-orchestration';
import { ServiceRequest } from '../model/service-request';
import { SupplyRequest } from '../model/supply-request';
import { Task } from '../model/task';
import { VisionPrescription } from '../model/vision-prescription';
/**
 * HAPI/FHIR <b>CarePlan</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/CarePlan">http://hl7.org/fhir/StructureDefinition/CarePlan</a>
 * </p>
 *
 */
export declare class CarePlan extends DomainResource {
    /**
     * Identifies the individual(s), organization or device who provided the contents of the care plan.
     *
     * Who provided the content of the care plan
     */
    contributor?: Patient[] | Practitioner[] | PractitionerRole[] | Device[] | RelatedPerson[] | Organization[] | CareTeam[] | Reference[];
    /**
     * Identifies portions of the patient's record that specifically influenced the formation of the plan.  These might include comorbidities, recent procedures, limitations, recent assessments, etc.
     *
     * Information considered as part of plan
     */
    supportingInfo?: Reference[];
    /**
     * Identifies what "kind" of plan this is to support differentiation between multiple co-existing plans; e.g. "Home health", "psychiatric", "asthma", "disease management", "wellness plan", etc.
     *
     * Type of plan
     */
    category?: CodeableConcept[];
    /**
     * Indicates whether the plan is currently being acted upon, represents future intentions or is now a historical record.
     *
     * draft | active | on-hold | revoked | completed | entered-in-error | unknown
     */
    status: string;
    /**
     * A higher-level request resource (i.e. a plan, proposal or order) that is fulfilled in whole or in part by this care plan.
     *
     * Fulfills plan, proposal or order
     */
    basedOn?: CarePlan[] | ServiceRequest[] | RequestOrchestration[] | NutritionOrder[] | Reference[];
    /**
     * Identifies all people and organizations who are expected to be involved in the care envisioned by this plan.
     *
     * Who's involved in plan?
     */
    careTeam?: CareTeam[] | Reference[];
    /**
     * Business identifiers assigned to this care plan by the performer or other systems which remain constant as the resource is updated and propagates from server to server.
     *
     * External Ids for this plan
     */
    identifier?: Identifier[];
    /**
     * A larger care plan of which this particular care plan is a component or step.
     *
     * Part of referenced CarePlan
     */
    partOf?: CarePlan[] | Reference[];
    /**
     * General notes about the care plan not covered elsewhere.
     *
     * Comments about the plan
     */
    note?: Annotation[];
    /**
     * Describes the intended objective(s) of carrying out the care plan.
     *
     * Desired outcome of plan
     */
    goal?: Goal[] | Reference[];
    /**
     * Indicates when the plan did (or is intended to) come into effect and end.
     *
     * Time period plan covers
     */
    period?: Period;
    /**
     * Identifies the conditions/problems/concerns/diagnoses/etc. whose management and/or mitigation are handled by this plan.
     *
     * Health issues this plan addresses
     */
    addresses?: CodeableReference[];
    /**
     * When populated, the custodian is responsible for the care plan. The care plan is attributed to the custodian.
     *
     * Who is the designated responsible party
     */
    custodian?: Patient | Practitioner | PractitionerRole | Device | RelatedPerson | Organization | CareTeam | Reference;
    /**
     * Identifies an action that has occurred or is a planned action to occur as part of the plan. For example, a medication to be used, lab tests to perform, self-monitoring that has occurred, education etc.
     *
     * Action to occur or has occurred as part of plan
     */
    activity?: CarePlan.CarePlanActivityComponent[];
    /**
     * Completed or terminated care plan whose function is taken by this new care plan.
     *
     * CarePlan replaced by this CarePlan
     */
    replaces?: CarePlan[] | Reference[];
    /**
     * Identifies the patient or group whose intended care is described by the plan.
     *
     * Who the care plan is for
     */
    subject: Patient | Group | Reference;
    /**
     * Represents when this particular CarePlan record was created in the system, which is often a system-generated date.
     *
     * Date record was first recorded
     */
    created?: Date;
    /**
     * A description of the scope and nature of the plan.
     *
     * Summary of nature of plan
     */
    description?: string;
    /**
     * The Encounter during which this CarePlan was created or to which the creation of this record is tightly associated.
     *
     * The Encounter during which this CarePlan was created
     */
    encounter?: Encounter | Reference;
    /**
     * Indicates the level of authority/intentionality associated with the care plan and where the care plan fits into the workflow chain.
     *
     * proposal | plan | order | option | directive
     */
    intent: string;
    /**
     * The URL pointing to a FHIR-defined protocol, guideline, questionnaire or other definition that is adhered to in whole or in part by this CarePlan.
     *
     * Instantiates FHIR protocol or definition
     */
    instantiatesCanonical?: string[];
    /**
     * Human-friendly name for the care plan.
     *
     * Human-friendly name for the care plan
     */
    title?: string;
    /**
     * The URL pointing to an externally maintained protocol, guideline, questionnaire or other definition that is adhered to in whole or in part by this CarePlan.
     *
     * Instantiates external protocol or definition
     */
    instantiatesUri?: string[];
    readonly resourceType: string;
    static revive(json: any): CarePlan;
    toJSON(): any;
}
export declare namespace CarePlan {
    enum CarePlanIntent {
        ORDER,
        NULL,
        DIRECTIVE,
        OPTION,
        PROPOSAL,
        PLAN
    }
    enum RequestStatus {
        REVOKED,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ACTIVE,
        DRAFT,
        ONHOLD,
        UNKNOWN
    }
    class CarePlanActivityComponent extends BackboneElement {
        /**
         * The details of the proposed activity represented in a specific resource.
         *
         * Activity that is intended to be part of the care plan
         */
        plannedActivityReference?: Appointment | CommunicationRequest | DeviceRequest | MedicationRequest | NutritionOrder | Task | ServiceRequest | VisionPrescription | RequestOrchestration | ImmunizationRecommendation | SupplyRequest | Reference;
        /**
         * Notes about the adherence/status/progress of the activity.
         *
         * Comments about the activity status/progress
         */
        progress?: Annotation[];
        /**
         * Identifies the activity that was performed. For example, an activity could be patient education, exercise, or a medication administration. The reference to an "event" resource, such as Procedure or Encounter or Observation, represents the activity that was performed. The requested activity can be conveyed using the CarePlan.activity.plannedActivityReference (a reference to a “request” resource).
         *
         * Results of the activity (concept, or Appointment, Encounter, Procedure, etc.)
         */
        performedActivity?: CodeableReference[];
        static revive(json: any): CarePlanActivityComponent;
        toJSON(): any;
    }
}
