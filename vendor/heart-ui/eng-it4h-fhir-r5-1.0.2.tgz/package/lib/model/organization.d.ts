import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { ExtendedContactDetail } from '../datatype/extended-contact-detail';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { DomainResource } from '../model/domain-resource';
import { Endpoint } from '../model/endpoint';
/**
 * HAPI/FHIR <b>Organization</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Organization">http://hl7.org/fhir/StructureDefinition/Organization</a>
 * </p>
 *
 */
export declare class Organization extends DomainResource {
    /**
     * The kind(s) of organization that this is.
     *
     * Kind of organization
     */
    type?: CodeableConcept[];
    /**
     * A name associated with the organization.
     *
     * Name used for the organization
     */
    name?: string;
    /**
     * Whether the organization's record is still in active use.
     *
     * Whether the organization's record is still in active use
     */
    active?: boolean;
    /**
     * A list of alternate names that the organization is known as, or was known as in the past.
     *
     * A list of alternate names that the organization is known as, or was known as in the past
     */
    alias?: string[];
    /**
     * Description of the organization, which helps provide additional general context on the organization to ensure that the correct organization is selected.
     *
     * Additional details about the Organization that could be displayed as further information to identify the Organization beyond its name
     */
    description?: string;
    /**
     * The contact details of communication devices available relevant to the specific Organization. This can include addresses, phone numbers, fax numbers, mobile numbers, email addresses and web sites.
     *
     * Official contact details for the Organization
     */
    contact?: ExtendedContactDetail[];
    /**
     * Identifier for the organization that is used to identify the organization across multiple disparate systems.
     *
     * Identifies this organization  across multiple systems
     */
    identifier?: Identifier[];
    /**
     * The organization of which this organization forms a part.
     *
     * The organization of which this organization forms a part
     */
    partOf?: Organization | Reference;
    /**
     * The official certifications, accreditations, training, designations and licenses that authorize and/or otherwise endorse the provision of care by the organization.

For example, an approval to provide a type of services issued by a certifying body (such as the US Joint Commission) to an organization.
     *
     * Qualifications, certifications, accreditations, licenses, training, etc. pertaining to the provision of care
     */
    qualification?: Organization.OrganizationQualificationComponent[];
    /**
     * Technical endpoints providing access to services operated for the organization.
     *
     * Technical endpoints providing access to services operated for the organization
     */
    endpoint?: Endpoint[] | Reference[];
    readonly resourceType: string;
    static revive(json: any): Organization;
    toJSON(): any;
}
export declare namespace Organization {
    class OrganizationQualificationComponent extends BackboneElement {
        /**
         * Coded representation of the qualification.
         *
         * Coded representation of the qualification
         */
        code: CodeableConcept;
        /**
         * Period during which the qualification is valid.
         *
         * Period during which the qualification is valid
         */
        period?: Period;
        /**
         * An identifier allocated to this qualification for this organization.
         *
         * An identifier for this qualification for the organization
         */
        identifier?: Identifier[];
        /**
         * Organization that regulates and issues the qualification.
         *
         * Organization that regulates and issues the qualification
         */
        issuer?: Organization | Reference;
        static revive(json: any): OrganizationQualificationComponent;
        toJSON(): any;
    }
}
