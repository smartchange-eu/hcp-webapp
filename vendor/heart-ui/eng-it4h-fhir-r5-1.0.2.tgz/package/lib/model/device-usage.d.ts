import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Timing } from '../datatype/timing';
import { Claim } from '../model/claim';
import { DocumentReference } from '../model/document-reference';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { EpisodeOfCare } from '../model/episode-of-care';
import { Observation } from '../model/observation';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Procedure } from '../model/procedure';
import { QuestionnaireResponse } from '../model/questionnaire-response';
import { RelatedPerson } from '../model/related-person';
import { ServiceRequest } from '../model/service-request';
/**
 * HAPI/FHIR <b>DeviceUsage</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/DeviceUsage">http://hl7.org/fhir/StructureDefinition/DeviceUsage</a>
 * </p>
 *
 */
export declare class DeviceUsage extends DomainResource {
    /**
     * Allows linking the DeviceUsage to the underlying Request, or to other information that supports or is used to derive the DeviceUsage.
     *
     * Supporting information
     */
    derivedFrom?: ServiceRequest[] | Procedure[] | Claim[] | Observation[] | QuestionnaireResponse[] | DocumentReference[] | Reference[];
    /**
     * The encounter or episode of care that establishes the context for this device use statement.
     *
     * The encounter or episode of care that establishes the context for this device use statement
     */
    context?: Encounter | EpisodeOfCare | Reference;
    /**
     * A code representing the patient or other source's judgment about the state of the device used that this statement is about.  Generally this will be active or completed.
     *
     * active | completed | not-done | entered-in-error +
     */
    status: string;
    /**
     * A plan, proposal or order that is fulfilled in whole or in part by this DeviceUsage.
     *
     * Fulfills plan, proposal or order
     */
    basedOn?: ServiceRequest[] | Reference[];
    /**
     * The time at which the statement was recorded by informationSource.
     *
     * When the statement was made (and recorded)
     */
    dateAsserted?: Date;
    /**
     * Code or Reference to device used.
     *
     * Code or Reference to device used
     */
    device: CodeableReference;
    /**
     * This attribute indicates a category for the statement - The device statement may be made in an inpatient or outpatient settting (inpatient | outpatient | community | patientspecified).
     *
     * The category of the statement - classifying how the statement is made
     */
    category?: CodeableConcept[];
    /**
     * Indicates the anotomic location on the subject's body where the device was used ( i.e. the target).
     *
     * Target body site
     */
    bodySite?: CodeableReference;
    /**
     * The patient who used the device.
     *
     * Patient using device
     */
    patient: Patient | Reference;
    /**
     * Who reported the device was being used by the patient.
     *
     * Who made the statement
     */
    informationSource?: Patient | Practitioner | PractitionerRole | RelatedPerson | Organization | Reference;
    /**
     * The reason for asserting the usage status - for example forgot, lost, stolen, broken.
     *
     * The reason for asserting the usage status - for example forgot, lost, stolen, broken
     */
    usageReason?: CodeableConcept[];
    /**
     * An external identifier for this statement such as an IRI.
     *
     * External identifier for this record
     */
    identifier?: Identifier[];
    /**
     * The status of the device usage, for example always, sometimes, never. This is not the same as the status of the statement.
     *
     * The status of the device usage, for example always, sometimes, never. This is not the same as the status of the statement
     */
    usageStatus?: CodeableConcept;
    /**
     * Reason or justification for the use of the device. A coded concept, or another resource whose existence justifies this DeviceUsage.
     *
     * Why device was used
     */
    reason?: CodeableReference[];
    /**
     * Details about the device statement that were not represented at all or sufficiently in one of the attributes provided in a class. These may include for example a comment, an instruction, or a note associated with the statement.
     *
     * Addition details (comments, instructions)
     */
    note?: Annotation[];
    /**
     * How often the device was used.
     *
     * How often  the device was used
     */
    timing?: Timing | Period | Date;
    /**
     * This indicates how or if the device is being used.
     *
     * How device is being used
     */
    adherence?: DeviceUsage.DeviceUsageAdherenceComponent;
    readonly resourceType: string;
    static revive(json: any): DeviceUsage;
    toJSON(): any;
}
export declare namespace DeviceUsage {
    enum DeviceUsageStatus {
        NOTDONE,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ACTIVE,
        ONHOLD,
        STOPPED,
        INTENDED
    }
    class DeviceUsageAdherenceComponent extends BackboneElement {
        /**
         * Type of adherence.
         *
         * always | never | sometimes
         */
        code: CodeableConcept;
        /**
         * Reason for adherence type.
         *
         * lost | stolen | prescribed | broken | burned | forgot
         */
        reason: CodeableConcept[];
        static revive(json: any): DeviceUsageAdherenceComponent;
        toJSON(): any;
    }
}
