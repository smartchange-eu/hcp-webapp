import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { HealthcareService } from '../model/healthcare-service';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
import { Specimen } from '../model/specimen';
/**
 * HAPI/FHIR <b>Group</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Group">http://hl7.org/fhir/StructureDefinition/Group</a>
 * </p>
 *
 */
export declare class Group extends DomainResource {
    /**
     * Identifies traits whose presence r absence is shared by members of the group.
     *
     * Include / Exclude group members by Trait
     */
    characteristic?: Group.GroupCharacteristicComponent[];
    /**
     * Identifies the broad classification of the kind of resources the group includes.
     *
     * person | animal | practitioner | device | careteam | healthcareservice | location | organization | relatedperson | specimen
     */
    type: string;
    /**
     * Basis for membership in the Group:

* 'definitional': The Group.characteristics specified are both necessary and sufficient to determine membership. All entities that meet the criteria are considered to be members of the group, whether referenced by the group or not. If members are present, they are individuals that happen to be known as meeting the Group.characteristics. The list cannot be presumed to be complete.
* 'enumerated': The Group.characteristics are necessary but not sufficient to determine membership. Membership is determined by being listed as one of the Group.member.
     *
     * definitional | enumerated
     */
    membership: string;
    /**
     * Indicates whether the record for the group is available for use or is merely being retained for historical purposes.
     *
     * Whether this group's record is in active use
     */
    active?: boolean;
    /**
     * Explanation of what the group represents and how it is intended to be used.
     *
     * Natural language description of the group
     */
    description?: string;
    /**
     * A label assigned to the group for human identification and communication.
     *
     * Label for Group
     */
    name?: string;
    /**
     * Identifies the resource instances that are members of the group.
     *
     * Who or what is in group
     */
    member?: Group.GroupMemberComponent[];
    /**
     * Provides a specific type of resource the group includes; e.g. "cow", "syringe", etc.
     *
     * Kind of Group members
     */
    code?: CodeableConcept;
    /**
     * A count of the number of resource instances that are part of the group.
     *
     * Number of members
     */
    quantity?: number;
    /**
     * Business identifiers assigned to this participant by one of the applications involved.  These identifiers remain constant as the resource is updated and propagates from server to server.
     *
     * Business Identifier for this Group
     */
    identifier?: Identifier[];
    /**
     * Entity responsible for defining and maintaining Group characteristics and/or registered members.
     *
     * Entity that is the custodian of the Group's definition
     */
    managingEntity?: Organization | RelatedPerson | Practitioner | PractitionerRole | Reference;
    readonly resourceType: string;
    static revive(json: any): Group;
    toJSON(): any;
}
export declare namespace Group {
    enum GroupType {
        LOCATION,
        ORGANIZATION,
        PERSON,
        NULL,
        ANIMAL,
        PRACTITIONER,
        DEVICE,
        RELATEDPERSON,
        CARETEAM,
        SPECIMEN,
        HEALTHCARESERVICE
    }
    enum GroupMembershipBasis {
        NULL,
        ENUMERATED,
        DEFINITIONAL
    }
    class GroupMemberComponent extends BackboneElement {
        /**
         * The period that the member was in the group, if known.
         *
         * Period member belonged to the group
         */
        period?: Period;
        /**
         * A flag to indicate that the member is no longer in the group, but previously may have been a member.
         *
         * If member is no longer in group
         */
        inactive?: boolean;
        /**
         * A reference to the entity that is a member of the group. Must be consistent with Group.type. If the entity is another group, then the type must be the same.
         *
         * Reference to the group member
         */
        entity: CareTeam | Device | Group | HealthcareService | Location | Organization | Patient | Practitioner | PractitionerRole | RelatedPerson | Specimen | Reference;
        static revive(json: any): GroupMemberComponent;
        toJSON(): any;
    }
    class GroupCharacteristicComponent extends BackboneElement {
        /**
         * The value of the trait that holds (or does not hold - see 'exclude') for members of the group.
         *
         * Value held by characteristic
         */
        value: CodeableConcept | boolean | Quantity | Range | Reference;
        /**
         * If true, indicates the characteristic is one that is NOT held by members of the group.
         *
         * Group includes or excludes
         */
        exclude: boolean;
        /**
         * A code that identifies the kind of trait being asserted.
         *
         * Kind of characteristic
         */
        code: CodeableConcept;
        /**
         * The period over which the characteristic is tested; e.g. the patient had an operation during the month of June.
         *
         * Period over which characteristic is tested
         */
        period?: Period;
        static revive(json: any): GroupCharacteristicComponent;
        toJSON(): any;
    }
}
