import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Duration } from '../datatype/duration';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { UsageContext } from '../datatype/usage-context';
import { DomainResource } from '../model/domain-resource';
import { Group } from '../model/group';
import { SubstanceDefinition } from '../model/substance-definition';
/**
 * HAPI/FHIR <b>SpecimenDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/SpecimenDefinition">http://hl7.org/fhir/StructureDefinition/SpecimenDefinition</a>
 * </p>
 *
 */
export declare class SpecimenDefinition extends DomainResource {
    /**
     * A code or group definition that describes the intended subject  from which this kind of specimen is to be collected.
     *
     * Type of subject for specimen collection
     */
    subject?: CodeableConcept | Group | Reference;
    /**
     * A jurisdiction in which the SpecimenDefinition is intended to be used.
     *
     * Intended jurisdiction for this SpecimenDefinition (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * Preparation of the patient for specimen collection.
     *
     * Patient preparation for collection
     */
    patientPreparation?: CodeableConcept[];
    /**
     * Time aspect of specimen collection (duration or offset).
     *
     * Time aspect for collection
     */
    timeAspect?: string;
    /**
     * Explains why this SpecimeDefinition is needed and why it has been designed as it has.
     *
     * Why this SpecimenDefinition is defined
     */
    purpose?: string;
    /**
     * Copyright statement relating to the SpecimenDefinition and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the SpecimenDefinition.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * The date on which the asset content was approved by the publisher. Approval happens once when the content is officially approved for usage.
     *
     * When SpecimenDefinition was approved by publisher
     */
    approvalDate?: Date;
    /**
     * For draft definitions, indicates the date of initial creation. For active definitions, represents the date of activation. For withdrawn definitions, indicates the date of withdrawal.
     *
     * Date status first applied
     */
    date?: Date;
    /**
     * A short, descriptive, user-friendly title for the SpecimenDefinition.
     *
     * Name for this SpecimenDefinition (Human friendly)
     */
    title?: string;
    /**
     * A flag to indicate that this SpecimenDefinition is not authored for  genuine usage.
     *
     * If this SpecimenDefinition is not for real usage
     */
    experimental?: boolean;
    /**
     * A free text natural language description of the SpecimenDefinition from the consumer's perspective.
     *
     * Natural language description of the SpecimenDefinition
     */
    description?: string;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * Specimen conditioned in a container as expected by the testing laboratory.
     *
     * Specimen in container intended for testing by lab
     */
    typeTested?: SpecimenDefinition.SpecimenDefinitionTypeTestedComponent[];
    /**
     * The URL pointing to an externally-defined type of specimen, guideline or other definition that is adhered to in whole or in part by this definition.
     *
     * Based on external definition
     */
    derivedFromUri?: string[];
    /**
     * The period during which the SpecimenDefinition content was or is planned to be effective.
     *
     * The effective date range for the SpecimenDefinition
     */
    effectivePeriod?: Period;
    /**
     * A business identifier assigned to this SpecimenDefinition.
     *
     * Business identifier
     */
    identifier?: Identifier;
    /**
     * An absolute URL that is used to identify this SpecimenDefinition when it is referenced in a specification, model, design or an instance. This SHALL be a URL, SHOULD be globally unique, and SHOULD be an address at which this SpecimenDefinition is (or will be) published. The URL SHOULD include the major version of the SpecimenDefinition. For more information see Technical and Business Versions.
     *
     * Logical canonical URL to reference this SpecimenDefinition (globally unique)
     */
    url?: string;
    /**
     * The identifier that is used to identify this version of the SpecimenDefinition when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the SpecimenDefinition author and is not expected to be globally unique.
     *
     * Business version of the SpecimenDefinition
     */
    version?: string;
    /**
     * The action to be performed for collecting the specimen.
     *
     * Specimen collection procedure
     */
    collection?: CodeableConcept[];
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * The date on which the asset content was last reviewed. Review happens periodically after that, but doesn't change the original approval date.
     *
     * The date on which the asset content was last reviewed by the publisher
     */
    lastReviewDate?: Date;
    /**
     * The canonical URL pointing to another FHIR-defined SpecimenDefinition that is adhered to in whole or in part by this definition.
     *
     * Based on FHIR definition of another SpecimenDefinition
     */
    derivedFromCanonical?: string[];
    /**
     * The current state of theSpecimenDefinition.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The kind of material to be collected.
     *
     * Kind of material to collect
     */
    typeCollected?: CodeableConcept;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These terms may be used to assist with indexing and searching of specimen definitions.
     *
     * Content intends to support these contexts
     */
    useContext?: UsageContext[];
    /**
     * A natural language name identifying the specimen definition. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this specimen definition (computer friendly)
     */
    name?: string;
    /**
     * Helps establish the "authority/credibility" of the SpecimenDefinition. May also allow for contact.
     *
     * The name of the individual or organization that published the SpecimenDefinition
     */
    publisher?: string;
    readonly resourceType: string;
    static revive(json: any): SpecimenDefinition;
    toJSON(): any;
}
export declare namespace SpecimenDefinition {
    enum SpecimenContainedPreference {
        ALTERNATE,
        NULL,
        PREFERRED
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class SpecimenDefinitionTypeTestedHandlingComponent extends BackboneElement {
        /**
         * The temperature interval for this set of handling instructions.
         *
         * Temperature range for these handling instructions
         */
        temperatureRange?: Range;
        /**
         * Additional textual instructions for the preservation or transport of the specimen. For instance, 'Protect from light exposure'.
         *
         * Preservation instruction
         */
        instruction?: string;
        /**
         * It qualifies the interval of temperature, which characterizes an occurrence of handling. Conditions that are not related to temperature may be handled in the instruction element.
         *
         * Qualifies the interval of temperature
         */
        temperatureQualifier?: CodeableConcept;
        /**
         * The maximum time interval of preservation of the specimen with these conditions.
         *
         * Maximum preservation time
         */
        maxDuration?: Duration;
        static revive(json: any): SpecimenDefinitionTypeTestedHandlingComponent;
        toJSON(): any;
    }
    class SpecimenDefinitionTypeTestedContainerAdditiveComponent extends BackboneElement {
        /**
         * Substance introduced in the kind of container to preserve, maintain or enhance the specimen. Examples: Formalin, Citrate, EDTA.
         *
         * Additive associated with container
         */
        additive: CodeableConcept | SubstanceDefinition | Reference;
        static revive(json: any): SpecimenDefinitionTypeTestedContainerAdditiveComponent;
        toJSON(): any;
    }
    class SpecimenDefinitionTypeTestedContainerComponent extends BackboneElement {
        /**
         * The textual description of the kind of container.
         *
         * The description of the kind of container
         */
        description?: string;
        /**
         * The capacity (volume or other measure) of this kind of container.
         *
         * The capacity of this kind of container
         */
        capacity?: Quantity;
        /**
         * Substance introduced in the kind of container to preserve, maintain or enhance the specimen. Examples: Formalin, Citrate, EDTA.
         *
         * Additive associated with container
         */
        additive?: SpecimenDefinition.SpecimenDefinitionTypeTestedContainerAdditiveComponent[];
        /**
         * Special processing that should be applied to the container for this kind of specimen.
         *
         * Special processing applied to the container for this specimen type
         */
        preparation?: string;
        /**
         * The type of container used to contain this kind of specimen.
         *
         * Kind of container associated with the kind of specimen
         */
        type?: CodeableConcept;
        /**
         * Color of container cap.
         *
         * Color of container cap
         */
        cap?: CodeableConcept;
        /**
         * The minimum volume to be conditioned in the container.
         *
         * Minimum volume
         */
        minimumVolume?: Quantity | string;
        /**
         * The type of material of the container.
         *
         * The material type used for the container
         */
        material?: CodeableConcept;
        static revive(json: any): SpecimenDefinitionTypeTestedContainerComponent;
        toJSON(): any;
    }
    class SpecimenDefinitionTypeTestedComponent extends BackboneElement {
        /**
         * Specimen can be used by only one test or panel if the value is "true".
         *
         * Specimen for single use only
         */
        singleUse?: boolean;
        /**
         * The preference for this type of conditioned specimen.
         *
         * preferred | alternate
         */
        preference: string;
        /**
         * Criterion for rejection of the specimen in its container by the laboratory.
         *
         * Criterion specified for specimen rejection
         */
        rejectionCriterion?: CodeableConcept[];
        /**
         * The specimen's container.
         *
         * The specimen's container
         */
        container?: SpecimenDefinition.SpecimenDefinitionTypeTestedContainerComponent;
        /**
         * Where the specimen will be tested: e.g., lab, sector, device or any combination of these.
         *
         * Where the specimen will be tested
         */
        testingDestination?: CodeableConcept[];
        /**
         * Primary of secondary specimen.
         *
         * Primary or secondary specimen
         */
        isDerived?: boolean;
        /**
         * The kind of specimen conditioned for testing expected by lab.
         *
         * Type of intended specimen
         */
        type?: CodeableConcept;
        /**
         * The usual time that a specimen of this kind is retained after the ordered tests are completed, for the purpose of additional testing.
         *
         * The usual time for retaining this kind of specimen
         */
        retentionTime?: Duration;
        /**
         * Set of instructions for preservation/transport of the specimen at a defined temperature interval, prior the testing process.
         *
         * Specimen handling before testing
         */
        handling?: SpecimenDefinition.SpecimenDefinitionTypeTestedHandlingComponent[];
        /**
         * Requirements for delivery and special handling of this kind of conditioned specimen.
         *
         * Requirements for specimen delivery and special handling
         */
        requirement?: string;
        static revive(json: any): SpecimenDefinitionTypeTestedComponent;
        toJSON(): any;
    }
}
