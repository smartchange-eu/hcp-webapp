import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Money } from '../datatype/money';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Condition } from '../model/condition';
import { Coverage } from '../model/coverage';
import { DomainResource } from '../model/domain-resource';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
/**
 * HAPI/FHIR <b>CoverageEligibilityRequest</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/CoverageEligibilityRequest">http://hl7.org/fhir/StructureDefinition/CoverageEligibilityRequest</a>
 * </p>
 *
 */
export declare class CoverageEligibilityRequest extends DomainResource {
    /**
     * Information code for an event with a corresponding date or period.
     *
     * Event information
     */
    event?: CoverageEligibilityRequest.CoverageEligibilityRequestEventComponent[];
    /**
     * Facility where the services are intended to be provided.
     *
     * Servicing facility
     */
    facility?: Location | Reference;
    /**
     * The status of the resource instance.
     *
     * active | cancelled | draft | entered-in-error
     */
    status: string;
    /**
     * Person who created the request.
     *
     * Author
     */
    enterer?: Practitioner | PractitionerRole | Reference;
    /**
     * The date or dates when the enclosed suite of services were performed or completed.
     *
     * Estimated date or dates of service
     */
    serviced?: Date | Period;
    /**
     * Additional information codes regarding exceptions, special considerations, the condition, situation, prior or concurrent issues.
     *
     * Supporting information
     */
    supportingInfo?: CoverageEligibilityRequest.SupportingInformationComponent[];
    /**
     * The provider which is responsible for the request.
     *
     * Party responsible for the request
     */
    provider?: Practitioner | PractitionerRole | Organization | Reference;
    /**
     * The party who is the beneficiary of the supplied coverage and for whom eligibility is sought.
     *
     * Intended recipient of products and services
     */
    patient: Patient | Reference;
    /**
     * The Insurer who issued the coverage in question and is the recipient of the request.
     *
     * Coverage issuer
     */
    insurer: Organization | Reference;
    /**
     * When the requestor expects the processor to complete processing.
     *
     * Desired processing priority
     */
    priority?: CodeableConcept;
    /**
     * Code to specify whether requesting: prior authorization requirements for some service categories or billing codes; benefits for coverages specified or discovered; discovery and return of coverages for the patient; and/or validation that the specified coverage is in-force at the date/period specified or 'now' if not specified.
     *
     * auth-requirements | benefits | discovery | validation
     */
    purpose: string[];
    /**
     * The date when this resource was created.
     *
     * Creation date
     */
    created: Date;
    /**
     * Financial instruments for reimbursement for the health care products and services.
     *
     * Patient insurance information
     */
    insurance?: CoverageEligibilityRequest.InsuranceComponent[];
    /**
     * A unique identifier assigned to this coverage eligiblity request.
     *
     * Business Identifier for coverage eligiblity request
     */
    identifier?: Identifier[];
    /**
     * Service categories or billable services for which benefit details and/or an authorization prior to service delivery may be required by the payor.
     *
     * Item to be evaluated for eligibiity
     */
    item?: CoverageEligibilityRequest.DetailsComponent[];
    readonly resourceType: string;
    static revive(json: any): CoverageEligibilityRequest;
    toJSON(): any;
}
export declare namespace CoverageEligibilityRequest {
    enum EligibilityRequestPurpose {
        NULL,
        VALIDATION,
        AUTHREQUIREMENTS,
        BENEFITS,
        DISCOVERY
    }
    enum FinancialResourceStatusCodes {
        CANCELLED,
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        DRAFT
    }
    class DiagnosisComponent extends BackboneElement {
        /**
         * The nature of illness or problem in a coded form or as a reference to an external defined Condition.
         *
         * Nature of illness or problem
         */
        diagnosis?: CodeableConcept | Condition | Reference;
        static revive(json: any): DiagnosisComponent;
        toJSON(): any;
    }
    class DetailsComponent extends BackboneElement {
        /**
         * Code to identify the general type of benefits under which products and services are provided.
         *
         * Benefit classification
         */
        category?: CodeableConcept;
        /**
         * Facility where the services will be provided.
         *
         * Servicing facility
         */
        facility?: Location | Organization | Reference;
        /**
         * This contains the product, service, drug or other billing code for the item.
         *
         * Billing, service, product, or drug code
         */
        productOrService?: CodeableConcept;
        /**
         * The plan/proposal/order describing the proposed service in detail.
         *
         * Product or service details
         */
        detail?: Reference[];
        /**
         * Exceptions, special conditions and supporting information applicable for this service or product line.
         *
         * Applicable exception or supporting information
         */
        supportingInfoSequence?: number[];
        /**
         * Patient diagnosis for which care is sought.
         *
         * Applicable diagnosis
         */
        diagnosis?: CoverageEligibilityRequest.DiagnosisComponent[];
        /**
         * Item typification or modifiers codes to convey additional context for the product or service.
         *
         * Product or service billing modifiers
         */
        modifier?: CodeableConcept[];
        /**
         * The practitioner who is responsible for the product or service to be rendered to the patient.
         *
         * Perfoming practitioner
         */
        provider?: Practitioner | PractitionerRole | Reference;
        /**
         * The number of repetitions of a service or product.
         *
         * Count of products or services
         */
        quantity?: Quantity;
        /**
         * The amount charged to the patient by the provider for a single unit.
         *
         * Fee, charge or cost per item
         */
        unitPrice?: Money;
        static revive(json: any): DetailsComponent;
        toJSON(): any;
    }
    class InsuranceComponent extends BackboneElement {
        /**
         * Reference to the insurance card level information contained in the Coverage resource. The coverage issuing insurer will use these details to locate the patient's actual coverage within the insurer's information system.
         *
         * Insurance information
         */
        coverage: Coverage | Reference;
        /**
         * A flag to indicate that this Coverage is to be used for evaluation of this request when set to true.
         *
         * Applicable coverage
         */
        focal?: boolean;
        /**
         * A business agreement number established between the provider and the insurer for special business processing purposes.
         *
         * Additional provider contract number
         */
        businessArrangement?: string;
        static revive(json: any): InsuranceComponent;
        toJSON(): any;
    }
    class SupportingInformationComponent extends BackboneElement {
        /**
         * Additional data or information such as resources, documents, images etc. including references to the data or the actual inclusion of the data.
         *
         * Data to be provided
         */
        information: Reference;
        /**
         * The supporting materials are applicable for all detail items, product/servce categories and specific billing codes.
         *
         * Applies to all items
         */
        appliesToAll?: boolean;
        /**
         * A number to uniquely identify supporting information entries.
         *
         * Information instance identifier
         */
        sequence: number;
        static revive(json: any): SupportingInformationComponent;
        toJSON(): any;
    }
    class CoverageEligibilityRequestEventComponent extends BackboneElement {
        /**
         * A coded event such as when a service is expected or a card printed.
         *
         * Specific event
         */
        type: CodeableConcept;
        /**
         * A date or period in the past or future indicating when the event occurred or is expectd to occur.
         *
         * Occurance date or period
         */
        when: Date | Period;
        static revive(json: any): CoverageEligibilityRequestEventComponent;
        toJSON(): any;
    }
}
