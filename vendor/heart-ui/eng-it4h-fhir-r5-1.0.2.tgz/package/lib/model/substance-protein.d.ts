import { BackboneElement } from '../datatype/backbone-element';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { DomainResource } from '../model/domain-resource';
/**
 * HAPI/FHIR <b>SubstanceProtein</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/SubstanceProtein">http://hl7.org/fhir/StructureDefinition/SubstanceProtein</a>
 * </p>
 *
 */
export declare class SubstanceProtein extends DomainResource {
    /**
     * Number of linear sequences of amino acids linked through peptide bonds. The number of subunits constituting the SubstanceProtein shall be described. It is possible that the number of subunits can be variable.
     *
     * Number of linear sequences of amino acids linked through peptide bonds. The number of subunits constituting the SubstanceProtein shall be described. It is possible that the number of subunits can be variable
     */
    numberOfSubunits?: number;
    /**
     * The SubstanceProtein descriptive elements will only be used when a complete or partial amino acid sequence is available or derivable from a nucleic acid sequence.
     *
     * The SubstanceProtein descriptive elements will only be used when a complete or partial amino acid sequence is available or derivable from a nucleic acid sequence
     */
    sequenceType?: CodeableConcept;
    /**
     * The disulphide bond between two cysteine residues either on the same subunit or on two different subunits shall be described. The position of the disulfide bonds in the SubstanceProtein shall be listed in increasing order of subunit number and position within subunit followed by the abbreviation of the amino acids involved. The disulfide linkage positions shall actually contain the amino acid Cysteine at the respective positions.
     *
     * The disulphide bond between two cysteine residues either on the same subunit or on two different subunits shall be described. The position of the disulfide bonds in the SubstanceProtein shall be listed in increasing order of subunit number and position within subunit followed by the abbreviation of the amino acids involved. The disulfide linkage positions shall actually contain the amino acid Cysteine at the respective positions
     */
    disulfideLinkage?: string[];
    /**
     * This subclause refers to the description of each subunit constituting the SubstanceProtein. A subunit is a linear sequence of amino acids linked through peptide bonds. The Subunit information shall be provided when the finished SubstanceProtein is a complex of multiple sequences; subunits are not used to delineate domains within a single sequence. Subunits are listed in order of decreasing length; sequences of the same length will be ordered by decreasing molecular weight; subunits that have identical sequences will be repeated multiple times.
     *
     * This subclause refers to the description of each subunit constituting the SubstanceProtein. A subunit is a linear sequence of amino acids linked through peptide bonds. The Subunit information shall be provided when the finished SubstanceProtein is a complex of multiple sequences; subunits are not used to delineate domains within a single sequence. Subunits are listed in order of decreasing length; sequences of the same length will be ordered by decreasing molecular weight; subunits that have identical sequences will be repeated multiple times
     */
    subunit?: SubstanceProtein.SubstanceProteinSubunitComponent[];
    readonly resourceType: string;
    static revive(json: any): SubstanceProtein;
    toJSON(): any;
}
export declare namespace SubstanceProtein {
    class SubstanceProteinSubunitComponent extends BackboneElement {
        /**
         * Length of linear sequences of amino acids contained in the subunit.
         *
         * Length of linear sequences of amino acids contained in the subunit
         */
        length?: number;
        /**
         * The name of the fragment modified at the N-terminal of the SubstanceProtein shall be specified.
         *
         * The name of the fragment modified at the N-terminal of the SubstanceProtein shall be specified
         */
        nTerminalModification?: string;
        /**
         * Index of primary sequences of amino acids linked through peptide bonds in order of decreasing length. Sequences of the same length will be ordered by molecular weight. Subunits that have identical sequences will be repeated and have sequential subscripts.
         *
         * Index of primary sequences of amino acids linked through peptide bonds in order of decreasing length. Sequences of the same length will be ordered by molecular weight. Subunits that have identical sequences will be repeated and have sequential subscripts
         */
        subunit?: number;
        /**
         * Unique identifier for molecular fragment modification based on the ISO 11238 Substance ID.
         *
         * Unique identifier for molecular fragment modification based on the ISO 11238 Substance ID
         */
        nTerminalModificationId?: Identifier;
        /**
         * The sequence information shall be provided enumerating the amino acids from N- to C-terminal end using standard single-letter amino acid codes. Uppercase shall be used for L-amino acids and lowercase for D-amino acids. Transcribed SubstanceProteins will always be described using the translated sequence; for synthetic peptide containing amino acids that are not represented with a single letter code an X should be used within the sequence. The modified amino acids will be distinguished by their position in the sequence.
         *
         * The sequence information shall be provided enumerating the amino acids from N- to C-terminal end using standard single-letter amino acid codes. Uppercase shall be used for L-amino acids and lowercase for D-amino acids. Transcribed SubstanceProteins will always be described using the translated sequence; for synthetic peptide containing amino acids that are not represented with a single letter code an X should be used within the sequence. The modified amino acids will be distinguished by their position in the sequence
         */
        sequenceAttachment?: Attachment;
        /**
         * Unique identifier for molecular fragment modification based on the ISO 11238 Substance ID.
         *
         * Unique identifier for molecular fragment modification based on the ISO 11238 Substance ID
         */
        cTerminalModificationId?: Identifier;
        /**
         * The sequence information shall be provided enumerating the amino acids from N- to C-terminal end using standard single-letter amino acid codes. Uppercase shall be used for L-amino acids and lowercase for D-amino acids. Transcribed SubstanceProteins will always be described using the translated sequence; for synthetic peptide containing amino acids that are not represented with a single letter code an X should be used within the sequence. The modified amino acids will be distinguished by their position in the sequence.
         *
         * The sequence information shall be provided enumerating the amino acids from N- to C-terminal end using standard single-letter amino acid codes. Uppercase shall be used for L-amino acids and lowercase for D-amino acids. Transcribed SubstanceProteins will always be described using the translated sequence; for synthetic peptide containing amino acids that are not represented with a single letter code an X should be used within the sequence. The modified amino acids will be distinguished by their position in the sequence
         */
        sequence?: string;
        /**
         * The modification at the C-terminal shall be specified.
         *
         * The modification at the C-terminal shall be specified
         */
        cTerminalModification?: string;
        static revive(json: any): SubstanceProteinSubunitComponent;
        toJSON(): any;
    }
}
