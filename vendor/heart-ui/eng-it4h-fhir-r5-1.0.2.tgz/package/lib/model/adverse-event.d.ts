import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Timing } from '../datatype/timing';
import { AllergyIntolerance } from '../model/allergy-intolerance';
import { BiologicallyDerivedProduct } from '../model/biologically-derived-product';
import { CareTeam } from '../model/care-team';
import { Condition } from '../model/condition';
import { Device } from '../model/device';
import { DeviceUsage } from '../model/device-usage';
import { DocumentReference } from '../model/document-reference';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { FamilyMemberHistory } from '../model/family-member-history';
import { Group } from '../model/group';
import { Immunization } from '../model/immunization';
import { Location } from '../model/location';
import { Medication } from '../model/medication';
import { MedicationAdministration } from '../model/medication-administration';
import { MedicationRequest } from '../model/medication-request';
import { MedicationStatement } from '../model/medication-statement';
import { Observation } from '../model/observation';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Procedure } from '../model/procedure';
import { QuestionnaireResponse } from '../model/questionnaire-response';
import { RelatedPerson } from '../model/related-person';
import { ResearchStudy } from '../model/research-study';
import { ResearchSubject } from '../model/research-subject';
import { Substance } from '../model/substance';
/**
 * HAPI/FHIR <b>AdverseEvent</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/AdverseEvent">http://hl7.org/fhir/StructureDefinition/AdverseEvent</a>
 * </p>
 *
 */
export declare class AdverseEvent extends DomainResource {
    /**
     * Estimated or actual date the AdverseEvent began, in the opinion of the reporter.
     *
     * When the event was detected
     */
    detected?: Date;
    /**
     * The information about where the adverse event occurred.
     *
     * Location where adverse event occurred
     */
    location?: Location | Reference;
    /**
     * The overall type of event, intended for search and filtering purposes.
     *
     * wrong-patient | procedure-mishap | medication-mishap | device | unsafe-physical-environment | hospital-aquired-infection | wrong-body-site
     */
    category?: CodeableConcept[];
    /**
     * The current state of the adverse event or potential adverse event.
     *
     * in-progress | completed | entered-in-error | unknown
     */
    status: string;
    /**
     * Describes the type of outcome from the adverse event, such as resolved, recovering, ongoing, resolved-with-sequelae, or fatal.
     *
     * Type of outcome from the adverse event
     */
    outcome?: CodeableConcept[];
    /**
     * The contributing factors suspected to have increased the probability or severity of the adverse event.
     *
     * Contributing factors suspected to have increased the probability or severity of the adverse event
     */
    contributingFactor?: AdverseEvent.AdverseEventContributingFactorComponent[];
    /**
     * Information about the condition that occurred as a result of the adverse event, such as hives due to the exposure to a substance (for example, a drug or a chemical) or a broken leg as a result of the fall.
     *
     * Effect on the subject due to this event
     */
    resultingEffect?: Condition[] | Observation[] | Reference[];
    /**
     * Considered likely or probable or anticipated in the research study.  Whether the reported event matches any of the outcomes for the patient that are considered by the study as known or likely.
     *
     * Considered likely or probable or anticipated in the research study
     */
    expectedInResearchStudy?: boolean;
    /**
     * Supporting information relevant to the event.
     *
     * Supporting information relevant to the event
     */
    supportingInfo?: AdverseEvent.AdverseEventSupportingInfoComponent[];
    /**
     * Assessment whether this event, or averted event, was of clinical importance.
     *
     * Seriousness or gravity of the event
     */
    seriousness?: CodeableConcept;
    /**
     * The Encounter associated with the start of the AdverseEvent.
     *
     * The Encounter associated with the start of the AdverseEvent
     */
    encounter?: Encounter | Reference;
    /**
     * The date (and perhaps time) when the adverse event occurred.
     *
     * When the event occurred
     */
    occurrence?: Date | Period | Timing;
    /**
     * Indicates who or what participated in the adverse event and how they were involved.
     *
     * Who was involved in the adverse event or the potential adverse event and what they did
     */
    participant?: AdverseEvent.AdverseEventParticipantComponent[];
    /**
     * Describes the entity that is suspected to have caused the adverse event.
     *
     * The suspected agent causing the adverse event
     */
    suspectEntity?: AdverseEvent.AdverseEventSuspectEntityComponent[];
    /**
     * Business identifiers assigned to this adverse event by the performer or other systems which remain constant as the resource is updated and propagates from server to server.
     *
     * Business identifier for the event
     */
    identifier?: Identifier[];
    /**
     * Comments made about the adverse event by the performer, subject or other participants.
     *
     * Comment on adverse event
     */
    note?: Annotation[];
    /**
     * Specific event that occurred or that was averted, such as patient fall, wrong organ removed, or wrong blood transfused.
     *
     * Event or incident that occurred or was averted
     */
    code?: CodeableConcept;
    /**
     * Information on who recorded the adverse event.  May be the patient or a practitioner.
     *
     * Who recorded the adverse event
     */
    recorder?: Patient | Practitioner | PractitionerRole | RelatedPerson | ResearchSubject | Reference;
    /**
     * The research study that the subject is enrolled in.
     *
     * Research study that the subject is enrolled in
     */
    study?: ResearchStudy[] | Reference[];
    /**
     * Preventive actions that contributed to avoiding the adverse event.
     *
     * Preventive actions that contributed to avoiding the adverse event
     */
    preventiveAction?: AdverseEvent.AdverseEventPreventiveActionComponent[];
    /**
     * Whether the event actually happened or was a near miss. Note that this is independent of whether anyone was affected or harmed or how severely.
     *
     * actual | potential
     */
    actuality: string;
    /**
     * The date on which the existence of the AdverseEvent was first recorded.
     *
     * When the event was recorded
     */
    recordedDate?: Date;
    /**
     * The ameliorating action taken after the adverse event occured in order to reduce the extent of harm.
     *
     * Ameliorating actions taken after the adverse event occured in order to reduce the extent of harm
     */
    mitigatingAction?: AdverseEvent.AdverseEventMitigatingActionComponent[];
    /**
     * This subject or group impacted by the event.
     *
     * Subject impacted by event
     */
    subject: Patient | Group | Practitioner | RelatedPerson | ResearchSubject | Reference;
    readonly resourceType: string;
    static revive(json: any): AdverseEvent;
    toJSON(): any;
}
export declare namespace AdverseEvent {
    enum AdverseEventStatus {
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        INPROGRESS,
        UNKNOWN
    }
    enum AdverseEventActuality {
        NULL,
        POTENTIAL,
        ACTUAL
    }
    class AdverseEventSupportingInfoComponent extends BackboneElement {
        /**
         * Relevant past history for the subject. In a clinical care context, an example being a patient had an adverse event following a pencillin administration and the patient had a previously documented penicillin allergy. In a clinical trials context, an example is a bunion or rash that was present prior to the study. Additionally, the supporting item can be a document that is relevant to this instance of the adverse event that is not part of the subject's medical history. For example, a clinical note, staff list, or material safety data sheet (MSDS).  Supporting information is not a contributing factor, preventive action, or mitigating action.
         *
         * Subject medical history or document relevant to this adverse event
         */
        item: Condition | Observation | AllergyIntolerance | FamilyMemberHistory | Immunization | Procedure | DocumentReference | MedicationAdministration | MedicationStatement | QuestionnaireResponse | CodeableConcept | Reference;
        static revive(json: any): AdverseEventSupportingInfoComponent;
        toJSON(): any;
    }
    class AdverseEventMitigatingActionComponent extends BackboneElement {
        /**
         * The ameliorating action taken after the adverse event occured in order to reduce the extent of harm.
         *
         * Ameliorating action taken after the adverse event occured in order to reduce the extent of harm
         */
        item: Procedure | DocumentReference | MedicationAdministration | MedicationRequest | CodeableConcept | Reference;
        static revive(json: any): AdverseEventMitigatingActionComponent;
        toJSON(): any;
    }
    class AdverseEventPreventiveActionComponent extends BackboneElement {
        /**
         * The action that contributed to avoiding the adverse event.
         *
         * Action that contributed to avoiding the adverse event
         */
        item: Immunization | Procedure | DocumentReference | MedicationAdministration | MedicationRequest | CodeableConcept | Reference;
        static revive(json: any): AdverseEventPreventiveActionComponent;
        toJSON(): any;
    }
    class AdverseEventContributingFactorComponent extends BackboneElement {
        /**
         * The item that is suspected to have increased the probability or severity of the adverse event.
         *
         * Item suspected to have increased the probability or severity of the adverse event
         */
        item: Condition | Observation | AllergyIntolerance | FamilyMemberHistory | Immunization | Procedure | Device | DeviceUsage | DocumentReference | MedicationAdministration | MedicationStatement | CodeableConcept | Reference;
        static revive(json: any): AdverseEventContributingFactorComponent;
        toJSON(): any;
    }
    class AdverseEventSuspectEntityCausalityComponent extends BackboneElement {
        /**
         * The method of evaluating the relatedness of the suspected entity to the event.
         *
         * Method of evaluating the relatedness of the suspected entity to the event
         */
        assessmentMethod?: CodeableConcept;
        /**
         * The result of the assessment regarding the relatedness of the suspected entity to the event.
         *
         * Result of the assessment regarding the relatedness of the suspected entity to the event
         */
        entityRelatedness?: CodeableConcept;
        /**
         * The author of the information on the possible cause of the event.
         *
         * Author of the information on the possible cause of the event
         */
        author?: Practitioner | PractitionerRole | Patient | RelatedPerson | ResearchSubject | Reference;
        static revive(json: any): AdverseEventSuspectEntityCausalityComponent;
        toJSON(): any;
    }
    class AdverseEventSuspectEntityComponent extends BackboneElement {
        /**
         * Information on the possible cause of the event.
         *
         * Information on the possible cause of the event
         */
        causality?: AdverseEvent.AdverseEventSuspectEntityCausalityComponent;
        /**
         * Identifies the actual instance of what caused the adverse event.  May be a substance, medication, medication administration, medication statement or a device.
         *
         * Refers to the specific entity that caused the adverse event
         */
        instance: CodeableConcept | Immunization | Procedure | Substance | Medication | MedicationAdministration | MedicationStatement | Device | BiologicallyDerivedProduct | ResearchStudy | Reference;
        static revive(json: any): AdverseEventSuspectEntityComponent;
        toJSON(): any;
    }
    class AdverseEventParticipantComponent extends BackboneElement {
        /**
         * Indicates who or what participated in the event.
         *
         * Who was involved in the adverse event or the potential adverse event
         */
        actor: Practitioner | PractitionerRole | Organization | CareTeam | Patient | Device | RelatedPerson | ResearchSubject | Reference;
        /**
         * Distinguishes the type of involvement of the actor in the adverse event, such as contributor or informant.
         *
         * Type of involvement
         */
        function?: CodeableConcept;
        static revive(json: any): AdverseEventParticipantComponent;
        toJSON(): any;
    }
}
