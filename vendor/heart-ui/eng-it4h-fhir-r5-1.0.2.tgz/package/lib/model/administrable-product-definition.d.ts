import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Duration } from '../datatype/duration';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { Ratio } from '../datatype/ratio';
import { DeviceDefinition } from '../model/device-definition';
import { DomainResource } from '../model/domain-resource';
import { ManufacturedItemDefinition } from '../model/manufactured-item-definition';
import { MedicinalProductDefinition } from '../model/medicinal-product-definition';
/**
 * HAPI/FHIR <b>AdministrableProductDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/AdministrableProductDefinition">http://hl7.org/fhir/StructureDefinition/AdministrableProductDefinition</a>
 * </p>
 *
 */
export declare class AdministrableProductDefinition extends DomainResource {
    /**
     * The dose form of the final product after necessary reconstitution or processing. Contrasts to the manufactured dose form (see ManufacturedItemDefinition). If the manufactured form was 'powder for solution for injection', the administrable dose form could be 'solution for injection' (once mixed with another item having manufactured form 'solvent for solution for injection').
     *
     * The dose form of the final product after necessary reconstitution or processing
     */
    administrableDoseForm?: CodeableConcept;
    /**
     * The presentation type in which this item is given to a patient. e.g. for a spray - 'puff' (as in 'contains 100 mcg per puff'), or for a liquid - 'vial' (as in 'contains 5 ml per vial').
     *
     * The presentation type in which this item is given to a patient. e.g. for a spray - 'puff'
     */
    unitOfPresentation?: CodeableConcept;
    /**
     * The ingredients of this administrable medicinal product. This is only needed if the ingredients are not specified either using ManufacturedItemDefiniton (via AdministrableProductDefinition.producedFrom) to state which component items are used to make this, or using by incoming references from the Ingredient resource, to state in detail which substances exist within this. This element allows a basic coded ingredient to be used.
     *
     * The ingredients of this administrable medicinal product. This is only needed if the ingredients are not specified either using ManufacturedItemDefiniton, or using by incoming references from the Ingredient resource
     */
    ingredient?: CodeableConcept[];
    /**
     * An identifier for the administrable product.
     *
     * An identifier for the administrable product
     */
    identifier?: Identifier[];
    /**
     * References a product from which one or more of the constituent parts of that product can be prepared and used as described by this administrable product.  If this administrable product describes the administration of a crushed tablet, the 'formOf' would be the product representing a distribution containing tablets and possibly also a cream.  This is distinct from the 'producedFrom' which refers to the specific components of the product that are used in this preparation, rather than the product as a whole.
     *
     * References a product from which one or more of the constituent parts of that product can be prepared and used as described by this administrable product
     */
    formOf?: MedicinalProductDefinition[] | Reference[];
    /**
     * A general description of the product, when in its final form, suitable for administration e.g. effervescent blue liquid, to be swallowed. Intended to be used when the other structured properties of this resource are insufficient or cannot be supported. It is not intended to duplicate information already carried elswehere.
     *
     * A general description of the product, when in its final form, suitable for administration e.g. effervescent blue liquid, to be swallowed
     */
    description?: string;
    /**
     * Characteristics e.g. a product's onset of action.
     *
     * Characteristics e.g. a product's onset of action
     */
    property?: AdministrableProductDefinition.AdministrableProductDefinitionPropertyComponent[];
    /**
     * The path by which the product is taken into or makes contact with the body. In some regions this is referred to as the licenced or approved route. RouteOfAdministration cannot be used when the 'formOf' product already uses MedicinalProductDefinition.route (and vice versa).
     *
     * The path by which the product is taken into or makes contact with the body
     */
    routeOfAdministration: AdministrableProductDefinition.AdministrableProductDefinitionRouteOfAdministrationComponent[];
    /**
     * The status of this administrable product. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * Indicates the specific manufactured items that are part of the 'formOf' product that are used in the preparation of this specific administrable form.  In some cases, an administrable form might use all of the items from the overall product (or there might only be one item), while in other cases, an administrable form might use only a subset of the items available in the overall product.  For example, an administrable form might involve combining a liquid and a powder available as part of an overall product, but not involve applying the also supplied cream.
     *
     * Indicates the specific manufactured items that are part of the 'formOf' product that are used in the preparation of this specific administrable form
     */
    producedFrom?: ManufacturedItemDefinition[] | Reference[];
    /**
     * A device that is integral to the medicinal product, in effect being considered as an "ingredient" of the medicinal product. This is not intended for devices that are just co-packaged.
     *
     * A device that is integral to the medicinal product, in effect being considered as an "ingredient" of the medicinal product
     */
    device?: DeviceDefinition | Reference;
    readonly resourceType: string;
    static revive(json: any): AdministrableProductDefinition;
    toJSON(): any;
}
export declare namespace AdministrableProductDefinition {
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class AdministrableProductDefinitionRouteOfAdministrationTargetSpeciesWithdrawalPeriodComponent extends BackboneElement {
        /**
         * Coded expression for the type of tissue for which the withdrawal period applies, e.g. meat, milk.
         *
         * The type of tissue for which the withdrawal period applies, e.g. meat, milk
         */
        tissue: CodeableConcept;
        /**
         * Extra information about the withdrawal period.
         *
         * Extra information about the withdrawal period
         */
        supportingInformation?: string;
        /**
         * A value for the time.
         *
         * A value for the time
         */
        value: Quantity;
        static revive(json: any): AdministrableProductDefinitionRouteOfAdministrationTargetSpeciesWithdrawalPeriodComponent;
        toJSON(): any;
    }
    class AdministrableProductDefinitionRouteOfAdministrationTargetSpeciesComponent extends BackboneElement {
        /**
         * Coded expression for the species.
         *
         * Coded expression for the species
         */
        code: CodeableConcept;
        /**
         * A species specific time during which consumption of animal product is not appropriate.
         *
         * A species specific time during which consumption of animal product is not appropriate
         */
        withdrawalPeriod?: AdministrableProductDefinition.AdministrableProductDefinitionRouteOfAdministrationTargetSpeciesWithdrawalPeriodComponent[];
        static revive(json: any): AdministrableProductDefinitionRouteOfAdministrationTargetSpeciesComponent;
        toJSON(): any;
    }
    class AdministrableProductDefinitionRouteOfAdministrationComponent extends BackboneElement {
        /**
         * Coded expression for the route.
         *
         * Coded expression for the route
         */
        code: CodeableConcept;
        /**
         * The maximum single dose that can be administered, specified using a numerical value and its unit of measurement.
         *
         * The maximum single dose that can be administered
         */
        maxSingleDose?: Quantity;
        /**
         * The maximum treatment period during which the product can be administered.
         *
         * The maximum treatment period during which the product can be administered
         */
        maxTreatmentPeriod?: Duration;
        /**
         * A species for which this route applies.
         *
         * A species for which this route applies
         */
        targetSpecies?: AdministrableProductDefinition.AdministrableProductDefinitionRouteOfAdministrationTargetSpeciesComponent[];
        /**
         * The first dose (dose quantity) administered can be specified for the product, using a numerical value and its unit of measurement.
         *
         * The first dose (dose quantity) administered can be specified for the product
         */
        firstDose?: Quantity;
        /**
         * The maximum dose per day (maximum dose quantity to be administered in any one 24-h period) that can be administered.
         *
         * The maximum dose quantity to be administered in any one 24-h period
         */
        maxDosePerDay?: Quantity;
        /**
         * The maximum dose per treatment period that can be administered.
         *
         * The maximum dose per treatment period that can be administered
         */
        maxDosePerTreatmentPeriod?: Ratio;
        static revive(json: any): AdministrableProductDefinitionRouteOfAdministrationComponent;
        toJSON(): any;
    }
    class AdministrableProductDefinitionPropertyComponent extends BackboneElement {
        /**
         * The status of characteristic e.g. assigned or pending.
         *
         * The status of characteristic e.g. assigned or pending
         */
        status?: CodeableConcept;
        /**
         * A value for the characteristic.
         *
         * A value for the characteristic
         */
        value?: CodeableConcept | Quantity | Date | boolean | string | Attachment;
        /**
         * A code expressing the type of characteristic.
         *
         * A code expressing the type of characteristic
         */
        type: CodeableConcept;
        static revive(json: any): AdministrableProductDefinitionPropertyComponent;
        toJSON(): any;
    }
}
