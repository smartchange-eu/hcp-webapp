import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { ContactPoint } from '../datatype/contact-point';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { DomainResource } from '../model/domain-resource';
import { Organization } from '../model/organization';
/**
 * HAPI/FHIR <b>Endpoint</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Endpoint">http://hl7.org/fhir/StructureDefinition/Endpoint</a>
 * </p>
 *
 */
export declare class Endpoint extends DomainResource {
    /**
     * The interval during which the endpoint is expected to be operational.
     *
     * Interval the endpoint is expected to be operational
     */
    period?: Period;
    /**
     * The organization that manages this endpoint (even if technically another organization is hosting this in the cloud, it is the organization associated with the data).
     *
     * Organization that manages this endpoint (might not be the organization that exposes the endpoint)
     */
    managingOrganization?: Organization | Reference;
    /**
     * The uri that describes the actual end-point to connect to.
     *
     * The technical base address for connecting to this endpoint
     */
    address: string;
    /**
     * Identifier for the organization that is used to identify the endpoint across multiple disparate systems.
     *
     * Identifies this endpoint across multiple systems
     */
    identifier?: Identifier[];
    /**
     * The type of environment(s) exposed at this endpoint (dev, prod, test, etc.).
     *
     * The type of environment(s) exposed at this endpoint
     */
    environmentType?: CodeableConcept[];
    /**
     * Contact details for a human to contact about the endpoint. The primary use of this for system administrator troubleshooting.
     *
     * Contact details for source (e.g. troubleshooting)
     */
    contact?: ContactPoint[];
    /**
     * The set of payloads that are provided/available at this endpoint.
     *
     * Set of payloads that are provided by this endpoint
     */
    payload?: Endpoint.EndpointPayloadComponent[];
    /**
     * A friendly name that this endpoint can be referred to with.
     *
     * A name that this endpoint can be identified by
     */
    name?: string;
    /**
     * The description of the endpoint and what it is for (typically used as supplemental information in an endpoint directory describing its usage/purpose).
     *
     * Additional details about the endpoint that could be displayed as further information to identify the description beyond its name
     */
    description?: string;
    /**
     * Additional headers / information to send as part of the notification.
     *
     * Usage depends on the channel type
     */
    header?: string[];
    /**
     * The endpoint status represents the general expected availability of an endpoint.
     *
     * active | suspended | error | off | entered-in-error | test
     */
    status: string;
    /**
     * A coded value that represents the technical details of the usage of this endpoint, such as what WSDLs should be used in what way. (e.g. XDS.b/DICOM/cds-hook).
     *
     * Protocol/Profile/Standard to be used with this endpoint connection
     */
    connectionType: CodeableConcept[];
    readonly resourceType: string;
    static revive(json: any): Endpoint;
    toJSON(): any;
}
export declare namespace Endpoint {
    enum EndpointStatus {
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        SUSPENDED,
        ERROR,
        OFF
    }
    class EndpointPayloadComponent extends BackboneElement {
        /**
         * The mime type to send the payload in - e.g. application/fhir+xml, application/fhir+json. If the mime type is not specified, then the sender could send any content (including no content depending on the connectionType).
         *
         * Mimetype to send. If not specified, the content could be anything (including no payload, if the connectionType defined this)
         */
        mimeType?: string[];
        /**
         * The payload type describes the acceptable content that can be communicated on the endpoint.
         *
         * The type of content that may be used at this endpoint (e.g. XDS Discharge summaries)
         */
        type?: CodeableConcept[];
        static revive(json: any): EndpointPayloadComponent;
        toJSON(): any;
    }
}
