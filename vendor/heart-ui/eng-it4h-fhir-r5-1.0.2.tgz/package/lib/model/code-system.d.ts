import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { RelatedArtifact } from '../datatype/related-artifact';
import { UsageContext } from '../datatype/usage-context';
import { MetadataResource } from '../model/metadata-resource';
/**
 * HAPI/FHIR <b>CodeSystem</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/CodeSystem">http://hl7.org/fhir/StructureDefinition/CodeSystem</a>
 * </p>
 *
 */
export declare class CodeSystem extends MetadataResource {
    /**
     * The canonical URL of the code system that this code system supplement is adding designations and properties to.
     *
     * Canonical URL of Code System this adds designations and properties to
     */
    supplements?: string;
    /**
     * A filter that can be used in a value set compose statement when selecting concepts using a filter.
     *
     * Filter that can be used in a value set
     */
    filter?: CodeSystem.CodeSystemFilterComponent[];
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * The date on which the resource content was last reviewed. Review happens periodically after approval but does not change the original approval date.
     *
     * When the CodeSystem was last reviewed by the publisher
     */
    lastReviewDate?: Date;
    /**
     * The code system defines a compositional (post-coordination) grammar.
     *
     * If code system defines a compositional grammar
     */
    compositional?: boolean;
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the code system.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * Descriptions related to the content of the CodeSystem. Topics provide a high-level categorization as well as keywords for the CodeSystem that can be useful for filtering and searching.
     *
     * E.g. Education, Treatment, Assessment, etc
     */
    topic?: CodeableConcept[];
    /**
     * A natural language name identifying the code system. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this code system (computer friendly)
     */
    name?: string;
    /**
     * The status of this code system. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate code system instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * Related artifacts such as additional documentation, justification, dependencies, bibliographic references, and predecessor and successor artifacts.
     *
     * Additional documentation, citations, etc
     */
    relatedArtifact?: RelatedArtifact[];
    /**
     * A formal identifier that is used to identify this code system when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the code system (business identifier)
     */
    identifier?: Identifier[];
    /**
     * An individual or organization primarily responsible for internal coherence of the CodeSystem.
     *
     * Who edited the CodeSystem
     */
    editor?: ContactDetail[];
    /**
     * This flag is used to signify that the code system does not commit to concept permanence across versions. If true, a version must be specified when referencing this code system.
     *
     * If definitions are not stable
     */
    versionNeeded?: boolean;
    /**
     * An individiual or organization primarily involved in the creation and maintenance of the CodeSystem.
     *
     * Who authored the CodeSystem
     */
    author?: ContactDetail[];
    /**
     * If code comparison is case sensitive when codes within this system are compared to each other.
     *
     * If code comparison is case sensitive
     */
    caseSensitive?: boolean;
    /**
     * The period during which the CodeSystem content was or is planned to be in active use.
     *
     * When the CodeSystem is expected to be used
     */
    effectivePeriod?: Period;
    /**
     * An individual or organization asserted by the publisher to be primarily responsible for review of some aspect of the CodeSystem.
     *
     * Who reviewed the CodeSystem
     */
    reviewer?: ContactDetail[];
    /**
     * The total number of concepts defined by the code system. Where the code system has a compositional grammar, the basis of this count is defined by the system steward.
     *
     * Total concepts in the code system
     */
    count?: number;
    /**
     * An absolute URI that is used to identify this code system when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this code system is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the code system is stored on different servers. This is used in [Coding](datatypes.html#Coding).system.
     *
     * Canonical identifier for this code system, represented as a URI (globally unique) (Coding.system)
     */
    url?: string;
    /**
     * The identifier that is used to identify this version of the code system when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the code system author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence. This is used in [Coding](datatypes.html#Coding).version.
     *
     * Business version of the code system (Coding.version)
     */
    version?: string;
    /**
     * Indicates the mechanism used to compare versions to determine which CodeSystem is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * An individual or organization asserted by the publisher to be responsible for officially endorsing the CodeSystem for use in some setting.
     *
     * Who endorsed the CodeSystem
     */
    endorser?: ContactDetail[];
    /**
     * A property defines an additional slot through which additional information can be provided about a concept.
     *
     * Additional information supplied about each concept
     */
    property?: CodeSystem.PropertyComponent[];
    /**
     * The date on which the resource content was approved by the publisher. Approval happens once when the content is officially approved for usage.
     *
     * When the CodeSystem was approved by publisher
     */
    approvalDate?: Date;
    /**
     * Canonical reference to the value set that contains all codes in the code system independent of code status.
     *
     * Canonical reference to the value set with entire code system
     */
    valueSet?: string;
    /**
     * A copyright statement relating to the code system and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the code system.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * The date  (and optionally time) when the code system was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the code system changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * A legal or geographic region in which the code system is intended to be used.
     *
     * Intended jurisdiction for code system (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * Concepts that are in the code system. The concept definitions are inherently hierarchical, but the definitions must be consulted to determine what the meanings of the hierarchical relationships are.
     *
     * Concepts in the code system
     */
    concept?: CodeSystem.ConceptDefinitionComponent[];
    /**
     * Explanation of why this code system is needed and why it has been designed as it has.
     *
     * Why this code system is defined
     */
    purpose?: string;
    /**
     * A Boolean value to indicate that this code system is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A free text natural language description of the code system from a consumer's perspective.
     *
     * Natural language description of the code system
     */
    description?: string;
    /**
     * The meaning of the hierarchy of concepts as represented in this resource.
     *
     * grouped-by | is-a | part-of | classified-with
     */
    hierarchyMeaning?: string;
    /**
     * The extent of the content of the code system (the concepts and codes it defines) are represented in this resource instance.
     *
     * not-present | example | fragment | complete | supplement
     */
    content: string;
    /**
     * A short, descriptive, user-friendly title for the code system.
     *
     * Name for this code system (human friendly)
     */
    title?: string;
    readonly resourceType: string;
    static revive(json: any): CodeSystem;
    toJSON(): any;
}
export declare namespace CodeSystem {
    enum PropertyType {
        CODE,
        NULL,
        DATETIME,
        CODING,
        STRING,
        DECIMAL,
        BOOLEAN,
        INTEGER
    }
    enum CodeSystemHierarchyMeaning {
        NULL,
        PARTOF,
        ISA,
        CLASSIFIEDWITH,
        GROUPEDBY
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    enum CodeSystemContentMode {
        SUPPLEMENT,
        COMPLETE,
        NULL,
        FRAGMENT,
        EXAMPLE,
        NOTPRESENT
    }
    class ConceptPropertyComponent extends BackboneElement {
        /**
         * The value of this property.
         *
         * Value of the property for this concept
         */
        value: string | Coding | number | boolean | Date | number;
        /**
         * A code that is a reference to CodeSystem.property.code.
         *
         * Reference to CodeSystem.property.code
         */
        code: string;
        static revive(json: any): ConceptPropertyComponent;
        toJSON(): any;
    }
    class ConceptDefinitionDesignationComponent extends BackboneElement {
        /**
         * A code that details how this designation would be used.
         *
         * Details how this designation would be used
         */
        use?: Coding;
        /**
         * Additional codes that detail how this designation would be used, if there is more than one use.
         *
         * Additional ways how this designation would be used
         */
        additionalUse?: Coding[];
        /**
         * The text value for this designation.
         *
         * The text value for this designation
         */
        value: string;
        /**
         * The language this designation is defined for.
         *
         * Human language of the designation
         */
        language?: string;
        static revive(json: any): ConceptDefinitionDesignationComponent;
        toJSON(): any;
    }
    class ConceptDefinitionComponent extends BackboneElement {
        /**
         * A property value for this concept.
         *
         * Property value for the concept
         */
        property?: CodeSystem.ConceptPropertyComponent[];
        /**
         * Additional representations for the concept - other languages, aliases, specialized purposes, used for particular purposes, etc.
         *
         * Additional representations for the concept
         */
        designation?: CodeSystem.ConceptDefinitionDesignationComponent[];
        /**
         * The formal definition of the concept. The code system resource does not make formal definitions required, because of the prevalence of legacy systems. However, they are highly recommended, as without them there is no formal meaning associated with the concept.
         *
         * Formal definition
         */
        definition?: string;
        /**
         * A code - a text symbol - that uniquely identifies the concept within the code system.
         *
         * Code that identifies concept
         */
        code: string;
        /**
         * A human readable string that is the recommended default way to present this concept to a user.
         *
         * Text to display to the user
         */
        display?: string;
        /**
         * Defines children of a concept to produce a hierarchy of concepts. The nature of the relationships is variable (is-a/contains/categorizes) - see hierarchyMeaning.
         *
         * Child Concepts (is-a/contains/categorizes)
         */
        concept?: CodeSystem.ConceptDefinitionComponent[];
        static revive(json: any): ConceptDefinitionComponent;
        toJSON(): any;
    }
    class PropertyComponent extends BackboneElement {
        /**
         * A code that is used to identify the property. The code is used internally (in CodeSystem.concept.property.code) and also externally, such as in property filters.
         *
         * Identifies the property on the concepts, and when referred to in operations
         */
        code: string;
        /**
         * A description of the property- why it is defined, and how its value might be used.
         *
         * Why the property is defined, and/or what it conveys
         */
        description?: string;
        /**
         * Reference to the formal meaning of the property. One possible source of meaning is the [Concept Properties](codesystem-concept-properties.html) code system.
         *
         * Formal identifier for the property
         */
        uri?: string;
        /**
         * The type of the property value. Properties of type "code" contain a code defined by the code system (e.g. a reference to another defined concept).
         *
         * code | Coding | string | integer | boolean | dateTime | decimal
         */
        type: string;
        static revive(json: any): PropertyComponent;
        toJSON(): any;
    }
    class CodeSystemFilterComponent extends BackboneElement {
        /**
         * A description of how or why the filter is used.
         *
         * How or why the filter is used
         */
        description?: string;
        /**
         * A description of what the value for the filter should be.
         *
         * What to use for the value
         */
        value: string;
        /**
         * A list of operators that can be used with the filter.
         *
         * = | is-a | descendent-of | is-not-a | regex | in | not-in | generalizes | child-of | descendent-leaf | exists
         */
        operator: string[];
        /**
         * The code that identifies this filter when it is used as a filter in [ValueSet](valueset.html#).compose.include.filter.
         *
         * Code that identifies the filter
         */
        code: string;
        static revive(json: any): CodeSystemFilterComponent;
        toJSON(): any;
    }
}
