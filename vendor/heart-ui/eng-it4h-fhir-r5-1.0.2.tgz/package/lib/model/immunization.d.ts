import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { CarePlan } from '../model/care-plan';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { ImmunizationRecommendation } from '../model/immunization-recommendation';
import { Location } from '../model/location';
import { MedicationRequest } from '../model/medication-request';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
import { ServiceRequest } from '../model/service-request';
/**
 * HAPI/FHIR <b>Immunization</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Immunization">http://hl7.org/fhir/StructureDefinition/Immunization</a>
 * </p>
 *
 */
export declare class Immunization extends DomainResource {
    /**
     * Indicates the source of the vaccine actually administered. This may be different than the patient eligibility (e.g. the patient may be eligible for a publically purchased vaccine but due to inventory issues, vaccine purchased with private funds was actually administered).
     *
     * Funding source for the vaccine
     */
    fundingSource?: CodeableConcept;
    /**
     * Indicates the current status of the immunization event.
     *
     * completed | entered-in-error | not-done
     */
    status: string;
    /**
     * An indication of which product was administered to the patient. This is typically a more detailed representation of the concept conveyed by the vaccineCode data element. If a Medication resource is referenced, it may be to a stand-alone resource or a contained resource within the Immunization resource.
     *
     * Product that was administered
     */
    administeredProduct?: CodeableReference;
    /**
     * The protocol (set of recommendations) being followed by the provider who administered the dose.
     *
     * Protocol followed by the provider
     */
    protocolApplied?: Immunization.ImmunizationProtocolAppliedComponent[];
    /**
     * The service delivery location where the vaccine administration occurred.
     *
     * Where immunization occurred
     */
    location?: Location | Reference;
    /**
     * The path by which the vaccine product is taken into the body.
     *
     * How vaccine entered body
     */
    route?: CodeableConcept;
    /**
     * Body site where vaccine was administered.
     *
     * Body site vaccine  was administered
     */
    site?: CodeableConcept;
    /**
     * Additional information that is relevant to the immunization (e.g. for a vaccine recipient who is pregnant, the gestational age of the fetus). The reason why a vaccine was given (e.g. occupation, underlying medical condition) should be conveyed in Immunization.reason, not as supporting information. The reason why a vaccine was not given (e.g. contraindication) should be conveyed in Immunization.statusReason, not as supporting information.
     *
     * Additional information in support of the immunization
     */
    supportingInformation?: Reference[];
    /**
     * Lot number of the  vaccine product.
     *
     * Vaccine lot number
     */
    lotNumber?: string;
    /**
     * The visit or admission or other contact between patient and health care provider the immunization was performed as part of.
     *
     * Encounter immunization was part of
     */
    encounter?: Encounter | Reference;
    /**
     * Reason why a dose is considered to be subpotent.
     *
     * Reason for being subpotent
     */
    subpotentReason?: CodeableConcept[];
    /**
     * A unique identifier assigned to this immunization record.
     *
     * Business identifier
     */
    identifier?: Identifier[];
    /**
     * Indicates who performed the immunization event.
     *
     * Who performed event
     */
    performer?: Immunization.ImmunizationPerformerComponent[];
    /**
     * Categorical data indicating that an adverse event is associated in time to an immunization.
     *
     * Details of a reaction that follows immunization
     */
    reaction?: Immunization.ImmunizationReactionComponent[];
    /**
     * Date vaccine batch expires.
     *
     * Vaccine expiration date
     */
    expirationDate?: Date;
    /**
     * A plan, order or recommendation fulfilled in whole or in part by this immunization.
     *
     * Authority that the immunization event is based on
     */
    basedOn?: CarePlan[] | MedicationRequest[] | ServiceRequest[] | ImmunizationRecommendation[] | Reference[];
    /**
     * Vaccine that was administered or was to be administered.
     *
     * Vaccine administered
     */
    vaccineCode: CodeableConcept;
    /**
     * Typically the source of the data when the report of the immunization event is not based on information from the person who administered the vaccine.
     *
     * Indicates the source of a  reported record
     */
    informationSource?: CodeableReference;
    /**
     * Indication if a dose is considered to be subpotent. By default, a dose should be considered to be potent.
     *
     * Dose potency
     */
    isSubpotent?: boolean;
    /**
     * The patient who either received or did not receive the immunization.
     *
     * Who was immunized
     */
    patient: Patient | Reference;
    /**
     * Indicates a patient's eligibility for a funding program.
     *
     * Patient eligibility for a specific vaccination program
     */
    programEligibility?: Immunization.ImmunizationProgramEligibilityComponent[];
    /**
     * Indicates the reason the immunization event was not performed.
     *
     * Reason for current status
     */
    statusReason?: CodeableConcept;
    /**
     * Name of vaccine manufacturer.
     *
     * Vaccine manufacturer
     */
    manufacturer?: CodeableReference;
    /**
     * Date vaccine administered or was to be administered.
     *
     * Vaccine administration date
     */
    occurrence: Date | string;
    /**
     * The quantity of vaccine product that was administered.
     *
     * Amount of vaccine administered
     */
    doseQuantity?: Quantity;
    /**
     * Indicates whether the data contained in the resource was captured by the individual/organization which was responsible for the administration of the vaccine rather than as 'secondary reported' data documented by a third party. A value of 'true' means this data originated with the individual/organization which was responsible for the administration of the vaccine.
     *
     * Indicates context the data was captured in
     */
    primarySource?: boolean;
    /**
     * Extra information about the immunization that is not conveyed by the other attributes.
     *
     * Additional immunization notes
     */
    note?: Annotation[];
    /**
     * Describes why the immunization occurred in coded or textual form, or Indicates another resource (Condition, Observation or DiagnosticReport) whose existence justifies this immunization.
     *
     * Why immunization occurred
     */
    reason?: CodeableReference[];
    readonly resourceType: string;
    static revive(json: any): Immunization;
    toJSON(): any;
}
export declare namespace Immunization {
    enum ImmunizationStatusCodes {
        ENTEREDINERROR,
        NOTDONE,
        COMPLETED,
        NULL
    }
    class ImmunizationProtocolAppliedComponent extends BackboneElement {
        /**
         * Indicates the authority who published the protocol (e.g. ACIP) that is being followed.
         *
         * Who is responsible for publishing the recommendations
         */
        authority?: Organization | Reference;
        /**
         * One possible path to achieve presumed immunity against a disease - within the context of an authority.
         *
         * Name of vaccine series
         */
        series?: string;
        /**
         * Nominal position in a series as intended by the practitioner administering the dose.
         *
         * Dose number within series
         */
        doseNumber: string;
        /**
         * The recommended number of doses to achieve immunity as intended by the practitioner administering the dose.
         *
         * Recommended number of doses for immunity
         */
        seriesDoses?: string;
        /**
         * The vaccine preventable disease the dose is being administered against.
         *
         * Vaccine preventatable disease being targeted
         */
        targetDisease?: CodeableConcept[];
        static revive(json: any): ImmunizationProtocolAppliedComponent;
        toJSON(): any;
    }
    class ImmunizationReactionComponent extends BackboneElement {
        /**
         * Self-reported indicator.
         *
         * Indicates self-reported reaction
         */
        reported?: boolean;
        /**
         * Details of the reaction.
         *
         * Additional information on reaction
         */
        manifestation?: CodeableReference;
        /**
         * Date of reaction to the immunization.
         *
         * When reaction started
         */
        date?: Date;
        static revive(json: any): ImmunizationReactionComponent;
        toJSON(): any;
    }
    class ImmunizationProgramEligibilityComponent extends BackboneElement {
        /**
         * Indicates which program the patient had their eligility evaluated for.
         *
         * The program that eligibility is declared for
         */
        program: CodeableConcept;
        /**
         * Indicates the patient's eligility status for for a specific payment program.
         *
         * The patient's eligibility status for the program
         */
        programStatus: CodeableConcept;
        static revive(json: any): ImmunizationProgramEligibilityComponent;
        toJSON(): any;
    }
    class ImmunizationPerformerComponent extends BackboneElement {
        /**
         * The practitioner or organization who performed the action.
         *
         * Individual or organization who was performing
         */
        actor: Practitioner | PractitionerRole | Organization | Patient | RelatedPerson | Reference;
        /**
         * Describes the type of performance (e.g. ordering provider, administering provider, etc.).
         *
         * What type of performance was done
         */
        function?: CodeableConcept;
        static revive(json: any): ImmunizationPerformerComponent;
        toJSON(): any;
    }
}
