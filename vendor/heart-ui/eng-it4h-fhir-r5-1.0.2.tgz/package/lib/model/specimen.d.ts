import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Duration } from '../datatype/duration';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { BiologicallyDerivedProduct } from '../model/biologically-derived-product';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Group } from '../model/group';
import { Location } from '../model/location';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Procedure } from '../model/procedure';
import { RelatedPerson } from '../model/related-person';
import { ServiceRequest } from '../model/service-request';
import { Substance } from '../model/substance';
/**
 * HAPI/FHIR <b>Specimen</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Specimen">http://hl7.org/fhir/StructureDefinition/Specimen</a>
 * </p>
 *
 */
export declare class Specimen extends DomainResource {
    /**
     * Time when specimen is received by the testing laboratory for processing or testing.
     *
     * The time when specimen is received by the testing laboratory
     */
    receivedTime?: Date;
    /**
     * A physical feature or landmark on a specimen, highlighted for context by the collector of the specimen (e.g. surgeon), that identifies the type of feature as well as its meaning (e.g. the red ink indicating the resection margin of the right lobe of the excised prostate tissue or wire loop at radiologically suspected tumor location).
     *
     * The physical feature of a specimen
     */
    feature?: Specimen.SpecimenFeatureComponent[];
    /**
     * A mode or state of being that describes the nature of the specimen.
     *
     * State of the specimen
     */
    condition?: CodeableConcept[];
    /**
     * The availability of the specimen.
     *
     * available | unavailable | unsatisfactory | entered-in-error
     */
    status?: string;
    /**
     * This element signifies if the specimen is part of a group or pooled.
     *
     * grouped | pooled
     */
    combined?: string;
    /**
     * Details concerning processing and processing steps for the specimen.
     *
     * Processing and processing step details
     */
    processing?: Specimen.SpecimenProcessingComponent[];
    /**
     * Where the specimen came from. This may be from patient(s), from a location (e.g., the source of an environmental sample), or a sampling of a substance, a biologically-derived product, or a device.
     *
     * Where the specimen came from. This may be from patient(s), from a location (e.g., the source of an environmental sample), or a sampling of a substance, a biologically-derived product, or a device
     */
    subject?: Patient | Group | Device | BiologicallyDerivedProduct | Substance | Location | Reference;
    /**
     * The role or reason for the specimen in the testing workflow.
     *
     * The role the specimen serves
     */
    role?: CodeableConcept[];
    /**
     * Id for specimen.
     *
     * External Identifier
     */
    identifier?: Identifier[];
    /**
     * The identifier assigned by the lab when accessioning specimen(s). This is not necessarily the same as the specimen identifier, depending on local lab procedures.
     *
     * Identifier assigned by the lab
     */
    accessionIdentifier?: Identifier;
    /**
     * Reference to the parent (source) specimen which is used when the specimen was either derived from or a component of another specimen.
     *
     * Specimen from which this specimen originated
     */
    parent?: Specimen[] | Reference[];
    /**
     * Details concerning a service request that required a specimen to be collected.
     *
     * Why the specimen was collected
     */
    request?: ServiceRequest[] | Reference[];
    /**
     * To communicate any details or issues about the specimen or during the specimen collection. (for example: broken vial, sent with patient, frozen).
     *
     * Comments
     */
    note?: Annotation[];
    /**
     * The container holding the specimen.  The recursive nature of containers; i.e. blood in tube in tray in rack is not addressed here.
     *
     * Direct container of specimen (tube/slide, etc.)
     */
    container?: Specimen.SpecimenContainerComponent[];
    /**
     * The kind of material that forms the specimen.
     *
     * Kind of material that forms the specimen
     */
    type?: CodeableConcept;
    /**
     * Details concerning the specimen collection.
     *
     * Collection details
     */
    collection?: Specimen.SpecimenCollectionComponent;
    readonly resourceType: string;
    static revive(json: any): Specimen;
    toJSON(): any;
}
export declare namespace Specimen {
    enum SpecimenStatus {
        AVAILABLE,
        ENTEREDINERROR,
        NULL,
        UNAVAILABLE,
        UNSATISFACTORY
    }
    enum SpecimenCombined {
        NULL,
        GROUPED,
        POOLED
    }
    class SpecimenContainerComponent extends BackboneElement {
        /**
         * The quantity of specimen in the container; may be volume, dimensions, or other appropriate measurements, depending on the specimen type.
         *
         * Quantity of specimen within container
         */
        specimenQuantity?: Quantity;
        /**
         * The location of the container holding the specimen.
         *
         * Where the container is
         */
        location?: Location | Reference;
        /**
         * The device resource for the the container holding the specimen. If the container is in a holder then the referenced device will point to a parent device.
         *
         * Device resource for the container
         */
        device: Device | Reference;
        static revive(json: any): SpecimenContainerComponent;
        toJSON(): any;
    }
    class SpecimenProcessingComponent extends BackboneElement {
        /**
         * Material used in the processing step.
         *
         * Material used in the processing step
         */
        additive?: Substance[] | Reference[];
        /**
         * Textual description of procedure.
         *
         * Textual description of procedure
         */
        description?: string;
        /**
         * A record of the time or period when the specimen processing occurred.  For example the time of sample fixation or the period of time the sample was in formalin.
         *
         * Date and time of specimen processing
         */
        time?: Date | Period;
        /**
         * A coded value specifying the method used to process the specimen.
         *
         * Indicates the treatment step  applied to the specimen
         */
        method?: CodeableConcept;
        static revive(json: any): SpecimenProcessingComponent;
        toJSON(): any;
    }
    class SpecimenCollectionComponent extends BackboneElement {
        /**
         * A coded value specifying the technique that is used to perform the procedure.
         *
         * Technique used to perform collection
         */
        method?: CodeableConcept;
        /**
         * Abstinence or reduction from some or all food, drink, or both, for a period of time prior to sample collection.
         *
         * Whether or how long patient abstained from food and/or drink
         */
        fastingStatus?: CodeableConcept | Duration;
        /**
         * The span of time over which the collection of a specimen occurred.
         *
         * How long it took to collect specimen
         */
        duration?: Duration;
        /**
         * Anatomical location from which the specimen was collected (if subject is a patient). This is the target site.  This element is not used for environmental specimens.
         *
         * Anatomical collection site
         */
        bodySite?: CodeableReference;
        /**
         * The quantity of specimen collected; for instance the volume of a blood sample, or the physical measurement of an anatomic pathology sample.
         *
         * The quantity of specimen collected
         */
        quantity?: Quantity;
        /**
         * A coded value specifying the technique that is used to perform the procedure.
         *
         * Device used to perform collection
         */
        device?: CodeableReference;
        /**
         * Person who collected the specimen.
         *
         * Who collected the specimen
         */
        collector?: Practitioner | PractitionerRole | Patient | RelatedPerson | Reference;
        /**
         * Time when specimen was collected from subject - the physiologically relevant time.
         *
         * Collection time
         */
        collected?: Date | Period;
        /**
         * The procedure event during which the specimen was collected (e.g. the surgery leading to the collection of a pathology sample).
         *
         * The procedure that collects the specimen
         */
        procedure?: Procedure | Reference;
        static revive(json: any): SpecimenCollectionComponent;
        toJSON(): any;
    }
    class SpecimenFeatureComponent extends BackboneElement {
        /**
         * The landmark or feature being highlighted.
         *
         * Highlighted feature
         */
        type: CodeableConcept;
        /**
         * Description of the feature of the specimen.
         *
         * Information about the feature
         */
        description: string;
        static revive(json: any): SpecimenFeatureComponent;
        toJSON(): any;
    }
}
