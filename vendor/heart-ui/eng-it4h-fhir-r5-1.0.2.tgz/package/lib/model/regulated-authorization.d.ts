import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { ActivityDefinition } from '../model/activity-definition';
import { BiologicallyDerivedProduct } from '../model/biologically-derived-product';
import { DeviceDefinition } from '../model/device-definition';
import { DocumentReference } from '../model/document-reference';
import { DomainResource } from '../model/domain-resource';
import { Ingredient } from '../model/ingredient';
import { Location } from '../model/location';
import { ManufacturedItemDefinition } from '../model/manufactured-item-definition';
import { MedicinalProductDefinition } from '../model/medicinal-product-definition';
import { NutritionProduct } from '../model/nutrition-product';
import { ObservationDefinition } from '../model/observation-definition';
import { Organization } from '../model/organization';
import { PackagedProductDefinition } from '../model/packaged-product-definition';
import { PlanDefinition } from '../model/plan-definition';
import { Practitioner } from '../model/practitioner';
import { ResearchStudy } from '../model/research-study';
import { SubstanceDefinition } from '../model/substance-definition';
/**
 * HAPI/FHIR <b>RegulatedAuthorization</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/RegulatedAuthorization">http://hl7.org/fhir/StructureDefinition/RegulatedAuthorization</a>
 * </p>
 *
 */
export declare class RegulatedAuthorization extends DomainResource {
    /**
     * The time period in which the regulatory approval, clearance or licencing is in effect. As an example, a Marketing Authorization includes the date of authorization and/or an expiration date.
     *
     * The time period in which the regulatory approval etc. is in effect, e.g. a Marketing Authorization includes the date of authorization and/or expiration date
     */
    validityPeriod?: Period;
    /**
     * The status that is authorised e.g. approved. Intermediate states and actions can be tracked with cases and applications.
     *
     * The status that is authorised e.g. approved. Intermediate states can be tracked with cases and applications
     */
    status?: CodeableConcept;
    /**
     * The territory (e.g., country, jurisdiction etc.) in which the authorization has been granted.
     *
     * The territory in which the authorization has been granted
     */
    region?: CodeableConcept[];
    /**
     * Condition for which the use of the regulated product applies.
     *
     * Condition for which the use of the regulated product applies
     */
    indication?: CodeableReference[];
    /**
     * The intended use of the product, e.g. prevention, treatment, diagnosis.
     *
     * The intended use of the product, e.g. prevention, treatment
     */
    intendedUse?: CodeableConcept;
    /**
     * The regulatory authority or authorizing body granting the authorization. For example, European Medicines Agency (EMA), Food and Drug Administration (FDA), Health Canada (HC), etc.
     *
     * The regulatory authority or authorizing body granting the authorization
     */
    regulator?: Organization | Reference;
    /**
     * The product type, treatment, facility or activity that is being authorized.
     *
     * The product type, treatment, facility or activity that is being authorized
     */
    subject?: MedicinalProductDefinition[] | BiologicallyDerivedProduct[] | NutritionProduct[] | PackagedProductDefinition[] | ManufacturedItemDefinition[] | Ingredient[] | SubstanceDefinition[] | DeviceDefinition[] | ResearchStudy[] | ActivityDefinition[] | PlanDefinition[] | ObservationDefinition[] | Practitioner[] | Organization[] | Location[] | Reference[];
    /**
     * Additional information or supporting documentation about the authorization.
     *
     * Additional information or supporting documentation about the authorization
     */
    attachedDocument?: DocumentReference[] | Reference[];
    /**
     * Business identifier for the authorization, typically assigned by the authorizing body.
     *
     * Business identifier for the authorization, typically assigned by the authorizing body
     */
    identifier?: Identifier[];
    /**
     * The date at which the current status was assigned.
     *
     * The date at which the current status was assigned
     */
    statusDate?: Date;
    /**
     * The case or regulatory procedure for granting or amending a regulated authorization. An authorization is granted in response to submissions/applications by those seeking authorization. A case is the administrative process that deals with the application(s) that relate to this and assesses them. Note: This area is subject to ongoing review and the workgroup is seeking implementer feedback on its use (see link at bottom of page).
     *
     * The case or regulatory procedure for granting or amending a regulated authorization. Note: This area is subject to ongoing review and the workgroup is seeking implementer feedback on its use (see link at bottom of page)
     */
    case?: RegulatedAuthorization.RegulatedAuthorizationCaseComponent;
    /**
     * Overall type of this authorization, for example drug marketing approval, orphan drug designation.
     *
     * Overall type of this authorization, for example drug marketing approval, orphan drug designation
     */
    type?: CodeableConcept;
    /**
     * The legal or regulatory framework against which this authorization is granted, or other reasons for it.
     *
     * The legal/regulatory framework or reasons under which this authorization is granted
     */
    basis?: CodeableConcept[];
    /**
     * The organization that has been granted this authorization, by some authoritative body (the 'regulator').
     *
     * The organization that has been granted this authorization, by the regulator
     */
    holder?: Organization | Reference;
    /**
     * General textual supporting information.
     *
     * General textual supporting information
     */
    description?: string;
    readonly resourceType: string;
    static revive(json: any): RegulatedAuthorization;
    toJSON(): any;
}
export declare namespace RegulatedAuthorization {
    class RegulatedAuthorizationCaseComponent extends BackboneElement {
        /**
         * The defining type of case.
         *
         * The defining type of case
         */
        type?: CodeableConcept;
        /**
         * The status associated with the case.
         *
         * The status associated with the case
         */
        status?: CodeableConcept;
        /**
         * A regulatory submission from an organization to a regulator, as part of an assessing case. Multiple applications may occur over time, with more or different information to support or modify the submission or the authorization. The applications can be considered as steps within the longer running case or procedure for this authorization process.
         *
         * Applications submitted to obtain a regulated authorization. Steps within the longer running case or procedure
         */
        application?: RegulatedAuthorization.RegulatedAuthorizationCaseComponent[];
        /**
         * Identifier by which this case can be referenced.
         *
         * Identifier by which this case can be referenced
         */
        identifier?: Identifier;
        /**
         * Relevant date for this case.
         *
         * Relevant date for this case
         */
        date?: Period | Date;
        static revive(json: any): RegulatedAuthorizationCaseComponent;
        toJSON(): any;
    }
}
