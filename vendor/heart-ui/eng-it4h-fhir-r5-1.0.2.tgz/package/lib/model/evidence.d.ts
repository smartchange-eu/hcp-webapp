import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { RelatedArtifact } from '../datatype/related-artifact';
import { UsageContext } from '../datatype/usage-context';
import { Citation } from '../model/citation';
import { EvidenceVariable } from '../model/evidence-variable';
import { Group } from '../model/group';
import { MetadataResource } from '../model/metadata-resource';
/**
 * HAPI/FHIR <b>Evidence</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Evidence">http://hl7.org/fhir/StructureDefinition/Evidence</a>
 * </p>
 *
 */
export declare class Evidence extends MetadataResource {
    /**
     * A Boolean value to indicate that this resource is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A free text natural language description of the evidence from a consumer's perspective.
     *
     * Description of the particular summary
     */
    description?: string;
    /**
     * A short, descriptive, user-friendly title for the summary.
     *
     * Name for this summary (human friendly)
     */
    title?: string;
    /**
     * The date on which the resource content was approved by the publisher. Approval happens once when the content is officially approved for usage.
     *
     * When the summary was approved by publisher
     */
    approvalDate?: Date;
    /**
     * A copyright statement relating to the Evidence and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the Evidence.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * Footnotes and/or explanatory notes.
     *
     * Footnotes and/or explanatory notes
     */
    note?: Annotation[];
    /**
     * The date  (and optionally time) when the summary was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the summary changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * The design of the study that produced this evidence. The design is described with any number of study design characteristics.
     *
     * The design of the study that produced this evidence
     */
    studyDesign?: CodeableConcept[];
    /**
     * Explanation of why this Evidence is needed and why it has been designed as it has.
     *
     * Why this Evidence is defined
     */
    purpose?: string;
    /**
     * Citation Resource or display of suggested citation for this evidence.
     *
     * Citation for this evidence
     */
    citeAs?: Citation | string | Reference;
    /**
     * Declarative description of the Evidence.
     *
     * Declarative description of the Evidence
     */
    assertion?: string;
    /**
     * An individiual, organization, or device responsible for officially endorsing the content for use in some setting.
     *
     * Who endorsed the content
     */
    endorser?: ContactDetail[];
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * An individiual, organization, or device primarily responsible for review of some aspect of the content.
     *
     * Who reviewed the content
     */
    reviewer?: ContactDetail[];
    /**
     * Assessment of certainty, confidence in the estimates, or quality of the evidence.
     *
     * Certainty or quality of the evidence
     */
    certainty?: Evidence.EvidenceCertaintyComponent[];
    /**
     * Evidence variable such as population, exposure, or outcome.
     *
     * Evidence variable such as population, exposure, or outcome
     */
    variableDefinition: Evidence.EvidenceVariableDefinitionComponent[];
    /**
     * An absolute URI that is used to identify this evidence when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this summary is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the summary is stored on different servers.
     *
     * Canonical identifier for this evidence, represented as a globally unique URI
     */
    url?: string;
    /**
     * The identifier that is used to identify this version of the summary when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the summary author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of this summary
     */
    version?: string;
    /**
     * Link or citation to artifact associated with the summary.
     *
     * Link or citation to artifact associated with the summary
     */
    relatedArtifact?: RelatedArtifact[];
    /**
     * Values and parameters for a single statistic.
     *
     * Values and parameters for a single statistic
     */
    statistic?: Evidence.EvidenceStatisticComponent[];
    /**
     * A formal identifier that is used to identify this summary when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the summary
     */
    identifier?: Identifier[];
    /**
     * An individiual, organization, or device primarily responsible for internal coherence of the content.
     *
     * Who edited the content
     */
    editor?: ContactDetail[];
    /**
     * An individiual, organization, or device primarily involved in the creation and maintenance of the content.
     *
     * Who authored the content
     */
    author?: ContactDetail[];
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the evidence.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * A natural language name identifying the evidence. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this summary (machine friendly)
     */
    name?: string;
    /**
     * The status of this summary. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate evidence instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * The date on which the resource content was last reviewed. Review happens periodically after approval but does not change the original approval date.
     *
     * When the summary was last reviewed by the publisher
     */
    lastReviewDate?: Date;
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * The method to combine studies.
     *
     * The method to combine studies
     */
    synthesisType?: CodeableConcept;
    readonly resourceType: string;
    static revive(json: any): Evidence;
    toJSON(): any;
}
export declare namespace Evidence {
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class EvidenceCertaintyComponent extends BackboneElement {
        /**
         * Footnotes and/or explanatory notes.
         *
         * Footnotes and/or explanatory notes
         */
        note?: Annotation[];
        /**
         * A domain or subdomain of certainty.
         *
         * A domain or subdomain of certainty
         */
        subcomponent?: Evidence.EvidenceCertaintyComponent[];
        /**
         * Individual or group who did the rating.
         *
         * Individual or group who did the rating
         */
        rater?: string;
        /**
         * Assessment or judgement of the aspect.
         *
         * Assessment or judgement of the aspect
         */
        rating?: CodeableConcept;
        /**
         * Textual description of certainty.
         *
         * Textual description of certainty
         */
        description?: string;
        /**
         * Aspect of certainty being rated.
         *
         * Aspect of certainty being rated
         */
        type?: CodeableConcept;
        static revive(json: any): EvidenceCertaintyComponent;
        toJSON(): any;
    }
    class EvidenceStatisticModelCharacteristicVariableComponent extends BackboneElement {
        /**
         * Description of the variable.
         *
         * Description of the variable
         */
        variableDefinition: Group | EvidenceVariable | Reference;
        /**
         * How the variable is classified for use in adjusted analysis.
         *
         * continuous | dichotomous | ordinal | polychotomous
         */
        handling?: string;
        /**
         * Discrete value for grouping of ordinal or polychotomous variables.
         *
         * Discrete value for grouping of ordinal or polychotomous variables
         */
        valueQuantity?: Quantity[];
        /**
         * Description for grouping of ordinal or polychotomous variables.
         *
         * Description for grouping of ordinal or polychotomous variables
         */
        valueCategory?: CodeableConcept[];
        /**
         * Range of values for grouping of ordinal or polychotomous variables.
         *
         * Range of values for grouping of ordinal or polychotomous variables
         */
        valueRange?: Range[];
        static revive(json: any): EvidenceStatisticModelCharacteristicVariableComponent;
        toJSON(): any;
    }
    class EvidenceStatisticModelCharacteristicComponent extends BackboneElement {
        /**
         * A variable adjusted for in the adjusted analysis.
         *
         * A variable adjusted for in the adjusted analysis
         */
        variable?: Evidence.EvidenceStatisticModelCharacteristicVariableComponent[];
        /**
         * An attribute of the statistic used as a model characteristic.
         *
         * An attribute of the statistic used as a model characteristic
         */
        attributeEstimate?: Evidence.EvidenceStatisticAttributeEstimateComponent[];
        /**
         * Further specification of the quantified value of the component of the method to generate the statistic.
         *
         * Numerical value to complete model specification
         */
        value?: Quantity;
        /**
         * Description of a component of the method to generate the statistic.
         *
         * Model specification
         */
        code: CodeableConcept;
        static revive(json: any): EvidenceStatisticModelCharacteristicComponent;
        toJSON(): any;
    }
    class EvidenceStatisticAttributeEstimateComponent extends BackboneElement {
        /**
         * A nested attribute estimate; which is the attribute estimate of an attribute estimate.
         *
         * A nested attribute estimate; which is the attribute estimate of an attribute estimate
         */
        attributeEstimate?: Evidence.EvidenceStatisticAttributeEstimateComponent[];
        /**
         * The type of attribute estimate, e.g., confidence interval or p value.
         *
         * The type of attribute estimate, e.g., confidence interval or p value
         */
        type?: CodeableConcept;
        /**
         * Human-readable summary of the estimate.
         *
         * Textual description of the attribute estimate
         */
        description?: string;
        /**
         * Lower bound of confidence interval.
         *
         * Lower and upper bound values of the attribute estimate
         */
        range?: Range;
        /**
         * Use 95 for a 95% confidence interval.
         *
         * Level of confidence interval, e.g., 0.95 for 95% confidence interval
         */
        level?: number;
        /**
         * The singular quantity of the attribute estimate, for attribute estimates represented as single values; also used to report unit of measure.
         *
         * The singular quantity of the attribute estimate, for attribute estimates represented as single values; also used to report unit of measure
         */
        quantity?: Quantity;
        /**
         * Footnote or explanatory note about the estimate.
         *
         * Footnote or explanatory note about the estimate
         */
        note?: Annotation[];
        static revive(json: any): EvidenceStatisticAttributeEstimateComponent;
        toJSON(): any;
    }
    class EvidenceStatisticSampleSizeComponent extends BackboneElement {
        /**
         * Footnote or explanatory note about the sample size.
         *
         * Footnote or explanatory note about the sample size
         */
        note?: Annotation[];
        /**
         * A human-readable string to clarify or explain concepts about the sample size.
         *
         * Cumulative number of participants
         */
        numberOfParticipants?: number;
        /**
         * Number of participants with known results for measured variables.
         *
         * Number of participants with known results for measured variables
         */
        knownDataCount?: number;
        /**
         * Human-readable summary of population sample size.
         *
         * Textual description of sample size for statistic
         */
        description?: string;
        /**
         * Number of participants in the population.
         *
         * Number of contributing studies
         */
        numberOfStudies?: number;
        static revive(json: any): EvidenceStatisticSampleSizeComponent;
        toJSON(): any;
    }
    class EvidenceStatisticComponent extends BackboneElement {
        /**
         * Statistic value.
         *
         * Statistic value
         */
        quantity?: Quantity;
        /**
         * Footnotes and/or explanatory notes.
         *
         * Footnotes and/or explanatory notes
         */
        note?: Annotation[];
        /**
         * Type of statistic, e.g., relative risk.
         *
         * Type of statistic, e.g., relative risk
         */
        statisticType?: CodeableConcept;
        /**
         * A component of the method to generate the statistic.
         *
         * An aspect of the statistical model
         */
        modelCharacteristic?: Evidence.EvidenceStatisticModelCharacteristicComponent[];
        /**
         * The number of participants affected where the unit of analysis is the same as sampleSize.knownDataCount and sampleSize.numberOfParticipants.
         *
         * The number of participants affected
         */
        numberAffected?: number;
        /**
         * A description of the content value of the statistic.
         *
         * Description of content
         */
        description?: string;
        /**
         * The number of events associated with the statistic, where the unit of analysis is different from numberAffected, sampleSize.knownDataCount and sampleSize.numberOfParticipants.
         *
         * The number of events associated with the statistic
         */
        numberOfEvents?: number;
        /**
         * A statistical attribute of the statistic such as a measure of heterogeneity.
         *
         * An attribute of the Statistic
         */
        attributeEstimate?: Evidence.EvidenceStatisticAttributeEstimateComponent[];
        /**
         * When the measured variable is handled categorically, the category element is used to define which category the statistic is reporting.
         *
         * Associated category for categorical variable
         */
        category?: CodeableConcept;
        /**
         * Number of samples in the statistic.
         *
         * Number of samples in the statistic
         */
        sampleSize?: Evidence.EvidenceStatisticSampleSizeComponent;
        static revive(json: any): EvidenceStatisticComponent;
        toJSON(): any;
    }
    class EvidenceVariableDefinitionComponent extends BackboneElement {
        /**
         * Footnotes and/or explanatory notes.
         *
         * Footnotes and/or explanatory notes
         */
        note?: Annotation[];
        /**
         * Indication of quality of match between intended variable to actual variable.
         *
         * low | moderate | high | exact
         */
        directnessMatch?: CodeableConcept;
        /**
         * population | subpopulation | exposure | referenceExposure | measuredVariable | confounder.
         *
         * population | subpopulation | exposure | referenceExposure | measuredVariable | confounder
         */
        variableRole: CodeableConcept;
        /**
         * Definition of the intended variable related to the Evidence.
         *
         * Definition of the intended variable related to the Evidence
         */
        intended?: Group | EvidenceVariable | Reference;
        /**
         * A text description or summary of the variable.
         *
         * A text description or summary of the variable
         */
        description?: string;
        /**
         * Definition of the actual variable related to the statistic(s).
         *
         * Definition of the actual variable related to the statistic(s)
         */
        observed?: Group | EvidenceVariable | Reference;
        static revive(json: any): EvidenceVariableDefinitionComponent;
        toJSON(): any;
    }
}
