import { BackboneElement } from '../datatype/backbone-element';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { DomainResource } from '../model/domain-resource';
/**
 * HAPI/FHIR <b>SubstancePolymer</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/SubstancePolymer">http://hl7.org/fhir/StructureDefinition/SubstancePolymer</a>
 * </p>
 *
 */
export declare class SubstancePolymer extends DomainResource {
    /**
     * A business idenfier for this polymer, but typically this is handled by a SubstanceDefinition identifier.
     *
     * A business idenfier for this polymer, but typically this is handled by a SubstanceDefinition identifier
     */
    identifier?: Identifier;
    /**
     * Todo.
     *
     * Todo
     */
    monomerSet?: SubstancePolymer.SubstancePolymerMonomerSetComponent[];
    /**
     * Descrtibes the copolymer sequence type (polymer connectivity).
     *
     * Descrtibes the copolymer sequence type (polymer connectivity)
     */
    copolymerConnectivity?: CodeableConcept[];
    /**
     * Specifies and quantifies the repeated units and their configuration.
     *
     * Specifies and quantifies the repeated units and their configuration
     */
    repeat?: SubstancePolymer.SubstancePolymerRepeatComponent[];
    /**
     * Polymer geometry, e.g. linear, branched, cross-linked, network or dendritic.
     *
     * Polymer geometry, e.g. linear, branched, cross-linked, network or dendritic
     */
    geometry?: CodeableConcept;
    /**
     * Overall type of the polymer.
     *
     * Overall type of the polymer
     */
    class?: CodeableConcept;
    /**
     * Todo - this is intended to connect to a repeating full modification structure, also used by Protein and Nucleic Acid . String is just a placeholder.
     *
     * Todo - this is intended to connect to a repeating full modification structure, also used by Protein and Nucleic Acid . String is just a placeholder
     */
    modification?: string;
    readonly resourceType: string;
    static revive(json: any): SubstancePolymer;
    toJSON(): any;
}
export declare namespace SubstancePolymer {
    class SubstancePolymerRepeatRepeatUnitStructuralRepresentationComponent extends BackboneElement {
        /**
         * The format of the representation e.g. InChI, SMILES, MOLFILE, CDX, SDF, PDB, mmCIF.
         *
         * The format of the representation e.g. InChI, SMILES, MOLFILE, CDX, SDF, PDB, mmCIF
         */
        format?: CodeableConcept;
        /**
         * The structural representation as text string in a standard format e.g. InChI, SMILES, MOLFILE, CDX, SDF, PDB, mmCIF.
         *
         * The structural representation as text string in a standard format e.g. InChI, SMILES, MOLFILE, CDX, SDF, PDB, mmCIF
         */
        representation?: string;
        /**
         * The type of structure (e.g. Full, Partial, Representative).
         *
         * The type of structure (e.g. Full, Partial, Representative)
         */
        type?: CodeableConcept;
        /**
         * An attached file with the structural representation.
         *
         * An attached file with the structural representation
         */
        attachment?: Attachment;
        static revive(json: any): SubstancePolymerRepeatRepeatUnitStructuralRepresentationComponent;
        toJSON(): any;
    }
    class SubstancePolymerRepeatRepeatUnitDegreeOfPolymerisationComponent extends BackboneElement {
        /**
         * The type of the degree of polymerisation shall be described, e.g. SRU/Polymer Ratio.
         *
         * The type of the degree of polymerisation shall be described, e.g. SRU/Polymer Ratio
         */
        type?: CodeableConcept;
        /**
         * A low expected limit of the amount.
         *
         * A low expected limit of the amount
         */
        low?: number;
        /**
         * An average amount of polymerisation.
         *
         * An average amount of polymerisation
         */
        average?: number;
        /**
         * A high expected limit of the amount.
         *
         * A high expected limit of the amount
         */
        high?: number;
        static revive(json: any): SubstancePolymerRepeatRepeatUnitDegreeOfPolymerisationComponent;
        toJSON(): any;
    }
    class SubstancePolymerRepeatRepeatUnitComponent extends BackboneElement {
        /**
         * A graphical structure for this SRU.
         *
         * A graphical structure for this SRU
         */
        structuralRepresentation?: SubstancePolymer.SubstancePolymerRepeatRepeatUnitStructuralRepresentationComponent[];
        /**
         * Structural repeat units are essential elements for defining polymers.
         *
         * Structural repeat units are essential elements for defining polymers
         */
        unit?: string;
        /**
         * The orientation of the polymerisation, e.g. head-tail, head-head, random.
         *
         * The orientation of the polymerisation, e.g. head-tail, head-head, random
         */
        orientation?: CodeableConcept;
        /**
         * Number of repeats of this unit.
         *
         * Number of repeats of this unit
         */
        amount?: number;
        /**
         * Applies to homopolymer and block co-polymers where the degree of polymerisation within a block can be described.
         *
         * Applies to homopolymer and block co-polymers where the degree of polymerisation within a block can be described
         */
        degreeOfPolymerisation?: SubstancePolymer.SubstancePolymerRepeatRepeatUnitDegreeOfPolymerisationComponent[];
        static revive(json: any): SubstancePolymerRepeatRepeatUnitComponent;
        toJSON(): any;
    }
    class SubstancePolymerRepeatComponent extends BackboneElement {
        /**
         * How the quantitative amount of Structural Repeat Units is captured (e.g. Exact, Numeric, Average).
         *
         * How the quantitative amount of Structural Repeat Units is captured (e.g. Exact, Numeric, Average)
         */
        repeatUnitAmountType?: CodeableConcept;
        /**
         * A representation of an (average) molecular formula from a polymer.
         *
         * A representation of an (average) molecular formula from a polymer
         */
        averageMolecularFormula?: string;
        /**
         * An SRU - Structural Repeat Unit.
         *
         * An SRU - Structural Repeat Unit
         */
        repeatUnit?: SubstancePolymer.SubstancePolymerRepeatRepeatUnitComponent[];
        static revive(json: any): SubstancePolymerRepeatComponent;
        toJSON(): any;
    }
    class SubstancePolymerMonomerSetStartingMaterialComponent extends BackboneElement {
        /**
         * A percentage.
         *
         * A percentage
         */
        amount?: Quantity;
        /**
         * The type of substance for this starting material.
         *
         * The type of substance for this starting material
         */
        code?: CodeableConcept;
        /**
         * Substance high level category, e.g. chemical substance.
         *
         * Substance high level category, e.g. chemical substance
         */
        category?: CodeableConcept;
        /**
         * Used to specify whether the attribute described is a defining element for the unique identification of the polymer.
         *
         * Used to specify whether the attribute described is a defining element for the unique identification of the polymer
         */
        isDefining?: boolean;
        static revive(json: any): SubstancePolymerMonomerSetStartingMaterialComponent;
        toJSON(): any;
    }
    class SubstancePolymerMonomerSetComponent extends BackboneElement {
        /**
         * Captures the type of ratio to the entire polymer, e.g. Monomer/Polymer ratio, SRU/Polymer Ratio.
         *
         * Captures the type of ratio to the entire polymer, e.g. Monomer/Polymer ratio, SRU/Polymer Ratio
         */
        ratioType?: CodeableConcept;
        /**
         * The starting materials - monomer(s) used in the synthesis of the polymer.
         *
         * The starting materials - monomer(s) used in the synthesis of the polymer
         */
        startingMaterial?: SubstancePolymer.SubstancePolymerMonomerSetStartingMaterialComponent[];
        static revive(json: any): SubstancePolymerMonomerSetComponent;
        toJSON(): any;
    }
}
