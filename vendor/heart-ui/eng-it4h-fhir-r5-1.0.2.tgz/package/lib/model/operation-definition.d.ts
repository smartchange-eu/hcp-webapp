import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { UsageContext } from '../datatype/usage-context';
import { CanonicalResource } from '../model/canonical-resource';
/**
 * HAPI/FHIR <b>OperationDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/OperationDefinition">http://hl7.org/fhir/StructureDefinition/OperationDefinition</a>
 * </p>
 *
 */
export declare class OperationDefinition extends CanonicalResource {
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * The parameters for the operation/query.
     *
     * Parameters for the operation/query
     */
    parameter?: OperationDefinition.OperationDefinitionParameterComponent[];
    /**
     * A copyright statement relating to the operation definition and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the operation definition.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * The label that is recommended to be used in the URL for this operation. In some cases, servers may need to use a different CapabilityStatement operation.name to differentiate between multiple SearchParameters that happen to have the same code.
     *
     * Recommended name for operation in search url
     */
    code: string;
    /**
     * Indicates whether this operation can be invoked on a particular instance of one of the given types.
     *
     * Invoke on an instance?
     */
    instance: boolean;
    /**
     * The date  (and optionally time) when the operation definition was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the operation definition changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * A legal or geographic region in which the operation definition is intended to be used.
     *
     * Intended jurisdiction for operation definition (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * Explanation of why this operation definition is needed and why it has been designed as it has.
     *
     * Why this operation definition is defined
     */
    purpose?: string;
    /**
     * A Boolean value to indicate that this operation definition is authored for testing purposes (or education/evaluation/marketing) and is not intended for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A free text natural language description of the operation definition from a consumer's perspective.
     *
     * Natural language description of the operation definition
     */
    description?: string;
    /**
     * A short, descriptive, user-friendly title for the operation definition.
     *
     * Name for this operation definition (human friendly)
     */
    title?: string;
    /**
     * Indicates whether this operation or named query can be invoked at the resource type level for any given resource type level (e.g. without needing to choose a specific resource id for the context).
     *
     * Invoke at the type level?
     */
    type: boolean;
    /**
     * Indicates whether this operation or named query can be invoked at the system level (e.g. without needing to choose a resource type for the context).
     *
     * Invoke at the system level?
     */
    system: boolean;
    /**
     * Additional validation information for the out parameters - a single profile that covers all the parameters. The profile is a constraint on the parameters resource.
     *
     * Validation information for out parameters
     */
    outputProfile?: string;
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * Additional information about how to use this operation or named query.
     *
     * Additional information about use
     */
    comment?: string;
    /**
     * A natural language name identifying the operation definition. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this operation definition (computer friendly)
     */
    name: string;
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the operation definition.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * The current state of this operation definition.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * Indicates that this operation definition is a constraining profile on the base.
     *
     * Marks this as a profile of the base
     */
    base?: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate operation definition.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * A formal identifier that is used to identify this implementation guide when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the implementation guide (business identifier)
     */
    identifier?: Identifier[];
    /**
     * Whether this is an operation or a named query.
     *
     * operation | query
     */
    kind: string;
    /**
     * Additional validation information for the in parameters - a single profile that covers all the parameters. The profile is a constraint on the parameters resource as a whole.
     *
     * Validation information for in parameters
     */
    inputProfile?: string;
    /**
     * The types on which this operation can be executed.
     *
     * Types this operation applies to
     */
    resource?: string[];
    /**
     * An absolute URI that is used to identify this operation definition when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this operation definition is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the operation definition is stored on different servers.
     *
     * Canonical identifier for this operation definition, represented as an absolute URI (globally unique)
     */
    url?: string;
    /**
     * Defines an appropriate combination of parameters to use when invoking this operation, to help code generators when generating overloaded parameter sets for this operation.
     *
     * Define overloaded variants for when  generating code
     */
    overload?: OperationDefinition.OperationDefinitionOverloadComponent[];
    /**
     * The identifier that is used to identify this version of the operation definition when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the operation definition author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the operation definition
     */
    version?: string;
    /**
     * Whether the operation affects state. Side effects such as producing audit trail entries do not count as 'affecting  state'.
     *
     * Whether content is changed by the operation
     */
    affectsState?: boolean;
    readonly resourceType: string;
    static revive(json: any): OperationDefinition;
    toJSON(): any;
}
export declare namespace OperationDefinition {
    enum OperationParameterScope {
        SYSTEM,
        NULL,
        INSTANCE,
        TYPE
    }
    enum OperationKind {
        NULL,
        OPERATION,
        QUERY
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class OperationDefinitionOverloadComponent extends BackboneElement {
        /**
         * Name of parameter to include in overload.
         *
         * Name of parameter to include in overload
         */
        parameterName?: string[];
        /**
         * Comments to go on overload.
         *
         * Comments to go on overload
         */
        comment?: string;
        static revive(json: any): OperationDefinitionOverloadComponent;
        toJSON(): any;
    }
    class OperationDefinitionParameterReferencedFromComponent extends BackboneElement {
        /**
         * The id of the element in the referencing resource that is expected to resolve to this resource.
         *
         * Element id of reference
         */
        sourceId?: string;
        /**
         * The name of the parameter or dot-separated path of parameter names pointing to the resource parameter that is expected to contain a reference to this resource.
         *
         * Referencing parameter
         */
        source: string;
        static revive(json: any): OperationDefinitionParameterReferencedFromComponent;
        toJSON(): any;
    }
    class OperationDefinitionParameterBindingComponent extends BackboneElement {
        /**
         * Points to the value set or external definition (e.g. implicit value set) that identifies the set of codes to be used.
         *
         * Source of value set
         */
        valueSet: string;
        /**
         * Indicates the degree of conformance expectations associated with this binding - that is, the degree to which the provided value set must be adhered to in the instances.
         *
         * required | extensible | preferred | example
         */
        strength: string;
        static revive(json: any): OperationDefinitionParameterBindingComponent;
        toJSON(): any;
    }
    class OperationDefinitionParameterComponent extends BackboneElement {
        /**
         * Used when the type is "Reference" or "canonical", and identifies a profile structure or implementation Guide that applies to the target of the reference this parameter refers to. If any profiles are specified, then the content must conform to at least one of them. The URL can be a local reference - to a contained StructureDefinition, or a reference to another StructureDefinition or Implementation Guide by a canonical URL. When an implementation guide is specified, the target resource SHALL conform to at least one profile defined in the implementation guide.
         *
         * If type is Reference | canonical, allowed targets. If type is 'Resource', then this constrains the allowed resource types
         */
        targetProfile?: string[];
        /**
         * The name of used to identify the parameter.
         *
         * Name in Parameters.parameter.name or in URL
         */
        name: string;
        /**
         * If present, indicates that the parameter applies when the operation is being invoked at the specified level.
         *
         * instance | type | system
         */
        scope?: string[];
        /**
         * Identifies other resource parameters within the operation invocation that are expected to resolve to this resource.
         *
         * References to this parameter
         */
        referencedFrom?: OperationDefinition.OperationDefinitionParameterReferencedFromComponent[];
        /**
         * The minimum number of times this parameter SHALL appear in the request or response.
         *
         * Minimum Cardinality
         */
        min: number;
        /**
         * The type for this parameter.
         *
         * What type this parameter has
         */
        type?: string;
        /**
         * Support for polymorphic types. If the parameter type is abstract, this element lists allowed sub-types for the parameter.
         *
         * Allowed sub-type this parameter can have (if type is abstract)
         */
        allowedType?: string[];
        /**
         * Binds to a value set if this parameter is coded (code, Coding, CodeableConcept).
         *
         * ValueSet details if this is coded
         */
        binding?: OperationDefinition.OperationDefinitionParameterBindingComponent;
        /**
         * The maximum number of times this element is permitted to appear in the request or response.
         *
         * Maximum Cardinality (a number or *)
         */
        max: string;
        /**
         * How the parameter is understood if/when it used as search parameter. This is only used if the parameter is a string.
         *
         * number | date | string | token | reference | composite | quantity | uri | special
         */
        searchType?: string;
        /**
         * Describes the meaning or use of this parameter.
         *
         * Description of meaning/use
         */
        documentation?: string;
        /**
         * The parts of a nested Parameter.
         *
         * Parts of a nested Parameter
         */
        part?: OperationDefinition.OperationDefinitionParameterComponent[];
        /**
         * Whether this is an input or an output parameter.
         *
         * in | out
         */
        use: string;
        static revive(json: any): OperationDefinitionParameterComponent;
        toJSON(): any;
    }
}
