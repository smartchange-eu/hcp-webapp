import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Account } from '../model/account';
import { CareTeam } from '../model/care-team';
import { DomainResource } from '../model/domain-resource';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { ServiceRequest } from '../model/service-request';
/**
 * HAPI/FHIR <b>EpisodeOfCare</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/EpisodeOfCare">http://hl7.org/fhir/StructureDefinition/EpisodeOfCare</a>
 * </p>
 *
 */
export declare class EpisodeOfCare extends DomainResource {
    /**
     * A classification of the type of episode of care; e.g. specialist referral, disease management, type of funded care.
     *
     * Type/class  - e.g. specialist referral, disease management
     */
    type?: CodeableConcept[];
    /**
     * The practitioner that is the care manager/care coordinator for this patient.
     *
     * Care manager/care coordinator for the patient
     */
    careManager?: Practitioner | PractitionerRole | Reference;
    /**
     * The list of medical conditions that were addressed during the episode of care.
     *
     * The list of medical conditions that were addressed during the episode of care
     */
    diagnosis?: EpisodeOfCare.DiagnosisComponent[];
    /**
     * The interval during which the managing organization assumes the defined responsibility.
     *
     * Interval during responsibility is assumed
     */
    period?: Period;
    /**
     * The EpisodeOfCare may be known by different identifiers for different contexts of use, such as when an external agency is tracking the Episode for funding purposes.
     *
     * Business Identifier(s) relevant for this EpisodeOfCare
     */
    identifier?: Identifier[];
    /**
     * The list of medical reasons that are expected to be addressed during the episode of care.
     *
     * The list of medical reasons that are expected to be addressed during the episode of care
     */
    reason?: EpisodeOfCare.ReasonComponent[];
    /**
     * The list of practitioners that may be facilitating this episode of care for specific purposes.
     *
     * Other practitioners facilitating this episode of care
     */
    careTeam?: CareTeam[] | Reference[];
    /**
     * The set of accounts that may be used for billing for this EpisodeOfCare.
     *
     * The set of accounts that may be used for billing for this EpisodeOfCare
     */
    account?: Account[] | Reference[];
    /**
     * planned | waitlist | active | onhold | finished | cancelled.
     *
     * planned | waitlist | active | onhold | finished | cancelled | entered-in-error
     */
    status: string;
    /**
     * The patient who is the focus of this episode of care.
     *
     * The patient who is the focus of this episode of care
     */
    patient: Patient | Reference;
    /**
     * The history of statuses that the EpisodeOfCare has been through (without requiring processing the history of the resource).
     *
     * Past list of status codes (the current status may be included to cover the start date of the status)
     */
    statusHistory?: EpisodeOfCare.EpisodeOfCareStatusHistoryComponent[];
    /**
     * The organization that has assumed the specific responsibilities for care coordination, care delivery, or other services for the specified duration.
     *
     * Organization that assumes responsibility for care coordination
     */
    managingOrganization?: Organization | Reference;
    /**
     * Referral Request(s) that are fulfilled by this EpisodeOfCare, incoming referrals.
     *
     * Originating Referral Request(s)
     */
    referralRequest?: ServiceRequest[] | Reference[];
    readonly resourceType: string;
    static revive(json: any): EpisodeOfCare;
    toJSON(): any;
}
export declare namespace EpisodeOfCare {
    enum EpisodeOfCareStatus {
        CANCELLED,
        ENTEREDINERROR,
        WAITLIST,
        NULL,
        ACTIVE,
        ONHOLD,
        FINISHED,
        PLANNED
    }
    class DiagnosisComponent extends BackboneElement {
        /**
         * Role that this diagnosis has within the episode of care (e.g. admission, billing, discharge …).
         *
         * Role that this diagnosis has within the episode of care (e.g. admission, billing, discharge …)
         */
        use?: CodeableConcept;
        /**
         * The medical condition that was addressed during the episode of care, expressed as a text, code or a reference to another resource.
         *
         * The medical condition that was addressed during the episode of care
         */
        condition?: CodeableReference[];
        static revive(json: any): DiagnosisComponent;
        toJSON(): any;
    }
    class ReasonComponent extends BackboneElement {
        /**
         * What the reason value should be used as e.g. Chief Complaint, Health Concern, Health Maintenance (including screening).
         *
         * What the reason value should be used for/as
         */
        use?: CodeableConcept;
        /**
         * The medical reason that is expected to be addressed during the episode of care, expressed as a text, code or a reference to another resource.
         *
         * Medical reason to be addressed
         */
        value?: CodeableReference[];
        static revive(json: any): ReasonComponent;
        toJSON(): any;
    }
    class EpisodeOfCareStatusHistoryComponent extends BackboneElement {
        /**
         * planned | waitlist | active | onhold | finished | cancelled.
         *
         * planned | waitlist | active | onhold | finished | cancelled | entered-in-error
         */
        status: string;
        /**
         * The period during this EpisodeOfCare that the specific status applied.
         *
         * Duration the EpisodeOfCare was in the specified status
         */
        period: Period;
        static revive(json: any): EpisodeOfCareStatusHistoryComponent;
        toJSON(): any;
    }
}
