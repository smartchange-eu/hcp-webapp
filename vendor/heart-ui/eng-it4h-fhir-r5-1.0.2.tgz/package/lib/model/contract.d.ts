import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Coding } from '../datatype/coding';
import { Identifier } from '../datatype/identifier';
import { Money } from '../datatype/money';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Signature } from '../datatype/signature';
import { Timing } from '../datatype/timing';
import { CareTeam } from '../model/care-team';
import { Composition } from '../model/composition';
import { Device } from '../model/device';
import { DocumentReference } from '../model/document-reference';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { EpisodeOfCare } from '../model/episode-of-care';
import { Group } from '../model/group';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Provenance } from '../model/provenance';
import { QuestionnaireResponse } from '../model/questionnaire-response';
import { RelatedPerson } from '../model/related-person';
import { Substance } from '../model/substance';
/**
 * HAPI/FHIR <b>Contract</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Contract">http://hl7.org/fhir/StructureDefinition/Contract</a>
 * </p>
 *
 */
export declare class Contract extends DomainResource {
    /**
     * The individual or organization that authored the Contract definition, derivative, or instance in any legal state.
     *
     * Source of Contract
     */
    author?: Patient | Practitioner | PractitionerRole | Organization | Reference;
    /**
     * Event resulting in discontinuation or termination of this Contract instance by one or more parties to the contract.
     *
     * Contract cessation cause
     */
    expirationType?: CodeableConcept;
    /**
     * Unique identifier for this Contract or a derivative that references a Source Contract.
     *
     * Contract number
     */
    identifier?: Identifier[];
    /**
     * Canonical identifier for this contract, represented as a URI (globally unique).
     *
     * Basal definition
     */
    url?: string;
    /**
     * Legally binding Contract: This is the signed and legally recognized representation of the Contract, which is considered the "source of truth" and which would be the basis for legal action related to enforcement of this Contract.
     *
     * Binding Contract
     */
    legallyBinding?: Attachment | Composition | DocumentReference | QuestionnaireResponse | Contract | Reference;
    /**
     * An edition identifier used for business purposes to label business significant variants.
     *
     * Business edition
     */
    version?: string;
    /**
     * The URL pointing to a FHIR-defined Contract Definition that is adhered to in whole or part by this Contract.
     *
     * Source Contract Definition
     */
    instantiatesCanonical?: Contract | Reference;
    /**
     * A formally or informally recognized grouping of people, principals, organizations, or jurisdictions formed for the purpose of achieving some form of collective action such as the promulgation, administration and enforcement of contracts and policies.
     *
     * Authority under which this Contract has standing
     */
    authority?: Organization[] | Reference[];
    /**
     * Recognized governance framework or system operating with a circumscribed scope in accordance with specified principles, policies, processes or procedures for managing rights, actions, or behaviors of parties or principals relative to resources.
     *
     * A sphere of control governed by an authoritative jurisdiction, organization, or person
     */
    domain?: Location[] | Reference[];
    /**
     * A more detailed or qualifying explanatory or alternate user-friendly title for this Contract definition, derivative, or instance in any legal state.
     *
     * Subordinate Friendly name
     */
    subtitle?: string;
    /**
     * Relevant time or time-period when this Contract is applicable.
     *
     * Effective time
     */
    applies?: Period;
    /**
     * Sites in which the contract is complied with,  exercised, or in force.
     *
     * Specific Location
     */
    site?: Location[] | Reference[];
    /**
     * The status of the resource instance.
     *
     * amended | appended | cancelled | disputed | entered-in-error | executable +
     */
    status?: string;
    /**
     * Legal states of the formation of a legal instrument, which is a formally executed written document that can be formally attributed to its author, records and formally expresses a legally enforceable act, process, or contractual duty, obligation, or right, and therefore evidences that act, process, or agreement.
     *
     * Negotiation status
     */
    legalState?: CodeableConcept;
    /**
     * Sub-category for the Contract that distinguishes the kinds of systems that would be interested in the Contract within the context of the Contract's scope.
     *
     * Subtype within the context of type
     */
    subType?: CodeableConcept[];
    /**
     * Narrows the range of legal concerns to focus on the achievement of specific contractual objectives.
     *
     * Focus of contract interest
     */
    topic?: CodeableConcept | Reference;
    /**
     * A natural language name identifying this Contract definition, derivative, or instance in any legal state. Provides additional information about its content. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Computer friendly designation
     */
    name?: string;
    /**
     * The target entity impacted by or of interest to parties to the agreement.
     *
     * Contract Target Entity
     */
    subject?: Reference[];
    /**
     * The "patient friendly language" versionof the Contract in whole or in parts. "Patient friendly language" means the representation of the Contract and Contract Provisions in a manner that is readily accessible and understandable by a layperson in accordance with best practices for communication styles that ensure that those agreeing to or signing the Contract understand the roles, actions, obligations, responsibilities, and implication of the agreement.
     *
     * Contract Friendly Language
     */
    friendly?: Contract.FriendlyLanguageComponent[];
    /**
     * The URL pointing to an externally maintained definition that is adhered to in whole or in part by this Contract.
     *
     * External Contract Definition
     */
    instantiatesUri?: string;
    /**
     * Links to Provenance records for past versions of this Contract definition, derivative, or instance, which identify key state transitions or updates that are likely to be relevant to a user looking at the current version of the Contract.  The Provenance.entity indicates the target that was changed in the update (see [Provenance.entity](provenance-definitions.html#Provenance.entity)).
     *
     * Key event in Contract History
     */
    relevantHistory?: Provenance[] | Reference[];
    /**
     * A short, descriptive, user-friendly title for this Contract definition, derivative, or instance in any legal state.
     *
     * Human Friendly name
     */
    title?: string;
    /**
     * A high-level category for the legal instrument, whether constructed as a Contract definition, derivative, or instance in any legal state.  Provides additional information about its content within the context of the Contract's scope to distinguish the kinds of systems that would be interested in the contract.
     *
     * Legal instrument category
     */
    type?: CodeableConcept;
    /**
     * List of Computable Policy Rule Language Representations of this Contract.
     *
     * Computable Contract Language
     */
    rule?: Contract.ComputableLanguageComponent[];
    /**
     * A selector of legal concerns for this Contract definition, derivative, or instance in any legal state.
     *
     * Range of Legal Concerns
     */
    scope?: CodeableConcept;
    /**
     * Precusory content developed with a focus and intent of supporting the formation a Contract instance, which may be associated with and transformable into a Contract.
     *
     * Contract precursor content
     */
    contentDefinition?: Contract.ContentDefinitionComponent;
    /**
     * Information that may be needed by/relevant to the performer in their execution of this term action.
     *
     * Extra Information
     */
    supportingInfo?: Reference[];
    /**
     * Parties with legal standing in the Contract, including the principal parties, the grantor(s) and grantee(s), which are any person or organization bound by the contract, and any ancillary parties, which facilitate the execution of the contract such as a notary or witness.
     *
     * Contract Signatory
     */
    signer?: Contract.SignatoryComponent[];
    /**
     * The minimal content derived from the basal information source at a specific stage in its lifecycle.
     *
     * Content derived from the basal information
     */
    contentDerivative?: CodeableConcept;
    /**
     * When this  Contract was issued.
     *
     * When this Contract was issued
     */
    issued?: Date;
    /**
     * One or more Contract Provisions, which may be related and conveyed as a group, and may contain nested groups.
     *
     * Contract Term List
     */
    term?: Contract.TermComponent[];
    /**
     * Alternative representation of the title for this Contract definition, derivative, or instance in any legal state., e.g., a domain specific contract number related to legislation.
     *
     * Acronym or short name
     */
    alias?: string[];
    /**
     * List of Legal expressions or representations of this Contract.
     *
     * Contract Legal Language
     */
    legal?: Contract.LegalLanguageComponent[];
    readonly resourceType: string;
    static revive(json: any): Contract;
    toJSON(): any;
}
export declare namespace Contract {
    enum ContractResourceStatusCodes {
        REVOKED,
        OFFERED,
        NEGOTIABLE,
        NULL,
        EXECUTABLE,
        EXECUTED,
        AMENDED,
        RENEWED,
        TERMINATED,
        DISPUTED,
        APPENDED,
        CANCELLED,
        ENTEREDINERROR,
        POLICY,
        RESOLVED,
        REJECTED
    }
    enum ContractResourcePublicationStatusCodes {
        REVOKED,
        OFFERED,
        NEGOTIABLE,
        NULL,
        EXECUTABLE,
        EXECUTED,
        AMENDED,
        RENEWED,
        TERMINATED,
        DISPUTED,
        APPENDED,
        CANCELLED,
        ENTEREDINERROR,
        POLICY,
        RESOLVED,
        REJECTED
    }
    class ComputableLanguageComponent extends BackboneElement {
        /**
         * Computable Contract conveyed using a policy rule language (e.g. XACML, DKAL, SecPal).
         *
         * Computable Contract Rules
         */
        content: Attachment | DocumentReference | Reference;
        static revive(json: any): ComputableLanguageComponent;
        toJSON(): any;
    }
    class LegalLanguageComponent extends BackboneElement {
        /**
         * Contract legal text in human renderable form.
         *
         * Contract Legal Text
         */
        content: Attachment | Composition | DocumentReference | QuestionnaireResponse | Reference;
        static revive(json: any): LegalLanguageComponent;
        toJSON(): any;
    }
    class FriendlyLanguageComponent extends BackboneElement {
        /**
         * Human readable rendering of this Contract in a format and representation intended to enhance comprehension and ensure understandability.
         *
         * Easily comprehended representation of this Contract
         */
        content: Attachment | Composition | DocumentReference | QuestionnaireResponse | Reference;
        static revive(json: any): FriendlyLanguageComponent;
        toJSON(): any;
    }
    class SignatoryComponent extends BackboneElement {
        /**
         * Legally binding Contract DSIG signature contents in Base64.
         *
         * Contract Documentation Signature
         */
        signature: Signature[];
        /**
         * Party which is a signator to this Contract.
         *
         * Contract Signatory Party
         */
        party: Organization | Patient | Practitioner | PractitionerRole | RelatedPerson | Reference;
        /**
         * Role of this Contract signer, e.g. notary, grantee.
         *
         * Contract Signatory Role
         */
        type: Coding;
        static revive(json: any): SignatoryComponent;
        toJSON(): any;
    }
    class ActionSubjectComponent extends BackboneElement {
        /**
         * Role type of agent assigned roles in this Contract.
         *
         * Role type of the agent
         */
        role?: CodeableConcept;
        /**
         * The entity the action is performed or not performed on or for.
         *
         * Entity of the action
         */
        reference: Patient[] | RelatedPerson[] | Practitioner[] | PractitionerRole[] | Device[] | Group[] | Organization[] | Reference[];
        static revive(json: any): ActionSubjectComponent;
        toJSON(): any;
    }
    class ActionComponent extends BackboneElement {
        /**
         * Reason or purpose for the action stipulated by this Contract Provision.
         *
         * Purpose for the Contract Term Action
         */
        intent: CodeableConcept;
        /**
         * Id [identifier??] of the clause or question text related to the requester of this action in the referenced form or QuestionnaireResponse.
         *
         * Pointer to specific item
         */
        contextLinkId?: string[];
        /**
         * The type of individual that is desired or required to perform or not perform the action.
         *
         * Kind of service performer
         */
        performerType?: CodeableConcept[];
        /**
         * Activity or service obligation to be done or not done, performed or not performed, effectuated or not by this Contract term.
         *
         * Type or form of the action
         */
        type: CodeableConcept;
        /**
         * Id [identifier??] of the clause or question text related to the requester of this action in the referenced form or QuestionnaireResponse.
         *
         * Pointer to specific item
         */
        requesterLinkId?: string[];
        /**
         * When action happens.
         *
         * When action happens
         */
        occurrence?: Date | Period | Timing;
        /**
         * Id [identifier??] of the clause or question text related to the reason type or reference of this  action in the referenced form or QuestionnaireResponse.
         *
         * Pointer to specific item
         */
        performerLinkId?: string[];
        /**
         * Security labels that protects the action.
         *
         * Action restriction numbers
         */
        securityLabelNumber?: number[];
        /**
         * The type of role or competency of an individual desired or required to perform or not perform the action.
         *
         * Competency of the performer
         */
        performerRole?: CodeableConcept;
        /**
         * Entity of the action.
         *
         * Entity of the action
         */
        subject?: Contract.ActionSubjectComponent[];
        /**
         * Rationale for the action to be performed or not performed. Describes why the action is permitted or prohibited. Either a coded concept, or another resource whose existence justifies permitting or not permitting this action.
         *
         * Why is action (not) needed?
         */
        reason?: CodeableReference[];
        /**
         * Comments made about the term action made by the requester, performer, subject or other participants.
         *
         * Comments about the action
         */
        note?: Annotation[];
        /**
         * Who or what initiated the action and has responsibility for its activation.
         *
         * Who asked for action
         */
        requester?: Patient[] | RelatedPerson[] | Practitioner[] | PractitionerRole[] | Device[] | Group[] | Organization[] | Reference[];
        /**
         * Indicates who or what is being asked to perform (or not perform) the ction.
         *
         * Actor that wil execute (or not) the action
         */
        performer?: RelatedPerson | Patient | Practitioner | PractitionerRole | CareTeam | Device | Substance | Organization | Location | Reference;
        /**
         * True if the term prohibits the  action.
         *
         * True if the term prohibits the  action
         */
        doNotPerform?: boolean;
        /**
         * Current state of the term action.
         *
         * State of the action
         */
        status: CodeableConcept;
        /**
         * Encounter or Episode with primary association to the specified term activity.
         *
         * Episode associated with action
         */
        context?: Encounter | EpisodeOfCare | Reference;
        /**
         * Id [identifier??] of the clause or question text related to the reason type or reference of this  action in the referenced form or QuestionnaireResponse.
         *
         * Pointer to specific item
         */
        reasonLinkId?: string[];
        /**
         * Id [identifier??] of the clause or question text related to this action in the referenced form or QuestionnaireResponse.
         *
         * Pointer to specific item
         */
        linkId?: string[];
        static revive(json: any): ActionComponent;
        toJSON(): any;
    }
    class ValuedItemComponent extends BackboneElement {
        /**
         * An amount that expresses the weighting (based on difficulty, cost and/or resource intensiveness) associated with the Contract Valued Item delivered. The concept of Points allows for assignment of point values for a Contract Valued Item, such that a monetary amount can be assigned to each point.
         *
         * Contract Valued Item Difficulty Scaling Factor
         */
        points?: number;
        /**
         * A set of security labels that define which terms are controlled by this condition.
         *
         * Security Labels that define affected terms
         */
        securityLabelNumber?: number[];
        /**
         * Indicates the time during which this Contract ValuedItem information is effective.
         *
         * Contract Valued Item Effective Tiem
         */
        effectiveTime?: Date;
        /**
         * Specifies the units by which the Contract Valued Item is measured or counted, and quantifies the countable or measurable Contract Valued Item instances.
         *
         * Count of Contract Valued Items
         */
        quantity?: Quantity;
        /**
         * A Contract Valued Item unit valuation measure.
         *
         * Contract Valued Item fee, charge, or cost
         */
        unitPrice?: Money;
        /**
         * Identifies a Contract Valued Item instance.
         *
         * Contract Valued Item Number
         */
        identifier?: Identifier;
        /**
         * Specific type of Contract Valued Item that may be priced.
         *
         * Contract Valued Item Type
         */
        entity?: CodeableConcept | Reference;
        /**
         * A real number that represents a multiplier used in determining the overall value of the Contract Valued Item delivered. The concept of a Factor allows for a discount or surcharge multiplier to be applied to a monetary amount.
         *
         * Contract Valued Item Price Scaling Factor
         */
        factor?: number;
        /**
         * Expresses the product of the Contract Valued Item unitQuantity and the unitPriceAmt. For example, the formula: unit Quantity * unit Price (Cost per Point) * factor Number  * points = net Amount. Quantity, factor and points are assumed to be 1 if not supplied.
         *
         * Total Contract Valued Item Value
         */
        net?: Money;
        /**
         * When payment is due.
         *
         * When payment is due
         */
        paymentDate?: Date;
        /**
         * Terms of valuation.
         *
         * Terms of valuation
         */
        payment?: string;
        /**
         * Who will receive payment.
         *
         * Who will receive payment
         */
        recipient?: Organization | Patient | Practitioner | PractitionerRole | RelatedPerson | Reference;
        /**
         * Who will make payment.
         *
         * Who will make payment
         */
        responsible?: Organization | Patient | Practitioner | PractitionerRole | RelatedPerson | Reference;
        /**
         * Id  of the clause or question text related to the context of this valuedItem in the referenced form or QuestionnaireResponse.
         *
         * Pointer to specific item
         */
        linkId?: string[];
        static revive(json: any): ValuedItemComponent;
        toJSON(): any;
    }
    class AssetContextComponent extends BackboneElement {
        /**
         * Context description.
         *
         * Context description
         */
        text?: string;
        /**
         * Coded representation of the context generally or of the Referenced entity, such as the asset holder type or location.
         *
         * Codeable asset context
         */
        code?: CodeableConcept[];
        /**
         * Asset context reference may include the creator, custodian, or owning Person or Organization (e.g., bank, repository),  location held, e.g., building,  jurisdiction.
         *
         * Creator,custodian or owner
         */
        reference?: Reference;
        static revive(json: any): AssetContextComponent;
        toJSON(): any;
    }
    class ContractAssetComponent extends BackboneElement {
        /**
         * Time period of asset use.
         *
         * Time period
         */
        usePeriod?: Period[];
        /**
         * Asset relevant contractual time period.
         *
         * Time period of the asset
         */
        period?: Period[];
        /**
         * Security labels that protects the asset.
         *
         * Asset restriction numbers
         */
        securityLabelNumber?: number[];
        /**
         * Target entity type about which the term may be concerned.
         *
         * Asset category
         */
        type?: CodeableConcept[];
        /**
         * Type of Asset availability for use or ownership.
         *
         * Asset availability types
         */
        periodType?: CodeableConcept[];
        /**
         * Id [identifier??] of the clause or question text about the asset in the referenced form or QuestionnaireResponse.
         *
         * Pointer to asset text
         */
        linkId?: string[];
        /**
         * Description of the quality and completeness of the asset that may be a factor in its valuation.
         *
         * Quality desctiption of asset
         */
        condition?: string;
        /**
         * Differentiates the kind of the asset .
         *
         * Range of asset
         */
        scope?: CodeableConcept;
        /**
         * May be a subtype or part of an offered asset.
         *
         * Asset sub-category
         */
        subtype?: CodeableConcept[];
        /**
         * Response to assets.
         *
         * Response to assets
         */
        answer?: Contract.AnswerComponent[];
        /**
         * Clause or question text (Prose Object) concerning the asset in a linked form, such as a QuestionnaireResponse used in the formation of the contract.
         *
         * Asset clause or question text
         */
        text?: string;
        /**
         * Contract Valued Item List.
         *
         * Contract Valued Item List
         */
        valuedItem?: Contract.ValuedItemComponent[];
        /**
         * Associated entities.
         *
         * Associated entities
         */
        typeReference?: Reference[];
        /**
         * Circumstance of the asset.
         *
         * Circumstance of the asset
         */
        context?: Contract.AssetContextComponent[];
        /**
         * Specifies the applicability of the term to an asset resource instance, and instances it refers to orinstances that refer to it, and/or are owned by the offeree.
         *
         * Kinship of the asset
         */
        relationship?: Coding;
        static revive(json: any): ContractAssetComponent;
        toJSON(): any;
    }
    class AnswerComponent extends BackboneElement {
        /**
         * Response to an offer clause or question text,  which enables selection of values to be agreed to, e.g., the period of participation, the date of occupancy of a rental, warranty duration, or whether biospecimen may be used for further research.
         *
         * The actual answer response
         */
        value: boolean | number | number | Date | Date | Date | string | Attachment | Coding | Quantity | Reference;
        static revive(json: any): AnswerComponent;
        toJSON(): any;
    }
    class ContractPartyComponent extends BackboneElement {
        /**
         * Participant in the offer.
         *
         * Referenced entity
         */
        reference: Patient[] | RelatedPerson[] | Practitioner[] | PractitionerRole[] | Device[] | Group[] | Organization[] | Reference[];
        /**
         * How the party participates in the offer.
         *
         * Participant engagement type
         */
        role: CodeableConcept;
        static revive(json: any): ContractPartyComponent;
        toJSON(): any;
    }
    class ContractOfferComponent extends BackboneElement {
        /**
         * Offer Recipient.
         *
         * Offer Recipient
         */
        party?: Contract.ContractPartyComponent[];
        /**
         * Type of Contract Provision such as specific requirements, purposes for actions, obligations, prohibitions, e.g. life time maximum benefit.
         *
         * Contract Offer Type or Form
         */
        type?: CodeableConcept;
        /**
         * Security labels that protects the offer.
         *
         * Offer restriction numbers
         */
        securityLabelNumber?: number[];
        /**
         * Human readable form of this Contract Offer.
         *
         * Human readable offer text
         */
        text?: string;
        /**
         * The owner of an asset has the residual control rights over the asset: the right to decide all usages of the asset in any way not inconsistent with a prior contract, custom, or law (Hart, 1995, p. 30).
         *
         * Negotiable offer asset
         */
        topic?: Reference;
        /**
         * How the decision about a Contract was conveyed.
         *
         * How decision is conveyed
         */
        decisionMode?: CodeableConcept[];
        /**
         * Type of choice made by accepting party with respect to an offer made by an offeror/ grantee.
         *
         * Accepting party choice
         */
        decision?: CodeableConcept;
        /**
         * Response to offer text.
         *
         * Response to offer text
         */
        answer?: Contract.AnswerComponent[];
        /**
         * The id of the clause or question text of the offer in the referenced questionnaire/response.
         *
         * Pointer to text
         */
        linkId?: string[];
        /**
         * Unique identifier for this particular Contract Provision.
         *
         * Offer business ID
         */
        identifier?: Identifier[];
        static revive(json: any): ContractOfferComponent;
        toJSON(): any;
    }
    class SecurityLabelComponent extends BackboneElement {
        /**
         * Security label privacy tag that specifies the level of confidentiality protection required for this term and/or term elements.
         *
         * Confidentiality Protection
         */
        classification: Coding;
        /**
         * Security label privacy tag that specifies the applicable privacy and security policies governing this term and/or term elements.
         *
         * Applicable Policy
         */
        category?: Coding[];
        /**
         * Security label privacy tag that specifies the manner in which term and/or term elements are to be protected.
         *
         * Handling Instructions
         */
        control?: Coding[];
        /**
         * Number used to link this term or term element to the applicable Security Label.
         *
         * Link to Security Labels
         */
        number?: number[];
        static revive(json: any): SecurityLabelComponent;
        toJSON(): any;
    }
    class TermComponent extends BackboneElement {
        /**
         * When this Contract Provision was issued.
         *
         * Contract Term Issue Date Time
         */
        issued?: Date;
        /**
         * A legal clause or condition contained within a contract that requires one or both parties to perform a particular requirement by some specified time or prevents one or both parties from performing a particular requirement by some specified time.
         *
         * Contract Term Type or Form
         */
        type?: CodeableConcept;
        /**
         * Contract Term Asset List.
         *
         * Contract Term Asset List
         */
        asset?: Contract.ContractAssetComponent[];
        /**
         * Nested group of Contract Provisions.
         *
         * Nested Contract Term Group
         */
        group?: Contract.TermComponent[];
        /**
         * The entity that the term applies to.
         *
         * Term Concern
         */
        topic?: CodeableConcept | Reference;
        /**
         * An actor taking a role in an activity for which it can be assigned some degree of responsibility for the activity taking place.
         *
         * Entity being ascribed responsibility
         */
        action?: Contract.ActionComponent[];
        /**
         * Statement of a provision in a policy or a contract.
         *
         * Term Statement
         */
        text?: string;
        /**
         * A specialized legal clause or condition based on overarching contract type.
         *
         * Contract Term Type specific classification
         */
        subType?: CodeableConcept;
        /**
         * Relevant time or time-period when this Contract Provision is applicable.
         *
         * Contract Term Effective Time
         */
        applies?: Period;
        /**
         * Security labels that protect the handling of information about the term and its elements, which may be specifically identified.
         *
         * Protection for the Term
         */
        securityLabel?: Contract.SecurityLabelComponent[];
        /**
         * Unique identifier for this particular Contract Provision.
         *
         * Contract Term Number
         */
        identifier?: Identifier;
        /**
         * The matter of concern in the context of this provision of the agrement.
         *
         * Context of the Contract term
         */
        offer: Contract.ContractOfferComponent;
        static revive(json: any): TermComponent;
        toJSON(): any;
    }
    class ContentDefinitionComponent extends BackboneElement {
        /**
         * amended | appended | cancelled | disputed | entered-in-error | executable +.
         *
         * amended | appended | cancelled | disputed | entered-in-error | executable +
         */
        publicationStatus: string;
        /**
         * A copyright statement relating to Contract precursor content. Copyright statements are generally legal restrictions on the use and publishing of the Contract precursor content.
         *
         * Publication Ownership
         */
        copyright?: string;
        /**
         * The  individual or organization that published the Contract precursor content.
         *
         * Publisher Entity
         */
        publisher?: Practitioner | PractitionerRole | Organization | Reference;
        /**
         * Detailed Precusory content type.
         *
         * Detailed Content Type Definition
         */
        subType?: CodeableConcept;
        /**
         * Precusory content structure and use, i.e., a boilerplate, template, application for a contract such as an insurance policy or benefits under a program, e.g., workers compensation.
         *
         * Content structure and use
         */
        type: CodeableConcept;
        /**
         * The date (and optionally time) when the contract was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the contract changes.
         *
         * When published
         */
        publicationDate?: Date;
        static revive(json: any): ContentDefinitionComponent;
        toJSON(): any;
    }
}
