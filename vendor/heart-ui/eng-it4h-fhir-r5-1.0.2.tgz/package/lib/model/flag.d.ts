import { Reference } from '../datatype/reference';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { Location } from '../model/location';
import { Medication } from '../model/medication';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { PlanDefinition } from '../model/plan-definition';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Procedure } from '../model/procedure';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Flag</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Flag">http://hl7.org/fhir/StructureDefinition/Flag</a>
 * </p>
 *
 */
export declare class Flag extends DomainResource {
    /**
     * This alert is only relevant during the encounter.
     *
     * Alert relevant during encounter
     */
    encounter?: Encounter | Reference;
    /**
     * Supports basic workflow.
     *
     * active | inactive | entered-in-error
     */
    status: string;
    /**
     * Allows a flag to be divided into different categories like clinical, administrative etc. Intended to be used as a means of filtering which flags are displayed to particular user or in a given context.
     *
     * Clinical, administrative, etc
     */
    category?: CodeableConcept[];
    /**
     * The period of time from the activation of the flag to inactivation of the flag. If the flag is active, the end of the period should be unspecified.
     *
     * Time period when flag is active
     */
    period?: Period;
    /**
     * The coded value or textual component of the flag to display to the user.
     *
     * Coded or textual message to display to user
     */
    code: CodeableConcept;
    /**
     * Business identifiers assigned to this flag by the performer or other systems which remain constant as the resource is updated and propagates from server to server.
     *
     * Business identifier
     */
    identifier?: Identifier[];
    /**
     * The patient, related person, location, group, organization, or practitioner etc. this is about record this flag is associated with.
     *
     * Who/What is flag about?
     */
    subject: Patient | RelatedPerson | Location | Group | Organization | Practitioner | PractitionerRole | PlanDefinition | Medication | Procedure | Reference;
    /**
     * The person, organization or device that created the flag.
     *
     * Flag creator
     */
    author?: Device | Organization | Patient | RelatedPerson | Practitioner | PractitionerRole | Reference;
    readonly resourceType: string;
    static revive(json: any): Flag;
    toJSON(): any;
}
export declare namespace Flag {
    enum FlagStatus {
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        INACTIVE
    }
}
