import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { ElementDefinition } from '../datatype/element-definition';
import { Identifier } from '../datatype/identifier';
import { UsageContext } from '../datatype/usage-context';
import { CanonicalResource } from '../model/canonical-resource';
/**
 * HAPI/FHIR <b>StructureDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/StructureDefinition">http://hl7.org/fhir/StructureDefinition/StructureDefinition</a>
 * </p>
 *
 */
export declare class StructureDefinition extends CanonicalResource {
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * The version of the FHIR specification on which this StructureDefinition is based - this is the formal version of the specification, without the revision number, e.g. [publication].[major].[minor], which is 4.6.0. for this version.
     *
     * FHIR Version this StructureDefinition targets
     */
    fhirVersion?: string;
    /**
     * Identifies the types of resource or data type elements to which the extension can be applied. For more guidance on using the 'context' element, see the [defining extensions page](defining-extensions.html#context).
     *
     * If an extension, where it can be used in instances
     */
    context?: StructureDefinition.StructureDefinitionContextComponent[];
    /**
     * (DEPRECATED) A set of key words or terms from external terminologies that may be used to assist with indexing and searching of templates nby describing the use of this structure definition, or the content it describes.
     *
     * Assist with indexing and finding
     */
    keyword?: Coding[];
    /**
     * A copyright statement relating to the structure definition and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the structure definition.  The short copyright declaration (e.g. (c) '2015+ xyz organization' should be sent in the copyrightLabel element.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * The date  (and optionally time) when the structure definition was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the structure definition changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * A legal or geographic region in which the structure definition is intended to be used.
     *
     * Intended jurisdiction for structure definition (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * Explanation of why this structure definition is needed and why it has been designed as it has.
     *
     * Why this structure definition is defined
     */
    purpose?: string;
    /**
     * A Boolean value to indicate that this structure definition is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A free text natural language description of the structure definition from a consumer's perspective.
     *
     * Natural language description of the structure definition
     */
    description?: string;
    /**
     * Whether structure this definition describes is abstract or not  - that is, whether the structure is not intended to be instantiated. For Resources and Data types, abstract types will never be exchanged  between systems.
     *
     * Whether the structure is abstract
     */
    abstract: boolean;
    /**
     * A differential view is expressed relative to the base StructureDefinition - a statement of differences that it applies.
     *
     * Differential view of the structure
     */
    differential?: StructureDefinition.StructureDefinitionDifferentialComponent;
    /**
     * A short, descriptive, user-friendly title for the structure definition.
     *
     * Name for this structure definition (human friendly)
     */
    title?: string;
    /**
     * The type this structure describes. If the derivation kind is 'specialization' then this is the master definition for a type, and there is always one of these (a data type, an extension, a resource, including abstract ones). Otherwise the structure definition is a constraint on the stated type (and in this case, the type cannot be an abstract type).  References are URLs that are relative to http://hl7.org/fhir/StructureDefinition e.g. "string" is a reference to http://hl7.org/fhir/StructureDefinition/string. Absolute URLs are only allowed in logical models, where they are required.
     *
     * Type defined or constrained by this structure
     */
    type: string;
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * A set of rules as FHIRPath Invariants about when the extension can be used (e.g. co-occurrence variants for the extension). All the rules must be true.
     *
     * FHIRPath invariants - when the extension can be used
     */
    contextInvariant?: string[];
    /**
     * How the type relates to the baseDefinition.
     *
     * specialization | constraint - How relates to base definition
     */
    derivation?: string;
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the structure definition.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * A natural language name identifying the structure definition. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this structure definition (computer friendly)
     */
    name: string;
    /**
     * The status of this structure definition. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * A snapshot view is expressed in a standalone form that can be used and interpreted without considering the base StructureDefinition.
     *
     * Snapshot view of the structure
     */
    snapshot?: StructureDefinition.StructureDefinitionSnapshotComponent;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate structure definition instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * An external specification that the content is mapped to.
     *
     * External specification that the content is mapped to
     */
    mapping?: StructureDefinition.StructureDefinitionMappingComponent[];
    /**
     * A formal identifier that is used to identify this structure definition when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the structure definition
     */
    identifier?: Identifier[];
    /**
     * Defines the kind of structure that this definition is describing.
     *
     * primitive-type | complex-type | resource | logical
     */
    kind: string;
    /**
     * An absolute URI that is the base structure from which this type is derived, either by specialization or constraint.
     *
     * Definition that this type is constrained/specialized from
     */
    baseDefinition?: string;
    /**
     * An absolute URI that is used to identify this structure definition when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this structure definition is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the structure definition is stored on different servers.
     *
     * Canonical identifier for this structure definition, represented as a URI (globally unique)
     */
    url: string;
    /**
     * The identifier that is used to identify this version of the structure definition when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the structure definition author and is not expected to be globally unique. There is no expectation that versions can be placed in a lexicographical sequence, so authors are encouraged to populate the StructureDefinition.versionAlgorithm[x] element to enable comparisons. If there is no managed version available, authors can consider using ISO date/time syntax (e.g., '2023-01-01').
     *
     * Business version of the structure definition
     */
    version?: string;
    readonly resourceType: string;
    static revive(json: any): StructureDefinition;
    toJSON(): any;
}
export declare namespace StructureDefinition {
    enum TypeDerivationRule {
        NULL,
        SPECIALIZATION,
        CONSTRAINT
    }
    enum StructureDefinitionKind {
        NULL,
        COMPLEXTYPE,
        PRIMITIVETYPE,
        LOGICAL,
        RESOURCE
    }
    enum ExtensionContextType {
        ELEMENT,
        NULL,
        EXTENSION,
        FHIRPATH
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    enum FHIRVersion {
        _4_5,
        _4_4,
        _0_05,
        _4_3,
        _4_2,
        _0_06,
        _4_6,
        _0_0,
        _4_3_0SNAPSHOT1,
        _0_5,
        _3_5_0,
        _4_1,
        _0_4,
        _4_0,
        _3_3_0,
        _5_0_0BALLOT,
        _5_0_0CIBUILD,
        _6_0_0,
        _0_0_81,
        _0_0_82,
        _0_01,
        _0_0_80,
        _1_6_0,
        _4_3_0CIBUILD,
        _1_4_0,
        NULL,
        _1_8_0,
        _1_0_2,
        _1_0_0,
        _1_0_1,
        _4_5_0,
        _0_4_0,
        _4_1_0,
        _0_11,
        _4_3_0,
        _1_8,
        _3_0_1,
        _3_0_0,
        _3_5,
        _1_6,
        _3_3,
        _1_0,
        _5_0,
        _1_4,
        _3_0,
        _1_1,
        _3_0_2,
        _5_0_0DRAFTFINAL,
        _6_0_0CIBUILD,
        _5_0_0,
        _1_1_0,
        _4_0_0,
        _0_5_0,
        _5_0_0SNAPSHOT1,
        _5_0_0SNAPSHOT3,
        _5_0_0SNAPSHOT2,
        _4_6_0,
        _4_2_0,
        _4_0_1,
        _4_4_0
    }
    class StructureDefinitionDifferentialComponent extends BackboneElement {
        /**
         * Captures constraints on each element within the resource.
         *
         * Definition of elements in the resource (if no StructureDefinition)
         */
        element: ElementDefinition[];
        static revive(json: any): StructureDefinitionDifferentialComponent;
        toJSON(): any;
    }
    class StructureDefinitionSnapshotComponent extends BackboneElement {
        /**
         * Captures constraints on each element within the resource.
         *
         * Definition of elements in the resource (if no StructureDefinition)
         */
        element: ElementDefinition[];
        static revive(json: any): StructureDefinitionSnapshotComponent;
        toJSON(): any;
    }
    class StructureDefinitionContextComponent extends BackboneElement {
        /**
         * Defines how to interpret the expression that defines what the context of the extension is.
         *
         * fhirpath | element | extension
         */
        type: string;
        /**
         * An expression that defines where an extension can be used in resources.
         *
         * Where the extension can be used in instances
         */
        expression: string;
        static revive(json: any): StructureDefinitionContextComponent;
        toJSON(): any;
    }
    class StructureDefinitionMappingComponent extends BackboneElement {
        /**
         * An Internal id that is used to identify this mapping set when specific mappings are made.
         *
         * Internal id when this mapping is used
         */
        identity: string;
        /**
         * Comments about this mapping, including version notes, issues, scope limitations, and other important notes for usage.
         *
         * Versions, Issues, Scope limitations etc
         */
        comment?: string;
        /**
         * A name for the specification that is being mapped to.
         *
         * Names what this mapping refers to
         */
        name?: string;
        /**
         * An absolute URI that identifies the specification that this mapping is expressed to.
         *
         * Identifies what this mapping refers to
         */
        uri?: string;
        static revive(json: any): StructureDefinitionMappingComponent;
        toJSON(): any;
    }
}
