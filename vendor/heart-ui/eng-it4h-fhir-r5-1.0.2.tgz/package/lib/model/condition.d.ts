import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Age } from '../datatype/age';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Range } from '../datatype/range';
import { CareTeam } from '../model/care-team';
import { ClinicalImpression } from '../model/clinical-impression';
import { Device } from '../model/device';
import { DiagnosticReport } from '../model/diagnostic-report';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { Observation } from '../model/observation';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Condition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Condition">http://hl7.org/fhir/StructureDefinition/Condition</a>
 * </p>
 *
 */
export declare class Condition extends DomainResource {
    /**
     * The verification status to support the clinical status of the condition.  The verification status pertains to the condition, itself, not to any specific condition attribute.
     *
     * unconfirmed | provisional | differential | confirmed | refuted | entered-in-error
     */
    verificationStatus?: CodeableConcept;
    /**
     * Supporting evidence / manifestations that are the basis of the Condition's verification status, such as evidence that confirmed or refuted the condition.
     *
     * Supporting evidence for the verification status
     */
    evidence?: CodeableReference[];
    /**
     * The recordedDate represents when this particular Condition record was created in the system, which is often a system-generated date.
     *
     * Date condition was first recorded
     */
    recordedDate?: Date;
    /**
     * Indicates the patient or group who the condition record is associated with.
     *
     * Who has the condition?
     */
    subject: Patient | Group | Reference;
    /**
     * Business identifiers assigned to this condition by the performer or other systems which remain constant as the resource is updated and propagates from server to server.
     *
     * External Ids for this condition
     */
    identifier?: Identifier[];
    /**
     * Additional information about the Condition. This is a general notes/comments entry  for description of the Condition, its diagnosis and prognosis.
     *
     * Additional information about the Condition
     */
    note?: Annotation[];
    /**
     * A subjective assessment of the severity of the condition as evaluated by the clinician.
     *
     * Subjective severity of condition
     */
    severity?: CodeableConcept;
    /**
     * Identification of the condition, problem or diagnosis.
     *
     * Identification of the condition, problem or diagnosis
     */
    code?: CodeableConcept;
    /**
     * The clinical status of the condition.
     *
     * active | recurrence | relapse | inactive | remission | resolved | unknown
     */
    clinicalStatus: CodeableConcept;
    /**
     * Estimated or actual date or date-time  the condition began, in the opinion of the clinician.
     *
     * Estimated or actual date,  date-time, or age
     */
    onset?: Date | Age | Period | Range | string;
    /**
     * Indicates who or what participated in the activities related to the condition and how they were involved.
     *
     * Who or what participated in the activities related to the condition and how they were involved
     */
    participant?: Condition.ConditionParticipantComponent[];
    /**
     * The Encounter during which this Condition was created or to which the creation of this record is tightly associated.
     *
     * The Encounter during which this Condition was created
     */
    encounter?: Encounter | Reference;
    /**
     * A simple summary of the stage such as "Stage 3" or "Early Onset". The determination of the stage is disease-specific, such as cancer, retinopathy of prematurity, kidney diseases, Alzheimer's, or Parkinson disease.
     *
     * Stage/grade, usually assessed formally
     */
    stage?: Condition.ConditionStageComponent[];
    /**
     * The anatomical location where this condition manifests itself.
     *
     * Anatomical location, if relevant
     */
    bodySite?: CodeableConcept[];
    /**
     * The date or estimated date that the condition resolved or went into remission. This is called "abatement" because of the many overloaded connotations associated with "remission" or "resolution" - Some conditions, such as chronic conditions, are never really resolved, but they can abate.
     *
     * When in resolution/remission
     */
    abatement?: Date | Age | Period | Range | string;
    /**
     * A category assigned to the condition.
     *
     * problem-list-item | encounter-diagnosis
     */
    category?: CodeableConcept[];
    readonly resourceType: string;
    static revive(json: any): Condition;
    toJSON(): any;
}
export declare namespace Condition {
    class ConditionStageComponent extends BackboneElement {
        /**
         * The kind of staging, such as pathological or clinical staging.
         *
         * Kind of staging
         */
        type?: CodeableConcept;
        /**
         * Reference to a formal record of the evidence on which the staging assessment is based.
         *
         * Formal record of assessment
         */
        assessment?: ClinicalImpression[] | DiagnosticReport[] | Observation[] | Reference[];
        /**
         * A simple summary of the stage such as "Stage 3" or "Early Onset". The determination of the stage is disease-specific, such as cancer, retinopathy of prematurity, kidney diseases, Alzheimer's, or Parkinson disease.
         *
         * Simple summary (disease specific)
         */
        summary?: CodeableConcept;
        static revive(json: any): ConditionStageComponent;
        toJSON(): any;
    }
    class ConditionParticipantComponent extends BackboneElement {
        /**
         * Indicates who or what participated in the activities related to the condition.
         *
         * Who or what participated in the activities related to the condition
         */
        actor: Practitioner | PractitionerRole | Patient | RelatedPerson | Device | Organization | CareTeam | Reference;
        /**
         * Distinguishes the type of involvement of the actor in the activities related to the condition.
         *
         * Type of involvement
         */
        function?: CodeableConcept;
        static revive(json: any): ConditionParticipantComponent;
        toJSON(): any;
    }
}
