import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Coding } from '../datatype/coding';
import { Identifier } from '../datatype/identifier';
import { Appointment } from '../model/appointment';
import { AppointmentResponse } from '../model/appointment-response';
import { CarePlan } from '../model/care-plan';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Endpoint } from '../model/endpoint';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Procedure } from '../model/procedure';
import { RelatedPerson } from '../model/related-person';
import { ServiceRequest } from '../model/service-request';
import { Specimen } from '../model/specimen';
import { Task } from '../model/task';
/**
 * HAPI/FHIR <b>ImagingStudy</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ImagingStudy">http://hl7.org/fhir/StructureDefinition/ImagingStudy</a>
 * </p>
 *
 */
export declare class ImagingStudy extends DomainResource {
    /**
     * Identifiers for the ImagingStudy such as DICOM Study Instance UID.
     *
     * Identifiers for the whole study
     */
    identifier?: Identifier[];
    /**
     * A larger event of which this particular ImagingStudy is a component or step.  For example,  an ImagingStudy as part of a procedure.
     *
     * Part of referenced event
     */
    partOf?: Procedure[] | Reference[];
    /**
     * Description of clinical condition indicating why the ImagingStudy was requested, and/or Indicates another resource whose existence justifies this Study.
     *
     * Why the study was requested / performed
     */
    reason?: CodeableReference[];
    /**
     * Per the recommended DICOM mapping, this element is derived from the Study Description attribute (0008,1030). Observations or findings about the imaging study should be recorded in another resource, e.g. Observation, and not in this element.
     *
     * User-defined comments
     */
    note?: Annotation[];
    /**
     * A list of all the distinct values of series.modality. This may include both acquisition and non-acquisition modalities.
     *
     * All of the distinct values for series' modalities
     */
    modality?: CodeableConcept[];
    /**
     * Number of Series in the Study. This value given may be larger than the number of series elements this Resource contains due to resource availability, security, or other factors. This element should be present if any series elements are present.
     *
     * Number of Study Related Series
     */
    numberOfSeries?: number;
    /**
     * The subject, typically a patient, of the imaging study.
     *
     * Who or what is the subject of the study
     */
    subject: Patient | Device | Group | Reference;
    /**
     * The Imaging Manager description of the study. Institution-generated description or classification of the Study (component) performed.
     *
     * Institution-generated description
     */
    description?: string;
    /**
     * The healthcare event (e.g. a patient and healthcare provider interaction) during which this ImagingStudy is made.
     *
     * Encounter with which this imaging study is associated
     */
    encounter?: Encounter | Reference;
    /**
     * This field corresponds to the DICOM Procedure Code Sequence (0008,1032). This is different from the FHIR Procedure resource that may include the ImagingStudy.
     *
     * The performed procedure or code
     */
    procedure?: CodeableReference[];
    /**
     * Date and time the study started.
     *
     * When the study was started
     */
    started?: Date;
    /**
     * The requesting/referring physician.
     *
     * Referring physician
     */
    referrer?: Practitioner | PractitionerRole | Reference;
    /**
     * The network service providing access (e.g., query, view, or retrieval) for the study. See implementation notes for information about using DICOM endpoints. A study-level endpoint applies to each series in the study, unless overridden by a series-level endpoint with the same Endpoint.connectionType.
     *
     * Study access endpoint
     */
    endpoint?: Endpoint[] | Reference[];
    /**
     * Number of SOP Instances in Study. This value given may be larger than the number of instance elements this resource contains due to resource availability, security, or other factors. This element should be present if any instance elements are present.
     *
     * Number of Study Related Instances
     */
    numberOfInstances?: number;
    /**
     * Each study has one or more series of images or other content.
     *
     * Each study has one or more series of instances
     */
    series?: ImagingStudy.ImagingStudySeriesComponent[];
    /**
     * The principal physical location where the ImagingStudy was performed.
     *
     * Where ImagingStudy occurred
     */
    location?: Location | Reference;
    /**
     * The current state of the ImagingStudy resource. This is not the status of any ServiceRequest or Task resources associated with the ImagingStudy.
     *
     * registered | available | cancelled | entered-in-error | unknown
     */
    status: string;
    /**
     * A list of the diagnostic requests that resulted in this imaging study being performed.
     *
     * Request fulfilled
     */
    basedOn?: CarePlan[] | ServiceRequest[] | Appointment[] | AppointmentResponse[] | Task[] | Reference[];
    readonly resourceType: string;
    static revive(json: any): ImagingStudy;
    toJSON(): any;
}
export declare namespace ImagingStudy {
    enum ImagingStudyStatus {
        AVAILABLE,
        CANCELLED,
        ENTEREDINERROR,
        NULL,
        REGISTERED,
        UNKNOWN
    }
    class ImagingStudySeriesInstanceComponent extends BackboneElement {
        /**
         * The DICOM SOP Instance UID for this image or other DICOM content.
         *
         * DICOM SOP Instance UID
         */
        uid: string;
        /**
         * The number of instance in the series.
         *
         * The number of this instance in the series
         */
        number?: number;
        /**
         * The description of the instance.
         *
         * Description of instance
         */
        title?: string;
        /**
         * DICOM instance  type.
         *
         * DICOM class type
         */
        sopClass: Coding;
        static revive(json: any): ImagingStudySeriesInstanceComponent;
        toJSON(): any;
    }
    class ImagingStudySeriesPerformerComponent extends BackboneElement {
        /**
         * Indicates who or what performed the series.
         *
         * Who performed the series
         */
        actor: Practitioner | PractitionerRole | Organization | CareTeam | Patient | Device | RelatedPerson | HealthcareService | Reference;
        /**
         * Distinguishes the type of involvement of the performer in the series.
         *
         * Type of performance
         */
        function?: CodeableConcept;
        static revive(json: any): ImagingStudySeriesPerformerComponent;
        toJSON(): any;
    }
    class ImagingStudySeriesComponent extends BackboneElement {
        /**
         * The date and time the series was started.
         *
         * When the series started
         */
        started?: Date;
        /**
         * A description of the series.
         *
         * A short human readable summary of the series
         */
        description?: string;
        /**
         * The laterality of the (possibly paired) anatomic structures examined. E.g., the left knee, both lungs, or unpaired abdomen. If present, shall be consistent with any laterality information indicated in ImagingStudy.series.bodySite.
         *
         * Body part laterality
         */
        laterality?: CodeableConcept;
        /**
         * The distinct modality for this series. This may include both acquisition and non-acquisition modalities.
         *
         * The modality used for this series
         */
        modality: CodeableConcept;
        /**
         * Indicates who or what performed the series and how they were involved.
         *
         * Who performed the series
         */
        performer?: ImagingStudy.ImagingStudySeriesPerformerComponent[];
        /**
         * A single SOP instance within the series, e.g. an image, or presentation state.
         *
         * A single SOP instance from the series
         */
        instance?: ImagingStudy.ImagingStudySeriesInstanceComponent[];
        /**
         * Number of SOP Instances in the Study. The value given may be larger than the number of instance elements this resource contains due to resource availability, security, or other factors. This element should be present if any instance elements are present.
         *
         * Number of Series Related Instances
         */
        numberOfInstances?: number;
        /**
         * The network service providing access (e.g., query, view, or retrieval) for this series. See implementation notes for information about using DICOM endpoints. A series-level endpoint, if present, has precedence over a study-level endpoint with the same Endpoint.connectionType.
         *
         * Series access endpoint
         */
        endpoint?: Endpoint[] | Reference[];
        /**
         * The anatomic structures examined. See DICOM Part 16 Annex L (http://dicom.nema.org/medical/dicom/current/output/chtml/part16/chapter_L.html) for DICOM to SNOMED-CT mappings. The bodySite may indicate the laterality of body part imaged; if so, it shall be consistent with any content of ImagingStudy.series.laterality.
         *
         * Body part examined
         */
        bodySite?: CodeableReference;
        /**
         * The DICOM Series Instance UID for the series.
         *
         * DICOM Series Instance UID for the series
         */
        uid: string;
        /**
         * The numeric identifier of this series in the study.
         *
         * Numeric identifier of this series
         */
        number?: number;
        /**
         * The specimen imaged, e.g., for whole slide imaging of a biopsy.
         *
         * Specimen imaged
         */
        specimen?: Specimen[] | Reference[];
        static revive(json: any): ImagingStudySeriesComponent;
        toJSON(): any;
    }
}
