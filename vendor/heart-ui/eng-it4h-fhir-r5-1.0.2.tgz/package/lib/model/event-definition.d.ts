import { Reference } from '../datatype/reference';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { RelatedArtifact } from '../datatype/related-artifact';
import { TriggerDefinition } from '../datatype/trigger-definition';
import { UsageContext } from '../datatype/usage-context';
import { Group } from '../model/group';
import { MetadataResource } from '../model/metadata-resource';
/**
 * HAPI/FHIR <b>EventDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/EventDefinition">http://hl7.org/fhir/StructureDefinition/EventDefinition</a>
 * </p>
 *
 */
export declare class EventDefinition extends MetadataResource {
    /**
     * A formal identifier that is used to identify this event definition when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the event definition
     */
    identifier?: Identifier[];
    /**
     * An individual or organization primarily responsible for internal coherence of the content.
     *
     * Who edited the content
     */
    editor?: ContactDetail[];
    /**
     * Related resources such as additional documentation, justification, or bibliographic references.
     *
     * Additional documentation, citations, etc
     */
    relatedArtifact?: RelatedArtifact[];
    /**
     * The period during which the event definition content was or is planned to be in active use.
     *
     * When the event definition is expected to be used
     */
    effectivePeriod?: Period;
    /**
     * An individiual or organization primarily involved in the creation and maintenance of the content.
     *
     * Who authored the content
     */
    author?: ContactDetail[];
    /**
     * An individual or organization asserted by the publisher to be primarily responsible for review of some aspect of the content.
     *
     * Who reviewed the content
     */
    reviewer?: ContactDetail[];
    /**
     * The trigger element defines when the event occurs. If more than one trigger condition is specified, the event fires whenever any one of the trigger conditions is met.
     *
     * "when" the event occurs (multiple = 'or')
     */
    trigger: TriggerDefinition[];
    /**
     * The identifier that is used to identify this version of the event definition when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the event definition author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the event definition
     */
    version?: string;
    /**
     * An absolute URI that is used to identify this event definition when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this event definition is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the event definition is stored on different servers.
     *
     * Canonical identifier for this event definition, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * The date on which the resource content was last reviewed. Review happens periodically after approval but does not change the original approval date.
     *
     * When the event definition was last reviewed by the publisher
     */
    lastReviewDate?: Date;
    /**
     * An explanatory or alternate title for the event definition giving additional information about its content.
     *
     * Subordinate title of the event definition
     */
    subtitle?: string;
    /**
     * A natural language name identifying the event definition. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this event definition (computer friendly)
     */
    name?: string;
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the event definition.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * Descriptive topics related to the module. Topics provide a high-level categorization of the module that can be useful for filtering and searching.
     *
     * E.g. Education, Treatment, Assessment, etc
     */
    topic?: CodeableConcept[];
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate event definition instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * The status of this event definition. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The date  (and optionally time) when the event definition was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the event definition changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * A copyright statement relating to the event definition and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the event definition.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * The date on which the resource content was approved by the publisher. Approval happens once when the content is officially approved for usage.
     *
     * When the event definition was approved by publisher
     */
    approvalDate?: Date;
    /**
     * Explanation of why this event definition is needed and why it has been designed as it has.
     *
     * Why this event definition is defined
     */
    purpose?: string;
    /**
     * A code or group definition that describes the intended subject of the event definition.
     *
     * Type of individual the event definition is focused on
     */
    subject?: CodeableConcept | Group | Reference;
    /**
     * A legal or geographic region in which the event definition is intended to be used.
     *
     * Intended jurisdiction for event definition (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * A detailed description of how the event definition is used from a clinical perspective.
     *
     * Describes the clinical usage of the event definition
     */
    usage?: string;
    /**
     * A free text natural language description of the event definition from a consumer's perspective.
     *
     * Natural language description of the event definition
     */
    description?: string;
    /**
     * A Boolean value to indicate that this event definition is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A short, descriptive, user-friendly title for the event definition.
     *
     * Name for this event definition (human friendly)
     */
    title?: string;
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * An individual or organization asserted by the publisher to be responsible for officially endorsing the content for use in some setting.
     *
     * Who endorsed the content
     */
    endorser?: ContactDetail[];
    readonly resourceType: string;
    static revive(json: any): EventDefinition;
    toJSON(): any;
}
export declare namespace EventDefinition {
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
}
