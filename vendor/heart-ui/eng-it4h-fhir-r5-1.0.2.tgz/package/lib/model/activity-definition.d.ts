import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Age } from '../datatype/age';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Dosage } from '../datatype/dosage';
import { Duration } from '../datatype/duration';
import { Expression } from '../datatype/expression';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { RelatedArtifact } from '../datatype/related-artifact';
import { Timing } from '../datatype/timing';
import { UsageContext } from '../datatype/usage-context';
import { AdministrableProductDefinition } from '../model/administrable-product-definition';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DeviceDefinition } from '../model/device-definition';
import { Endpoint } from '../model/endpoint';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { Ingredient } from '../model/ingredient';
import { Location } from '../model/location';
import { ManufacturedItemDefinition } from '../model/manufactured-item-definition';
import { Medication } from '../model/medication';
import { MedicinalProductDefinition } from '../model/medicinal-product-definition';
import { MetadataResource } from '../model/metadata-resource';
import { Organization } from '../model/organization';
import { PackagedProductDefinition } from '../model/packaged-product-definition';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
import { Substance } from '../model/substance';
import { SubstanceDefinition } from '../model/substance-definition';
/**
 * HAPI/FHIR <b>ActivityDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ActivityDefinition">http://hl7.org/fhir/StructureDefinition/ActivityDefinition</a>
 * </p>
 *
 */
export declare class ActivityDefinition extends MetadataResource {
    /**
     * An individual or organization asserted by the publisher to be responsible for officially endorsing the content for use in some setting.
     *
     * Who endorsed the content
     */
    endorser?: ContactDetail[];
    /**
     * Set this to true if the definition is to indicate that a particular activity should NOT be performed. If true, this element should be interpreted to reinforce a negative coding. For example NPO as a code with a doNotPerform of true would still indicate to NOT perform the action.
     *
     * True if the activity should not be performed
     */
    doNotPerform?: boolean;
    /**
     * If a CodeableConcept is present, it indicates the pre-condition for performing the service.  For example "pain", "on flare-up", etc.
     *
     * Preconditions for service
     */
    asNeeded?: boolean | CodeableConcept;
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * Defines the observations that are expected to be produced by the action.
     *
     * What observations must be produced by this action
     */
    observationResultRequirement?: string[];
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * A Boolean value to indicate that this activity definition is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * Indicates who should participate in performing the action described.
     *
     * Who should participate in the action
     */
    participant?: ActivityDefinition.ActivityDefinitionParticipantComponent[];
    /**
     * The date  (and optionally time) when the activity definition was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the activity definition changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * A copyright statement relating to the activity definition and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the activity definition.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * A detailed description of how the activity definition is used from a clinical perspective.
     *
     * Describes the clinical usage of the activity definition
     */
    usage?: string;
    /**
     * A code, group definition, or canonical reference that describes  or identifies the intended subject of the activity being defined.  Canonical references are allowed to support the definition of protocols for drug and substance quality specifications, and is allowed to reference a MedicinalProductDefinition, SubstanceDefinition, AdministrableProductDefinition, ManufacturedItemDefinition, or PackagedProductDefinition resource.
     *
     * Type of individual the activity definition is intended for
     */
    subject?: CodeableConcept | Group | MedicinalProductDefinition | SubstanceDefinition | AdministrableProductDefinition | ManufacturedItemDefinition | PackagedProductDefinition | string | Reference;
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the activity definition.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * Descriptive topics related to the content of the activity. Topics provide a high-level categorization of the activity that can be useful for filtering and searching.
     *
     * E.g. Education, Treatment, Assessment, etc
     */
    topic?: CodeableConcept[];
    /**
     * A natural language name identifying the activity definition. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this activity definition (computer friendly)
     */
    name?: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate activity definition instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * The status of this activity definition. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * An explanatory or alternate title for the activity definition giving additional information about its content.
     *
     * Subordinate title of the activity definition
     */
    subtitle?: string;
    /**
     * The date on which the resource content was last reviewed. Review happens periodically after approval but does not change the original approval date.
     *
     * When the activity definition was last reviewed by the publisher
     */
    lastReviewDate?: Date;
    /**
     * The identifier that is used to identify this version of the activity definition when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the activity definition author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence. To provide a version consistent with the Decision Support Service specification, use the format Major.Minor.Revision (e.g. 1.0.0). For more information on versioning knowledge assets, refer to the Decision Support Service specification. Note that a version is required for non-experimental active assets.
     *
     * Business version of the activity definition
     */
    version?: string;
    /**
     * Indicates how quickly the activity  should be addressed with respect to other requests.
     *
     * routine | urgent | asap | stat
     */
    priority?: string;
    /**
     * A formal identifier that is used to identify this activity definition when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the activity definition
     */
    identifier?: Identifier[];
    /**
     * Related artifacts such as additional documentation, justification, or bibliographic references.
     *
     * Additional documentation, citations, etc
     */
    relatedArtifact?: RelatedArtifact[];
    /**
     * The period during which the activity definition content was or is planned to be in active use.
     *
     * When the activity definition is expected to be used
     */
    effectivePeriod?: Period;
    /**
     * A profile to which the target of the activity definition is expected to conform.
     *
     * What profile the resource needs to conform to
     */
    profile?: string;
    /**
     * An individiual or organization primarily involved in the creation and maintenance of the content.
     *
     * Who authored the content
     */
    author?: ContactDetail[];
    /**
     * A description of the kind of resource the activity definition is representing. For example, a MedicationRequest, a ServiceRequest, or a CommunicationRequest.
     *
     * Kind of resource
     */
    kind?: string;
    /**
     * The timing or frequency upon which the described activity is to occur.
     *
     * When activity is to occur
     */
    timing?: Timing | Age | Range | Duration;
    /**
     * A reference to a Library resource containing any formal logic used by the activity definition.
     *
     * Logic used by the activity definition
     */
    library?: string[];
    /**
     * Dynamic values that will be evaluated to produce values for elements of the resulting resource. For example, if the dosage of a medication must be computed based on the patient's weight, a dynamic value would be used to specify an expression that calculated the weight, and the path on the request resource that would contain the result.
     *
     * Dynamic aspects of the definition
     */
    dynamicValue?: ActivityDefinition.ActivityDefinitionDynamicValueComponent[];
    /**
     * A reference to a StructureMap resource that defines a transform that can be executed to produce the intent resource using the ActivityDefinition instance as the input.
     *
     * Transform to apply the template
     */
    transform?: string;
    /**
     * A free text natural language description of the activity definition from a consumer's perspective.
     *
     * Natural language description of the activity definition
     */
    description?: string;
    /**
     * Defines specimen requirements for the action to be performed, such as required specimens for a lab test.
     *
     * What specimens are required to perform this action
     */
    specimenRequirement?: string[];
    /**
     * A short, descriptive, user-friendly title for the activity definition.
     *
     * Name for this activity definition (human friendly)
     */
    title?: string;
    /**
     * Provides detailed dosage instructions in the same way that they are described for MedicationRequest resources.
     *
     * Detailed dosage instructions
     */
    dosage?: Dosage[];
    /**
     * The date on which the resource content was approved by the publisher. Approval happens once when the content is officially approved for usage.
     *
     * When the activity definition was approved by publisher
     */
    approvalDate?: Date;
    /**
     * Detailed description of the type of activity; e.g. What lab test, what procedure, what kind of encounter.
     *
     * Detail type of activity
     */
    code?: CodeableConcept;
    /**
     * Explanation of why this activity definition is needed and why it has been designed as it has.
     *
     * Why this activity definition is defined
     */
    purpose?: string;
    /**
     * A legal or geographic region in which the activity definition is intended to be used.
     *
     * Intended jurisdiction for activity definition (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * Identifies the facility where the activity will occur; e.g. home, hospital, specific clinic, etc.
     *
     * Where it should happen
     */
    location?: CodeableReference;
    /**
     * Indicates the sites on the subject's body where the procedure should be performed (I.e. the target sites).
     *
     * What part of body to perform on
     */
    bodySite?: CodeableConcept[];
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * An individual or organization asserted by the publisher to be primarily responsible for review of some aspect of the content.
     *
     * Who reviewed the content
     */
    reviewer?: ContactDetail[];
    /**
     * Indicates the level of authority/intentionality associated with the activity and where the request should fit into the workflow chain.
     *
     * proposal | plan | directive | order | original-order | reflex-order | filler-order | instance-order | option
     */
    intent?: string;
    /**
     * An absolute URI that is used to identify this activity definition when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this activity definition is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the activity definition is stored on different servers.
     *
     * Canonical identifier for this activity definition, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * Defines observation requirements for the action to be performed, such as body weight or surface area.
     *
     * What observations are required to perform this action
     */
    observationRequirement?: string[];
    /**
     * An individual or organization primarily responsible for internal coherence of the content.
     *
     * Who edited the content
     */
    editor?: ContactDetail[];
    /**
     * Identifies the quantity expected to be consumed at once (per dose, per meal, etc.).
     *
     * How much is administered/consumed/supplied
     */
    quantity?: Quantity;
    /**
     * Identifies the food, drug or other product being consumed or supplied in the activity.
     *
     * What's administered/supplied
     */
    product?: Medication | Ingredient | Substance | SubstanceDefinition | CodeableConcept | Reference;
    readonly resourceType: string;
    static revive(json: any): ActivityDefinition;
    toJSON(): any;
}
export declare namespace ActivityDefinition {
    enum RequestResourceTypes {
        SERVICEREQUEST,
        TASK,
        NULL,
        MEDICATIONREQUEST,
        ENROLLMENTREQUEST,
        IMMUNIZATIONRECOMMENDATION,
        CLAIM,
        DEVICEREQUEST,
        TRANSPORT,
        SUPPLYREQUEST,
        APPOINTMENT,
        NUTRITIONORDER,
        VISIONPRESCRIPTION,
        CAREPLAN,
        APPOINTMENTRESPONSE,
        COMMUNICATIONREQUEST,
        COVERAGEELIGIBILITYREQUEST,
        REQUESTORCHESTRATION
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    enum RequestIntent {
        ORDER,
        FILLERORDER,
        ORIGINALORDER,
        NULL,
        REFLEXORDER,
        DIRECTIVE,
        OPTION,
        PROPOSAL,
        PLAN,
        INSTANCEORDER
    }
    enum RequestPriority {
        URGENT,
        STAT,
        NULL,
        ROUTINE,
        ASAP
    }
    class ActivityDefinitionDynamicValueComponent extends BackboneElement {
        /**
         * An expression specifying the value of the customized element.
         *
         * An expression that provides the dynamic value for the customization
         */
        expression: Expression;
        /**
         * The path to the element to be customized. This is the path on the resource that will hold the result of the calculation defined by the expression. The specified path SHALL be a FHIRPath resolvable on the specified target type of the ActivityDefinition, and SHALL consist only of identifiers, constant indexers, and a restricted subset of functions. The path is allowed to contain qualifiers (.) to traverse sub-elements, as well as indexers ([x]) to traverse multiple-cardinality sub-elements (see the [Simple FHIRPath Profile](fhirpath.html#simple) for full details).
         *
         * The path to the element to be set dynamically
         */
        path: string;
        static revive(json: any): ActivityDefinitionDynamicValueComponent;
        toJSON(): any;
    }
    class ActivityDefinitionParticipantComponent extends BackboneElement {
        /**
         * The type of participant in the action.
         *
         * Who or what can participate
         */
        typeReference?: CareTeam | Device | DeviceDefinition | Endpoint | Group | HealthcareService | Location | Organization | Patient | Practitioner | PractitionerRole | RelatedPerson | Reference;
        /**
         * The type of participant in the action.
         *
         * careteam | device | group | healthcareservice | location | organization | patient | practitioner | practitionerrole | relatedperson
         */
        type?: string;
        /**
         * The role the participant should play in performing the described action.
         *
         * E.g. Nurse, Surgeon, Parent, etc
         */
        role?: CodeableConcept;
        /**
         * Indicates how the actor will be involved in the action - author, reviewer, witness, etc.
         *
         * E.g. Author, Reviewer, Witness, etc
         */
        function?: CodeableConcept;
        /**
         * The type of participant in the action.
         *
         * Who or what can participate
         */
        typeCanonical?: string;
        static revive(json: any): ActivityDefinitionParticipantComponent;
        toJSON(): any;
    }
}
