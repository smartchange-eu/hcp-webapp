import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Money } from '../datatype/money';
import { Period } from '../datatype/period';
import { Account } from '../model/account';
import { ChargeItem } from '../model/charge-item';
import { Claim } from '../model/claim';
import { ClaimResponse } from '../model/claim-response';
import { Contract } from '../model/contract';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Invoice } from '../model/invoice';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
import { Task } from '../model/task';
/**
 * HAPI/FHIR <b>PaymentReconciliation</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/PaymentReconciliation">http://hl7.org/fhir/StructureDefinition/PaymentReconciliation</a>
 * </p>
 *
 */
export declare class PaymentReconciliation extends DomainResource {
    /**
     * Issuer's unique identifier for the payment instrument.
     *
     * Business identifier for the payment
     */
    paymentIdentifier?: Identifier;
    /**
     * A human readable description of the status of the request for the reconciliation.
     *
     * Disposition message
     */
    disposition?: string;
    /**
     * The status of the resource instance.
     *
     * active | cancelled | draft | entered-in-error
     */
    status: string;
    /**
     * The amount returned by the receiver which is excess to the amount payable, often referred to as 'change'.
     *
     * Amount returned by the receiver
     */
    returnedAmount?: Money;
    /**
     * The location of the site or device for electronic transfers or physical location for cash payments.
     *
     * Where payment collected
     */
    location?: Location | Reference;
    /**
     * The workflow or activity which gave rise to or during which the payment ocurred such as a kiosk, deposit on account, periodic payment etc.
     *
     * Workflow originating payment
     */
    kind?: CodeableConcept;
    /**
     * The date when the resource was created.
     *
     * Creation date
     */
    created: Date;
    /**
     * A code for the form to be used for printing the content.
     *
     * Printed form identifier
     */
    formCode?: CodeableConcept;
    /**
     * The means of payment such as check, card cash, or electronic funds transfer.
     *
     * Payment instrument
     */
    method?: CodeableConcept;
    /**
     * The period of time for which payments have been gathered into this bulk payment for settlement.
     *
     * Period covered
     */
    period?: Period;
    /**
     * Total payment amount as indicated on the financial instrument.
     *
     * Total amount of Payment
     */
    amount: Money;
    /**
     * Distribution of the payment amount for a previously acknowledged payable.
     *
     * Settlement particulars
     */
    allocation?: PaymentReconciliation.PaymentReconciliationAllocationComponent[];
    /**
     * A unique identifier assigned to this payment reconciliation.
     *
     * Business Identifier for a payment reconciliation
     */
    identifier?: Identifier[];
    /**
     * The party who generated the payment.
     *
     * Party generating payment
     */
    paymentIssuer?: Organization | Patient | RelatedPerson | Reference;
    /**
     * The practitioner who is responsible for the services rendered to the patient.
     *
     * Responsible practitioner
     */
    requestor?: Practitioner | PractitionerRole | Organization | Reference;
    /**
     * The name of the card processor, etf processor, bank for checks.
     *
     * Processor name
     */
    processor?: string;
    /**
     * A portion of the account number, often the last 4 digits, used for verification not charging purposes.
     *
     * Digits for verification
     */
    accountNumber?: string;
    /**
     * The type of the source such as patient or insurance.
     *
     * Nature of the source
     */
    issuerType?: CodeableConcept;
    /**
     * The check number, eft reference, car processor reference.
     *
     * Check number or payment reference
     */
    referenceNumber?: string;
    /**
     * An alphanumeric issued by the processor to confirm the successful issuance of payment.
     *
     * Authorization number
     */
    authorization?: string;
    /**
     * The year and month (YYYY-MM) when the instrument, typically card, expires.
     *
     * Expiration year-month
     */
    expirationDate?: Date;
    /**
     * The outcome of a request for a reconciliation.
     *
     * queued | complete | error | partial
     */
    outcome?: string;
    /**
     * The card brand such as debit, Visa, Amex etc. used if a card is the method of payment.
     *
     * Type of card
     */
    cardBrand?: string;
    /**
     * Payment enterer if not the actual payment issuer.
     *
     * Who entered the payment
     */
    enterer?: Practitioner | PractitionerRole | Organization | Reference;
    /**
     * The amount offered by the issuer, typically applies to cash when the issuer provides an amount in bank note denominations equal to or excess of the amount actually being paid.
     *
     * Amount offered by the issuer
     */
    tenderedAmount?: Money;
    /**
     * Original request resource reference.
     *
     * Reference to requesting resource
     */
    request?: Task | Reference;
    /**
     * The date of payment as indicated on the financial instrument.
     *
     * When payment issued
     */
    date: Date;
    /**
     * A note that describes or explains the processing in a human readable form.
     *
     * Note concerning processing
     */
    processNote?: PaymentReconciliation.NotesComponent[];
    /**
     * Code to indicate the nature of the payment such as payment, adjustment.
     *
     * Category of payment
     */
    type: CodeableConcept;
    readonly resourceType: string;
    static revive(json: any): PaymentReconciliation;
    toJSON(): any;
}
export declare namespace PaymentReconciliation {
    enum PaymentOutcome {
        COMPLETE,
        NULL,
        QUEUED,
        PARTIAL,
        ERROR
    }
    enum NoteType {
        PRINT,
        DISPLAY,
        PRINTOPER,
        NULL
    }
    enum FinancialResourceStatusCodes {
        CANCELLED,
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        DRAFT
    }
    class NotesComponent extends BackboneElement {
        /**
         * The business purpose of the note text.
         *
         * display | print | printoper
         */
        type?: string;
        /**
         * The explanation or description associated with the processing.
         *
         * Note explanatory text
         */
        text?: string;
        static revive(json: any): NotesComponent;
        toJSON(): any;
    }
    class PaymentReconciliationAllocationComponent extends BackboneElement {
        /**
         * The monetary amount allocated from the total payment to the payable.
         *
         * Amount allocated to this payable
         */
        amount?: Money;
        /**
         * Unique identifier for the current payment item for the referenced payable.
         *
         * Business identifier of the payment detail
         */
        identifier?: Identifier;
        /**
         * The party which submitted the claim or financial transaction.
         *
         * Submitter of the request
         */
        submitter?: Practitioner | PractitionerRole | Organization | Reference;
        /**
         * The date from the response resource containing a commitment to pay.
         *
         * Date of commitment to pay
         */
        date?: Date;
        /**
         * Unique identifier for the prior payment item for the referenced payable.
         *
         * Business identifier of the prior payment detail
         */
        predecessor?: Identifier;
        /**
         * The Encounter to which this payment applies, may be completed by the receiver, used for search.
         *
         * Applied-to encounter
         */
        encounter?: Encounter | Reference;
        /**
         * Specific resource to which the payment/adjustment/advance applies.
         *
         * Subject of the payment
         */
        target?: Claim | Account | Invoice | ChargeItem | Encounter | Contract | Reference;
        /**
         * Code to indicate the nature of the payment.
         *
         * Category of payment
         */
        type?: CodeableConcept;
        /**
         * The party which is receiving the payment.
         *
         * Recipient of the payment
         */
        payee?: Practitioner | PractitionerRole | Organization | Reference;
        /**
         * A reference to the individual who is responsible for inquiries regarding the response and its payment.
         *
         * Contact for the response
         */
        responsible?: PractitionerRole | Reference;
        /**
         * A resource, such as a ClaimResponse, which contains a commitment to payment.
         *
         * Response committing to a payment
         */
        response?: ClaimResponse | Reference;
        /**
         *  Identifies the claim line item, encounter or other sub-element being paid. Note payment may be partial, that is not match the then outstanding balance or amount incurred.
         *
         * Sub-element of the subject
         */
        targetItem?: string | Identifier | number;
        /**
         * The Account to which this payment applies, may be completed by the receiver, used for search.
         *
         * Applied-to account
         */
        account?: Account | Reference;
        static revive(json: any): PaymentReconciliationAllocationComponent;
        toJSON(): any;
    }
}
