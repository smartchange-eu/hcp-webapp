import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { Timing } from '../datatype/timing';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { HealthcareService } from '../model/healthcare-service';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>SupplyRequest</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/SupplyRequest">http://hl7.org/fhir/StructureDefinition/SupplyRequest</a>
 * </p>
 *
 */
export declare class SupplyRequest extends DomainResource {
    /**
     * Specific parameters for the ordered item.  For example, the size of the indicated item.
     *
     * Ordered item details
     */
    parameter?: SupplyRequest.SupplyRequestParameterComponent[];
    /**
     * Who is intended to fulfill the request.
     *
     * Who is intended to fulfill the request
     */
    supplier?: Organization[] | HealthcareService[] | Reference[];
    /**
     * Plan/proposal/order fulfilled by this request.
     *
     * What other request is fulfilled by this supply request
     */
    basedOn?: Reference[];
    /**
     * Status of the supply request.
     *
     * draft | active | suspended +
     */
    status?: string;
    /**
     * Category of supply, e.g.  central, non-stock, etc. This is used to support work flows associated with the supply process.
     *
     * The kind of supply (central, non-stock, etc.)
     */
    category?: CodeableConcept;
    /**
     * The patient to whom the supply will be given or for whom they will be used.
     *
     * The patient for who the supply request is for
     */
    deliverFor?: Patient | Reference;
    /**
     * Where the supply is expected to come from.
     *
     * The origin of the supply
     */
    deliverFrom?: Organization | Location | Reference;
    /**
     * The item that is requested to be supplied. This is either a link to a resource representing the details of the item or a code that identifies the item from a known list.
     *
     * Medication, Substance, or Device requested to be supplied
     */
    item: CodeableReference;
    /**
     * The amount that is being ordered of the indicated item.
     *
     * The requested amount of the item indicated
     */
    quantity: Quantity;
    /**
     * When the request was made.
     *
     * When the request was made
     */
    authoredOn?: Date;
    /**
     * The device, practitioner, etc. who initiated the request.
     *
     * Individual making the request
     */
    requester?: Practitioner | PractitionerRole | Organization | Patient | RelatedPerson | Device | CareTeam | Reference;
    /**
     * Business identifiers assigned to this SupplyRequest by the author and/or other systems. These identifiers remain constant as the resource is updated and propagates from server to server.
     *
     * Business Identifier for SupplyRequest
     */
    identifier?: Identifier[];
    /**
     * The reason why the supply item was requested.
     *
     * The reason why the supply item was requested
     */
    reason?: CodeableReference[];
    /**
     * Where the supply is destined to go.
     *
     * The destination of the supply
     */
    deliverTo?: Organization | Location | Patient | RelatedPerson | Reference;
    /**
     * Indicates how quickly this SupplyRequest should be addressed with respect to other requests.
     *
     * routine | urgent | asap | stat
     */
    priority?: string;
    /**
     * When the request should be fulfilled.
     *
     * When the request should be fulfilled
     */
    occurrence?: Date | Period | Timing;
    readonly resourceType: string;
    static revive(json: any): SupplyRequest;
    toJSON(): any;
}
export declare namespace SupplyRequest {
    enum SupplyRequestStatus {
        CANCELLED,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ACTIVE,
        DRAFT,
        SUSPENDED,
        UNKNOWN
    }
    enum RequestPriority {
        URGENT,
        STAT,
        NULL,
        ROUTINE,
        ASAP
    }
    class SupplyRequestParameterComponent extends BackboneElement {
        /**
         * A code or string that identifies the device detail being asserted.
         *
         * Item detail
         */
        code?: CodeableConcept;
        /**
         * The value of the device detail.
         *
         * Value of detail
         */
        value?: CodeableConcept | Quantity | Range | boolean;
        static revive(json: any): SupplyRequestParameterComponent;
        toJSON(): any;
    }
}
