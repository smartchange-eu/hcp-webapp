import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { UsageContext } from '../datatype/usage-context';
import { CareTeam } from '../model/care-team';
import { MetadataResource } from '../model/metadata-resource';
import { PlanDefinition } from '../model/plan-definition';
import { Questionnaire } from '../model/questionnaire';
/**
 * HAPI/FHIR <b>ConditionDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ConditionDefinition">http://hl7.org/fhir/StructureDefinition/ConditionDefinition</a>
 * </p>
 *
 */
export declare class ConditionDefinition extends MetadataResource {
    /**
     * Formal definitions of the condition. These may be references to ontologies, published clinical protocols or research papers.
     *
     * Formal Definition for the condition
     */
    definition?: string[];
    /**
     * Plan that is appropriate.
     *
     * Plan that is appropriate
     */
    plan?: ConditionDefinition.ConditionDefinitionPlanComponent[];
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * Whether bodySite is appropriate to collect for this condition.
     *
     * Whether bodySite is appropriate
     */
    hasBodySite?: boolean;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * A Boolean value to indicate that this condition definition is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A free text natural language description of the condition definition from a consumer's perspective.
     *
     * Natural language description of the condition definition
     */
    description?: string;
    /**
     * A short, descriptive, user-friendly title for the condition definition.
     *
     * Name for this condition definition (human friendly)
     */
    title?: string;
    /**
     * Questionnaire for this condition.
     *
     * Questionnaire for this condition
     */
    questionnaire?: ConditionDefinition.ConditionDefinitionQuestionnaireComponent[];
    /**
     * Identification of the condition, problem or diagnosis.
     *
     * Identification of the condition, problem or diagnosis
     */
    code: CodeableConcept;
    /**
     * The date  (and optionally time) when the condition definition was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the condition definition changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * Whether Severity is appropriate to collect for this condition.
     *
     * Whether Severity is appropriate
     */
    hasSeverity?: boolean;
    /**
     * A legal or geographic region in which the condition definition is intended to be used.
     *
     * Intended jurisdiction for condition definition (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * A natural language name identifying the condition definition. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this condition definition (computer friendly)
     */
    name?: string;
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the condition definition.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * The status of this condition definition. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * Whether stage is appropriate to collect for this condition.
     *
     * Whether stage is appropriate
     */
    hasStage?: boolean;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate condition definition instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * The anatomical location where this condition manifests itself.
     *
     * Anatomical location, if relevant
     */
    bodySite?: CodeableConcept;
    /**
     * An explanatory or alternate title for the event definition giving additional information about its content.
     *
     * Subordinate title of the event definition
     */
    subtitle?: string;
    /**
     * Clinical stage or grade of a condition. May include formal severity assessments.
     *
     * Stage/grade, usually assessed formally
     */
    stage?: CodeableConcept;
    /**
     * Medications particularly relevant for this condition.
     *
     * Medications particularly relevant for this condition
     */
    medication?: ConditionDefinition.ConditionDefinitionMedicationComponent[];
    /**
     * An observation that suggests that this condition applies.
     *
     * Observation that suggets this condition
     */
    precondition?: ConditionDefinition.ConditionDefinitionPreconditionComponent[];
    /**
     * Appropriate team for this condition.
     *
     * Appropriate team for this condition
     */
    team?: CareTeam[] | Reference[];
    /**
     * An absolute URI that is used to identify this condition definition when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this condition definition is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the condition definition is stored on different servers.
     *
     * Canonical identifier for this condition definition, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * The identifier that is used to identify this version of the condition definition when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the condition definition author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the condition definition
     */
    version?: string;
    /**
     * A subjective assessment of the severity of the condition as evaluated by the clinician.
     *
     * Subjective severity of condition
     */
    severity?: CodeableConcept;
    /**
     * A formal identifier that is used to identify this condition definition when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the condition definition
     */
    identifier?: Identifier[];
    /**
     * Observations particularly relevant to this condition.
     *
     * Observations particularly relevant to this condition
     */
    observation?: ConditionDefinition.ConditionDefinitionObservationComponent[];
    readonly resourceType: string;
    static revive(json: any): ConditionDefinition;
    toJSON(): any;
}
export declare namespace ConditionDefinition {
    enum ConditionQuestionnairePurpose {
        NULL,
        OUTCOME,
        DIFFDIAGNOSIS,
        PREADMIT
    }
    enum ConditionPreconditionType {
        SENSITIVE,
        NULL,
        SPECIFIC
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class ConditionDefinitionPlanComponent extends BackboneElement {
        /**
         * Use for the plan.
         *
         * Use for the plan
         */
        role?: CodeableConcept;
        /**
         * The actual plan.
         *
         * The actual plan
         */
        reference: PlanDefinition | Reference;
        static revive(json: any): ConditionDefinitionPlanComponent;
        toJSON(): any;
    }
    class ConditionDefinitionQuestionnaireComponent extends BackboneElement {
        /**
         * Use of the questionnaire.
         *
         * preadmit | diff-diagnosis | outcome
         */
        purpose: string;
        /**
         * Specific Questionnaire.
         *
         * Specific Questionnaire
         */
        reference: Questionnaire | Reference;
        static revive(json: any): ConditionDefinitionQuestionnaireComponent;
        toJSON(): any;
    }
    class ConditionDefinitionPreconditionComponent extends BackboneElement {
        /**
         * Code for relevant Observation.
         *
         * Code for relevant Observation
         */
        code: CodeableConcept;
        /**
         * Value of Observation.
         *
         * Value of Observation
         */
        value?: CodeableConcept | Quantity;
        /**
         * Kind of pre-condition.
         *
         * sensitive | specific
         */
        type: string;
        static revive(json: any): ConditionDefinitionPreconditionComponent;
        toJSON(): any;
    }
    class ConditionDefinitionMedicationComponent extends BackboneElement {
        /**
         * Category that is relevant.
         *
         * Category that is relevant
         */
        category?: CodeableConcept;
        /**
         * Code for relevant Medication.
         *
         * Code for relevant Medication
         */
        code?: CodeableConcept;
        static revive(json: any): ConditionDefinitionMedicationComponent;
        toJSON(): any;
    }
    class ConditionDefinitionObservationComponent extends BackboneElement {
        /**
         * Code for relevant Observation.
         *
         * Code for relevant Observation
         */
        code?: CodeableConcept;
        /**
         * Category that is relevant.
         *
         * Category that is relevant
         */
        category?: CodeableConcept;
        static revive(json: any): ConditionDefinitionObservationComponent;
        toJSON(): any;
    }
}
