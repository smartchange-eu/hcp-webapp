import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { UsageContext } from '../datatype/usage-context';
import { CanonicalResource } from '../model/canonical-resource';
/**
 * HAPI/FHIR <b>ActorDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ActorDefinition">http://hl7.org/fhir/StructureDefinition/ActorDefinition</a>
 * </p>
 *
 */
export declare class ActorDefinition extends CanonicalResource {
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the actor definition.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * A natural language name identifying the actor definition. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this actor definition (computer friendly)
     */
    name?: string;
    /**
     * A url that identifies the definition of this actor in another IG (which IG must be listed in the dependencies). This actor inherits all the obligations etc. as defined in the other IG.
     *
     * Definition of this actor in another context / IG
     */
    derivedFrom?: string[];
    /**
     * The status of this actor definition. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate actor definition instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * A reference to additional documentation about the actor, but description and documentation.
     *
     * Reference to more information about the actor
     */
    reference?: string[];
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * A Boolean value to indicate that this actor definition is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A free text natural language description of the actor.
     *
     * Natural language description of the actor
     */
    description?: string;
    /**
     * An absolute URI that is used to identify this actor definition when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this actor definition is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the actor definition is stored on different servers.
     *
     * Canonical identifier for this actor definition, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * The identifier that is used to identify this version of the actor definition when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the actor definition author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the actor definition
     */
    version?: string;
    /**
     * A short, descriptive, user-friendly title for the actor definition.
     *
     * Name for this actor definition (human friendly)
     */
    title?: string;
    /**
     * Whether the actor represents a human or an appliction.
     *
     * person | system
     */
    type: string;
    /**
     * The capability statement for the actor (if the concept is applicable).
     *
     * CapabilityStatement for the actor (if applicable)
     */
    capabilities?: string;
    /**
     * A copyright statement relating to the actor definition and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the actor definition.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * A formal identifier that is used to identify this actor definition when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the actor definition (business identifier)
     */
    identifier?: Identifier[];
    /**
     * The date  (and optionally time) when the actor definition was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the actor definition changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * A legal or geographic region in which the actor definition is intended to be used.
     *
     * Intended jurisdiction for actor definition (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * Documentation about the functionality of the actor.
     *
     * Functionality associated with the actor
     */
    documentation?: string;
    /**
     * Explanation of why this actor definition is needed and why it has been designed as it has.
     *
     * Why this actor definition is defined
     */
    purpose?: string;
    readonly resourceType: string;
    static revive(json: any): ActorDefinition;
    toJSON(): any;
}
export declare namespace ActorDefinition {
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    enum ExampleScenarioActorType {
        SYSTEM,
        PERSON,
        NULL
    }
}
