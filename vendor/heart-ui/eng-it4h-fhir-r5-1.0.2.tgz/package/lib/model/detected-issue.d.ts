import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { BiologicallyDerivedProduct } from '../model/biologically-derived-product';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { Location } from '../model/location';
import { Medication } from '../model/medication';
import { NutritionProduct } from '../model/nutrition-product';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Procedure } from '../model/procedure';
import { RelatedPerson } from '../model/related-person';
import { Substance } from '../model/substance';
/**
 * HAPI/FHIR <b>DetectedIssue</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/DetectedIssue">http://hl7.org/fhir/StructureDefinition/DetectedIssue</a>
 * </p>
 *
 */
export declare class DetectedIssue extends DomainResource {
    /**
     * Indicates the status of the detected issue.
     *
     * preliminary | final | entered-in-error | mitigated
     */
    status: string;
    /**
     * A code that classifies the general type of detected issue.
     *
     * Type of detected issue, e.g. drug-drug, duplicate therapy, etc
     */
    category?: CodeableConcept[];
    /**
     * A textual explanation of the detected issue.
     *
     * Description and context
     */
    detail?: string;
    /**
     * Indicates the resource representing the current activity or proposed activity that is potentially problematic.
     *
     * Problem resource
     */
    implicated?: Reference[];
    /**
     * The date or period when the detected issue was initially identified.
     *
     * When identified
     */
    identified?: Date | Period;
    /**
     * The literature, knowledge-base or similar reference that describes the propensity for the detected issue identified.
     *
     * Authority for issue
     */
    reference?: string;
    /**
     * The encounter during which this issue was detected.
     *
     * Encounter detected issue is part of
     */
    encounter?: Encounter | Reference;
    /**
     * Indicates the subject whose record the detected issue is associated with.
     *
     * Associated subject
     */
    subject?: Patient | Group | Device | Location | Organization | Procedure | Practitioner | Medication | Substance | BiologicallyDerivedProduct | NutritionProduct | Reference;
    /**
     * Individual or device responsible for the issue being raised.  For example, a decision support application or a pharmacist conducting a medication review.
     *
     * The provider or device that identified the issue
     */
    author?: Patient | RelatedPerson | Practitioner | PractitionerRole | Device | Reference;
    /**
     * Supporting evidence or manifestations that provide the basis for identifying the detected issue such as a GuidanceResponse or MeasureReport.
     *
     * Supporting evidence
     */
    evidence?: DetectedIssue.DetectedIssueEvidenceComponent[];
    /**
     * Identifies the specific type of issue identified.
     *
     * Specific type of detected issue, e.g. drug-drug, duplicate therapy, etc
     */
    code?: CodeableConcept;
    /**
     * Indicates an action that has been taken or is committed to reduce or eliminate the likelihood of the risk identified by the detected issue from manifesting.  Can also reflect an observation of known mitigating factors that may reduce/eliminate the need for any action.
     *
     * Step taken to address
     */
    mitigation?: DetectedIssue.DetectedIssueMitigationComponent[];
    /**
     * Business identifier associated with the detected issue record.
     *
     * Unique id for the detected issue
     */
    identifier?: Identifier[];
    /**
     * Indicates the degree of importance associated with the identified issue based on the potential impact on the patient.
     *
     * high | moderate | low
     */
    severity?: string;
    readonly resourceType: string;
    static revive(json: any): DetectedIssue;
    toJSON(): any;
}
export declare namespace DetectedIssue {
    enum DetectedIssueStatus {
        ENTEREDINERROR,
        NULL,
        MITIGATED,
        PRELIMINARY,
        FINAL
    }
    enum DetectedIssueSeverity {
        MODERATE,
        HIGH,
        NULL,
        LOW
    }
    class DetectedIssueMitigationComponent extends BackboneElement {
        /**
         * Describes the action that was taken or the observation that was made that reduces/eliminates the risk associated with the identified issue.
         *
         * What mitigation?
         */
        action: CodeableConcept;
        /**
         * Clinicians may add additional notes or justifications about the mitigation action. For example, patient can have this drug because they have had it before without any issues. Multiple justifications may be provided.
         *
         * Additional notes about the mitigation
         */
        note?: Annotation[];
        /**
         * Indicates when the mitigating action was documented.
         *
         * Date committed
         */
        date?: Date;
        /**
         * Identifies the practitioner who determined the mitigation and takes responsibility for the mitigation step occurring.
         *
         * Who is committing?
         */
        author?: Practitioner | PractitionerRole | Reference;
        static revive(json: any): DetectedIssueMitigationComponent;
        toJSON(): any;
    }
    class DetectedIssueEvidenceComponent extends BackboneElement {
        /**
         * Links to resources that constitute evidence for the detected issue such as a GuidanceResponse or MeasureReport.
         *
         * Supporting information
         */
        detail?: Reference[];
        /**
         * A manifestation that led to the recording of this detected issue.
         *
         * Manifestation
         */
        code?: CodeableConcept[];
        static revive(json: any): DetectedIssueEvidenceComponent;
        toJSON(): any;
    }
}
