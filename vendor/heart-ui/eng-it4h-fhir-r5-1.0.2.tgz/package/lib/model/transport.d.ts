import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Address } from '../datatype/address';
import { Age } from '../datatype/age';
import { Annotation } from '../datatype/annotation';
import { Attachment } from '../datatype/attachment';
import { Availability } from '../datatype/availability';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { ContactPoint } from '../datatype/contact-point';
import { Count } from '../datatype/count';
import { DataRequirement } from '../datatype/data-requirement';
import { Distance } from '../datatype/distance';
import { Dosage } from '../datatype/dosage';
import { Duration } from '../datatype/duration';
import { Expression } from '../datatype/expression';
import { ExtendedContactDetail } from '../datatype/extended-contact-detail';
import { HumanName } from '../datatype/human-name';
import { Identifier } from '../datatype/identifier';
import { Meta } from '../datatype/meta';
import { Money } from '../datatype/money';
import { ParameterDefinition } from '../datatype/parameter-definition';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { Ratio } from '../datatype/ratio';
import { RatioRange } from '../datatype/ratio-range';
import { RelatedArtifact } from '../datatype/related-artifact';
import { SampledData } from '../datatype/sampled-data';
import { Signature } from '../datatype/signature';
import { Timing } from '../datatype/timing';
import { TriggerDefinition } from '../datatype/trigger-definition';
import { UsageContext } from '../datatype/usage-context';
import { CareTeam } from '../model/care-team';
import { ClaimResponse } from '../model/claim-response';
import { Coverage } from '../model/coverage';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Provenance } from '../model/provenance';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Transport</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Transport">http://hl7.org/fhir/StructureDefinition/Transport</a>
 * </p>
 *
 */
export declare class Transport extends DomainResource {
    /**
     * Identifies the completion time of the event (the occurrence).
     *
     * Completion time of the event (the occurrence)
     */
    completionTime?: Date;
    /**
     * Outputs produced by the Transport.
     *
     * Information produced as part of transport
     */
    output?: Transport.TransportOutputComponent[];
    /**
     * An explanation as to why this transport is held, failed, was refused, etc.
     *
     * Reason for current status
     */
    statusReason?: CodeableConcept;
    /**
     * BasedOn refers to a higher-level authorization that triggered the creation of the transport.  It references a "request" resource such as a ServiceRequest or Transport, which is distinct from the "request" resource the Transport is seeking to fulfill.  This latter resource is referenced by FocusOn.  For example, based on a ServiceRequest (= BasedOn), a transport is created to fulfill a procedureRequest ( = FocusOn ) to transport a specimen to the lab.
     *
     * Request fulfilled by this transport
     */
    basedOn?: Reference[];
    /**
     * A larger event of which this particular event is a component or step.
     *
     * Part of referenced event
     */
    partOf?: Transport[] | Reference[];
    /**
     * Free-text information captured about the transport as it progresses.
     *
     * Comments made about the transport
     */
    note?: Annotation[];
    /**
     * A resource reference indicating why this transport needs to be performed.
     *
     * Why transport is needed
     */
    reason?: CodeableReference;
    /**
     * Insurance plans, coverage extensions, pre-authorizations and/or pre-determinations that may be relevant to the Transport.
     *
     * Associated insurance coverage
     */
    insurance?: Coverage[] | ClaimResponse[] | Reference[];
    /**
     * A name or code (or both) briefly describing what the transport involves.
     *
     * Transport Type
     */
    code?: CodeableConcept;
    /**
     * The entity who benefits from the performance of the service specified in the transport (e.g., the patient).
     *
     * Beneficiary of the Transport
     */
    for?: Reference;
    /**
     * A free-text description of what is to be performed.
     *
     * Human-readable explanation of transport
     */
    description?: string;
    /**
     * The request being actioned or the resource being manipulated by this transport.
     *
     * What transport is acting on
     */
    focus?: Reference;
    /**
     * The URL pointing to an *externally* maintained  protocol, guideline, orderset or other definition that is adhered to in whole or in part by this Transport.
     *
     * Formal definition of transport
     */
    instantiatesUri?: string;
    /**
     * Links to Provenance records for past versions of this Transport that identify key state transitions or updates that are likely to be relevant to a user looking at the current version of the transport.
     *
     * Key events in history of the Transport
     */
    relevantHistory?: Provenance[] | Reference[];
    /**
     * Additional information that may be needed in the execution of the transport.
     *
     * Information used to perform transport
     */
    input?: Transport.ParameterComponent[];
    /**
     * If the Transport.focus is a request resource and the transport is seeking fulfillment (i.e. is asking for the request to be actioned), this element identifies any limitations on what parts of the referenced request should be actioned.
     *
     * Constraints on fulfillment transports
     */
    restriction?: Transport.TransportRestrictionComponent;
    /**
     * The date and time of last modification to this transport.
     *
     * Transport Last Modified Date
     */
    lastModified?: Date;
    /**
     * Principal physical location where this transport is performed.
     *
     * Where transport occurs
     */
    location?: Location | Reference;
    /**
     * A shared identifier common to multiple independent Request instances that were activated/authorized more or less simultaneously by a single author.  The presence of the same identifier on each request ties those requests together and may have business ramifications in terms of reporting of results, billing, etc.  E.g. a requisition number shared by a set of lab tests ordered together, or a prescription number shared by all meds ordered at one time.
     *
     * Requisition or grouper id
     */
    groupIdentifier?: Identifier;
    /**
     * A code specifying the state of the transport event.
     *
     * in-progress | completed | abandoned | cancelled | planned | entered-in-error
     */
    status?: string;
    /**
     * Identifier for the transport event that is used to identify it across multiple disparate systems.
     *
     * External identifier
     */
    identifier?: Identifier[];
    /**
     * The creator of the transport.
     *
     * Who is asking for transport to be done
     */
    requester?: Device | Organization | Patient | Practitioner | PractitionerRole | RelatedPerson | Reference;
    /**
     * Individual organization or Device currently responsible for transport execution.
     *
     * Responsible individual
     */
    owner?: Practitioner | PractitionerRole | Organization | CareTeam | HealthcareService | Patient | Device | RelatedPerson | Reference;
    /**
     * The date and time this transport was created.
     *
     * Transport Creation Date
     */
    authoredOn?: Date;
    /**
     * The desired or final location for the transport.
     *
     * The desired location
     */
    requestedLocation: Location | Reference;
    /**
     * The healthcare event  (e.g. a patient and healthcare provider interaction) during which this transport was created.
     *
     * Healthcare event during which this transport originated
     */
    encounter?: Encounter | Reference;
    /**
     * The transport event prior to this one.
     *
     * Parent (or preceding) transport
     */
    history?: Transport | Reference;
    /**
     * Indicates the "level" of actionability associated with the Transport, i.e. i+R[9]Cs this a proposed transport, a planned transport, an actionable transport, etc.
     *
     * unknown | proposal | plan | order | original-order | reflex-order | filler-order | instance-order | option
     */
    intent: string;
    /**
     * The kind of participant that should perform the transport.
     *
     * Requested performer
     */
    performerType?: CodeableConcept[];
    /**
     * The URL pointing to a *FHIR*-defined protocol, guideline, orderset or other definition that is adhered to in whole or in part by this Transport.
     *
     * Formal definition of transport
     */
    instantiatesCanonical?: string;
    /**
     * Indicates how quickly the Transport should be addressed with respect to other requests.
     *
     * routine | urgent | asap | stat
     */
    priority?: string;
    /**
     * The current location for the entity to be transported.
     *
     * The entity current location
     */
    currentLocation: Location | Reference;
    readonly resourceType: string;
    static revive(json: any): Transport;
    toJSON(): any;
}
export declare namespace Transport {
    enum TransportStatus {
        CANCELLED,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ABANDONED,
        INPROGRESS,
        PLANNED
    }
    enum TransportIntent {
        ORDER,
        FILLERORDER,
        ORIGINALORDER,
        NULL,
        REFLEXORDER,
        OPTION,
        PROPOSAL,
        UNKNOWN,
        PLAN,
        INSTANCEORDER
    }
    enum RequestPriority {
        URGENT,
        STAT,
        NULL,
        ROUTINE,
        ASAP
    }
    class TransportOutputComponent extends BackboneElement {
        /**
         * The name of the Output parameter.
         *
         * Label for output
         */
        type: CodeableConcept;
        /**
         * The value of the Output parameter as a basic type.
         *
         * Result of output
         */
        value: string | boolean | Date | Date | number | number | number | Date | number | Address | Age | Annotation | Attachment | CodeableConcept | CodeableReference | Coding | ContactPoint | Count | Distance | Duration | HumanName | Identifier | Money | Period | Quantity | Range | Ratio | RatioRange | Reference | SampledData | Signature | Timing | ContactDetail | DataRequirement | Expression | ParameterDefinition | RelatedArtifact | TriggerDefinition | UsageContext | Availability | ExtendedContactDetail | Dosage | Meta;
        static revive(json: any): TransportOutputComponent;
        toJSON(): any;
    }
    class ParameterComponent extends BackboneElement {
        /**
         * A code or description indicating how the input is intended to be used as part of the transport execution.
         *
         * Label for the input
         */
        type: CodeableConcept;
        /**
         * The value of the input parameter as a basic type.
         *
         * Content to use in performing the transport
         */
        value: string | boolean | Date | Date | number | number | number | Date | number | Address | Age | Annotation | Attachment | CodeableConcept | CodeableReference | Coding | ContactPoint | Count | Distance | Duration | HumanName | Identifier | Money | Period | Quantity | Range | Ratio | RatioRange | Reference | SampledData | Signature | Timing | ContactDetail | DataRequirement | Expression | ParameterDefinition | RelatedArtifact | TriggerDefinition | UsageContext | Availability | ExtendedContactDetail | Dosage | Meta;
        static revive(json: any): ParameterComponent;
        toJSON(): any;
    }
    class TransportRestrictionComponent extends BackboneElement {
        /**
         * For requests that are targeted to more than one potential recipient/target, to identify who is fulfillment is sought for.
         *
         * For whom is fulfillment sought?
         */
        recipient?: Patient[] | Practitioner[] | PractitionerRole[] | RelatedPerson[] | Group[] | Organization[] | Reference[];
        /**
         * Indicates the number of times the requested action should occur.
         *
         * How many times to repeat
         */
        repetitions?: number;
        /**
         * Over what time-period is fulfillment sought.
         *
         * When fulfillment sought
         */
        period?: Period;
        static revive(json: any): TransportRestrictionComponent;
        toJSON(): any;
    }
}
