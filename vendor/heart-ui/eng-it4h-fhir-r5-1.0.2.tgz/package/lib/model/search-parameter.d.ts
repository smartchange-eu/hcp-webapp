import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { UsageContext } from '../datatype/usage-context';
import { CanonicalResource } from '../model/canonical-resource';
/**
 * HAPI/FHIR <b>SearchParameter</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/SearchParameter">http://hl7.org/fhir/StructureDefinition/SearchParameter</a>
 * </p>
 *
 */
export declare class SearchParameter extends CanonicalResource {
    /**
     * Where this search parameter is originally defined. If a derivedFrom is provided, then the details in the search parameter must be consistent with the definition from which it is defined. i.e. the parameter should have the same meaning, and (usually) the functionality should be a proper subset of the underlying search parameter.
     *
     * Original definition for the search parameter
     */
    derivedFrom?: string;
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * And how it used.
     *
     * Natural language description of the search parameter
     */
    description: string;
    /**
     * A Boolean value to indicate that this search parameter is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A short, descriptive, user-friendly title for the search parameter.
     *
     * Name for this search parameter (human friendly)
     */
    title?: string;
    /**
     * The type of value that a search parameter may contain, and how the content is interpreted.
     *
     * number | date | string | token | reference | composite | quantity | uri | special
     */
    type: string;
    /**
     * The date  (and optionally time) when the search parameter was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the search parameter changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * A copyright statement relating to the search parameter and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the search parameter.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * The label that is recommended to be used in the URL or the parameter name in a parameters resource for this search parameter.  In some cases, servers may need to use a different CapabilityStatement searchParam.name to differentiate between multiple SearchParameters that happen to have the same code.
     *
     * Recommended name for parameter in search url
     */
    code: string;
    /**
     * Explanation of why this search parameter is needed and why it has been designed as it has.
     *
     * Why this search parameter is defined
     */
    purpose?: string;
    /**
     * A legal or geographic region in which the search parameter is intended to be used.
     *
     * Intended jurisdiction for search parameter (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * A modifier supported for the search parameter.
     *
     * missing | exact | contains | not | text | in | not-in | below | above | type | identifier | of-type | code-text | text-advanced | iterate
     */
    modifier?: string[];
    /**
     * A natural language name identifying the search parameter. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this search parameter (computer friendly)
     */
    name: string;
    /**
     * The name of the organization or individual tresponsible for the release and ongoing maintenance of the search parameter.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * FHIRPath expression that defines/sets a complex constraint for when this SearchParameter is applicable.
     *
     * FHIRPath expression that constraints the usage of this SearchParamete
     */
    constraint?: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate search parameter instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * How the search parameter relates to the set of elements returned by evaluating the expression query.
     *
     * normal | phonetic | other
     */
    processingMode?: string;
    /**
     * The status of this search parameter. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The base resource type(s) that this search parameter can be used against.
     *
     * The resource type(s) this search parameter applies to
     */
    base: string[];
    /**
     * Comparators supported for the search parameter.
     *
     * eq | ne | gt | lt | ge | le | sa | eb | ap
     */
    comparator?: string[];
    /**
     * Used to define the parts of a composite search parameter.
     *
     * For Composite resources to define the parts
     */
    component?: SearchParameter.SearchParameterComponentComponent[];
    /**
     * Whether multiple values are allowed for each time the parameter exists. Values are separated by commas, and the parameter matches if any of the values match.
     *
     * Allow multiple values per parameter (or)
     */
    multipleOr?: boolean;
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * The identifier that is used to identify this version of the search parameter when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the search parameter author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the search parameter
     */
    version?: string;
    /**
     * An absolute URI that is used to identify this search parameter when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this search parameter is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the search parameter is stored on different servers.
     *
     * Canonical identifier for this search parameter, represented as a URI (globally unique)
     */
    url: string;
    /**
     * Types of resource (if a resource is referenced).
     *
     * Types of resource (if a resource reference)
     */
    target?: string[];
    /**
     * A formal identifier that is used to identify this search parameter when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the search parameter (business identifier)
     */
    identifier?: Identifier[];
    /**
     * Whether multiple parameters are allowed - e.g. more than one parameter with the same name. The search matches if all the parameters match.
     *
     * Allow multiple parameters (and)
     */
    multipleAnd?: boolean;
    /**
     * Contains the names of any search parameters which may be chained to the containing search parameter. Chained parameters may be added to search parameters of type reference and specify that resources will only be returned if they contain a reference to a resource which matches the chained parameter value. Values for this field should be drawn from SearchParameter.code for a parameter on the target resource type.
     *
     * Chained names supported
     */
    chain?: string[];
    /**
     * A FHIRPath expression that returns a set of elements for the search parameter.
     *
     * FHIRPath expression that extracts the values
     */
    expression?: string;
    readonly resourceType: string;
    static revive(json: any): SearchParameter;
    toJSON(): any;
}
export declare namespace SearchParameter {
    enum SearchProcessingModeType {
        OTHER,
        NULL,
        PHONETIC,
        NORMAL
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    enum SearchParamType {
        DATE,
        NUMBER,
        NULL,
        QUANTITY,
        REFERENCE,
        STRING,
        TOKEN,
        URI,
        SPECIAL,
        COMPOSITE
    }
    class SearchParameterComponentComponent extends BackboneElement {
        /**
         * A sub-expression that defines how to extract values for this component from the output of the main SearchParameter.expression.
         *
         * Subexpression relative to main expression
         */
        expression: string;
        /**
         * The definition of the search parameter that describes this part.
         *
         * Defines how the part works
         */
        definition: string;
        static revive(json: any): SearchParameterComponentComponent;
        toJSON(): any;
    }
}
