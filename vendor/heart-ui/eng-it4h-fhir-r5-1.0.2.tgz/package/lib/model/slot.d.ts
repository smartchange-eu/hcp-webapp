import { Reference } from '../datatype/reference';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { DomainResource } from '../model/domain-resource';
import { Schedule } from '../model/schedule';
/**
 * HAPI/FHIR <b>Slot</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Slot">http://hl7.org/fhir/StructureDefinition/Slot</a>
 * </p>
 *
 */
export declare class Slot extends DomainResource {
    /**
     * Date/Time that the slot is to conclude.
     *
     * Date/Time that the slot is to conclude
     */
    end: Date;
    /**
     * Comments on the slot to describe any extended information. Such as custom constraints on the slot.
     *
     * Comments on the slot to describe any extended information. Such as custom constraints on the slot
     */
    comment?: string;
    /**
     * Date/Time that the slot is to begin.
     *
     * Date/Time that the slot is to begin
     */
    start: Date;
    /**
     * A broad categorization of the service that is to be performed during this appointment.
     *
     * A broad categorization of the service that is to be performed during this appointment
     */
    serviceCategory?: CodeableConcept[];
    /**
     * busy | free | busy-unavailable | busy-tentative | entered-in-error.
     *
     * busy | free | busy-unavailable | busy-tentative | entered-in-error
     */
    status: string;
    /**
     * The specialty of a practitioner that would be required to perform the service requested in this appointment.
     *
     * The specialty of a practitioner that would be required to perform the service requested in this appointment
     */
    specialty?: CodeableConcept[];
    /**
     * The type of appointments that can be booked into this slot (ideally this would be an identifiable service - which is at a location, rather than the location itself). If provided then this overrides the value provided on the Schedule resource.
     *
     * The type of appointments that can be booked into this slot (ideally this would be an identifiable service - which is at a location, rather than the location itself). If provided then this overrides the value provided on the Schedule resource
     */
    serviceType?: CodeableReference[];
    /**
     * External Ids for this item.
     *
     * External Ids for this item
     */
    identifier?: Identifier[];
    /**
     * The style of appointment or patient that may be booked in the slot (not service type).
     *
     * The style of appointment or patient that may be booked in the slot (not service type)
     */
    appointmentType?: CodeableConcept[];
    /**
     * The schedule resource that this slot defines an interval of status information.
     *
     * The schedule resource that this slot defines an interval of status information
     */
    schedule: Schedule | Reference;
    /**
     * This slot has already been overbooked, appointments are unlikely to be accepted for this time.
     *
     * This slot has already been overbooked, appointments are unlikely to be accepted for this time
     */
    overbooked?: boolean;
    readonly resourceType: string;
    static revive(json: any): Slot;
    toJSON(): any;
}
export declare namespace Slot {
    enum SlotStatus {
        ENTEREDINERROR,
        NULL,
        BUSY,
        BUSYTENTATIVE,
        BUSYUNAVAILABLE,
        FREE
    }
}
