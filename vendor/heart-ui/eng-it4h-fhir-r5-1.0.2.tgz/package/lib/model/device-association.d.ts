import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { BodyStructure } from '../model/body-structure';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Group } from '../model/group';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>DeviceAssociation</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/DeviceAssociation">http://hl7.org/fhir/StructureDefinition/DeviceAssociation</a>
 * </p>
 *
 */
export declare class DeviceAssociation extends DomainResource {
    /**
     * Describes the relationship between the device and subject.
     *
     * Describes the relationship between the device and subject
     */
    category?: CodeableConcept[];
    /**
     * Reference to the devices associated with the patient or group.
     *
     * Reference to the devices associated with the patient or group
     */
    device: Device | Reference;
    /**
     * The details about the device when it is in use to describe its operation.
     *
     * The details about the device when it is in use to describe its operation
     */
    operation?: DeviceAssociation.DeviceAssociationOperationComponent[];
    /**
     * Indicates the state of the Device association.
     *
     * implanted | explanted | attached | entered-in-error | unknown
     */
    status: CodeableConcept;
    /**
     * Current anatomical location of the device in/on subject.
     *
     * Current anatomical location of the device in/on subject
     */
    bodyStructure?: BodyStructure | Reference;
    /**
     * The individual, group of individuals or device that the device is on or associated with.
     *
     * The individual, group of individuals or device that the device is on or associated with
     */
    subject?: Patient | Group | Practitioner | RelatedPerson | Device | Reference;
    /**
     * Instance identifier.
     *
     * Instance identifier
     */
    identifier?: Identifier[];
    /**
     * Begin and end dates and times for the device association.
     *
     * Begin and end dates and times for the device association
     */
    period?: Period;
    /**
     * The reasons given for the current association status.
     *
     * The reasons given for the current association status
     */
    statusReason?: CodeableConcept[];
    readonly resourceType: string;
    static revive(json: any): DeviceAssociation;
    toJSON(): any;
}
export declare namespace DeviceAssociation {
    class DeviceAssociationOperationComponent extends BackboneElement {
        /**
         * The individual performing the action enabled by the device.
         *
         * The individual performing the action enabled by the device
         */
        operator?: Patient[] | Practitioner[] | RelatedPerson[] | Reference[];
        /**
         * Device operational condition corresponding to the association.
         *
         * Device operational condition
         */
        status: CodeableConcept;
        /**
         * Begin and end dates and times for the device's operation.
         *
         * Begin and end dates and times for the device's operation
         */
        period?: Period;
        static revive(json: any): DeviceAssociationOperationComponent;
        toJSON(): any;
    }
}
