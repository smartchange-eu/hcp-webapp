import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Duration } from '../datatype/duration';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>MeasureReport</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/MeasureReport">http://hl7.org/fhir/StructureDefinition/MeasureReport</a>
 * </p>
 *
 */
export declare class MeasureReport extends DomainResource {
    /**
     * The date this measure was calculated.
     *
     * When the measure was calculated
     */
    date?: Date;
    /**
     * A formal identifier that is used to identify this MeasureReport when it is represented in other formats or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the MeasureReport
     */
    identifier?: Identifier[];
    /**
     * The reporting period for which the report was calculated.
     *
     * What period the report covers
     */
    period: Period;
    /**
     * Indicates how the calculation is performed for the measure, including proportion, ratio, continuous-variable, and cohort. The value set is extensible, allowing additional measure scoring types to be represented. It is expected to be the same as the scoring element on the referenced Measure.
     *
     * What scoring method (e.g. proportion, ratio, continuous-variable)
     */
    scoring?: CodeableConcept;
    /**
     * Optional subject identifying the individual or individuals the report is for.
     *
     * What individual(s) the report is for
     */
    subject?: CareTeam | Device | Group | HealthcareService | Location | Organization | Patient | Practitioner | PractitionerRole | RelatedPerson | Reference;
    /**
     * A reference to a Resource that represents additional information collected for the report. If the value of the supplemental data is not a Resource (i.e. evaluating the supplementalData expression for this case in the measure results in a value that is not a FHIR Resource), it is reported as a reference to a contained Observation resource.
     *
     * Additional information collected for the report
     */
    supplementalData?: Reference[];
    /**
     * The individual or organization that is reporting the data.
     *
     * Who is reporting the data
     */
    reporter?: Practitioner | PractitionerRole | Organization | Group | Reference;
    /**
     * Whether improvement in the measure is noted by an increase or decrease in the measure score.
     *
     * increase | decrease
     */
    improvementNotation?: CodeableConcept;
    /**
     * The type of measure report. This may be an individual report, which provides the score for the measure for an individual member of the population; a subject-listing, which returns the list of members that meet the various criteria in the measure; a summary report, which returns a population count for each of the criteria in the measure; or a data-collection, which enables the MeasureReport to be used to exchange the data-of-interest for a quality measure.
     *
     * individual | subject-list | summary | data-exchange
     */
    type: string;
    /**
     * A reference to a Parameters resource (typically represented using a contained resource) that represents any input parameters that were provided to the operation that generated the report.
     *
     * What parameters were provided to the report
     */
    inputParameters?: any;
    /**
     * Indicates whether the data submitted in a data-exchange report represents a snapshot or incremental update. A snapshot update replaces all previously submitted data for the receiver, whereas an incremental update represents only updated and/or changed data and should be applied as a differential update to the existing submitted data for the receiver.
     *
     * incremental | snapshot
     */
    dataUpdateType?: string;
    /**
     * A reference to the vendor who queried the data, calculated results and/or generated the report. The ‘reporting vendor’ is intended to represent the submitting entity when it is not the same as the reporting entity. This extension is used when the Receiver is interested in getting vendor information in the report.
     *
     * What vendor prepared the data
     */
    reportingVendor?: Organization | Reference;
    /**
     * A reference to the Measure that was calculated to produce this report.
     *
     * What measure was calculated
     */
    measure?: string;
    /**
     * A reference to the location for which the data is being reported.
     *
     * Where the reported data is from
     */
    location?: Location | Reference;
    /**
     * Evaluated resources are used to capture what data was involved in the calculation of a measure. This usage is only allowed for individual reports to ensure that the size of the MeasureReport resource is bounded.
     *
     * What data was used to calculate the measure score
     */
    evaluatedResource?: Reference[];
    /**
     * The MeasureReport status. No data will be available until the MeasureReport status is complete.
     *
     * complete | pending | error
     */
    status: string;
    /**
     * The results of the calculation, one for each population group in the measure.
     *
     * Measure results for each group
     */
    group?: MeasureReport.MeasureReportGroupComponent[];
    readonly resourceType: string;
    static revive(json: any): MeasureReport;
    toJSON(): any;
}
export declare namespace MeasureReport {
    enum SubmitDataUpdateType {
        NULL,
        SNAPSHOT,
        INCREMENTAL
    }
    enum MeasureReportType {
        SUBJECTLIST,
        NULL,
        SUMMARY,
        DATAEXCHANGE,
        INDIVIDUAL
    }
    enum MeasureReportStatus {
        COMPLETE,
        NULL,
        ERROR,
        PENDING
    }
    class StratifierGroupPopulationComponent extends BackboneElement {
        /**
         * Optional Group identifying the individuals that make up the population.
         *
         * What individual(s) in the population
         */
        subjects?: Group | Reference;
        /**
         * The population from the Measure that corresponds to this population in the MeasureReport resource.
         *
         * Pointer to specific population from Measure
         */
        linkId?: string;
        /**
         * The type of the population.
         *
         * initial-population | numerator | numerator-exclusion | denominator | denominator-exclusion | denominator-exception | measure-population | measure-population-exclusion | measure-observation
         */
        code?: CodeableConcept;
        /**
         * A reference to an individual level MeasureReport resource for a member of the population.
         *
         * For subject-list reports, a subject result in this population
         */
        subjectReport?: MeasureReport[] | Reference[];
        /**
         * This element refers to a List of individual level MeasureReport resources, one for each subject in this population in this stratum.
         *
         * For subject-list reports, the subject results in this population
         */
        subjectResults?: any;
        /**
         * The number of members of the population in this stratum.
         *
         * Size of the population
         */
        count?: number;
        static revive(json: any): StratifierGroupPopulationComponent;
        toJSON(): any;
    }
    class StratifierGroupComponentComponent extends BackboneElement {
        /**
         * The stratum component value.
         *
         * The stratum component value, e.g. male
         */
        value: CodeableConcept | boolean | Quantity | Range | Reference;
        /**
         * The stratifier component from the Measure that corresponds to this stratifier component in the MeasureReport resource.
         *
         * Pointer to specific stratifier component from Measure
         */
        linkId?: string;
        /**
         * The code for the stratum component value.
         *
         * What stratifier component of the group
         */
        code: CodeableConcept;
        static revive(json: any): StratifierGroupComponentComponent;
        toJSON(): any;
    }
    class StratifierGroupComponent extends BackboneElement {
        /**
         * A stratifier component value.
         *
         * Stratifier component values
         */
        component?: MeasureReport.StratifierGroupComponentComponent[];
        /**
         * The value for this stratum, expressed as a CodeableConcept. When defining stratifiers on complex values, the value must be rendered such that the value for each stratum within the stratifier is unique.
         *
         * The stratum value, e.g. male
         */
        value?: CodeableConcept | boolean | Quantity | Range | Reference;
        /**
         * The measure score for this stratum, calculated as appropriate for the measure type and scoring method, and based on only the members of this stratum.
         *
         * What score this stratum achieved
         */
        measureScore?: Quantity | Date | CodeableConcept | Period | Range | Duration;
        /**
         * The populations that make up the stratum, one for each type of population appropriate to the measure.
         *
         * Population results in this stratum
         */
        population?: MeasureReport.StratifierGroupPopulationComponent[];
        static revive(json: any): StratifierGroupComponent;
        toJSON(): any;
    }
    class MeasureReportGroupStratifierComponent extends BackboneElement {
        /**
         * The stratifier from the Measure that corresponds to this stratifier in the MeasureReport resource.
         *
         * Pointer to specific stratifier from Measure
         */
        linkId?: string;
        /**
         * The meaning of this stratifier, as defined in the measure definition.
         *
         * What stratifier of the group
         */
        code?: CodeableConcept;
        /**
         * This element contains the results for a single stratum within the stratifier. For example, when stratifying on administrative gender, there will be four strata, one for each possible gender value.
         *
         * Stratum results, one for each unique value, or set of values, in the stratifier, or stratifier components
         */
        stratum?: MeasureReport.StratifierGroupComponent[];
        static revive(json: any): MeasureReportGroupStratifierComponent;
        toJSON(): any;
    }
    class MeasureReportGroupPopulationComponent extends BackboneElement {
        /**
         * The number of members of the population.
         *
         * Size of the population
         */
        count?: number;
        /**
         * This element refers to a List of individual level MeasureReport resources, one for each subject in this population.
         *
         * For subject-list reports, the subject results in this population
         */
        subjectResults?: any;
        /**
         * A reference to an individual level MeasureReport resource for a member of the population.
         *
         * For subject-list reports, a subject result in this population
         */
        subjectReport?: MeasureReport[] | Reference[];
        /**
         * Optional Group identifying the individuals that make up the population.
         *
         * What individual(s) in the population
         */
        subjects?: Group | Reference;
        /**
         * The population from the Measure that corresponds to this population in the MeasureReport resource.
         *
         * Pointer to specific population from Measure
         */
        linkId?: string;
        /**
         * The type of the population.
         *
         * initial-population | numerator | numerator-exclusion | denominator | denominator-exclusion | denominator-exception | measure-population | measure-population-exclusion | measure-observation
         */
        code?: CodeableConcept;
        static revive(json: any): MeasureReportGroupPopulationComponent;
        toJSON(): any;
    }
    class MeasureReportGroupComponent extends BackboneElement {
        /**
         * The group from the Measure that corresponds to this group in the MeasureReport resource.
         *
         * Pointer to specific group from Measure
         */
        linkId?: string;
        /**
         * The meaning of the population group as defined in the measure definition.
         *
         * Meaning of the group
         */
        code?: CodeableConcept;
        /**
         * Optional subject identifying the individual or individuals the report is for.
         *
         * What individual(s) the report is for
         */
        subject?: CareTeam | Device | Group | HealthcareService | Location | Organization | Patient | Practitioner | PractitionerRole | RelatedPerson | Reference;
        /**
         * When a measure includes multiple stratifiers, there will be a stratifier group for each stratifier defined by the measure.
         *
         * Stratification results
         */
        stratifier?: MeasureReport.MeasureReportGroupStratifierComponent[];
        /**
         * The measure score for this population group, calculated as appropriate for the measure type and scoring method, and based on the contents of the populations defined in the group.
         *
         * What score this group achieved
         */
        measureScore?: Quantity | Date | CodeableConcept | Period | Range | Duration;
        /**
         * The populations that make up the population group, one for each type of population appropriate for the measure.
         *
         * The populations in the group
         */
        population?: MeasureReport.MeasureReportGroupPopulationComponent[];
        static revive(json: any): MeasureReportGroupComponent;
        toJSON(): any;
    }
}
