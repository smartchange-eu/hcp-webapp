import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { Ratio } from '../datatype/ratio';
import { DomainResource } from '../model/domain-resource';
/**
 * HAPI/FHIR <b>Substance</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Substance">http://hl7.org/fhir/StructureDefinition/Substance</a>
 * </p>
 *
 */
export declare class Substance extends DomainResource {
    /**
     * Unique identifier for the substance. For an instance, an identifier associated with the package/container (usually a label affixed directly).
     *
     * Unique identifier
     */
    identifier?: Identifier[];
    /**
     * A boolean to indicate if this an instance of a substance or a kind of one (a definition).
     *
     * Is this an instance of a substance or a kind of one
     */
    instance: boolean;
    /**
     * A code (or set of codes) that identify this substance.
     *
     * What substance this is
     */
    code: CodeableReference;
    /**
     * The amount of the substance.
     *
     * Amount of substance in the package
     */
    quantity?: Quantity;
    /**
     * A substance can be composed of other substances.
     *
     * Composition information about the substance
     */
    ingredient?: Substance.SubstanceIngredientComponent[];
    /**
     * A code that classifies the general type of substance.  This is used  for searching, sorting and display purposes.
     *
     * What class/type of substance this is
     */
    category?: CodeableConcept[];
    /**
     * A code to indicate if the substance is actively used.
     *
     * active | inactive | entered-in-error
     */
    status?: string;
    /**
     * A description of the substance - its appearance, handling requirements, and other usage notes.
     *
     * Textual description of the substance, comments
     */
    description?: string;
    /**
     * When the substance is no longer valid to use. For some substances, a single arbitrary date is used for expiry.
     *
     * When no longer valid to use
     */
    expiry?: Date;
    readonly resourceType: string;
    static revive(json: any): Substance;
    toJSON(): any;
}
export declare namespace Substance {
    enum FHIRSubstanceStatus {
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        INACTIVE
    }
    class SubstanceIngredientComponent extends BackboneElement {
        /**
         * The amount of the ingredient in the substance - a concentration ratio.
         *
         * Optional amount (concentration)
         */
        quantity?: Ratio;
        /**
         * Another substance that is a component of this substance.
         *
         * A component of the substance
         */
        substance: CodeableConcept | Substance | Reference;
        static revive(json: any): SubstanceIngredientComponent;
        toJSON(): any;
    }
}
