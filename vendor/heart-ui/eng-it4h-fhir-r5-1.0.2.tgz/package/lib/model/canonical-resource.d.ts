import { DomainResource } from '../model/domain-resource';
/**
 * HAPI/FHIR <b>CanonicalResource</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class CanonicalResource extends DomainResource {
    readonly resourceType: string;
    static revive(json: any): CanonicalResource;
    toJSON(): any;
}
