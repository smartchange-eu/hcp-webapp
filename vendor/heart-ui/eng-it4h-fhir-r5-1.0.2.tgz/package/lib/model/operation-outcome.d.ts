import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { DomainResource } from '../model/domain-resource';
/**
 * HAPI/FHIR <b>OperationOutcome</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/OperationOutcome">http://hl7.org/fhir/StructureDefinition/OperationOutcome</a>
 * </p>
 *
 */
export declare class OperationOutcome extends DomainResource {
    /**
     * An error, warning, or information message that results from a system action.
     *
     * A single issue associated with the action
     */
    issue: OperationOutcome.OperationOutcomeIssueComponent[];
    readonly resourceType: string;
    static revive(json: any): OperationOutcome;
    toJSON(): any;
}
export declare namespace OperationOutcome {
    enum IssueType {
        LIMITEDFILTER,
        CONFLICT,
        EXPIRED,
        PROCESSING,
        THROTTLED,
        EXCEPTION,
        EXTENSION,
        VALUE,
        INVALID,
        DELETED,
        NOTSUPPORTED,
        NOSTORE,
        DUPLICATE,
        LOGIN,
        TOOCOSTLY,
        LOCKERROR,
        SUCCESS,
        NULL,
        STRUCTURE,
        INVARIANT,
        TOOLONG,
        REQUIRED,
        INCOMPLETE,
        MULTIPLEMATCHES,
        SUPPRESSED,
        FORBIDDEN,
        BUSINESSRULE,
        NOTFOUND,
        CODEINVALID,
        SECURITY,
        UNKNOWN,
        TIMEOUT,
        INFORMATIONAL,
        TRANSIENT
    }
    enum IssueSeverity {
        SUCCESS,
        NULL,
        INFORMATION,
        ERROR,
        FATAL,
        WARNING
    }
    class OperationOutcomeIssueComponent extends BackboneElement {
        /**
         * Additional details about the error. This may be a text description of the error or a system code that identifies the error.
         *
         * Additional details about the error
         */
        details?: CodeableConcept;
        /**
         * This element is deprecated because it is XML specific. It is replaced by issue.expression, which is format independent, and simpler to parse.

For resource issues, this will be a simple XPath limited to element names, repetition indicators and the default child accessor that identifies one of the elements in the resource that caused this issue to be raised.  For HTTP errors, will be "http." + the parameter name.
         *
         * Deprecated: Path of element(s) related to issue
         */
        location?: string[];
        /**
         * Indicates whether the issue indicates a variation from successful processing.
         *
         * fatal | error | warning | information | success
         */
        severity: string;
        /**
         * Additional diagnostic information about the issue.
         *
         * Additional diagnostic information about the issue
         */
        diagnostics?: string;
        /**
         * Describes the type of the issue. The system that creates an OperationOutcome SHALL choose the most applicable code from the IssueType value set, and may additional provide its own code for the error in the details element.
         *
         * Error or warning code
         */
        code: string;
        /**
         * A [simple subset of FHIRPath](fhirpath.html#simple) limited to element names, repetition indicators and the default child accessor that identifies one of the elements in the resource that caused this issue to be raised.
         *
         * FHIRPath of element(s) related to issue
         */
        expression?: string[];
        static revive(json: any): OperationOutcomeIssueComponent;
        toJSON(): any;
    }
}
