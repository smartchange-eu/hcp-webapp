import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { Ratio } from '../datatype/ratio';
import { RatioRange } from '../datatype/ratio-range';
import { AdministrableProductDefinition } from '../model/administrable-product-definition';
import { DomainResource } from '../model/domain-resource';
import { ManufacturedItemDefinition } from '../model/manufactured-item-definition';
import { MedicinalProductDefinition } from '../model/medicinal-product-definition';
import { Organization } from '../model/organization';
/**
 * HAPI/FHIR <b>Ingredient</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Ingredient">http://hl7.org/fhir/StructureDefinition/Ingredient</a>
 * </p>
 *
 */
export declare class Ingredient extends DomainResource {
    /**
     * A classification of the ingredient identifying its purpose within the product, e.g. active, inactive.
     *
     * Purpose of the ingredient within the product, e.g. active, inactive
     */
    role: CodeableConcept;
    /**
     * The identifier(s) of this Ingredient that are assigned by business processes and/or used to refer to it when a direct URL reference to the resource itself is not appropriate.
     *
     * An identifier or code by which the ingredient can be referenced
     */
    identifier?: Identifier;
    /**
     * A classification of the ingredient identifying its precise purpose(s) in the drug product. This extends the Ingredient.role to add more detail. Example: antioxidant, alkalizing agent.
     *
     * Precise action within the drug product, e.g. antioxidant, alkalizing agent
     */
    function?: CodeableConcept[];
    /**
     * The substance that comprises this ingredient.
     *
     * The substance that comprises this ingredient
     */
    substance: Ingredient.IngredientSubstanceComponent;
    /**
     * The product which this ingredient is a constituent part of.
     *
     * The product which this ingredient is a constituent part of
     */
    for?: MedicinalProductDefinition[] | AdministrableProductDefinition[] | ManufacturedItemDefinition[] | Reference[];
    /**
     * A place for providing any notes that are relevant to the component, e.g. removed during process, adjusted for loss on drying.
     *
     * A place for providing any notes that are relevant to the component, e.g. removed during process, adjusted for loss on drying
     */
    comment?: string;
    /**
     * The status of this ingredient. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * A classification of the ingredient according to where in the physical item it tends to be used, such the outer shell of a tablet, inner body or ink.
     *
     * A classification of the ingredient according to where in the physical item it tends to be used, such the outer shell of a tablet, inner body or ink
     */
    group?: CodeableConcept;
    /**
     * The organization(s) that manufacture this ingredient. Can be used to indicate:         1) Organizations we are aware of that manufacture this ingredient         2) Specific Manufacturer(s) currently being used         3) Set of organisations allowed to manufacture this ingredient for this product         Users must be clear on the application of context relevant to their use case.
     *
     * An organization that manufactures this ingredient
     */
    manufacturer?: Ingredient.IngredientManufacturerComponent[];
    /**
     * If the ingredient is a known or suspected allergen. Note that this is a property of the substance, so if a reference to a SubstanceDefinition is used to decribe that (rather than just a code), the allergen information should go there, not here.
     *
     * If the ingredient is a known or suspected allergen
     */
    allergenicIndicator?: boolean;
    readonly resourceType: string;
    static revive(json: any): Ingredient;
    toJSON(): any;
}
export declare namespace Ingredient {
    enum IngredientManufacturerRole {
        ALLOWED,
        POSSIBLE,
        NULL,
        ACTUAL
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class IngredientSubstanceStrengthReferenceStrengthComponent extends BackboneElement {
        /**
         * For when strength is measured at a particular point or distance.
         *
         * When strength is measured at a particular point or distance
         */
        measurementPoint?: string;
        /**
         * The country or countries for which the strength range applies.
         *
         * Where the strength range applies
         */
        country?: CodeableConcept[];
        /**
         * Strength expressed in terms of a reference substance.
         *
         * Strength expressed in terms of a reference substance
         */
        strength: Ratio | RatioRange | Quantity;
        /**
         * Relevant reference substance.
         *
         * Relevant reference substance
         */
        substance: CodeableReference;
        static revive(json: any): IngredientSubstanceStrengthReferenceStrengthComponent;
        toJSON(): any;
    }
    class IngredientSubstanceStrengthComponent extends BackboneElement {
        /**
         * A textual represention of either the whole of the concentration strength or a part of it - with the rest being in Strength.concentration as a ratio.
         *
         * Text of either the whole concentration strength or a part of it (rest being in Strength.concentration as a ratio)
         */
        textConcentration?: string;
        /**
         * Strength expressed in terms of a reference substance. For when the ingredient strength is additionally expressed as equivalent to the strength of some other closely related substance (e.g. salt vs. base). Reference strength represents the strength (quantitative composition) of the active moiety of the active substance. There are situations when the active substance and active moiety are different, therefore both a strength and a reference strength are needed.
         *
         * Strength expressed in terms of a reference substance
         */
        referenceStrength?: Ingredient.IngredientSubstanceStrengthReferenceStrengthComponent[];
        /**
         * The country or countries for which the strength range applies.
         *
         * Where the strength range applies
         */
        country?: CodeableConcept[];
        /**
         * The quantity of substance in the unit of presentation, or in the volume (or mass) of the single pharmaceutical product or manufactured item. Unit of presentation refers to the quantity that the item occurs in e.g. a strength per tablet size, perhaps 'per 20mg' (the size of the tablet). It is not generally normalized as a unitary unit, which would be 'per mg').
         *
         * The quantity of substance in the unit of presentation
         */
        presentation?: Ratio | RatioRange | CodeableConcept | Quantity;
        /**
         * A textual represention of either the whole of the presentation strength or a part of it - with the rest being in Strength.presentation as a ratio.
         *
         * Text of either the whole presentation strength or a part of it (rest being in Strength.presentation as a ratio)
         */
        textPresentation?: string;
        /**
         * A code that indicates if the strength is, for example, based on the ingredient substance as stated or on the substance base (when the ingredient is a salt).
         *
         * A code that indicates if the strength is, for example, based on the ingredient substance as stated or on the substance base (when the ingredient is a salt)
         */
        basis?: CodeableConcept;
        /**
         * For when strength is measured at a particular point or distance. There are products where strength is measured at a particular point. For example, the strength of the ingredient in some inhalers is measured at a particular position relative to the point of aerosolization.
         *
         * When strength is measured at a particular point or distance
         */
        measurementPoint?: string;
        /**
         * The strength per unitary volume (or mass).
         *
         * The strength per unitary volume (or mass)
         */
        concentration?: Ratio | RatioRange | CodeableConcept | Quantity;
        static revive(json: any): IngredientSubstanceStrengthComponent;
        toJSON(): any;
    }
    class IngredientSubstanceComponent extends BackboneElement {
        /**
         * A code or full resource that represents the ingredient's substance.
         *
         * A code or full resource that represents the ingredient substance
         */
        code: CodeableReference;
        /**
         * The quantity of substance in the unit of presentation, or in the volume (or mass) of the single pharmaceutical product or manufactured item. The allowed repetitions do not represent different strengths, but are different representations - mathematically equivalent - of a single strength.
         *
         * The quantity of substance, per presentation, or per volume or mass, and type of quantity
         */
        strength?: Ingredient.IngredientSubstanceStrengthComponent[];
        static revive(json: any): IngredientSubstanceComponent;
        toJSON(): any;
    }
    class IngredientManufacturerComponent extends BackboneElement {
        /**
         * The way in which this manufacturer is associated with the ingredient. For example whether it is a possible one (others allowed), or an exclusive authorized one for this ingredient. Note that this is not the manufacturing process role.
         *
         * allowed | possible | actual
         */
        role?: string;
        /**
         * An organization that manufactures this ingredient.
         *
         * An organization that manufactures this ingredient
         */
        manufacturer: Organization | Reference;
        static revive(json: any): IngredientManufacturerComponent;
        toJSON(): any;
    }
}
