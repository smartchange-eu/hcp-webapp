import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Duration } from '../datatype/duration';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { Location } from '../model/location';
import { Patient } from '../model/patient';
/**
 * HAPI/FHIR <b>EncounterHistory</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/EncounterHistory">http://hl7.org/fhir/StructureDefinition/EncounterHistory</a>
 * </p>
 *
 */
export declare class EncounterHistory extends DomainResource {
    /**
     * Concepts representing classification of patient encounter such as ambulatory (outpatient), inpatient, emergency, home health or others due to local variations.
     *
     * Classification of patient encounter
     */
    class: CodeableConcept;
    /**
     * Actual quantity of time the encounter lasted. This excludes the time during leaves of absence.

When missing it is the time in between the start and end values.
     *
     * Actual quantity of time the encounter lasted (less time absent)
     */
    length?: Duration;
    /**
     * The Encounter associated with this set of historic values.
     *
     * The Encounter associated with this set of historic values
     */
    encounter?: Encounter | Reference;
    /**
     * Specific type of encounter (e.g. e-mail consultation, surgical day-care, skilled nursing, rehabilitation).
     *
     * Specific type of encounter
     */
    type?: CodeableConcept[];
    /**
     * The planned end date/time (or discharge date) of the encounter.
     *
     * The planned end date/time (or discharge date) of the encounter
     */
    plannedEndDate?: Date;
    /**
     * Broad categorization of the service that is to be provided (e.g. cardiology).
     *
     * Specific type of service
     */
    serviceType?: CodeableReference[];
    /**
     * Identifier(s) by which this encounter is known.
     *
     * Identifier(s) by which this encounter is known
     */
    identifier?: Identifier[];
    /**
     * The subjectStatus value can be used to track the patient's status within the encounter. It details whether the patient has arrived or departed, has been triaged or is currently in a waiting status.
     *
     * The current status of the subject in relation to the Encounter
     */
    subjectStatus?: CodeableConcept;
    /**
     * The start and end time associated with this set of values associated with the encounter, may be different to the planned times for various reasons.
     *
     * The actual start and end time associated with this set of values associated with the encounter
     */
    actualPeriod?: Period;
    /**
     * The patient or group related to this encounter. In some use-cases the patient MAY not be present, such as a case meeting about a patient between several practitioners or a careteam.
     *
     * The patient or group related to this encounter
     */
    subject?: Patient | Group | Reference;
    /**
     * The location of the patient at this point in the encounter, the multiple cardinality permits de-normalizing the levels of the location hierarchy, such as site/ward/room/bed.
     *
     * Location of the patient at this point in the encounter
     */
    location?: EncounterHistory.EncounterHistoryLocationComponent[];
    /**
     * planned | in-progress | on-hold | discharged | completed | cancelled | discontinued | entered-in-error | unknown.
     *
     * planned | in-progress | on-hold | discharged | completed | cancelled | discontinued | entered-in-error | unknown
     */
    status: string;
    /**
     * The planned start date/time (or admission date) of the encounter.
     *
     * The planned start date/time (or admission date) of the encounter
     */
    plannedStartDate?: Date;
    readonly resourceType: string;
    static revive(json: any): EncounterHistory;
    toJSON(): any;
}
export declare namespace EncounterHistory {
    enum EncounterStatus {
        CANCELLED,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ONHOLD,
        INPROGRESS,
        UNKNOWN,
        DISCONTINUED,
        DISCHARGED,
        PLANNED
    }
    class EncounterHistoryLocationComponent extends BackboneElement {
        /**
         * This will be used to specify the required levels (bed/ward/room/etc.) desired to be recorded to simplify either messaging or query.
         *
         * The physical type of the location (usually the level in the location hierarchy - bed, room, ward, virtual etc.)
         */
        form?: CodeableConcept;
        /**
         * The location where the encounter takes place.
         *
         * Location the encounter takes place
         */
        location: Location | Reference;
        static revive(json: any): EncounterHistoryLocationComponent;
        toJSON(): any;
    }
}
