import { Reference } from '../datatype/reference';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Basic</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Basic">http://hl7.org/fhir/StructureDefinition/Basic</a>
 * </p>
 *
 */
export declare class Basic extends DomainResource {
    /**
     * Identifier assigned to the resource for business purposes, outside the context of FHIR.
     *
     * Business identifier
     */
    identifier?: Identifier[];
    /**
     * Identifies the 'type' of resource - equivalent to the resource name for other resources.
     *
     * Kind of Resource
     */
    code: CodeableConcept;
    /**
     * Identifies the patient, practitioner, device or any other resource that is the "focus" of this resource.
     *
     * Identifies the focus of this resource
     */
    subject?: Reference;
    /**
     * Identifies when the resource was first created.
     *
     * When created
     */
    created?: Date;
    /**
     * Indicates who was responsible for creating the resource instance.
     *
     * Who created
     */
    author?: Practitioner | PractitionerRole | Patient | RelatedPerson | Organization | Device | CareTeam | Reference;
    readonly resourceType: string;
    static revive(json: any): Basic;
    toJSON(): any;
}
