import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Expression } from '../datatype/expression';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { RelatedArtifact } from '../datatype/related-artifact';
import { UsageContext } from '../datatype/usage-context';
import { Device } from '../model/device';
import { DeviceMetric } from '../model/device-metric';
import { Evidence } from '../model/evidence';
import { Group } from '../model/group';
import { MetadataResource } from '../model/metadata-resource';
/**
 * HAPI/FHIR <b>EvidenceVariable</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/EvidenceVariable">http://hl7.org/fhir/StructureDefinition/EvidenceVariable</a>
 * </p>
 *
 */
export declare class EvidenceVariable extends MetadataResource {
    /**
     * The short title provides an alternate title for use in informal descriptive contexts where the full, formal title is not necessary.
     *
     * Title for use in informal contexts
     */
    shortTitle?: string;
    /**
     * A Boolean value to indicate that this resource is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A free text natural language description of the evidence variable from a consumer's perspective.
     *
     * Natural language description of the evidence variable
     */
    description?: string;
    /**
     * A defining factor of the EvidenceVariable. Multiple characteristics are applied with "and" semantics.
     *
     * A defining factor of the EvidenceVariable
     */
    characteristic?: EvidenceVariable.EvidenceVariableCharacteristicComponent[];
    /**
     * A short, descriptive, user-friendly title for the evidence variable.
     *
     * Name for this evidence variable (human friendly)
     */
    title?: string;
    /**
     * The date on which the resource content was approved by the publisher. Approval happens once when the content is officially approved for usage.

See guidance around (not) making local changes to elements [here](canonicalresource.html#localization).
     *
     * When the resource was approved by publisher
     */
    approvalDate?: Date;
    /**
     * A copyright statement relating to the resource and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the resource.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * A human-readable string to clarify or explain concepts about the resource.
     *
     * Used for footnotes or explanatory notes
     */
    note?: Annotation[];
    /**
     * The date  (and optionally time) when the evidence variable was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the evidence variable changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * Explanation of why this EvidenceVariable is needed and why it has been designed as it has.
     *
     * Why this EvidenceVariable is defined
     */
    purpose?: string;
    /**
     * An individual or organization asserted by the publisher to be responsible for officially endorsing the content for use in some setting.
     *
     * Who endorsed the content
     */
    endorser?: ContactDetail[];
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * An individual or organization asserted by the publisher to be primarily responsible for review of some aspect of the content.
     *
     * Who reviewed the content
     */
    reviewer?: ContactDetail[];
    /**
     * An absolute URI that is used to identify this evidence variable when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this evidence variable is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the evidence variable is stored on different servers.
     *
     * Canonical identifier for this evidence variable, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * The identifier that is used to identify this version of the evidence variable when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the evidence variable author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence. To provide a version consistent with the Decision Support Service specification, use the format Major.Minor.Revision (e.g. 1.0.0). For more information on versioning knowledge assets, refer to the Decision Support Service specification. Note that a version is required for non-experimental active artifacts.
     *
     * Business version of the evidence variable
     */
    version?: string;
    /**
     * Related artifacts such as additional documentation, justification, or bibliographic references.
     *
     * Additional documentation, citations, etc
     */
    relatedArtifact?: RelatedArtifact[];
    /**
     * A formal identifier that is used to identify this evidence variable when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the evidence variable
     */
    identifier?: Identifier[];
    /**
     * An individual or organization primarily responsible for internal coherence of the content.
     *
     * Who edited the content
     */
    editor?: ContactDetail[];
    /**
     * True if the actual variable measured, false if a conceptual representation of the intended variable.
     *
     * Actual or conceptual
     */
    actual?: boolean;
    /**
     * An individiual or organization primarily involved in the creation and maintenance of the content.
     *
     * Who authored the content
     */
    author?: ContactDetail[];
    /**
     * The period during which the resource content was or is planned to be in active use.
     *
     * When the resource is expected to be used
     */
    effectivePeriod?: Period;
    /**
     * The method of handling in statistical analysis.
     *
     * continuous | dichotomous | ordinal | polychotomous
     */
    handling?: string;
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the evidence variable.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * A natural language name identifying the evidence variable. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this evidence variable (computer friendly)
     */
    name?: string;
    /**
     * The status of this evidence variable. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate evidence variable instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * A grouping for ordinal or polychotomous variables.
     *
     * A grouping for ordinal or polychotomous variables
     */
    category?: EvidenceVariable.EvidenceVariableCategoryComponent[];
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * The date on which the resource content was last reviewed. Review happens periodically after approval but does not change the original approval date.
     *
     * When the resource was last reviewed by the publisher
     */
    lastReviewDate?: Date;
    readonly resourceType: string;
    static revive(json: any): EvidenceVariable;
    toJSON(): any;
}
export declare namespace EvidenceVariable {
    enum CharacteristicCombination {
        NULL,
        STATISTICAL,
        ATMOST,
        DATASET,
        ANYOF,
        ATLEAST,
        NETEFFECT,
        ALLOF
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    enum EvidenceVariableHandling {
        NULL,
        POLYCHOTOMOUS,
        ORDINAL,
        CONTINUOUS,
        DICHOTOMOUS
    }
    class EvidenceVariableCategoryComponent extends BackboneElement {
        /**
         * Definition of the grouping.
         *
         * Definition of the grouping
         */
        value?: CodeableConcept | Quantity | Range;
        /**
         * Description of the grouping.
         *
         * Description of the grouping
         */
        name?: string;
        static revive(json: any): EvidenceVariableCategoryComponent;
        toJSON(): any;
    }
    class EvidenceVariableCharacteristicTimeFromEventComponent extends BackboneElement {
        /**
         * The event used as a base point (reference point) in time.
         *
         * The event used as a base point (reference point) in time
         */
        event?: CodeableConcept | Reference | Date | string;
        /**
         * Human readable description.
         *
         * Human readable description
         */
        description?: string;
        /**
         * Used to express the observation within a period before and/or after the event.
         *
         * Used to express the observation within a period before and/or after the event
         */
        range?: Range;
        /**
         * Used to express the observation at a defined amount of time before or after the event.
         *
         * Used to express the observation at a defined amount of time before or after the event
         */
        quantity?: Quantity;
        /**
         * A human-readable string to clarify or explain concepts about the timeFromEvent.
         *
         * Used for footnotes or explanatory notes
         */
        note?: Annotation[];
        static revive(json: any): EvidenceVariableCharacteristicTimeFromEventComponent;
        toJSON(): any;
    }
    class EvidenceVariableCharacteristicDefinitionByCombinationComponent extends BackboneElement {
        /**
         * A defining factor of the characteristic.
         *
         * A defining factor of the characteristic
         */
        characteristic: EvidenceVariable.EvidenceVariableCharacteristicComponent[];
        /**
         * Provides the value of "n" when "at-least" or "at-most" codes are used.
         *
         * Provides the value of "n" when "at-least" or "at-most" codes are used
         */
        threshold?: number;
        /**
         * Used to specify if two or more characteristics are combined with OR or AND.
         *
         * all-of | any-of | at-least | at-most | statistical | net-effect | dataset
         */
        code: string;
        static revive(json: any): EvidenceVariableCharacteristicDefinitionByCombinationComponent;
        toJSON(): any;
    }
    class EvidenceVariableCharacteristicDefinitionByTypeAndValueComponent extends BackboneElement {
        /**
         * Method for how the characteristic value was determined.
         *
         * Method for how the characteristic value was determined
         */
        method?: CodeableConcept[];
        /**
         * Defines the reference point for comparison when valueQuantity or valueRange is not compared to zero.
         *
         * Reference point for valueQuantity or valueRange
         */
        offset?: CodeableConcept;
        /**
         * Device used for determining characteristic.
         *
         * Device used for determining characteristic
         */
        device?: Device | DeviceMetric | Reference;
        /**
         * Defines the characteristic when paired with characteristic.type.
         *
         * Defines the characteristic when coupled with characteristic.type
         */
        value: CodeableConcept | boolean | Quantity | Range | Reference | string;
        /**
         * Used to express the type of characteristic.
         *
         * Expresses the type of characteristic
         */
        type: CodeableConcept;
        static revive(json: any): EvidenceVariableCharacteristicDefinitionByTypeAndValueComponent;
        toJSON(): any;
    }
    class EvidenceVariableCharacteristicComponent extends BackboneElement {
        /**
         * Defines the characteristic using both a type and value[x] elements.
         *
         * Defines the characteristic using type and value
         */
        definitionByTypeAndValue?: EvidenceVariable.EvidenceVariableCharacteristicDefinitionByTypeAndValueComponent;
        /**
         * Timing in which the characteristic is determined.
         *
         * Timing in which the characteristic is determined
         */
        timeFromEvent?: EvidenceVariable.EvidenceVariableCharacteristicTimeFromEventComponent[];
        /**
         * A short, natural language description of the characteristic that could be used to communicate the criteria to an end-user.
         *
         * Natural language description of the characteristic
         */
        description?: string;
        /**
         * Defines the characteristic using a Reference.
         *
         * Defines the characteristic (without using type and value) by a Reference
         */
        definitionReference?: EvidenceVariable | Group | Evidence | Reference;
        /**
         * Number of occurrences meeting the characteristic.
         *
         * Number of occurrences meeting the characteristic
         */
        instances?: Quantity | Range;
        /**
         * Defines the characteristic using Canonical.
         *
         * Defines the characteristic (without using type and value) by a Canonical
         */
        definitionCanonical?: string;
        /**
         * A human-readable string to clarify or explain concepts about the characteristic.
         *
         * Used for footnotes or explanatory notes
         */
        note?: Annotation[];
        /**
         * Defines the characteristic using CodeableConcept.
         *
         * Defines the characteristic (without using type and value) by a CodeableConcept
         */
        definitionCodeableConcept?: CodeableConcept;
        /**
         * Defines the characteristic using id.
         *
         * Defines the characteristic (without using type and value) by an id
         */
        definitionId?: string;
        /**
         * When true, this characteristic is an exclusion criterion. In other words, not matching this characteristic definition is equivalent to meeting this criterion.
         *
         * Whether the characteristic is an inclusion criterion or exclusion criterion
         */
        exclude?: boolean;
        /**
         * Defines the characteristic using Expression.
         *
         * Defines the characteristic (without using type and value) by an expression
         */
        definitionExpression?: Expression;
        /**
         * Label used for when a characteristic refers to another characteristic.
         *
         * Label for internal linking
         */
        linkId?: string;
        /**
         * Defines the characteristic as a combination of two or more characteristics.
         *
         * Used to specify how two or more characteristics are combined
         */
        definitionByCombination?: EvidenceVariable.EvidenceVariableCharacteristicDefinitionByCombinationComponent;
        /**
         * Length of time in which the characteristic is met.
         *
         * Length of time in which the characteristic is met
         */
        duration?: Quantity | Range;
        static revive(json: any): EvidenceVariableCharacteristicComponent;
        toJSON(): any;
    }
}
