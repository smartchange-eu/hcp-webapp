import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Dosage } from '../datatype/dosage';
import { Duration } from '../datatype/duration';
import { Identifier } from '../datatype/identifier';
import { Money } from '../datatype/money';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { Ratio } from '../datatype/ratio';
import { ClinicalUseDefinition } from '../model/clinical-use-definition';
import { DocumentReference } from '../model/document-reference';
import { DomainResource } from '../model/domain-resource';
import { Medication } from '../model/medication';
import { MedicinalProductDefinition } from '../model/medicinal-product-definition';
import { Organization } from '../model/organization';
import { PackagedProductDefinition } from '../model/packaged-product-definition';
/**
 * HAPI/FHIR <b>MedicationKnowledge</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/MedicationKnowledge">http://hl7.org/fhir/StructureDefinition/MedicationKnowledge</a>
 * </p>
 *
 */
export declare class MedicationKnowledge extends DomainResource {
    /**
     * Regulatory information about a medication.
     *
     * Regulatory information about a medication
     */
    regulatory?: MedicationKnowledge.MedicationKnowledgeRegulatoryComponent[];
    /**
     * The creator or owner of the knowledge or information about the medication.
     *
     * Creator or owner of the knowledge or information about the medication
     */
    author?: Organization | Reference;
    /**
     * Potential clinical issue with or between medication(s) (for example, drug-drug interaction, drug-disease contraindication, drug-allergy interaction, etc.).
     *
     * Potential clinical issue with or between medication(s)
     */
    clinicalUseIssue?: ClinicalUseDefinition[] | Reference[];
    /**
     * Guidelines or protocols that are applicable for the administration of the medication based on indication.
     *
     * Guidelines or protocols for administration of the medication for an indication
     */
    indicationGuideline?: MedicationKnowledge.MedicationKnowledgeIndicationGuidelineComponent[];
    /**
     * A code that specifies this medication, or a textual description if no code is available. Usage note: This could be a standard medication code such as a code from RxNorm, SNOMED CT, IDMP etc. It could also be a national or local formulary code, optionally with translations to other code systems.
     *
     * Code that identifies this medication
     */
    code?: CodeableConcept;
    /**
     * The price of the medication.
     *
     * The pricing of the medication
     */
    cost?: MedicationKnowledge.MedicationKnowledgeCostComponent[];
    /**
     * Business identifier for this medication.
     *
     * Business identifier for this medication
     */
    identifier?: Identifier[];
    /**
     * Along with the link to a Medicinal Product Definition resource, this information provides common definitional elements that are needed to understand the specific medication that is being described.
     *
     * Minimal definition information about the medication
     */
    definitional?: MedicationKnowledge.MedicationKnowledgeDefinitionalComponent;
    /**
     * The program under which the medication is reviewed.
     *
     * Program under which a medication is reviewed
     */
    monitoringProgram?: MedicationKnowledge.MedicationKnowledgeMonitoringProgramComponent[];
    /**
     * Links to associated medications that could be prescribed, dispensed or administered.
     *
     * The set of medication resources that are associated with this medication
     */
    associatedMedication?: Medication[] | Reference[];
    /**
     * Information that only applies to packages (not products).
     *
     * Details about packaged medications
     */
    packaging?: MedicationKnowledge.MedicationKnowledgePackagingComponent[];
    /**
     * Information on how the medication should be stored, for example, refrigeration temperatures and length of stability at a given temperature.
     *
     * How the medication should be stored
     */
    storageGuideline?: MedicationKnowledge.MedicationKnowledgeStorageGuidelineComponent[];
    /**
     * The instructions for preparing the medication.
     *
     * The instructions for preparing the medication
     */
    preparationInstruction?: string;
    /**
     * Categorization of the medication within a formulary or classification system.
     *
     * Categorization of the medication within a formulary or classification system
     */
    medicineClassification?: MedicationKnowledge.MedicationKnowledgeMedicineClassificationComponent[];
    /**
     * Associated documentation about the medication.
     *
     * Associated documentation about the medication
     */
    monograph?: MedicationKnowledge.MedicationKnowledgeMonographComponent[];
    /**
     * Lists the jurisdictions that this medication knowledge was written for.
     *
     * Codes that identify the different jurisdictions for which the information of this resource was created
     */
    intendedJurisdiction?: CodeableConcept[];
    /**
     * A code to indicate if the medication referred to by this MedicationKnowledge is in active use within the drug database or inventory system. The status refers to the validity about the information of the medication and not to its medicinal properties.
     *
     * active | entered-in-error | inactive
     */
    status?: string;
    /**
     * Category of the medication or product (e.g. branded product, therapeutic moeity, generic product, innovator product, etc.).
     *
     * Category of the medication or product
     */
    productType?: CodeableConcept[];
    /**
     * Associated or related medications. For example, if the medication is a branded product (e.g. Crestor), this is the Therapeutic Moeity (e.g. Rosuvastatin) or if this is a generic medication (e.g. Rosuvastatin), this would link to a branded product (e.g. Crestor.
     *
     * Associated or related medication information
     */
    relatedMedicationKnowledge?: MedicationKnowledge.MedicationKnowledgeRelatedMedicationKnowledgeComponent[];
    /**
     * All of the names for a medication, for example, the name(s) given to a medication in different countries.  For example, acetaminophen and paracetamol or salbutamol and albuterol.
     *
     * A name associated with the medication being described
     */
    name?: string[];
    readonly resourceType: string;
    static revive(json: any): MedicationKnowledge;
    toJSON(): any;
}
export declare namespace MedicationKnowledge {
    enum MedicationKnowledgeStatusCodes {
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        INACTIVE
    }
    class MedicationKnowledgeDefinitionalDrugCharacteristicComponent extends BackboneElement {
        /**
         * Description of the characteristic.
         *
         * Description of the characteristic
         */
        value?: CodeableConcept | string | Quantity | Attachment;
        /**
         * A code specifying which characteristic of the medicine is being described (for example, colour, shape, imprint).
         *
         * Code specifying the type of characteristic of medication
         */
        type?: CodeableConcept;
        static revive(json: any): MedicationKnowledgeDefinitionalDrugCharacteristicComponent;
        toJSON(): any;
    }
    class MedicationKnowledgeDefinitionalIngredientComponent extends BackboneElement {
        /**
         * Indication of whether this ingredient affects the therapeutic action of the drug.
         *
         * A code that defines the type of ingredient, active, base, etc
         */
        type?: CodeableConcept;
        /**
         * A reference to the resource that provides information about the ingredient.
         *
         * Substances contained in the medication
         */
        item: CodeableReference;
        /**
         * Specifies how many (or how much) of the items there are in this Medication.  For example, 250 mg per tablet.  This is expressed as a ratio where the numerator is 250mg and the denominator is 1 tablet but can also be expressed a quantity when the denominator is assumed to be 1 tablet.
         *
         * Quantity of ingredient present
         */
        strength?: Ratio | CodeableConcept | Quantity;
        static revive(json: any): MedicationKnowledgeDefinitionalIngredientComponent;
        toJSON(): any;
    }
    class MedicationKnowledgeDefinitionalComponent extends BackboneElement {
        /**
         * Specifies descriptive properties of the medicine, such as color, shape, imprints, etc.
         *
         * Specifies descriptive properties of the medicine
         */
        drugCharacteristic?: MedicationKnowledge.MedicationKnowledgeDefinitionalDrugCharacteristicComponent[];
        /**
         * Describes the form of the item.  Powder; tablets; capsule.
         *
         * powder | tablets | capsule +
         */
        doseForm?: CodeableConcept;
        /**
         * The intended or approved route of administration.
         *
         * The intended or approved route of administration
         */
        intendedRoute?: CodeableConcept[];
        /**
         * Identifies a particular constituent of interest in the product.
         *
         * Active or inactive ingredient
         */
        ingredient?: MedicationKnowledge.MedicationKnowledgeDefinitionalIngredientComponent[];
        /**
         * Associated definitions for this medication.
         *
         * Definitional resources that provide more information about this medication
         */
        definition?: MedicinalProductDefinition[] | Reference[];
        static revive(json: any): MedicationKnowledgeDefinitionalComponent;
        toJSON(): any;
    }
    class MedicationKnowledgeRegulatoryMaxDispenseComponent extends BackboneElement {
        /**
         * The period that applies to the maximum number of units.
         *
         * The period that applies to the maximum number of units
         */
        period?: Duration;
        /**
         * The maximum number of units of the medication that can be dispensed.
         *
         * The maximum number of units of the medication that can be dispensed
         */
        quantity: Quantity;
        static revive(json: any): MedicationKnowledgeRegulatoryMaxDispenseComponent;
        toJSON(): any;
    }
    class MedicationKnowledgeRegulatorySubstitutionComponent extends BackboneElement {
        /**
         * Specifies the type of substitution allowed.
         *
         * Specifies the type of substitution allowed
         */
        type: CodeableConcept;
        /**
         * Specifies if regulation allows for changes in the medication when dispensing.
         *
         * Specifies if regulation allows for changes in the medication when dispensing
         */
        allowed: boolean;
        static revive(json: any): MedicationKnowledgeRegulatorySubstitutionComponent;
        toJSON(): any;
    }
    class MedicationKnowledgeRegulatoryComponent extends BackboneElement {
        /**
         * Specifies the schedule of a medication in jurisdiction.
         *
         * Specifies the schedule of a medication in jurisdiction
         */
        schedule?: CodeableConcept[];
        /**
         * Specifies if changes are allowed when dispensing a medication from a regulatory perspective.
         *
         * Specifies if changes are allowed when dispensing a medication from a regulatory perspective
         */
        substitution?: MedicationKnowledge.MedicationKnowledgeRegulatorySubstitutionComponent[];
        /**
         * The maximum number of units of the medication that can be dispensed in a period.
         *
         * The maximum number of units of the medication that can be dispensed in a period
         */
        maxDispense?: MedicationKnowledge.MedicationKnowledgeRegulatoryMaxDispenseComponent;
        /**
         * The authority that is specifying the regulations.
         *
         * Specifies the authority of the regulation
         */
        regulatoryAuthority: Organization | Reference;
        static revive(json: any): MedicationKnowledgeRegulatoryComponent;
        toJSON(): any;
    }
    class MedicationKnowledgeStorageGuidelineEnvironmentalSettingComponent extends BackboneElement {
        /**
         * Value associated to the setting. E.g., 40° – 50°F for temperature.
         *
         * Value of the setting
         */
        value: Quantity | Range | CodeableConcept;
        /**
         * Identifies the category or type of setting (e.g., type of location, temperature, humidity).
         *
         * Categorization of the setting
         */
        type: CodeableConcept;
        static revive(json: any): MedicationKnowledgeStorageGuidelineEnvironmentalSettingComponent;
        toJSON(): any;
    }
    class MedicationKnowledgeStorageGuidelineComponent extends BackboneElement {
        /**
         * Reference to additional information about the storage guidelines.
         *
         * Reference to additional information
         */
        reference?: string;
        /**
         * Additional notes about the storage.
         *
         * Additional storage notes
         */
        note?: Annotation[];
        /**
         * Duration that the medication remains stable if the environmentalSetting is respected.
         *
         * Duration remains stable
         */
        stabilityDuration?: Duration;
        /**
         * Describes a setting/value on the environment for the adequate storage of the medication and other substances.  Environment settings may involve temperature, humidity, or exposure to light.
         *
         * Setting or value of environment for adequate storage
         */
        environmentalSetting?: MedicationKnowledge.MedicationKnowledgeStorageGuidelineEnvironmentalSettingComponent[];
        static revive(json: any): MedicationKnowledgeStorageGuidelineComponent;
        toJSON(): any;
    }
    class MedicationKnowledgePackagingComponent extends BackboneElement {
        /**
         * A reference to a PackagedProductDefinition that provides the details of the product that is in the packaging and is being priced.
         *
         * The packaged medication that is being priced
         */
        packagedProduct?: PackagedProductDefinition | Reference;
        /**
         * The cost of the packaged medication.
         *
         * Cost of the packaged medication
         */
        cost?: MedicationKnowledge.MedicationKnowledgeCostComponent[];
        static revive(json: any): MedicationKnowledgePackagingComponent;
        toJSON(): any;
    }
    class MedicationKnowledgeMedicineClassificationComponent extends BackboneElement {
        /**
         * The type of category for the medication (for example, therapeutic classification, therapeutic sub-classification).
         *
         * The type of category for the medication (for example, therapeutic classification, therapeutic sub-classification)
         */
        type: CodeableConcept;
        /**
         * Specific category assigned to the medication (e.g. anti-infective, anti-hypertensive, antibiotic, etc.).
         *
         * Specific category assigned to the medication
         */
        classification?: CodeableConcept[];
        /**
         * Either a textual source of the classification or a reference to an online source.
         *
         * The source of the classification
         */
        source?: string;
        static revive(json: any): MedicationKnowledgeMedicineClassificationComponent;
        toJSON(): any;
    }
    class MedicationKnowledgeIndicationGuidelineDosingGuidelinePatientCharacteristicComponent extends BackboneElement {
        /**
         * The specific characteristic (e.g. height, weight, gender, etc.).
         *
         * The specific characteristic
         */
        value?: CodeableConcept | Quantity | Range;
        /**
         * The categorization of the specific characteristic that is relevant to the administration guideline (e.g. height, weight, gender).
         *
         * Categorization of specific characteristic that is relevant to the administration guideline
         */
        type: CodeableConcept;
        static revive(json: any): MedicationKnowledgeIndicationGuidelineDosingGuidelinePatientCharacteristicComponent;
        toJSON(): any;
    }
    class MedicationKnowledgeIndicationGuidelineDosingGuidelineDosageComponent extends BackboneElement {
        /**
         * Dosage for the medication for the specific guidelines.
         *
         * Dosage for the medication for the specific guidelines
         */
        dosage: Dosage[];
        /**
         * The type or category of dosage for a given medication (for example, prophylaxis, maintenance, therapeutic, etc.).
         *
         * Category of dosage for a medication
         */
        type: CodeableConcept;
        static revive(json: any): MedicationKnowledgeIndicationGuidelineDosingGuidelineDosageComponent;
        toJSON(): any;
    }
    class MedicationKnowledgeIndicationGuidelineDosingGuidelineComponent extends BackboneElement {
        /**
         * Dosage for the medication for the specific guidelines.
         *
         * Dosage for the medication for the specific guidelines
         */
        dosage?: MedicationKnowledge.MedicationKnowledgeIndicationGuidelineDosingGuidelineDosageComponent[];
        /**
         * The type of the treatment that the guideline applies to, for example, long term therapy, first line treatment, etc.
         *
         * Type of treatment the guideline applies to
         */
        administrationTreatment?: CodeableConcept;
        /**
         * Characteristics of the patient that are relevant to the administration guidelines (for example, height, weight, gender, etc.).
         *
         * Characteristics of the patient that are relevant to the administration guidelines
         */
        patientCharacteristic?: MedicationKnowledge.MedicationKnowledgeIndicationGuidelineDosingGuidelinePatientCharacteristicComponent[];
        /**
         * The overall intention of the treatment, for example, prophylactic, supporative, curative, etc.
         *
         * Intention of the treatment
         */
        treatmentIntent?: CodeableConcept;
        static revive(json: any): MedicationKnowledgeIndicationGuidelineDosingGuidelineComponent;
        toJSON(): any;
    }
    class MedicationKnowledgeIndicationGuidelineComponent extends BackboneElement {
        /**
         * The guidelines for the dosage of the medication for the indication.
         *
         * Guidelines for dosage of the medication
         */
        dosingGuideline?: MedicationKnowledge.MedicationKnowledgeIndicationGuidelineDosingGuidelineComponent[];
        /**
         * Indication or reason for use of the medication that applies to the specific administration guideline.
         *
         * Indication for use that applies to the specific administration guideline
         */
        indication?: CodeableReference[];
        static revive(json: any): MedicationKnowledgeIndicationGuidelineComponent;
        toJSON(): any;
    }
    class MedicationKnowledgeMonitoringProgramComponent extends BackboneElement {
        /**
         * Type of program under which the medication is monitored.
         *
         * Type of program under which the medication is monitored
         */
        type?: CodeableConcept;
        /**
         * Name of the reviewing program.
         *
         * Name of the reviewing program
         */
        name?: string;
        static revive(json: any): MedicationKnowledgeMonitoringProgramComponent;
        toJSON(): any;
    }
    class MedicationKnowledgeCostComponent extends BackboneElement {
        /**
         * The price or representation of the cost (for example, Band A, Band B or $, $$) of the medication.
         *
         * The price or category of the cost of the medication
         */
        cost: Money | CodeableConcept;
        /**
         * The source or owner that assigns the price to the medication.
         *
         * The source or owner for the price information
         */
        source?: string;
        /**
         * The category of the cost information.  For example, manufacturers' cost, patient cost, claim reimbursement cost, actual acquisition cost.
         *
         * The category of the cost information
         */
        type: CodeableConcept;
        /**
         * The date range for which the cost information of the medication is effective.
         *
         * The date range for which the cost is effective
         */
        effectiveDate?: Period[];
        static revive(json: any): MedicationKnowledgeCostComponent;
        toJSON(): any;
    }
    class MedicationKnowledgeMonographComponent extends BackboneElement {
        /**
         * The category of documentation about the medication. (e.g. professional monograph, patient education monograph).
         *
         * The category of medication document
         */
        type?: CodeableConcept;
        /**
         * Associated documentation about the medication.
         *
         * Associated documentation about the medication
         */
        source?: DocumentReference | Reference;
        static revive(json: any): MedicationKnowledgeMonographComponent;
        toJSON(): any;
    }
    class MedicationKnowledgeRelatedMedicationKnowledgeComponent extends BackboneElement {
        /**
         * The category of the associated medication knowledge reference.
         *
         * Category of medicationKnowledge
         */
        type: CodeableConcept;
        /**
         * Associated documentation about the associated medication knowledge.
         *
         * Associated documentation about the associated medication knowledge
         */
        reference: MedicationKnowledge[] | Reference[];
        static revive(json: any): MedicationKnowledgeRelatedMedicationKnowledgeComponent;
        toJSON(): any;
    }
}
