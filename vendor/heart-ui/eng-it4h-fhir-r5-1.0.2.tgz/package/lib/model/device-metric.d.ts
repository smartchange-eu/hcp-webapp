import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
/**
 * HAPI/FHIR <b>DeviceMetric</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/DeviceMetric">http://hl7.org/fhir/StructureDefinition/DeviceMetric</a>
 * </p>
 *
 */
export declare class DeviceMetric extends DomainResource {
    /**
     * Describes the type of the metric. For example: Heart Rate, PEEP Setting, etc.
     *
     * Identity of metric, for example Heart Rate or PEEP Setting
     */
    type: CodeableConcept;
    /**
     * Indicates the category of the observation generation process. A DeviceMetric can be for example a setting, measurement, or calculation.
     *
     * measurement | setting | calculation | unspecified
     */
    category: string;
    /**
     * Describes the link to the Device.  This is also known as a channel device.
     *
     * Describes the link to the Device
     */
    device: Device | Reference;
    /**
     * Describes the calibrations that have been performed or that are required to be performed.
     *
     * Describes the calibrations that have been performed or that are required to be performed
     */
    calibration?: DeviceMetric.DeviceMetricCalibrationComponent[];
    /**
     * The frequency at which the metric is taken or recorded. Devices measure metrics at a wide range of frequencies; for example, an ECG might sample measurements in the millisecond range, while an NIBP might trigger only once an hour. Less often, the measurementFrequency may be based on a unit other than time, such as distance (e.g. for a measuring wheel). The update period may be different than the measurement frequency, if the device does not update the published observed value with the same frequency as it was measured.
     *
     * Indicates how often the metric is taken or recorded
     */
    measurementFrequency?: Quantity;
    /**
     * The preferred color associated with the metric (e.g., display color). This is often used to aid clinicians to track and identify parameter types by color. In practice, consider a Patient Monitor that has ECG/HR and Pleth; the metrics are displayed in different characteristic colors, such as HR in blue, BP in green, and PR and SpO2 in magenta.
     *
     * Color name (from CSS4) or #RRGGBB code
     */
    color?: string;
    /**
     * Indicates current operational state of the device. For example: On, Off, Standby, etc.
     *
     * on | off | standby | entered-in-error
     */
    operationalStatus?: string;
    /**
     * Instance identifiers assigned to a device, by the device or gateway software, manufacturers, other organizations or owners. For example, handle ID.
     *
     * Instance identifier
     */
    identifier?: Identifier[];
    /**
     * Describes the unit that an observed value determined for this metric will have. For example: Percent, Seconds, etc.
     *
     * Unit of Measure for the Metric
     */
    unit?: CodeableConcept;
    readonly resourceType: string;
    static revive(json: any): DeviceMetric;
    toJSON(): any;
}
export declare namespace DeviceMetric {
    enum DeviceMetricOperationalStatus {
        ENTEREDINERROR,
        NULL,
        STANDBY,
        OFF,
        ON
    }
    enum DeviceMetricCategory {
        UNSPECIFIED,
        NULL,
        CALCULATION,
        MEASUREMENT,
        SETTING
    }
    enum DeviceMetricCalibrationType {
        UNSPECIFIED,
        NULL,
        TWOPOINT,
        OFFSET,
        GAIN
    }
    enum DeviceMetricCalibrationState {
        UNSPECIFIED,
        NOTCALIBRATED,
        NULL,
        CALIBRATED,
        CALIBRATIONREQUIRED
    }
    class DeviceMetricCalibrationComponent extends BackboneElement {
        /**
         * Describes the state of the calibration.
         *
         * not-calibrated | calibration-required | calibrated | unspecified
         */
        state?: string;
        /**
         * Describes the time last calibration has been performed.
         *
         * Describes the time last calibration has been performed
         */
        time?: Date;
        /**
         * Describes the type of the calibration method.
         *
         * unspecified | offset | gain | two-point
         */
        type?: string;
        static revive(json: any): DeviceMetricCalibrationComponent;
        toJSON(): any;
    }
}
