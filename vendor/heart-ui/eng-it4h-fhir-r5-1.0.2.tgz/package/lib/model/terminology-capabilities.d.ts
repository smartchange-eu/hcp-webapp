import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { UsageContext } from '../datatype/usage-context';
import { CanonicalResource } from '../model/canonical-resource';
/**
 * HAPI/FHIR <b>TerminologyCapabilities</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/TerminologyCapabilities">http://hl7.org/fhir/StructureDefinition/TerminologyCapabilities</a>
 * </p>
 *
 */
export declare class TerminologyCapabilities extends CanonicalResource {
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * Whether the $closure operation is supported.
     *
     * Information about the [ConceptMap/$closure](conceptmap-operation-closure.html) operation
     */
    closure?: TerminologyCapabilities.TerminologyCapabilitiesClosureComponent;
    /**
     * A copyright statement relating to the terminology capabilities and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the terminology capabilities.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * The date  (and optionally time) when the terminology capabilities was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the terminology capabilities changes.
     *
     * Date last changed
     */
    date: Date;
    /**
     * A legal or geographic region in which the terminology capabilities is intended to be used.
     *
     * Intended jurisdiction for terminology capabilities (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * Software that is covered by this terminology capability statement.  It is used when the statement describes the capabilities of a particular software version, independent of an installation.
     *
     * Software that is covered by this terminology capability statement
     */
    software?: TerminologyCapabilities.TerminologyCapabilitiesSoftwareComponent;
    /**
     * Explanation of why this terminology capabilities is needed and why it has been designed as it has.
     *
     * Why this terminology capabilities is defined
     */
    purpose?: string;
    /**
     * A Boolean value to indicate that this terminology capabilities is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * The degree to which the server supports the code search parameter on ValueSet, if it is supported.
     *
     * in-compose | in-expansion | in-compose-or-expansion
     */
    codeSearch?: string;
    /**
     * A free text natural language description of the terminology capabilities from a consumer's perspective. Typically, this is used when the capability statement describes a desired rather than an actual solution, for example as a formal expression of requirements as part of an RFP.
     *
     * Natural language description of the terminology capabilities
     */
    description?: string;
    /**
     * Information about the [ValueSet/$validate-code](valueset-operation-validate-code.html) operation.
     *
     * Information about the [ValueSet/$validate-code](valueset-operation-validate-code.html) operation
     */
    validateCode?: TerminologyCapabilities.TerminologyCapabilitiesValidateCodeComponent;
    /**
     * A short, descriptive, user-friendly title for the terminology capabilities.
     *
     * Name for this terminology capabilities (human friendly)
     */
    title?: string;
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * A natural language name identifying the terminology capabilities. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this terminology capabilities (computer friendly)
     */
    name?: string;
    /**
     * Information about the [ConceptMap/$translate](conceptmap-operation-translate.html) operation.
     *
     * Information about the [ConceptMap/$translate](conceptmap-operation-translate.html) operation
     */
    translation?: TerminologyCapabilities.TerminologyCapabilitiesTranslationComponent;
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the terminology capabilities.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * The status of this terminology capabilities. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate terminology capabilities instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * Identifies a code system that is supported by the server. If there is a no code system URL, then this declares the general assumptions a client can make about support for any CodeSystem resource.
     *
     * A code system supported by the server
     */
    codeSystem?: TerminologyCapabilities.TerminologyCapabilitiesCodeSystemComponent[];
    /**
     * A formal identifier that is used to identify this terminology capabilities when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the terminology capabilities
     */
    identifier?: Identifier[];
    /**
     * The way that this statement is intended to be used, to describe an actual running instance of software, a particular product (kind, not instance of software) or a class of implementation (e.g. a desired purchase).
     *
     * instance | capability | requirements
     */
    kind: string;
    /**
     * Identifies a specific implementation instance that is described by the terminology capability statement - i.e. a particular installation, rather than the capabilities of a software program.
     *
     * If this describes a specific instance
     */
    implementation?: TerminologyCapabilities.TerminologyCapabilitiesImplementationComponent;
    /**
     * Whether the server supports lockedDate.
     *
     * Whether lockedDate is supported
     */
    lockedDate?: boolean;
    /**
     * An absolute URI that is used to identify this terminology capabilities when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this terminology capabilities is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the terminology capabilities is stored on different servers.
     *
     * Canonical identifier for this terminology capabilities, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * Information about the [ValueSet/$expand](valueset-operation-expand.html) operation.
     *
     * Information about the [ValueSet/$expand](valueset-operation-expand.html) operation
     */
    expansion?: TerminologyCapabilities.TerminologyCapabilitiesExpansionComponent;
    /**
     * The identifier that is used to identify this version of the terminology capabilities when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the terminology capabilities author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the terminology capabilities
     */
    version?: string;
    readonly resourceType: string;
    static revive(json: any): TerminologyCapabilities;
    toJSON(): any;
}
export declare namespace TerminologyCapabilities {
    enum CodeSearchSupport {
        NULL,
        INCOMPOSEOREXPANSION,
        INEXPANSION,
        INCOMPOSE
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    enum CapabilityStatementKind {
        REQUIREMENTS,
        NULL,
        INSTANCE,
        CAPABILITY
    }
    class TerminologyCapabilitiesClosureComponent extends BackboneElement {
        /**
         * If cross-system closure is supported.
         *
         * If cross-system closure is supported
         */
        translation?: boolean;
        static revive(json: any): TerminologyCapabilitiesClosureComponent;
        toJSON(): any;
    }
    class TerminologyCapabilitiesTranslationComponent extends BackboneElement {
        /**
         * Whether the client must identify the map.
         *
         * Whether the client must identify the map
         */
        needsMap: boolean;
        static revive(json: any): TerminologyCapabilitiesTranslationComponent;
        toJSON(): any;
    }
    class TerminologyCapabilitiesValidateCodeComponent extends BackboneElement {
        /**
         * Whether translations are validated.
         *
         * Whether translations are validated
         */
        translations: boolean;
        static revive(json: any): TerminologyCapabilitiesValidateCodeComponent;
        toJSON(): any;
    }
    class TerminologyCapabilitiesExpansionParameterComponent extends BackboneElement {
        /**
         * Name of the supported expansion parameter.
         *
         * Name of the supported expansion parameter
         */
        name: string;
        /**
         * Description of support for parameter.
         *
         * Description of support for parameter
         */
        documentation?: string;
        static revive(json: any): TerminologyCapabilitiesExpansionParameterComponent;
        toJSON(): any;
    }
    class TerminologyCapabilitiesExpansionComponent extends BackboneElement {
        /**
         * Whether the server supports paging on expansion.
         *
         * Whether the server supports paging on expansion
         */
        paging?: boolean;
        /**
         * Documentation about text searching works.
         *
         * Documentation about text searching works
         */
        textFilter?: string;
        /**
         * True if requests for incomplete expansions are allowed.
         *
         * Allow request for incomplete expansions?
         */
        incomplete?: boolean;
        /**
         * Whether the server can return nested value sets.
         *
         * Whether the server can return nested value sets
         */
        hierarchical?: boolean;
        /**
         * Supported expansion parameter.
         *
         * Supported expansion parameter
         */
        parameter?: TerminologyCapabilities.TerminologyCapabilitiesExpansionParameterComponent[];
        static revive(json: any): TerminologyCapabilitiesExpansionComponent;
        toJSON(): any;
    }
    class TerminologyCapabilitiesCodeSystemVersionFilterComponent extends BackboneElement {
        /**
         * Code of the property supported.
         *
         * Code of the property supported
         */
        code: string;
        /**
         * Operations supported for the property.
         *
         * Operations supported for the property
         */
        op: string[];
        static revive(json: any): TerminologyCapabilitiesCodeSystemVersionFilterComponent;
        toJSON(): any;
    }
    class TerminologyCapabilitiesCodeSystemVersionComponent extends BackboneElement {
        /**
         * Properties supported for $lookup.
         *
         * Properties supported for $lookup
         */
        property?: string[];
        /**
         * Language Displays supported.
         *
         * Language Displays supported
         */
        language?: string[];
        /**
         * Filter Properties supported.
         *
         * Filter Properties supported
         */
        filter?: TerminologyCapabilities.TerminologyCapabilitiesCodeSystemVersionFilterComponent[];
        /**
         * For version-less code systems, there should be a single version with no identifier.
         *
         * Version identifier for this version
         */
        code?: string;
        /**
         * If this is the default version for this code system.
         *
         * If this is the default version for this code system
         */
        isDefault?: boolean;
        /**
         * If the compositional grammar defined by the code system is supported.
         *
         * If compositional grammar is supported
         */
        compositional?: boolean;
        static revive(json: any): TerminologyCapabilitiesCodeSystemVersionComponent;
        toJSON(): any;
    }
    class TerminologyCapabilitiesCodeSystemComponent extends BackboneElement {
        /**
         * Canonical identifier for the code system, represented as a URI.
         *
         * Canonical identifier for the code system, represented as a URI
         */
        uri?: string;
        /**
         * For the code system, a list of versions that are supported by the server.
         *
         * Version of Code System supported
         */
        version?: TerminologyCapabilities.TerminologyCapabilitiesCodeSystemVersionComponent[];
        /**
         * The extent of the content of the code system (the concepts and codes it defines) are represented in this resource instance.
         *
         * not-present | example | fragment | complete | supplement
         */
        content: string;
        /**
         * True if subsumption is supported for this version of the code system.
         *
         * Whether subsumption is supported
         */
        subsumption?: boolean;
        static revive(json: any): TerminologyCapabilitiesCodeSystemComponent;
        toJSON(): any;
    }
    class TerminologyCapabilitiesImplementationComponent extends BackboneElement {
        /**
         * An absolute base URL for the implementation.
         *
         * Base URL for the implementation
         */
        url?: string;
        /**
         * Information about the specific installation that this terminology capability statement relates to.
         *
         * Describes this specific instance
         */
        description: string;
        static revive(json: any): TerminologyCapabilitiesImplementationComponent;
        toJSON(): any;
    }
    class TerminologyCapabilitiesSoftwareComponent extends BackboneElement {
        /**
         * Name the software is known by.
         *
         * A name the software is known by
         */
        name: string;
        /**
         * The version identifier for the software covered by this statement.
         *
         * Version covered by this statement
         */
        version?: string;
        static revive(json: any): TerminologyCapabilitiesSoftwareComponent;
        toJSON(): any;
    }
}
