import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Address } from '../datatype/address';
import { Age } from '../datatype/age';
import { Annotation } from '../datatype/annotation';
import { Attachment } from '../datatype/attachment';
import { Availability } from '../datatype/availability';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { ContactPoint } from '../datatype/contact-point';
import { Count } from '../datatype/count';
import { DataRequirement } from '../datatype/data-requirement';
import { Distance } from '../datatype/distance';
import { Dosage } from '../datatype/dosage';
import { Duration } from '../datatype/duration';
import { Expression } from '../datatype/expression';
import { ExtendedContactDetail } from '../datatype/extended-contact-detail';
import { HumanName } from '../datatype/human-name';
import { Identifier } from '../datatype/identifier';
import { Meta } from '../datatype/meta';
import { Money } from '../datatype/money';
import { ParameterDefinition } from '../datatype/parameter-definition';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { Ratio } from '../datatype/ratio';
import { RatioRange } from '../datatype/ratio-range';
import { RelatedArtifact } from '../datatype/related-artifact';
import { SampledData } from '../datatype/sampled-data';
import { Signature } from '../datatype/signature';
import { Timing } from '../datatype/timing';
import { TriggerDefinition } from '../datatype/trigger-definition';
import { UsageContext } from '../datatype/usage-context';
import { CareTeam } from '../model/care-team';
import { ClaimResponse } from '../model/claim-response';
import { Coverage } from '../model/coverage';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Provenance } from '../model/provenance';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Task</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Task">http://hl7.org/fhir/StructureDefinition/Task</a>
 * </p>
 *
 */
export declare class Task extends DomainResource {
    /**
     * The URL pointing to an *externally* maintained  protocol, guideline, orderset or other definition that is adhered to in whole or in part by this Task.
     *
     * Formal definition of task
     */
    instantiatesUri?: string;
    /**
     * Links to Provenance records for past versions of this Task that identify key state transitions or updates that are likely to be relevant to a user looking at the current version of the task.
     *
     * Key events in history of the Task
     */
    relevantHistory?: Provenance[] | Reference[];
    /**
     * A free-text description of what is to be performed.
     *
     * Human-readable explanation of task
     */
    description?: string;
    /**
     * The request being fulfilled or the resource being manipulated (changed, suspended, etc.) by this task.
     *
     * What task is acting on
     */
    focus?: Reference;
    /**
     * The kind of participant or specific participant that should perform the task.
     *
     * Who should perform Task
     */
    requestedPerformer?: CodeableReference[];
    /**
     * Indicates the start and/or end of the period of time when completion of the task is desired to take place.
     *
     * When the task should be performed
     */
    requestedPeriod?: Period;
    /**
     * The entity who benefits from the performance of the service specified in the task (e.g., the patient).
     *
     * Beneficiary of the Task
     */
    for?: Reference;
    /**
     * Task that this particular task is part of.
     *
     * Composite task
     */
    partOf?: Task[] | Reference[];
    /**
     * A description, code, or reference indicating why this task needs to be performed.
     *
     * Why task is needed
     */
    reason?: CodeableReference[];
    /**
     * Free-text information captured about the task as it progresses.
     *
     * Comments made about the task
     */
    note?: Annotation[];
    /**
     * Insurance plans, coverage extensions, pre-authorizations and/or pre-determinations that may be relevant to the Task.
     *
     * Associated insurance coverage
     */
    insurance?: Coverage[] | ClaimResponse[] | Reference[];
    /**
     * A name or code (or both) briefly describing what the task involves.
     *
     * Task Type
     */
    code?: CodeableConcept;
    /**
     * If true indicates that the Task is asking for the specified action to *not* occur.
     *
     * True if Task is prohibiting action
     */
    doNotPerform?: boolean;
    /**
     * BasedOn refers to a higher-level authorization that triggered the creation of the task.  It references a "request" resource such as a ServiceRequest, MedicationRequest, CarePlan, etc. which is distinct from the "request" resource the task is seeking to fulfill.  This latter resource is referenced by focus.  For example, based on a CarePlan (= basedOn), a task is created to fulfill a ServiceRequest ( = focus ) to collect a specimen from a patient.
     *
     * Request fulfilled by this task
     */
    basedOn?: Reference[];
    /**
     * Identifies the time action was first taken against the task (start) and/or the time final action was taken against the task prior to marking it as completed (end).
     *
     * Start and end time of execution
     */
    executionPeriod?: Period;
    /**
     * Outputs produced by the Task.
     *
     * Information produced as part of task
     */
    output?: Task.TaskOutputComponent[];
    /**
     * An explanation as to why this task is held, failed, was refused, etc.
     *
     * Reason for current status
     */
    statusReason?: CodeableReference;
    /**
     * Indicates the "level" of actionability associated with the Task, i.e. i+R[9]Cs this a proposed task, a planned task, an actionable task, etc.
     *
     * unknown | proposal | plan | order | original-order | reflex-order | filler-order | instance-order | option
     */
    intent: string;
    /**
     * The URL pointing to a *FHIR*-defined protocol, guideline, orderset or other definition that is adhered to in whole or in part by this Task.
     *
     * Formal definition of task
     */
    instantiatesCanonical?: string;
    /**
     * Indicates how quickly the Task should be addressed with respect to other requests.
     *
     * routine | urgent | asap | stat
     */
    priority?: string;
    /**
     * The healthcare event  (e.g. a patient and healthcare provider interaction) during which this task was created.
     *
     * Healthcare event during which this task originated
     */
    encounter?: Encounter | Reference;
    /**
     * Contains business-specific nuances of the business state.
     *
     * E.g. "Specimen collected", "IV prepped"
     */
    businessStatus?: CodeableConcept;
    /**
     * The business identifier for this task.
     *
     * Task Instance Identifier
     */
    identifier?: Identifier[];
    /**
     * The creator of the task.
     *
     * Who is asking for task to be done
     */
    requester?: Device | Organization | Patient | Practitioner | PractitionerRole | RelatedPerson | Reference;
    /**
     * Party responsible for managing task execution.
     *
     * Responsible individual
     */
    owner?: Practitioner | PractitionerRole | Organization | CareTeam | Patient | RelatedPerson | Reference;
    /**
     * The date and time this task was created.
     *
     * Task Creation Date
     */
    authoredOn?: Date;
    /**
     * The entity who performed the requested task.
     *
     * Who or what performed the task
     */
    performer?: Task.TaskPerformerComponent[];
    /**
     * A shared identifier common to multiple independent Task and Request instances that were activated/authorized more or less simultaneously by a single author.  The presence of the same identifier on each request ties those requests together and may have business ramifications in terms of reporting of results, billing, etc.  E.g. a requisition number shared by a set of lab tests ordered together, or a prescription number shared by all meds ordered at one time.
     *
     * Requisition or grouper id
     */
    groupIdentifier?: Identifier;
    /**
     * The current status of the task.
     *
     * draft | requested | received | accepted | +
     */
    status: string;
    /**
     * If the Task.focus is a request resource and the task is seeking fulfillment (i.e. is asking for the request to be actioned), this element identifies any limitations on what parts of the referenced request should be actioned.
     *
     * Constraints on fulfillment tasks
     */
    restriction?: Task.TaskRestrictionComponent;
    /**
     * The date and time of last modification to this task.
     *
     * Task Last Modified Date
     */
    lastModified?: Date;
    /**
     * Principal physical location where this task is performed.
     *
     * Where task occurs
     */
    location?: Location | Reference;
    /**
     * Additional information that may be needed in the execution of the task.
     *
     * Information used to perform task
     */
    input?: Task.TaskInputComponent[];
    readonly resourceType: string;
    static revive(json: any): Task;
    toJSON(): any;
}
export declare namespace Task {
    enum TaskStatus {
        READY,
        NULL,
        DRAFT,
        ONHOLD,
        RECEIVED,
        CANCELLED,
        ENTEREDINERROR,
        COMPLETED,
        ACCEPTED,
        FAILED,
        INPROGRESS,
        REQUESTED,
        REJECTED
    }
    enum TaskIntent {
        ORDER,
        FILLERORDER,
        ORIGINALORDER,
        NULL,
        REFLEXORDER,
        OPTION,
        PROPOSAL,
        UNKNOWN,
        PLAN,
        INSTANCEORDER
    }
    enum RequestPriority {
        URGENT,
        STAT,
        NULL,
        ROUTINE,
        ASAP
    }
    class TaskOutputComponent extends BackboneElement {
        /**
         * The value of the Output parameter as a basic type.
         *
         * Result of output
         */
        value: string | boolean | Date | Date | number | number | number | Date | number | Address | Age | Annotation | Attachment | CodeableConcept | CodeableReference | Coding | ContactPoint | Count | Distance | Duration | HumanName | Identifier | Money | Period | Quantity | Range | Ratio | RatioRange | Reference | SampledData | Signature | Timing | ContactDetail | DataRequirement | Expression | ParameterDefinition | RelatedArtifact | TriggerDefinition | UsageContext | Availability | ExtendedContactDetail | Dosage | Meta;
        /**
         * The name of the Output parameter.
         *
         * Label for output
         */
        type: CodeableConcept;
        static revive(json: any): TaskOutputComponent;
        toJSON(): any;
    }
    class TaskInputComponent extends BackboneElement {
        /**
         * A code or description indicating how the input is intended to be used as part of the task execution.
         *
         * Label for the input
         */
        type: CodeableConcept;
        /**
         * The value of the input parameter as a basic type.
         *
         * Content to use in performing the task
         */
        value: string | boolean | Date | Date | number | number | number | Date | number | Address | Age | Annotation | Attachment | CodeableConcept | CodeableReference | Coding | ContactPoint | Count | Distance | Duration | HumanName | Identifier | Money | Period | Quantity | Range | Ratio | RatioRange | Reference | SampledData | Signature | Timing | ContactDetail | DataRequirement | Expression | ParameterDefinition | RelatedArtifact | TriggerDefinition | UsageContext | Availability | ExtendedContactDetail | Dosage | Meta;
        static revive(json: any): TaskInputComponent;
        toJSON(): any;
    }
    class TaskRestrictionComponent extends BackboneElement {
        /**
         * Indicates the number of times the requested action should occur.
         *
         * How many times to repeat
         */
        repetitions?: number;
        /**
         * For requests that are targeted to more than one potential recipient/target, to identify who is fulfillment is sought for.
         *
         * For whom is fulfillment sought?
         */
        recipient?: Patient[] | Practitioner[] | PractitionerRole[] | RelatedPerson[] | Group[] | Organization[] | Reference[];
        /**
         * The time-period for which fulfillment is sought. This must fall within the overall time period authorized in the referenced request.  E.g. ServiceRequest.occurance[x].
         *
         * When fulfillment is sought
         */
        period?: Period;
        static revive(json: any): TaskRestrictionComponent;
        toJSON(): any;
    }
    class TaskPerformerComponent extends BackboneElement {
        /**
         * A code or description of the performer of the task.
         *
         * Type of performance
         */
        function?: CodeableConcept;
        /**
         * The actor or entity who performed the task.
         *
         * Who performed the task
         */
        actor: Practitioner | PractitionerRole | Organization | CareTeam | Patient | RelatedPerson | Reference;
        static revive(json: any): TaskPerformerComponent;
        toJSON(): any;
    }
}
