import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Endpoint } from '../model/endpoint';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Communication</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Communication">http://hl7.org/fhir/StructureDefinition/Communication</a>
 * </p>
 *
 */
export declare class Communication extends DomainResource {
    /**
     * Prior communication that this communication is in response to.
     *
     * Reply to
     */
    inResponseTo?: Communication[] | Reference[];
    /**
     * The entity (e.g. person, organization, clinical information system, or device) which is the source of the communication.
     *
     * Who shares the information
     */
    sender?: Device | Organization | Patient | Practitioner | PractitionerRole | RelatedPerson | HealthcareService | Endpoint | CareTeam | Reference;
    /**
     * Text, attachment(s), or resource(s) that was communicated to the recipient.
     *
     * Message payload
     */
    payload?: Communication.CommunicationPayloadComponent[];
    /**
     * Captures the reason for the current state of the Communication.
     *
     * Reason for current status
     */
    statusReason?: CodeableConcept;
    /**
     * An order, proposal or plan fulfilled in whole or in part by this Communication.
     *
     * Request fulfilled by this communication
     */
    basedOn?: Reference[];
    /**
     * The status of the transmission.
     *
     * preparation | in-progress | not-done | on-hold | stopped | completed | entered-in-error | unknown
     */
    status: string;
    /**
     * The type of message conveyed such as alert, notification, reminder, instruction, etc.
     *
     * Message category
     */
    category?: CodeableConcept[];
    /**
     * The entity (e.g. person, organization, clinical information system, care team or device) which is the target of the communication.
     *
     * Who the information is shared with
     */
    recipient?: CareTeam[] | Device[] | Group[] | HealthcareService[] | Location[] | Organization[] | Patient[] | Practitioner[] | PractitionerRole[] | RelatedPerson[] | Endpoint[] | Reference[];
    /**
     * Description of the purpose/content, similar to a subject line in an email.
     *
     * Description of the purpose/content
     */
    topic?: CodeableConcept;
    /**
     * The patient or group that was the focus of this communication.
     *
     * Focus of message
     */
    subject?: Patient | Group | Reference;
    /**
     * Business identifiers assigned to this communication by the performer or other systems which remain constant as the resource is updated and propagates from server to server.
     *
     * Unique identifier
     */
    identifier?: Identifier[];
    /**
     * A larger event (e.g. Communication, Procedure) of which this particular communication is a component or step.
     *
     * Part of referenced event (e.g. Communication, Procedure)
     */
    partOf?: Reference[];
    /**
     * The reason or justification for the communication.
     *
     * Indication for message
     */
    reason?: CodeableReference[];
    /**
     * Additional notes or commentary about the communication by the sender, receiver or other interested parties.
     *
     * Comments made about the communication
     */
    note?: Annotation[];
    /**
     * The URL pointing to an externally maintained protocol, guideline, orderset or other definition that is adhered to in whole or in part by this Communication.
     *
     * Instantiates external protocol or definition
     */
    instantiatesUri?: string[];
    /**
     * The URL pointing to a FHIR-defined protocol, guideline, orderset or other definition that is adhered to in whole or in part by this Communication.
     *
     * Instantiates FHIR protocol or definition
     */
    instantiatesCanonical?: string[];
    /**
     * Characterizes how quickly the planned or in progress communication must be addressed. Includes concepts such as stat, urgent, routine.
     *
     * routine | urgent | asap | stat
     */
    priority?: string;
    /**
     * The time when this communication was sent.
     *
     * When sent
     */
    sent?: Date;
    /**
     * The time when this communication arrived at the destination.
     *
     * When received
     */
    received?: Date;
    /**
     * A channel that was used for this communication (e.g. email, fax).
     *
     * A channel of communication
     */
    medium?: CodeableConcept[];
    /**
     * The Encounter during which this Communication was created or to which the creation of this record is tightly associated.
     *
     * The Encounter during which this Communication was created
     */
    encounter?: Encounter | Reference;
    /**
     * Other resources that pertain to this communication and to which this communication should be associated.
     *
     * Resources that pertain to this communication
     */
    about?: Reference[];
    readonly resourceType: string;
    static revive(json: any): Communication;
    toJSON(): any;
}
export declare namespace Communication {
    enum EventStatus {
        NOTDONE,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ONHOLD,
        STOPPED,
        INPROGRESS,
        UNKNOWN,
        PREPARATION
    }
    enum RequestPriority {
        URGENT,
        STAT,
        NULL,
        ROUTINE,
        ASAP
    }
    class CommunicationPayloadComponent extends BackboneElement {
        /**
         * A communicated content (or for multi-part communications, one portion of the communication).
         *
         * Message part content
         */
        content: Attachment | Reference | CodeableConcept;
        static revive(json: any): CommunicationPayloadComponent;
        toJSON(): any;
    }
}
