import { Reference } from '../datatype/reference';
import { Identifier } from '../datatype/identifier';
import { Coverage } from '../model/coverage';
import { DomainResource } from '../model/domain-resource';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
/**
 * HAPI/FHIR <b>EnrollmentRequest</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/EnrollmentRequest">http://hl7.org/fhir/StructureDefinition/EnrollmentRequest</a>
 * </p>
 *
 */
export declare class EnrollmentRequest extends DomainResource {
    /**
     * Patient Resource.
     *
     * The subject to be enrolled
     */
    candidate?: Patient | Reference;
    /**
     * Reference to the program or plan identification, underwriter or payor.
     *
     * Insurance information
     */
    coverage?: Coverage | Reference;
    /**
     * The Response business identifier.
     *
     * Business Identifier
     */
    identifier?: Identifier[];
    /**
     * The date when this resource was created.
     *
     * Creation date
     */
    created?: Date;
    /**
     * The Insurer who is target  of the request.
     *
     * Target
     */
    insurer?: Organization | Reference;
    /**
     * The practitioner who is responsible for the services rendered to the patient.
     *
     * Responsible practitioner
     */
    provider?: Practitioner | PractitionerRole | Organization | Reference;
    /**
     * The status of the resource instance.
     *
     * active | cancelled | draft | entered-in-error
     */
    status?: string;
    readonly resourceType: string;
    static revive(json: any): EnrollmentRequest;
    toJSON(): any;
}
export declare namespace EnrollmentRequest {
    enum FinancialResourceStatusCodes {
        CANCELLED,
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        DRAFT
    }
}
