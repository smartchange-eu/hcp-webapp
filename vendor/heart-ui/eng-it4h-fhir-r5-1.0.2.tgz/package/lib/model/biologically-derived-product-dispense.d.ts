import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { BiologicallyDerivedProduct } from '../model/biologically-derived-product';
import { DomainResource } from '../model/domain-resource';
import { Location } from '../model/location';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { ServiceRequest } from '../model/service-request';
/**
 * HAPI/FHIR <b>BiologicallyDerivedProductDispense</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/BiologicallyDerivedProductDispense">http://hl7.org/fhir/StructureDefinition/BiologicallyDerivedProductDispense</a>
 * </p>
 *
 */
export declare class BiologicallyDerivedProductDispense extends DomainResource {
    /**
     * Indicates the relationship between the donor of the biologically derived product and the intended recipient.
     *
     * Relationship between the donor and intended recipient
     */
    originRelationshipType?: CodeableConcept;
    /**
     * Link to a resource identifying the physical location that the product was dispatched to.
     *
     * Where the product was dispatched to
     */
    destination?: Location | Reference;
    /**
     * When the product was dispatched for clinical use.
     *
     * When the product was dispatched
     */
    whenHandedOver?: Date;
    /**
     * When the product was selected/ matched.
     *
     * When product was selected/matched
     */
    preparedDate?: Date;
    /**
     * Unique instance identifiers assigned to a biologically derived product dispense. Note: This is a business identifier, not a resource identifier.
     *
     * Business identifier for this dispense
     */
    identifier?: Identifier[];
    /**
     * A larger event of which this particular event is a component.
     *
     * Short description
     */
    partOf?: BiologicallyDerivedProductDispense[] | Reference[];
    /**
     * Additional notes.
     *
     * Additional notes
     */
    note?: Annotation[];
    /**
     * A link to a resource identifying the biologically derived product that is being dispensed.
     *
     * The BiologicallyDerivedProduct that is dispensed
     */
    product: BiologicallyDerivedProduct | Reference;
    /**
     * Indicates who or what performed an action.
     *
     * Indicates who or what performed an action
     */
    performer?: BiologicallyDerivedProductDispense.BiologicallyDerivedProductDispensePerformerComponent[];
    /**
     * The amount of product in the dispense. Quantity will depend on the product being dispensed. Examples are: volume; cell count; concentration.
     *
     * Amount dispensed
     */
    quantity?: Quantity;
    /**
     * The order or request that the dispense is fulfilling. This is a reference to a ServiceRequest resource.
     *
     * The order or request that this dispense is fulfilling
     */
    basedOn?: ServiceRequest[] | Reference[];
    /**
     * A code specifying the state of the dispense event.
     *
     * preparation | in-progress | allocated | issued | unfulfilled | returned | entered-in-error | unknown
     */
    status: string;
    /**
     * Specific instructions for use.
     *
     * Specific instructions for use
     */
    usageInstruction?: string;
    /**
     * The physical location where the dispense was performed.
     *
     * Where the dispense occurred
     */
    location?: Location | Reference;
    /**
     * A link to a resource representing the patient that the product is dispensed for.
     *
     * The intended recipient of the dispensed product
     */
    patient: Patient | Reference;
    /**
     * Indicates the type of matching associated with the dispense.
     *
     * Indicates the type of matching associated with the dispense
     */
    matchStatus?: CodeableConcept;
    readonly resourceType: string;
    static revive(json: any): BiologicallyDerivedProductDispense;
    toJSON(): any;
}
export declare namespace BiologicallyDerivedProductDispense {
    enum BiologicallyDerivedProductDispenseCodes {
        ISSUED,
        ENTEREDINERROR,
        NULL,
        RETURNED,
        INPROGRESS,
        ALLOCATED,
        UNFULFILLED,
        UNKNOWN,
        PREPARATION
    }
    class BiologicallyDerivedProductDispensePerformerComponent extends BackboneElement {
        /**
         * Identifies the function of the performer during the dispense.
         *
         * Identifies the function of the performer during the dispense
         */
        function?: CodeableConcept;
        /**
         * Identifies the person responsible for the action.
         *
         * Who performed the action
         */
        actor: Practitioner | Reference;
        static revive(json: any): BiologicallyDerivedProductDispensePerformerComponent;
        toJSON(): any;
    }
}
