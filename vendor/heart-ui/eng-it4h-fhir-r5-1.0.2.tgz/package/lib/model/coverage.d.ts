import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Money } from '../datatype/money';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Contract } from '../model/contract';
import { DomainResource } from '../model/domain-resource';
import { InsurancePlan } from '../model/insurance-plan';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Coverage</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Coverage">http://hl7.org/fhir/StructureDefinition/Coverage</a>
 * </p>
 *
 */
export declare class Coverage extends DomainResource {
    /**
     * The type of coverage: social program, medical plan, accident coverage (workers compensation, auto), group health or payment by an individual or organization.
     *
     * Coverage category such as medical or accident
     */
    type?: CodeableConcept;
    /**
     * The insurer-specific identifier for the insurer-defined network of providers to which the beneficiary may seek treatment which will be covered at the 'in-network' rate, otherwise 'out of network' terms and conditions apply.
     *
     * Insurer network
     */
    network?: string;
    /**
     * The insurer assigned ID for the Subscriber.
     *
     * ID assigned to the subscriber
     */
    subscriberId?: Identifier[];
    /**
     * A suite of underwriter specific classifiers.
     *
     * Additional coverage classifications
     */
    class?: Coverage.ClassComponent[];
    /**
     * Link to the paying party and optionally what specifically they will be responsible to pay.
     *
     * Self-pay parties and responsibility
     */
    paymentBy?: Coverage.CoveragePaymentByComponent[];
    /**
     * The policy(s) which constitute this insurance coverage.
     *
     * Contract details
     */
    contract?: Contract[] | Reference[];
    /**
     * The nature of the coverage be it insurance, or cash payment such as self-pay.
     *
     * insurance | self-pay | other
     */
    kind: string;
    /**
     * The identifier of the coverage as issued by the insurer.
     *
     * Business identifier(s) for this coverage
     */
    identifier?: Identifier[];
    /**
     * The party who has signed-up for or 'owns' the contractual relationship to the policy or to whom the benefit of the policy for services rendered to them or their family is due.
     *
     * Subscriber to the policy
     */
    subscriber?: Patient | RelatedPerson | Reference;
    /**
     * Time period during which the coverage is in force. A missing start date indicates the start date isn't known, a missing end date means the coverage is continuing to be in force.
     *
     * Coverage start and end dates
     */
    period?: Period;
    /**
     * A suite of codes indicating the cost category and associated amount which have been detailed in the policy and may have been  included on the health card.
     *
     * Patient payments for services/products
     */
    costToBeneficiary?: Coverage.CostToBeneficiaryComponent[];
    /**
     * When 'subrogation=true' this insurance instance has been included not for adjudication but to provide insurers with the details to recover costs.
     *
     * Reimbursement to insurer
     */
    subrogation?: boolean;
    /**
     * A designator for a dependent under the coverage.
     *
     * Dependent number
     */
    dependent?: string;
    /**
     * The relationship of beneficiary (patient) to the subscriber.
     *
     * Beneficiary relationship to the subscriber
     */
    relationship?: CodeableConcept;
    /**
     * The status of the resource instance.
     *
     * active | cancelled | draft | entered-in-error
     */
    status: string;
    /**
     * The party who 'owns' the insurance policy.
     *
     * Owner of the policy
     */
    policyHolder?: Patient | RelatedPerson | Organization | Reference;
    /**
     * The order of applicability of this coverage relative to other coverages which are currently in force. Note, there may be gaps in the numbering and this does not imply primary, secondary etc. as the specific positioning of coverages depends upon the episode of care. For example; a patient might have (0) auto insurance (1) their own health insurance and (2) spouse's health insurance. When claiming for treatments which were not the result of an auto accident then only coverages (1) and (2) above would be applicatble and would apply in the order specified in parenthesis.
     *
     * Relative order of the coverage
     */
    order?: number;
    /**
     * The insurance plan details, benefits and costs, which constitute this insurance coverage.
     *
     * Insurance plan details
     */
    insurancePlan?: InsurancePlan | Reference;
    /**
     * The party who benefits from the insurance coverage; the patient when products and/or services are provided.
     *
     * Plan beneficiary
     */
    beneficiary: Patient | Reference;
    /**
     * The program or plan underwriter, payor, insurance company.
     *
     * Issuer of the policy
     */
    insurer?: Organization | Reference;
    readonly resourceType: string;
    static revive(json: any): Coverage;
    toJSON(): any;
}
export declare namespace Coverage {
    enum Kind {
        OTHER,
        NULL,
        INSURANCE,
        SELFPAY
    }
    enum FinancialResourceStatusCodes {
        CANCELLED,
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        DRAFT
    }
    class ExemptionComponent extends BackboneElement {
        /**
         * The timeframe the exception is in force.
         *
         * The effective period of the exception
         */
        period?: Period;
        /**
         * The code for the specific exception.
         *
         * Exception category
         */
        type: CodeableConcept;
        static revive(json: any): ExemptionComponent;
        toJSON(): any;
    }
    class CostToBeneficiaryComponent extends BackboneElement {
        /**
         * The term or period of the values such as 'maximum lifetime benefit' or 'maximum annual visits'.
         *
         * Annual or lifetime
         */
        term?: CodeableConcept;
        /**
         * The amount due from the patient for the cost category.
         *
         * The amount or percentage due from the beneficiary
         */
        value?: Quantity | Money;
        /**
         * The category of patient centric costs associated with treatment.
         *
         * Cost category
         */
        type?: CodeableConcept;
        /**
         * Code to identify the general type of benefits under which products and services are provided.
         *
         * Benefit classification
         */
        category?: CodeableConcept;
        /**
         * Is a flag to indicate whether the benefits refer to in-network providers or out-of-network providers.
         *
         * In or out of network
         */
        network?: CodeableConcept;
        /**
         * A suite of codes indicating exceptions or reductions to patient costs and their effective periods.
         *
         * Exceptions for patient payments
         */
        exception?: Coverage.ExemptionComponent[];
        /**
         * Indicates if the benefits apply to an individual or to the family.
         *
         * Individual or family
         */
        unit?: CodeableConcept;
        static revive(json: any): CostToBeneficiaryComponent;
        toJSON(): any;
    }
    class ClassComponent extends BackboneElement {
        /**
         * A short description for the class.
         *
         * Human readable description of the type and value
         */
        name?: string;
        /**
         * The alphanumeric identifier associated with the insurer issued label.
         *
         * Value associated with the type
         */
        value: Identifier;
        /**
         * The type of classification for which an insurer-specific class label or number and optional name is provided.  For example, type may be used to identify a class of coverage or employer group, policy, or plan.
         *
         * Type of class such as 'group' or 'plan'
         */
        type: CodeableConcept;
        static revive(json: any): ClassComponent;
        toJSON(): any;
    }
    class CoveragePaymentByComponent extends BackboneElement {
        /**
         * The list of parties providing non-insurance payment for the treatment costs.
         *
         * Parties performing self-payment
         */
        party: Patient | RelatedPerson | Organization | Reference;
        /**
         *  Description of the financial responsibility.
         *
         * Party's responsibility
         */
        responsibility?: string;
        static revive(json: any): CoveragePaymentByComponent;
        toJSON(): any;
    }
}
