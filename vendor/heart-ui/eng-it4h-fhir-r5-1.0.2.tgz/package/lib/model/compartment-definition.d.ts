import { BackboneElement } from '../datatype/backbone-element';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { UsageContext } from '../datatype/usage-context';
import { CanonicalResource } from '../model/canonical-resource';
/**
 * HAPI/FHIR <b>CompartmentDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/CompartmentDefinition">http://hl7.org/fhir/StructureDefinition/CompartmentDefinition</a>
 * </p>
 *
 */
export declare class CompartmentDefinition extends CanonicalResource {
    /**
     * The status of this compartment definition. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate compartment definition instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the compartment definition.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * A natural language name identifying the compartment definition. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this compartment definition (computer friendly)
     */
    name: string;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * Whether the search syntax is supported,.
     *
     * Whether the search syntax is supported
     */
    search: boolean;
    /**
     * An absolute URI that is used to identify this compartment definition when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this compartment definition is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the compartment definition is stored on different servers.
     *
     * Canonical identifier for this compartment definition, represented as a URI (globally unique)
     */
    url: string;
    /**
     * The identifier that is used to identify this version of the compartment definition when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the compartment definition author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the compartment definition
     */
    version?: string;
    /**
     * A short, descriptive, user-friendly title for the capability statement.
     *
     * Name for this compartment definition (human friendly)
     */
    title?: string;
    /**
     * A Boolean value to indicate that this compartment definition is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A free text natural language description of the compartment definition from a consumer's perspective.
     *
     * Natural language description of the compartment definition
     */
    description?: string;
    /**
     * Explanation of why this compartment definition is needed and why it has been designed as it has.
     *
     * Why this compartment definition is defined
     */
    purpose?: string;
    /**
     * Information about how a resource is related to the compartment.
     *
     * How a resource is related to the compartment
     */
    resource?: CompartmentDefinition.CompartmentDefinitionResourceComponent[];
    /**
     * Which compartment this definition describes.
     *
     * Patient | Encounter | RelatedPerson | Practitioner | Device | EpisodeOfCare
     */
    code: string;
    /**
     * The date  (and optionally time) when the compartment definition was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the compartment definition changes.
     *
     * Date last changed
     */
    date?: Date;
    readonly resourceType: string;
    static revive(json: any): CompartmentDefinition;
    toJSON(): any;
}
export declare namespace CompartmentDefinition {
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    enum CompartmentType {
        ENCOUNTER,
        NULL,
        PRACTITIONER,
        RELATEDPERSON,
        DEVICE,
        PATIENT,
        EPISODEOFCARE
    }
    class CompartmentDefinitionResourceComponent extends BackboneElement {
        /**
         * Additional documentation about the resource and compartment.
         *
         * Additional documentation about the resource and compartment
         */
        documentation?: string;
        /**
         * The name of a search parameter that represents the link to the compartment. More than one may be listed because a resource may be linked to a compartment in more than one way,.
         *
         * Search Parameter Name, or chained parameters
         */
        param?: string[];
        /**
         * Search Parameter for mapping requests made with $everything.start (e.g. on [Patient.$everything](patient-operation-everything.html)).
         *
         * Search Param for interpreting $everything.start
         */
        startParam?: string;
        /**
         * The name of a resource supported by the server.
         *
         * Name of resource type
         */
        code: string;
        /**
         * Search Parameter for mapping requests made with $everything.end (e.g. on [Patient.$everything](patient-operation-everything.html)).
         *
         * Search Param for interpreting $everything.end
         */
        endParam?: string;
        static revive(json: any): CompartmentDefinitionResourceComponent;
        toJSON(): any;
    }
}
