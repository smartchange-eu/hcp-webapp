import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { DomainResource } from '../model/domain-resource';
import { Immunization } from '../model/immunization';
import { ImmunizationEvaluation } from '../model/immunization-evaluation';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
/**
 * HAPI/FHIR <b>ImmunizationRecommendation</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ImmunizationRecommendation">http://hl7.org/fhir/StructureDefinition/ImmunizationRecommendation</a>
 * </p>
 *
 */
export declare class ImmunizationRecommendation extends DomainResource {
    /**
     * Indicates the authority who published the protocol (e.g. ACIP).
     *
     * Who is responsible for protocol
     */
    authority?: Organization | Reference;
    /**
     * The patient the recommendation(s) are for.
     *
     * Who this profile is for
     */
    patient: Patient | Reference;
    /**
     * A unique identifier assigned to this particular recommendation record.
     *
     * Business identifier
     */
    identifier?: Identifier[];
    /**
     * The date the immunization recommendation(s) were created.
     *
     * Date recommendation(s) created
     */
    date: Date;
    /**
     * Vaccine administration recommendations.
     *
     * Vaccine administration recommendations
     */
    recommendation: ImmunizationRecommendation.ImmunizationRecommendationRecommendationComponent[];
    readonly resourceType: string;
    static revive(json: any): ImmunizationRecommendation;
    toJSON(): any;
}
export declare namespace ImmunizationRecommendation {
    class ImmunizationRecommendationRecommendationDateCriterionComponent extends BackboneElement {
        /**
         * Date classification of recommendation.  For example, earliest date to give, latest date to give, etc.
         *
         * Type of date
         */
        code: CodeableConcept;
        /**
         * The date whose meaning is specified by dateCriterion.code.
         *
         * Recommended date
         */
        value: Date;
        static revive(json: any): ImmunizationRecommendationRecommendationDateCriterionComponent;
        toJSON(): any;
    }
    class ImmunizationRecommendationRecommendationComponent extends BackboneElement {
        /**
         * Vaccine(s) which should not be used to fulfill the recommendation.
         *
         * Vaccine which is contraindicated to fulfill the recommendation
         */
        contraindicatedVaccineCode?: CodeableConcept[];
        /**
         * The reason for the assigned forecast status.
         *
         * Vaccine administration status reason
         */
        forecastReason?: CodeableConcept[];
        /**
         * Nominal position of the recommended dose in a series as determined by the evaluation and forecasting process (e.g. dose 2 is the next recommended dose).
         *
         * Recommended dose number within series
         */
        doseNumber?: string;
        /**
         * The recommended number of doses to achieve immunity as determined by the evaluation and forecasting process.
         *
         * Recommended number of doses for immunity
         */
        seriesDoses?: string;
        /**
         * Immunization event history and/or evaluation that supports the status and recommendation.
         *
         * Past immunizations supporting recommendation
         */
        supportingImmunization?: Immunization[] | ImmunizationEvaluation[] | Reference[];
        /**
         * One possible path to achieve presumed immunity against a disease - within the context of an authority.
         *
         * Name of vaccination series
         */
        series?: string;
        /**
         * Patient Information that supports the status and recommendation.  This includes patient observations, adverse reactions and allergy/intolerance information.
         *
         * Patient observations supporting recommendation
         */
        supportingPatientInformation?: Reference[];
        /**
         * The targeted disease for the recommendation.
         *
         * Disease to be immunized against
         */
        targetDisease?: CodeableConcept[];
        /**
         * Indicates the patient status with respect to the path to immunity for the target disease.
         *
         * Vaccine recommendation status
         */
        forecastStatus: CodeableConcept;
        /**
         * Contains the description about the protocol under which the vaccine was administered.
         *
         * Protocol details
         */
        description?: string;
        /**
         * Vaccine(s) or vaccine group that pertain to the recommendation.
         *
         * Vaccine  or vaccine group recommendation applies to
         */
        vaccineCode?: CodeableConcept[];
        /**
         * Vaccine date recommendations.  For example, earliest date to administer, latest date to administer, etc.
         *
         * Dates governing proposed immunization
         */
        dateCriterion?: ImmunizationRecommendation.ImmunizationRecommendationRecommendationDateCriterionComponent[];
        static revive(json: any): ImmunizationRecommendationRecommendationComponent;
        toJSON(): any;
    }
}
