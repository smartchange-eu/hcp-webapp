import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Signature } from '../datatype/signature';
import { Timing } from '../datatype/timing';
import { DomainResource } from '../model/domain-resource';
import { Organization } from '../model/organization';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
/**
 * HAPI/FHIR <b>VerificationResult</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/VerificationResult">http://hl7.org/fhir/StructureDefinition/VerificationResult</a>
 * </p>
 *
 */
export declare class VerificationResult extends DomainResource {
    /**
     * The date/time validation was last completed (including failed validations).
     *
     * The date/time validation was last completed (including failed validations)
     */
    lastPerformed?: Date;
    /**
     * The validation status of the target (attested; validated; in process; requires revalidation; validation failed; revalidation failed).
     *
     * attested | validated | in-process | req-revalid | val-fail | reval-fail | entered-in-error
     */
    status: string;
    /**
     * The primary process by which the target is validated (edit check; value set; primary source; multiple sources; standalone; in context).
     *
     * The primary process by which the target is validated (edit check; value set; primary source; multiple sources; standalone; in context)
     */
    validationProcess?: CodeableConcept[];
    /**
     * What the target is validated against (nothing; primary source; multiple sources).
     *
     * nothing | primary | multiple
     */
    validationType?: CodeableConcept;
    /**
     * The frequency with which the target must be validated (none; initial; periodic).
     *
     * none | initial | periodic
     */
    need?: CodeableConcept;
    /**
     * The result if validation fails (fatal; warning; record only; none).
     *
     * fatal | warn | rec-only | none
     */
    failureAction?: CodeableConcept;
    /**
     * Information about the entity attesting to information.
     *
     * Information about the entity attesting to information
     */
    attestation?: VerificationResult.VerificationResultAttestationComponent;
    /**
     * When the validation status was updated.
     *
     * When the validation status was updated
     */
    statusDate?: Date;
    /**
     * The date when target is next validated, if appropriate.
     *
     * The date when target is next validated, if appropriate
     */
    nextScheduled?: Date;
    /**
     * Information about the primary source(s) involved in validation.
     *
     * Information about the primary source(s) involved in validation
     */
    primarySource?: VerificationResult.VerificationResultPrimarySourceComponent[];
    /**
     * A resource that was validated.
     *
     * A resource that was validated
     */
    target?: Reference[];
    /**
     * Frequency of revalidation.
     *
     * Frequency of revalidation
     */
    frequency?: Timing;
    /**
     * The fhirpath location(s) within the resource that was validated.
     *
     * The fhirpath location(s) within the resource that was validated
     */
    targetLocation?: string[];
    /**
     * Information about the entity validating information.
     *
     * Information about the entity validating information
     */
    validator?: VerificationResult.VerificationResultValidatorComponent[];
    readonly resourceType: string;
    static revive(json: any): VerificationResult;
    toJSON(): any;
}
export declare namespace VerificationResult {
    enum VerificationResultStatus {
        ENTEREDINERROR,
        REVALFAIL,
        NULL,
        REQREVALID,
        ATTESTED,
        VALIDATED,
        INPROCESS,
        VALFAIL
    }
    class VerificationResultValidatorComponent extends BackboneElement {
        /**
         * Reference to the organization validating information.
         *
         * Reference to the organization validating information
         */
        organization: Organization | Reference;
        /**
         * A digital identity certificate associated with the validator.
         *
         * A digital identity certificate associated with the validator
         */
        identityCertificate?: string;
        /**
         * Signed assertion by the validator that they have validated the information.
         *
         * Validator signature (digital or image)
         */
        attestationSignature?: Signature;
        static revive(json: any): VerificationResultValidatorComponent;
        toJSON(): any;
    }
    class VerificationResultAttestationComponent extends BackboneElement {
        /**
         * The method by which attested information was submitted/retrieved (manual; API; Push).
         *
         * The method by which attested information was submitted/retrieved
         */
        communicationMethod?: CodeableConcept;
        /**
         * A digital identity certificate associated with the proxy entity submitting attested information on behalf of the attestation source.
         *
         * A digital identity certificate associated with the proxy entity submitting attested information on behalf of the attestation source
         */
        proxyIdentityCertificate?: string;
        /**
         * The date the information was attested to.
         *
         * The date the information was attested to
         */
        date?: Date;
        /**
         * A digital identity certificate associated with the attestation source.
         *
         * A digital identity certificate associated with the attestation source
         */
        sourceIdentityCertificate?: string;
        /**
         * Signed assertion by the attestation source that they have attested to the information.
         *
         * Attester signature (digital or image)
         */
        sourceSignature?: Signature;
        /**
         * The individual or organization attesting to information.
         *
         * The individual or organization attesting to information
         */
        who?: Practitioner | PractitionerRole | Organization | Reference;
        /**
         * Signed assertion by the proxy entity indicating that they have the right to submit attested information on behalf of the attestation source.
         *
         * Proxy signature (digital or image)
         */
        proxySignature?: Signature;
        /**
         * When the who is asserting on behalf of another (organization or individual).
         *
         * When the who is asserting on behalf of another (organization or individual)
         */
        onBehalfOf?: Organization | Practitioner | PractitionerRole | Reference;
        static revive(json: any): VerificationResultAttestationComponent;
        toJSON(): any;
    }
    class VerificationResultPrimarySourceComponent extends BackboneElement {
        /**
         * Method for communicating with the primary source (manual; API; Push).
         *
         * Method for exchanging information with the primary source
         */
        communicationMethod?: CodeableConcept[];
        /**
         * Type of alerts/updates the primary source can send (specific requested changes; any changes; as defined by source).
         *
         * specific | any | source
         */
        pushTypeAvailable?: CodeableConcept[];
        /**
         * Reference to the primary source.
         *
         * Reference to the primary source
         */
        who?: Organization | Practitioner | PractitionerRole | Reference;
        /**
         * Ability of the primary source to push updates/alerts (yes; no; undetermined).
         *
         * yes | no | undetermined
         */
        canPushUpdates?: CodeableConcept;
        /**
         * Status of the validation of the target against the primary source (successful; failed; unknown).
         *
         * successful | failed | unknown
         */
        validationStatus?: CodeableConcept;
        /**
         * Type of primary source (License Board; Primary Education; Continuing Education; Postal Service; Relationship owner; Registration Authority; legal source; issuing source; authoritative source).
         *
         * Type of primary source (License Board; Primary Education; Continuing Education; Postal Service; Relationship owner; Registration Authority; legal source; issuing source; authoritative source)
         */
        type?: CodeableConcept[];
        /**
         * When the target was validated against the primary source.
         *
         * When the target was validated against the primary source
         */
        validationDate?: Date;
        static revive(json: any): VerificationResultPrimarySourceComponent;
        toJSON(): any;
    }
}
