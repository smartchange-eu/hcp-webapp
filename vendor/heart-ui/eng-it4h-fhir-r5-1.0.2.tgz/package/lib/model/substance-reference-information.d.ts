import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { DocumentReference } from '../model/document-reference';
import { DomainResource } from '../model/domain-resource';
/**
 * HAPI/FHIR <b>SubstanceReferenceInformation</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/SubstanceReferenceInformation">http://hl7.org/fhir/StructureDefinition/SubstanceReferenceInformation</a>
 * </p>
 *
 */
export declare class SubstanceReferenceInformation extends DomainResource {
    /**
     * Todo.
     *
     * Todo
     */
    target?: SubstanceReferenceInformation.SubstanceReferenceInformationTargetComponent[];
    /**
     * Todo.
     *
     * Todo
     */
    comment?: string;
    /**
     * Todo.
     *
     * Todo
     */
    gene?: SubstanceReferenceInformation.SubstanceReferenceInformationGeneComponent[];
    /**
     * Todo.
     *
     * Todo
     */
    geneElement?: SubstanceReferenceInformation.SubstanceReferenceInformationGeneElementComponent[];
    readonly resourceType: string;
    static revive(json: any): SubstanceReferenceInformation;
    toJSON(): any;
}
export declare namespace SubstanceReferenceInformation {
    class SubstanceReferenceInformationTargetComponent extends BackboneElement {
        /**
         * Todo.
         *
         * Todo
         */
        interaction?: CodeableConcept;
        /**
         * Todo.
         *
         * Todo
         */
        source?: DocumentReference[] | Reference[];
        /**
         * Todo.
         *
         * Todo
         */
        type?: CodeableConcept;
        /**
         * Todo.
         *
         * Todo
         */
        target?: Identifier;
        /**
         * Todo.
         *
         * Todo
         */
        organismType?: CodeableConcept;
        /**
         * Todo.
         *
         * Todo
         */
        amountType?: CodeableConcept;
        /**
         * Todo.
         *
         * Todo
         */
        amount?: Quantity | Range | string;
        /**
         * Todo.
         *
         * Todo
         */
        organism?: CodeableConcept;
        static revive(json: any): SubstanceReferenceInformationTargetComponent;
        toJSON(): any;
    }
    class SubstanceReferenceInformationGeneElementComponent extends BackboneElement {
        /**
         * Todo.
         *
         * Todo
         */
        source?: DocumentReference[] | Reference[];
        /**
         * Todo.
         *
         * Todo
         */
        element?: Identifier;
        /**
         * Todo.
         *
         * Todo
         */
        type?: CodeableConcept;
        static revive(json: any): SubstanceReferenceInformationGeneElementComponent;
        toJSON(): any;
    }
    class SubstanceReferenceInformationGeneComponent extends BackboneElement {
        /**
         * Todo.
         *
         * Todo
         */
        geneSequenceOrigin?: CodeableConcept;
        /**
         * Todo.
         *
         * Todo
         */
        source?: DocumentReference[] | Reference[];
        /**
         * Todo.
         *
         * Todo
         */
        gene?: CodeableConcept;
        static revive(json: any): SubstanceReferenceInformationGeneComponent;
        toJSON(): any;
    }
}
