import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { DomainResource } from '../model/domain-resource';
/**
 * HAPI/FHIR <b>SubstanceSourceMaterial</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/SubstanceSourceMaterial">http://hl7.org/fhir/StructureDefinition/SubstanceSourceMaterial</a>
 * </p>
 *
 */
export declare class SubstanceSourceMaterial extends DomainResource {
    /**
     * The place/region where the plant is harvested or the places/regions where the animal source material has its habitat.
     *
     * The place/region where the plant is harvested or the places/regions where the animal source material has its habitat
     */
    geographicalLocation?: string[];
    /**
     * This subclause describes the organism which the substance is derived from. For vaccines, the parent organism shall be specified based on these subclause elements. As an example, full taxonomy will be described for the Substance Name: ., Leaf.
     *
     * This subclause describes the organism which the substance is derived from. For vaccines, the parent organism shall be specified based on these subclause elements. As an example, full taxonomy will be described for the Substance Name: ., Leaf
     */
    organism?: SubstanceSourceMaterial.SubstanceSourceMaterialOrganismComponent;
    /**
     * The type of the source material shall be specified based on a controlled vocabulary. For vaccines, this subclause refers to the class of infectious agent.
     *
     * The type of the source material shall be specified based on a controlled vocabulary. For vaccines, this subclause refers to the class of infectious agent
     */
    sourceMaterialType?: CodeableConcept;
    /**
     * The organism accepted Scientific name shall be provided based on the organism taxonomy.
     *
     * The organism accepted Scientific name shall be provided based on the organism taxonomy
     */
    organismName?: string;
    /**
     * To do.
     *
     * To do
     */
    partDescription?: SubstanceSourceMaterial.SubstanceSourceMaterialPartDescriptionComponent[];
    /**
     * The unique identifier associated with the source material parent organism shall be specified.
     *
     * The unique identifier associated with the source material parent organism shall be specified
     */
    organismId?: Identifier;
    /**
     * The parent substance of the Herbal Drug, or Herbal preparation.
     *
     * The parent substance of the Herbal Drug, or Herbal preparation
     */
    parentSubstanceName?: string[];
    /**
     * Stage of life for animals, plants, insects and microorganisms. This information shall be provided only when the substance is significantly different in these stages (e.g. foetal bovine serum).
     *
     * Stage of life for animals, plants, insects and microorganisms. This information shall be provided only when the substance is significantly different in these stages (e.g. foetal bovine serum)
     */
    developmentStage?: CodeableConcept;
    /**
     * The state of the source material when extracted.
     *
     * The state of the source material when extracted
     */
    sourceMaterialState?: CodeableConcept;
    /**
     * The country where the plant material is harvested or the countries where the plasma is sourced from as laid down in accordance with the Plasma Master File. For “Plasma-derived substances” the attribute country of origin provides information about the countries used for the manufacturing of the Cryopoor plama or Crioprecipitate.
     *
     * The country where the plant material is harvested or the countries where the plasma is sourced from as laid down in accordance with the Plasma Master File. For “Plasma-derived substances” the attribute country of origin provides information about the countries used for the manufacturing of the Cryopoor plama or Crioprecipitate
     */
    countryOfOrigin?: CodeableConcept[];
    /**
     * General high level classification of the source material specific to the origin of the material.
     *
     * General high level classification of the source material specific to the origin of the material
     */
    sourceMaterialClass?: CodeableConcept;
    /**
     * The parent of the herbal drug Ginkgo biloba, Leaf is the substance ID of the substance (fresh) of Ginkgo biloba L. or Ginkgo biloba L. (Whole plant).
     *
     * The parent of the herbal drug Ginkgo biloba, Leaf is the substance ID of the substance (fresh) of Ginkgo biloba L. or Ginkgo biloba L. (Whole plant)
     */
    parentSubstanceId?: Identifier[];
    /**
     * Many complex materials are fractions of parts of plants, animals, or minerals. Fraction elements are often necessary to define both Substances and Specified Group 1 Substances. For substances derived from Plants, fraction information will be captured at the Substance information level ( . Oils, Juices and Exudates). Additional information for Extracts, such as extraction solvent composition, will be captured at the Specified Substance Group 1 information level. For plasma-derived products fraction information will be captured at the Substance and the Specified Substance Group 1 levels.
     *
     * Many complex materials are fractions of parts of plants, animals, or minerals. Fraction elements are often necessary to define both Substances and Specified Group 1 Substances. For substances derived from Plants, fraction information will be captured at the Substance information level ( . Oils, Juices and Exudates). Additional information for Extracts, such as extraction solvent composition, will be captured at the Specified Substance Group 1 information level. For plasma-derived products fraction information will be captured at the Substance and the Specified Substance Group 1 levels
     */
    fractionDescription?: SubstanceSourceMaterial.SubstanceSourceMaterialFractionDescriptionComponent[];
    readonly resourceType: string;
    static revive(json: any): SubstanceSourceMaterial;
    toJSON(): any;
}
export declare namespace SubstanceSourceMaterial {
    class SubstanceSourceMaterialPartDescriptionComponent extends BackboneElement {
        /**
         * Entity of anatomical origin of source material within an organism.
         *
         * Entity of anatomical origin of source material within an organism
         */
        part?: CodeableConcept;
        /**
         * The detailed anatomic location when the part can be extracted from different anatomical locations of the organism. Multiple alternative locations may apply.
         *
         * The detailed anatomic location when the part can be extracted from different anatomical locations of the organism. Multiple alternative locations may apply
         */
        partLocation?: CodeableConcept;
        static revive(json: any): SubstanceSourceMaterialPartDescriptionComponent;
        toJSON(): any;
    }
    class SubstanceSourceMaterialOrganismOrganismGeneralComponent extends BackboneElement {
        /**
         * The phylum of an organism shall be specified.
         *
         * The phylum of an organism shall be specified
         */
        phylum?: CodeableConcept;
        /**
         * The order of an organism shall be specified,.
         *
         * The order of an organism shall be specified,
         */
        order?: CodeableConcept;
        /**
         * The kingdom of an organism shall be specified.
         *
         * The kingdom of an organism shall be specified
         */
        kingdom?: CodeableConcept;
        /**
         * The class of an organism shall be specified.
         *
         * The class of an organism shall be specified
         */
        class?: CodeableConcept;
        static revive(json: any): SubstanceSourceMaterialOrganismOrganismGeneralComponent;
        toJSON(): any;
    }
    class SubstanceSourceMaterialOrganismHybridComponent extends BackboneElement {
        /**
         * The identifier of the maternal species constituting the hybrid organism shall be specified based on a controlled vocabulary. For plants, the parents aren’t always known, and it is unlikely that it will be known which is maternal and which is paternal.
         *
         * The identifier of the maternal species constituting the hybrid organism shall be specified based on a controlled vocabulary. For plants, the parents aren’t always known, and it is unlikely that it will be known which is maternal and which is paternal
         */
        maternalOrganismId?: string;
        /**
         * The name of the maternal species constituting the hybrid organism shall be specified. For plants, the parents aren’t always known, and it is unlikely that it will be known which is maternal and which is paternal.
         *
         * The name of the maternal species constituting the hybrid organism shall be specified. For plants, the parents aren’t always known, and it is unlikely that it will be known which is maternal and which is paternal
         */
        maternalOrganismName?: string;
        /**
         * The identifier of the paternal species constituting the hybrid organism shall be specified based on a controlled vocabulary.
         *
         * The identifier of the paternal species constituting the hybrid organism shall be specified based on a controlled vocabulary
         */
        paternalOrganismId?: string;
        /**
         * The name of the paternal species constituting the hybrid organism shall be specified.
         *
         * The name of the paternal species constituting the hybrid organism shall be specified
         */
        paternalOrganismName?: string;
        /**
         * The hybrid type of an organism shall be specified.
         *
         * The hybrid type of an organism shall be specified
         */
        hybridType?: CodeableConcept;
        static revive(json: any): SubstanceSourceMaterialOrganismHybridComponent;
        toJSON(): any;
    }
    class SubstanceSourceMaterialOrganismAuthorComponent extends BackboneElement {
        /**
         * The type of author of an organism species shall be specified. The parenthetical author of an organism species refers to the first author who published the plant/animal name (of any rank). The primary author of an organism species refers to the first author(s), who validly published the plant/animal name.
         *
         * The type of author of an organism species shall be specified. The parenthetical author of an organism species refers to the first author who published the plant/animal name (of any rank). The primary author of an organism species refers to the first author(s), who validly published the plant/animal name
         */
        authorType?: CodeableConcept;
        /**
         * The author of an organism species shall be specified. The author year of an organism shall also be specified when applicable; refers to the year in which the first author(s) published the infraspecific plant/animal name (of any rank).
         *
         * The author of an organism species shall be specified. The author year of an organism shall also be specified when applicable; refers to the year in which the first author(s) published the infraspecific plant/animal name (of any rank)
         */
        authorDescription?: string;
        static revive(json: any): SubstanceSourceMaterialOrganismAuthorComponent;
        toJSON(): any;
    }
    class SubstanceSourceMaterialOrganismComponent extends BackboneElement {
        /**
         * The intraspecific description of an organism shall be specified based on a controlled vocabulary. For Influenza Vaccine, the intraspecific description shall contain the syntax of the antigen in line with the WHO convention.
         *
         * The intraspecific description of an organism shall be specified based on a controlled vocabulary. For Influenza Vaccine, the intraspecific description shall contain the syntax of the antigen in line with the WHO convention
         */
        intraspecificDescription?: string;
        /**
         * The family of an organism shall be specified.
         *
         * The family of an organism shall be specified
         */
        family?: CodeableConcept;
        /**
         * The Intraspecific type of an organism shall be specified.
         *
         * The Intraspecific type of an organism shall be specified
         */
        intraspecificType?: CodeableConcept;
        /**
         * 4.9.13.8.1 Hybrid species maternal organism ID (Optional).
         *
         * 4.9.13.8.1 Hybrid species maternal organism ID (Optional)
         */
        hybrid?: SubstanceSourceMaterial.SubstanceSourceMaterialOrganismHybridComponent;
        /**
         * 4.9.13.6.1 Author type (Conditional).
         *
         * 4.9.13.6.1 Author type (Conditional)
         */
        author?: SubstanceSourceMaterial.SubstanceSourceMaterialOrganismAuthorComponent[];
        /**
         * 4.9.13.7.1 Kingdom (Conditional).
         *
         * 4.9.13.7.1 Kingdom (Conditional)
         */
        organismGeneral?: SubstanceSourceMaterial.SubstanceSourceMaterialOrganismOrganismGeneralComponent;
        /**
         * The genus of an organism shall be specified; refers to the Latin epithet of the genus element of the plant/animal scientific name; it is present in names for genera, species and infraspecies.
         *
         * The genus of an organism shall be specified; refers to the Latin epithet of the genus element of the plant/animal scientific name; it is present in names for genera, species and infraspecies
         */
        genus?: CodeableConcept;
        /**
         * The species of an organism shall be specified; refers to the Latin epithet of the species of the plant/animal; it is present in names for species and infraspecies.
         *
         * The species of an organism shall be specified; refers to the Latin epithet of the species of the plant/animal; it is present in names for species and infraspecies
         */
        species?: CodeableConcept;
        static revive(json: any): SubstanceSourceMaterialOrganismComponent;
        toJSON(): any;
    }
    class SubstanceSourceMaterialFractionDescriptionComponent extends BackboneElement {
        /**
         * This element is capturing information about the fraction of a plant part, or human plasma for fractionation.
         *
         * This element is capturing information about the fraction of a plant part, or human plasma for fractionation
         */
        fraction?: string;
        /**
         * The specific type of the material constituting the component. For Herbal preparations the particulars of the extracts (liquid/dry) is described in Specified Substance Group 1.
         *
         * The specific type of the material constituting the component. For Herbal preparations the particulars of the extracts (liquid/dry) is described in Specified Substance Group 1
         */
        materialType?: CodeableConcept;
        static revive(json: any): SubstanceSourceMaterialFractionDescriptionComponent;
        toJSON(): any;
    }
}
