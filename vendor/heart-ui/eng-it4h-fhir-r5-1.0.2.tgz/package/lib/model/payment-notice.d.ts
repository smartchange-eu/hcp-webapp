import { Reference } from '../datatype/reference';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Money } from '../datatype/money';
import { DomainResource } from '../model/domain-resource';
import { Organization } from '../model/organization';
import { PaymentReconciliation } from '../model/payment-reconciliation';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
/**
 * HAPI/FHIR <b>PaymentNotice</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/PaymentNotice">http://hl7.org/fhir/StructureDefinition/PaymentNotice</a>
 * </p>
 *
 */
export declare class PaymentNotice extends DomainResource {
    /**
     * Reference of response to resource for which payment is being made.
     *
     * Response reference
     */
    response?: Reference;
    /**
     * The date when this resource was created.
     *
     * Creation date
     */
    created: Date;
    /**
     * The party who will receive or has received payment that is the subject of this notification.
     *
     * Party being paid
     */
    payee?: Practitioner | PractitionerRole | Organization | Reference;
    /**
     * A unique identifier assigned to this payment notice.
     *
     * Business Identifier for the payment notice
     */
    identifier?: Identifier[];
    /**
     * Reference of resource for which payment is being made.
     *
     * Request reference
     */
    request?: Reference;
    /**
     * The amount sent to the payee.
     *
     * Monetary amount of the payment
     */
    amount: Money;
    /**
     * The date when the above payment action occurred.
     *
     * Payment or clearing date
     */
    paymentDate?: Date;
    /**
     * A code indicating whether payment has been sent or cleared.
     *
     * Issued or cleared Status of the payment
     */
    paymentStatus?: CodeableConcept;
    /**
     * The status of the resource instance.
     *
     * active | cancelled | draft | entered-in-error
     */
    status: string;
    /**
     * The party who is notified of the payment status.
     *
     * Party being notified
     */
    recipient: Organization | Reference;
    /**
     * The party who reports the payment notice.
     *
     * Responsible practitioner
     */
    reporter?: Practitioner | PractitionerRole | Organization | Reference;
    /**
     * A reference to the payment which is the subject of this notice.
     *
     * Payment reference
     */
    payment?: PaymentReconciliation | Reference;
    readonly resourceType: string;
    static revive(json: any): PaymentNotice;
    toJSON(): any;
}
export declare namespace PaymentNotice {
    enum FinancialResourceStatusCodes {
        CANCELLED,
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        DRAFT
    }
}
