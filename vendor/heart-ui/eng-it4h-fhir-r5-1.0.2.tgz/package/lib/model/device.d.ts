import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { ContactPoint } from '../datatype/contact-point';
import { Count } from '../datatype/count';
import { Duration } from '../datatype/duration';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { DomainResource } from '../model/domain-resource';
import { Endpoint } from '../model/endpoint';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
/**
 * HAPI/FHIR <b>Device</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Device">http://hl7.org/fhir/StructureDefinition/Device</a>
 * </p>
 *
 */
export declare class Device extends DomainResource {
    /**
     * The designated condition for performing a task with the device.
     *
     * The designated condition for performing a task
     */
    mode?: CodeableConcept;
    /**
     * A measurement of time during the device's operation (e.g., days, hours, mins, etc.).
     *
     * A measurement of time during the device's operation (e.g., days, hours, mins, etc.)
     */
    duration?: Duration;
    /**
     * Technical endpoints providing access to services provided by the device defined at this resource.
     *
     * Technical endpoints providing access to electronic services provided by the device
     */
    endpoint?: Endpoint[] | Reference[];
    /**
     * Contact details for an organization or a particular human that is responsible for the device.
     *
     * Details for human/organization for support
     */
    contact?: ContactPoint[];
    /**
     * Provides additional safety characteristics about a medical device.  For example devices containing latex.
     *
     * Safety Characteristics of Device
     */
    safety?: CodeableConcept[];
    /**
     * The date and time when the device was manufactured.
     *
     * Date when the device was made
     */
    manufactureDate?: Date;
    /**
     * Static or essentially fixed characteristics or features of the device (e.g., time or timing attributes, resolution, accuracy, intended use or instructions for use, and physical attributes) that are not otherwise captured in more specific attributes.
     *
     * Inherent, essentially fixed, characteristics of the device.  e.g., time properties, size, material, etc.
     */
    property?: Device.DevicePropertyComponent[];
    /**
     * The availability of the device.
     *
     * lost | damaged | destroyed | available
     */
    availabilityStatus?: CodeableConcept;
    /**
     * The reference to the definition for the device.
     *
     * The reference to the definition for the device
     */
    definition?: CodeableReference;
    /**
     * The date and time beyond which this device is no longer valid or should not be used (if applicable).
     *
     * Date and time of expiry of this device (if applicable)
     */
    expirationDate?: Date;
    /**
     * Descriptive information, usage information or implantation information that is not captured in an existing element.
     *
     * Device notes and comments
     */
    note?: Annotation[];
    /**
     * The higher level or encompassing device that this device is a logical part of.
     *
     * The higher level or encompassing device that this device is a logical part of
     */
    parent?: Device | Reference;
    /**
     * An identifier that supports traceability to the event during which material in this product from one or more biological entities was obtained or pooled.
     *
     * An identifier that supports traceability to the event during which material in this product from one or more biological entities was obtained or pooled
     */
    biologicalSourceEvent?: Identifier;
    /**
     * The name used to display by default when the device is referenced. Based on intent of use by the resource creator, this may reflect one of the names in Device.name, or may be another simple name.
     *
     * The name used to display by default when the device is referenced
     */
    displayName?: string;
    /**
     * The series of occurrences that repeats during the operation of the device.
     *
     * The series of occurrences that repeats during the operation of the device
     */
    cycle?: Count;
    /**
     * The kind or type of device. A device instance may have more than one type - in which case those are the types that apply to the specific instance of the device.
     *
     * The kind or type of device
     */
    type?: CodeableConcept[];
    /**
     * A name of the manufacturer or entity legally responsible for the device.
     *
     * Name of device manufacturer
     */
    manufacturer?: string;
    /**
     * Unique device identifier (UDI) assigned to device label or package.  Note that the Device may include multiple udiCarriers as it either may include just the udiCarrier for the jurisdiction it is sold, or for multiple jurisdictions it could have been sold.
     *
     * Unique Device Identifier (UDI) Barcode string
     */
    udiCarrier?: Device.DeviceUdiCarrierComponent[];
    /**
     * This represents the manufacturer's name of the device as provided by the device, from a UDI label, or by a person describing the Device.  This typically would be used when a person provides the name(s) or when the device represents one of the names available from DeviceDefinition.
     *
     * The name or names of the device as known to the manufacturer and/or patient
     */
    name?: Device.DeviceNameComponent[];
    /**
     * Identifies the standards, specifications, or formal guidances for the capabilities supported by the device. The device may be certified as conformant to these specifications e.g., communication, performance, process, measurement, or specialization standards.
     *
     * Identifies the standards, specifications, or formal guidances for the capabilities supported by the device
     */
    conformsTo?: Device.DeviceConformsToComponent[];
    /**
     * The manufacturer's model number for the device.
     *
     * The manufacturer's model number for the device
     */
    modelNumber?: string;
    /**
     * The part number or catalog number of the device.
     *
     * The part number or catalog number of the device
     */
    partNumber?: string;
    /**
     * The place where the device can be found.
     *
     * Where the device is found
     */
    location?: Location | Reference;
    /**
     * Devices may be associated with one or more categories.
     *
     * Indicates a high-level grouping of the device
     */
    category?: CodeableConcept[];
    /**
     * The Device record status. This is not the status of the device like availability.
     *
     * active | inactive | entered-in-error
     */
    status?: string;
    /**
     * The linked device acting as a communication controller, data collector, translator, or concentrator for the current device (e.g., mobile phone application that relays a blood pressure device's data).
     *
     * Linked device acting as a communication/data collector, translator or controller
     */
    gateway?: CodeableReference[];
    /**
     * Unique instance identifiers assigned to a device by manufacturers other organizations or owners.
     *
     * Instance identifier
     */
    identifier?: Identifier[];
    /**
     * An organization that is responsible for the provision and ongoing maintenance of the device.
     *
     * Organization responsible for device
     */
    owner?: Organization | Reference;
    /**
     * The serial number assigned by the organization when the device was manufactured.
     *
     * Serial number assigned by the manufacturer
     */
    serialNumber?: string;
    /**
     * Lot number assigned by the manufacturer.
     *
     * Lot number of manufacture
     */
    lotNumber?: string;
    /**
     * The actual design of the device or software version running on the device.
     *
     * The actual design of the device or software version running on the device
     */
    version?: Device.DeviceVersionComponent[];
    /**
     * A network address on which the device may be contacted directly.
     *
     * Network address to contact device
     */
    url?: string;
    readonly resourceType: string;
    static revive(json: any): Device;
    toJSON(): any;
}
export declare namespace Device {
    enum UDIEntryType {
        NULL,
        BARCODE,
        RFID,
        MANUAL,
        UNKNOWN,
        SELFREPORTED,
        CARD,
        ELECTRONICTRANSMISSION
    }
    enum FHIRDeviceStatus {
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        INACTIVE
    }
    class DevicePropertyComponent extends BackboneElement {
        /**
         * The value of the property specified by the associated property.type code.
         *
         * Value of the property
         */
        value: Quantity | CodeableConcept | string | boolean | number | Range | Attachment;
        /**
         * Code that specifies the property, such as resolution, color, size, being represented.
         *
         * Code that specifies the property being represented
         */
        type: CodeableConcept;
        static revive(json: any): DevicePropertyComponent;
        toJSON(): any;
    }
    class DeviceConformsToComponent extends BackboneElement {
        /**
         * Code that identifies the specific standard, specification, protocol, formal guidance, regulation, legislation, or certification scheme to which the device adheres.
         *
         * Identifies the standard, specification, or formal guidance that the device adheres to
         */
        specification: CodeableConcept;
        /**
         * Describes the type of the standard, specification, or formal guidance.
         *
         * Describes the common type of the standard, specification, or formal guidance.  communication | performance | measurement
         */
        category?: CodeableConcept;
        /**
         * Identifies the specific form or variant of the standard, specification, or formal guidance. This may be a 'version number', release, document edition, publication year, or other label.
         *
         * Specific form or variant of the standard
         */
        version?: string;
        static revive(json: any): DeviceConformsToComponent;
        toJSON(): any;
    }
    class DeviceVersionComponent extends BackboneElement {
        /**
         * The type of the device version, e.g. manufacturer, approved, internal.
         *
         * The type of the device version, e.g. manufacturer, approved, internal
         */
        type?: CodeableConcept;
        /**
         * The version text.
         *
         * The version text
         */
        value: string;
        /**
         * The hardware or software module of the device to which the version applies.
         *
         * The hardware or software module of the device to which the version applies
         */
        component?: Identifier;
        /**
         * The date the version was installed on the device.
         *
         * The date the version was installed on the device
         */
        installDate?: Date;
        static revive(json: any): DeviceVersionComponent;
        toJSON(): any;
    }
    class DeviceNameComponent extends BackboneElement {
        /**
         * Indicates the default or preferred name to be displayed.
         *
         * The preferred device name
         */
        display?: boolean;
        /**
         * Indicates the kind of name. RegisteredName | UserFriendlyName | PatientReportedName.
         *
         * registered-name | user-friendly-name | patient-reported-name
         */
        type: string;
        /**
         * The actual name that identifies the device.
         *
         * The term that names the device
         */
        value: string;
        static revive(json: any): DeviceNameComponent;
        toJSON(): any;
    }
    class DeviceUdiCarrierComponent extends BackboneElement {
        /**
         * The identity of the authoritative source for UDI generation within a jurisdiction. All UDIs are globally unique within a single namespace with the appropriate repository uri as the system. For example, UDIs of devices managed in the U.S. by the FDA, the value is http://hl7.org/fhir/NamingSystem/us-fda-udi or in the European Union by the European Commission http://hl7.org/fhir/NamingSystem/eu-ec-udi.
         *
         * Regional UDI authority
         */
        jurisdiction?: string;
        /**
         * The full UDI carrier as the human readable form (HRF) representation of the barcode string as printed on the packaging of the device.
         *
         * UDI Human Readable Barcode String
         */
        carrierHRF?: string;
        /**
         * The device identifier (DI) is a mandatory, fixed portion of a UDI that identifies the labeler and the specific version or model of a device.
         *
         * Mandatory fixed portion of UDI
         */
        deviceIdentifier: string;
        /**
         * A coded entry to indicate how the data was entered.
         *
         * barcode | rfid | manual | card | self-reported | electronic-transmission | unknown
         */
        entryType?: string;
        /**
         * Organization that is charged with issuing UDIs for devices. For example, the US FDA issuers include:
1) GS1: http://hl7.org/fhir/NamingSystem/gs1-di,
2) HIBCC: http://hl7.org/fhir/NamingSystem/hibcc-diI,
3) ICCBBA for blood containers: http://hl7.org/fhir/NamingSystem/iccbba-blood-di,
4) ICCBA for other devices: http://hl7.org/fhir/NamingSystem/iccbba-other-di # Informationsstelle für Arzneispezialitäten (IFA GmbH) (EU only): http://hl7.org/fhir/NamingSystem/ifa-gmbh-di.
         *
         * UDI Issuing Organization
         */
        issuer: string;
        /**
         * The full UDI carrier of the Automatic Identification and Data Capture (AIDC) technology representation of the barcode string as printed on the packaging of the device - e.g., a barcode or RFID.   Because of limitations on character sets in XML and the need to round-trip JSON data through XML, AIDC Formats *SHALL* be base64 encoded.
         *
         * UDI Machine Readable Barcode String
         */
        carrierAIDC?: string;
        static revive(json: any): DeviceUdiCarrierComponent;
        toJSON(): any;
    }
}
