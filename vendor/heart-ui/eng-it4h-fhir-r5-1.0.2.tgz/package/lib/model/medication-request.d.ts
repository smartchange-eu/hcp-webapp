import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Dosage } from '../datatype/dosage';
import { Duration } from '../datatype/duration';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { CarePlan } from '../model/care-plan';
import { CareTeam } from '../model/care-team';
import { ClaimResponse } from '../model/claim-response';
import { Coverage } from '../model/coverage';
import { Device } from '../model/device';
import { DeviceDefinition } from '../model/device-definition';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { ImmunizationRecommendation } from '../model/immunization-recommendation';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Provenance } from '../model/provenance';
import { RelatedPerson } from '../model/related-person';
import { ServiceRequest } from '../model/service-request';
/**
 * HAPI/FHIR <b>MedicationRequest</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/MedicationRequest">http://hl7.org/fhir/StructureDefinition/MedicationRequest</a>
 * </p>
 *
 */
export declare class MedicationRequest extends DomainResource {
    /**
     * Specific instructions for how the medication is to be used by the patient.
     *
     * Specific instructions for how the medication should be taken
     */
    dosageInstruction?: Dosage[];
    /**
     * Links to Provenance records for past versions of this resource or fulfilling request or event resources that identify key state transitions or updates that are likely to be relevant to a user looking at the current version of the resource.
     *
     * A list of events of interest in the lifecycle
     */
    eventHistory?: Provenance[] | Reference[];
    /**
     * A code specifying the current state of the order.  Generally, this will be active or completed state.
     *
     * active | on-hold | ended | stopped | completed | cancelled | entered-in-error | draft | unknown
     */
    status: string;
    /**
     * The period over which the medication is to be taken.  Where there are multiple dosageInstruction lines (for example, tapering doses), this is the earliest date and the latest end date of the dosageInstructions.
     *
     * Period over which the medication is to be taken
     */
    effectiveDosePeriod?: Period;
    /**
     * The intended type of device that is to be used for the administration of the medication (for example, PCA Pump).
     *
     * Intended type of device for the administration
     */
    device?: CodeableReference[];
    /**
     * A shared identifier common to multiple independent Request instances that were activated/authorized more or less simultaneously by a single author.  The presence of the same identifier on each request ties those requests together and may have business ramifications in terms of reporting of results, billing, etc.  E.g. a requisition number shared by a set of lab tests ordered together, or a prescription number shared by all meds ordered at one time.
     *
     * Composite request this is part of
     */
    groupIdentifier?: Identifier;
    /**
     * An arbitrary categorization or grouping of the medication request.  It could be used for indicating where meds are intended to be administered, eg. in an inpatient setting or in a patient's home, or a legal category of the medication.
     *
     * Grouping or category of medication request
     */
    category?: CodeableConcept[];
    /**
     * The date (and perhaps time) when the prescription was initially written or authored on.
     *
     * When request was initially authored
     */
    authoredOn?: Date;
    /**
     * The specified desired performer of the medication treatment (e.g. the performer of the medication administration).  For devices, this is the device that is intended to perform the administration of the medication.  An IV Pump would be an example of a device that is performing the administration.  Both the IV Pump and the practitioner that set the rate or bolus on the pump can be listed as performers.
     *
     * Intended performer of administration
     */
    performer?: Practitioner[] | PractitionerRole[] | Organization[] | Patient[] | DeviceDefinition[] | RelatedPerson[] | CareTeam[] | HealthcareService[] | Reference[];
    /**
     * The person who entered the order on behalf of another individual for example in the case of a verbal or a telephone order.
     *
     * Person who entered the request
     */
    recorder?: Practitioner | PractitionerRole | Reference;
    /**
     * Identifiers associated with this medication request that are defined by business processes and/or used to refer to it when a direct URL reference to the resource itself is not appropriate. They are business identifiers assigned to this resource by the performer or other systems and remain constant as the resource is updated and propagates from server to server.
     *
     * External ids for this request
     */
    identifier?: Identifier[];
    /**
     * The individual, organization, or device that initiated the request and has responsibility for its activation.
     *
     * Who/What requested the Request
     */
    requester?: Practitioner | PractitionerRole | Organization | Patient | RelatedPerson | Device | Reference;
    /**
     * The Encounter during which this [x] was created or to which the creation of this record is tightly associated.
     *
     * Encounter created as part of encounter/admission/stay
     */
    encounter?: Encounter | Reference;
    /**
     * Identifies the medication being requested. This is a link to a resource that represents the medication which may be the details of the medication or simply an attribute carrying a code that identifies the medication from a known list of medications.
     *
     * Medication to be taken
     */
    medication: CodeableReference;
    /**
     * Information to support fulfilling (i.e. dispensing or administering) of the medication, for example, patient height and weight, a MedicationStatement for the patient).
     *
     * Information to support fulfilling of the medication
     */
    supportingInformation?: Reference[];
    /**
     * Whether the request is a proposal, plan, or an original order.
     *
     * proposal | plan | order | original-order | reflex-order | filler-order | instance-order | option
     */
    intent: string;
    /**
     * Indicates the type of performer of the administration of the medication.
     *
     * Desired kind of performer of the medication administration
     */
    performerType?: CodeableConcept;
    /**
     * Indicates how quickly the Medication Request should be addressed with respect to other requests.
     *
     * routine | urgent | asap | stat
     */
    priority?: string;
    /**
     * Captures the reason for the current state of the MedicationRequest.
     *
     * Reason for current status
     */
    statusReason?: CodeableConcept;
    /**
     * The full representation of the dose of the medication included in all dosage instructions.  To be used when multiple dosage instructions are included to represent complex dosing such as increasing or tapering doses.
     *
     * Full representation of the dosage instructions
     */
    renderedDosageInstruction?: string;
    /**
     * The person or organization who provided the information about this request, if the source is someone other than the requestor.  This is often used when the MedicationRequest is reported by another person.
     *
     * The person or organization who provided the information about this request, if the source is someone other than the requestor
     */
    informationSource?: Patient[] | Practitioner[] | PractitionerRole[] | RelatedPerson[] | Organization[] | Reference[];
    /**
     * Indicates the specific details for the dispense or medication supply part of a medication request (also known as a Medication Prescription or Medication Order).  Note that this information is not always sent with the order.  There may be in some settings (e.g. hospitals) institutional or system support for completing the dispense details in the pharmacy department.
     *
     * Medication supply authorization
     */
    dispenseRequest?: MedicationRequest.MedicationRequestDispenseRequestComponent;
    /**
     * The date (and perhaps time) when the status was changed.
     *
     * When the status was changed
     */
    statusChanged?: Date;
    /**
     * Indicates if this record was captured as a secondary 'reported' record rather than as an original primary source-of-truth record.  It may also indicate the source of the report.
     *
     * Reported rather than primary record
     */
    reported?: boolean;
    /**
     * A plan or request that is fulfilled in whole or in part by this medication request.
     *
     * A plan or request that is fulfilled in whole or in part by this medication request
     */
    basedOn?: CarePlan[] | MedicationRequest[] | ServiceRequest[] | ImmunizationRecommendation[] | Reference[];
    /**
     * If true, indicates that the provider is asking for the patient to either stop taking or to not start taking the specified medication. For example, the patient is taking an existing medication and the provider is changing their medication. They want to create two seperate requests: one to stop using the current medication and another to start the new medication.
     *
     * True if patient is to stop taking or not to start taking the medication
     */
    doNotPerform?: boolean;
    /**
     * Indicates whether or not substitution can or should be part of the dispense. In some cases, substitution must happen, in other cases substitution must not happen. This block explains the prescriber's intent. If nothing is specified substitution may be done.
     *
     * Any restrictions on medication substitution
     */
    substitution?: MedicationRequest.MedicationRequestSubstitutionComponent;
    /**
     * The reason or the indication for ordering or not ordering the medication.
     *
     * Reason or indication for ordering or not ordering the medication
     */
    reason?: CodeableReference[];
    /**
     * Extra information about the prescription that could not be conveyed by the other attributes.
     *
     * Information about the prescription
     */
    note?: Annotation[];
    /**
     * Insurance plans, coverage extensions, pre-authorizations and/or pre-determinations that may be required for delivering the requested service.
     *
     * Associated insurance coverage
     */
    insurance?: Coverage[] | ClaimResponse[] | Reference[];
    /**
     * Reference to an order/prescription that is being replaced by this MedicationRequest.
     *
     * Reference to an order/prescription that is being replaced by this MedicationRequest
     */
    priorPrescription?: MedicationRequest | Reference;
    /**
     * The individual or group for whom the medication has been requested.
     *
     * Individual or group for whom the medication has been requested
     */
    subject: Patient | Group | Reference;
    /**
     * The description of the overall pattern of the administration of the medication to the patient.
     *
     * Overall pattern of medication administration
     */
    courseOfTherapyType?: CodeableConcept;
    readonly resourceType: string;
    static revive(json: any): MedicationRequest;
    toJSON(): any;
}
export declare namespace MedicationRequest {
    enum MedicationrequestStatus {
        CANCELLED,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ACTIVE,
        ONHOLD,
        DRAFT,
        STOPPED,
        ENDED,
        UNKNOWN
    }
    enum MedicationRequestIntent {
        ORDER,
        FILLERORDER,
        ORIGINALORDER,
        NULL,
        REFLEXORDER,
        OPTION,
        PROPOSAL,
        PLAN,
        INSTANCEORDER
    }
    enum RequestPriority {
        URGENT,
        STAT,
        NULL,
        ROUTINE,
        ASAP
    }
    class MedicationRequestSubstitutionComponent extends BackboneElement {
        /**
         * Indicates the reason for the substitution, or why substitution must or must not be performed.
         *
         * Why should (not) substitution be made
         */
        reason?: CodeableConcept;
        /**
         * True if the prescriber allows a different drug to be dispensed from what was prescribed.
         *
         * Whether substitution is allowed or not
         */
        allowed: boolean | CodeableConcept;
        static revive(json: any): MedicationRequestSubstitutionComponent;
        toJSON(): any;
    }
    class MedicationRequestDispenseRequestInitialFillComponent extends BackboneElement {
        /**
         * The length of time that the first dispense is expected to last.
         *
         * First fill duration
         */
        duration?: Duration;
        /**
         * The amount or quantity to provide as part of the first dispense.
         *
         * First fill quantity
         */
        quantity?: Quantity;
        static revive(json: any): MedicationRequestDispenseRequestInitialFillComponent;
        toJSON(): any;
    }
    class MedicationRequestDispenseRequestComponent extends BackboneElement {
        /**
         * Indicates the quantity or duration for the first dispense of the medication.
         *
         * First fill details
         */
        initialFill?: MedicationRequest.MedicationRequestDispenseRequestInitialFillComponent;
        /**
         * Provides information about the type of adherence packaging to be supplied for the medication dispense.
         *
         * Type of adherence packaging to use for the dispense
         */
        doseAdministrationAid?: CodeableConcept;
        /**
         * Identifies the period time over which the supplied product is expected to be used, or the length of time the dispense is expected to last.
         *
         * Number of days supply per dispense
         */
        expectedSupplyDuration?: Duration;
        /**
         * The minimum period of time that must occur between dispenses of the medication.
         *
         * Minimum period of time between dispenses
         */
        dispenseInterval?: Duration;
        /**
         * The amount that is to be dispensed for one fill.
         *
         * Amount of medication to supply per dispense
         */
        quantity?: Quantity;
        /**
         * This indicates the validity period of a prescription (stale dating the Prescription).
         *
         * Time period supply is authorized for
         */
        validityPeriod?: Period;
        /**
         * Indicates the intended performing Organization that will dispense the medication as specified by the prescriber.
         *
         * Intended performer of dispense
         */
        dispenser?: Organization | Reference;
        /**
         * Provides additional information to the dispenser, for example, counselling to be provided to the patient.
         *
         * Additional information for the dispenser
         */
        dispenserInstruction?: Annotation[];
        /**
         * An integer indicating the number of times, in addition to the original dispense, (aka refills or repeats) that the patient can receive the prescribed medication. Usage Notes: This integer does not include the original order dispense. This means that if an order indicates dispense 30 tablets plus "3 repeats", then the order can be dispensed a total of 4 times and the patient can receive a total of 120 tablets.  A prescriber may explicitly say that zero refills are permitted after the initial dispense.
         *
         * Number of refills authorized
         */
        numberOfRepeatsAllowed?: number;
        static revive(json: any): MedicationRequestDispenseRequestComponent;
        toJSON(): any;
    }
}
