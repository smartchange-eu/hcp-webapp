import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>List</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/List">http://hl7.org/fhir/StructureDefinition/List</a>
 * </p>
 *
 */
export declare class List extends DomainResource {
    /**
     * If the list is empty, why the list is empty.
     *
     * Why list is empty
     */
    emptyReason?: CodeableConcept;
    /**
     * The common subject(s) (or patient(s)) of the resources that are in the list if there is one (or a set of subjects).
     *
     * If all resources have the same subject(s)
     */
    subject?: Reference[];
    /**
     * Date list was last reviewed/revised and determined to be 'current'.
     *
     * When the list was prepared
     */
    date?: Date;
    /**
     * Identifier for the List assigned for business purposes outside the context of FHIR.
     *
     * Business identifier
     */
    identifier?: Identifier[];
    /**
     * Comments that apply to the overall list.
     *
     * Comments about the list
     */
    note?: Annotation[];
    /**
     * This code defines the purpose of the list - why it was created.
     *
     * What the purpose of this list is
     */
    code?: CodeableConcept;
    /**
     * A label for the list assigned by the author.
     *
     * Descriptive name for the list
     */
    title?: string;
    /**
     * The encounter that is the context in which this list was created.
     *
     * Context in which list created
     */
    encounter?: Encounter | Reference;
    /**
     * The entity responsible for deciding what the contents of the list were. Where the list was created by a human, this is the same as the author of the list.
     *
     * Who and/or what defined the list contents (aka Author)
     */
    source?: Practitioner | PractitionerRole | Patient | Device | Organization | RelatedPerson | CareTeam | Reference;
    /**
     * What order applies to the items in the list.
     *
     * What order the list has
     */
    orderedBy?: CodeableConcept;
    /**
     * How this list was prepared - whether it is a working list that is suitable for being maintained on an ongoing basis, or if it represents a snapshot of a list of items from another source, or whether it is a prepared list where items may be marked as added, modified or deleted.
     *
     * working | snapshot | changes
     */
    mode: string;
    /**
     * Entries in this list.
     *
     * Entries in the list
     */
    entry?: List.ListResourceEntryComponent[];
    /**
     * Indicates the current state of this list.
     *
     * current | retired | entered-in-error
     */
    status: string;
    readonly resourceType: string;
    static revive(json: any): List;
    toJSON(): any;
}
export declare namespace List {
    enum ListStatus {
        ENTEREDINERROR,
        NULL,
        RETIRED,
        CURRENT
    }
    enum ListMode {
        WORKING,
        NULL,
        SNAPSHOT,
        CHANGES
    }
    class ListResourceEntryComponent extends BackboneElement {
        /**
         * A reference to the actual resource from which data was derived.
         *
         * Actual entry
         */
        item: Reference;
        /**
         * The flag allows the system constructing the list to indicate the role and significance of the item in the list.
         *
         * Status/Workflow information about this item
         */
        flag?: CodeableConcept;
        /**
         * True if this item is marked as deleted in the list.
         *
         * If this item is actually marked as deleted
         */
        deleted?: boolean;
        /**
         * When this item was added to the list.
         *
         * When item added to list
         */
        date?: Date;
        static revive(json: any): ListResourceEntryComponent;
        toJSON(): any;
    }
}
