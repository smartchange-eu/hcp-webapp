import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { DomainResource } from '../model/domain-resource';
import { ImagingSelection } from '../model/imaging-selection';
import { Patient } from '../model/patient';
/**
 * HAPI/FHIR <b>BodyStructure</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/BodyStructure">http://hl7.org/fhir/StructureDefinition/BodyStructure</a>
 * </p>
 *
 */
export declare class BodyStructure extends DomainResource {
    /**
     * Whether this body site is in active use.
     *
     * Whether this record is in active use
     */
    active?: boolean;
    /**
     * The anatomical location(s) or region(s) not occupied or represented by the specimen, lesion, or body structure.
     *
     * Excluded anatomic locations(s)
     */
    excludedStructure?: BodyStructure.BodyStructureIncludedStructureComponent[];
    /**
     * A summary, characterization or explanation of the body structure.
     *
     * Text description
     */
    description?: string;
    /**
     * The kind of structure being represented by the body structure at `BodyStructure.location`.  This can define both normal and abnormal morphologies.
     *
     * Kind of Structure
     */
    morphology?: CodeableConcept;
    /**
     * The person to which the body site belongs.
     *
     * Who this is about
     */
    patient: Patient | Reference;
    /**
     * Identifier for this instance of the anatomical structure.
     *
     * Bodystructure identifier
     */
    identifier?: Identifier[];
    /**
     * Image or images used to identify a location.
     *
     * Attached images
     */
    image?: Attachment[];
    /**
     * The anatomical location(s) or region(s) of the specimen, lesion, or body structure.
     *
     * Included anatomic location(s)
     */
    includedStructure: BodyStructure.BodyStructureIncludedStructureComponent[];
    readonly resourceType: string;
    static revive(json: any): BodyStructure;
    toJSON(): any;
}
export declare namespace BodyStructure {
    class BodyStructureIncludedStructureBodyLandmarkOrientationDistanceFromLandmarkComponent extends BackboneElement {
        /**
         * An instrument, tool, analyzer, etc. used in the measurement.
         *
         * Measurement device
         */
        device?: CodeableReference[];
        /**
         * The measured distance (e.g., in cm) from a body landmark.
         *
         * Measured distance from body landmark
         */
        value?: Quantity[];
        static revive(json: any): BodyStructureIncludedStructureBodyLandmarkOrientationDistanceFromLandmarkComponent;
        toJSON(): any;
    }
    class BodyStructureIncludedStructureBodyLandmarkOrientationComponent extends BackboneElement {
        /**
         * A description of a landmark on the body used as a reference to locate something else.
         *
         * Body ]andmark description
         */
        landmarkDescription?: CodeableConcept[];
        /**
         * The distance in centimeters a certain observation is made from a body landmark.
         *
         * Landmark relative location
         */
        distanceFromLandmark?: BodyStructure.BodyStructureIncludedStructureBodyLandmarkOrientationDistanceFromLandmarkComponent[];
        /**
         * An description of the direction away from a landmark something is located based on a radial clock dial.
         *
         * Clockface orientation
         */
        clockFacePosition?: CodeableConcept[];
        /**
         * The surface area a body location is in relation to a landmark.
         *
         * Relative landmark surface orientation
         */
        surfaceOrientation?: CodeableConcept[];
        static revive(json: any): BodyStructureIncludedStructureBodyLandmarkOrientationComponent;
        toJSON(): any;
    }
    class BodyStructureIncludedStructureComponent extends BackboneElement {
        /**
         * Body locations in relation to a specific body landmark (tatoo, scar, other body structure).
         *
         * Landmark relative location
         */
        bodyLandmarkOrientation?: BodyStructure.BodyStructureIncludedStructureBodyLandmarkOrientationComponent[];
        /**
         * Code that represents the included structure qualifier.
         *
         * Code that represents the included structure qualifier
         */
        qualifier?: CodeableConcept[];
        /**
         * XY or XYZ-coordinate orientation for structure.
         *
         * Cartesian reference for structure
         */
        spatialReference?: ImagingSelection[] | Reference[];
        /**
         * Code that represents the included structure.
         *
         * Code that represents the included structure
         */
        structure: CodeableConcept;
        /**
         * Code that represents the included structure laterality.
         *
         * Code that represents the included structure laterality
         */
        laterality?: CodeableConcept;
        static revive(json: any): BodyStructureIncludedStructureComponent;
        toJSON(): any;
    }
}
