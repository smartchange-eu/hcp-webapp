import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { ContactPoint } from '../datatype/contact-point';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Timing } from '../datatype/timing';
import { DomainResource } from '../model/domain-resource';
import { Group } from '../model/group';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>CareTeam</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/CareTeam">http://hl7.org/fhir/StructureDefinition/CareTeam</a>
 * </p>
 *
 */
export declare class CareTeam extends DomainResource {
    /**
     * Identifies all people and organizations who are expected to be involved in the care team.
     *
     * Members of the team
     */
    participant?: CareTeam.CareTeamParticipantComponent[];
    /**
     * Indicates the current state of the care team.
     *
     * proposed | active | suspended | inactive | entered-in-error
     */
    status?: string;
    /**
     * Identifies what kind of team.  This is to support differentiation between multiple co-existing teams, such as care plan team, episode of care team, longitudinal care team.
     *
     * Type of team
     */
    category?: CodeableConcept[];
    /**
     * A central contact detail for the care team (that applies to all members).
     *
     * A contact detail for the care team (that applies to all members)
     */
    telecom?: ContactPoint[];
    /**
     * A label for human use intended to distinguish like teams.  E.g. the "red" vs. "green" trauma teams.
     *
     * Name of the team, such as crisis assessment team
     */
    name?: string;
    /**
     * Identifies the patient or group whose intended care is handled by the team.
     *
     * Who care team is for
     */
    subject?: Patient | Group | Reference;
    /**
     * Indicates when the team did (or is intended to) come into effect and end.
     *
     * Time period team covers
     */
    period?: Period;
    /**
     * The organization responsible for the care team.
     *
     * Organization responsible for the care team
     */
    managingOrganization?: Organization[] | Reference[];
    /**
     * Business identifiers assigned to this care team by the performer or other systems which remain constant as the resource is updated and propagates from server to server.
     *
     * External Ids for this team
     */
    identifier?: Identifier[];
    /**
     * Describes why the care team exists.
     *
     * Why the care team exists
     */
    reason?: CodeableReference[];
    /**
     * Comments made about the CareTeam.
     *
     * Comments made about the CareTeam
     */
    note?: Annotation[];
    readonly resourceType: string;
    static revive(json: any): CareTeam;
    toJSON(): any;
}
export declare namespace CareTeam {
    enum CareTeamStatus {
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        INACTIVE,
        SUSPENDED,
        PROPOSED
    }
    class CareTeamParticipantComponent extends BackboneElement {
        /**
         * The specific person or organization who is participating/expected to participate in the care team.
         *
         * Who is involved
         */
        member?: Practitioner | PractitionerRole | RelatedPerson | Patient | Organization | CareTeam | Reference;
        /**
         * The organization of the practitioner.
         *
         * Organization of the practitioner
         */
        onBehalfOf?: Organization | Reference;
        /**
         * Indicates specific responsibility of an individual within the care team, such as "Primary care physician", "Trained social worker counselor", "Caregiver", etc.
         *
         * Type of involvement
         */
        role?: CodeableConcept;
        /**
         * When the member is generally available within this care team.
         *
         * When the member is generally available within this care team
         */
        coverage?: Period | Timing;
        static revive(json: any): CareTeamParticipantComponent;
        toJSON(): any;
    }
}
