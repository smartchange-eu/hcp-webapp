import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Ratio } from '../datatype/ratio';
import { Timing } from '../datatype/timing';
import { CarePlan } from '../model/care-plan';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { MedicationDispense } from '../model/medication-dispense';
import { MedicationRequest } from '../model/medication-request';
import { Patient } from '../model/patient';
import { Procedure } from '../model/procedure';
import { Provenance } from '../model/provenance';
/**
 * HAPI/FHIR <b>MedicationAdministration</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/MedicationAdministration">http://hl7.org/fhir/StructureDefinition/MedicationAdministration</a>
 * </p>
 *
 */
export declare class MedicationAdministration extends DomainResource {
    /**
     * The person or animal or group receiving the medication.
     *
     * Who received medication
     */
    subject: Patient | Group | Reference;
    /**
     * The performer of the medication treatment.  For devices this is the device that performed the administration of the medication.  An IV Pump would be an example of a device that is performing the administration. Both the IV Pump and the practitioner that set the rate or bolus on the pump can be listed as performers.
     *
     * Who or what performed the medication administration and what type of performance they did
     */
    performer?: MedicationAdministration.MedicationAdministrationPerformerComponent[];
    /**
     * Identifiers associated with this Medication Administration that are defined by business processes and/or used to refer to it when a direct URL reference to the resource itself is not appropriate. They are business identifiers assigned to this resource by the performer or other systems and remain constant as the resource is updated and propagates from server to server.
     *
     * External identifier
     */
    identifier?: Identifier[];
    /**
     * A larger event of which this particular event is a component or step.
     *
     * Part of referenced event
     */
    partOf?: MedicationAdministration[] | Procedure[] | MedicationDispense[] | Reference[];
    /**
     * A code, Condition or observation that supports why the medication was administered.
     *
     * Concept, condition or observation that supports why the medication was administered
     */
    reason?: CodeableReference[];
    /**
     * The original request, instruction or authority to perform the administration.
     *
     * Request administration performed against
     */
    request?: MedicationRequest | Reference;
    /**
     * Extra information about the medication administration that is not conveyed by the other attributes.
     *
     * Information about the administration
     */
    note?: Annotation[];
    /**
     * Describes the medication dosage information details e.g. dose, rate, site, route, etc.
     *
     * Details of how medication was taken
     */
    dosage?: MedicationAdministration.MedicationAdministrationDosageComponent;
    /**
     * The date the occurrence of the  MedicationAdministration was first captured in the record - potentially significantly after the occurrence of the event.
     *
     * When the MedicationAdministration was first captured in the subject's record
     */
    recorded?: Date;
    /**
     * Identifies the medication that was administered. This is either a link to a resource representing the details of the medication or a simple attribute carrying a code that identifies the medication from a known list of medications.
     *
     * What was administered
     */
    medication: CodeableReference;
    /**
     * The visit, admission, or other contact between patient and health care provider during which the medication administration was performed.
     *
     * Encounter administered as part of
     */
    encounter?: Encounter | Reference;
    /**
     * Additional information (for example, patient height and weight) that supports the administration of the medication.  This attribute can be used to provide documentation of specific characteristics of the patient present at the time of administration.  For example, if the dose says "give "x" if the heartrate exceeds "y"", then the heart rate can be included using this attribute.
     *
     * Additional information to support administration
     */
    supportingInformation?: Reference[];
    /**
     * A code indicating why the administration was not performed.
     *
     * Reason administration not performed
     */
    statusReason?: CodeableConcept[];
    /**
     * The reason or reasons why the full dose was not administered.
     *
     * Reason full dose was not administered
     */
    subPotentReason?: CodeableConcept[];
    /**
     * A specific date/time or interval of time during which the administration took place (or did not take place). For many administrations, such as swallowing a tablet the use of dateTime is more appropriate.
     *
     * Specific date/time or interval of time during which the administration took place (or did not take place)
     */
    occurence: Date | Period | Timing;
    /**
     * An indication that the full dose was not administered.
     *
     * Full dose was not administered
     */
    isSubPotent?: boolean;
    /**
     * A plan that is fulfilled in whole or in part by this MedicationAdministration.
     *
     * Plan this is fulfilled by this administration
     */
    basedOn?: CarePlan[] | Reference[];
    /**
     * Will generally be set to show that the administration has been completed.  For some long running administrations such as infusions, it is possible for an administration to be started but not completed or it may be paused while some other process is under way.
     *
     * in-progress | not-done | on-hold | completed | entered-in-error | stopped | unknown
     */
    status: string;
    /**
     * The type of medication administration (for example, drug classification like ATC, where meds would be administered, legal category of the medication).
     *
     * Type of medication administration
     */
    category?: CodeableConcept[];
    /**
     * The device that is to be used for the administration of the medication (for example, PCA Pump).
     *
     * Device used to administer
     */
    device?: CodeableReference[];
    /**
     * A summary of the events of interest that have occurred, such as when the administration was verified.
     *
     * A list of events of interest in the lifecycle
     */
    eventHistory?: Provenance[] | Reference[];
    readonly resourceType: string;
    static revive(json: any): MedicationAdministration;
    toJSON(): any;
}
export declare namespace MedicationAdministration {
    enum MedicationAdministrationStatusCodes {
        NOTDONE,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ONHOLD,
        STOPPED,
        INPROGRESS,
        UNKNOWN
    }
    class MedicationAdministrationDosageComponent extends BackboneElement {
        /**
         * A coded value indicating the method by which the medication is intended to be or was introduced into or on the body.  This attribute will most often NOT be populated.  It is most commonly used for injections.  For example, Slow Push, Deep IV.
         *
         * How drug was administered
         */
        method?: CodeableConcept;
        /**
         * Identifies the speed with which the medication was or will be introduced into the patient.  Typically, the rate for an infusion e.g. 100 ml per 1 hour or 100 ml/hr.  May also be expressed as a rate per unit of time, e.g. 500 ml per 2 hours.  Other examples:  200 mcg/min or 200 mcg/1 minute; 1 liter/8 hours.
         *
         * Dose quantity per unit of time
         */
        rate?: Ratio | Quantity;
        /**
         * A coded specification of the anatomic site where the medication first entered the body.  For example, "left arm".
         *
         * Body site administered to
         */
        site?: CodeableConcept;
        /**
         * The amount of the medication given at one administration event.   Use this value when the administration is essentially an instantaneous event such as a swallowing a tablet or giving an injection.
         *
         * Amount of medication per dose
         */
        dose?: Quantity;
        /**
         * A code specifying the route or physiological path of administration of a therapeutic agent into or onto the patient.  For example, topical, intravenous, etc.
         *
         * Path of substance into body
         */
        route?: CodeableConcept;
        /**
         * Free text dosage can be used for cases where the dosage administered is too complex to code. When coded dosage is present, the free text dosage may still be present for display to humans.

The dosage instructions should reflect the dosage of the medication that was administered.
         *
         * Free text dosage instructions e.g. SIG
         */
        text?: string;
        static revive(json: any): MedicationAdministrationDosageComponent;
        toJSON(): any;
    }
    class MedicationAdministrationPerformerComponent extends BackboneElement {
        /**
         * Indicates who or what performed the medication administration.
         *
         * Who or what performed the medication administration
         */
        actor: CodeableReference;
        /**
         * Distinguishes the type of involvement of the performer in the medication administration.
         *
         * Type of performance
         */
        function?: CodeableConcept;
        static revive(json: any): MedicationAdministrationPerformerComponent;
        toJSON(): any;
    }
}
