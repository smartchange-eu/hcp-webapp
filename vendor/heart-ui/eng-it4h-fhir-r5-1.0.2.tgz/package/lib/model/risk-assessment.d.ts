import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Range } from '../datatype/range';
import { Condition } from '../model/condition';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>RiskAssessment</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/RiskAssessment">http://hl7.org/fhir/StructureDefinition/RiskAssessment</a>
 * </p>
 *
 */
export declare class RiskAssessment extends DomainResource {
    /**
     * For assessments or prognosis specific to a particular condition, indicates the condition being assessed.
     *
     * Condition assessed
     */
    condition?: Condition | Reference;
    /**
     * A reference to the request that is fulfilled by this risk assessment.
     *
     * Request fulfilled by this assessment
     */
    basedOn?: Reference;
    /**
     * The status of the RiskAssessment, using the same statuses as an Observation.
     *
     * registered | preliminary | final | amended +
     */
    status: string;
    /**
     * Describes the expected outcome for the subject.
     *
     * Outcome predicted
     */
    prediction?: RiskAssessment.RiskAssessmentPredictionComponent[];
    /**
     * The patient or group the risk assessment applies to.
     *
     * Who/what does assessment apply to?
     */
    subject: Patient | Group | Reference;
    /**
     * The algorithm, process or mechanism used to evaluate the risk.
     *
     * Evaluation mechanism
     */
    method?: CodeableConcept;
    /**
     * A description of the steps that might be taken to reduce the identified risk(s).
     *
     * How to reduce risk
     */
    mitigation?: string;
    /**
     * The type of the risk assessment performed.
     *
     * Type of assessment
     */
    code?: CodeableConcept;
    /**
     * The provider, patient, related person, or software application that performed the assessment.
     *
     * Who did assessment?
     */
    performer?: Patient | Practitioner | PractitionerRole | RelatedPerson | Device | Reference;
    /**
     * Business identifier assigned to the risk assessment.
     *
     * Unique identifier for the assessment
     */
    identifier?: Identifier[];
    /**
     * A reference to a resource that this risk assessment is part of, such as a Procedure.
     *
     * Part of this occurrence
     */
    parent?: Reference;
    /**
     * The reason the risk assessment was performed.
     *
     * Why the assessment was necessary?
     */
    reason?: CodeableReference[];
    /**
     * Additional comments about the risk assessment.
     *
     * Comments on the risk assessment
     */
    note?: Annotation[];
    /**
     * Indicates the source data considered as part of the assessment (for example, FamilyHistory, Observations, Procedures, Conditions, etc.).
     *
     * Information used in assessment
     */
    basis?: Reference[];
    /**
     * The encounter where the assessment was performed.
     *
     * Where was assessment performed?
     */
    encounter?: Encounter | Reference;
    /**
     * The date (and possibly time) the risk assessment was performed.
     *
     * When was assessment made?
     */
    occurrence?: Date | Period;
    readonly resourceType: string;
    static revive(json: any): RiskAssessment;
    toJSON(): any;
}
export declare namespace RiskAssessment {
    enum ObservationStatus {
        CANCELLED,
        ENTEREDINERROR,
        NULL,
        AMENDED,
        REGISTERED,
        CORRECTED,
        PRELIMINARY,
        FINAL,
        UNKNOWN
    }
    class RiskAssessmentPredictionComponent extends BackboneElement {
        /**
         * Indicates how likely the outcome is (in the specified timeframe).
         *
         * Likelihood of specified outcome
         */
        probability?: number | Range;
        /**
         * Indicates how likely the outcome is (in the specified timeframe), expressed as a qualitative value (e.g. low, medium, or high).
         *
         * Likelihood of specified outcome as a qualitative value
         */
        qualitativeRisk?: CodeableConcept;
        /**
         * Indicates the risk for this particular subject (with their specific characteristics) divided by the risk of the population in general.  (Numbers greater than 1 = higher risk than the population, numbers less than 1 = lower risk.).
         *
         * Relative likelihood
         */
        relativeRisk?: number;
        /**
         * Indicates the period of time or age range of the subject to which the specified probability applies.
         *
         * Timeframe or age range
         */
        when?: Period | Range;
        /**
         * Additional information explaining the basis for the prediction.
         *
         * Explanation of prediction
         */
        rationale?: string;
        /**
         * One of the potential outcomes for the patient (e.g. remission, death,  a particular condition).
         *
         * Possible outcome for the subject
         */
        outcome?: CodeableConcept;
        static revive(json: any): RiskAssessmentPredictionComponent;
        toJSON(): any;
    }
}
