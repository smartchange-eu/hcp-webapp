import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { Ratio } from '../datatype/ratio';
import { Citation } from '../model/citation';
import { DocumentReference } from '../model/document-reference';
import { DomainResource } from '../model/domain-resource';
import { Organization } from '../model/organization';
import { SubstanceNucleicAcid } from '../model/substance-nucleic-acid';
import { SubstancePolymer } from '../model/substance-polymer';
import { SubstanceProtein } from '../model/substance-protein';
import { SubstanceReferenceInformation } from '../model/substance-reference-information';
/**
 * HAPI/FHIR <b>SubstanceDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/SubstanceDefinition">http://hl7.org/fhir/StructureDefinition/SubstanceDefinition</a>
 * </p>
 *
 */
export declare class SubstanceDefinition extends DomainResource {
    /**
     * Data items specific to polymers.
     *
     * Data items specific to polymers
     */
    polymer?: SubstancePolymer | Reference;
    /**
     * Identifier by which this substance is known.
     *
     * Identifier by which this substance is known
     */
    identifier?: Identifier[];
    /**
     * Textual comment about the substance's catalogue or registry record.
     *
     * Textual comment about the substance's catalogue or registry record
     */
    note?: Annotation[];
    /**
     * General information detailing this substance.
     *
     * General information detailing this substance
     */
    referenceInformation?: SubstanceReferenceInformation | Reference;
    /**
     * Codes associated with the substance.
     *
     * Codes associated with the substance
     */
    code?: SubstanceDefinition.SubstanceDefinitionCodeComponent[];
    /**
     * A high level categorization, e.g. polymer or nucleic acid, or food, chemical, biological, or a lower level such as the general types of polymer (linear or branch chain) or type of impurity (process related or contaminant).
     *
     * A categorization, high level e.g. polymer or nucleic acid, or food, chemical, biological, or lower e.g. polymer linear or branch chain, or type of impurity
     */
    classification?: CodeableConcept[];
    /**
     * A business level version identifier of the substance.
     *
     * A business level version identifier of the substance
     */
    version?: string;
    /**
     * Moiety, for structural modifications.
     *
     * Moiety, for structural modifications
     */
    moiety?: SubstanceDefinition.SubstanceDefinitionMoietyComponent[];
    /**
     * Structural information.
     *
     * Structural information
     */
    structure?: SubstanceDefinition.SubstanceDefinitionStructureComponent;
    /**
     * The entity that creates, makes, produces or fabricates the substance. This is a set of potential manufacturers but is not necessarily comprehensive.
     *
     * The entity that creates, makes, produces or fabricates the substance
     */
    manufacturer?: Organization[] | Reference[];
    /**
     * Material or taxonomic/anatomical source for the substance.
     *
     * Material or taxonomic/anatomical source
     */
    sourceMaterial?: SubstanceDefinition.SubstanceDefinitionSourceMaterialComponent;
    /**
     * Textual description of the substance.
     *
     * Textual description of the substance
     */
    description?: string;
    /**
     * The average mass of a molecule of a compound compared to 1/12 the mass of carbon 12 and calculated as the sum of the atomic weights of the constituent atoms.
     *
     * The average mass of a molecule of a compound
     */
    molecularWeight?: SubstanceDefinition.SubstanceDefinitionMolecularWeightComponent[];
    /**
     * Supporting literature.
     *
     * Supporting literature
     */
    informationSource?: Citation[] | Reference[];
    /**
     * If the substance applies to human or veterinary use.
     *
     * If the substance applies to human or veterinary use
     */
    domain?: CodeableConcept;
    /**
     * The quality standard, established benchmark, to which substance complies (e.g. USP/NF, Ph. Eur, JP, BP, Company Standard).
     *
     * The quality standard, established benchmark, to which substance complies (e.g. USP/NF, BP)
     */
    grade?: CodeableConcept[];
    /**
     * An entity that is the source for the substance. It may be different from the manufacturer. Supplier is synonymous to a distributor.
     *
     * An entity that is the source for the substance. It may be different from the manufacturer
     */
    supplier?: Organization[] | Reference[];
    /**
     * Data items specific to proteins.
     *
     * Data items specific to proteins
     */
    protein?: SubstanceProtein | Reference;
    /**
     * Data items specific to nucleic acids.
     *
     * Data items specific to nucleic acids
     */
    nucleicAcid?: SubstanceNucleicAcid | Reference;
    /**
     * A link between this substance and another, with details of the relationship.
     *
     * A link between this substance and another
     */
    relationship?: SubstanceDefinition.SubstanceDefinitionRelationshipComponent[];
    /**
     * General specifications for this substance.
     *
     * General specifications for this substance
     */
    characterization?: SubstanceDefinition.SubstanceDefinitionCharacterizationComponent[];
    /**
     * Status of substance within the catalogue e.g. active, retired.
     *
     * Status of substance within the catalogue e.g. active, retired
     */
    status?: CodeableConcept;
    /**
     * General specifications for this substance.
     *
     * General specifications for this substance
     */
    property?: SubstanceDefinition.SubstanceDefinitionPropertyComponent[];
    /**
     * Names applicable to this substance.
     *
     * Names applicable to this substance
     */
    name?: SubstanceDefinition.SubstanceDefinitionNameComponent[];
    readonly resourceType: string;
    static revive(json: any): SubstanceDefinition;
    toJSON(): any;
}
export declare namespace SubstanceDefinition {
    class SubstanceDefinitionSourceMaterialComponent extends BackboneElement {
        /**
         * A classification that provides the origin of the raw material. Example: cat hair would be an Animal source type.
         *
         * Classification of the origin of the raw material. e.g. cat hair is an Animal source type
         */
        type?: CodeableConcept;
        /**
         * The country or countries where the material is harvested.
         *
         * The country or countries where the material is harvested
         */
        countryOfOrigin?: CodeableConcept[];
        /**
         * The genus of an organism, typically referring to the Latin epithet of the genus element of the plant/animal scientific name.
         *
         * The genus of an organism e.g. the Latin epithet of the plant/animal scientific name
         */
        genus?: CodeableConcept;
        /**
         * The species of an organism, typically referring to the Latin epithet of the species of the plant/animal.
         *
         * The species of an organism e.g. the Latin epithet of the species of the plant/animal
         */
        species?: CodeableConcept;
        /**
         * An anatomical origin of the source material within an organism.
         *
         * An anatomical origin of the source material within an organism
         */
        part?: CodeableConcept;
        static revive(json: any): SubstanceDefinitionSourceMaterialComponent;
        toJSON(): any;
    }
    class SubstanceDefinitionRelationshipComponent extends BackboneElement {
        /**
         * Supporting literature.
         *
         * Supporting literature
         */
        source?: DocumentReference[] | Reference[];
        /**
         * For example "salt to parent", "active moiety", "starting material", "polymorph", "impurity of".
         *
         * For example "salt to parent", "active moiety"
         */
        type: CodeableConcept;
        /**
         * A pointer to another substance, as a resource or just a representational code.
         *
         * A pointer to another substance, as a resource or a representational code
         */
        substanceDefinition?: SubstanceDefinition | CodeableConcept | Reference;
        /**
         * For use when the numeric has an uncertain range.
         *
         * For use when the numeric has an uncertain range
         */
        ratioHighLimitAmount?: Ratio;
        /**
         * For example where an enzyme strongly bonds with a particular substance, this is a defining relationship for that enzyme, out of several possible substance relationships.
         *
         * For example where an enzyme strongly bonds with a particular substance, this is a defining relationship for that enzyme, out of several possible relationships
         */
        isDefining?: boolean;
        /**
         * An operator for the amount, for example "average", "approximately", "less than".
         *
         * An operator for the amount, for example "average", "approximately", "less than"
         */
        comparator?: CodeableConcept;
        /**
         * A numeric factor for the relationship, for instance to express that the salt of a substance has some percentage of the active substance in relation to some other.
         *
         * A numeric factor for the relationship, e.g. that a substance salt has some percentage of active substance in relation to some other
         */
        amount?: Quantity | Ratio | string;
        static revive(json: any): SubstanceDefinitionRelationshipComponent;
        toJSON(): any;
    }
    class SubstanceDefinitionNameOfficialComponent extends BackboneElement {
        /**
         * The status of the official name, for example 'draft', 'active', 'retired'.
         *
         * The status of the official name, for example 'draft', 'active'
         */
        status?: CodeableConcept;
        /**
         * Date of the official name change.
         *
         * Date of official name change
         */
        date?: Date;
        /**
         * Which authority uses this official name.
         *
         * Which authority uses this official name
         */
        authority?: CodeableConcept;
        static revive(json: any): SubstanceDefinitionNameOfficialComponent;
        toJSON(): any;
    }
    class SubstanceDefinitionNameComponent extends BackboneElement {
        /**
         * Supporting literature.
         *
         * Supporting literature
         */
        source?: DocumentReference[] | Reference[];
        /**
         * Human language that the name is written in.
         *
         * Human language that the name is written in
         */
        language?: CodeableConcept[];
        /**
         * Details of the official nature of this name.
         *
         * Details of the official nature of this name
         */
        official?: SubstanceDefinition.SubstanceDefinitionNameOfficialComponent[];
        /**
         * The actual name.
         *
         * The actual name
         */
        name: string;
        /**
         * A translation for this name into another human language.
         *
         * A translation for this name into another human language
         */
        translation?: SubstanceDefinition.SubstanceDefinitionNameComponent[];
        /**
         * The status of the name, for example 'current', 'proposed'.
         *
         * The status of the name e.g. 'current', 'proposed'
         */
        status?: CodeableConcept;
        /**
         * If this is the preferred name for this substance.
         *
         * If this is the preferred name for this substance
         */
        preferred?: boolean;
        /**
         * Name type, for example 'systematic',  'scientific, 'brand'.
         *
         * Name type e.g. 'systematic',  'scientific, 'brand'
         */
        type?: CodeableConcept;
        /**
         * A synonym of this particular name, by which the substance is also known.
         *
         * A synonym of this particular name, by which the substance is also known
         */
        synonym?: SubstanceDefinition.SubstanceDefinitionNameComponent[];
        /**
         * The use context of this name for example if there is a different name a drug active ingredient as opposed to a food colour additive.
         *
         * The use context of this name e.g. as an active ingredient or as a food colour additive
         */
        domain?: CodeableConcept[];
        /**
         * The jurisdiction where this name applies.
         *
         * The jurisdiction where this name applies
         */
        jurisdiction?: CodeableConcept[];
        static revive(json: any): SubstanceDefinitionNameComponent;
        toJSON(): any;
    }
    class SubstanceDefinitionCodeComponent extends BackboneElement {
        /**
         * The date at which the code status was changed as part of the terminology maintenance.
         *
         * The date at which the code status was changed
         */
        statusDate?: Date;
        /**
         * Any comment can be provided in this field, if necessary.
         *
         * Any comment can be provided in this field
         */
        note?: Annotation[];
        /**
         * The specific code.
         *
         * The specific code
         */
        code?: CodeableConcept;
        /**
         * Status of the code assignment, for example 'provisional', 'approved'.
         *
         * Status of the code assignment, for example 'provisional', 'approved'
         */
        status?: CodeableConcept;
        /**
         * Supporting literature.
         *
         * Supporting literature
         */
        source?: DocumentReference[] | Reference[];
        static revive(json: any): SubstanceDefinitionCodeComponent;
        toJSON(): any;
    }
    class SubstanceDefinitionStructureRepresentationComponent extends BackboneElement {
        /**
         * An attached file with the structural representation e.g. a molecular structure graphic of the substance, a JCAMP or AnIML file.
         *
         * An attachment with the structural representation e.g. a structure graphic or AnIML file
         */
        document?: DocumentReference | Reference;
        /**
         * The format of the representation e.g. InChI, SMILES, MOLFILE, CDX, SDF, PDB, mmCIF. The logical content type rather than the physical file format of a document.
         *
         * The format of the representation e.g. InChI, SMILES, MOLFILE (note: not the physical file format)
         */
        format?: CodeableConcept;
        /**
         * The structural representation as a text string in a standard format.
         *
         * The structural representation as a text string in a standard format
         */
        representation?: string;
        /**
         * The kind of structural representation (e.g. full, partial).
         *
         * The kind of structural representation (e.g. full, partial)
         */
        type?: CodeableConcept;
        static revive(json: any): SubstanceDefinitionStructureRepresentationComponent;
        toJSON(): any;
    }
    class SubstanceDefinitionStructureComponent extends BackboneElement {
        /**
         * The method used to elucidate the structure of the drug substance. Examples: X-ray, NMR, Peptide mapping, Ligand binding assay.
         *
         * The method used to find the structure e.g. X-ray, NMR
         */
        technique?: CodeableConcept[];
        /**
         * Stereochemistry type.
         *
         * Stereochemistry type
         */
        stereochemistry?: CodeableConcept;
        /**
         * Specified per moiety according to the Hill system, i.e. first C, then H, then alphabetical, each moiety separated by a dot.
         *
         * Specified per moiety according to the Hill system
         */
        molecularFormulaByMoiety?: string;
        /**
         * The molecular weight or weight range (for proteins, polymers or nucleic acids).
         *
         * The molecular weight or weight range
         */
        molecularWeight?: SubstanceDefinition.SubstanceDefinitionMolecularWeightComponent;
        /**
         * A depiction of the structure of the substance.
         *
         * A depiction of the structure of the substance
         */
        representation?: SubstanceDefinition.SubstanceDefinitionStructureRepresentationComponent[];
        /**
         * The source of information about the structure.
         *
         * Source of information for the structure
         */
        sourceDocument?: DocumentReference[] | Reference[];
        /**
         * An expression which states the number and type of atoms present in a molecule of a substance.
         *
         * An expression which states the number and type of atoms present in a molecule of a substance
         */
        molecularFormula?: string;
        /**
         * Optical activity type.
         *
         * Optical activity type
         */
        opticalActivity?: CodeableConcept;
        static revive(json: any): SubstanceDefinitionStructureComponent;
        toJSON(): any;
    }
    class SubstanceDefinitionMolecularWeightComponent extends BackboneElement {
        /**
         * Type of molecular weight such as exact, average (also known as. number average), weight average.
         *
         * Type of molecular weight e.g. exact, average, weight average
         */
        type?: CodeableConcept;
        /**
         * Used to capture quantitative values for a variety of elements. If only limits are given, the arithmetic mean would be the average. If only a single definite value for a given element is given, it would be captured in this field.
         *
         * Used to capture quantitative values for a variety of elements
         */
        amount: Quantity;
        /**
         * The method by which the molecular weight was determined.
         *
         * The method by which the weight was determined
         */
        method?: CodeableConcept;
        static revive(json: any): SubstanceDefinitionMolecularWeightComponent;
        toJSON(): any;
    }
    class SubstanceDefinitionPropertyComponent extends BackboneElement {
        /**
         * A value for the property.
         *
         * A value for the property
         */
        value?: CodeableConcept | Quantity | Date | boolean | Attachment;
        /**
         * A code expressing the type of property.
         *
         * A code expressing the type of property
         */
        type: CodeableConcept;
        static revive(json: any): SubstanceDefinitionPropertyComponent;
        toJSON(): any;
    }
    class SubstanceDefinitionCharacterizationComponent extends BackboneElement {
        /**
         * The method used to elucidate the characterization of the drug substance. Example: HPLC.
         *
         * The method used to find the characterization e.g. HPLC
         */
        technique?: CodeableConcept;
        /**
         * The description or justification in support of the interpretation of the data file.
         *
         * The description or justification in support of the interpretation of the data file
         */
        description?: string;
        /**
         * Describes the nature of the chemical entity and explains, for instance, whether this is a base or a salt form.
         *
         * Describes the nature of the chemical entity and explains, for instance, whether this is a base or a salt form
         */
        form?: CodeableConcept;
        /**
         * The data produced by the analytical instrument or a pictorial representation of that data. Examples: a JCAMP, JDX, or ADX file, or a chromatogram or spectrum analysis.
         *
         * The data produced by the analytical instrument or a pictorial representation of that data. Examples: a JCAMP, JDX, or ADX file, or a chromatogram or spectrum analysis
         */
        file?: Attachment[];
        static revive(json: any): SubstanceDefinitionCharacterizationComponent;
        toJSON(): any;
    }
    class SubstanceDefinitionMoietyComponent extends BackboneElement {
        /**
         * Quantitative value for this moiety.
         *
         * Quantitative value for this moiety
         */
        amount?: Quantity | string;
        /**
         * Role that the moiety is playing.
         *
         * Role that the moiety is playing
         */
        role?: CodeableConcept;
        /**
         * Identifier by which this moiety substance is known.
         *
         * Identifier by which this moiety substance is known
         */
        identifier?: Identifier;
        /**
         * Optical activity type.
         *
         * Optical activity type
         */
        opticalActivity?: CodeableConcept;
        /**
         * Molecular formula for this moiety of this substance, typically using the Hill system.
         *
         * Molecular formula for this moiety (e.g. with the Hill system)
         */
        molecularFormula?: string;
        /**
         * Textual name for this moiety substance.
         *
         * Textual name for this moiety substance
         */
        name?: string;
        /**
         * Stereochemistry type.
         *
         * Stereochemistry type
         */
        stereochemistry?: CodeableConcept;
        /**
         * The measurement type of the quantitative value. In capturing the actual relative amounts of substances or molecular fragments it may be necessary to indicate whether the amount refers to, for example, a mole ratio or weight ratio.
         *
         * The measurement type of the quantitative value
         */
        measurementType?: CodeableConcept;
        static revive(json: any): SubstanceDefinitionMoietyComponent;
        toJSON(): any;
    }
}
