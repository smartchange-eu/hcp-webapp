import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { RelatedArtifact } from '../datatype/related-artifact';
import { UsageContext } from '../datatype/usage-context';
import { MetadataResource } from '../model/metadata-resource';
/**
 * HAPI/FHIR <b>ConceptMap</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ConceptMap">http://hl7.org/fhir/StructureDefinition/ConceptMap</a>
 * </p>
 *
 */
export declare class ConceptMap extends MetadataResource {
    /**
     * Indicates the mechanism used to compare versions to determine which ConceptMap is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * An additionalAttribute defines an additional data element found in the source or target data model where the data will come from or be mapped to. Some mappings are based on data in addition to the source data element, where codes in multiple fields are combined to a single field (or vice versa).
     *
     * Definition of an additional attribute to act as a data source or target
     */
    additionalAttribute?: ConceptMap.AdditionalAttributeComponent[];
    /**
     * An individual or organization asserted by the publisher to be responsible for officially endorsing the ConceptMap for use in some setting.
     *
     * Who endorsed the ConceptMap
     */
    endorser?: ContactDetail[];
    /**
     * A property defines a slot through which additional information can be provided about a map from source -> target.
     *
     * Additional properties of the mapping
     */
    property?: ConceptMap.PropertyComponent[];
    /**
     * A group of mappings that all have the same source and target system.
     *
     * Same source and target systems
     */
    group?: ConceptMap.ConceptMapGroupComponent[];
    /**
     * A copyright statement relating to the concept map and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the concept map.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * The date on which the resource content was approved by the publisher. Approval happens once when the content is officially approved for usage.
     *
     * When the ConceptMap was approved by publisher
     */
    approvalDate?: Date;
    /**
     * The date  (and optionally time) when the concept map was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the concept map changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * A legal or geographic region in which the concept map is intended to be used.
     *
     * Intended jurisdiction for concept map (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * Explanation of why this concept map is needed and why it has been designed as it has.
     *
     * Why this concept map is defined
     */
    purpose?: string;
    /**
     * A Boolean value to indicate that this concept map is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A free text natural language description of the concept map from a consumer's perspective.
     *
     * Natural language description of the concept map
     */
    description?: string;
    /**
     * A short, descriptive, user-friendly title for the concept map.
     *
     * Name for this concept map (human friendly)
     */
    title?: string;
    /**
     * Identifier for the target value set that provides important context about how the mapping choices are made.  Limits the scope of the map to target codes (ConceptMap.group.element.target code or valueSet) that are members of this value set.
     *
     * The target value set which provides context for the mappings
     */
    targetScope?: string;
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * The date on which the resource content was last reviewed. Review happens periodically after approval but does not change the original approval date.
     *
     * When the ConceptMap was last reviewed by the publisher
     */
    lastReviewDate?: Date;
    /**
     * Identifier for the source value set that contains the concepts that are being mapped and provides context for the mappings.  Limits the scope of the map to source codes (ConceptMap.group.element code or valueSet) that are members of this value set.
     *
     * The source value set that contains the concepts that are being mapped
     */
    sourceScope?: string;
    /**
     * A natural language name identifying the concept map. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this concept map (computer friendly)
     */
    name?: string;
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the concept map.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * Descriptions related to the content of the ConceptMap. Topics provide a high-level categorization as well as keywords for the ConceptMap that can be useful for filtering and searching.
     *
     * E.g. Education, Treatment, Assessment, etc
     */
    topic?: CodeableConcept[];
    /**
     * The status of this concept map. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate concept map instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * Related artifacts such as additional documentation, justification, dependencies, bibliographic references, and predecessor and successor artifacts.
     *
     * Additional documentation, citations, etc
     */
    relatedArtifact?: RelatedArtifact[];
    /**
     * A formal identifier that is used to identify this concept map when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the concept map
     */
    identifier?: Identifier[];
    /**
     * An individual or organization primarily responsible for internal coherence of the ConceptMap.
     *
     * Who edited the ConceptMap
     */
    editor?: ContactDetail[];
    /**
     * An individiual or organization primarily involved in the creation and maintenance of the ConceptMap.
     *
     * Who authored the ConceptMap
     */
    author?: ContactDetail[];
    /**
     * The period during which the ConceptMap content was or is planned to be in active use.
     *
     * When the ConceptMap is expected to be used
     */
    effectivePeriod?: Period;
    /**
     * An individual or organization asserted by the publisher to be primarily responsible for review of some aspect of the ConceptMap.
     *
     * Who reviewed the ConceptMap
     */
    reviewer?: ContactDetail[];
    /**
     * An absolute URI that is used to identify this concept map when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this concept map is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the concept map is stored on different servers.
     *
     * Canonical identifier for this concept map, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * The identifier that is used to identify this version of the concept map when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the concept map author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the concept map
     */
    version?: string;
    readonly resourceType: string;
    static revive(json: any): ConceptMap;
    toJSON(): any;
}
export declare namespace ConceptMap {
    enum ConceptMapPropertyType {
        CODE,
        NULL,
        DATETIME,
        CODING,
        STRING,
        DECIMAL,
        BOOLEAN,
        INTEGER
    }
    enum ConceptMapGroupUnmappedMode {
        USESOURCECODE,
        NULL,
        FIXED,
        OTHERMAP
    }
    enum ConceptMapAttributeType {
        CODE,
        NULL,
        QUANTITY,
        CODING,
        STRING,
        BOOLEAN
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class ConceptMapGroupUnmappedComponent extends BackboneElement {
        /**
         * The fixed code to use when the mode = 'fixed'  - all unmapped codes are mapped to a single fixed code.
         *
         * Fixed code when mode = fixed
         */
        code?: string;
        /**
         * The set of fixed codes to use when the mode = 'fixed'  - all unmapped codes are mapped to each of the fixed codes.
         *
         * Fixed code set when mode = fixed
         */
        valueSet?: string;
        /**
         * Defines which action to take if there is no match for the source concept in the target system designated for the group. One of 3 actions are possible: use the unmapped source code (this is useful when doing a mapping between versions, and only a few codes have changed), use a fixed code (a default code), or alternatively, a reference to a different concept map can be provided (by canonical URL).
         *
         * use-source-code | fixed | other-map
         */
        mode: string;
        /**
         * The display for the code. The display is only provided to help editors when editing the concept map.
         *
         * Display for the code
         */
        display?: string;
        /**
         * The canonical reference to an additional ConceptMap resource instance to use for mapping if this ConceptMap resource contains no matching mapping for the source concept.
         *
         * canonical reference to an additional ConceptMap to use for mapping if the source concept is unmapped
         */
        otherMap?: string;
        /**
         * The default relationship value to apply between the source and target concepts when the source code is unmapped and the mode is 'fixed' or 'use-source-code'.
         *
         * related-to | equivalent | source-is-narrower-than-target | source-is-broader-than-target | not-related-to
         */
        relationship?: string;
        static revive(json: any): ConceptMapGroupUnmappedComponent;
        toJSON(): any;
    }
    class OtherElementComponent extends BackboneElement {
        /**
         * A reference to the additional attribute that holds a value the map depends on.
         *
         * A reference to a mapping attribute defined in ConceptMap.additionalAttribute
         */
        attribute: string;
        /**
         * Data element value that the map depends on / produces.
         *
         * Value of the referenced data element
         */
        value?: string | Coding | boolean | Quantity;
        /**
         * This mapping applies if the data element value is a code from this value set.
         *
         * The mapping depends on a data element with a value from this value set
         */
        valueSet?: string;
        static revive(json: any): OtherElementComponent;
        toJSON(): any;
    }
    class MappingPropertyComponent extends BackboneElement {
        /**
         * The value of this property. If the type chosen for this element is 'code', then the property SHALL be defined in a ConceptMap.property element.
         *
         * Value of the property for this concept
         */
        value: Coding | string | number | boolean | Date | number;
        /**
         * A reference to a mapping property defined in ConceptMap.property.
         *
         * Reference to ConceptMap.property.code
         */
        code: string;
        static revive(json: any): MappingPropertyComponent;
        toJSON(): any;
    }
    class TargetElementComponent extends BackboneElement {
        /**
         * A description of status/issues in mapping that conveys additional information not represented in  the structured data.
         *
         * Description of status/issues in mapping
         */
        comment?: string;
        /**
         * A property value for this source -> target mapping.
         *
         * Property value for the source -> target mapping
         */
        property?: ConceptMap.MappingPropertyComponent[];
        /**
         * The relationship between the source and target concepts. The relationship is read from source to target (e.g. source-is-narrower-than-target).
         *
         * related-to | equivalent | source-is-narrower-than-target | source-is-broader-than-target | not-related-to
         */
        relationship: string;
        /**
         * Identity (code or path) or the element/item that the map refers to.
         *
         * Code that identifies the target element
         */
        code?: string;
        /**
         * The set of concepts from the ConceptMap.group.target code system which are all being mapped to as part of this mapping rule. The effect of using this data element is the same as having multiple ConceptMap.group.element.target elements with one for each concept in the ConceptMap.group.element.target.valueSet value set.
         *
         * Identifies the set of target concepts
         */
        valueSet?: string;
        /**
         * Product is the output of a ConceptMap that provides additional values that go in other attributes / data elemnts of the target data.
         *
         * Other data elements that this mapping also produces
         */
        product?: ConceptMap.OtherElementComponent[];
        /**
         * The display for the code. The display is only provided to help editors when editing the concept map.
         *
         * Display for the code
         */
        display?: string;
        /**
         * A set of additional dependencies for this mapping to hold. This mapping is only applicable if the specified data attribute can be resolved, and it has the specified value.
         *
         * Other properties required for this mapping
         */
        dependsOn?: ConceptMap.OtherElementComponent[];
        static revive(json: any): TargetElementComponent;
        toJSON(): any;
    }
    class SourceElementComponent extends BackboneElement {
        /**
         * If noMap = true this indicates that no mapping to a target concept exists for this source concept.
         *
         * No mapping to a target concept for this source concept
         */
        noMap?: boolean;
        /**
         * A concept from the target value set that this concept maps to.
         *
         * Concept in target system for element
         */
        target?: ConceptMap.TargetElementComponent[];
        /**
         * Identity (code or path) or the element/item being mapped.
         *
         * Identifies element being mapped
         */
        code?: string;
        /**
         * The set of concepts from the ConceptMap.group.source code system which are all being mapped to the target as part of this mapping rule.
         *
         * Identifies the set of concepts being mapped
         */
        valueSet?: string;
        /**
         * The display for the code. The display is only provided to help editors when editing the concept map.
         *
         * Display for the code
         */
        display?: string;
        static revive(json: any): SourceElementComponent;
        toJSON(): any;
    }
    class ConceptMapGroupComponent extends BackboneElement {
        /**
         * What to do when there is no mapping to a target concept from the source concept and ConceptMap.group.element.noMap is not true. This provides the "default" to be applied when there is no target concept mapping specified or the expansion of ConceptMap.group.element.target.valueSet is empty.
         *
         * What to do when there is no mapping target for the source concept and ConceptMap.group.element.noMap is not true
         */
        unmapped?: ConceptMap.ConceptMapGroupUnmappedComponent;
        /**
         * An absolute URI that identifies the target system that the concepts will be mapped to.
         *
         * Target system that the concepts are to be mapped to
         */
        target?: string;
        /**
         * Mappings for an individual concept in the source to one or more concepts in the target.
         *
         * Mappings for a concept from the source set
         */
        element: ConceptMap.SourceElementComponent[];
        /**
         * An absolute URI that identifies the source system where the concepts to be mapped are defined.
         *
         * Source system where concepts to be mapped are defined
         */
        source?: string;
        static revive(json: any): ConceptMapGroupComponent;
        toJSON(): any;
    }
    class AdditionalAttributeComponent extends BackboneElement {
        /**
         * The type of the source data contained in this concept map for this data element.
         *
         * code | Coding | string | boolean | Quantity
         */
        type: string;
        /**
         * Reference to the formal definition of the source/target data element. For elements defined by the FHIR specification, or using a FHIR logical model, the correct format is {canonical-url}#{element-id}.
         *
         * Formal identifier for the data element referred to in this attribte
         */
        uri?: string;
        /**
         * A description of the additional attribute and/or the data element it refers to - why it is defined, and how the value might be used in mappings, and a discussion of issues associated with the use of the data element.
         *
         * Why the additional attribute is defined, and/or what the data element it refers to is
         */
        description?: string;
        /**
         * A code that is used to identify this additional data attribute. The code is used internally in ConceptMap.group.element.target.dependsOn.attribute and ConceptMap.group.element.target.product.attribute.
         *
         * Identifies this additional attribute through this resource
         */
        code: string;
        static revive(json: any): AdditionalAttributeComponent;
        toJSON(): any;
    }
    class PropertyComponent extends BackboneElement {
        /**
         * A code that is used to identify the property. The code is used internally (in ConceptMap.group.element.target.property.code) and also in the $translate operation.
         *
         * Identifies the property on the mappings, and when referred to in the $translate operation
         */
        code: string;
        /**
         * The CodeSystem that defines the codes from which values of type ```code``` in property values.
         *
         * The CodeSystem from which code values come
         */
        system?: string;
        /**
         * Reference to the formal meaning of the property.
         *
         * Formal identifier for the property
         */
        uri?: string;
        /**
         * The type of the property value.
         *
         * Coding | string | integer | boolean | dateTime | decimal | code
         */
        type: string;
        /**
         * A description of the property - why it is defined, and how its value might be used.
         *
         * Why the property is defined, and/or what it conveys
         */
        description?: string;
        static revive(json: any): PropertyComponent;
        toJSON(): any;
    }
}
