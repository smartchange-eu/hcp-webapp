import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Coding } from '../datatype/coding';
import { ContactPoint } from '../datatype/contact-point';
import { Identifier } from '../datatype/identifier';
import { CareTeam } from '../model/care-team';
import { DomainResource } from '../model/domain-resource';
import { HealthcareService } from '../model/healthcare-service';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Subscription</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Subscription">http://hl7.org/fhir/StructureDefinition/Subscription</a>
 * </p>
 *
 */
export declare class Subscription extends DomainResource {
    /**
     * A formal identifier that is used to identify this code system when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifiers (business identifier)
     */
    identifier?: Identifier[];
    /**
     * A description of why this subscription is defined.
     *
     * Description of why this subscription was created
     */
    reason?: string;
    /**
     * The filter properties to be applied to narrow the subscription topic stream.  When multiple filters are applied, evaluates to true if all the conditions applicable to that resource are met; otherwise it returns false (i.e., logical AND).
     *
     * Criteria for narrowing the subscription topic stream
     */
    filterBy?: Subscription.SubscriptionFilterByComponent[];
    /**
     * If present, a 'heartbeat' notification (keep-alive) is sent via this channel with an interval period equal to this elements integer value in seconds.  If not present, a heartbeat notification is not sent.
     *
     * Interval in seconds to send 'heartbeat' notification
     */
    heartbeatPeriod?: number;
    /**
     * If present, the maximum number of events that will be included in a notification bundle. Note that this is not a strict limit on the number of entries in a bundle, as dependent resources can be included.
     *
     * Maximum number of events that can be combined in a single notification
     */
    maxCount?: number;
    /**
     * If present, the maximum amount of time a server will allow before failing a notification attempt.
     *
     * Timeout in seconds to attempt notification delivery
     */
    timeout?: number;
    /**
     * How much of the resource content to deliver in the notification payload. The choices are an empty payload, only the resource id, or the full resource content.
     *
     * empty | id-only | full-resource
     */
    content?: string;
    /**
     * The type of channel to send notifications on.
     *
     * Channel type for notifications
     */
    channelType: Coding;
    /**
     * Contact details for a human to contact about the subscription. The primary use of this for system administrator troubleshooting.
     *
     * Contact details for source (e.g. troubleshooting)
     */
    contact?: ContactPoint[];
    /**
     * Channel-dependent information to send as part of the notification (e.g., HTTP Headers).
     *
     * Channel type
     */
    parameter?: Subscription.SubscriptionParameterComponent[];
    /**
     * Entity with authorization to make subsequent revisions to the Subscription and also determines what data the subscription is authorized to disclose.
     *
     * Entity responsible for Subscription changes
     */
    managingEntity?: CareTeam | HealthcareService | Organization | RelatedPerson | Patient | Practitioner | PractitionerRole | Reference;
    /**
     * The url that describes the actual end-point to send notifications to.
     *
     * Where the channel points to
     */
    endpoint?: string;
    /**
     * The MIME type to send the payload in - e.g., `application/fhir+xml` or `application/fhir+json`. Note that:

* clients may request notifications in a specific FHIR version by using the [FHIR Version Parameter](http.html#version-parameter) - e.g., `application/fhir+json; fhirVersion=4.0`.

* additional MIME types can be allowed by channels - e.g., `text/plain` and `text/html` are defined by the Email channel.
     *
     * MIME type to send, or omit for no payload
     */
    contentType?: string;
    /**
     * The status of the subscription, which marks the server state for managing the subscription.
     *
     * requested | active | error | off | entered-in-error
     */
    status: string;
    /**
     * A natural language name identifying the subscription.
     *
     * Human readable name for this subscription
     */
    name?: string;
    /**
     * The reference to the subscription topic to be notified about.
     *
     * Reference to the subscription topic being subscribed to
     */
    topic: string;
    /**
     * The time for the server to turn the subscription off.
     *
     * When to automatically delete the subscription
     */
    end?: Date;
    readonly resourceType: string;
    static revive(json: any): Subscription;
    toJSON(): any;
}
export declare namespace Subscription {
    enum SubscriptionPayloadContent {
        IDONLY,
        NULL,
        EMPTY,
        FULLRESOURCE
    }
    enum SubscriptionStatusCodes {
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        REQUESTED,
        ERROR,
        OFF
    }
    class SubscriptionParameterComponent extends BackboneElement {
        /**
         * Parameter value for information passed to the channel for notifications, for example in the case of a REST hook wanting to pass through an authorization header, the value would be `Bearer 0193...`.
         *
         * Value of the parameter to use or pass through
         */
        value: string;
        /**
         * Parameter name for information passed to the channel for notifications, for example in the case of a REST hook wanting to pass through an authorization header, the name would be Authorization.
         *
         * Name (key) of the parameter
         */
        name: string;
        static revive(json: any): SubscriptionParameterComponent;
        toJSON(): any;
    }
    class SubscriptionFilterByComponent extends BackboneElement {
        /**
         * Comparator applied to this filter parameter.
         *
         * eq | ne | gt | lt | ge | le | sa | eb | ap
         */
        comparator?: string;
        /**
         * Modifier applied to this filter parameter.
         *
         * missing | exact | contains | not | text | in | not-in | below | above | type | identifier | of-type | code-text | text-advanced | iterate
         */
        modifier?: string;
        /**
         * The filter as defined in the `SubscriptionTopic.canFilterBy.filterParameter` element.
         *
         * Filter label defined in SubscriptionTopic
         */
        filterParameter: string;
        /**
         * A resource listed in the `SubscriptionTopic` this `Subscription` references (`SubscriptionTopic.canFilterBy.resource`). This element can be used to differentiate filters for topics that include more than one resource type.
         *
         * Allowed Resource (reference to definition) for this Subscription filter
         */
        resourceType?: string;
        /**
         * The literal value or resource path as is legal in search - for example, `Patient/123` or `le1950`.
         *
         * Literal value or resource path
         */
        value: string;
        static revive(json: any): SubscriptionFilterByComponent;
        toJSON(): any;
    }
}
