import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Dosage } from '../datatype/dosage';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { CarePlan } from '../model/care-plan';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { Location } from '../model/location';
import { MedicationAdministration } from '../model/medication-administration';
import { MedicationRequest } from '../model/medication-request';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Procedure } from '../model/procedure';
import { Provenance } from '../model/provenance';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>MedicationDispense</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/MedicationDispense">http://hl7.org/fhir/StructureDefinition/MedicationDispense</a>
 * </p>
 *
 */
export declare class MedicationDispense extends DomainResource {
    /**
     * The time when the dispensed product was packaged and reviewed.
     *
     * When product was packaged and reviewed
     */
    whenPrepared?: Date;
    /**
     * Identifies the person who picked up the medication or the location of where the medication was delivered.  This will usually be a patient or their caregiver, but some cases exist where it can be a healthcare professional or a location.
     *
     * Who collected the medication or where the medication was delivered
     */
    receiver?: Patient[] | Practitioner[] | RelatedPerson[] | Location[] | PractitionerRole[] | Reference[];
    /**
     * The amount of medication expressed as a timing amount.
     *
     * Amount of medication expressed as a timing amount
     */
    daysSupply?: Quantity;
    /**
     * Identifiers associated with this Medication Dispense that are defined by business processes and/or used to refer to it when a direct URL reference to the resource itself is not appropriate. They are business identifiers assigned to this resource by the performer or other systems and remain constant as the resource is updated and propagates from server to server.
     *
     * External identifier
     */
    identifier?: Identifier[];
    /**
     * Indicates who or what performed the event.
     *
     * Who performed event
     */
    performer?: MedicationDispense.MedicationDispensePerformerComponent[];
    /**
     * The amount of medication that has been dispensed. Includes unit of measure.
     *
     * Amount dispensed
     */
    quantity?: Quantity;
    /**
     * The date (and maybe time) when the dispense activity started if whenPrepared or whenHandedOver is not populated.
     *
     * When the recording of the dispense started
     */
    recorded?: Date;
    /**
     * Additional information that supports the medication being dispensed.  For example, there may be requirements that a specific lab test has been completed prior to dispensing or the patient's weight at the time of dispensing is documented.
     *
     * Information that supports the dispensing of the medication
     */
    supportingInformation?: Reference[];
    /**
     * The time the dispensed product was provided to the patient or their representative.
     *
     * When product was given out
     */
    whenHandedOver?: Date;
    /**
     * Identifies the medication supplied. This is either a link to a resource representing the details of the medication or a simple attribute carrying a code that identifies the medication from a known list of medications.
     *
     * What medication was supplied
     */
    medication: CodeableReference;
    /**
     * The encounter that establishes the context for this event.
     *
     * Encounter associated with event
     */
    encounter?: Encounter | Reference;
    /**
     * Indicates how the medication is to be used by the patient.
     *
     * How the medication is to be used by the patient or administered by the caregiver
     */
    dosageInstruction?: Dosage[];
    /**
     * Indicates the type of medication dispense (for example, drug classification like ATC, where meds would be administered, legal category of the medication.).
     *
     * Type of medication dispense
     */
    category?: CodeableConcept[];
    /**
     * A code specifying the state of the set of dispense events.
     *
     * preparation | in-progress | cancelled | on-hold | completed | entered-in-error | stopped | declined | unknown
     */
    status: string;
    /**
     * A summary of the events of interest that have occurred, such as when the dispense was verified.
     *
     * A list of relevant lifecycle events
     */
    eventHistory?: Provenance[] | Reference[];
    /**
     * The principal physical location where the dispense was performed.
     *
     * Where the dispense occurred
     */
    location?: Location | Reference;
    /**
     * A link to a resource representing the person or the group to whom the medication will be given.
     *
     * Who the dispense is for
     */
    subject: Patient | Group | Reference;
    /**
     * The procedure or medication administration that triggered the dispense.
     *
     * Event that dispense is part of
     */
    partOf?: Procedure[] | MedicationAdministration[] | Reference[];
    /**
     * Extra information about the dispense that could not be conveyed in the other attributes.
     *
     * Information about the dispense
     */
    note?: Annotation[];
    /**
     * Indicates the reason why a dispense was not performed.
     *
     * Why a dispense was not performed
     */
    notPerformedReason?: CodeableReference;
    /**
     * Indicates whether or not substitution was made as part of the dispense.  In some cases, substitution will be expected but does not happen, in other cases substitution is not expected but does happen.  This block explains what substitution did or did not happen and why.  If nothing is specified, substitution was not done.
     *
     * Whether a substitution was performed on the dispense
     */
    substitution?: MedicationDispense.MedicationDispenseSubstitutionComponent;
    /**
     * Indicates the type of dispensing event that is performed. For example, Trial Fill, Completion of Trial, Partial Fill, Emergency Fill, Samples, etc.
     *
     * Trial fill, partial fill, emergency fill, etc
     */
    type?: CodeableConcept;
    /**
     * Identification of the facility/location where the medication was/will be shipped to, as part of the dispense event.
     *
     * Where the medication was/will be sent
     */
    destination?: Location | Reference;
    /**
     * The full representation of the dose of the medication included in all dosage instructions.  To be used when multiple dosage instructions are included to represent complex dosing such as increasing or tapering doses.
     *
     * Full representation of the dosage instructions
     */
    renderedDosageInstruction?: string;
    /**
     * Indicates the medication order that is being dispensed against.
     *
     * Medication order that authorizes the dispense
     */
    authorizingPrescription?: MedicationRequest[] | Reference[];
    /**
     * A plan that is fulfilled in whole or in part by this MedicationDispense.
     *
     * Plan that is fulfilled by this dispense
     */
    basedOn?: CarePlan[] | Reference[];
    /**
     * The date (and maybe time) when the status of the dispense record changed.
     *
     * When the status changed
     */
    statusChanged?: Date;
    readonly resourceType: string;
    static revive(json: any): MedicationDispense;
    toJSON(): any;
}
export declare namespace MedicationDispense {
    enum MedicationDispenseStatusCodes {
        CANCELLED,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ONHOLD,
        STOPPED,
        INPROGRESS,
        UNKNOWN,
        PREPARATION,
        DECLINED
    }
    class MedicationDispenseSubstitutionComponent extends BackboneElement {
        /**
         * Indicates the reason for the substitution (or lack of substitution) from what was prescribed.
         *
         * Why was substitution made
         */
        reason?: CodeableConcept[];
        /**
         * The person or organization that has primary responsibility for the substitution.
         *
         * Who is responsible for the substitution
         */
        responsibleParty?: Practitioner | PractitionerRole | Organization | Reference;
        /**
         * True if the dispenser dispensed a different drug or product from what was prescribed.
         *
         * Whether a substitution was or was not performed on the dispense
         */
        wasSubstituted: boolean;
        /**
         * A code signifying whether a different drug was dispensed from what was prescribed.
         *
         * Code signifying whether a different drug was dispensed from what was prescribed
         */
        type?: CodeableConcept;
        static revive(json: any): MedicationDispenseSubstitutionComponent;
        toJSON(): any;
    }
    class MedicationDispensePerformerComponent extends BackboneElement {
        /**
         * Distinguishes the type of performer in the dispense.  For example, date enterer, packager, final checker.
         *
         * Who performed the dispense and what they did
         */
        function?: CodeableConcept;
        /**
         * The device, practitioner, etc. who performed the action.  It should be assumed that the actor is the dispenser of the medication.
         *
         * Individual who was performing
         */
        actor: Practitioner | PractitionerRole | Organization | Patient | Device | RelatedPerson | CareTeam | Reference;
        static revive(json: any): MedicationDispensePerformerComponent;
        toJSON(): any;
    }
}
