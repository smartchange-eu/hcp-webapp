import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { AllergyIntolerance } from '../model/allergy-intolerance';
import { Condition } from '../model/condition';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RiskAssessment } from '../model/risk-assessment';
/**
 * HAPI/FHIR <b>ClinicalImpression</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ClinicalImpression">http://hl7.org/fhir/StructureDefinition/ClinicalImpression</a>
 * </p>
 *
 */
export declare class ClinicalImpression extends DomainResource {
    /**
     * Identifies the workflow status of the assessment.
     *
     * preparation | in-progress | not-done | on-hold | stopped | completed | entered-in-error | unknown
     */
    status: string;
    /**
     * Change in the status/pattern of a subject's condition since previously assessed, such as worsening, improving, or no change.  It is a subjective assessment of the direction of the change.
     *
     * Change in the status/pattern of a subject's condition since previously assessed, such as worsening, improving, or no change
     */
    changePattern?: CodeableConcept;
    /**
     * Reference to a specific published clinical protocol that was followed during this assessment, and/or that provides evidence in support of the diagnosis.
     *
     * Clinical Protocol followed
     */
    protocol?: string[];
    /**
     * Captures the reason for the current state of the ClinicalImpression.
     *
     * Reason for current status
     */
    statusReason?: CodeableConcept;
    /**
     * A list of the relevant problems/conditions for a patient.
     *
     * Relevant impressions of patient state
     */
    problem?: Condition[] | AllergyIntolerance[] | Reference[];
    /**
     * Estimate of likely outcome.
     *
     * Estimate of likely outcome
     */
    prognosisCodeableConcept?: CodeableConcept[];
    /**
     * The point in time or period over which the subject was assessed.
     *
     * Time of assessment
     */
    effective?: Date | Period;
    /**
     * Information supporting the clinical impression, which can contain investigation results.
     *
     * Information supporting the clinical impression
     */
    supportingInfo?: Reference[];
    /**
     * The Encounter during which this ClinicalImpression was created or to which the creation of this record is tightly associated.
     *
     * The Encounter during which this ClinicalImpression was created
     */
    encounter?: Encounter | Reference;
    /**
     * A summary of the context and/or cause of the assessment - why / where it was performed, and what patient events/status prompted it.
     *
     * Why/how the assessment was performed
     */
    description?: string;
    /**
     * RiskAssessment expressing likely outcome.
     *
     * RiskAssessment expressing likely outcome
     */
    prognosisReference?: RiskAssessment[] | Reference[];
    /**
     * Specific findings or diagnoses that were considered likely or relevant to ongoing treatment.
     *
     * Possible or likely findings and diagnoses
     */
    finding?: ClinicalImpression.ClinicalImpressionFindingComponent[];
    /**
     * The clinician performing the assessment.
     *
     * The clinician performing the assessment
     */
    performer?: Practitioner | PractitionerRole | Reference;
    /**
     * Indicates when the documentation of the assessment was complete.
     *
     * When the assessment was documented
     */
    date?: Date;
    /**
     * A text summary of the investigations and the diagnosis.
     *
     * Summary of the assessment
     */
    summary?: string;
    /**
     * Business identifiers assigned to this clinical impression by the performer or other systems which remain constant as the resource is updated and propagates from server to server.
     *
     * Business identifier
     */
    identifier?: Identifier[];
    /**
     * Commentary about the impression, typically recorded after the impression itself was made, though supplemental notes by the original author could also appear.
     *
     * Comments made about the ClinicalImpression
     */
    note?: Annotation[];
    /**
     * The patient or group of individuals assessed as part of this record.
     *
     * Patient or group assessed
     */
    subject: Patient | Group | Reference;
    /**
     * A reference to the last assessment that was conducted on this patient. Assessments are often/usually ongoing in nature; a care provider (practitioner or team) will make new assessments on an ongoing basis as new data arises or the patient's conditions changes.
     *
     * Reference to last assessment
     */
    previous?: ClinicalImpression | Reference;
    readonly resourceType: string;
    static revive(json: any): ClinicalImpression;
    toJSON(): any;
}
export declare namespace ClinicalImpression {
    enum EventStatus {
        NOTDONE,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ONHOLD,
        STOPPED,
        INPROGRESS,
        UNKNOWN,
        PREPARATION
    }
    class ClinicalImpressionFindingComponent extends BackboneElement {
        /**
         * Which investigations support finding or diagnosis.
         *
         * Which investigations support finding
         */
        basis?: string;
        /**
         * Specific text, code or reference for finding or diagnosis, which may include ruled-out or resolved conditions.
         *
         * What was found
         */
        item?: CodeableReference;
        static revive(json: any): ClinicalImpressionFindingComponent;
        toJSON(): any;
    }
}
