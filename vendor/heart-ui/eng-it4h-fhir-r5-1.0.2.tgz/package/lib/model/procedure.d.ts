import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Age } from '../datatype/age';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Range } from '../datatype/range';
import { Timing } from '../datatype/timing';
import { CarePlan } from '../model/care-plan';
import { CareTeam } from '../model/care-team';
import { Composition } from '../model/composition';
import { Device } from '../model/device';
import { DiagnosticReport } from '../model/diagnostic-report';
import { DocumentReference } from '../model/document-reference';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { Location } from '../model/location';
import { MedicationAdministration } from '../model/medication-administration';
import { Observation } from '../model/observation';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
import { ServiceRequest } from '../model/service-request';
import { Specimen } from '../model/specimen';
/**
 * HAPI/FHIR <b>Procedure</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Procedure">http://hl7.org/fhir/StructureDefinition/Procedure</a>
 * </p>
 *
 */
export declare class Procedure extends DomainResource {
    /**
     * The location where the procedure actually happened.  E.g. a newborn at home, a tracheostomy at a restaurant.
     *
     * Where the procedure happened
     */
    location?: Location | Reference;
    /**
     * This could be a histology result, pathology report, surgical report, etc.
     *
     * Any report resulting from the procedure
     */
    report?: DiagnosticReport[] | DocumentReference[] | Composition[] | Reference[];
    /**
     * A code specifying the state of the procedure. Generally, this will be the in-progress or completed state.
     *
     * preparation | in-progress | not-done | on-hold | stopped | completed | entered-in-error | unknown
     */
    status: string;
    /**
     * A code that classifies the procedure for searching, sorting and display purposes (e.g. "Surgical Procedure").
     *
     * Classification of the procedure
     */
    category?: CodeableConcept[];
    /**
     * Detailed and structured anatomical location information. Multiple locations are allowed - e.g. multiple punch biopsies of a lesion.
     *
     * Target body sites
     */
    bodySite?: CodeableConcept[];
    /**
     * A device that is implanted, removed or otherwise manipulated (calibration, battery replacement, fitting a prosthesis, attaching a wound-vac, etc.) as a focal portion of the Procedure.
     *
     * Manipulated, implanted, or removed device
     */
    focalDevice?: Procedure.ProcedureFocalDeviceComponent[];
    /**
     * The Encounter during which this Procedure was created or performed or to which the creation of this record is tightly associated.
     *
     * The Encounter during which this Procedure was created
     */
    encounter?: Encounter | Reference;
    /**
     * The URL pointing to a FHIR-defined protocol, guideline, order set or other definition that is adhered to in whole or in part by this Procedure.
     *
     * Instantiates FHIR protocol or definition
     */
    instantiatesCanonical?: string[];
    /**
     * The date the occurrence of the procedure was first captured in the record regardless of Procedure.status (potentially after the occurrence of the event).
     *
     * When the procedure was first captured in the subject's record
     */
    recorded?: Date;
    /**
     * Individual who recorded the record and takes responsibility for its content.
     *
     * Who recorded the procedure
     */
    recorder?: Patient | RelatedPerson | Practitioner | PractitionerRole | Reference;
    /**
     * Indicates who or what performed the procedure and how they were involved.
     *
     * Who performed the procedure and what they did
     */
    performer?: Procedure.ProcedurePerformerComponent[];
    /**
     * Business identifiers assigned to this procedure by the performer or other systems which remain constant as the resource is updated and is propagated from server to server.
     *
     * External Identifiers for this procedure
     */
    identifier?: Identifier[];
    /**
     * Indicates if this record was captured as a secondary 'reported' record rather than as an original primary source-of-truth record.  It may also indicate the source of the report.
     *
     * Reported rather than primary record
     */
    reported?: boolean | Patient | RelatedPerson | Practitioner | PractitionerRole | Organization | Reference;
    /**
     * A reference to a resource that contains details of the request for this procedure.
     *
     * A request for this procedure
     */
    basedOn?: CarePlan[] | ServiceRequest[] | Reference[];
    /**
     * The outcome of the procedure - did it resolve the reasons for the procedure being performed?
     *
     * The result of procedure
     */
    outcome?: CodeableConcept;
    /**
     * Captures the reason for the current state of the procedure.
     *
     * Reason for current status
     */
    statusReason?: CodeableConcept;
    /**
     * If the procedure required specific follow up - e.g. removal of sutures. The follow up may be represented as a simple note or could potentially be more complex, in which case the CarePlan resource can be used.
     *
     * Instructions for follow up
     */
    followUp?: CodeableConcept[];
    /**
     * Other resources from the patient record that may be relevant to the procedure.  The information from these resources was either used to create the instance or is provided to help with its interpretation. This extension should not be used if more specific inline elements or extensions are available.
     *
     * Extra information relevant to the procedure
     */
    supportingInfo?: Reference[];
    /**
     * Estimated or actual date, date-time, period, or age when the procedure did occur or is occurring.  Allows a period to support complex procedures that span more than one date, and also allows for the length of the procedure to be captured.
     *
     * When the procedure occurred or is occurring
     */
    occurrence?: Date | Period | string | Age | Range | Timing;
    /**
     * Identifies medications, devices and any other substance used as part of the procedure.
     *
     * Items used during procedure
     */
    used?: CodeableReference[];
    /**
     * Who is the target of the procedure when it is not the subject of record only.  If focus is not present, then subject is the focus.  If focus is present and the subject is one of the targets of the procedure, include subject as a focus as well. If focus is present and the subject is not included in focus, it implies that the procedure was only targeted on the focus. For example, when a caregiver is given education for a patient, the caregiver would be the focus and the procedure record is associated with the subject (e.g. patient).  For example, use focus when recording the target of the education, training, or counseling is the parent or relative of a patient.
     *
     * Who is the target of the procedure when it is not the subject of record only
     */
    focus?: Patient | Group | RelatedPerson | Practitioner | Organization | CareTeam | PractitionerRole | Specimen | Reference;
    /**
     * The URL pointing to an externally maintained protocol, guideline, order set or other definition that is adhered to in whole or in part by this Procedure.
     *
     * Instantiates external protocol or definition
     */
    instantiatesUri?: string[];
    /**
     * Any complications that occurred during the procedure, or in the immediate post-performance period. These are generally tracked separately from the notes, which will typically describe the procedure itself rather than any 'post procedure' issues.
     *
     * Complication following the procedure
     */
    complication?: CodeableReference[];
    /**
     * The specific procedure that is performed. Use text if the exact nature of the procedure cannot be coded (e.g. "Laparoscopic Appendectomy").
     *
     * Identification of the procedure
     */
    code?: CodeableConcept;
    /**
     * A larger event of which this particular procedure is a component or step.
     *
     * Part of referenced event
     */
    partOf?: Procedure[] | Observation[] | MedicationAdministration[] | Reference[];
    /**
     * The coded reason or reference why the procedure was performed. This may be a coded entity of some type, be present as text, or be a reference to one of several resources that justify the procedure.
     *
     * The justification that the procedure was performed
     */
    reason?: CodeableReference[];
    /**
     * Any other notes and comments about the procedure.
     *
     * Additional information about the procedure
     */
    note?: Annotation[];
    /**
     * On whom or on what the procedure was performed. This is usually an individual human, but can also be performed on animals, groups of humans or animals, organizations or practitioners (for licensing), locations or devices (for safety inspections or regulatory authorizations).  If the actual focus of the procedure is different from the subject, the focus element specifies the actual focus of the procedure.
     *
     * Individual or entity the procedure was performed on
     */
    subject: Patient | Group | Device | Practitioner | Organization | Location | Reference;
    readonly resourceType: string;
    static revive(json: any): Procedure;
    toJSON(): any;
}
export declare namespace Procedure {
    enum EventStatus {
        NOTDONE,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ONHOLD,
        STOPPED,
        INPROGRESS,
        UNKNOWN,
        PREPARATION
    }
    class ProcedureFocalDeviceComponent extends BackboneElement {
        /**
         * The device that was manipulated (changed) during the procedure.
         *
         * Device that was changed
         */
        manipulated: Device | Reference;
        /**
         * The kind of change that happened to the device during the procedure.
         *
         * Kind of change to device
         */
        action?: CodeableConcept;
        static revive(json: any): ProcedureFocalDeviceComponent;
        toJSON(): any;
    }
    class ProcedurePerformerComponent extends BackboneElement {
        /**
         * The Organization the Patient, RelatedPerson, Device, CareTeam, and HealthcareService was acting on behalf of.
         *
         * Organization the device or practitioner was acting for
         */
        onBehalfOf?: Organization | Reference;
        /**
         * Indicates who or what performed the procedure.
         *
         * Who performed the procedure
         */
        actor: Practitioner | PractitionerRole | Organization | Patient | RelatedPerson | Device | CareTeam | HealthcareService | Reference;
        /**
         * Time period during which the performer performed the procedure.
         *
         * When the performer performed the procedure
         */
        period?: Period;
        /**
         * Distinguishes the type of involvement of the performer in the procedure. For example, surgeon, anaesthetist, endoscopist.
         *
         * Type of performance
         */
        function?: CodeableConcept;
        static revive(json: any): ProcedurePerformerComponent;
        toJSON(): any;
    }
}
