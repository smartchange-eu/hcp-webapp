import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { MarketingStatus } from '../datatype/marketing-status';
import { ProductShelfLife } from '../datatype/product-shelf-life';
import { Quantity } from '../datatype/quantity';
import { DocumentReference } from '../model/document-reference';
import { DomainResource } from '../model/domain-resource';
import { MedicinalProductDefinition } from '../model/medicinal-product-definition';
import { Organization } from '../model/organization';
/**
 * HAPI/FHIR <b>PackagedProductDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/PackagedProductDefinition">http://hl7.org/fhir/StructureDefinition/PackagedProductDefinition</a>
 * </p>
 *
 */
export declare class PackagedProductDefinition extends DomainResource {
    /**
     * A high level category e.g. medicinal product, raw material, shipping/transport container, etc.
     *
     * A high level category e.g. medicinal product, raw material, shipping container etc
     */
    type?: CodeableConcept;
    /**
     * Allows the key features to be recorded, such as "hospital pack", "nurse prescribable", "calendar pack".
     *
     * Allows the key features to be recorded, such as "hospital pack", "nurse prescribable"
     */
    characteristic?: PackagedProductDefinition.PackagedProductDefinitionPackagingPropertyComponent[];
    /**
     * Allows specifying that an item is on the market for sale, or that it is not available, and the dates and locations associated.
     *
     * Allows specifying that an item is on the market for sale, or that it is not available, and the dates and locations associated
     */
    marketingStatus?: MarketingStatus[];
    /**
     * Manufacturer of this package type. When there are multiple it means these are all possible manufacturers.
     *
     * Manufacturer of this package type (multiple means these are all possible manufacturers)
     */
    manufacturer?: Organization[] | Reference[];
    /**
     * Textual description. Note that this is not the name of the package or product.
     *
     * Textual description. Note that this is not the name of the package or product
     */
    description?: string;
    /**
     * A packaging item, as a container for medically related items, possibly with other packaging items within, or a packaging component, such as bottle cap (which is not a device or a medication manufactured item).
     *
     * A packaging item, as a container for medically related items, possibly with other packaging items within, or a packaging component, such as bottle cap
     */
    packaging?: PackagedProductDefinition.PackagedProductDefinitionPackagingComponent;
    /**
     * A total of the complete count of contained items of a particular type/form, independent of sub-packaging or organization. This can be considered as the pack size. This attribute differs from containedItem.amount in that it can give a single aggregated count of all tablet types in a pack, even when these are different manufactured items. For example a pill pack of 21 tablets plus 7 sugar tablets, can be denoted here as '28 tablets'. This attribute is repeatable so that the different item types in one pack type can be counted (e.g. a count of vials and count of syringes). Each repeat must have different units, so that it is clear what the different sets of counted items are, and it is not intended to allow different counts of similar items (e.g. not '2 tubes and 3 tubes'). Repeats are not to be used to represent different pack sizes (e.g. 20 pack vs. 50 pack) - which would be different instances of this resource.
     *
     * A total of the complete count of contained items of a particular type/form, independent of sub-packaging or organization. This can be considered as the pack size. See also packaging.containedItem.amount (especially the long definition)
     */
    containedItemQuantity?: Quantity[];
    /**
     * The date at which the given status became applicable.
     *
     * The date at which the given status became applicable
     */
    statusDate?: Date;
    /**
     * A unique identifier for this package as whole - not the the content of the package. Unique instance identifiers assigned to a package by manufacturers, regulators, drug catalogue custodians or other organizations.
     *
     * A unique identifier for this package as whole - not for the content of the package
     */
    identifier?: Identifier[];
    /**
     * Additional information or supporting documentation about the packaged product.
     *
     * Additional information or supporting documentation about the packaged product
     */
    attachedDocument?: DocumentReference[] | Reference[];
    /**
     * The product this package model relates to, not the contents of the package (for which see package.containedItem).
     *
     * The product that this is a pack for
     */
    packageFor?: MedicinalProductDefinition[] | Reference[];
    /**
     * The status within the lifecycle of this item. A high level status, this is not intended to duplicate details carried elsewhere such as legal status, or authorization or marketing status.
     *
     * The status within the lifecycle of this item. High level - not intended to duplicate details elsewhere e.g. legal status, or authorization/marketing status
     */
    status?: CodeableConcept;
    /**
     * A name for this package. Typically what it would be listed as in a drug formulary or catalogue, inventory etc.
     *
     * A name for this package. Typically as listed in a drug formulary, catalogue, inventory etc
     */
    name?: string;
    /**
     * The legal status of supply of the packaged item as classified by the regulator.
     *
     * The legal status of supply of the packaged item as classified by the regulator
     */
    legalStatusOfSupply?: PackagedProductDefinition.PackagedProductDefinitionLegalStatusOfSupplyComponent[];
    /**
     * Identifies if the package contains different items, such as when a drug product is supplied with another item e.g. a diluent or adjuvant.
     *
     * Identifies if the drug product is supplied with another item such as a diluent or adjuvant
     */
    copackagedIndicator?: boolean;
    readonly resourceType: string;
    static revive(json: any): PackagedProductDefinition;
    toJSON(): any;
}
export declare namespace PackagedProductDefinition {
    class PackagedProductDefinitionPackagingContainedItemComponent extends BackboneElement {
        /**
         * The actual item(s) of medication, as manufactured, or a device (typically, but not necessarily, a co-packaged one), or other medically related item (such as food, biologicals, raw materials, medical fluids, gases etc.), as contained in the package. This also allows another whole packaged product to be included, which is solely for the case where a package of other entire packages is wanted - such as a wholesale or distribution pack (for layers within one package, use PackagedProductDefinition.packaging.packaging).
         *
         * The actual item(s) of medication, as manufactured, or a device, or other medically related item (food, biologicals, raw materials, medical fluids, gases etc.), as contained in the package
         */
        item: CodeableReference;
        /**
         * The number of this type of item within this packaging or for continuous items such as liquids it is the quantity (for example 25ml). See also PackagedProductDefinition.containedItemQuantity (especially the long definition).
         *
         * The number of this type of item within this packaging or for continuous items such as liquids it is the quantity (for example 25ml). See also PackagedProductDefinition.containedItemQuantity (especially the long definition)
         */
        amount?: Quantity;
        static revive(json: any): PackagedProductDefinitionPackagingContainedItemComponent;
        toJSON(): any;
    }
    class PackagedProductDefinitionPackagingPropertyComponent extends BackboneElement {
        /**
         * A value for the characteristic.
         *
         * A value for the characteristic
         */
        value?: CodeableConcept | Quantity | Date | boolean | Attachment;
        /**
         * A code expressing the type of characteristic.
         *
         * A code expressing the type of characteristic
         */
        type: CodeableConcept;
        static revive(json: any): PackagedProductDefinitionPackagingPropertyComponent;
        toJSON(): any;
    }
    class PackagedProductDefinitionPackagingComponent extends BackboneElement {
        /**
         * General characteristics of this item.
         *
         * General characteristics of this item
         */
        property?: PackagedProductDefinition.PackagedProductDefinitionPackagingPropertyComponent[];
        /**
         * Allows containers (and parts of containers) within containers, still as a part of a single packaged product. See also PackagedProductDefinition.packaging.containedItem.item(PackagedProductDefinition).
         *
         * Allows containers (and parts of containers) within containers, still as a part of single packaged product
         */
        packaging?: PackagedProductDefinition.PackagedProductDefinitionPackagingComponent[];
        /**
         * The physical type of the container of the items.
         *
         * The physical type of the container of the items
         */
        type?: CodeableConcept;
        /**
         * A possible alternate material for this part of the packaging, that is allowed to be used instead of the usual material (e.g. different types of plastic for a blister sleeve).
         *
         * A possible alternate material for this part of the packaging, that is allowed to be used instead of the usual material
         */
        alternateMaterial?: CodeableConcept[];
        /**
         * Manufacturer of this packaging item. When there are multiple values each one is a potential manufacturer of this packaging item.
         *
         * Manufacturer of this packaging item (multiple means these are all potential manufacturers)
         */
        manufacturer?: Organization[] | Reference[];
        /**
         * A business identifier that is specific to this particular part of the packaging, often assigned by the manufacturer. Including possibly Data Carrier Identifier (a GS1 barcode).
         *
         * An identifier that is specific to this particular part of the packaging. Including possibly a Data Carrier Identifier
         */
        identifier?: Identifier[];
        /**
         * The quantity of packaging items contained at this layer of the package. This does not relate to the number of contained items but relates solely to the number of packaging items. When looking at the outermost layer it is always 1. If there are two boxes within, at the next layer it would be 2.
         *
         * The quantity of this level of packaging in the package that contains it (with the outermost level being 1)
         */
        quantity?: number;
        /**
         * Is this a part of the packaging (e.g. a cap or bottle stopper), rather than the packaging itself (e.g. a bottle or vial). The latter type are designed be a container, but the former are not.
         *
         * Is this a part of the packaging (e.g. a cap or bottle stopper), rather than the packaging itself (e.g. a bottle or vial)
         */
        componentPart?: boolean;
        /**
         * Material type of the package item.
         *
         * Material type of the package item
         */
        material?: CodeableConcept[];
        /**
         * Shelf Life and storage information.
         *
         * Shelf Life and storage information
         */
        shelfLifeStorage?: ProductShelfLife[];
        /**
         * The item(s) within the packaging.
         *
         * The item(s) within the packaging
         */
        containedItem?: PackagedProductDefinition.PackagedProductDefinitionPackagingContainedItemComponent[];
        static revive(json: any): PackagedProductDefinitionPackagingComponent;
        toJSON(): any;
    }
    class PackagedProductDefinitionLegalStatusOfSupplyComponent extends BackboneElement {
        /**
         * The actual status of supply. Conveys in what situation this package type may be supplied for use.
         *
         * The actual status of supply. In what situation this package type may be supplied for use
         */
        code?: CodeableConcept;
        /**
         * The place where the legal status of supply applies. When not specified, this indicates it is unknown in this context.
         *
         * The place where the legal status of supply applies
         */
        jurisdiction?: CodeableConcept;
        static revive(json: any): PackagedProductDefinitionLegalStatusOfSupplyComponent;
        toJSON(): any;
    }
}
