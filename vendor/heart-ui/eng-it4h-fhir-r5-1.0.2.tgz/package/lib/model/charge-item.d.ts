import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { MonetaryComponent } from '../datatype/monetary-component';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Timing } from '../datatype/timing';
import { Account } from '../model/account';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>ChargeItem</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ChargeItem">http://hl7.org/fhir/StructureDefinition/ChargeItem</a>
 * </p>
 *
 */
export declare class ChargeItem extends DomainResource {
    /**
     * The financial cost center permits the tracking of charge attribution.
     *
     * Organization that has ownership of the (potential, future) revenue
     */
    costCenter?: Organization | Reference;
    /**
     * Date the charge item was entered.
     *
     * Date the charge item was entered
     */
    enteredDate?: Date;
    /**
     * Identifies the device, food, drug or other product being charged either by type code or reference to an instance.
     *
     * Product charged
     */
    product?: CodeableReference[];
    /**
     * Indicates who or what performed or participated in the charged service.
     *
     * Who performed charged service
     */
    performer?: ChargeItem.ChargeItemPerformerComponent[];
    /**
     * Quantity of which the charge item has been serviced.
     *
     * Quantity of which the charge item has been serviced
     */
    quantity?: Quantity;
    /**
     * The anatomical location where the related service has been applied.
     *
     * Anatomical location, if relevant
     */
    bodysite?: CodeableConcept[];
    /**
     * Identifiers assigned to this event performer or other systems.
     *
     * Business Identifier for item
     */
    identifier?: Identifier[];
    /**
     * The total price for the chargable item, accounting for the quantity.
     *
     * Total price overriding the associated rules
     */
    totalPriceComponent?: MonetaryComponent;
    /**
     * This ChargeItem has the details of how the associated Encounter should be billed or otherwise be handled by finance systems.
     *
     * Encounter associated with this ChargeItem
     */
    encounter?: Encounter | Reference;
    /**
     * Further information supporting this charge.
     *
     * Further information supporting this charge
     */
    supportingInformation?: Reference[];
    /**
     * Indicated the rendered service that caused this charge.
     *
     * Which rendered service is being charged?
     */
    service?: CodeableReference[];
    /**
     * Account into which this ChargeItems belongs.
     *
     * Account to place this charge
     */
    account?: Account[] | Reference[];
    /**
     * The current state of the ChargeItem.
     *
     * planned | billable | not-billable | aborted | billed | entered-in-error | unknown
     */
    status: string;
    /**
     * The organization requesting the service.
     *
     * Organization requesting the charged service
     */
    requestingOrganization?: Organization | Reference;
    /**
     * The individual or set of individuals the action is being or was performed on.
     *
     * Individual service was done for/to
     */
    subject: Patient | Group | Reference;
    /**
     * References the source of pricing information, rules of application for the code this ChargeItem uses.
     *
     * Resource defining the code of this ChargeItem
     */
    definitionCanonical?: string[];
    /**
     * The unit price of the chargable item.
     *
     * Unit price overriding the associated rules
     */
    unitPriceComponent?: MonetaryComponent;
    /**
     * A code that identifies the charge, like a billing code.
     *
     * A code that identifies the charge, like a billing code
     */
    code: CodeableConcept;
    /**
     * ChargeItems can be grouped to larger ChargeItems covering the whole set.
     *
     * Part of referenced ChargeItem
     */
    partOf?: ChargeItem[] | Reference[];
    /**
     * Describes why the event occurred in coded or textual form.
     *
     * Why was the charged  service rendered?
     */
    reason?: CodeableConcept[];
    /**
     * Comments made about the event by the performer, subject or other participants.
     *
     * Comments made about the ChargeItem
     */
    note?: Annotation[];
    /**
     * References the (external) source of pricing information, rules of application for the code this ChargeItem uses.
     *
     * Defining information about the code of this charge item
     */
    definitionUri?: string[];
    /**
     * Date/time(s) or duration when the charged service was applied.
     *
     * When the charged service was applied
     */
    occurrence?: Date | Period | Timing;
    /**
     * If the list price or the rule-based factor associated with the code is overridden, this attribute can capture a text to indicate the  reason for this action.
     *
     * Reason for overriding the list price/factor
     */
    overrideReason?: CodeableConcept;
    /**
     * The organization performing the service.
     *
     * Organization providing the charged service
     */
    performingOrganization?: Organization | Reference;
    /**
     * The device, practitioner, etc. who entered the charge item.
     *
     * Individual who was entering
     */
    enterer?: Practitioner | PractitionerRole | Organization | Patient | Device | RelatedPerson | Reference;
    readonly resourceType: string;
    static revive(json: any): ChargeItem;
    toJSON(): any;
}
export declare namespace ChargeItem {
    enum ChargeItemStatus {
        ENTEREDINERROR,
        BILLABLE,
        NULL,
        NOTBILLABLE,
        ABORTED,
        UNKNOWN,
        BILLED,
        PLANNED
    }
    class ChargeItemPerformerComponent extends BackboneElement {
        /**
         * The device, practitioner, etc. who performed or participated in the service.
         *
         * Individual who was performing
         */
        actor: Practitioner | PractitionerRole | Organization | HealthcareService | CareTeam | Patient | Device | RelatedPerson | Reference;
        /**
         * Describes the type of performance or participation(e.g. primary surgeon, anesthesiologiest, etc.).
         *
         * What type of performance was done
         */
        function?: CodeableConcept;
        static revive(json: any): ChargeItemPerformerComponent;
        toJSON(): any;
    }
}
