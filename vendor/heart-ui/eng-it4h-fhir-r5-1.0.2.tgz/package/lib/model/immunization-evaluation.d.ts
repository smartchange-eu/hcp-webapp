import { Reference } from '../datatype/reference';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { DomainResource } from '../model/domain-resource';
import { Immunization } from '../model/immunization';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
/**
 * HAPI/FHIR <b>ImmunizationEvaluation</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ImmunizationEvaluation">http://hl7.org/fhir/StructureDefinition/ImmunizationEvaluation</a>
 * </p>
 *
 */
export declare class ImmunizationEvaluation extends DomainResource {
    /**
     * Provides an explanation as to why the vaccine administration event is valid or not relative to the published recommendations.
     *
     * Reason why the doese is considered valid, invalid or some other status
     */
    doseStatusReason?: CodeableConcept[];
    /**
     * Nominal position in a series as determined by the outcome of the evaluation process.
     *
     * Dose number within series
     */
    doseNumber?: string;
    /**
     * The recommended number of doses to achieve immunity as determined by the outcome of the evaluation process.
     *
     * Recommended number of doses for immunity
     */
    seriesDoses?: string;
    /**
     * Indicates the authority who published the protocol (e.g. ACIP).
     *
     * Who is responsible for publishing the recommendations
     */
    authority?: Organization | Reference;
    /**
     * The individual for whom the evaluation is being done.
     *
     * Who this evaluation is for
     */
    patient: Patient | Reference;
    /**
     * One possible path to achieve presumed immunity against a disease - within the context of an authority.
     *
     * Name of vaccine series
     */
    series?: string;
    /**
     * The vaccine preventable disease the dose is being evaluated against.
     *
     * The vaccine preventable disease schedule being evaluated
     */
    targetDisease: CodeableConcept;
    /**
     * Indicates the current status of the evaluation of the vaccination administration event.
     *
     * completed | entered-in-error
     */
    status: string;
    /**
     * A unique identifier assigned to this immunization evaluation record.
     *
     * Business identifier
     */
    identifier?: Identifier[];
    /**
     * The date the evaluation of the vaccine administration event was performed.
     *
     * Date evaluation was performed
     */
    date?: Date;
    /**
     * Indicates if the dose is valid or not valid with respect to the published recommendations.
     *
     * Status of the dose relative to published recommendations
     */
    doseStatus: CodeableConcept;
    /**
     * Additional information about the evaluation.
     *
     * Evaluation notes
     */
    description?: string;
    /**
     * The vaccine administration event being evaluated.
     *
     * Immunization being evaluated
     */
    immunizationEvent: Immunization | Reference;
    readonly resourceType: string;
    static revive(json: any): ImmunizationEvaluation;
    toJSON(): any;
}
export declare namespace ImmunizationEvaluation {
    enum ImmunizationEvaluationStatusCodes {
        ENTEREDINERROR,
        COMPLETED,
        NULL
    }
}
