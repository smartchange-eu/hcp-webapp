import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { BiologicallyDerivedProduct } from '../model/biologically-derived-product';
import { Device } from '../model/device';
import { DocumentReference } from '../model/document-reference';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { NutritionProduct } from '../model/nutrition-product';
import { Observation } from '../model/observation';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Procedure } from '../model/procedure';
import { ServiceRequest } from '../model/service-request';
import { Specimen } from '../model/specimen';
import { Substance } from '../model/substance';
import { Task } from '../model/task';
/**
 * HAPI/FHIR <b>GenomicStudy</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/GenomicStudy">http://hl7.org/fhir/StructureDefinition/GenomicStudy</a>
 * </p>
 *
 */
export declare class GenomicStudy extends DomainResource {
    /**
     * When the genomic study was started.
     *
     * When the genomic study was started
     */
    startDate?: Date;
    /**
     * Event resources that the genomic study is based on.
     *
     * Event resources that the genomic study is based on
     */
    basedOn?: ServiceRequest[] | Task[] | Reference[];
    /**
     * The status of the genomic study.
     *
     * registered | available | cancelled | entered-in-error | unknown
     */
    status: string;
    /**
     * Healthcare professional who requested or referred the genomic study.
     *
     * Healthcare professional who requested or referred the genomic study
     */
    referrer?: Practitioner | PractitionerRole | Reference;
    /**
     * Healthcare professionals who interpreted the genomic study.
     *
     * Healthcare professionals who interpreted the genomic study
     */
    interpreter?: Practitioner[] | PractitionerRole[] | Reference[];
    /**
     * The healthcare event with which this genomics study is associated.
     *
     * The healthcare event with which this genomics study is associated
     */
    encounter?: Encounter | Reference;
    /**
     * Description of the genomic study.
     *
     * Description of the genomic study
     */
    description?: string;
    /**
     * The URL pointing to an externally maintained protocol that describes the study.
     *
     * The URL pointing to an externally maintained protocol that describes the study
     */
    instantiatesUri?: string;
    /**
     * The type of the study, e.g., Familial variant segregation, Functional variation detection, or Gene expression profiling.
     *
     * The type of the study (e.g., Familial variant segregation, Functional variation detection, or Gene expression profiling)
     */
    type?: CodeableConcept[];
    /**
     * The defined protocol that describes the study.
     *
     * The defined protocol that describes the study
     */
    instantiatesCanonical?: string;
    /**
     * The details about a specific analysis that was performed in this GenomicStudy.
     *
     * Genomic Analysis Event
     */
    analysis?: GenomicStudy.GenomicStudyAnalysisComponent[];
    /**
     * Identifiers for this genomic study.
     *
     * Identifiers for this genomic study
     */
    identifier?: Identifier[];
    /**
     * Why the genomic study was performed.
     *
     * Why the genomic study was performed
     */
    reason?: CodeableReference[];
    /**
     * Comments related to the genomic study.
     *
     * Comments related to the genomic study
     */
    note?: Annotation[];
    /**
     * The primary subject of the genomic study.
     *
     * The primary subject of the genomic study
     */
    subject: Patient | Group | Substance | BiologicallyDerivedProduct | NutritionProduct | Reference;
    readonly resourceType: string;
    static revive(json: any): GenomicStudy;
    toJSON(): any;
}
export declare namespace GenomicStudy {
    enum GenomicStudyStatus {
        AVAILABLE,
        CANCELLED,
        ENTEREDINERROR,
        NULL,
        REGISTERED,
        UNKNOWN
    }
    class GenomicStudyAnalysisDeviceComponent extends BackboneElement {
        /**
         * Device used for the analysis.
         *
         * Device used for the analysis
         */
        device?: Device | Reference;
        /**
         * Specific function for the device used for the analysis.
         *
         * Specific function for the device used for the analysis
         */
        function?: CodeableConcept;
        static revive(json: any): GenomicStudyAnalysisDeviceComponent;
        toJSON(): any;
    }
    class GenomicStudyAnalysisPerformerComponent extends BackboneElement {
        /**
         * The organization, healthcare professional, or others who participated in performing this analysis.
         *
         * The organization, healthcare professional, or others who participated in performing this analysis
         */
        actor?: Practitioner | PractitionerRole | Organization | Device | Reference;
        /**
         * Role of the actor for this analysis.
         *
         * Role of the actor for this analysis
         */
        role?: CodeableConcept;
        static revive(json: any): GenomicStudyAnalysisPerformerComponent;
        toJSON(): any;
    }
    class GenomicStudyAnalysisOutputComponent extends BackboneElement {
        /**
         * Type of output data, e.g., VCF, MAF, or BAM.
         *
         * Type of output data (e.g., VCF, MAF, or BAM)
         */
        type?: CodeableConcept;
        /**
         * File containing output data.
         *
         * File containing output data
         */
        file?: DocumentReference | Reference;
        static revive(json: any): GenomicStudyAnalysisOutputComponent;
        toJSON(): any;
    }
    class GenomicStudyAnalysisInputComponent extends BackboneElement {
        /**
         * Type of input data, e.g., BAM, CRAM, or FASTA.
         *
         * Type of input data (e.g., BAM, CRAM, or FASTA)
         */
        type?: CodeableConcept;
        /**
         * The analysis event or other GenomicStudy that generated this input file.
         *
         * The analysis event or other GenomicStudy that generated this input file
         */
        generatedBy?: Identifier | GenomicStudy | Reference;
        /**
         * File containing input data.
         *
         * File containing input data
         */
        file?: DocumentReference | Reference;
        static revive(json: any): GenomicStudyAnalysisInputComponent;
        toJSON(): any;
    }
    class GenomicStudyAnalysisComponent extends BackboneElement {
        /**
         * The protocol that was performed for the analysis event.
         *
         * The protocol that was performed for the analysis event
         */
        protocolPerformed?: Procedure | Task | Reference;
        /**
         * Devices used for the analysis (e.g., instruments, software), with settings and parameters.
         *
         * Devices used for the analysis (e.g., instruments, software), with settings and parameters
         */
        device?: GenomicStudy.GenomicStudyAnalysisDeviceComponent[];
        /**
         * Type of the methods used in the analysis, e.g., Fluorescence in situ hybridization (FISH), Karyotyping, or Microsatellite instability testing (MSI).
         *
         * Type of the methods used in the analysis (e.g., FISH, Karyotyping, MSI)
         */
        methodType?: CodeableConcept[];
        /**
         * Outputs for the analysis event.
         *
         * Outputs for the analysis event
         */
        output?: GenomicStudy.GenomicStudyAnalysisOutputComponent[];
        /**
         * Inputs for the analysis event.
         *
         * Inputs for the analysis event
         */
        input?: GenomicStudy.GenomicStudyAnalysisInputComponent[];
        /**
         * The reference genome build that is used in this analysis.
         *
         * Genome build that is used in this analysis
         */
        genomeBuild?: CodeableConcept;
        /**
         * Genomic regions actually called in the analysis event (BED file).
         *
         * Genomic regions actually called in the analysis event (BED file)
         */
        regionsCalled?: DocumentReference[] | Observation[] | Reference[];
        /**
         * The specimen used in the analysis event.
         *
         * The specimen used in the analysis event
         */
        specimen?: Specimen[] | Reference[];
        /**
         * The focus of a genomic analysis when it is not the patient of record representing something or someone associated with the patient such as a spouse, parent, child, or sibling. For example, in trio testing, the GenomicStudy.subject would be the child (proband) and the GenomicStudy.analysis.focus of a specific analysis would be the parent.
         *
         * What the genomic analysis is about, when it is not about the subject of record
         */
        focus?: Reference[];
        /**
         * The URL pointing to an externally maintained protocol that describes the analysis.
         *
         * The URL pointing to an externally maintained protocol that describes the analysis
         */
        instantiatesUri?: string;
        /**
         * The defined protocol that describes the analysis.
         *
         * The defined protocol that describes the analysis
         */
        instantiatesCanonical?: string;
        /**
         * Name of the analysis event (human friendly).
         *
         * Name of the analysis event (human friendly)
         */
        title?: string;
        /**
         * The genomic regions to be studied in the analysis (BED file).
         *
         * The genomic regions to be studied in the analysis (BED file)
         */
        regionsStudied?: DocumentReference[] | Observation[] | Reference[];
        /**
         * Performer for the analysis event.
         *
         * Performer for the analysis event
         */
        performer?: GenomicStudy.GenomicStudyAnalysisPerformerComponent[];
        /**
         * The date of the analysis event.
         *
         * The date of the analysis event
         */
        date?: Date;
        /**
         * Identifiers for the analysis event.
         *
         * Identifiers for the analysis event
         */
        identifier?: Identifier[];
        /**
         * Any notes capture with the analysis event.
         *
         * Any notes capture with the analysis event
         */
        note?: Annotation[];
        /**
         * Type of the genomic changes studied in the analysis, e.g., DNA, RNA, or amino acid change.
         *
         * Type of the genomic changes studied in the analysis (e.g., DNA, RNA, or AA change)
         */
        changeType?: CodeableConcept[];
        static revive(json: any): GenomicStudyAnalysisComponent;
        toJSON(): any;
    }
}
