import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { UsageContext } from '../datatype/usage-context';
import { CanonicalResource } from '../model/canonical-resource';
/**
 * HAPI/FHIR <b>StructureMap</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/StructureMap">http://hl7.org/fhir/StructureDefinition/StructureMap</a>
 * </p>
 *
 */
export declare class StructureMap extends CanonicalResource {
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the structure map.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * A natural language name identifying the structure map. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this structure map (computer friendly)
     */
    name: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate structure map instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * The status of this structure map. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * Organizes the mapping into managable chunks for human review/ease of maintenance.
     *
     * Named sections for reader convenience
     */
    group: StructureMap.StructureMapGroupComponent[];
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * Other maps used by this map (canonical URLs).
     *
     * Other maps used by this map (canonical URLs)
     */
    import?: string[];
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * A free text natural language description of the structure map from a consumer's perspective.
     *
     * Natural language description of the structure map
     */
    description?: string;
    /**
     * A Boolean value to indicate that this structure map is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * The identifier that is used to identify this version of the structure map when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the structure map author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the structure map
     */
    version?: string;
    /**
     * A short, descriptive, user-friendly title for the structure map.
     *
     * Name for this structure map (human friendly)
     */
    title?: string;
    /**
     * An absolute URI that is used to identify this structure map when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this structure map is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the structure map is stored on different servers.
     *
     * Canonical identifier for this structure map, represented as a URI (globally unique)
     */
    url: string;
    /**
     * A structure definition used by this map. The structure definition may describe instances that are converted, or the instances that are produced.
     *
     * Structure Definition used by this map
     */
    structure?: StructureMap.StructureMapStructureComponent[];
    /**
     * A formal identifier that is used to identify this structure map when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the structure map
     */
    identifier?: Identifier[];
    /**
     * The date  (and optionally time) when the structure map was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the structure map changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * Definition of a constant value used in the map rules.
     *
     * Definition of the constant value used in the map rules
     */
    const?: StructureMap.StructureMapConstComponent[];
    /**
     * A copyright statement relating to the structure map and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the structure map.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * Explanation of why this structure map is needed and why it has been designed as it has.
     *
     * Why this structure map is defined
     */
    purpose?: string;
    /**
     * A legal or geographic region in which the structure map is intended to be used.
     *
     * Intended jurisdiction for structure map (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    readonly resourceType: string;
    static revive(json: any): StructureMap;
    toJSON(): any;
}
export declare namespace StructureMap {
    enum StructureMapTransform {
        CAST,
        CC,
        C,
        NULL,
        CREATE,
        COPY,
        DATEOP,
        APPEND,
        CP,
        ESCAPE,
        EVALUATE,
        TRANSLATE,
        POINTER,
        QTY,
        REFERENCE,
        ID,
        UUID,
        TRUNCATE
    }
    enum StructureMapTargetListMode {
        SINGLE,
        NULL,
        LAST,
        FIRST,
        SHARE
    }
    enum StructureMapSourceListMode {
        NOTLAST,
        NULL,
        ONLYONE,
        LAST,
        NOTFIRST,
        FIRST
    }
    enum StructureMapModelMode {
        QUERIED,
        TARGET,
        NULL,
        PRODUCED,
        SOURCE
    }
    enum StructureMapInputMode {
        TARGET,
        NULL,
        SOURCE
    }
    enum StructureMapGroupTypeMode {
        TYPES,
        NULL,
        TYPEANDTYPES
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class StructureMapGroupRuleDependentComponent extends BackboneElement {
        /**
         * Name of a rule or group to apply.
         *
         * Name of a rule or group to apply
         */
        name: string;
        /**
         * Parameter to pass to the rule or group.
         *
         * Parameter to pass to the rule or group
         */
        parameter: StructureMap.StructureMapGroupRuleTargetParameterComponent[];
        static revive(json: any): StructureMapGroupRuleDependentComponent;
        toJSON(): any;
    }
    class StructureMapGroupRuleTargetParameterComponent extends BackboneElement {
        /**
         * Parameter value - variable or literal.
         *
         * Parameter value - variable or literal
         */
        value: string | boolean | number | number | Date | Date | Date;
        static revive(json: any): StructureMapGroupRuleTargetParameterComponent;
        toJSON(): any;
    }
    class StructureMapGroupRuleTargetComponent extends BackboneElement {
        /**
         * Field to create in the context.
         *
         * Field to create in the context
         */
        element?: string;
        /**
         * Variable this rule applies to.
         *
         * Variable this rule applies to
         */
        context?: string;
        /**
         * Named context for field, if desired, and a field is specified.
         *
         * Named context for field, if desired, and a field is specified
         */
        variable?: string;
        /**
         * Parameters to the transform.
         *
         * Parameters to the transform
         */
        parameter?: StructureMap.StructureMapGroupRuleTargetParameterComponent[];
        /**
         * If field is a list, how to manage the list.
         *
         * first | share | last | single
         */
        listMode?: string[];
        /**
         * Internal rule reference for shared list items.
         *
         * Internal rule reference for shared list items
         */
        listRuleId?: string;
        /**
         * How the data is copied / created.
         *
         * create | copy +
         */
        transform?: string;
        static revive(json: any): StructureMapGroupRuleTargetComponent;
        toJSON(): any;
    }
    class StructureMapGroupRuleSourceComponent extends BackboneElement {
        /**
         * How to handle the list mode for this element.
         *
         * first | not_first | last | not_last | only_one
         */
        listMode?: string;
        /**
         * FHIRPath expression  - must be true or the rule does not apply.
         *
         * FHIRPath expression  - must be true or the rule does not apply
         */
        condition?: string;
        /**
         * Specified minimum cardinality for the element. This is optional; if present, it acts an implicit check on the input content.
         *
         * Specified minimum cardinality
         */
        min?: number;
        /**
         * Specified maximum cardinality for the element - a number or a "*". This is optional; if present, it acts an implicit check on the input content (* just serves as documentation; it's the default value).
         *
         * Specified maximum cardinality (number or *)
         */
        max?: string;
        /**
         * A value to use if there is no existing value in the source object.
         *
         * Default value if no value exists
         */
        defaultValue?: string;
        /**
         * A FHIRPath expression which specifies a message to put in the transform log when content matching the source rule is found.
         *
         * Message to put in log if source exists (FHIRPath)
         */
        logMessage?: string;
        /**
         * Type or variable this rule applies to.
         *
         * Type or variable this rule applies to
         */
        context: string;
        /**
         * Named context for field, if a field is specified.
         *
         * Named context for field, if a field is specified
         */
        variable?: string;
        /**
         * FHIRPath expression  - must be true or the mapping engine throws an error instead of completing.
         *
         * FHIRPath expression  - must be true or the mapping engine throws an error instead of completing
         */
        check?: string;
        /**
         * Specified type for the element. This works as a condition on the mapping - use for polymorphic elements.
         *
         * Rule only applies if source has this type
         */
        type?: string;
        /**
         * Optional field for this source.
         *
         * Optional field for this source
         */
        element?: string;
        static revive(json: any): StructureMapGroupRuleSourceComponent;
        toJSON(): any;
    }
    class StructureMapGroupRuleComponent extends BackboneElement {
        /**
         * Documentation for this instance of data.
         *
         * Documentation for this instance of data
         */
        documentation?: string;
        /**
         * Rules contained in this rule.
         *
         * Rules contained in this rule
         */
        rule?: StructureMap.StructureMapGroupRuleComponent[];
        /**
         * Name of the rule for internal references.
         *
         * Name of the rule for internal references
         */
        name?: string;
        /**
         * Source inputs to the mapping.
         *
         * Source inputs to the mapping
         */
        source: StructureMap.StructureMapGroupRuleSourceComponent[];
        /**
         * Which other rules to apply in the context of this rule.
         *
         * Which other rules to apply in the context of this rule
         */
        dependent?: StructureMap.StructureMapGroupRuleDependentComponent[];
        /**
         * Content to create because of this mapping rule.
         *
         * Content to create because of this mapping rule
         */
        target?: StructureMap.StructureMapGroupRuleTargetComponent[];
        static revive(json: any): StructureMapGroupRuleComponent;
        toJSON(): any;
    }
    class StructureMapGroupInputComponent extends BackboneElement {
        /**
         * Mode for this instance of data.
         *
         * source | target
         */
        mode: string;
        /**
         * Documentation for this instance of data.
         *
         * Documentation for this instance of data
         */
        documentation?: string;
        /**
         * Name for this instance of data.
         *
         * Name for this instance of data
         */
        name: string;
        /**
         * Type for this instance of data.
         *
         * Type for this instance of data
         */
        type?: string;
        static revive(json: any): StructureMapGroupInputComponent;
        toJSON(): any;
    }
    class StructureMapGroupComponent extends BackboneElement {
        /**
         * Additional supporting documentation that explains the purpose of the group and the types of mappings within it.
         *
         * Additional description/explanation for group
         */
        documentation?: string;
        /**
         * If this is the default rule set to apply for the source type or this combination of types.
         *
         * types | type-and-types
         */
        typeMode?: string;
        /**
         * Another group that this group adds rules to.
         *
         * Another group that this group adds rules to
         */
        extends?: string;
        /**
         * A name assigned to an instance of data. The instance must be provided when the mapping is invoked.
         *
         * Named instance provided when invoking the map
         */
        input: StructureMap.StructureMapGroupInputComponent[];
        /**
         * A unique name for the group for the convenience of human readers.
         *
         * Human-readable label
         */
        name: string;
        /**
         * Transform Rule from source to target.
         *
         * Transform Rule from source to target
         */
        rule?: StructureMap.StructureMapGroupRuleComponent[];
        static revive(json: any): StructureMapGroupComponent;
        toJSON(): any;
    }
    class StructureMapConstComponent extends BackboneElement {
        /**
         * Other maps used by this map (canonical URLs).
         *
         * Constant name
         */
        name?: string;
        /**
         * A FHIRPath expression that is the value of this variable.
         *
         * FHIRPath exression - value of the constant
         */
        value?: string;
        static revive(json: any): StructureMapConstComponent;
        toJSON(): any;
    }
    class StructureMapStructureComponent extends BackboneElement {
        /**
         * The name used for this type in the map.
         *
         * Name for type in this map
         */
        alias?: string;
        /**
         * The canonical reference to the structure.
         *
         * Canonical reference to structure definition
         */
        url: string;
        /**
         * How the referenced structure is used in this mapping.
         *
         * source | queried | target | produced
         */
        mode: string;
        /**
         * Documentation that describes how the structure is used in the mapping.
         *
         * Documentation on use of structure
         */
        documentation?: string;
        static revive(json: any): StructureMapStructureComponent;
        toJSON(): any;
    }
}
