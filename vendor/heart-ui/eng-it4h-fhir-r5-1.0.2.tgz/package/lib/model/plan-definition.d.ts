import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Age } from '../datatype/age';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { DataRequirement } from '../datatype/data-requirement';
import { Duration } from '../datatype/duration';
import { Expression } from '../datatype/expression';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { Ratio } from '../datatype/ratio';
import { RelatedArtifact } from '../datatype/related-artifact';
import { Timing } from '../datatype/timing';
import { TriggerDefinition } from '../datatype/trigger-definition';
import { UsageContext } from '../datatype/usage-context';
import { AdministrableProductDefinition } from '../model/administrable-product-definition';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DeviceDefinition } from '../model/device-definition';
import { Endpoint } from '../model/endpoint';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { Location } from '../model/location';
import { ManufacturedItemDefinition } from '../model/manufactured-item-definition';
import { MedicinalProductDefinition } from '../model/medicinal-product-definition';
import { MetadataResource } from '../model/metadata-resource';
import { Organization } from '../model/organization';
import { PackagedProductDefinition } from '../model/packaged-product-definition';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
import { SubstanceDefinition } from '../model/substance-definition';
/**
 * HAPI/FHIR <b>PlanDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/PlanDefinition">http://hl7.org/fhir/StructureDefinition/PlanDefinition</a>
 * </p>
 *
 */
export declare class PlanDefinition extends MetadataResource {
    /**
     * An individiual or organization primarily involved in the creation and maintenance of the content.
     *
     * Who authored the content
     */
    author?: ContactDetail[];
    /**
     * The period during which the plan definition content was or is planned to be in active use.
     *
     * When the plan definition is expected to be used
     */
    effectivePeriod?: Period;
    /**
     * Related artifacts such as additional documentation, justification, or bibliographic references.
     *
     * Additional documentation, citations
     */
    relatedArtifact?: RelatedArtifact[];
    /**
     * A goal describes an expected outcome that activities within the plan are intended to achieve. For example, weight loss, restoring an activity of daily living, obtaining herd immunity via immunization, meeting a process improvement objective, meeting the acceptance criteria for a test as specified by a quality specification, etc.
     *
     * What the plan is trying to accomplish
     */
    goal?: PlanDefinition.PlanDefinitionGoalComponent[];
    /**
     * A formal identifier that is used to identify this plan definition when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the plan definition
     */
    identifier?: Identifier[];
    /**
     * An individual or organization primarily responsible for internal coherence of the content.
     *
     * Who edited the content
     */
    editor?: ContactDetail[];
    /**
     * An absolute URI that is used to identify this plan definition when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this plan definition is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the plan definition is stored on different servers.
     *
     * Canonical identifier for this plan definition, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * The identifier that is used to identify this version of the plan definition when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the plan definition author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence. To provide a version consistent with the Decision Support Service specification, use the format Major.Minor.Revision (e.g. 1.0.0). For more information on versioning knowledge assets, refer to the Decision Support Service specification. Note that a version is required for non-experimental active artifacts.
     *
     * Business version of the plan definition
     */
    version?: string;
    /**
     * An individual or organization asserted by the publisher to be primarily responsible for review of some aspect of the content.
     *
     * Who reviewed the content
     */
    reviewer?: ContactDetail[];
    /**
     * An explanatory or alternate title for the plan definition giving additional information about its content.
     *
     * Subordinate title of the plan definition
     */
    subtitle?: string;
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * The date on which the resource content was last reviewed. Review happens periodically after approval but does not change the original approval date.
     *
     * When the plan definition was last reviewed by the publisher
     */
    lastReviewDate?: Date;
    /**
     * Actors represent the individuals or groups involved in the execution of the defined set of activities.
     *
     * Actors within the plan
     */
    actor?: PlanDefinition.PlanDefinitionActorComponent[];
    /**
     * The status of this plan definition. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate plan definition instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the plan definition.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * Descriptive topics related to the content of the plan definition. Topics provide a high-level categorization of the definition that can be useful for filtering and searching.
     *
     * E.g. Education, Treatment, Assessment
     */
    topic?: CodeableConcept[];
    /**
     * A natural language name identifying the plan definition. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this plan definition (computer friendly)
     */
    name?: string;
    /**
     * A legal or geographic region in which the plan definition is intended to be used.
     *
     * Intended jurisdiction for plan definition (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * A detailed description of how the plan definition is used from a clinical perspective.
     *
     * Describes the clinical usage of the plan
     */
    usage?: string;
    /**
     * A code, group definition, or canonical reference that describes  or identifies the intended subject of the plan definition. Canonical references are allowed to support the definition of protocols for drug and substance quality specifications, and is allowed to reference a MedicinalProductDefinition, SubstanceDefinition, AdministrableProductDefinition, ManufacturedItemDefinition, or PackagedProductDefinition resource.
     *
     * Type of individual the plan definition is focused on
     */
    subject?: CodeableConcept | Group | MedicinalProductDefinition | SubstanceDefinition | AdministrableProductDefinition | ManufacturedItemDefinition | PackagedProductDefinition | string | Reference;
    /**
     * Explanation of why this plan definition is needed and why it has been designed as it has.
     *
     * Why this plan definition is defined
     */
    purpose?: string;
    /**
     * The date on which the resource content was approved by the publisher. Approval happens once when the content is officially approved for usage.
     *
     * When the plan definition was approved by publisher
     */
    approvalDate?: Date;
    /**
     * A copyright statement relating to the plan definition and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the plan definition.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * The date  (and optionally time) when the plan definition was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the plan definition changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * A short, descriptive, user-friendly title for the plan definition.
     *
     * Name for this plan definition (human friendly)
     */
    title?: string;
    /**
     * A high-level category for the plan definition that distinguishes the kinds of systems that would be interested in the plan definition.
     *
     * order-set | clinical-protocol | eca-rule | workflow-definition
     */
    type?: CodeableConcept;
    /**
     * A Boolean value to indicate that this plan definition is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A free text natural language description of the plan definition from a consumer's perspective.
     *
     * Natural language description of the plan definition
     */
    description?: string;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * A reference to a Library resource containing any formal logic used by the plan definition.
     *
     * Logic used by the plan definition
     */
    library?: string[];
    /**
     * If a CodeableConcept is present, it indicates the pre-condition for performing the service.  For example "pain", "on flare-up", etc.
     *
     * Preconditions for service
     */
    asNeeded?: boolean | CodeableConcept;
    /**
     * An action or group of actions to be taken as part of the plan. For example, in clinical care, an action would be to prescribe a particular indicated medication, or perform a particular test as appropriate. In pharmaceutical quality, an action would be the test that needs to be performed on a drug product as defined in the quality specification.
     *
     * Action defined by the plan
     */
    action?: PlanDefinition.PlanDefinitionActionComponent[];
    /**
     * An individual or organization asserted by the publisher to be responsible for officially endorsing the content for use in some setting.
     *
     * Who endorsed the content
     */
    endorser?: ContactDetail[];
    readonly resourceType: string;
    static revive(json: any): PlanDefinition;
    toJSON(): any;
}
export declare namespace PlanDefinition {
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class PlanDefinitionActionDynamicValueComponent extends BackboneElement {
        /**
         * The path to the element to be customized. This is the path on the resource that will hold the result of the calculation defined by the expression. The specified path SHALL be a FHIRPath resolvable on the specified target type of the ActivityDefinition, and SHALL consist only of identifiers, constant indexers, and a restricted subset of functions. The path is allowed to contain qualifiers (.) to traverse sub-elements, as well as indexers ([x]) to traverse multiple-cardinality sub-elements (see the [Simple FHIRPath Profile](fhirpath.html#simple) for full details).
         *
         * The path to the element to be set dynamically
         */
        path?: string;
        /**
         * An expression specifying the value of the customized element.
         *
         * An expression that provides the dynamic value for the customization
         */
        expression?: Expression;
        static revive(json: any): PlanDefinitionActionDynamicValueComponent;
        toJSON(): any;
    }
    class PlanDefinitionActionParticipantComponent extends BackboneElement {
        /**
         * The type of participant in the action.
         *
         * Who or what can participate
         */
        typeReference?: CareTeam | Device | DeviceDefinition | Endpoint | Group | HealthcareService | Location | Organization | Patient | Practitioner | PractitionerRole | RelatedPerson | Reference;
        /**
         * The type of participant in the action.
         *
         * careteam | device | group | healthcareservice | location | organization | patient | practitioner | practitionerrole | relatedperson
         */
        type?: string;
        /**
         * A reference to the id element of the actor who will participate in this action.
         *
         * What actor
         */
        actorId?: string;
        /**
         * The role the participant should play in performing the described action.
         *
         * E.g. Nurse, Surgeon, Parent
         */
        role?: CodeableConcept;
        /**
         * Indicates how the actor will be involved in the action - author, reviewer, witness, etc.
         *
         * E.g. Author, Reviewer, Witness, etc
         */
        function?: CodeableConcept;
        /**
         * The type of participant in the action.
         *
         * Who or what can participate
         */
        typeCanonical?: string;
        static revive(json: any): PlanDefinitionActionParticipantComponent;
        toJSON(): any;
    }
    class PlanDefinitionActionRelatedActionComponent extends BackboneElement {
        /**
         * The element id of the target related action.
         *
         * What action is this related to
         */
        targetId: string;
        /**
         * A duration or range of durations to apply to the relationship. For example, 30-60 minutes before.
         *
         * Time offset for the relationship
         */
        offset?: Duration | Range;
        /**
         * The relationship of the start of this action to the related action.
         *
         * before | before-start | before-end | concurrent | concurrent-with-start | concurrent-with-end | after | after-start | after-end
         */
        relationship: string;
        /**
         * The relationship of the end of this action to the related action.
         *
         * before | before-start | before-end | concurrent | concurrent-with-start | concurrent-with-end | after | after-start | after-end
         */
        endRelationship?: string;
        static revive(json: any): PlanDefinitionActionRelatedActionComponent;
        toJSON(): any;
    }
    class PlanDefinitionActionOutputComponent extends BackboneElement {
        /**
         * A human-readable label for the data requirement used to label data flows in BPMN or similar diagrams. Also provides a human readable label when rendering the data requirement that conveys its purpose to human readers.
         *
         * User-visible title
         */
        title?: string;
        /**
         * Points to an existing input or output element that is results as output from the action.
         *
         * What data is provided
         */
        relatedData?: string;
        /**
         * Defines the data that results as output from the action.
         *
         * What data is provided
         */
        requirement?: DataRequirement;
        static revive(json: any): PlanDefinitionActionOutputComponent;
        toJSON(): any;
    }
    class PlanDefinitionActionInputComponent extends BackboneElement {
        /**
         * Points to an existing input or output element that provides data to this input.
         *
         * What data is provided
         */
        relatedData?: string;
        /**
         * Defines the data that is to be provided as input to the action.
         *
         * What data is provided
         */
        requirement?: DataRequirement;
        /**
         * A human-readable label for the data requirement used to label data flows in BPMN or similar diagrams. Also provides a human readable label when rendering the data requirement that conveys its purpose to human readers.
         *
         * User-visible title
         */
        title?: string;
        static revive(json: any): PlanDefinitionActionInputComponent;
        toJSON(): any;
    }
    class PlanDefinitionActionConditionComponent extends BackboneElement {
        /**
         * An expression that returns true or false, indicating whether the condition is satisfied.
         *
         * Boolean-valued expression
         */
        expression?: Expression;
        /**
         * The kind of condition.
         *
         * applicability | start | stop
         */
        kind: string;
        static revive(json: any): PlanDefinitionActionConditionComponent;
        toJSON(): any;
    }
    class PlanDefinitionActionComponent extends BackboneElement {
        /**
         * A code that provides a meaning, grouping, or classification for the action or action group. For example, a section may have a LOINC code for the section of a documentation template. In pharmaceutical quality, an action (Test) such as pH could be classified as a physical property.
         *
         * Code representing the meaning of the action or sub-actions
         */
        code?: CodeableConcept;
        /**
         * Identifies goals that this action supports. The reference must be to a goal element defined within this plan definition. In pharmaceutical quality, a goal represents acceptance criteria (Goal) for a given action (Test), so the goalId would be the unique id of a defined goal element establishing the acceptance criteria for the action.
         *
         * What goals this action supports
         */
        goalId?: string[];
        /**
         * Defines whether the action can be selected multiple times.
         *
         * single | multiple
         */
        cardinalityBehavior?: string;
        /**
         * A description of why this action is necessary or appropriate.
         *
         * Why the action should be performed
         */
        reason?: CodeableConcept[];
        /**
         * A user-visible prefix for the action. For example a section or item numbering such as 1. or A.
         *
         * User-visible prefix for the action (e.g. 1. or A.)
         */
        prefix?: string;
        /**
         * A code, group definition, or canonical reference that describes the intended subject of the action and its children, if any. Canonical references are allowed to support the definition of protocols for drug and substance quality specifications, and is allowed to reference a MedicinalProductDefinition, SubstanceDefinition, AdministrableProductDefinition, ManufacturedItemDefinition, or PackagedProductDefinition resource.
         *
         * Type of individual the action is focused on
         */
        subject?: CodeableConcept | Group | string | Reference;
        /**
         * A brief description of the action used to provide a summary to display to the user.
         *
         * Brief description of the action
         */
        description?: string;
        /**
         * Indicates who should participate in performing the action described.
         *
         * Who should participate in the action
         */
        participant?: PlanDefinition.PlanDefinitionActionParticipantComponent[];
        /**
         * Defines the grouping behavior for the action and its children.
         *
         * visual-group | logical-group | sentence-group
         */
        groupingBehavior?: string;
        /**
         * The textual description of the action displayed to a user. For example, when the action is a test to be performed, the title would be the title of the test such as Assay by HPLC.
         *
         * User-visible title
         */
        title?: string;
        /**
         * The type of action to perform (create, update, remove).
         *
         * create | update | remove | fire-event
         */
        type?: CodeableConcept;
        /**
         * Customizations that should be applied to the statically defined resource. For example, if the dosage of a medication must be computed based on the patient's weight, a customization would be used to specify an expression that calculated the weight, and the path on the resource that would contain the result.
         *
         * Dynamic aspects of the definition
         */
        dynamicValue?: PlanDefinition.PlanDefinitionActionDynamicValueComponent[];
        /**
         * A reference to a StructureMap resource that defines a transform that can be executed to produce the intent resource using the ActivityDefinition instance as the input.
         *
         * Transform to apply the template
         */
        transform?: string;
        /**
         * Defines the outputs of the action, if any.
         *
         * Output data definition
         */
        output?: PlanDefinition.PlanDefinitionActionOutputComponent[];
        /**
         * A relationship to another action such as "before" or "30-60 minutes after start of".
         *
         * Relationship to another action
         */
        relatedAction?: PlanDefinition.PlanDefinitionActionRelatedActionComponent[];
        /**
         * A reference to an ActivityDefinition that describes the action to be taken in detail, a MessageDefinition describing a message to be snet, a PlanDefinition that describes a series of actions to be taken, a Questionnaire that should be filled out, a SpecimenDefinition describing a specimen to be collected, or an ObservationDefinition that specifies what observation should be captured.
         *
         * Description of the activity to be performed
         */
        definition?: string;
        /**
         * Sub actions that are contained within the action. The behavior of this action determines the functionality of the sub-actions. For example, a selection behavior of at-most-one indicates that of the sub-actions, at most one may be chosen as part of realizing the action definition.
         *
         * A sub-action
         */
        action?: PlanDefinition.PlanDefinitionActionComponent[];
        /**
         * A text equivalent of the action to be performed. This provides a human-interpretable description of the action when the definition is consumed by a system that might not be capable of interpreting it dynamically.
         *
         * Static text equivalent of the action, used if the dynamic aspects cannot be interpreted by the receiving system
         */
        textEquivalent?: string;
        /**
         * Didactic or other informational resources associated with the action that can be provided to the CDS recipient. Information resources can include inline text commentary and links to web resources.
         *
         * Supporting documentation for the intended performer of the action
         */
        documentation?: RelatedArtifact[];
        /**
         * An optional value describing when the action should be performed.
         *
         * When the action should take place
         */
        timing?: Age | Duration | Range | Timing;
        /**
         * A description of when the action should be triggered. When multiple triggers are specified on an action, any triggering event invokes the action.
         *
         * When the action should be triggered
         */
        trigger?: TriggerDefinition[];
        /**
         * Indicates how quickly the action should be addressed with respect to other actions.
         *
         * routine | urgent | asap | stat
         */
        priority?: string;
        /**
         * An identifier that is unique within the PlanDefinition to allow linkage within the realized CarePlan and/or RequestOrchestration.
         *
         * Unique id for the action in the PlanDefinition
         */
        linkId?: string;
        /**
         * Defines the selection behavior for the action and its children.
         *
         * any | all | all-or-none | exactly-one | at-most-one | one-or-more
         */
        selectionBehavior?: string;
        /**
         * An expression that describes applicability criteria or start/stop conditions for the action.
         *
         * Whether or not the action is applicable
         */
        condition?: PlanDefinition.PlanDefinitionActionConditionComponent[];
        /**
         * Defines input data requirements for the action.
         *
         * Input data requirements
         */
        input?: PlanDefinition.PlanDefinitionActionInputComponent[];
        /**
         * Defines the required behavior for the action.
         *
         * must | could | must-unless-documented
         */
        requiredBehavior?: string;
        /**
         * Defines whether the action should usually be preselected.
         *
         * yes | no
         */
        precheckBehavior?: string;
        /**
         * Identifies the facility where the action will occur; e.g. home, hospital, specific clinic, etc.
         *
         * Where it should happen
         */
        location?: CodeableReference;
        static revive(json: any): PlanDefinitionActionComponent;
        toJSON(): any;
    }
    class PlanDefinitionActorOptionComponent extends BackboneElement {
        /**
         * The type of participant in the action.
         *
         * Who or what can participate
         */
        typeReference?: CareTeam | Device | DeviceDefinition | Endpoint | Group | HealthcareService | Location | Organization | Patient | Practitioner | PractitionerRole | RelatedPerson | Reference;
        /**
         * The type of participant in the action.
         *
         * careteam | device | group | healthcareservice | location | organization | patient | practitioner | practitionerrole | relatedperson
         */
        type?: string;
        /**
         * The role the participant should play in performing the described action.
         *
         * E.g. Nurse, Surgeon, Parent
         */
        role?: CodeableConcept;
        /**
         * The type of participant in the action.
         *
         * Who or what can participate
         */
        typeCanonical?: string;
        static revive(json: any): PlanDefinitionActorOptionComponent;
        toJSON(): any;
    }
    class PlanDefinitionActorComponent extends BackboneElement {
        /**
         * A descriptive label for the actor.
         *
         * User-visible title
         */
        title?: string;
        /**
         * The characteristics of the candidates that could serve as the actor.
         *
         * Who or what can be this actor
         */
        option: PlanDefinition.PlanDefinitionActorOptionComponent[];
        /**
         * A description of how the actor fits into the overall actions of the plan definition.
         *
         * Describes the actor
         */
        description?: string;
        static revive(json: any): PlanDefinitionActorComponent;
        toJSON(): any;
    }
    class PlanDefinitionGoalTargetComponent extends BackboneElement {
        /**
         * Indicates the timeframe after the start of the goal in which the goal should be met.
         *
         * Reach goal within
         */
        due?: Duration;
        /**
         * The parameter whose value is to be tracked, e.g. body weight, blood pressure, or hemoglobin A1c level.
         *
         * The parameter whose value is to be tracked
         */
        measure?: CodeableConcept;
        /**
         * The target value of the measure to be achieved to signify fulfillment of the goal, e.g. 150 pounds or 7.0%, or in the case of pharmaceutical quality - NMT 0.6%, Clear solution, etc. Either the high or low or both values of the range can be specified. When a low value is missing, it indicates that the goal is achieved at any value at or below the high value. Similarly, if the high value is missing, it indicates that the goal is achieved at any value at or above the low value.
         *
         * The target value to be achieved
         */
        detail?: Quantity | Range | CodeableConcept | string | boolean | number | Ratio;
        static revive(json: any): PlanDefinitionGoalTargetComponent;
        toJSON(): any;
    }
    class PlanDefinitionGoalComponent extends BackboneElement {
        /**
         * Indicates what should be done and within what timeframe.
         *
         * Target outcome for the goal
         */
        target?: PlanDefinition.PlanDefinitionGoalTargetComponent[];
        /**
         * Indicates a category the goal falls within.
         *
         * E.g. Treatment, dietary, behavioral
         */
        category?: CodeableConcept;
        /**
         * Identifies the expected level of importance associated with reaching/sustaining the defined goal.
         *
         * high-priority | medium-priority | low-priority
         */
        priority?: CodeableConcept;
        /**
         * The event after which the goal should begin being pursued.
         *
         * When goal pursuit begins
         */
        start?: CodeableConcept;
        /**
         * Human-readable and/or coded description of a specific desired objective of care, such as "control blood pressure" or "negotiate an obstacle course" or "dance with child at wedding".
         *
         * Code or text describing the goal
         */
        description: CodeableConcept;
        /**
         * Didactic or other informational resources associated with the goal that provide further supporting information about the goal. Information resources can include inline text commentary and links to web resources.
         *
         * Supporting documentation for the goal
         */
        documentation?: RelatedArtifact[];
        /**
         * Identifies problems, conditions, issues, or concerns the goal is intended to address.
         *
         * What does the goal address
         */
        addresses?: CodeableConcept[];
        static revive(json: any): PlanDefinitionGoalComponent;
        toJSON(): any;
    }
}
