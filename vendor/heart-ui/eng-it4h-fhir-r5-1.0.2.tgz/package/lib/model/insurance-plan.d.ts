import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { ExtendedContactDetail } from '../datatype/extended-contact-detail';
import { Identifier } from '../datatype/identifier';
import { Money } from '../datatype/money';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { DomainResource } from '../model/domain-resource';
import { Endpoint } from '../model/endpoint';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
/**
 * HAPI/FHIR <b>InsurancePlan</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/InsurancePlan">http://hl7.org/fhir/StructureDefinition/InsurancePlan</a>
 * </p>
 *
 */
export declare class InsurancePlan extends DomainResource {
    /**
     * The contact details of communication devices available relevant to the specific Insurance Plan/Product. This can include addresses, phone numbers, fax numbers, mobile numbers, email addresses and web sites.
     *
     * Official contact details relevant to the health insurance plan/product
     */
    contact?: ExtendedContactDetail[];
    /**
     * The technical endpoints providing access to services operated for the health insurance product.
     *
     * Technical endpoint
     */
    endpoint?: Endpoint[] | Reference[];
    /**
     * The entity that is providing  the health insurance product and underwriting the risk.  This is typically an insurance carriers, other third-party payers, or health plan sponsors comonly referred to as 'payers'.
     *
     * Product issuer
     */
    ownedBy?: Organization | Reference;
    /**
     * Details about an insurance plan.
     *
     * Plan details
     */
    plan?: InsurancePlan.InsurancePlanPlanComponent[];
    /**
     * The current state of the health insurance product.
     *
     * draft | active | retired | unknown
     */
    status?: string;
    /**
     * The geographic region in which a health insurance product's benefits apply.
     *
     * Where product applies
     */
    coverageArea?: Location[] | Reference[];
    /**
     * Official name of the health insurance product as designated by the owner.
     *
     * Official name
     */
    name?: string;
    /**
     * A list of alternate names that the product is known as, or was known as in the past.
     *
     * Alternate names
     */
    alias?: string[];
    /**
     * Details about the coverage offered by the insurance product.
     *
     * Coverage details
     */
    coverage?: InsurancePlan.InsurancePlanCoverageComponent[];
    /**
     * Business identifiers assigned to this health insurance product which remain constant as the resource is updated and propagates from server to server.
     *
     * Business Identifier for Product
     */
    identifier?: Identifier[];
    /**
     * The period of time that the health insurance product is available.
     *
     * When the product is available
     */
    period?: Period;
    /**
     * The kind of health insurance product.
     *
     * Kind of product
     */
    type?: CodeableConcept[];
    /**
     * An organization which administer other services such as underwriting, customer service and/or claims processing on behalf of the health insurance product owner.
     *
     * Product administrator
     */
    administeredBy?: Organization | Reference;
    /**
     * Reference to the network included in the health insurance product.
     *
     * What networks are Included
     */
    network?: Organization[] | Reference[];
    readonly resourceType: string;
    static revive(json: any): InsurancePlan;
    toJSON(): any;
}
export declare namespace InsurancePlan {
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class PlanBenefitCostComponent extends BackboneElement {
        /**
         * Whether the cost applies to in-network or out-of-network providers (in-network; out-of-network; other).
         *
         * in-network | out-of-network | other
         */
        applicability?: CodeableConcept;
        /**
         * Additional information about the cost, such as information about funding sources (e.g. HSA, HRA, FSA, RRA).
         *
         * Additional information about the cost
         */
        qualifiers?: CodeableConcept[];
        /**
         * Type of cost (copay; individual cap; family cap; coinsurance; deductible).
         *
         * Type of cost
         */
        type: CodeableConcept;
        /**
         * The actual cost value. (some of the costs may be represented as percentages rather than currency, e.g. 10% coinsurance).
         *
         * The actual cost value
         */
        value?: Quantity;
        static revive(json: any): PlanBenefitCostComponent;
        toJSON(): any;
    }
    class PlanBenefitComponent extends BackboneElement {
        /**
         * List of the costs associated with a specific benefit.
         *
         * List of the costs
         */
        cost?: InsurancePlan.PlanBenefitCostComponent[];
        /**
         * Type of specific benefit (preventative; primary care office visit; speciality office visit; hospitalization; emergency room; urgent care).
         *
         * Type of specific benefit
         */
        type: CodeableConcept;
        static revive(json: any): PlanBenefitComponent;
        toJSON(): any;
    }
    class InsurancePlanPlanSpecificCostComponent extends BackboneElement {
        /**
         * General category of benefit (Medical; Dental; Vision; Drug; Mental Health; Substance Abuse; Hospice, Home Health).
         *
         * General category of benefit
         */
        category: CodeableConcept;
        /**
         * List of the specific benefits under this category of benefit.
         *
         * Benefits list
         */
        benefit?: InsurancePlan.PlanBenefitComponent[];
        static revive(json: any): InsurancePlanPlanSpecificCostComponent;
        toJSON(): any;
    }
    class InsurancePlanPlanGeneralCostComponent extends BackboneElement {
        /**
         * Number of participants enrolled in the plan.
         *
         * Number of enrollees
         */
        groupSize?: number;
        /**
         * Additional information about the general costs associated with this plan.
         *
         * Additional cost information
         */
        comment?: string;
        /**
         * Type of cost.
         *
         * Type of cost
         */
        type?: CodeableConcept;
        /**
         * Value of the cost.
         *
         * Cost value
         */
        cost?: Money;
        static revive(json: any): InsurancePlanPlanGeneralCostComponent;
        toJSON(): any;
    }
    class InsurancePlanPlanComponent extends BackboneElement {
        /**
         * The geographic region in which a health insurance plan's benefits apply.
         *
         * Where product applies
         */
        coverageArea?: Location[] | Reference[];
        /**
         * Reference to the network that providing the type of coverage.
         *
         * What networks provide coverage
         */
        network?: Organization[] | Reference[];
        /**
         * Overall costs associated with the plan.
         *
         * Overall costs
         */
        generalCost?: InsurancePlan.InsurancePlanPlanGeneralCostComponent[];
        /**
         * Type of plan. For example, "Platinum" or "High Deductable".
         *
         * Type of plan
         */
        type?: CodeableConcept;
        /**
         * Costs associated with the coverage provided by the product.
         *
         * Specific costs
         */
        specificCost?: InsurancePlan.InsurancePlanPlanSpecificCostComponent[];
        /**
         * Business identifiers assigned to this health insurance plan which remain constant as the resource is updated and propagates from server to server.
         *
         * Business Identifier for Product
         */
        identifier?: Identifier[];
        static revive(json: any): InsurancePlanPlanComponent;
        toJSON(): any;
    }
    class CoverageBenefitLimitComponent extends BackboneElement {
        /**
         * The specific limit on the benefit.
         *
         * Benefit limit details
         */
        code?: CodeableConcept;
        /**
         * The maximum amount of a service item a plan will pay for a covered benefit.  For examples. wellness visits, or eyeglasses.
         *
         * Maximum value allowed
         */
        value?: Quantity;
        static revive(json: any): CoverageBenefitLimitComponent;
        toJSON(): any;
    }
    class CoverageBenefitComponent extends BackboneElement {
        /**
         * Type of benefit (primary care; speciality care; inpatient; outpatient).
         *
         * Type of benefit
         */
        type: CodeableConcept;
        /**
         * The referral requirements to have access/coverage for this benefit.
         *
         * Referral requirements
         */
        requirement?: string;
        /**
         * The specific limits on the benefit.
         *
         * Benefit limits
         */
        limit?: InsurancePlan.CoverageBenefitLimitComponent[];
        static revive(json: any): CoverageBenefitComponent;
        toJSON(): any;
    }
    class InsurancePlanCoverageComponent extends BackboneElement {
        /**
         * Type of coverage  (Medical; Dental; Mental Health; Substance Abuse; Vision; Drug; Short Term; Long Term Care; Hospice; Home Health).
         *
         * Type of coverage
         */
        type: CodeableConcept;
        /**
         * Reference to the network that providing the type of coverage.
         *
         * What networks provide coverage
         */
        network?: Organization[] | Reference[];
        /**
         * Specific benefits under this type of coverage.
         *
         * List of benefits
         */
        benefit: InsurancePlan.CoverageBenefitComponent[];
        static revive(json: any): InsurancePlanCoverageComponent;
        toJSON(): any;
    }
}
