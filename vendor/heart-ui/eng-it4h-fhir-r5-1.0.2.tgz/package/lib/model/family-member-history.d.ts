import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Age } from '../datatype/age';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Range } from '../datatype/range';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>FamilyMemberHistory</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/FamilyMemberHistory">http://hl7.org/fhir/StructureDefinition/FamilyMemberHistory</a>
 * </p>
 *
 */
export declare class FamilyMemberHistory extends DomainResource {
    /**
     * The type of relationship this person has to the patient (father, mother, brother etc.).
     *
     * Relationship to the subject
     */
    relationship: CodeableConcept;
    /**
     * The age of the relative at the time the family member history is recorded.
     *
     * (approximate) age
     */
    age?: Age | Range | string;
    /**
     * A code specifying the status of the record of the family history of a specific family member.
     *
     * partial | completed | entered-in-error | health-unknown
     */
    status: string;
    /**
     * This will either be a name or a description; e.g. "Aunt Susan", "my cousin with the red hair".
     *
     * The family member described
     */
    name?: string;
    /**
     * If true, indicates that the age value specified is an estimated value.
     *
     * Age is estimated?
     */
    estimatedAge?: boolean;
    /**
     * The person who this history concerns.
     *
     * Patient history is about
     */
    patient: Patient | Reference;
    /**
     * The significant Conditions (or condition) that the family member had. This is a repeating section to allow a system to represent more than one condition per resource, though there is nothing stopping multiple resources - one per condition.
     *
     * Condition that the related person had
     */
    condition?: FamilyMemberHistory.FamilyMemberHistoryConditionComponent[];
    /**
     * The URL pointing to a FHIR-defined protocol, guideline, orderset or other definition that is adhered to in whole or in part by this FamilyMemberHistory.
     *
     * Instantiates FHIR protocol or definition
     */
    instantiatesCanonical?: string[];
    /**
     * The URL pointing to an externally maintained protocol, guideline, orderset or other definition that is adhered to in whole or in part by this FamilyMemberHistory.
     *
     * Instantiates external protocol or definition
     */
    instantiatesUri?: string[];
    /**
     * Indicates who or what participated in the activities related to the family member history and how they were involved.
     *
     * Who or what participated in the activities related to the family member history and how they were involved
     */
    participant?: FamilyMemberHistory.FamilyMemberHistoryParticipantComponent[];
    /**
     * The significant Procedures (or procedure) that the family member had. This is a repeating section to allow a system to represent more than one procedure per resource, though there is nothing stopping multiple resources - one per procedure.
     *
     * Procedures that the related person had
     */
    procedure?: FamilyMemberHistory.FamilyMemberHistoryProcedureComponent[];
    /**
     * The birth sex of the family member.
     *
     * male | female | other | unknown
     */
    sex?: CodeableConcept;
    /**
     * The actual or approximate date of birth of the relative.
     *
     * (approximate) date of birth
     */
    born?: Period | Date | string;
    /**
     * The date (and possibly time) when the family member history was recorded or last updated.
     *
     * When history was recorded or last updated
     */
    date?: Date;
    /**
     * Business identifiers assigned to this family member history by the performer or other systems which remain constant as the resource is updated and propagates from server to server.
     *
     * External Id(s) for this record
     */
    identifier?: Identifier[];
    /**
     * Describes why the family member's history is not available.
     *
     * subject-unknown | withheld | unable-to-obtain | deferred
     */
    dataAbsentReason?: CodeableConcept;
    /**
     * Describes why the family member history occurred in coded or textual form, or Indicates a Condition, Observation, AllergyIntolerance, or QuestionnaireResponse that justifies this family member history event.
     *
     * Why was family member history performed?
     */
    reason?: CodeableReference[];
    /**
     * This property allows a non condition-specific note to the made about the related person. Ideally, the note would be in the condition property, but this is not always possible.
     *
     * General note about related person
     */
    note?: Annotation[];
    /**
     * Deceased flag or the actual or approximate age of the relative at the time of death for the family member history record.
     *
     * Dead? How old/when?
     */
    deceased?: boolean | Age | Range | Date | string;
    readonly resourceType: string;
    static revive(json: any): FamilyMemberHistory;
    toJSON(): any;
}
export declare namespace FamilyMemberHistory {
    enum FamilyHistoryStatus {
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        PARTIAL,
        HEALTHUNKNOWN
    }
    class FamilyMemberHistoryProcedureComponent extends BackboneElement {
        /**
         * The actual procedure specified. Could be a coded procedure or a less specific string depending on how much is known about the procedure and the capabilities of the creating system.
         *
         * Procedures performed on the related person
         */
        code: CodeableConcept;
        /**
         * This procedure contributed to the cause of death of the related person. If contributedToDeath is not populated, then it is unknown.
         *
         * Whether the procedure contributed to the cause of death
         */
        contributedToDeath?: boolean;
        /**
         * An area where general notes can be placed about this specific procedure.
         *
         * Extra information about the procedure
         */
        note?: Annotation[];
        /**
         * Indicates what happened following the procedure. If the procedure resulted in death, deceased date is captured on the relation.
         *
         * What happened following the procedure
         */
        outcome?: CodeableConcept;
        /**
         * Estimated or actual date, date-time, period, or age when the procedure was performed. Allows a period to support complex procedures that span more than one date, and also allows for the length of the procedure to be captured.
         *
         * When the procedure was performed
         */
        performed?: Age | Range | Period | string | Date;
        static revive(json: any): FamilyMemberHistoryProcedureComponent;
        toJSON(): any;
    }
    class FamilyMemberHistoryConditionComponent extends BackboneElement {
        /**
         * Either the age of onset, range of approximate age or descriptive string can be recorded.  For conditions with multiple occurrences, this describes the first known occurrence.
         *
         * When condition first manifested
         */
        onset?: Age | Range | Period | string;
        /**
         * Indicates what happened following the condition.  If the condition resulted in death, deceased date is captured on the relation.
         *
         * deceased | permanent disability | etc
         */
        outcome?: CodeableConcept;
        /**
         * This condition contributed to the cause of death of the related person. If contributedToDeath is not populated, then it is unknown.
         *
         * Whether the condition contributed to the cause of death
         */
        contributedToDeath?: boolean;
        /**
         * An area where general notes can be placed about this specific condition.
         *
         * Extra information about condition
         */
        note?: Annotation[];
        /**
         * The actual condition specified. Could be a coded condition (like MI or Diabetes) or a less specific string like 'cancer' depending on how much is known about the condition and the capabilities of the creating system.
         *
         * Condition suffered by relation
         */
        code: CodeableConcept;
        static revive(json: any): FamilyMemberHistoryConditionComponent;
        toJSON(): any;
    }
    class FamilyMemberHistoryParticipantComponent extends BackboneElement {
        /**
         * Distinguishes the type of involvement of the actor in the activities related to the family member history.
         *
         * Type of involvement
         */
        function?: CodeableConcept;
        /**
         * Indicates who or what participated in the activities related to the family member history.
         *
         * Who or what participated in the activities related to the family member history
         */
        actor: Practitioner | PractitionerRole | Patient | RelatedPerson | Device | Organization | CareTeam | Reference;
        static revive(json: any): FamilyMemberHistoryParticipantComponent;
        toJSON(): any;
    }
}
