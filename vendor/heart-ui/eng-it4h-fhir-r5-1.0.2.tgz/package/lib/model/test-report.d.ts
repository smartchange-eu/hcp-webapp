import { BackboneElement } from '../datatype/backbone-element';
import { Identifier } from '../datatype/identifier';
import { DomainResource } from '../model/domain-resource';
/**
 * HAPI/FHIR <b>TestReport</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/TestReport">http://hl7.org/fhir/StructureDefinition/TestReport</a>
 * </p>
 *
 */
export declare class TestReport extends DomainResource {
    /**
     * A free text natural language name identifying the executed TestReport.
     *
     * Informal name of the executed TestReport
     */
    name?: string;
    /**
     * Name of the tester producing this report (Organization or individual).
     *
     * Name of the tester producing this report (Organization or individual)
     */
    tester?: string;
    /**
     * The results of the series of required setup operations before the tests were executed.
     *
     * The results of the series of required setup operations before the tests were executed
     */
    setup?: TestReport.TestReportSetupComponent;
    /**
     * When the TestScript was executed and this TestReport was generated.
     *
     * When the TestScript was executed and this TestReport was generated
     */
    issued?: Date;
    /**
     * The results of the series of operations required to clean up after all the tests were executed (successfully or otherwise).
     *
     * The results of running the series of required clean up steps
     */
    teardown?: TestReport.TestReportTeardownComponent;
    /**
     * A participant in the test execution, either the execution engine, a client, or a server.
     *
     * A participant in the test execution, either the execution engine, a client, or a server
     */
    participant?: TestReport.TestReportParticipantComponent[];
    /**
     * The current state of this test report.
     *
     * completed | in-progress | waiting | stopped | entered-in-error
     */
    status: string;
    /**
     * The overall result from the execution of the TestScript.
     *
     * pass | fail | pending
     */
    result: string;
    /**
     * Identifier for the TestReport assigned for external purposes outside the context of FHIR.
     *
     * External identifier
     */
    identifier?: Identifier;
    /**
     * The final score (percentage of tests passed) resulting from the execution of the TestScript.
     *
     * The final score (percentage of tests passed) resulting from the execution of the TestScript
     */
    score?: number;
    /**
     * A test executed from the test script.
     *
     * A test executed from the test script
     */
    test?: TestReport.TestReportTestComponent[];
    /**
     * Ideally this is an absolute URL that is used to identify the version-specific TestScript that was executed, matching the `TestScript.url`.
     *
     * Canonical URL to the  version-specific TestScript that was executed to produce this TestReport
     */
    testScript: string;
    readonly resourceType: string;
    static revive(json: any): TestReport;
    toJSON(): any;
}
export declare namespace TestReport {
    enum TestReportStatus {
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        STOPPED,
        INPROGRESS,
        WAITING
    }
    enum TestReportResult {
        NULL,
        PASS,
        PENDING,
        FAIL
    }
    enum TestReportParticipantType {
        NULL,
        TESTENGINE,
        SERVER,
        CLIENT
    }
    enum TestReportActionResult {
        NULL,
        PASS,
        SKIP,
        ERROR,
        WARNING,
        FAIL
    }
    class TeardownActionComponent extends BackboneElement {
        /**
         * An operation would involve a REST request to a server.
         *
         * The teardown operation performed
         */
        operation: TestReport.SetupActionOperationComponent;
        static revive(json: any): TeardownActionComponent;
        toJSON(): any;
    }
    class TestReportTeardownComponent extends BackboneElement {
        /**
         * The teardown action will only contain an operation.
         *
         * One or more teardown operations performed
         */
        action: TestReport.TeardownActionComponent[];
        static revive(json: any): TestReportTeardownComponent;
        toJSON(): any;
    }
    class TestActionComponent extends BackboneElement {
        /**
         * An operation would involve a REST request to a server.
         *
         * The operation performed
         */
        operation?: TestReport.SetupActionOperationComponent;
        /**
         * The results of the assertion performed on the previous operations.
         *
         * The assertion performed
         */
        assert?: TestReport.SetupActionAssertComponent;
        static revive(json: any): TestActionComponent;
        toJSON(): any;
    }
    class TestReportTestComponent extends BackboneElement {
        /**
         * A short description of the test used by test engines for tracking and reporting purposes.
         *
         * Tracking/reporting short description of the test
         */
        description?: string;
        /**
         * Action would contain either an operation or an assertion.
         *
         * A test operation or assert that was performed
         */
        action: TestReport.TestActionComponent[];
        /**
         * The name of this test used for tracking/logging purposes by test engines.
         *
         * Tracking/logging name of this test
         */
        name?: string;
        static revive(json: any): TestReportTestComponent;
        toJSON(): any;
    }
    class SetupActionAssertRequirementComponent extends BackboneElement {
        /**
         * Link or reference providing traceability to the testing requirement for this test.
         *
         * Link or reference to the testing requirement
         */
        link?: string;
        static revive(json: any): SetupActionAssertRequirementComponent;
        toJSON(): any;
    }
    class SetupActionAssertComponent extends BackboneElement {
        /**
         * The result of this assertion.
         *
         * pass | skip | fail | warning | error
         */
        result: string;
        /**
         * A link to further details on the result.
         *
         * A link to further details on the result
         */
        detail?: string;
        /**
         * Links or references providing traceability to the testing requirements for this assert.
         *
         * Links or references to the testing requirements
         */
        requirement?: TestReport.SetupActionAssertRequirementComponent[];
        /**
         * An explanatory message associated with the result.
         *
         * A message associated with the result
         */
        message?: string;
        static revive(json: any): SetupActionAssertComponent;
        toJSON(): any;
    }
    class SetupActionOperationComponent extends BackboneElement {
        /**
         * The result of this operation.
         *
         * pass | skip | fail | warning | error
         */
        result: string;
        /**
         * A link to further details on the result.
         *
         * A link to further details on the result
         */
        detail?: string;
        /**
         * An explanatory message associated with the result.
         *
         * A message associated with the result
         */
        message?: string;
        static revive(json: any): SetupActionOperationComponent;
        toJSON(): any;
    }
    class SetupActionComponent extends BackboneElement {
        /**
         * The results of the assertion performed on the previous operations.
         *
         * The assertion to perform
         */
        assert?: TestReport.SetupActionAssertComponent;
        /**
         * The operation performed.
         *
         * The operation to perform
         */
        operation?: TestReport.SetupActionOperationComponent;
        static revive(json: any): SetupActionComponent;
        toJSON(): any;
    }
    class TestReportSetupComponent extends BackboneElement {
        /**
         * Action would contain either an operation or an assertion.
         *
         * A setup operation or assert that was executed
         */
        action: TestReport.SetupActionComponent[];
        static revive(json: any): TestReportSetupComponent;
        toJSON(): any;
    }
    class TestReportParticipantComponent extends BackboneElement {
        /**
         * The type of participant.
         *
         * test-engine | client | server
         */
        type: string;
        /**
         * The uri of the participant. An absolute URL is preferred.
         *
         * The uri of the participant. An absolute URL is preferred
         */
        uri: string;
        /**
         * The display name of the participant.
         *
         * The display name of the participant
         */
        display?: string;
        static revive(json: any): TestReportParticipantComponent;
        toJSON(): any;
    }
}
