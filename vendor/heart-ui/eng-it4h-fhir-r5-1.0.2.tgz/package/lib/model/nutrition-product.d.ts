import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { Ratio } from '../datatype/ratio';
import { DomainResource } from '../model/domain-resource';
import { Organization } from '../model/organization';
/**
 * HAPI/FHIR <b>NutritionProduct</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/NutritionProduct">http://hl7.org/fhir/StructureDefinition/NutritionProduct</a>
 * </p>
 *
 */
export declare class NutritionProduct extends DomainResource {
    /**
     * Nutrition products can have different classifications - according to its nutritional properties, preparation methods, etc.
     *
     * Broad product groups or categories used to classify the product, such as Legume and Legume Products, Beverages, or Beef Products
     */
    category?: CodeableConcept[];
    /**
     * Specifies descriptive properties of the nutrition product.
     *
     * Specifies descriptive properties of the nutrition product
     */
    characteristic?: NutritionProduct.NutritionProductCharacteristicComponent[];
    /**
     * The current state of the product.
     *
     * active | inactive | entered-in-error
     */
    status: string;
    /**
     * The organisation (manufacturer, representative or legal authorization holder) that is responsible for the device.
     *
     * Manufacturer, representative or officially responsible for the product
     */
    manufacturer?: Organization[] | Reference[];
    /**
     * Allergens that are known or suspected to be a part of this nutrition product.
     *
     * Known or suspected allergens that are a part of this product
     */
    knownAllergen?: CodeableReference[];
    /**
     * Comments made about the product.
     *
     * Comments made about the product
     */
    note?: Annotation[];
    /**
     * The code assigned to the product, for example a USDA NDB number, a USDA FDC ID number, or a Langual code.
     *
     * A code that can identify the detailed nutrients and ingredients in a specific food product
     */
    code?: CodeableConcept;
    /**
     * The product's nutritional information expressed by the nutrients.
     *
     * The product's nutritional information expressed by the nutrients
     */
    nutrient?: NutritionProduct.NutritionProductNutrientComponent[];
    /**
     * Ingredients contained in this product.
     *
     * Ingredients contained in this product
     */
    ingredient?: NutritionProduct.NutritionProductIngredientComponent[];
    /**
     * Conveys instance-level information about this product item. One or several physical, countable instances or occurrences of the product.
     *
     * One or several physical instances or occurrences of the nutrition product
     */
    instance?: NutritionProduct.NutritionProductInstanceComponent[];
    readonly resourceType: string;
    static revive(json: any): NutritionProduct;
    toJSON(): any;
}
export declare namespace NutritionProduct {
    enum NutritionProductStatus {
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        INACTIVE
    }
    class NutritionProductInstanceComponent extends BackboneElement {
        /**
         * The amount of items or instances that the resource considers, for instance when referring to 2 identical units together.
         *
         * The amount of items or instances
         */
        quantity?: Quantity;
        /**
         * An identifier that supports traceability to the event during which material in this product from one or more biological entities was obtained or pooled.
         *
         * An identifier that supports traceability to the event during which material in this product from one or more biological entities was obtained or pooled
         */
        biologicalSourceEvent?: Identifier;
        /**
         * The identifier for the physical instance, typically a serial number or manufacturer number.
         *
         * The identifier for the physical instance, typically a serial number or manufacturer number
         */
        identifier?: Identifier[];
        /**
         * The identification of the batch or lot of the product.
         *
         * The identification of the batch or lot of the product
         */
        lotNumber?: string;
        /**
         * The time after which the product is no longer expected to be in proper condition, or its use is not advised or not allowed.
         *
         * The expiry date or date and time for the product
         */
        expiry?: Date;
        /**
         * The name for the specific product.
         *
         * The name for the specific product
         */
        name?: string;
        /**
         * The time after which the product is no longer expected to be in proper condition, or its use is not advised or not allowed.
         *
         * The date until which the product is expected to be good for consumption
         */
        useBy?: Date;
        static revive(json: any): NutritionProductInstanceComponent;
        toJSON(): any;
    }
    class NutritionProductCharacteristicComponent extends BackboneElement {
        /**
         * A code specifying which characteristic of the product is being described (for example, colour, shape).
         *
         * Code specifying the type of characteristic
         */
        type: CodeableConcept;
        /**
         * The actual characteristic value corresponding to the type.
         *
         * The value of the characteristic
         */
        value: CodeableConcept | string | Quantity | Attachment | boolean;
        static revive(json: any): NutritionProductCharacteristicComponent;
        toJSON(): any;
    }
    class NutritionProductIngredientComponent extends BackboneElement {
        /**
         * The ingredient contained in the product.
         *
         * The ingredient contained in the product
         */
        item: CodeableReference;
        /**
         * The amount of ingredient that is in the product.
         *
         * The amount of ingredient that is in the product
         */
        amount?: Ratio[];
        static revive(json: any): NutritionProductIngredientComponent;
        toJSON(): any;
    }
    class NutritionProductNutrientComponent extends BackboneElement {
        /**
         * The (relevant) nutrients in the product.
         *
         * The (relevant) nutrients in the product
         */
        item?: CodeableReference;
        /**
         * The amount of nutrient expressed in one or more units: X per pack / per serving / per dose.
         *
         * The amount of nutrient expressed in one or more units: X per pack / per serving / per dose
         */
        amount?: Ratio[];
        static revive(json: any): NutritionProductNutrientComponent;
        toJSON(): any;
    }
}
