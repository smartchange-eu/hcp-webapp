import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { RelatedArtifact } from '../datatype/related-artifact';
import { UsageContext } from '../datatype/usage-context';
import { MetadataResource } from '../model/metadata-resource';
/**
 * HAPI/FHIR <b>NamingSystem</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/NamingSystem">http://hl7.org/fhir/StructureDefinition/NamingSystem</a>
 * </p>
 *
 */
export declare class NamingSystem extends MetadataResource {
    /**
     * Explanation of why this naming system is needed and why it has been designed as it has.
     *
     * Why this naming system is defined
     */
    purpose?: string;
    /**
     * A legal or geographic region in which the naming system is intended to be used.
     *
     * Intended jurisdiction for naming system (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * Provides guidance on the use of the namespace, including the handling of formatting characters, use of upper vs. lower case, etc.
     *
     * How/where is it used
     */
    usage?: string;
    /**
     * The date  (and optionally time) when the naming system was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the naming system changes.
     *
     * Date last changed
     */
    date: Date;
    /**
     * The date on which the resource content was approved by the publisher. Approval happens once when the content is officially approved for usage.
     *
     * When the NamingSystem was approved by publisher
     */
    approvalDate?: Date;
    /**
     * A copyright statement relating to the naming system and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the naming system.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * A short, descriptive, user-friendly title for the naming system.
     *
     * Title for this naming system (human friendly)
     */
    title?: string;
    /**
     * Categorizes a naming system for easier search by grouping related naming systems.
     *
     * e.g. driver,  provider,  patient, bank etc
     */
    type?: CodeableConcept;
    /**
     * A free text natural language description of the naming system from a consumer's perspective. Details about what the namespace identifies including scope, granularity, version labeling, etc.
     *
     * Natural language description of the naming system
     */
    description?: string;
    /**
     * A Boolean value to indicate that this naming system is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * The name of the organization that is responsible for issuing identifiers or codes for this namespace and ensuring their non-collision.
     *
     * Who maintains system namespace?
     */
    responsible?: string;
    /**
     * Indicates the mechanism used to compare versions to determine which NamingSystem is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * An individual or organization asserted by the publisher to be responsible for officially endorsing the NamingSystem for use in some setting.
     *
     * Who endorsed the NamingSystem
     */
    endorser?: ContactDetail[];
    /**
     * The period during which the NamingSystem content was or is planned to be in active use.
     *
     * When the NamingSystem is expected to be used
     */
    effectivePeriod?: Period;
    /**
     * Indicates the purpose for the naming system - what kinds of things does it make unique?
     *
     * codesystem | identifier | root
     */
    kind: string;
    /**
     * An individiual or organization primarily involved in the creation and maintenance of the NamingSystem.
     *
     * Who authored the CodeSystem
     */
    author?: ContactDetail[];
    /**
     * A formal identifier that is used to identify this naming system when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the naming system (business identifier)
     */
    identifier?: Identifier[];
    /**
     * An individual or organization primarily responsible for internal coherence of the NamingSystem.
     *
     * Who edited the NamingSystem
     */
    editor?: ContactDetail[];
    /**
     * Related artifacts such as additional documentation, justification, dependencies, bibliographic references, and predecessor and successor artifacts.
     *
     * Additional documentation, citations, etc
     */
    relatedArtifact?: RelatedArtifact[];
    /**
     * The identifier that is used to identify this version of the naming system when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the naming system author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the naming system
     */
    version?: string;
    /**
     * An absolute URI that is used to identify this naming system when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this naming system is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the naming system is stored on different servers.
     *
     * Canonical identifier for this naming system, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * An individual or organization asserted by the publisher to be primarily responsible for review of some aspect of the NamingSystem.
     *
     * Who reviewed the NamingSystem
     */
    reviewer?: ContactDetail[];
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * The date on which the resource content was last reviewed. Review happens periodically after approval but does not change the original approval date.
     *
     * When the NamingSystem was last reviewed by the publisher
     */
    lastReviewDate?: Date;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate naming system instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * The status of this naming system. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * Indicates how the system may be identified when referenced in electronic exchange.
     *
     * Unique identifiers used for system
     */
    uniqueId: NamingSystem.NamingSystemUniqueIdComponent[];
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the naming system.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * Descriptions related to the content of the NamingSystem. Topics provide a high-level categorization as well as keywords for the NamingSystem that can be useful for filtering and searching.
     *
     * E.g. Education, Treatment, Assessment, etc
     */
    topic?: CodeableConcept[];
    /**
     * A natural language name identifying the naming system. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this naming system (computer friendly)
     */
    name: string;
    readonly resourceType: string;
    static revive(json: any): NamingSystem;
    toJSON(): any;
}
export declare namespace NamingSystem {
    enum NamingSystemType {
        NULL,
        ROOT,
        CODESYSTEM,
        IDENTIFIER
    }
    enum NamingSystemIdentifierType {
        OTHER,
        NULL,
        IRISTEM,
        OID,
        UUID,
        V2CSMNEMONIC,
        URI
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class NamingSystemUniqueIdComponent extends BackboneElement {
        /**
         * Notes about the past or intended usage of this identifier.
         *
         * Notes about identifier usage
         */
        comment?: string;
        /**
         * Identifies the unique identifier scheme used for this particular identifier.
         *
         * oid | uuid | uri | iri-stem | v2csmnemonic | other
         */
        type: string;
        /**
         * The string that should be sent over the wire to identify the code system or identifier system.
         *
         * The unique identifier
         */
        value: string;
        /**
         * Indicates whether this identifier is the "preferred" identifier of this type.
         *
         * Is this the id that should be used for this type
         */
        preferred?: boolean;
        /**
         * Identifies the period of time over which this identifier is considered appropriate to refer to the naming system.  Outside of this window, the identifier might be non-deterministic.
         *
         * When is identifier valid?
         */
        period?: Period;
        /**
         * Indicates whether this identifier ie endorsed by the official owner of the associated naming system.
         *
         * Whether the identifier is authoritative
         */
        authoritative?: boolean;
        static revive(json: any): NamingSystemUniqueIdComponent;
        toJSON(): any;
    }
}
