import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { UsageContext } from '../datatype/usage-context';
import { CanonicalResource } from '../model/canonical-resource';
/**
 * HAPI/FHIR <b>TestScript</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/TestScript">http://hl7.org/fhir/StructureDefinition/TestScript</a>
 * </p>
 *
 */
export declare class TestScript extends CanonicalResource {
    /**
     * Reference to the profile to be used for validation.
     *
     * Reference of the validation profile
     */
    profile?: string[];
    /**
     * A test in this script.
     *
     * A test in this script
     */
    test?: TestScript.TestScriptTestComponent[];
    /**
     * A formal identifier that is used to identify this test script when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the test script
     */
    identifier?: Identifier[];
    /**
     * An absolute URI that is used to identify this test script when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this test script is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the test script is stored on different servers.
     *
     * Canonical identifier for this test script, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * The identifier that is used to identify this version of the test script when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the test script author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the test script
     */
    version?: string;
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * Fixture in the test script - by reference (uri). All fixtures are required for the test script to execute.
     *
     * Fixture in the test script - by reference (uri)
     */
    fixture?: TestScript.TestScriptFixtureComponent[];
    /**
     * The status of this test script. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate test script instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * A natural language name identifying the test script. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this test script (computer friendly)
     */
    name: string;
    /**
     * Variable is set based either on element value in response body or on header field value in the response headers.
     *
     * Placeholder for evaluated elements
     */
    variable?: TestScript.TestScriptVariableComponent[];
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the test script.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * A series of required setup operations before tests are executed.
     *
     * A series of required setup operations before tests are executed
     */
    setup?: TestScript.TestScriptSetupComponent;
    /**
     * A legal or geographic region in which the test script is intended to be used.
     *
     * Intended jurisdiction for test script (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * An abstract server used in operations within this test script in the origin element.
     *
     * An abstract server representing a client or sender in a message exchange
     */
    origin?: TestScript.TestScriptOriginComponent[];
    /**
     * Explanation of why this test script is needed and why it has been designed as it has.
     *
     * Why this test script is defined
     */
    purpose?: string;
    /**
     * A copyright statement relating to the test script and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the test script.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * The required capability must exist and are assumed to function correctly on the FHIR server being tested.
     *
     * Required capability that is assumed to function correctly on the FHIR server being tested
     */
    metadata?: TestScript.TestScriptMetadataComponent;
    /**
     * The date  (and optionally time) when the test script was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the test script changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * A short, descriptive, user-friendly title for the test script.
     *
     * Name for this test script (human friendly)
     */
    title?: string;
    /**
     * A Boolean value to indicate that this test script is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * An abstract server used in operations within this test script in the destination element.
     *
     * An abstract server representing a destination or receiver in a message exchange
     */
    destination?: TestScript.TestScriptDestinationComponent[];
    /**
     * A free text natural language description of the test script from a consumer's perspective.
     *
     * Natural language description of the test script
     */
    description?: string;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * The scope indicates a conformance artifact that is tested by the test(s) within this test case and the expectation of the test outcome(s) as well as the intended test phase inclusion.
     *
     * Indication of the artifact(s) that are tested by this test case
     */
    scope?: TestScript.TestScriptScopeComponent[];
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * A series of operations required to clean up after all the tests are executed (successfully or otherwise).
     *
     * A series of required clean up steps
     */
    teardown?: TestScript.TestScriptTeardownComponent;
    readonly resourceType: string;
    static revive(json: any): TestScript;
    toJSON(): any;
}
export declare namespace TestScript {
    enum TestScriptRequestMethodCode {
        HEAD,
        DELETE,
        NULL,
        POST,
        GET,
        OPTIONS,
        PATCH,
        PUT
    }
    enum AssertionResponseTypes {
        CONFLICT,
        NOTACCEPTABLE,
        LENGTHREQUIRED,
        NONAUTHORITATIVEINFORMATION,
        PAYMENTREQUIRED,
        INTERNALSERVERERROR,
        EXPECTATIONFAILED,
        PERMANENTREDIRECT,
        CREATED,
        GATEWAYTIMEOUT,
        ACCEPTED,
        SEEOTHER,
        BADREQUEST,
        HTTPVERSIONNOTSUPPORTED,
        UNAUTHORIZED,
        PROXYAUTHENTICATIONREQUIRED,
        CONTENTTOOLARGE,
        METHODNOTALLOWED,
        MULTIPLECHOICES,
        MISDIRECTEDREQUEST,
        FOUND,
        UNSUPPORTEDMEDIATYPE,
        UNPROCESSABLECONTENT,
        NOCONTENT,
        RANGENOTSATISFIABLE,
        SERVICEUNAVAILABLE,
        NULL,
        MOVEDPERMANENTLY,
        PARTIALCONTENT,
        REQUESTTIMEOUT,
        FORBIDDEN,
        CONTINUE,
        OKAY,
        NOTFOUND,
        USEPROXY,
        NOTIMPLEMENTED,
        RESETCONTENT,
        UPGRADEREQUIRED,
        SWITCHINGPROTOCOLS,
        BADGATEWAY,
        TEMPORARYREDIRECT,
        NOTMODIFIED,
        GONE,
        PRECONDITIONFAILED,
        URITOOLONG
    }
    enum AssertionOperatorType {
        NULL,
        EQUALS,
        IN,
        NOTIN,
        CONTAINS,
        NOTEQUALS,
        NOTCONTAINS,
        NOTEMPTY,
        LESSTHAN,
        EVAL,
        GREATERTHAN,
        EMPTY,
        MANUALEVAL
    }
    enum AssertionManualCompletionType {
        NULL,
        PASS,
        STOP,
        SKIP,
        FAIL
    }
    enum AssertionDirectionType {
        NULL,
        REQUEST,
        RESPONSE
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class TeardownActionComponent extends BackboneElement {
        /**
         * An operation would involve a REST request to a server.
         *
         * The teardown operation to perform
         */
        operation: TestScript.SetupActionOperationComponent;
        static revive(json: any): TeardownActionComponent;
        toJSON(): any;
    }
    class TestScriptTeardownComponent extends BackboneElement {
        /**
         * The teardown action will only contain an operation.
         *
         * One or more teardown operations to perform
         */
        action: TestScript.TeardownActionComponent[];
        static revive(json: any): TestScriptTeardownComponent;
        toJSON(): any;
    }
    class TestActionComponent extends BackboneElement {
        /**
         * An operation would involve a REST request to a server.
         *
         * The setup operation to perform
         */
        operation?: TestScript.SetupActionOperationComponent;
        /**
         * Evaluates the results of previous operations to determine if the server under test behaves appropriately.
         *
         * The setup assertion to perform
         */
        assert?: TestScript.SetupActionAssertComponent;
        static revive(json: any): TestActionComponent;
        toJSON(): any;
    }
    class TestScriptTestComponent extends BackboneElement {
        /**
         * A short description of the test used by test engines for tracking and reporting purposes.
         *
         * Tracking/reporting short description of the test
         */
        description?: string;
        /**
         * Action would contain either an operation or an assertion.
         *
         * A test operation or assert to perform
         */
        action: TestScript.TestActionComponent[];
        /**
         * The name of this test used for tracking/logging purposes by test engines.
         *
         * Tracking/logging name of this test
         */
        name?: string;
        static revive(json: any): TestScriptTestComponent;
        toJSON(): any;
    }
    class SetupActionAssertRequirementComponent extends BackboneElement {
        /**
         * Link or reference providing traceability to the testing requirement for this test.
         *
         * Link or reference to the testing requirement
         */
        link?: string;
        static revive(json: any): SetupActionAssertRequirementComponent;
        toJSON(): any;
    }
    class SetupActionAssertComponent extends BackboneElement {
        /**
         * The request method or HTTP operation code to compare against that used by the client system under test.
         *
         * delete | get | options | patch | post | put | head
         */
        requestMethod?: string;
        /**
         * The ID of a fixture. Asserts that the response contains at a minimum the fixture specified by minimumId.
         *
         * Fixture Id of minimum content resource
         */
        minimumId?: string;
        /**
         * The HTTP header field name e.g. 'Location'.
         *
         * HTTP header field name
         */
        headerField?: string;
        /**
         * Fixture to evaluate the XPath/JSONPath expression or the headerField  against.
         *
         * Fixture Id of source expression or headerField
         */
        sourceId?: string;
        /**
         * The value of the HTTP response code to be tested.
         *
         * HTTP response code to test
         */
        responseCode?: string;
        /**
         * The operator type defines the conditional behavior of the assert.
         *
         * equals | notEquals | in | notIn | greaterThan | lessThan | empty | notEmpty | contains | notContains | eval | manualEval
         */
        operator?: string;
        /**
         * The description would be used by test engines for tracking and reporting purposes.
         *
         * Tracking/reporting assertion description
         */
        description?: string;
        /**
         * Whether or not the current test execution will stop on failure for this assert.
         *
         * If this assert fails, will the current test execution stop?
         */
        stopTestOnFail: boolean;
        /**
         * The value to use in a comparison against the request URL path string.
         *
         * Request URL comparison value
         */
        requestURL?: string;
        /**
         * The XPath or JSONPath expression to be evaluated against the fixture representing the response received from server.
         *
         * XPath or JSONPath expression
         */
        path?: string;
        /**
         * The direction to use for the assertion.
         *
         * response | request
         */
        direction?: string;
        /**
         * The mime-type contents to compare against the request or response message 'Content-Type' header.
         *
         * Mime type to compare against the 'Content-Type' header
         */
        contentType?: string;
        /**
         * The value to compare to.
         *
         * The value to compare to
         */
        value?: string;
        /**
         * The ID of the Profile to validate against.
         *
         * Profile Id of validation profile reference
         */
        validateProfileId?: string;
        /**
         * XPath or JSONPath expression to evaluate against the source fixture. When compareToSourceId is defined, either compareToSourceExpression or compareToSourcePath must be defined, but not both.
         *
         * XPath or JSONPath expression to evaluate against the source fixture
         */
        compareToSourcePath?: string;
        /**
         * The type of the resource.  See the [resource list](resourcelist.html).
         *
         * Resource type
         */
        resource?: string;
        /**
         * The FHIRPath expression to be evaluated against the request or response message contents - HTTP headers and payload.
         *
         * The FHIRPath expression to be evaluated
         */
        expression?: string;
        /**
         * Id of the source fixture used as the contents to be evaluated by either the "source/expression" or "sourceId/path" definition.
         *
         * Id of the source fixture to be evaluated
         */
        compareToSourceId?: string;
        /**
         * The FHIRPath expression for a specific value to evaluate against the source fixture. When compareToSourceId is defined, either compareToSourceExpression or compareToSourcePath must be defined, but not both.
         *
         * The FHIRPath expression to evaluate against the source fixture
         */
        compareToSourceExpression?: string;
        /**
         * The label would be used for tracking/logging purposes by test engines.
         *
         * Tracking/logging assertion label
         */
        label?: string;
        /**
         * Links or references providing traceability to the testing requirements for this assert.
         *
         * Links or references to the testing requirements
         */
        requirement?: TestScript.SetupActionAssertRequirementComponent[];
        /**
         * The default manual completion outcome applied to this assertion.
         *
         * fail | pass | skip | stop
         */
        defaultManualCompletion?: string;
        /**
         * continue | switchingProtocols | okay | created | accepted | nonAuthoritativeInformation | noContent | resetContent | partialContent | multipleChoices | movedPermanently | found | seeOther | notModified | useProxy | temporaryRedirect | permanentRedirect | badRequest | unauthorized | paymentRequired | forbidden | notFound | methodNotAllowed | notAcceptable | proxyAuthenticationRequired | requestTimeout | conflict | gone | lengthRequired | preconditionFailed | contentTooLarge | uriTooLong | unsupportedMediaType | rangeNotSatisfiable | expectationFailed | misdirectedRequest | unprocessableContent | upgradeRequired | internalServerError | notImplemented | badGateway | serviceUnavailable | gatewayTimeout | httpVersionNotSupported.
         *
         * continue | switchingProtocols | okay | created | accepted | nonAuthoritativeInformation | noContent | resetContent | partialContent | multipleChoices | movedPermanently | found | seeOther | notModified | useProxy | temporaryRedirect | permanentRedirect | badRequest | unauthorized | paymentRequired | forbidden | notFound | methodNotAllowed | notAcceptable | proxyAuthenticationRequired | requestTimeout | conflict | gone | lengthRequired | preconditionFailed | contentTooLarge | uriTooLong | unsupportedMediaType | rangeNotSatisfiable | expectationFailed | misdirectedRequest | unprocessableContent | upgradeRequired | internalServerError | notImplemented | badGateway | serviceUnavailable | gatewayTimeout | httpVersionNotSupported
         */
        response?: string;
        /**
         * Whether or not the test execution performs validation on the bundle navigation links.
         *
         * Perform validation on navigation links?
         */
        navigationLinks?: boolean;
        /**
         * Whether or not the test execution will produce a warning only on error for this assert.
         *
         * Will this assert produce a warning only on error?
         */
        warningOnly: boolean;
        static revive(json: any): SetupActionAssertComponent;
        toJSON(): any;
    }
    class SetupActionOperationRequestHeaderComponent extends BackboneElement {
        /**
         * The value of the header e.g. "application/fhir+xml".
         *
         * HTTP headerfield value
         */
        value: string;
        /**
         * The HTTP header field e.g. "Accept".
         *
         * HTTP header field name
         */
        field: string;
        static revive(json: any): SetupActionOperationRequestHeaderComponent;
        toJSON(): any;
    }
    class SetupActionOperationComponent extends BackboneElement {
        /**
         * The server where the request message is destined for.  Must be one of the server numbers listed in TestScript.destination section.
         *
         * Server responding to the request
         */
        destination?: number;
        /**
         * The description would be used by test engines for tracking and reporting purposes.
         *
         * Tracking/reporting operation description
         */
        description?: string;
        /**
         * The label would be used for tracking/logging purposes by test engines.
         *
         * Tracking/logging operation label
         */
        label?: string;
        /**
         * Server interaction or operation type.
         *
         * The operation code type that will be executed
         */
        type?: Coding;
        /**
         * Path plus parameters after [type].  Used to set parts of the request URL explicitly.
         *
         * Explicitly defined path parameters
         */
        params?: string;
        /**
         * Complete request URL.
         *
         * Request URL
         */
        url?: string;
        /**
         * The mime-type to use for RESTful operation in the 'Accept' header.
         *
         * Mime type to accept in the payload of the response, with charset etc
         */
        accept?: string;
        /**
         * The id of the fixture used as the body of a PUT or POST request.
         *
         * Fixture Id of body for PUT and POST requests
         */
        sourceId?: string;
        /**
         * The HTTP method the test engine MUST use for this operation regardless of any other operation details.
         *
         * delete | get | options | patch | post | put | head
         */
        method?: string;
        /**
         * Id of fixture used for extracting the [id],  [type], and [vid] for GET requests.
         *
         * Id of fixture used for extracting the [id],  [type], and [vid] for GET requests
         */
        targetId?: string;
        /**
         * The type of the FHIR resource. See the [resource list](resourcelist.html). Data type of uri is needed when non-HL7 artifacts are identified.
         *
         * Resource type
         */
        resource?: string;
        /**
         * Whether or not to implicitly send the request url in encoded format. The default is true to match the standard RESTful client behavior. Set to false when communicating with a server that does not support encoded url paths.
         *
         * Whether or not to send the request url in encoded format
         */
        encodeRequestUrl: boolean;
        /**
         * The server where the request message originates from.  Must be one of the server numbers listed in TestScript.origin section.
         *
         * Server initiating the request
         */
        origin?: number;
        /**
         * Header elements would be used to set HTTP headers.
         *
         * Each operation can have one or more header elements
         */
        requestHeader?: TestScript.SetupActionOperationRequestHeaderComponent[];
        /**
         * The mime-type to use for RESTful operation in the 'Content-Type' header.
         *
         * Mime type of the request payload contents, with charset etc
         */
        contentType?: string;
        /**
         * The fixture id (maybe new) to map to the response.
         *
         * Fixture Id of mapped response
         */
        responseId?: string;
        /**
         * The fixture id (maybe new) to map to the request.
         *
         * Fixture Id of mapped request
         */
        requestId?: string;
        static revive(json: any): SetupActionOperationComponent;
        toJSON(): any;
    }
    class SetupActionComponent extends BackboneElement {
        /**
         * The operation to perform.
         *
         * The setup operation to perform
         */
        operation?: TestScript.SetupActionOperationComponent;
        /**
         * Evaluates the results of previous operations to determine if the server under test behaves appropriately.
         *
         * The assertion to perform
         */
        assert?: TestScript.SetupActionAssertComponent;
        static revive(json: any): SetupActionComponent;
        toJSON(): any;
    }
    class TestScriptSetupComponent extends BackboneElement {
        /**
         * Action would contain either an operation or an assertion.
         *
         * A setup operation or assert to perform
         */
        action: TestScript.SetupActionComponent[];
        static revive(json: any): TestScriptSetupComponent;
        toJSON(): any;
    }
    class TestScriptVariableComponent extends BackboneElement {
        /**
         * Descriptive name for this variable.
         *
         * Descriptive name for this variable
         */
        name: string;
        /**
         * A free text natural language description of the variable and its purpose.
         *
         * Natural language description of the variable
         */
        description?: string;
        /**
         * A default, hard-coded, or user-defined value for this variable.
         *
         * Default, hard-coded, or user-defined value for this variable
         */
        defaultValue?: string;
        /**
         * Displayable text string with hint help information to the user when entering a default value.
         *
         * Hint help text for default value to enter
         */
        hint?: string;
        /**
         * Will be used to grab the HTTP header field value from the headers that sourceId is pointing to.
         *
         * HTTP header field name for source
         */
        headerField?: string;
        /**
         * The FHIRPath expression for a specific value to evaluate against the fixture body. When variables are defined, only one of either expression, headerField or path must be specified.
         *
         * The FHIRPath expression against the fixture body
         */
        expression?: string;
        /**
         * Fixture to evaluate the XPath/JSONPath expression or the headerField  against within this variable.
         *
         * Fixture Id of source expression or headerField within this variable
         */
        sourceId?: string;
        /**
         * XPath or JSONPath to evaluate against the fixture body.  When variables are defined, only one of either expression, headerField or path must be specified.
         *
         * XPath or JSONPath against the fixture body
         */
        path?: string;
        static revive(json: any): TestScriptVariableComponent;
        toJSON(): any;
    }
    class TestScriptFixtureComponent extends BackboneElement {
        /**
         * Whether or not to implicitly create the fixture during setup. If true, the fixture is automatically created on each server being tested during setup, therefore no create operation is required for this fixture in the TestScript.setup section.
         *
         * Whether or not to implicitly create the fixture during setup
         */
        autocreate: boolean;
        /**
         * Whether or not to implicitly delete the fixture during teardown. If true, the fixture is automatically deleted on each server being tested during teardown, therefore no delete operation is required for this fixture in the TestScript.teardown section.
         *
         * Whether or not to implicitly delete the fixture during teardown
         */
        autodelete: boolean;
        /**
         * Reference to the resource (containing the contents of the resource needed for operations). This is allowed to be a Parameters resource.
         *
         * Reference of the resource
         */
        resource?: Reference;
        static revive(json: any): TestScriptFixtureComponent;
        toJSON(): any;
    }
    class TestScriptScopeComponent extends BackboneElement {
        /**
         * The expectation of whether the test must pass for the system to be considered conformant with the artifact: required - all tests are expected to pass, optional - all test are expected to pass but non-pass status may be allowed, strict - all tests are expected to pass and warnings are treated as a failure.
         *
         * required | optional | strict
         */
        conformance?: CodeableConcept;
        /**
         * The specific conformance artifact being tested. The canonical reference can be version-specific.
         *
         * The specific conformance artifact being tested
         */
        artifact: string;
        /**
         * The phase of testing for this artifact: unit - development / implementation phase, integration - internal system to system phase, production - live system to system phase (Note, this may involve pii/phi data).
         *
         * unit | integration | production
         */
        phase?: CodeableConcept;
        static revive(json: any): TestScriptScopeComponent;
        toJSON(): any;
    }
    class TestScriptMetadataCapabilityComponent extends BackboneElement {
        /**
         * Which origin server these requirements apply to.
         *
         * Which origin server these requirements apply to
         */
        origin?: number[];
        /**
         * Whether or not the test execution will validate the given capabilities of the server in order for this test script to execute.
         *
         * Are the capabilities validated?
         */
        validated: boolean;
        /**
         * Minimum capabilities required of server for test script to execute successfully.   If server does not meet at a minimum the referenced capability statement, then all tests in this script are skipped.
         *
         * Required Capability Statement
         */
        capabilities: string;
        /**
         * Whether or not the test execution will require the given capabilities of the server in order for this test script to execute.
         *
         * Are the capabilities required?
         */
        required: boolean;
        /**
         * Description of the capabilities that this test script is requiring the server to support.
         *
         * The expected capabilities of the server
         */
        description?: string;
        /**
         * Which server these requirements apply to.
         *
         * Which server these requirements apply to
         */
        destination?: number;
        /**
         * Links to the FHIR specification that describes this interaction and the resources involved in more detail.
         *
         * Links to the FHIR specification
         */
        link?: string[];
        static revive(json: any): TestScriptMetadataCapabilityComponent;
        toJSON(): any;
    }
    class TestScriptMetadataLinkComponent extends BackboneElement {
        /**
         * URL to a particular requirement or feature within the FHIR specification.
         *
         * URL to the specification
         */
        url: string;
        /**
         * Short description of the link.
         *
         * Short description
         */
        description?: string;
        static revive(json: any): TestScriptMetadataLinkComponent;
        toJSON(): any;
    }
    class TestScriptMetadataComponent extends BackboneElement {
        /**
         * A link to the FHIR specification that this test is covering.
         *
         * Links to the FHIR specification
         */
        link?: TestScript.TestScriptMetadataLinkComponent[];
        /**
         * Capabilities that must exist and are assumed to function correctly on the FHIR server being tested.
         *
         * Capabilities  that are assumed to function correctly on the FHIR server being tested
         */
        capability: TestScript.TestScriptMetadataCapabilityComponent[];
        static revive(json: any): TestScriptMetadataComponent;
        toJSON(): any;
    }
    class TestScriptDestinationComponent extends BackboneElement {
        /**
         * The explicit url path of the destination server used in this test script.
         *
         * The url path of the destination server
         */
        url?: string;
        /**
         * Abstract name given to a destination server in this test script.  The name is provided as a number starting at 1.
         *
         * The index of the abstract destination server starting at 1
         */
        index: number;
        /**
         * The type of destination profile the test system supports.
         *
         * FHIR-Server | FHIR-SDC-FormManager | FHIR-SDC-FormReceiver | FHIR-SDC-FormProcessor
         */
        profile: Coding;
        static revive(json: any): TestScriptDestinationComponent;
        toJSON(): any;
    }
    class TestScriptOriginComponent extends BackboneElement {
        /**
         * The type of origin profile the test system supports.
         *
         * FHIR-Client | FHIR-SDC-FormFiller
         */
        profile: Coding;
        /**
         * Abstract name given to an origin server in this test script.  The name is provided as a number starting at 1.
         *
         * The index of the abstract origin server starting at 1
         */
        index: number;
        /**
         * The explicit url path of the origin server used in this test script.
         *
         * The url path of the origin server
         */
        url?: string;
        static revive(json: any): TestScriptOriginComponent;
        toJSON(): any;
    }
}
