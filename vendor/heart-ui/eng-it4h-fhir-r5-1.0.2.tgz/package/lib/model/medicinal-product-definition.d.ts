import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Coding } from '../datatype/coding';
import { Identifier } from '../datatype/identifier';
import { MarketingStatus } from '../datatype/marketing-status';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { DeviceDefinition } from '../model/device-definition';
import { DocumentReference } from '../model/document-reference';
import { DomainResource } from '../model/domain-resource';
import { ManufacturedItemDefinition } from '../model/manufactured-item-definition';
import { Organization } from '../model/organization';
import { PractitionerRole } from '../model/practitioner-role';
import { ResearchStudy } from '../model/research-study';
/**
 * HAPI/FHIR <b>MedicinalProductDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/MedicinalProductDefinition">http://hl7.org/fhir/StructureDefinition/MedicinalProductDefinition</a>
 * </p>
 *
 */
export declare class MedicinalProductDefinition extends DomainResource {
    /**
     * Business identifier for this product. Could be an MPID. When in development or being regulated, products are typically referenced by official identifiers, assigned by a manufacturer or regulator, and unique to a product (which, when compared to a product instance being prescribed, is actually a product type). See also MedicinalProductDefinition.code.
     *
     * Business identifier for this product. Could be an MPID
     */
    identifier?: Identifier[];
    /**
     * The ingredients of this medicinal product - when not detailed in other resources. This is only needed if the ingredients are not specified by incoming references from the Ingredient resource, or indirectly via incoming AdministrableProductDefinition, PackagedProductDefinition or ManufacturedItemDefinition references. In cases where those levels of detail are not used, the ingredients may be specified directly here as codes.
     *
     * The ingredients of this medicinal product - when not detailed in other resources
     */
    ingredient?: CodeableConcept[];
    /**
     * Whether the Medicinal Product is subject to additional monitoring for regulatory reasons, such as heightened reporting requirements.
     *
     * Whether the Medicinal Product is subject to additional monitoring for regulatory reasons
     */
    additionalMonitoringIndicator?: CodeableConcept;
    /**
     * Types of medicinal manufactured items and/or devices that this product consists of, such as tablets, capsule, or syringes. Used as a direct link when the item's packaging is not being recorded (see also PackagedProductDefinition.package.containedItem.item).
     *
     * Types of medicinal manufactured items and/or devices that this product consists of, such as tablets, capsule, or syringes
     */
    comprisedOf?: ManufacturedItemDefinition[] | DeviceDefinition[] | Reference[];
    /**
     * A business identifier relating to a specific version of the product, this is commonly used to support revisions to an existing product.
     *
     * A business identifier relating to a specific version of the product
     */
    version?: string;
    /**
     * Allows the product to be classified by various systems, commonly WHO ATC.
     *
     * Allows the product to be classified by various systems
     */
    classification?: CodeableConcept[];
    /**
     * Package type for the product. See also the PackagedProductDefinition resource.
     *
     * Package type for the product
     */
    packagedMedicinalProduct?: CodeableConcept[];
    /**
     * Whether the Medicinal Product is subject to special measures for regulatory reasons, such as a requirement to conduct post-authorization studies.
     *
     * Whether the Medicinal Product is subject to special measures for regulatory reasons
     */
    specialMeasures?: CodeableConcept[];
    /**
     * The path by which the product is taken into or makes contact with the body. In some regions this is referred to as the licenced or approved route. See also AdministrableProductDefinition resource. MedicinalProductDefinition.route is the same concept as AdministrableProductDefinition.routeOfAdministration.code, and they cannot be used together.
     *
     * The path by which the product is taken into or makes contact with the body
     */
    route?: CodeableConcept[];
    /**
     * The legal status of supply of the medicinal product as classified by the regulator.
     *
     * The legal status of supply of the medicinal product as classified by the regulator
     */
    legalStatusOfSupply?: CodeableConcept;
    /**
     * If this medicine applies to human or veterinary uses.
     *
     * If this medicine applies to human or veterinary uses
     */
    domain?: CodeableConcept;
    /**
     * The product's name, including full name and possibly coded parts.
     *
     * The product's name, including full name and possibly coded parts
     */
    name: MedicinalProductDefinition.MedicinalProductDefinitionNameComponent[];
    /**
     * Description of indication(s) for this product, used when structured indications are not required. In cases where structured indications are required, they are captured using the ClinicalUseDefinition resource. An indication is a medical situation for which using the product is appropriate.
     *
     * Description of indication(s) for this product, used when structured indications are not required
     */
    indication?: string;
    /**
     * A manufacturing or administrative process or step associated with (or performed on) the medicinal product.
     *
     * A manufacturing or administrative process for the medicinal product
     */
    operation?: MedicinalProductDefinition.MedicinalProductDefinitionOperationComponent[];
    /**
     * The status within the lifecycle of this product record. A high-level status, this is not intended to duplicate details carried elsewhere such as legal status, or authorization status.
     *
     * The status within the lifecycle of this product record
     */
    status?: CodeableConcept;
    /**
     * The dose form for a single part product, or combined form of a multiple part product. This is one concept that describes all the components. It does not represent the form with components physically mixed, if that might be necessary, for which see (AdministrableProductDefinition.administrableDoseForm).
     *
     * The dose form for a single part product, or combined form of a multiple part product
     */
    combinedPharmaceuticalDoseForm?: CodeableConcept;
    /**
     * Clinical trials or studies that this product is involved in.
     *
     * Clinical trials or studies that this product is involved in
     */
    clinicalTrial?: ResearchStudy[] | Reference[];
    /**
     * The date at which the given status became applicable.
     *
     * The date at which the given status became applicable
     */
    statusDate?: Date;
    /**
     * A code that this product is known by, usually within some formal terminology, perhaps assigned by a third party (i.e. not the manufacturer or regulator). Products (types of medications) tend to be known by identifiers during development and within regulatory process. However when they are prescribed they tend to be identified by codes. The same product may be have multiple codes, applied to it by multiple organizations.
     *
     * A code that this product is known by, within some formal terminology
     */
    code?: Coding[];
    /**
     * Any component of the drug product which is not the chemical entity defined as the drug substance, or an excipient in the drug product. This includes process-related impurities and contaminants, product-related impurities including degradation products.
     *
     * Any component of the drug product which is not the chemical entity defined as the drug substance, or an excipient in the drug product
     */
    impurity?: CodeableReference[];
    /**
     * Additional information or supporting documentation about the medicinal product.
     *
     * Additional documentation about the medicinal product
     */
    attachedDocument?: DocumentReference[] | Reference[];
    /**
     * Reference to another product, e.g. for linking authorised to investigational product, or a virtual product.
     *
     * Reference to another product, e.g. for linking authorised to investigational product
     */
    crossReference?: MedicinalProductDefinition.MedicinalProductDefinitionCrossReferenceComponent[];
    /**
     * General description of this product.
     *
     * General description of this product
     */
    description?: string;
    /**
     * If authorised for use in children, or infants, neonates etc.
     *
     * If authorised for use in children
     */
    pediatricUseIndicator?: CodeableConcept;
    /**
     * Regulatory type, e.g. Investigational or Authorized.
     *
     * Regulatory type, e.g. Investigational or Authorized
     */
    type?: CodeableConcept;
    /**
     * Marketing status of the medicinal product, in contrast to marketing authorization. This refers to the product being actually 'on the market' as opposed to being allowed to be on the market (which is an authorization).
     *
     * Marketing status of the medicinal product, in contrast to marketing authorization
     */
    marketingStatus?: MarketingStatus[];
    /**
     * Allows the key product features to be recorded, such as "sugar free", "modified release", "parallel import".
     *
     * Key product features such as "sugar free", "modified release"
     */
    characteristic?: MedicinalProductDefinition.MedicinalProductDefinitionCharacteristicComponent[];
    /**
     * A master file for the medicinal product (e.g. Pharmacovigilance System Master File). Drug master files (DMFs) are documents submitted to regulatory agencies to provide confidential detailed information about facilities, processes or articles used in the manufacturing, processing, packaging and storing of drug products.
     *
     * A master file for the medicinal product (e.g. Pharmacovigilance System Master File)
     */
    masterFile?: DocumentReference[] | Reference[];
    /**
     * A product specific contact, person (in a role), or an organization.
     *
     * A product specific contact, person (in a role), or an organization
     */
    contact?: MedicinalProductDefinition.MedicinalProductDefinitionContactComponent[];
    readonly resourceType: string;
    static revive(json: any): MedicinalProductDefinition;
    toJSON(): any;
}
export declare namespace MedicinalProductDefinition {
    class MedicinalProductDefinitionCharacteristicComponent extends BackboneElement {
        /**
         * A code expressing the type of characteristic.
         *
         * A code expressing the type of characteristic
         */
        type: CodeableConcept;
        /**
         * A value for the characteristic.text.
         *
         * A value for the characteristic
         */
        value?: CodeableConcept | string | Quantity | number | Date | boolean | Attachment;
        static revive(json: any): MedicinalProductDefinitionCharacteristicComponent;
        toJSON(): any;
    }
    class MedicinalProductDefinitionOperationComponent extends BackboneElement {
        /**
         * The type of manufacturing operation e.g. manufacturing itself, re-packaging. For the authorization of this, a RegulatedAuthorization would point to the same plan or activity referenced here.
         *
         * The type of manufacturing operation e.g. manufacturing itself, re-packaging
         */
        type?: CodeableReference;
        /**
         * Date range of applicability.
         *
         * Date range of applicability
         */
        effectiveDate?: Period;
        /**
         * The organization or establishment responsible for (or associated with) the particular process or step, examples include the manufacturer, importer, agent.
         *
         * The organization responsible for the particular process, e.g. the manufacturer or importer
         */
        organization?: Organization[] | Reference[];
        /**
         * Specifies whether this particular business or manufacturing process is considered proprietary or confidential.
         *
         * Specifies whether this process is considered proprietary or confidential
         */
        confidentialityIndicator?: CodeableConcept;
        static revive(json: any): MedicinalProductDefinitionOperationComponent;
        toJSON(): any;
    }
    class MedicinalProductDefinitionCrossReferenceComponent extends BackboneElement {
        /**
         * The type of relationship, for instance branded to generic, virtual to actual product, product to development product (investigational), parallel import version.
         *
         * The type of relationship, for instance branded to generic or virtual to actual product
         */
        type?: CodeableConcept;
        /**
         * Reference to another product, e.g. for linking authorised to investigational product.
         *
         * Reference to another product, e.g. for linking authorised to investigational product
         */
        product: CodeableReference;
        static revive(json: any): MedicinalProductDefinitionCrossReferenceComponent;
        toJSON(): any;
    }
    class MedicinalProductDefinitionNameUsageComponent extends BackboneElement {
        /**
         * Country code for where this name applies.
         *
         * Country code for where this name applies
         */
        country: CodeableConcept;
        /**
         * Jurisdiction code for where this name applies. A jurisdiction may be a sub- or supra-national entity (e.g. a state or a geographic region).
         *
         * Jurisdiction code for where this name applies
         */
        jurisdiction?: CodeableConcept;
        /**
         * Language code for this name.
         *
         * Language code for this name
         */
        language: CodeableConcept;
        static revive(json: any): MedicinalProductDefinitionNameUsageComponent;
        toJSON(): any;
    }
    class MedicinalProductDefinitionNamePartComponent extends BackboneElement {
        /**
         * Identifying type for this part of the name (e.g. strength part).
         *
         * Identifying type for this part of the name (e.g. strength part)
         */
        type: CodeableConcept;
        /**
         * A fragment of a product name.
         *
         * A fragment of a product name
         */
        part: string;
        static revive(json: any): MedicinalProductDefinitionNamePartComponent;
        toJSON(): any;
    }
    class MedicinalProductDefinitionNameComponent extends BackboneElement {
        /**
         * Type of product name, such as rINN, BAN, Proprietary, Non-Proprietary.
         *
         * Type of product name, such as rINN, BAN, Proprietary, Non-Proprietary
         */
        type?: CodeableConcept;
        /**
         * The full product name.
         *
         * The full product name
         */
        productName: string;
        /**
         * Coding words or phrases of the name.
         *
         * Coding words or phrases of the name
         */
        part?: MedicinalProductDefinition.MedicinalProductDefinitionNamePartComponent[];
        /**
         * Country and jurisdiction where the name applies, and associated language.
         *
         * Country and jurisdiction where the name applies
         */
        usage?: MedicinalProductDefinition.MedicinalProductDefinitionNameUsageComponent[];
        static revive(json: any): MedicinalProductDefinitionNameComponent;
        toJSON(): any;
    }
    class MedicinalProductDefinitionContactComponent extends BackboneElement {
        /**
         * Allows the contact to be classified, for example QPPV, Pharmacovigilance Enquiry Information.
         *
         * Allows the contact to be classified, for example QPPV, Pharmacovigilance Enquiry Information
         */
        type?: CodeableConcept;
        /**
         * A product specific contact, person (in a role), or an organization.
         *
         * A product specific contact, person (in a role), or an organization
         */
        contact: Organization | PractitionerRole | Reference;
        static revive(json: any): MedicinalProductDefinitionContactComponent;
        toJSON(): any;
    }
}
