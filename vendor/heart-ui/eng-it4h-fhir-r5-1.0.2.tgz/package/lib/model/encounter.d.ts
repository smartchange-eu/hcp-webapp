import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Duration } from '../datatype/duration';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { VirtualServiceDetail } from '../datatype/virtual-service-detail';
import { Account } from '../model/account';
import { Appointment } from '../model/appointment';
import { CarePlan } from '../model/care-plan';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DeviceRequest } from '../model/device-request';
import { DomainResource } from '../model/domain-resource';
import { EpisodeOfCare } from '../model/episode-of-care';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { Location } from '../model/location';
import { MedicationRequest } from '../model/medication-request';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
import { ServiceRequest } from '../model/service-request';
/**
 * HAPI/FHIR <b>Encounter</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Encounter">http://hl7.org/fhir/StructureDefinition/Encounter</a>
 * </p>
 *
 */
export declare class Encounter extends DomainResource {
    /**
     * List of locations where  the patient has been during this encounter.
     *
     * List of locations where the patient has been
     */
    location?: Encounter.EncounterLocationComponent[];
    /**
     * The organization that is primarily responsible for this Encounter's services. This MAY be the same as the organization on the Patient record, however it could be different, such as if the actor performing the services was from an external organization (which may be billed seperately) for an external consultation.  Refer to the colonoscopy example on the Encounter examples tab.
     *
     * The organization (facility) responsible for this encounter
     */
    serviceProvider?: Organization | Reference;
    /**
     * The set of accounts that may be used for billing for this Encounter.
     *
     * The set of accounts that may be used for billing for this Encounter
     */
    account?: Account[] | Reference[];
    /**
     * The current state of the encounter (not the state of the patient within the encounter - that is subjectState).
     *
     * planned | in-progress | on-hold | discharged | completed | cancelled | discontinued | entered-in-error | unknown
     */
    status: string;
    /**
     * The planned start date/time (or admission date) of the encounter.
     *
     * The planned start date/time (or admission date) of the encounter
     */
    plannedStartDate?: Date;
    /**
     * Details about the stay during which a healthcare service is provided.

This does not describe the event of admitting the patient, but rather any information that is relevant from the time of admittance until the time of discharge.
     *
     * Details about the admission to a healthcare service
     */
    admission?: Encounter.EncounterAdmissionComponent;
    /**
     * Concepts representing classification of patient encounter such as ambulatory (outpatient), inpatient, emergency, home health or others due to local variations.
     *
     * Classification of patient encounter context - e.g. Inpatient, outpatient
     */
    class?: CodeableConcept[];
    /**
     * Actual quantity of time the encounter lasted. This excludes the time during leaves of absence.

When missing it is the time in between the start and end values.
     *
     * Actual quantity of time the encounter lasted (less time absent)
     */
    length?: Duration;
    /**
     * The list of diagnosis relevant to this encounter.
     *
     * The list of diagnosis relevant to this encounter
     */
    diagnosis?: Encounter.DiagnosisComponent[];
    /**
     * Indicates the urgency of the encounter.
     *
     * Indicates the urgency of the encounter
     */
    priority?: CodeableConcept;
    /**
     * Identifier(s) by which this encounter is known.
     *
     * Identifier(s) by which this encounter is known
     */
    identifier?: Identifier[];
    /**
     * The subjectStatus value can be used to track the patient's status within the encounter. It details whether the patient has arrived or departed, has been triaged or is currently in a waiting status.
     *
     * The current status of the subject in relation to the Encounter
     */
    subjectStatus?: CodeableConcept;
    /**
     * The actual start and end time of the encounter.
     *
     * The actual start and end time of the encounter
     */
    actualPeriod?: Period;
    /**
     * Special courtesies that may be provided to the patient during the encounter (VIP, board member, professional courtesy).
     *
     * Special courtesies (VIP, board member)
     */
    specialCourtesy?: CodeableConcept[];
    /**
     * Where a specific encounter should be classified as a part of a specific episode(s) of care this field should be used. This association can facilitate grouping of related encounters together for a specific purpose, such as government reporting, issue tracking, association via a common problem.  The association is recorded on the encounter as these are typically created after the episode of care and grouped on entry rather than editing the episode of care to append another encounter to it (the episode of care could span years).
     *
     * Episode(s) of care that this encounter should be recorded against
     */
    episodeOfCare?: EpisodeOfCare[] | Reference[];
    /**
     * The request this encounter satisfies (e.g. incoming referral or procedure request).
     *
     * The request that initiated this encounter
     */
    basedOn?: CarePlan[] | DeviceRequest[] | MedicationRequest[] | ServiceRequest[] | Reference[];
    /**
     * The group(s) of individuals, organizations that are allocated to participate in this encounter. The participants backbone will record the actuals of when these individuals participated during the encounter.
     *
     * The group(s) that are allocated to participate in this encounter
     */
    careTeam?: CareTeam[] | Reference[];
    /**
     * The appointment that scheduled this encounter.
     *
     * The appointment that scheduled this encounter
     */
    appointment?: Appointment[] | Reference[];
    /**
     * Diet preferences reported by the patient.
     *
     * Diet preferences reported by the patient
     */
    dietPreference?: CodeableConcept[];
    /**
     * The list of people responsible for providing the service.
     *
     * List of participants involved in the encounter
     */
    participant?: Encounter.EncounterParticipantComponent[];
    /**
     * The planned end date/time (or discharge date) of the encounter.
     *
     * The planned end date/time (or discharge date) of the encounter
     */
    plannedEndDate?: Date;
    /**
     * Specific type of encounter (e.g. e-mail consultation, surgical day-care, skilled nursing, rehabilitation).
     *
     * Specific type of encounter (e.g. e-mail consultation, surgical day-care, ...)
     */
    type?: CodeableConcept[];
    /**
     * Any special requests that have been made for this encounter, such as the provision of specific equipment or other things.
     *
     * Wheelchair, translator, stretcher, etc
     */
    specialArrangement?: CodeableConcept[];
    /**
     * Broad categorization of the service that is to be provided (e.g. cardiology).
     *
     * Specific type of service
     */
    serviceType?: CodeableReference[];
    /**
     * Another Encounter of which this encounter is a part of (administratively or in time).
     *
     * Another Encounter this encounter is part of
     */
    partOf?: Encounter | Reference;
    /**
     * The list of medical reasons that are expected to be addressed during the episode of care.
     *
     * The list of medical reasons that are expected to be addressed during the episode of care
     */
    reason?: Encounter.ReasonComponent[];
    /**
     * The patient or group related to this encounter. In some use-cases the patient MAY not be present, such as a case meeting about a patient between several practitioners or a careteam.
     *
     * The patient or group related to this encounter
     */
    subject?: Patient | Group | Reference;
    /**
     * Connection details of a virtual service (e.g. conference call).
     *
     * Connection details of a virtual service (e.g. conference call)
     */
    virtualService?: VirtualServiceDetail[];
    readonly resourceType: string;
    static revive(json: any): Encounter;
    toJSON(): any;
}
export declare namespace Encounter {
    enum EncounterLocationStatus {
        COMPLETED,
        NULL,
        ACTIVE,
        RESERVED,
        PLANNED
    }
    enum EncounterStatus {
        CANCELLED,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ONHOLD,
        INPROGRESS,
        UNKNOWN,
        DISCONTINUED,
        DISCHARGED,
        PLANNED
    }
    class EncounterLocationComponent extends BackboneElement {
        /**
         * This will be used to specify the required levels (bed/ward/room/etc.) desired to be recorded to simplify either messaging or query.
         *
         * The physical type of the location (usually the level in the location hierarchy - bed, room, ward, virtual etc.)
         */
        form?: CodeableConcept;
        /**
         * Time period during which the patient was present at the location.
         *
         * Time period during which the patient was present at the location
         */
        period?: Period;
        /**
         * The status of the participants' presence at the specified location during the period specified. If the participant is no longer at the location, then the period will have an end date/time.
         *
         * planned | active | reserved | completed
         */
        status?: string;
        /**
         * The location where the encounter takes place.
         *
         * Location the encounter takes place
         */
        location: Location | Reference;
        static revive(json: any): EncounterLocationComponent;
        toJSON(): any;
    }
    class EncounterAdmissionComponent extends BackboneElement {
        /**
         * Pre-admission identifier.
         *
         * Pre-admission identifier
         */
        preAdmissionIdentifier?: Identifier;
        /**
         * Location/organization to which the patient is discharged.
         *
         * Location/organization to which the patient is discharged
         */
        destination?: Location | Organization | Reference;
        /**
         * From where patient was admitted (physician referral, transfer).
         *
         * From where patient was admitted (physician referral, transfer)
         */
        admitSource?: CodeableConcept;
        /**
         * Category or kind of location after discharge.
         *
         * Category or kind of location after discharge
         */
        dischargeDisposition?: CodeableConcept;
        /**
         * Indicates that this encounter is directly related to a prior admission, often because the conditions addressed in the prior admission were not fully addressed.
         *
         * Indicates that the patient is being re-admitted
         */
        reAdmission?: CodeableConcept;
        /**
         * The location/organization from which the patient came before admission.
         *
         * The location/organization from which the patient came before admission
         */
        origin?: Location | Organization | Reference;
        static revive(json: any): EncounterAdmissionComponent;
        toJSON(): any;
    }
    class DiagnosisComponent extends BackboneElement {
        /**
         * Role that this diagnosis has within the encounter (e.g. admission, billing, discharge …).
         *
         * Role that this diagnosis has within the encounter (e.g. admission, billing, discharge …)
         */
        use?: CodeableConcept[];
        /**
         * The coded diagnosis or a reference to a Condition (with other resources referenced in the evidence.detail), the use property will indicate the purpose of this specific diagnosis.
         *
         * The diagnosis relevant to the encounter
         */
        condition?: CodeableReference[];
        static revive(json: any): DiagnosisComponent;
        toJSON(): any;
    }
    class ReasonComponent extends BackboneElement {
        /**
         * Reason the encounter takes place, expressed as a code or a reference to another resource. For admissions, this can be used for a coded admission diagnosis.
         *
         * Reason the encounter takes place (core or reference)
         */
        value?: CodeableReference[];
        /**
         * What the reason value should be used as e.g. Chief Complaint, Health Concern, Health Maintenance (including screening).
         *
         * What the reason value should be used for/as
         */
        use?: CodeableConcept[];
        static revive(json: any): ReasonComponent;
        toJSON(): any;
    }
    class EncounterParticipantComponent extends BackboneElement {
        /**
         * The period of time that the specified participant participated in the encounter. These can overlap or be sub-sets of the overall encounter's period.
         *
         * Period of time during the encounter that the participant participated
         */
        period?: Period;
        /**
         * Person involved in the encounter, the patient/group is also included here to indicate that the patient was actually participating in the encounter. Not including the patient here covers use cases such as a case meeting between practitioners about a patient - non contact times.
         *
         * The individual, device, or service participating in the encounter
         */
        actor?: Patient | Group | RelatedPerson | Practitioner | PractitionerRole | Device | HealthcareService | Reference;
        /**
         * Role of participant in encounter.
         *
         * Role of participant in encounter
         */
        type?: CodeableConcept[];
        static revive(json: any): EncounterParticipantComponent;
        toJSON(): any;
    }
}
