import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { DomainResource } from '../model/domain-resource';
/**
 * HAPI/FHIR <b>FormularyItem</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/FormularyItem">http://hl7.org/fhir/StructureDefinition/FormularyItem</a>
 * </p>
 *
 */
export declare class FormularyItem extends DomainResource {
    /**
     * The validity about the information of the formulary item and not of the underlying product or service itself.
     *
     * active | entered-in-error | inactive
     */
    status?: string;
    /**
     * Business identifier for this formulary item.
     *
     * Business identifier for this formulary item
     */
    identifier?: Identifier[];
    /**
     * A code (or set of codes) that specify the product or service that is identified by this formulary item.
     *
     * Codes that identify this formulary item
     */
    code?: CodeableConcept;
    readonly resourceType: string;
    static revive(json: any): FormularyItem;
    toJSON(): any;
}
export declare namespace FormularyItem {
    enum FormularyItemStatusCodes {
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        INACTIVE
    }
}
