import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { DomainResource } from '../model/domain-resource';
import { Subscription } from '../model/subscription';
/**
 * HAPI/FHIR <b>SubscriptionStatus</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/SubscriptionStatus">http://hl7.org/fhir/StructureDefinition/SubscriptionStatus</a>
 * </p>
 *
 */
export declare class SubscriptionStatus extends DomainResource {
    /**
     * The reference to the Subscription which generated this notification.
     *
     * Reference to the Subscription responsible for this notification
     */
    subscription: Subscription | Reference;
    /**
     * The reference to the SubscriptionTopic for the Subscription which generated this notification.
     *
     * Reference to the SubscriptionTopic this notification relates to
     */
    topic?: string;
    /**
     * The status of the subscription, which marks the server state for managing the subscription.
     *
     * requested | active | error | off | entered-in-error
     */
    status?: string;
    /**
     * Detailed information about events relevant to this subscription notification.
     *
     * Detailed information about any events relevant to this notification
     */
    notificationEvent?: SubscriptionStatus.SubscriptionStatusNotificationEventComponent[];
    /**
     * The type of event being conveyed with this notification.
     *
     * handshake | heartbeat | event-notification | query-status | query-event
     */
    type: string;
    /**
     * A record of errors that occurred when the server processed a notification.
     *
     * List of errors on the subscription
     */
    error?: CodeableConcept[];
    /**
     * The total number of actual events which have been generated since the Subscription was created (inclusive of this notification) - regardless of how many have been successfully communicated.  This number is NOT incremented for handshake and heartbeat notifications.
     *
     * Events since the Subscription was created
     */
    eventsSinceSubscriptionStart?: any;
    readonly resourceType: string;
    static revive(json: any): SubscriptionStatus;
    toJSON(): any;
}
export declare namespace SubscriptionStatus {
    enum SubscriptionNotificationType {
        NULL,
        QUERYSTATUS,
        HANDSHAKE,
        QUERYEVENT,
        HEARTBEAT,
        EVENTNOTIFICATION
    }
    enum SubscriptionStatusCodes {
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        REQUESTED,
        ERROR,
        OFF
    }
    class SubscriptionStatusNotificationEventComponent extends BackboneElement {
        /**
         * The actual time this event occurred on the server.
         *
         * The instant this event occurred
         */
        timestamp?: Date;
        /**
         * Additional context information for this event. Generally, this will contain references to additional resources included with the event (e.g., the Patient relevant to an Encounter), however it MAY refer to non-FHIR objects.
         *
         * References related to the focus resource and/or context of this event
         */
        additionalContext?: Reference[];
        /**
         * The focus of this event. While this will usually be a reference to the focus resource of the event, it MAY contain a reference to a non-FHIR object.
         *
         * Reference to the primary resource or information of this event
         */
        focus?: Reference;
        /**
         * Either the sequential number of this event in this subscription context or a relative event number for this notification.
         *
         * Sequencing index of this event
         */
        eventNumber: any;
        static revive(json: any): SubscriptionStatusNotificationEventComponent;
        toJSON(): any;
    }
}
