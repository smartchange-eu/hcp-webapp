import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactPoint } from '../datatype/contact-point';
import { Identifier } from '../datatype/identifier';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Endpoint } from '../model/endpoint';
import { OperationOutcome } from '../model/operation-outcome';
import { Organization } from '../model/organization';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
/**
 * HAPI/FHIR <b>MessageHeader</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/MessageHeader">http://hl7.org/fhir/StructureDefinition/MessageHeader</a>
 * </p>
 *
 */
export declare class MessageHeader extends DomainResource {
    /**
     * Permanent link to the MessageDefinition for this message.
     *
     * Link to the definition for this message
     */
    definition?: string;
    /**
     * The source application from which this message originated.
     *
     * Message source application
     */
    source: MessageHeader.MessageSourceComponent;
    /**
     * The destination application which the message is intended for.
     *
     * Message destination application(s)
     */
    destination?: MessageHeader.MessageDestinationComponent[];
    /**
     * The actual data of the message - a reference to the root/focus class of the event. This is allowed to be a Parameters resource.
     *
     * The actual content of the message
     */
    focus?: Reference[];
    /**
     * Code that identifies the event this message represents and connects it with its definition. Events defined as part of the FHIR specification are defined by the implementation.  Alternatively a canonical uri to the EventDefinition.
     *
     * Event code or link to EventDefinition
     */
    event: Coding | string;
    /**
     * Coded indication of the cause for the event - indicates  a reason for the occurrence of the event that is a focus of this message.
     *
     * Cause of event
     */
    reason?: CodeableConcept;
    /**
     * The logical author of the message - the personor device that decided the described event should happen. When there is more than one candidate, pick the most proximal to the MessageHeader. Can provide other authors in extensions.
     *
     * The source of the decision
     */
    author?: Practitioner | PractitionerRole | Device | Organization | Reference;
    /**
     * Information about the message that this message is a response to.  Only present if this message is a response.
     *
     * If this is a reply to prior message
     */
    response?: MessageHeader.MessageHeaderResponseComponent;
    /**
     * The person or organization that accepts overall responsibility for the contents of the message. The implication is that the message event happened under the policies of the responsible party.
     *
     * Final responsibility for event
     */
    responsible?: Practitioner | PractitionerRole | Organization | Reference;
    /**
     * Identifies the sending system to allow the use of a trust relationship.
     *
     * Real world sender of the message
     */
    sender?: Practitioner | PractitionerRole | Device | Organization | Reference;
    readonly resourceType: string;
    static revive(json: any): MessageHeader;
    toJSON(): any;
}
export declare namespace MessageHeader {
    enum ResponseType {
        TRANSIENTERROR,
        NULL,
        FATALERROR,
        OK
    }
    class MessageHeaderResponseComponent extends BackboneElement {
        /**
         * The Bundle.identifier of the message to which this message is a response.
         *
         * Bundle.identifier of original message
         */
        identifier: Identifier;
        /**
         * Code that identifies the type of response to the message - whether it was successful or not, and whether it should be resent or not.
         *
         * ok | transient-error | fatal-error
         */
        code: string;
        /**
         * Full details of any issues found in the message.
         *
         * Specific list of hints/warnings/errors
         */
        details?: OperationOutcome | Reference;
        static revive(json: any): MessageHeaderResponseComponent;
        toJSON(): any;
    }
    class MessageSourceComponent extends BackboneElement {
        /**
         * Human-readable name for the source system.
         *
         * Name of system
         */
        name?: string;
        /**
         * Can convey versions of multiple systems in situations where a message passes through multiple hands.
         *
         * Version of software running
         */
        version?: string;
        /**
         * Identifies the routing target to send acknowledgements to.
         *
         * Actual source address or Endpoint resource
         */
        endpoint?: string | Endpoint | Reference;
        /**
         * An e-mail, phone, website or other contact point to use to resolve issues with message communications.
         *
         * Human contact for problems
         */
        contact?: ContactPoint;
        /**
         * May include configuration or other information useful in debugging.
         *
         * Name of software running the system
         */
        software?: string;
        static revive(json: any): MessageSourceComponent;
        toJSON(): any;
    }
    class MessageDestinationComponent extends BackboneElement {
        /**
         * Indicates where the message should be routed.
         *
         * Actual destination address or Endpoint resource
         */
        endpoint?: string | Endpoint | Reference;
        /**
         * Allows data conveyed by a message to be addressed to a particular person or department when routing to a specific application isn't sufficient.
         *
         * Intended "real-world" recipient for the data
         */
        receiver?: Practitioner | PractitionerRole | Organization | Reference;
        /**
         * Human-readable name for the target system.
         *
         * Name of system
         */
        name?: string;
        /**
         * Identifies the target end system in situations where the initial message transmission is to an intermediary system.
         *
         * Particular delivery destination within the destination
         */
        target?: Device | Reference;
        static revive(json: any): MessageDestinationComponent;
        toJSON(): any;
    }
}
