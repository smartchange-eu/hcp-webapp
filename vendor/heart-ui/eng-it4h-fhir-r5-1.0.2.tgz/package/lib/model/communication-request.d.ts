import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Endpoint } from '../model/endpoint';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>CommunicationRequest</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/CommunicationRequest">http://hl7.org/fhir/StructureDefinition/CommunicationRequest</a>
 * </p>
 *
 */
export declare class CommunicationRequest extends DomainResource {
    /**
     * Captures the reason for the current state of the CommunicationRequest.
     *
     * Reason for current status
     */
    statusReason?: CodeableConcept;
    /**
     * Text, attachment(s), or resource(s) to be communicated to the recipient.
     *
     * Message payload
     */
    payload?: CommunicationRequest.CommunicationRequestPayloadComponent[];
    /**
     * The entity (e.g. person, organization, clinical information system, device, group, or care team) which is the intended target of the communication.
     *
     * Who to share the information with
     */
    recipient?: Device[] | Organization[] | Patient[] | Practitioner[] | PractitionerRole[] | RelatedPerson[] | Group[] | CareTeam[] | HealthcareService[] | Endpoint[] | Reference[];
    /**
     * The status of the proposal or order.
     *
     * draft | active | on-hold | revoked | completed | entered-in-error | unknown
     */
    status: string;
    /**
     * A plan or proposal that is fulfilled in whole or in part by this request.
     *
     * Fulfills plan or proposal
     */
    basedOn?: Reference[];
    /**
     * A shared identifier common to multiple independent Request instances that were activated/authorized more or less simultaneously by a single author.  The presence of the same identifier on each request ties those requests together and may have business ramifications in terms of reporting of results, billing, etc.  E.g. a requisition number shared by a set of lab tests ordered together, or a prescription number shared by all meds ordered at one time.
     *
     * Composite request this is part of
     */
    groupIdentifier?: Identifier;
    /**
     * The type of message to be sent such as alert, notification, reminder, instruction, etc.
     *
     * Message category
     */
    category?: CodeableConcept[];
    /**
     * If true indicates that the CommunicationRequest is asking for the specified action to *not* occur.
     *
     * True if request is prohibiting action
     */
    doNotPerform?: boolean;
    /**
     * For draft requests, indicates the date of initial creation.  For requests with other statuses, indicates the date of activation.
     *
     * When request transitioned to being actionable
     */
    authoredOn?: Date;
    /**
     * Business identifiers assigned to this communication request by the performer or other systems which remain constant as the resource is updated and propagates from server to server.
     *
     * Unique identifier
     */
    identifier?: Identifier[];
    /**
     * Describes why the request is being made in coded or textual form.
     *
     * Why is communication needed?
     */
    reason?: CodeableReference[];
    /**
     * Comments made about the request by the requester, sender, recipient, subject or other participants.
     *
     * Comments made about communication request
     */
    note?: Annotation[];
    /**
     * The device, individual, or organization who asks for the information to be shared.
     *
     * Who asks for the information to be shared
     */
    requester?: Practitioner | PractitionerRole | Organization | Patient | RelatedPerson | Device | Reference;
    /**
     * Completed or terminated request(s) whose function is taken by this new request.
     *
     * Request(s) replaced by this request
     */
    replaces?: CommunicationRequest[] | Reference[];
    /**
     * The patient or group that is the focus of this communication request.
     *
     * Focus of message
     */
    subject?: Patient | Group | Reference;
    /**
     * A channel that was used for this communication (e.g. email, fax).
     *
     * A channel of communication
     */
    medium?: CodeableConcept[];
    /**
     * The Encounter during which this CommunicationRequest was created or to which the creation of this record is tightly associated.
     *
     * The Encounter during which this CommunicationRequest was created
     */
    encounter?: Encounter | Reference;
    /**
     * The time when this communication is to occur.
     *
     * When scheduled
     */
    occurrence?: Date | Period;
    /**
     * Other resources that pertain to this communication request and to which this communication request should be associated.
     *
     * Resources that pertain to this communication request
     */
    about?: Reference[];
    /**
     * The entity (e.g. person, organization, clinical information system, or device) which is to be the source of the communication.
     *
     * Who should share the information
     */
    informationProvider?: Device[] | Organization[] | Patient[] | Practitioner[] | PractitionerRole[] | RelatedPerson[] | HealthcareService[] | Endpoint[] | Reference[];
    /**
     * Indicates the level of authority/intentionality associated with the CommunicationRequest and where the request fits into the workflow chain.
     *
     * proposal | plan | directive | order | original-order | reflex-order | filler-order | instance-order | option
     */
    intent: string;
    /**
     * Characterizes how quickly the proposed act must be initiated. Includes concepts such as stat, urgent, routine.
     *
     * routine | urgent | asap | stat
     */
    priority?: string;
    readonly resourceType: string;
    static revive(json: any): CommunicationRequest;
    toJSON(): any;
}
export declare namespace CommunicationRequest {
    enum RequestStatus {
        REVOKED,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ACTIVE,
        DRAFT,
        ONHOLD,
        UNKNOWN
    }
    enum RequestIntent {
        ORDER,
        FILLERORDER,
        ORIGINALORDER,
        NULL,
        REFLEXORDER,
        DIRECTIVE,
        OPTION,
        PROPOSAL,
        PLAN,
        INSTANCEORDER
    }
    enum RequestPriority {
        URGENT,
        STAT,
        NULL,
        ROUTINE,
        ASAP
    }
    class CommunicationRequestPayloadComponent extends BackboneElement {
        /**
         * The communicated content (or for multi-part communications, one portion of the communication).
         *
         * Message part content
         */
        content: Attachment | Reference | CodeableConcept;
        static revive(json: any): CommunicationRequestPayloadComponent;
        toJSON(): any;
    }
}
