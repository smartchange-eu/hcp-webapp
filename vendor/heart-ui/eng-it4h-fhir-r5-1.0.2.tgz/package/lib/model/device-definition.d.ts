import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Coding } from '../datatype/coding';
import { ContactPoint } from '../datatype/contact-point';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { ProductShelfLife } from '../datatype/product-shelf-life';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { RelatedArtifact } from '../datatype/related-artifact';
import { UsageContext } from '../datatype/usage-context';
import { DomainResource } from '../model/domain-resource';
import { Organization } from '../model/organization';
/**
 * HAPI/FHIR <b>DeviceDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/DeviceDefinition">http://hl7.org/fhir/StructureDefinition/DeviceDefinition</a>
 * </p>
 *
 */
export declare class DeviceDefinition extends DomainResource {
    /**
     * Identifies the standards, specifications, or formal guidances for the capabilities supported by the device. The device may be certified as conformant to these specifications e.g., communication, performance, process, measurement, or specialization standards.
     *
     * Identifies the standards, specifications, or formal guidances for the capabilities supported by the device
     */
    conformsTo?: DeviceDefinition.DeviceDefinitionConformsToComponent[];
    /**
     * The part number or catalog number of the device.
     *
     * The part number or catalog number of the device
     */
    partNumber?: string;
    /**
     * The model number for the device for example as defined by the manufacturer or labeler, or other agency.
     *
     * The catalog or model number for the device for example as defined by the manufacturer
     */
    modelNumber?: string;
    /**
     * Tracking of latest field safety corrective action.
     *
     * Tracking of latest field safety corrective action
     */
    correctiveAction?: DeviceDefinition.DeviceDefinitionCorrectiveActionComponent;
    /**
     * Information aimed at providing directions for the usage of this model of device.
     *
     * Information aimed at providing directions for the usage of this model of device
     */
    guideline?: DeviceDefinition.DeviceDefinitionGuidelineComponent;
    /**
     * A substance used to create the material(s) of which the device is made.
     *
     * A substance used to create the material(s) of which the device is made
     */
    material?: DeviceDefinition.DeviceDefinitionMaterialComponent[];
    /**
     * Unique device identifier (UDI) assigned to device label or package.  Note that the Device may include multiple udiCarriers as it either may include just the udiCarrier for the jurisdiction it is sold, or for multiple jurisdictions it could have been sold.
     *
     * Unique Device Identifier (UDI) Barcode string
     */
    udiDeviceIdentifier?: DeviceDefinition.DeviceDefinitionUdiDeviceIdentifierComponent[];
    /**
     * The version of the device or software.
     *
     * The version of the device or software
     */
    version?: DeviceDefinition.DeviceDefinitionVersionComponent[];
    /**
     * Indicates the production identifier(s) that are expected to appear in the UDI carrier on the device label.
     *
     * lot-number | manufactured-date | serial-number | expiration-date | biological-source | software-version
     */
    productionIdentifierInUDI?: string[];
    /**
     * What kind of device or device system this is.
     *
     * What kind of device or device system this is
     */
    classification?: DeviceDefinition.DeviceDefinitionClassificationComponent[];
    /**
     * Language code for the human-readable text strings produced by the device (all supported).
     *
     * Language code for the human-readable text strings produced by the device (all supported)
     */
    languageCode?: CodeableConcept[];
    /**
     * Information about the packaging of the device, i.e. how the device is packaged.
     *
     * Information about the packaging of the device, i.e. how the device is packaged
     */
    packaging?: DeviceDefinition.DeviceDefinitionPackagingComponent[];
    /**
     * Billing code or reference associated with the device.
     *
     * Billing code or reference associated with the device
     */
    chargeItem?: DeviceDefinition.DeviceDefinitionChargeItemComponent[];
    /**
     * A device that is part (for example a component) of the present device.
     *
     * A device, part of the current one
     */
    hasPart?: DeviceDefinition.DeviceDefinitionHasPartComponent[];
    /**
     * Unique instance identifiers assigned to a device by the software, manufacturers, other organizations or owners. For example: handle ID. The identifier is typically valued if the udiDeviceIdentifier, partNumber or modelNumber is not valued and represents a different type of identifier.  However, it is permissible to still include those identifiers in DeviceDefinition.identifier with the appropriate identifier.type.
     *
     * Instance identifier
     */
    identifier?: Identifier[];
    /**
     * An organization that is responsible for the provision and ongoing maintenance of the device.
     *
     * Organization responsible for device
     */
    owner?: Organization | Reference;
    /**
     * Static or essentially fixed characteristics or features of this kind of device that are otherwise not captured in more specific attributes, e.g., time or timing attributes, resolution, accuracy, and physical attributes.
     *
     * Inherent, essentially fixed, characteristics of this kind of device, e.g., time properties, size, etc
     */
    property?: DeviceDefinition.DeviceDefinitionPropertyComponent[];
    /**
     * Contact details for an organization or a particular human that is responsible for the device.
     *
     * Details for human/organization for support
     */
    contact?: ContactPoint[];
    /**
     * Safety characteristics of the device.
     *
     * Safety characteristics of the device
     */
    safety?: CodeableConcept[];
    /**
     * Shelf Life and storage information.
     *
     * Shelf Life and storage information
     */
    shelfLifeStorage?: ProductShelfLife[];
    /**
     * A name of the manufacturer  or legal representative e.g. labeler. Whether this is the actual manufacturer or the labeler or responsible depends on implementation and jurisdiction.
     *
     * Name of device manufacturer
     */
    manufacturer?: Organization | Reference;
    /**
     * The name or names of the device as given by the manufacturer.
     *
     * The name or names of the device as given by the manufacturer
     */
    deviceName?: DeviceDefinition.DeviceDefinitionDeviceNameComponent[];
    /**
     * Additional information to describe the device.
     *
     * Additional information to describe the device
     */
    description?: string;
    /**
     * Identifier associated with the regulatory documentation (certificates, technical documentation, post-market surveillance documentation and reports) of a set of device models sharing the same intended purpose, risk class and essential design and manufacturing characteristics. One example is the Basic UDI-DI in Europe.
     *
     * Regulatory identifier(s) associated with this device
     */
    regulatoryIdentifier?: DeviceDefinition.DeviceDefinitionRegulatoryIdentifierComponent[];
    /**
     * An associated device, attached to, used with, communicating with or linking a previous or new device model to the focal device.
     *
     * An associated device, attached to, used with, communicating with or linking a previous or new device model to the focal device
     */
    link?: DeviceDefinition.DeviceDefinitionLinkComponent[];
    /**
     * Descriptive information, usage information or implantation information that is not captured in an existing element.
     *
     * Device notes and comments
     */
    note?: Annotation[];
    readonly resourceType: string;
    static revive(json: any): DeviceDefinition;
    toJSON(): any;
}
export declare namespace DeviceDefinition {
    enum DeviceProductionIdentifierInUDI {
        NULL,
        SERIALNUMBER,
        MANUFACTUREDDATE,
        BIOLOGICALSOURCE,
        EXPIRATIONDATE,
        LOTNUMBER,
        SOFTWAREVERSION
    }
    enum DeviceDefinitionRegulatoryIdentifierType {
        MASTER,
        NULL,
        LICENSE,
        BASIC
    }
    enum DeviceCorrectiveActionScope {
        SERIALNUMBERS,
        NULL,
        LOTNUMBERS,
        MODEL
    }
    class DeviceDefinitionChargeItemComponent extends BackboneElement {
        /**
         * The code or reference for the charge item.
         *
         * The code or reference for the charge item
         */
        chargeItemCode: CodeableReference;
        /**
         * A specific time period in which this charge item applies.
         *
         * A specific time period in which this charge item applies
         */
        effectivePeriod?: Period;
        /**
         * Coefficient applicable to the billing code.
         *
         * Coefficient applicable to the billing code
         */
        count: Quantity;
        /**
         * The context to which this charge item applies.
         *
         * The context to which this charge item applies
         */
        useContext?: UsageContext[];
        static revive(json: any): DeviceDefinitionChargeItemComponent;
        toJSON(): any;
    }
    class DeviceDefinitionCorrectiveActionComponent extends BackboneElement {
        /**
         * Start and end dates of the  corrective action.
         *
         * Start and end dates of the  corrective action
         */
        period: Period;
        /**
         * Whether the last corrective action known for this device was a recall.
         *
         * Whether the corrective action was a recall
         */
        recall: boolean;
        /**
         * The scope of the corrective action - whether the action targeted all units of a given device model, or only a specific set of batches identified by lot numbers, or individually identified devices identified by the serial name.
         *
         * model | lot-numbers | serial-numbers
         */
        scope?: string;
        static revive(json: any): DeviceDefinitionCorrectiveActionComponent;
        toJSON(): any;
    }
    class DeviceDefinitionGuidelineComponent extends BackboneElement {
        /**
         * Detailed written and visual directions for the user on how to use the device.
         *
         * Detailed written and visual directions for the user on how to use the device
         */
        usageInstruction?: string;
        /**
         * Specific hazard alert information that a user needs to know before using the device.
         *
         * Specific hazard alert information that a user needs to know before using the device
         */
        warning?: CodeableConcept[];
        /**
         * A description of the general purpose or medical use of the device or its function.
         *
         * A description of the general purpose or medical use of the device or its function
         */
        intendedUse?: string;
        /**
         * A clinical condition for which the device was designed to be used.
         *
         * A clinical condition for which the device was designed to be used
         */
        indication?: CodeableConcept[];
        /**
         * The circumstances that form the setting for using the device.
         *
         * The circumstances that form the setting for using the device
         */
        useContext?: UsageContext[];
        /**
         * A specific situation when a device should not be used because it may cause harm.
         *
         * A specific situation when a device should not be used because it may cause harm
         */
        contraindication?: CodeableConcept[];
        /**
         * A source of information or reference for this guideline.
         *
         * A source of information or reference for this guideline
         */
        relatedArtifact?: RelatedArtifact[];
        static revive(json: any): DeviceDefinitionGuidelineComponent;
        toJSON(): any;
    }
    class DeviceDefinitionMaterialComponent extends BackboneElement {
        /**
         * Whether the substance is a known or suspected allergen.
         *
         * Whether the substance is a known or suspected allergen
         */
        allergenicIndicator?: boolean;
        /**
         * Indicates an alternative material of the device.
         *
         * Indicates an alternative material of the device
         */
        alternate?: boolean;
        /**
         * A substance that the device contains, may contain, or is made of - for example latex - to be used to determine patient compatibility. This is not intended to represent the composition of the device, only the clinically relevant materials.
         *
         * A relevant substance that the device contains, may contain, or is made of
         */
        substance: CodeableConcept;
        static revive(json: any): DeviceDefinitionMaterialComponent;
        toJSON(): any;
    }
    class DeviceDefinitionLinkComponent extends BackboneElement {
        /**
         * The type indicates the relationship of the related device to the device instance.
         *
         * The type indicates the relationship of the related device to the device instance
         */
        relation: Coding;
        /**
         * A reference to the linked device.
         *
         * A reference to the linked device
         */
        relatedDevice: CodeableReference;
        static revive(json: any): DeviceDefinitionLinkComponent;
        toJSON(): any;
    }
    class DeviceDefinitionPropertyComponent extends BackboneElement {
        /**
         * Code that specifies the property such as a resolution or color being represented.
         *
         * Code that specifies the property being represented
         */
        type: CodeableConcept;
        /**
         * The value of the property specified by the associated property.type code.
         *
         * Value of the property
         */
        value: Quantity | CodeableConcept | string | boolean | number | Range | Attachment;
        static revive(json: any): DeviceDefinitionPropertyComponent;
        toJSON(): any;
    }
    class DeviceDefinitionVersionComponent extends BackboneElement {
        /**
         * The hardware or software module of the device to which the version applies.
         *
         * The hardware or software module of the device to which the version applies
         */
        component?: Identifier;
        /**
         * The version text.
         *
         * The version text
         */
        value: string;
        /**
         * The type of the device version, e.g. manufacturer, approved, internal.
         *
         * The type of the device version, e.g. manufacturer, approved, internal
         */
        type?: CodeableConcept;
        static revive(json: any): DeviceDefinitionVersionComponent;
        toJSON(): any;
    }
    class PackagingDistributorComponent extends BackboneElement {
        /**
         * Distributor's human-readable name.
         *
         * Distributor's human-readable name
         */
        name?: string;
        /**
         * Distributor as an Organization resource.
         *
         * Distributor as an Organization resource
         */
        organizationReference?: Organization[] | Reference[];
        static revive(json: any): PackagingDistributorComponent;
        toJSON(): any;
    }
    class DeviceDefinitionPackagingComponent extends BackboneElement {
        /**
         * The number of items contained in the package (devices or sub-packages).
         *
         * The number of items contained in the package (devices or sub-packages)
         */
        count?: number;
        /**
         * Allows packages within packages.
         *
         * Allows packages within packages
         */
        packaging?: DeviceDefinition.DeviceDefinitionPackagingComponent[];
        /**
         * A code that defines the specific type of packaging.
         *
         * A code that defines the specific type of packaging
         */
        type?: CodeableConcept;
        /**
         * An organization that distributes the packaged device.
         *
         * An organization that distributes the packaged device
         */
        distributor?: DeviceDefinition.PackagingDistributorComponent[];
        /**
         * Unique Device Identifier (UDI) Barcode string on the packaging.
         *
         * Unique Device Identifier (UDI) Barcode string on the packaging
         */
        udiDeviceIdentifier?: DeviceDefinition.DeviceDefinitionUdiDeviceIdentifierComponent[];
        /**
         * The business identifier of the packaged medication.
         *
         * Business identifier of the packaged medication
         */
        identifier?: Identifier;
        static revive(json: any): DeviceDefinitionPackagingComponent;
        toJSON(): any;
    }
    class DeviceDefinitionHasPartComponent extends BackboneElement {
        /**
         * Number of instances of the component device in the current device.
         *
         * Number of occurrences of the part
         */
        count?: number;
        /**
         * Reference to the device that is part of the current device.
         *
         * Reference to the part
         */
        reference: DeviceDefinition | Reference;
        static revive(json: any): DeviceDefinitionHasPartComponent;
        toJSON(): any;
    }
    class DeviceDefinitionConformsToComponent extends BackboneElement {
        /**
         * Describes the type of the standard, specification, or formal guidance.
         *
         * Describes the common type of the standard, specification, or formal guidance
         */
        category?: CodeableConcept;
        /**
         * Identifies the specific form or variant of the standard, specification, or formal guidance. This may be a 'version number', release, document edition, publication year, or other label.
         *
         * The specific form or variant of the standard, specification or formal guidance
         */
        version?: string[];
        /**
         * Code that identifies the specific standard, specification, protocol, formal guidance, regulation, legislation, or certification scheme to which the device adheres.
         *
         * Identifies the standard, specification, or formal guidance that the device adheres to the Device Specification type
         */
        specification: CodeableConcept;
        /**
         * Standard, regulation, certification, or guidance website, document, or other publication, or similar, supporting the conformance.
         *
         * Standard, regulation, certification, or guidance website, document, or other publication, or similar, supporting the conformance
         */
        source?: RelatedArtifact[];
        static revive(json: any): DeviceDefinitionConformsToComponent;
        toJSON(): any;
    }
    class DeviceDefinitionClassificationComponent extends BackboneElement {
        /**
         * A classification or risk class of the device model.
         *
         * A classification or risk class of the device model
         */
        type: CodeableConcept;
        /**
         * Further information qualifying this classification of the device model.
         *
         * Further information qualifying this classification of the device model
         */
        justification?: RelatedArtifact[];
        static revive(json: any): DeviceDefinitionClassificationComponent;
        toJSON(): any;
    }
    class DeviceDefinitionDeviceNameComponent extends BackboneElement {
        /**
         * A human-friendly name that is used to refer to the device - depending on the type, it can be the brand name, the common name or alias, or other.
         *
         * A name that is used to refer to the device
         */
        name: string;
        /**
         * The type of deviceName.
RegisteredName | UserFriendlyName | PatientReportedName.
         *
         * registered-name | user-friendly-name | patient-reported-name
         */
        type: string;
        static revive(json: any): DeviceDefinitionDeviceNameComponent;
        toJSON(): any;
    }
    class DeviceDefinitionRegulatoryIdentifierComponent extends BackboneElement {
        /**
         * The jurisdiction to which the deviceIdentifier applies.
         *
         * The jurisdiction to which the deviceIdentifier applies
         */
        jurisdiction: string;
        /**
         * The identifier itself.
         *
         * The identifier itself
         */
        deviceIdentifier: string;
        /**
         * The organization that issued this identifier.
         *
         * The organization that issued this identifier
         */
        issuer: string;
        /**
         * The type of identifier itself.
         *
         * basic | master | license
         */
        type: string;
        static revive(json: any): DeviceDefinitionRegulatoryIdentifierComponent;
        toJSON(): any;
    }
    class UdiDeviceIdentifierMarketDistributionComponent extends BackboneElement {
        /**
         * National state or territory to which the marketDistribution recers, typically where the device is commercialized.
         *
         * National state or territory where the device is commercialized
         */
        subJurisdiction: string;
        /**
         * Begin and end dates for the commercial distribution of the device.
         *
         * Begin and end dates for the commercial distribution of the device
         */
        marketPeriod: Period;
        static revive(json: any): UdiDeviceIdentifierMarketDistributionComponent;
        toJSON(): any;
    }
    class DeviceDefinitionUdiDeviceIdentifierComponent extends BackboneElement {
        /**
         * The jurisdiction to which the deviceIdentifier applies.
         *
         * The jurisdiction to which the deviceIdentifier applies
         */
        jurisdiction: string;
        /**
         * Indicates where and when the device is available on the market.
         *
         * Indicates whether and when the device is available on the market
         */
        marketDistribution?: DeviceDefinition.UdiDeviceIdentifierMarketDistributionComponent[];
        /**
         * The identifier that is to be associated with every Device that references this DeviceDefintiion for the issuer and jurisdiction provided in the DeviceDefinition.udiDeviceIdentifier.
         *
         * The identifier that is to be associated with every Device that references this DeviceDefintiion for the issuer and jurisdiction provided in the DeviceDefinition.udiDeviceIdentifier
         */
        deviceIdentifier: string;
        /**
         * The organization that assigns the identifier algorithm.
         *
         * The organization that assigns the identifier algorithm
         */
        issuer: string;
        static revive(json: any): DeviceDefinitionUdiDeviceIdentifierComponent;
        toJSON(): any;
    }
}
