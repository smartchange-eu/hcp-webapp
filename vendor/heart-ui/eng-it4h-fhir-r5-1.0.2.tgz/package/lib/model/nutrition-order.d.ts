import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { Ratio } from '../datatype/ratio';
import { Timing } from '../datatype/timing';
import { AllergyIntolerance } from '../model/allergy-intolerance';
import { CarePlan } from '../model/care-plan';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { ServiceRequest } from '../model/service-request';
/**
 * HAPI/FHIR <b>NutritionOrder</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/NutritionOrder">http://hl7.org/fhir/StructureDefinition/NutritionOrder</a>
 * </p>
 *
 */
export declare class NutritionOrder extends DomainResource {
    /**
     * The URL pointing to a FHIR-defined protocol, guideline, orderset or other definition that is adhered to in whole or in part by this NutritionOrder.
     *
     * Instantiates FHIR protocol or definition
     */
    instantiatesCanonical?: string[];
    /**
     * Indicates how quickly the Nutrition Order should be addressed with respect to other        requests.
     *
     * routine | urgent | asap | stat
     */
    priority?: string;
    /**
     * Indicates the level of authority/intentionality associated with the NutrionOrder and where the request fits into the workflow chain.
     *
     * proposal | plan | directive | order | original-order | reflex-order | filler-order | instance-order | option
     */
    intent: string;
    /**
     * The URL pointing to an externally maintained protocol, guideline, orderset or other definition that is adhered to in whole or in part by this NutritionOrder.
     *
     * Instantiates external protocol or definition
     */
    instantiatesUri?: string[];
    /**
     * Information to support fulfilling (i.e. dispensing or administering) of the nutrition,        for example, patient height and weight).
     *
     * Information to support fulfilling of the nutrition order
     */
    supportingInformation?: Reference[];
    /**
     * An encounter that provides additional information about the healthcare context in which this request is made.
     *
     * The encounter associated with this nutrition order
     */
    encounter?: Encounter | Reference;
    /**
     * This modifier is used to convey Order-specific modifier about the type of oral food or oral fluids that should not be given. These can be derived from patient allergies, intolerances, or preferences such as No Red Meat, No Soy or No Wheat or  Gluten-Free.  While it should not be necessary to repeat allergy or intolerance information captured in the referenced AllergyIntolerance resource in the excludeFoodModifier, this element may be used to convey additional specificity related to foods that should be eliminated from the patient’s diet for any reason.  This modifier applies to the entire nutrition order inclusive of the oral diet, nutritional supplements and enteral formula feedings.
     *
     * Order-specific modifier about the type of food that should not be given
     */
    excludeFoodModifier?: CodeableConcept[];
    /**
     * The person or set of individuals who needs the nutrition order for an oral diet, nutritional supplement and/or enteral or formula feeding.
     *
     * Who requires the diet, formula or nutritional supplement
     */
    subject: Patient | Group | Reference;
    /**
     * The date and time that this nutrition order was requested.
     *
     * Date and time the nutrition order was requested
     */
    dateTime: Date;
    /**
     * Identifiers assigned to this order by the order sender or by the order receiver.
     *
     * Identifiers assigned to this order
     */
    identifier?: Identifier[];
    /**
     * The URL pointing to a protocol, guideline, orderset or other definition that is adhered to in whole or in part by this NutritionOrder.
     *
     * Instantiates protocol or definition
     */
    instantiates?: string[];
    /**
     * Comments made about the nutrition order by the requester, performer, subject or other participants.
     *
     * Comments
     */
    note?: Annotation[];
    /**
     * The specified desired performer of the nutrition order.
     *
     * Who is desired to perform the administration of what is being ordered
     */
    performer?: CodeableReference[];
    /**
     * Diet given orally in contrast to enteral (tube) feeding.
     *
     * Oral diet components
     */
    oralDiet?: NutritionOrder.NutritionOrderOralDietComponent;
    /**
     * Feeding provided through the gastrointestinal tract via a tube, catheter, or stoma that delivers nutrition distal to the oral cavity.
     *
     * Enteral formula components
     */
    enteralFormula?: NutritionOrder.NutritionOrderEnteralFormulaComponent;
    /**
     * A shared identifier common to all nutrition orders that were authorized more or less simultaneously by a single author, representing the composite or group identifier.
     *
     * Composite Request ID
     */
    groupIdentifier?: Identifier;
    /**
     * A plan or request that is fulfilled in whole or in part by this nutrition order.
     *
     * What this order fulfills
     */
    basedOn?: CarePlan[] | NutritionOrder[] | ServiceRequest[] | Reference[];
    /**
     * A link to a record of allergies or intolerances  which should be included in the nutrition order.
     *
     * List of the patient's food and nutrition-related allergies and intolerances
     */
    allergyIntolerance?: AllergyIntolerance[] | Reference[];
    /**
     * This modifier is used to convey order-specific modifiers about the type of food that should be given. These can be derived from patient allergies, intolerances, or preferences such as Halal, Vegan or Kosher. This modifier applies to the entire nutrition order inclusive of the oral diet, nutritional supplements and enteral formula feedings.
     *
     * Order-specific modifier about the type of food that should be given
     */
    foodPreferenceModifier?: CodeableConcept[];
    /**
     * The workflow status of the nutrition order/request.
     *
     * draft | active | on-hold | revoked | completed | entered-in-error | unknown
     */
    status: string;
    /**
     * Oral nutritional products given in order to add further nutritional value to the patient's diet.
     *
     * Supplement components
     */
    supplement?: NutritionOrder.NutritionOrderSupplementComponent[];
    /**
     * The practitioner that holds legal responsibility for ordering the diet, nutritional supplement, or formula feedings.
     *
     * Who ordered the diet, formula or nutritional supplement
     */
    orderer?: Practitioner | PractitionerRole | Reference;
    /**
     * This modifier is used to convey whether a food item is allowed to be brought in by the patient and/or family.  If set to true, indicates that the receiving system does not need to supply the food item.
     *
     * Capture when a food item is brought in by the patient and/or family
     */
    outsideFoodAllowed?: boolean;
    readonly resourceType: string;
    static revive(json: any): NutritionOrder;
    toJSON(): any;
}
export declare namespace NutritionOrder {
    enum RequestStatus {
        REVOKED,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ACTIVE,
        DRAFT,
        ONHOLD,
        UNKNOWN
    }
    enum RequestIntent {
        ORDER,
        FILLERORDER,
        ORIGINALORDER,
        NULL,
        REFLEXORDER,
        DIRECTIVE,
        OPTION,
        PROPOSAL,
        PLAN,
        INSTANCEORDER
    }
    enum RequestPriority {
        URGENT,
        STAT,
        NULL,
        ROUTINE,
        ASAP
    }
    class EnteralFormulaScheduleComponent extends BackboneElement {
        /**
         * The time period and frequency at which the enteral formula should be given.  The enteral formula should be given for the combination of all schedules if more than one schedule is present.
         *
         * Scheduled frequency of enteral formula
         */
        timing?: Timing[];
        /**
         * Indicates whether the enteral formula is only taken when needed within a specific dosing schedule.
         *
         * Take 'as needed'
         */
        asNeeded?: boolean;
        /**
         * Indicates whether the enteral formula is only taken based on a precondition for taking the enteral formula.
         *
         * Take 'as needed' for x
         */
        asNeededFor?: CodeableConcept;
        static revive(json: any): EnteralFormulaScheduleComponent;
        toJSON(): any;
    }
    class NutritionOrderEnteralFormulaAdministrationComponent extends BackboneElement {
        /**
         * The rate of administration of formula via a feeding pump, e.g. 60 mL per hour, according to the specified schedule.
         *
         * Speed with which the formula is provided per period of time
         */
        rate?: Quantity | Ratio;
        /**
         * The volume of formula to provide to the patient per the specified administration schedule.
         *
         * The volume of formula to provide
         */
        quantity?: Quantity;
        /**
         * Schedule information for an enteral formula.
         *
         * Scheduling information for enteral formula products
         */
        schedule?: NutritionOrder.EnteralFormulaScheduleComponent;
        static revive(json: any): NutritionOrderEnteralFormulaAdministrationComponent;
        toJSON(): any;
    }
    class NutritionOrderEnteralFormulaAdditiveComponent extends BackboneElement {
        /**
         * Indicates the type of modular component such as protein, carbohydrate, fat or fiber to be provided in addition to or mixed with the base formula.
         *
         * Type of modular component to add to the feeding
         */
        type?: CodeableReference;
        /**
         * The product or brand name of the type of modular component to be added to the formula.
         *
         * Product or brand name of the modular additive
         */
        productName?: string;
        /**
         * The amount of additive to be given in addition or to be mixed in with the base formula.
         *
         * Amount of additive to be given or mixed in
         */
        quantity?: Quantity;
        static revive(json: any): NutritionOrderEnteralFormulaAdditiveComponent;
        toJSON(): any;
    }
    class NutritionOrderEnteralFormulaComponent extends BackboneElement {
        /**
         * The maximum total quantity of formula that may be administered to a subject over the period of time, e.g. 1440 mL over 24 hours.
         *
         * Upper limit on formula volume per unit of time
         */
        maxVolumeToDeliver?: Quantity;
        /**
         * The amount of energy (calories) that the formula should provide per specified volume, typically per mL or fluid oz.  For example, an infant may require a formula that provides 24 calories per fluid ounce or an adult may require an enteral formula that provides 1.5 calorie/mL.
         *
         * Amount of energy per specified volume that is required
         */
        caloricDensity?: Quantity;
        /**
         * The route or physiological path of administration into the patient's gastrointestinal  tract for purposes of providing the formula feeding, e.g. nasogastric tube.
         *
         * How the formula should enter the patient's gastrointestinal tract
         */
        routeOfAdministration?: CodeableConcept;
        /**
         * The intended type of device that is to be used for the administration of the enteral formula.
         *
         * Intended type of device for the administration
         */
        deliveryDevice?: CodeableReference[];
        /**
         * Indicates modular components to be provided in addition or mixed with the base formula.
         *
         * Components to add to the feeding
         */
        additive?: NutritionOrder.NutritionOrderEnteralFormulaAdditiveComponent[];
        /**
         * Formula administration instructions as structured data.  This repeating structure allows for changing the administration rate or volume over time for both bolus and continuous feeding.  An example of this would be an instruction to increase the rate of continuous feeding every 2 hours.
         *
         * Formula feeding instruction as structured data
         */
        administration?: NutritionOrder.NutritionOrderEnteralFormulaAdministrationComponent[];
        /**
         * The type of enteral or infant formula such as an adult standard formula with fiber or a soy-based infant formula.
         *
         * Type of enteral or infant formula
         */
        baseFormulaType?: CodeableReference;
        /**
         * Free text formula administration, feeding instructions or additional instructions or information.
         *
         * Formula feeding instructions expressed as text
         */
        administrationInstruction?: string;
        /**
         * The product or brand name of the enteral or infant formula product such as "ACME Adult Standard Formula".
         *
         * Product or brand name of the enteral or infant formula
         */
        baseFormulaProductName?: string;
        static revive(json: any): NutritionOrderEnteralFormulaComponent;
        toJSON(): any;
    }
    class SupplementScheduleComponent extends BackboneElement {
        /**
         * Indicates whether the supplement is only taken based on a precondition for taking the supplement.
         *
         * Take 'as needed' for x
         */
        asNeededFor?: CodeableConcept;
        /**
         * The time period and frequency at which the supplement should be given.  The supplement should be given for the combination of all schedules if more than one schedule is present.
         *
         * Scheduled frequency of diet
         */
        timing?: Timing[];
        /**
         * Indicates whether the supplement is only taken when needed within a specific dosing schedule.
         *
         * Take 'as needed'
         */
        asNeeded?: boolean;
        static revive(json: any): SupplementScheduleComponent;
        toJSON(): any;
    }
    class NutritionOrderSupplementComponent extends BackboneElement {
        /**
         * The kind of nutritional supplement product required such as a high protein or pediatric clear liquid supplement.
         *
         * Type of supplement product requested
         */
        type?: CodeableReference;
        /**
         * The product or brand name of the nutritional supplement such as "Acme Protein Shake".
         *
         * Product or brand name of the nutritional supplement
         */
        productName?: string;
        /**
         * Free text or additional instructions or information pertaining to the oral supplement.
         *
         * Instructions or additional information about the oral supplement
         */
        instruction?: string;
        /**
         * Schedule information for a supplement.
         *
         * Scheduling information for supplements
         */
        schedule?: NutritionOrder.SupplementScheduleComponent;
        /**
         * The amount of the nutritional supplement to be given.
         *
         * Amount of the nutritional supplement
         */
        quantity?: Quantity;
        static revive(json: any): NutritionOrderSupplementComponent;
        toJSON(): any;
    }
    class NutritionOrderOralDietTextureComponent extends BackboneElement {
        /**
         * The food type(s) (e.g. meats, all foods)  that the texture modification applies to.  This could be all foods types.
         *
         * Concepts that are used to identify an entity that is ingested for nutritional purposes
         */
        foodType?: CodeableConcept;
        /**
         * Any texture modifications (for solid foods) that should be made, e.g. easy to chew, chopped, ground, and pureed.
         *
         * Code to indicate how to alter the texture of the foods, e.g. pureed
         */
        modifier?: CodeableConcept;
        static revive(json: any): NutritionOrderOralDietTextureComponent;
        toJSON(): any;
    }
    class NutritionOrderOralDietNutrientComponent extends BackboneElement {
        /**
         * The nutrient that is being modified such as carbohydrate or sodium.
         *
         * Type of nutrient that is being modified
         */
        modifier?: CodeableConcept;
        /**
         * The quantity of the specified nutrient to include in diet.
         *
         * Quantity of the specified nutrient
         */
        amount?: Quantity;
        static revive(json: any): NutritionOrderOralDietNutrientComponent;
        toJSON(): any;
    }
    class OralDietScheduleComponent extends BackboneElement {
        /**
         * Indicates whether the product is only taken based on a precondition for taking the product.
         *
         * Take 'as needed' for x
         */
        asNeededFor?: CodeableConcept;
        /**
         * The time period and frequency at which the diet should be given.  The diet should be given for the combination of all schedules if more than one schedule is present.
         *
         * Scheduled frequency of diet
         */
        timing?: Timing[];
        /**
         * Indicates whether the product is only taken when needed within a specific dosing schedule.
         *
         * Take 'as needed'
         */
        asNeeded?: boolean;
        static revive(json: any): OralDietScheduleComponent;
        toJSON(): any;
    }
    class NutritionOrderOralDietComponent extends BackboneElement {
        /**
         * The kind of diet or dietary restriction such as fiber restricted diet or diabetic diet.
         *
         * Type of oral diet or diet restrictions that describe what can be consumed orally
         */
        type?: CodeableConcept[];
        /**
         * The required consistency (e.g. honey-thick, nectar-thick, thin, thickened.) of liquids or fluids served to the patient.
         *
         * The required consistency of fluids and liquids provided to the patient
         */
        fluidConsistencyType?: CodeableConcept[];
        /**
         * Class that describes any texture modifications required for the patient to safely consume various types of solid foods.
         *
         * Required  texture modifications
         */
        texture?: NutritionOrder.NutritionOrderOralDietTextureComponent[];
        /**
         * Free text or additional instructions or information pertaining to the oral diet.
         *
         * Instructions or additional information about the oral diet
         */
        instruction?: string;
        /**
         * Schedule information for an oral diet.
         *
         * Scheduling information for oral diets
         */
        schedule?: NutritionOrder.OralDietScheduleComponent;
        /**
         * Class that defines the quantity and type of nutrient modifications (for example carbohydrate, fiber or sodium) required for the oral diet.
         *
         * Required  nutrient modifications
         */
        nutrient?: NutritionOrder.NutritionOrderOralDietNutrientComponent[];
        static revive(json: any): NutritionOrderOralDietComponent;
        toJSON(): any;
    }
}
