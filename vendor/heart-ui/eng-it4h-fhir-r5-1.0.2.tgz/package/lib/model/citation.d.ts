import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { RelatedArtifact } from '../datatype/related-artifact';
import { UsageContext } from '../datatype/usage-context';
import { ArtifactAssessment } from '../model/artifact-assessment';
import { MetadataResource } from '../model/metadata-resource';
import { Organization } from '../model/organization';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
/**
 * HAPI/FHIR <b>Citation</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Citation">http://hl7.org/fhir/StructureDefinition/Citation</a>
 * </p>
 *
 */
export declare class Citation extends MetadataResource {
    /**
     * Who reviewed the citation record.
     *
     * Who reviewed the citation record
     */
    reviewer?: ContactDetail[];
    /**
     * The identifier that is used to identify this version of the citation record when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the citation record author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the citation record
     */
    version?: string;
    /**
     * The assignment to an organizing scheme.
     *
     * The assignment to an organizing scheme
     */
    classification?: Citation.CitationClassificationComponent[];
    /**
     * An absolute URI that is used to identify this citation record when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this summary is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the summary is stored on different servers.
     *
     * Canonical identifier for this citation record, represented as a globally unique URI
     */
    url?: string;
    /**
     * A formal identifier that is used to identify this citation record when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Identifier for the citation record itself
     */
    identifier?: Identifier[];
    /**
     * Who edited or revised the citation record.
     *
     * Who edited the citation record
     */
    editor?: ContactDetail[];
    /**
     * A human-readable display of key concepts to represent the citation.
     *
     * A human-readable display of key concepts to represent the citation
     */
    summary?: Citation.CitationSummaryComponent[];
    /**
     * Artifact related to the citation record.
     *
     * Artifact related to the citation record
     */
    relatedArtifact?: RelatedArtifact[];
    /**
     * The article or artifact being described.
     *
     * The article or artifact being described
     */
    citedArtifact?: Citation.CitationCitedArtifactComponent;
    /**
     * The period during which the citation record content was or is planned to be in active use.
     *
     * When the citation record is expected to be used
     */
    effectivePeriod?: Period;
    /**
     * Who authored or created the citation record.
     *
     * Who authored the citation record
     */
    author?: ContactDetail[];
    /**
     * The name of the organization or individual that published the citation record.
     *
     * The publisher of the citation record, not the publisher of the article or artifact being cited
     */
    publisher?: string;
    /**
     * A natural language name identifying the citation record. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this citation record (computer friendly)
     */
    name?: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate citation record instances.
     *
     * The context that the citation record content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * The status of the citation record.
     *
     * The status of the citation record
     */
    currentState?: CodeableConcept[];
    /**
     * The status of this summary. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s) for the ciation record, not for the cited artifact
     */
    copyrightLabel?: string;
    /**
     * The date on which the resource content was last reviewed. Review happens periodically after approval but does not change the original approval date.
     *
     * When the citation record was last reviewed by the publisher
     */
    lastReviewDate?: Date;
    /**
     * A free text natural language description of the citation from a consumer's perspective.
     *
     * Natural language description of the citation
     */
    description?: string;
    /**
     * A Boolean value to indicate that this citation record is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A short, descriptive, user-friendly title for the citation record.
     *
     * Name for this citation record (human friendly)
     */
    title?: string;
    /**
     * Used for general notes and annotations not coded elsewhere.
     *
     * Used for general notes and annotations not coded elsewhere
     */
    note?: Annotation[];
    /**
     * The date (and optionally time) when the citation record was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the citation record changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * The state or status of the citation record paired with an effective date or period for that state.
     *
     * An effective date or period for a status of the citation record
     */
    statusDate?: Citation.CitationStatusDateComponent[];
    /**
     * The date on which the resource content was approved by the publisher. Approval happens once when the content is officially approved for usage.
     *
     * When the citation record was approved by publisher
     */
    approvalDate?: Date;
    /**
     * Use and/or publishing restrictions for the citation record, not for the cited artifact.
     *
     * Use and/or publishing restrictions for the citation record, not for the cited artifact
     */
    copyright?: string;
    /**
     * Explanation of why this citation is needed and why it has been designed as it has.
     *
     * Why this citation is defined
     */
    purpose?: string;
    /**
     * A legal or geographic region in which the citation record is intended to be used.
     *
     * Intended jurisdiction for citation record (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * Who endorsed the citation record.
     *
     * Who endorsed the citation record
     */
    endorser?: ContactDetail[];
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher of the citation record
     */
    contact?: ContactDetail[];
    readonly resourceType: string;
    static revive(json: any): Citation;
    toJSON(): any;
}
export declare namespace Citation {
    enum RelatedArtifactTypeExpanded {
        CITATION,
        REPLACES,
        DOCUMENTATION,
        SIMILARTO,
        CORRECTS,
        SIGNS,
        SUPPORTEDWITH,
        DERIVEDFROM,
        SUPPORTS,
        CITEAS,
        CONTAINEDIN,
        CONTAINS,
        TRANSFORMEDINTO,
        DOCUMENTS,
        CITES,
        SPECIFICATIONOF,
        COMMENTSON,
        REPLACEDWITH,
        APPENDEDWITH,
        COMMENTIN,
        NULL,
        AMENDS,
        COMPOSEDOF,
        REPRINT,
        PARTOF,
        REPRINTOF,
        JUSTIFICATION,
        CORRECTIONIN,
        RETRACTS,
        AMENDEDWITH,
        CITEDBY,
        APPENDS,
        SUCCESSOR,
        PREDECESSOR,
        DEPENDSON,
        RETRACTEDBY,
        TRANSFORMEDWITH,
        CREATEDWITH,
        TRANSFORMS
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class ContributorshipSummaryComponent extends BackboneElement {
        /**
         * Used to code the producer or rule for creating the display string.
         *
         * Used to code the producer or rule for creating the display string
         */
        source?: CodeableConcept;
        /**
         * The format for the display string, such as author last name with first letter capitalized followed by forename initials.
         *
         * The format for the display string
         */
        style?: CodeableConcept;
        /**
         * The display string for the author list, contributor list, or contributorship statement.
         *
         * The display string for the author list, contributor list, or contributorship statement
         */
        value: string;
        /**
         * Used most commonly to express an author list or a contributorship statement.
         *
         * Such as author list, contributorship statement, funding statement, acknowledgements statement, or conflicts of interest statement
         */
        type?: CodeableConcept;
        static revive(json: any): ContributorshipSummaryComponent;
        toJSON(): any;
    }
    class CitationCitedArtifactContributorshipEntryContributionInstanceComponent extends BackboneElement {
        /**
         * The specific contribution.
         *
         * The specific contribution
         */
        type: CodeableConcept;
        /**
         * The time that the contribution was made.
         *
         * The time that the contribution was made
         */
        time?: Date;
        static revive(json: any): CitationCitedArtifactContributorshipEntryContributionInstanceComponent;
        toJSON(): any;
    }
    class CitationCitedArtifactContributorshipEntryComponent extends BackboneElement {
        /**
         * For citation styles that use initials.
         *
         * For citation styles that use initials
         */
        forenameInitials?: string;
        /**
         * Whether the contributor is the corresponding contributor for the role.
         *
         * Whether the contributor is the corresponding contributor for the role
         */
        correspondingContact?: boolean;
        /**
         * Provides a numerical ranking to represent the degree of contributorship relative to other contributors, such as 1 for first author and 2 for second author.
         *
         * Ranked order of contribution
         */
        rankingOrder?: number;
        /**
         * This element identifies the specific nature of an individual’s contribution with respect to the cited work.
         *
         * The specific contribution
         */
        contributionType?: CodeableConcept[];
        /**
         * The identity of the individual contributor.
         *
         * The identity of the individual contributor
         */
        contributor: Practitioner | Organization | Reference;
        /**
         * The role of the contributor (e.g. author, editor, reviewer, funder).
         *
         * The role of the contributor (e.g. author, editor, reviewer, funder)
         */
        role?: CodeableConcept;
        /**
         * Contributions with accounting for time or number.
         *
         * Contributions with accounting for time or number
         */
        contributionInstance?: Citation.CitationCitedArtifactContributorshipEntryContributionInstanceComponent[];
        /**
         * Organization affiliated with the contributor.
         *
         * Organizational affiliation
         */
        affiliation?: Organization[] | PractitionerRole[] | Reference[];
        static revive(json: any): CitationCitedArtifactContributorshipEntryComponent;
        toJSON(): any;
    }
    class CitationCitedArtifactContributorshipComponent extends BackboneElement {
        /**
         * Indicates if the list includes all authors and/or contributors.
         *
         * Indicates if the list includes all authors and/or contributors
         */
        complete?: boolean;
        /**
         * An individual entity named as a contributor, for example in the author list or contributor list.
         *
         * An individual entity named as a contributor
         */
        entry?: Citation.CitationCitedArtifactContributorshipEntryComponent[];
        /**
         * Used to record a display of the author/contributor list without separate data element for each list member.
         *
         * Used to record a display of the author/contributor list without separate data element for each list member
         */
        summary?: Citation.ContributorshipSummaryComponent[];
        static revive(json: any): CitationCitedArtifactContributorshipComponent;
        toJSON(): any;
    }
    class CitationCitedArtifactClassificationComponent extends BackboneElement {
        /**
         * The kind of classifier (e.g. publication type, keyword).
         *
         * The kind of classifier (e.g. publication type, keyword)
         */
        type?: CodeableConcept;
        /**
         * Complex or externally created classification.
         *
         * Complex or externally created classification
         */
        artifactAssessment?: ArtifactAssessment[] | Reference[];
        /**
         * The specific classification value.
         *
         * The specific classification value
         */
        classifier?: CodeableConcept[];
        static revive(json: any): CitationCitedArtifactClassificationComponent;
        toJSON(): any;
    }
    class CitationCitedArtifactWebLocationComponent extends BackboneElement {
        /**
         * A characterization of the object expected at the web location.
         *
         * Code the reason for different URLs, e.g. abstract and full-text
         */
        classifier?: CodeableConcept[];
        /**
         * The specific URL.
         *
         * The specific URL
         */
        url?: string;
        static revive(json: any): CitationCitedArtifactWebLocationComponent;
        toJSON(): any;
    }
    class CitationCitedArtifactPublicationFormPublishedInComponent extends BackboneElement {
        /**
         * Journal identifiers include ISSN, ISO Abbreviation and NLMuniqueID; Book identifiers include ISBN.
         *
         * Journal identifiers include ISSN, ISO Abbreviation and NLMuniqueID; Book identifiers include ISBN
         */
        identifier?: Identifier[];
        /**
         * Name of or resource describing the publisher.
         *
         * Name of or resource describing the publisher
         */
        publisher?: Organization | Reference;
        /**
         * Geographic location of the publisher.
         *
         * Geographic location of the publisher
         */
        publisherLocation?: string;
        /**
         * Kind of container (e.g. Periodical, database, or book).
         *
         * Kind of container (e.g. Periodical, database, or book)
         */
        type?: CodeableConcept;
        /**
         * Name of the database or title of the book or journal.
         *
         * Name of the database or title of the book or journal
         */
        title?: string;
        static revive(json: any): CitationCitedArtifactPublicationFormPublishedInComponent;
        toJSON(): any;
    }
    class CitationCitedArtifactPublicationFormComponent extends BackboneElement {
        /**
         * Actual or approximate number of pages or screens. Distinct from reporting the page numbers.
         *
         * Number of pages or screens
         */
        pageCount?: string;
        /**
         * Copyright notice for the full article or artifact.
         *
         * Copyright notice for the full article or artifact
         */
        copyright?: string;
        /**
         * Issue, part or supplement of journal or other collection in which the article is published.
         *
         * Issue, part or supplement of journal or other collection in which the article is published
         */
        issue?: string;
        /**
         * Used for isolated representation of last page.
         *
         * Used for isolated representation of last page
         */
        lastPage?: string;
        /**
         * Spring, Summer, Fall/Autumn, Winter.
         *
         * Season in which the cited artifact was published
         */
        publicationDateSeason?: string;
        /**
         * The language or languages in which this form of the article is published.
         *
         * Language(s) in which this form of the article is published
         */
        language?: CodeableConcept[];
        /**
         * Entry number or identifier for inclusion in a database.
         *
         * Entry number or identifier for inclusion in a database
         */
        accessionNumber?: string;
        /**
         * Volume number of journal or other collection in which the article is published.
         *
         * Volume number of journal or other collection in which the article is published
         */
        volume?: string;
        /**
         * Used for isolated representation of first page.
         *
         * Used for isolated representation of first page
         */
        firstPage?: string;
        /**
         * Text representation of the date on which the issue of the cited artifact was published.
         *
         * Text representation of the date on which the issue of the cited artifact was published
         */
        publicationDateText?: string;
        /**
         * The collection the cited article or artifact is published in.
         *
         * The collection the cited article or artifact is published in
         */
        publishedIn?: Citation.CitationCitedArtifactPublicationFormPublishedInComponent;
        /**
         * The date the article was last revised or updated in the database.
         *
         * The date the article was last revised or updated in the database
         */
        lastRevisionDate?: Date;
        /**
         * Used for full display of pagination.
         *
         * Used for full display of pagination
         */
        pageString?: string;
        /**
         * The date the article was added to the database, or the date the article was released.
         *
         * The date the article was added to the database, or the date the article was released
         */
        articleDate?: Date;
        /**
         * Describes the form of the medium cited. Common codes are "Internet" or "Print". The CitedMedium value set has 6 codes. The codes internet, print, and offline-digital-storage are the common codes for a typical publication form, though internet and print are more common for study citations. Three additional codes (each appending one of the primary codes with "-without-issue" are used for situations when a study is published both within an issue (of a periodical release as commonly done for journals) AND is published separately from the issue (as commonly done with early online publication), to represent specific identification of the publication form not associated with the issue.
         *
         * Internet or Print
         */
        citedMedium?: CodeableConcept;
        static revive(json: any): CitationCitedArtifactPublicationFormComponent;
        toJSON(): any;
    }
    class CitationCitedArtifactRelatesToComponent extends BackboneElement {
        /**
         * The related artifact, if the artifact is not a canonical resource, or a resource reference to a canonical resource.
         *
         * What artifact, if not a conformance resource
         */
        resourceReference?: Reference;
        /**
         * The type of relationship to the related artifact.
         *
         * documentation | justification | citation | predecessor | successor | derived-from | depends-on | composed-of | part-of | amends | amended-with | appends | appended-with | cites | cited-by | comments-on | comment-in | contains | contained-in | corrects | correction-in | replaces | replaced-with | retracts | retracted-by | signs | similar-to | supports | supported-with | transforms | transformed-into | transformed-with | documents | specification-of | created-with | cite-as | reprint | reprint-of
         */
        type: string;
        /**
         * A short label that can be used to reference the related artifact from elsewhere in the containing artifact, such as a footnote index.
         *
         * Short label
         */
        label?: string;
        /**
         * Provides additional classifiers of the related artifact.
         *
         * Additional classifiers
         */
        classifier?: CodeableConcept[];
        /**
         * A brief description of the document or knowledge resource being referenced, suitable for display to a consumer.
         *
         * Brief description of the related artifact
         */
        display?: string;
        /**
         * The document being referenced, represented as an attachment. Do not use this element if using the resource element to provide the canonical to the related artifact.
         *
         * What document is being referenced
         */
        document?: Attachment;
        /**
         * A bibliographic citation for the related artifact. This text SHOULD be formatted according to an accepted citation format.
         *
         * Bibliographic citation for the artifact
         */
        citation?: string;
        /**
         * The related artifact, such as a library, value set, profile, or other knowledge resource.
         *
         * What artifact is being referenced
         */
        resource?: string;
        static revive(json: any): CitationCitedArtifactRelatesToComponent;
        toJSON(): any;
    }
    class CitationCitedArtifactPartComponent extends BackboneElement {
        /**
         * The citation for the full article or artifact.
         *
         * The citation for the full article or artifact
         */
        baseCitation?: Citation | Reference;
        /**
         * The specification of the component.
         *
         * The specification of the component
         */
        value?: string;
        /**
         * The kind of component.
         *
         * The kind of component
         */
        type?: CodeableConcept;
        static revive(json: any): CitationCitedArtifactPartComponent;
        toJSON(): any;
    }
    class CitationCitedArtifactAbstractComponent extends BackboneElement {
        /**
         * Copyright notice for the abstract.
         *
         * Copyright notice for the abstract
         */
        copyright?: string;
        /**
         * Used to express the reason for or classification of the abstract.
         *
         * The kind of abstract
         */
        type?: CodeableConcept;
        /**
         * Abstract content.
         *
         * Abstract content
         */
        text: string;
        /**
         * Used to express the specific language of the abstract.
         *
         * Used to express the specific language
         */
        language?: CodeableConcept;
        static revive(json: any): CitationCitedArtifactAbstractComponent;
        toJSON(): any;
    }
    class CitationCitedArtifactTitleComponent extends BackboneElement {
        /**
         * Used to express the reason for or classification of the title.
         *
         * The kind of title
         */
        type?: CodeableConcept[];
        /**
         * Used to express the specific language of the title.
         *
         * Used to express the specific language
         */
        language?: CodeableConcept;
        /**
         * The title of the article or artifact.
         *
         * The title of the article or artifact
         */
        text: string;
        static revive(json: any): CitationCitedArtifactTitleComponent;
        toJSON(): any;
    }
    class CitationCitedArtifactStatusDateComponent extends BackboneElement {
        /**
         * Either occurred or expected.
         *
         * Either occurred or expected
         */
        actual?: boolean;
        /**
         * When the status started and/or ended.
         *
         * When the status started and/or ended
         */
        period: Period;
        /**
         * A definition of the status associated with a date or period.
         *
         * Classification of the status
         */
        activity: CodeableConcept;
        static revive(json: any): CitationCitedArtifactStatusDateComponent;
        toJSON(): any;
    }
    class CitationCitedArtifactVersionComponent extends BackboneElement {
        /**
         * Citation for the main version of the cited artifact.
         *
         * Citation for the main version of the cited artifact
         */
        baseCitation?: Citation | Reference;
        /**
         * The version number or other version identifier.
         *
         * The version number or other version identifier
         */
        value: string;
        static revive(json: any): CitationCitedArtifactVersionComponent;
        toJSON(): any;
    }
    class CitationCitedArtifactComponent extends BackboneElement {
        /**
         * The component of the article or artifact.
         *
         * The component of the article or artifact
         */
        part?: Citation.CitationCitedArtifactPartComponent;
        /**
         * A formal identifier that is used to identify things closely related to the cited artifact.
         *
         * Identifier not unique to the cited artifact. May include trial registry identifiers
         */
        relatedIdentifier?: Identifier[];
        /**
         * A formal identifier that is used to identify the cited artifact when it is represented in other formats, or referenced in a specification, model, design or an instance.
         *
         * Unique identifier. May include DOI, PMID, PMCID, etc
         */
        identifier?: Identifier[];
        /**
         * Any additional information or content for the article or artifact.
         *
         * Any additional information or content for the article or artifact
         */
        note?: Annotation[];
        /**
         * An effective date or period, historical or future, actual or expected, for a status of the cited artifact.
         *
         * An effective date or period for a status of the cited artifact
         */
        statusDate?: Citation.CitationCitedArtifactStatusDateComponent[];
        /**
         * The defined version of the cited artifact.
         *
         * The defined version of the cited artifact
         */
        version?: Citation.CitationCitedArtifactVersionComponent;
        /**
         * When the cited artifact was accessed.
         *
         * When the cited artifact was accessed
         */
        dateAccessed?: Date;
        /**
         * The title details of the article or artifact.
         *
         * The title details of the article or artifact
         */
        title?: Citation.CitationCitedArtifactTitleComponent[];
        /**
         * Used for any URL for the article or artifact cited.
         *
         * Used for any URL for the article or artifact cited
         */
        webLocation?: Citation.CitationCitedArtifactWebLocationComponent[];
        /**
         * The assignment to an organizing scheme.
         *
         * The assignment to an organizing scheme
         */
        classification?: Citation.CitationCitedArtifactClassificationComponent[];
        /**
         * This element is used to list authors and other contributors, their contact information, specific contributions, and summary statements.
         *
         * Attribution of authors and other contributors
         */
        contributorship?: Citation.CitationCitedArtifactContributorshipComponent;
        /**
         * The abstract may be used to convey article-contained abstracts, externally-created abstracts, or other descriptive summaries.
         *
         * Summary of the article or artifact
         */
        abstract?: Citation.CitationCitedArtifactAbstractComponent[];
        /**
         * The status of the cited artifact.
         *
         * The status of the cited artifact
         */
        currentState?: CodeableConcept[];
        /**
         * The artifact related to the cited artifact.
         *
         * The artifact related to the cited artifact
         */
        relatesTo?: Citation.CitationCitedArtifactRelatesToComponent[];
        /**
         * If multiple, used to represent alternative forms of the article that are not separate citations.
         *
         * If multiple, used to represent alternative forms of the article that are not separate citations
         */
        publicationForm?: Citation.CitationCitedArtifactPublicationFormComponent[];
        static revive(json: any): CitationCitedArtifactComponent;
        toJSON(): any;
    }
    class CitationStatusDateComponent extends BackboneElement {
        /**
         * When the status started and/or ended.
         *
         * When the status started and/or ended
         */
        period: Period;
        /**
         * Whether the status date is actual (has occurred) or expected (estimated or anticipated).
         *
         * Either occurred or expected
         */
        actual?: boolean;
        /**
         * The state or status of the citation record (that will be paired with the period).
         *
         * Classification of the status
         */
        activity: CodeableConcept;
        static revive(json: any): CitationStatusDateComponent;
        toJSON(): any;
    }
    class CitationClassificationComponent extends BackboneElement {
        /**
         * The specific classification value.
         *
         * The specific classification value
         */
        classifier?: CodeableConcept[];
        /**
         * The kind of classifier (e.g. publication type, keyword).
         *
         * The kind of classifier (e.g. publication type, keyword)
         */
        type?: CodeableConcept;
        static revive(json: any): CitationClassificationComponent;
        toJSON(): any;
    }
    class CitationSummaryComponent extends BackboneElement {
        /**
         * The human-readable display of the citation summary.
         *
         * The human-readable display of the citation summary
         */
        text: string;
        /**
         * Format for display of the citation summary.
         *
         * Format for display of the citation summary
         */
        style?: CodeableConcept;
        static revive(json: any): CitationSummaryComponent;
        toJSON(): any;
    }
}
