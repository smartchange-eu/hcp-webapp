import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Attachment } from '../datatype/attachment';
import { Coding } from '../datatype/coding';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { CarePlan } from '../model/care-plan';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Observation } from '../model/observation';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Procedure } from '../model/procedure';
import { RelatedPerson } from '../model/related-person';
import { ServiceRequest } from '../model/service-request';
/**
 * HAPI/FHIR <b>QuestionnaireResponse</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/QuestionnaireResponse">http://hl7.org/fhir/StructureDefinition/QuestionnaireResponse</a>
 * </p>
 *
 */
export declare class QuestionnaireResponse extends DomainResource {
    /**
     * Business identifiers assigned to this questionnaire response by the performer and/or other systems.  These identifiers remain constant as the resource is updated and propagates from server to server.
     *
     * Business identifier for this set of answers
     */
    identifier?: Identifier[];
    /**
     * A procedure or observation that this questionnaire was performed as part of the execution of.  For example, the surgery a checklist was executed as part of.
     *
     * Part of referenced event
     */
    partOf?: Observation[] | Procedure[] | Reference[];
    /**
     * The date and/or time that this questionnaire response was last modified by the user - e.g. changing answers or revising status.
     *
     * Date the answers were gathered
     */
    authored?: Date;
    /**
     * The Questionnaire that defines and organizes the questions for which answers are being provided.
     *
     * Canonical URL of Questionnaire being answered
     */
    questionnaire: string;
    /**
     * A group or question item from the original questionnaire for which answers are provided.
     *
     * Groups and questions
     */
    item?: QuestionnaireResponse.QuestionnaireResponseItemComponent[];
    /**
     * The subject of the questionnaire response.  This could be a patient, organization, practitioner, device, etc.  This is who/what the answers apply to, but is not necessarily the source of information.
     *
     * The subject of the questions
     */
    subject?: Reference;
    /**
     * The individual or device that received the answers to the questions in the QuestionnaireResponse and recorded them in the system.
     *
     * The individual or device that received and recorded the answers
     */
    author?: Device | Practitioner | PractitionerRole | Patient | RelatedPerson | Organization | Reference;
    /**
     * The Encounter during which this questionnaire response was created or to which the creation of this record is tightly associated.
     *
     * Encounter the questionnaire response is part of
     */
    encounter?: Encounter | Reference;
    /**
     * The individual or device that answered the questions about the subject.
     *
     * The individual or device that answered the questions
     */
    source?: Device | Organization | Patient | Practitioner | PractitionerRole | RelatedPerson | Reference;
    /**
     * The current state of the questionnaire response.
     *
     * in-progress | completed | amended | entered-in-error | stopped
     */
    status: string;
    /**
     * A plan, proposal or order that is fulfilled in whole or in part by this questionnaire response.  For example, a ServiceRequest seeking an intake assessment or a decision support recommendation to assess for post-partum depression.
     *
     * Request fulfilled by this QuestionnaireResponse
     */
    basedOn?: CarePlan[] | ServiceRequest[] | Reference[];
    readonly resourceType: string;
    static revive(json: any): QuestionnaireResponse;
    toJSON(): any;
}
export declare namespace QuestionnaireResponse {
    enum QuestionnaireResponseStatus {
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        AMENDED,
        STOPPED,
        INPROGRESS
    }
    class QuestionnaireResponseItemAnswerComponent extends BackboneElement {
        /**
         * The answer (or one of the answers) provided by the respondent to the question.
         *
         * Single-valued answer to the question
         */
        value: boolean | number | number | Date | Date | Date | string | Attachment | Coding | Quantity | Reference;
        /**
         * Nested groups and/or questions found within this particular answer.
         *
         * Child items of question
         */
        item?: QuestionnaireResponse.QuestionnaireResponseItemComponent[];
        static revive(json: any): QuestionnaireResponseItemAnswerComponent;
        toJSON(): any;
    }
    class QuestionnaireResponseItemComponent extends BackboneElement {
        /**
         * The respondent's answer(s) to the question.
         *
         * The response(s) to the question
         */
        answer?: QuestionnaireResponse.QuestionnaireResponseItemAnswerComponent[];
        /**
         * Sub-questions, sub-groups or display items nested beneath a group.
         *
         * Child items of group item
         */
        item?: QuestionnaireResponse.QuestionnaireResponseItemComponent[];
        /**
         * The item from the Questionnaire that corresponds to this item in the QuestionnaireResponse resource.
         *
         * Pointer to specific item from Questionnaire
         */
        linkId: string;
        /**
         * A reference to an [ElementDefinition](elementdefinition.html) that provides the details for the item.
         *
         * ElementDefinition - details for the item
         */
        definition?: string;
        /**
         * Text that is displayed above the contents of the group or as the text of the question being answered.
         *
         * Name for group or question text
         */
        text?: string;
        static revive(json: any): QuestionnaireResponseItemComponent;
        toJSON(): any;
    }
}
