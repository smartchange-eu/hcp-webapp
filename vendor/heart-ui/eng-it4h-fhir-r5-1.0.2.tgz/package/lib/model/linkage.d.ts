import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { DomainResource } from '../model/domain-resource';
import { Organization } from '../model/organization';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
/**
 * HAPI/FHIR <b>Linkage</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Linkage">http://hl7.org/fhir/StructureDefinition/Linkage</a>
 * </p>
 *
 */
export declare class Linkage extends DomainResource {
    /**
     * Identifies which record considered as the reference to the same real-world occurrence as well as how the items should be evaluated within the collection of linked items.
     *
     * Item to be linked
     */
    item: Linkage.LinkageItemComponent[];
    /**
     * Identifies the user or organization responsible for asserting the linkages as well as the user or organization who establishes the context in which the nature of each linkage is evaluated.
     *
     * Who is responsible for linkages
     */
    author?: Practitioner | PractitionerRole | Organization | Reference;
    /**
     * Indicates whether the asserted set of linkages are considered to be "in effect".
     *
     * Whether this linkage assertion is active or not
     */
    active?: boolean;
    readonly resourceType: string;
    static revive(json: any): Linkage;
    toJSON(): any;
}
export declare namespace Linkage {
    enum LinkageType {
        ALTERNATE,
        NULL,
        HISTORICAL,
        SOURCE
    }
    class LinkageItemComponent extends BackboneElement {
        /**
         * The resource instance being linked as part of the group.
         *
         * Resource being linked
         */
        resource: Reference;
        /**
         * Distinguishes which item is "source of truth" (if any) and which items are no longer considered to be current representations.
         *
         * source | alternate | historical
         */
        type: string;
        static revive(json: any): LinkageItemComponent;
        toJSON(): any;
    }
}
