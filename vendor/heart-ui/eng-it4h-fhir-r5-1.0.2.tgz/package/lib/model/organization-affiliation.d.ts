import { Reference } from '../datatype/reference';
import { CodeableConcept } from '../datatype/codeable-concept';
import { ExtendedContactDetail } from '../datatype/extended-contact-detail';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { DomainResource } from '../model/domain-resource';
import { Endpoint } from '../model/endpoint';
import { HealthcareService } from '../model/healthcare-service';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
/**
 * HAPI/FHIR <b>OrganizationAffiliation</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/OrganizationAffiliation">http://hl7.org/fhir/StructureDefinition/OrganizationAffiliation</a>
 * </p>
 *
 */
export declare class OrganizationAffiliation extends DomainResource {
    /**
     * Organization where the role is available (primary organization/has members).
     *
     * Organization where the role is available
     */
    organization?: Organization | Reference;
    /**
     * The contact details of communication devices available at the participatingOrganization relevant to this Affiliation.
     *
     * Official contact details at the participatingOrganization relevant to this Affiliation
     */
    contact?: ExtendedContactDetail[];
    /**
     * Healthcare services provided through the role.
     *
     * Healthcare services provided through the role
     */
    healthcareService?: HealthcareService[] | Reference[];
    /**
     * Definition of the role the participatingOrganization plays in the association.
     *
     * Definition of the role the participatingOrganization plays
     */
    code?: CodeableConcept[];
    /**
     * The period during which the participatingOrganization is affiliated with the primary organization.
     *
     * The period during which the participatingOrganization is affiliated with the primary organization
     */
    period?: Period;
    /**
     * Specific specialty of the participatingOrganization in the context of the role.
     *
     * Specific specialty of the participatingOrganization in the context of the role
     */
    specialty?: CodeableConcept[];
    /**
     * Technical endpoints providing access to services operated for this role.
     *
     * Technical endpoints providing access to services operated for this role
     */
    endpoint?: Endpoint[] | Reference[];
    /**
     * Business identifiers that are specific to this role.
     *
     * Business identifiers that are specific to this role
     */
    identifier?: Identifier[];
    /**
     * The network in which the participatingOrganization provides the role's services (if defined) at the indicated locations (if defined).
     *
     * The network in which the participatingOrganization provides the role's services (if defined) at the indicated locations (if defined)
     */
    network?: Organization[] | Reference[];
    /**
     * The location(s) at which the role occurs.
     *
     * The location(s) at which the role occurs
     */
    location?: Location[] | Reference[];
    /**
     * Whether this organization affiliation record is in active use.
     *
     * Whether this organization affiliation record is in active use
     */
    active?: boolean;
    /**
     * The Participating Organization provides/performs the role(s) defined by the code to the Primary Organization (e.g. providing services or is a member of).
     *
     * Organization that provides/performs the role (e.g. providing services or is a member of)
     */
    participatingOrganization?: Organization | Reference;
    readonly resourceType: string;
    static revive(json: any): OrganizationAffiliation;
    toJSON(): any;
}
