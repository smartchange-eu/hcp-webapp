import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Period } from '../datatype/period';
import { Signature } from '../datatype/signature';
import { CarePlan } from '../model/care-plan';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DeviceRequest } from '../model/device-request';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { ImmunizationRecommendation } from '../model/immunization-recommendation';
import { Location } from '../model/location';
import { MedicationRequest } from '../model/medication-request';
import { NutritionOrder } from '../model/nutrition-order';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
import { ServiceRequest } from '../model/service-request';
import { Task } from '../model/task';
/**
 * HAPI/FHIR <b>Provenance</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Provenance">http://hl7.org/fhir/StructureDefinition/Provenance</a>
 * </p>
 *
 */
export declare class Provenance extends DomainResource {
    /**
     * An actor taking a role in an activity  for which it can be assigned some degree of responsibility for the activity taking place.
     *
     * Actor involved
     */
    agent: Provenance.ProvenanceAgentComponent[];
    /**
     * A digital signature on the target Reference(s). The signer should match a Provenance.agent. The purpose of the signature is indicated.
     *
     * Signature on target
     */
    signature?: Signature[];
    /**
     * The period during which the activity occurred.
     *
     * When the activity occurred
     */
    occurred?: Period | Date;
    /**
     * An activity is something that occurs over a period of time and acts upon or with entities; it may include consuming, processing, transforming, modifying, relocating, using, or generating entities.
     *
     * Activity that occurred
     */
    activity?: CodeableConcept;
    /**
     * This will typically be the encounter the event occurred, but some events may be initiated prior to or after the official completion of an encounter but still be tied to the context of the encounter (e.g. pre-admission lab tests).
     *
     * Encounter within which this event occurred or which the event is tightly associated
     */
    encounter?: Encounter | Reference;
    /**
     * The Reference(s) that were generated or updated by  the activity described in this resource. A provenance can point to more than one target if multiple resources were created/updated by the same activity.
     *
     * Target Reference(s) (usually version specific)
     */
    target: Reference[];
    /**
     * The instant of time at which the activity was recorded.
     *
     * When the activity was recorded / updated
     */
    recorded?: Date;
    /**
     * The authorization (e.g., PurposeOfUse) that was used during the event being recorded.
     *
     * Authorization (purposeOfUse) related to the event
     */
    authorization?: CodeableReference[];
    /**
     * The patient element is available to enable deterministic tracking of activities that involve the patient as the subject of the data used in an activity.
     *
     * The patient is the subject of the data created/updated (.target) by the activity
     */
    patient?: Patient | Reference;
    /**
     * Where the activity occurred, if relevant.
     *
     * Where the activity occurred, if relevant
     */
    location?: Location | Reference;
    /**
     * Policy or plan the activity was defined by. Typically, a single activity may have multiple applicable policy documents, such as patient consent, guarantor funding, etc.
     *
     * Policy or plan the activity was defined by
     */
    policy?: string[];
    /**
     * Allows tracing of authorizatino for the events and tracking whether proposals/recommendations were acted upon.
     *
     * Workflow authorization within which this event occurred
     */
    basedOn?: CarePlan[] | DeviceRequest[] | ImmunizationRecommendation[] | MedicationRequest[] | NutritionOrder[] | ServiceRequest[] | Task[] | Reference[];
    /**
     * An entity used in this activity.
     *
     * An entity used in this activity
     */
    entity?: Provenance.ProvenanceEntityComponent[];
    readonly resourceType: string;
    static revive(json: any): Provenance;
    toJSON(): any;
}
export declare namespace Provenance {
    enum ProvenanceEntityRole {
        REVISION,
        REMOVAL,
        NULL,
        QUOTATION,
        SOURCE,
        INSTANTIATES
    }
    class ProvenanceEntityComponent extends BackboneElement {
        /**
         * The entity is attributed to an agent to express the agent's responsibility for that entity, possibly along with other agents. This description can be understood as shorthand for saying that the agent was responsible for the activity which used the entity.
         *
         * Entity is attributed to this agent
         */
        agent?: Provenance.ProvenanceAgentComponent[];
        /**
         * How the entity was used during the activity.
         *
         * revision | quotation | source | instantiates | removal
         */
        role: string;
        /**
         * Identity of the  Entity used. May be a logical or physical uri and maybe absolute or relative.
         *
         * Identity of entity
         */
        what: Reference;
        static revive(json: any): ProvenanceEntityComponent;
        toJSON(): any;
    }
    class ProvenanceAgentComponent extends BackboneElement {
        /**
         * The structural roles of the agent indicating the agent's competency. The security role enabling the agent with respect to the activity.
         *
         * What the agents role was
         */
        role?: CodeableConcept[];
        /**
         * Indicates who or what performed in the event.
         *
         * The agent that participated in the event
         */
        who: Practitioner | PractitionerRole | Organization | CareTeam | Patient | Device | RelatedPerson | Reference;
        /**
         * The Functional Role of the agent with respect to the activity.
         *
         * How the agent participated
         */
        type?: CodeableConcept;
        /**
         * The agent that delegated authority to perform the activity performed by the agent.who element.
         *
         * The agent that delegated
         */
        onBehalfOf?: Practitioner | PractitionerRole | Organization | CareTeam | Patient | Reference;
        static revive(json: any): ProvenanceAgentComponent;
        toJSON(): any;
    }
}
