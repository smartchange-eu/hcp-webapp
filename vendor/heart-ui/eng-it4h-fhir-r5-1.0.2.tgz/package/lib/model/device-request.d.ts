import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { Timing } from '../datatype/timing';
import { ClaimResponse } from '../model/claim-response';
import { Coverage } from '../model/coverage';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Provenance } from '../model/provenance';
/**
 * HAPI/FHIR <b>DeviceRequest</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/DeviceRequest">http://hl7.org/fhir/StructureDefinition/DeviceRequest</a>
 * </p>
 *
 */
export declare class DeviceRequest extends DomainResource {
    /**
     * The URL pointing to an externally maintained protocol, guideline, orderset or other definition that is adhered to in whole or in part by this DeviceRequest.
     *
     * Instantiates external protocol or definition
     */
    instantiatesUri?: string[];
    /**
     * Key events in the history of the request.
     *
     * Request provenance
     */
    relevantHistory?: Provenance[] | Reference[];
    /**
     * The reason for using the device.
     *
     * Device usage reason
     */
    asNeededFor?: CodeableConcept;
    /**
     * The timing schedule for the use of the device. The Schedule data type allows many different expressions, for example. "Every 8 hours"; "Three times a day"; "1/2 an hour before breakfast for 10 days from 23-Dec 2011:"; "15 Oct 2013, 17 Oct 2013 and 1 Nov 2013".
     *
     * Desired time or schedule for use
     */
    occurrence?: Date | Period | Timing;
    /**
     * The patient who will use the device.
     *
     * Focus of request
     */
    subject: Patient | Group | Location | Device | Reference;
    /**
     * Insurance plans, coverage extensions, pre-authorizations and/or pre-determinations that may be required for delivering the requested service.
     *
     * Associated insurance coverage
     */
    insurance?: Coverage[] | ClaimResponse[] | Reference[];
    /**
     * Reason or justification for the use of this device.
     *
     * Coded/Linked Reason for request
     */
    reason?: CodeableReference[];
    /**
     * Details about this request that were not represented at all or sufficiently in one of the attributes provided in a class. These may include for example a comment, an instruction, or a note associated with the statement.
     *
     * Notes or comments
     */
    note?: Annotation[];
    /**
     * The details of the device to be used.
     *
     * Device requested
     */
    code: CodeableReference;
    /**
     * If true, indicates that the provider is asking for the patient to either stop using or to not start using the specified device or category of devices. For example, the patient has undergone surgery and the provider is indicating that the patient should not wear contact lenses.
     *
     * True if the request is to stop or not to start using the device
     */
    doNotPerform?: boolean;
    /**
     * Plan/proposal/order fulfilled by this request.
     *
     * What request fulfills
     */
    basedOn?: Reference[];
    /**
     * Additional clinical information about the patient that may influence the request fulfilment.  For example, this may include where on the subject's body the device will be used (i.e. the target site).
     *
     * Additional clinical information
     */
    supportingInfo?: Reference[];
    /**
     * Specific parameters for the ordered item.  For example, the prism value for lenses.
     *
     * Device details
     */
    parameter?: DeviceRequest.DeviceRequestParameterComponent[];
    /**
     * This status is to indicate whether the request is a PRN or may be given as needed.
     *
     * PRN status of request
     */
    asNeeded?: boolean;
    /**
     * The URL pointing to a FHIR-defined protocol, guideline, orderset or other definition that is adhered to in whole or in part by this DeviceRequest.
     *
     * Instantiates FHIR protocol or definition
     */
    instantiatesCanonical?: string[];
    /**
     * Indicates how quickly the request should be addressed with respect to other requests.
     *
     * routine | urgent | asap | stat
     */
    priority?: string;
    /**
     * Whether the request is a proposal, plan, an original order or a reflex order.
     *
     * proposal | plan | directive | order | original-order | reflex-order | filler-order | instance-order | option
     */
    intent: string;
    /**
     * An encounter that provides additional context in which this request is made.
     *
     * Encounter motivating request
     */
    encounter?: Encounter | Reference;
    /**
     * The request takes the place of the referenced completed or terminated request(s).
     *
     * What request replaces
     */
    replaces?: DeviceRequest[] | Reference[];
    /**
     * The individual or entity who initiated the request and has responsibility for its activation.
     *
     * Who/what submitted the device request
     */
    requester?: Device | Practitioner | PractitionerRole | Organization | Reference;
    /**
     * Identifiers assigned to this order by the orderer or by the receiver.
     *
     * External Request identifier
     */
    identifier?: Identifier[];
    /**
     * The number of devices to be provided.
     *
     * Quantity of devices to supply
     */
    quantity?: number;
    /**
     * When the request transitioned to being actionable.
     *
     * When recorded
     */
    authoredOn?: Date;
    /**
     * The desired individual or entity to provide the device to the subject of the request (e.g., patient, location).
     *
     * Requested Filler
     */
    performer?: CodeableReference;
    /**
     * A shared identifier common to multiple independent Request instances that were activated/authorized more or less simultaneously by a single author.  The presence of the same identifier on each request ties those requests together and may have business ramifications in terms of reporting of results, billing, etc.  E.g. a requisition number shared by a set of lab tests ordered together, or a prescription number shared by all meds ordered at one time.
     *
     * Identifier of composite request
     */
    groupIdentifier?: Identifier;
    /**
     * The status of the request.
     *
     * draft | active | on-hold | revoked | completed | entered-in-error | unknown
     */
    status?: string;
    readonly resourceType: string;
    static revive(json: any): DeviceRequest;
    toJSON(): any;
}
export declare namespace DeviceRequest {
    enum RequestStatus {
        REVOKED,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ACTIVE,
        DRAFT,
        ONHOLD,
        UNKNOWN
    }
    enum RequestIntent {
        ORDER,
        FILLERORDER,
        ORIGINALORDER,
        NULL,
        REFLEXORDER,
        DIRECTIVE,
        OPTION,
        PROPOSAL,
        PLAN,
        INSTANCEORDER
    }
    enum RequestPriority {
        URGENT,
        STAT,
        NULL,
        ROUTINE,
        ASAP
    }
    class DeviceRequestParameterComponent extends BackboneElement {
        /**
         * The value of the device detail.
         *
         * Value of detail
         */
        value?: CodeableConcept | Quantity | Range | boolean;
        /**
         * A code or string that identifies the device detail being asserted.
         *
         * Device detail
         */
        code?: CodeableConcept;
        static revive(json: any): DeviceRequestParameterComponent;
        toJSON(): any;
    }
}
