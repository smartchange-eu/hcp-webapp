import { Reference } from '../datatype/reference';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { HealthcareService } from '../model/healthcare-service';
import { Location } from '../model/location';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Schedule</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Schedule">http://hl7.org/fhir/StructureDefinition/Schedule</a>
 * </p>
 *
 */
export declare class Schedule extends DomainResource {
    /**
     * A broad categorization of the service that is to be performed during this appointment.
     *
     * High-level category
     */
    serviceCategory?: CodeableConcept[];
    /**
     * The period of time that the slots that reference this Schedule resource cover (even if none exist). These  cover the amount of time that an organization's planning horizon; the interval for which they are currently accepting appointments. This does not define a "template" for planning outside these dates.
     *
     * Period of time covered by schedule
     */
    planningHorizon?: Period;
    /**
     * Further description of the schedule as it would be presented to a consumer while searching.
     *
     * Human-readable label
     */
    name?: string;
    /**
     * Whether this schedule record is in active use or should not be used (such as was entered in error).
     *
     * Whether this schedule is in active use
     */
    active?: boolean;
    /**
     * Comments on the availability to describe any extended information. Such as custom constraints on the slots that may be associated.
     *
     * Comments on availability
     */
    comment?: string;
    /**
     * The specific service that is to be performed during this appointment.
     *
     * Specific service
     */
    serviceType?: CodeableReference[];
    /**
     * Slots that reference this schedule resource provide the availability details to these referenced resource(s).
     *
     * Resource(s) that availability information is being provided for
     */
    actor: Patient[] | Practitioner[] | PractitionerRole[] | CareTeam[] | RelatedPerson[] | Device[] | HealthcareService[] | Location[] | Reference[];
    /**
     * External Ids for this item.
     *
     * External Ids for this item
     */
    identifier?: Identifier[];
    /**
     * The specialty of a practitioner that would be required to perform the service requested in this appointment.
     *
     * Type of specialty needed
     */
    specialty?: CodeableConcept[];
    readonly resourceType: string;
    static revive(json: any): Schedule;
    toJSON(): any;
}
