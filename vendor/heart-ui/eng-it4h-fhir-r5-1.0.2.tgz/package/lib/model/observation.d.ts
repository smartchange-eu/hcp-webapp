import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { Ratio } from '../datatype/ratio';
import { SampledData } from '../datatype/sampled-data';
import { Timing } from '../datatype/timing';
import { BiologicallyDerivedProduct } from '../model/biologically-derived-product';
import { BodyStructure } from '../model/body-structure';
import { CarePlan } from '../model/care-plan';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DeviceMetric } from '../model/device-metric';
import { DeviceRequest } from '../model/device-request';
import { DocumentReference } from '../model/document-reference';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { GenomicStudy } from '../model/genomic-study';
import { Group } from '../model/group';
import { ImagingSelection } from '../model/imaging-selection';
import { ImagingStudy } from '../model/imaging-study';
import { Immunization } from '../model/immunization';
import { ImmunizationRecommendation } from '../model/immunization-recommendation';
import { Location } from '../model/location';
import { Medication } from '../model/medication';
import { MedicationAdministration } from '../model/medication-administration';
import { MedicationDispense } from '../model/medication-dispense';
import { MedicationRequest } from '../model/medication-request';
import { MedicationStatement } from '../model/medication-statement';
import { MolecularSequence } from '../model/molecular-sequence';
import { NutritionOrder } from '../model/nutrition-order';
import { NutritionProduct } from '../model/nutrition-product';
import { ObservationDefinition } from '../model/observation-definition';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Procedure } from '../model/procedure';
import { QuestionnaireResponse } from '../model/questionnaire-response';
import { RelatedPerson } from '../model/related-person';
import { ServiceRequest } from '../model/service-request';
import { Specimen } from '../model/specimen';
import { Substance } from '../model/substance';
/**
 * HAPI/FHIR <b>Observation</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Observation">http://hl7.org/fhir/StructureDefinition/Observation</a>
 * </p>
 *
 */
export declare class Observation extends DomainResource {
    /**
     * The healthcare event  (e.g. a patient and healthcare provider interaction) during which this observation is made.
     *
     * Healthcare event during which this observation is made
     */
    encounter?: Encounter | Reference;
    /**
     * Who was responsible for asserting the observed value as "true".
     *
     * Who is responsible for the observation
     */
    performer?: Practitioner[] | PractitionerRole[] | Organization[] | CareTeam[] | Patient[] | RelatedPerson[] | Reference[];
    /**
     * A unique identifier assigned to this observation.
     *
     * Business Identifier for observation
     */
    identifier?: Identifier[];
    /**
     * This observation is a group observation (e.g. a battery, a panel of tests, a set of vital sign measurements) that includes the target as a member of the group.
     *
     * Related resource that belongs to the Observation group
     */
    hasMember?: Observation[] | QuestionnaireResponse[] | MolecularSequence[] | Reference[];
    /**
     * Indicates the mechanism used to perform the observation.
     *
     * How it was done
     */
    method?: CodeableConcept;
    /**
     * Indicates the body structure on the subject's body where the observation was made (i.e. the target site).
     *
     * Observed body structure
     */
    bodyStructure?: BodyStructure | Reference;
    /**
     * Identifies the observation(s) that triggered the performance of this observation.
     *
     * Triggering observation(s)
     */
    triggeredBy?: Observation.ObservationTriggeredByComponent[];
    /**
     * The status of the result value.
     *
     * registered | preliminary | final | amended +
     */
    status: string;
    /**
     * A reference to the device that generates the measurements or the device settings for the device.
     *
     * A reference to the device that generates the measurements or the device settings for the device
     */
    device?: Device | DeviceMetric | Reference;
    /**
     * A code that classifies the general type of observation being made.
     *
     * Classification of  type of observation
     */
    category?: CodeableConcept[];
    /**
     * Indicates the site on the subject's body where the observation was made (i.e. the target site).
     *
     * Observed body part
     */
    bodySite?: CodeableConcept;
    /**
     * Guidance on how to interpret the value by comparison to a normal or recommended range.  Multiple reference ranges are interpreted as an "OR".   In other words, to represent two distinct target populations, two `referenceRange` elements would be used.
     *
     * Provides guide for interpretation
     */
    referenceRange?: Observation.ObservationReferenceRangeComponent[];
    /**
     * Some observations have multiple component observations.  These component observations are expressed as separate code value pairs that share the same attributes.  Examples include systolic and diastolic component observations for blood pressure measurement and multiple component observations for genetics observations.
     *
     * Component results
     */
    component?: Observation.ObservationComponentComponent[];
    /**
     * A categorical assessment of an observation value.  For example, high, low, normal.
     *
     * High, low, normal, etc
     */
    interpretation?: CodeableConcept[];
    /**
     * The actual focus of an observation when it is not the patient of record representing something or someone associated with the patient such as a spouse, parent, fetus, or donor. For example, fetus observations in a mother's record.  The focus of an observation could also be an existing condition,  an intervention, the subject's diet,  another observation of the subject,  or a body structure such as tumor or implanted device.   An example use case would be using the Observation resource to capture whether the mother is trained to change her child's tracheostomy tube. In this example, the child is the patient of record and the mother is the focus.
     *
     * What the observation is about, when it is not about the subject of record
     */
    focus?: Reference[];
    /**
     * Describes what was observed. Sometimes this is called the observation "name".
     *
     * Type of observation (code / type)
     */
    code: CodeableConcept;
    /**
     * The reference to a FHIR ObservationDefinition resource that provides the definition that is adhered to in whole or in part by this Observation instance.
     *
     * Instantiates FHIR ObservationDefinition
     */
    instantiates?: string | ObservationDefinition | Reference;
    /**
     * A larger event of which this particular Observation is a component or step.  For example,  an observation as part of a procedure.
     *
     * Part of referenced event
     */
    partOf?: MedicationAdministration[] | MedicationDispense[] | MedicationStatement[] | Procedure[] | Immunization[] | ImagingStudy[] | GenomicStudy[] | Reference[];
    /**
     * Provides a reason why the expected value in the element Observation.value[x] is missing.
     *
     * Why the result is missing
     */
    dataAbsentReason?: CodeableConcept;
    /**
     * Comments about the observation or the results.
     *
     * Comments about the observation
     */
    note?: Annotation[];
    /**
     * The patient, or group of patients, location, device, organization, procedure or practitioner this observation is about and into whose or what record the observation is placed. If the actual focus of the observation is different from the subject (or a sample of, part, or region of the subject), the `focus` element or the `code` itself specifies the actual focus of the observation.
     *
     * Who and/or what the observation is about
     */
    subject?: Patient | Group | Device | Location | Organization | Procedure | Practitioner | Medication | Substance | BiologicallyDerivedProduct | NutritionProduct | Reference;
    /**
     * The target resource that represents a measurement from which this observation value is derived. For example, a calculated anion gap or a fetal measurement based on an ultrasound image.
     *
     * Related resource from which the observation is made
     */
    derivedFrom?: DocumentReference[] | ImagingStudy[] | ImagingSelection[] | QuestionnaireResponse[] | Observation[] | MolecularSequence[] | GenomicStudy[] | Reference[];
    /**
     * A plan, proposal or order that is fulfilled in whole or in part by this event.  For example, a MedicationRequest may require a patient to have laboratory test performed before  it is dispensed.
     *
     * Fulfills plan, proposal or order
     */
    basedOn?: CarePlan[] | DeviceRequest[] | ImmunizationRecommendation[] | MedicationRequest[] | NutritionOrder[] | ServiceRequest[] | Reference[];
    /**
     * The information determined as a result of making the observation, if the information has a simple value.
     *
     * Actual result
     */
    value?: Quantity | CodeableConcept | string | boolean | number | Range | Ratio | SampledData | Date | Date | Period | Attachment | MolecularSequence | Reference;
    /**
     * The date and time this version of the observation was made available to providers, typically after the results have been reviewed and verified.
     *
     * Date/Time this version was made available
     */
    issued?: Date;
    /**
     * The time or time-period the observed value is asserted as being true. For biological subjects - e.g. human patients - this is usually called the "physiologically relevant time". This is usually either the time of the procedure or of specimen collection, but very often the source of the date/time is not known, only the date/time itself.
     *
     * Clinically relevant time/time-period for observation
     */
    effective?: Date | Period | Timing;
    /**
     * The specimen that was used when this observation was made.
     *
     * Specimen used for this observation
     */
    specimen?: Specimen | Group | Reference;
    readonly resourceType: string;
    static revive(json: any): Observation;
    toJSON(): any;
}
export declare namespace Observation {
    enum TriggeredBytype {
        NULL,
        REPEAT,
        REFLEX,
        RERUN
    }
    enum ObservationStatus {
        CANCELLED,
        ENTEREDINERROR,
        NULL,
        AMENDED,
        REGISTERED,
        CORRECTED,
        PRELIMINARY,
        FINAL,
        UNKNOWN
    }
    class ObservationComponentComponent extends BackboneElement {
        /**
         * The information determined as a result of making the observation, if the information has a simple value.
         *
         * Actual component result
         */
        value?: Quantity | CodeableConcept | string | boolean | number | Range | Ratio | SampledData | Date | Date | Period | Attachment | MolecularSequence | Reference;
        /**
         * A categorical assessment of an observation value.  For example, high, low, normal.
         *
         * High, low, normal, etc
         */
        interpretation?: CodeableConcept[];
        /**
         * Provides a reason why the expected value in the element Observation.component.value[x] is missing.
         *
         * Why the component result is missing
         */
        dataAbsentReason?: CodeableConcept;
        /**
         * Describes what was observed. Sometimes this is called the observation "code".
         *
         * Type of component observation (code / type)
         */
        code: CodeableConcept;
        /**
         * Guidance on how to interpret the value by comparison to a normal or recommended range.
         *
         * Provides guide for interpretation of component result
         */
        referenceRange?: Observation.ObservationReferenceRangeComponent[];
        static revive(json: any): ObservationComponentComponent;
        toJSON(): any;
    }
    class ObservationReferenceRangeComponent extends BackboneElement {
        /**
         * The value of the high bound of the reference range.  The high bound of the reference range endpoint is inclusive of the value (e.g.  reference range is >=5 - <=9). If the high bound is omitted,  it is assumed to be meaningless (e.g. reference range is >= 2.3).
         *
         * High Range, if relevant
         */
        high?: Quantity;
        /**
         * The value of the low bound of the reference range.  The low bound of the reference range endpoint is inclusive of the value (e.g.  reference range is >=5 - <=9). If the low bound is omitted,  it is assumed to be meaningless (e.g. reference range is <=2.3).
         *
         * Low Range, if relevant
         */
        low?: Quantity;
        /**
         * Codes to indicate the target population this reference range applies to.  For example, a reference range may be based on the normal population or a particular sex or race.  Multiple `appliesTo`  are interpreted as an "AND" of the target populations.  For example, to represent a target population of African American females, both a code of female and a code for African American would be used.
         *
         * Reference range population
         */
        appliesTo?: CodeableConcept[];
        /**
         * Text based reference range in an observation which may be used when a quantitative range is not appropriate for an observation.  An example would be a reference value of "Negative" or a list or table of "normals".
         *
         * Text based reference range in an observation
         */
        text?: string;
        /**
         * The value of the normal value of the reference range.
         *
         * Normal value, if relevant
         */
        normalValue?: CodeableConcept;
        /**
         * Codes to indicate the what part of the targeted reference population it applies to. For example, the normal or therapeutic range.
         *
         * Reference range qualifier
         */
        type?: CodeableConcept;
        /**
         * The age at which this reference range is applicable. This is a neonatal age (e.g. number of weeks at term) if the meaning says so.
         *
         * Applicable age range, if relevant
         */
        age?: Range;
        static revive(json: any): ObservationReferenceRangeComponent;
        toJSON(): any;
    }
    class ObservationTriggeredByComponent extends BackboneElement {
        /**
         * Reference to the triggering observation.
         *
         * Triggering observation
         */
        observation: Observation | Reference;
        /**
         * Provides the reason why this observation was performed as a result of the observation(s) referenced.
         *
         * Reason that the observation was triggered
         */
        reason?: string;
        /**
         * The type of trigger.
Reflex | Repeat | Re-run.
         *
         * reflex | repeat | re-run
         */
        type: string;
        static revive(json: any): ObservationTriggeredByComponent;
        toJSON(): any;
    }
}
