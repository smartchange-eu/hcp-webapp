import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Expression } from '../datatype/expression';
import { Identifier } from '../datatype/identifier';
import { MonetaryComponent } from '../datatype/monetary-component';
import { Period } from '../datatype/period';
import { RelatedArtifact } from '../datatype/related-artifact';
import { UsageContext } from '../datatype/usage-context';
import { ActivityDefinition } from '../model/activity-definition';
import { Device } from '../model/device';
import { DeviceDefinition } from '../model/device-definition';
import { HealthcareService } from '../model/healthcare-service';
import { Medication } from '../model/medication';
import { MetadataResource } from '../model/metadata-resource';
import { PlanDefinition } from '../model/plan-definition';
import { Substance } from '../model/substance';
/**
 * HAPI/FHIR <b>ChargeItemDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ChargeItemDefinition">http://hl7.org/fhir/StructureDefinition/ChargeItemDefinition</a>
 * </p>
 *
 */
export declare class ChargeItemDefinition extends MetadataResource {
    /**
     * A short, descriptive, user-friendly title for the charge item definition.
     *
     * Name for this charge item definition (human friendly)
     */
    title?: string;
    /**
     * A free text natural language description of the charge item definition from a consumer's perspective.
     *
     * Natural language description of the charge item definition
     */
    description?: string;
    /**
     * A Boolean value to indicate that this charge item definition is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * Explanation of why this charge item definition is needed and why it has been designed as it has.
     *
     * Why this charge item definition is defined
     */
    purpose?: string;
    /**
     * A legal or geographic region in which the charge item definition is intended to be used.
     *
     * Intended jurisdiction for charge item definition (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * The date  (and optionally time) when the charge item definition was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the charge item definition changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * Group of properties which are applicable under the same conditions. If no applicability rules are established for the group, then all properties always apply.
     *
     * Group of properties which are applicable under the same conditions
     */
    propertyGroup?: ChargeItemDefinition.ChargeItemDefinitionPropertyGroupComponent[];
    /**
     * A larger definition of which this particular definition is a component or step.
     *
     * A larger definition of which this particular definition is a component or step
     */
    partOf?: string[];
    /**
     * A copyright statement relating to the charge item definition and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the charge item definition.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * The date on which the resource content was approved by the publisher. Approval happens once when the content is officially approved for usage.
     *
     * When the charge item definition was approved by publisher
     */
    approvalDate?: Date;
    /**
     * The defined billing details in this resource pertain to the given billing code.
     *
     * Billing code or product type this definition applies to
     */
    code?: CodeableConcept;
    /**
     * The defined billing details in this resource pertain to the given product instance(s).
     *
     * Instances this definition applies to
     */
    instance?: Medication[] | Substance[] | Device[] | DeviceDefinition[] | ActivityDefinition[] | PlanDefinition[] | HealthcareService[] | Reference[];
    /**
     * The URL pointing to an externally-defined charge item definition that is adhered to in whole or in part by this definition.
     *
     * Underlying externally-defined charge item definition
     */
    derivedFromUri?: string[];
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * The identifier that is used to identify this version of the charge item definition when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the charge item definition author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence. To provide a version consistent with the Decision Support Service specification, use the format Major.Minor.Revision (e.g. 1.0.0). For more information on versioning knowledge assets, refer to the Decision Support Service specification. Note that a version is required for non-experimental active assets.
     *
     * Business version of the charge item definition
     */
    version?: string;
    /**
     * An absolute URI that is used to identify this charge item definition when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this charge item definition is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the charge item definition is stored on different servers.
     *
     * Canonical identifier for this charge item definition, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * As new versions of a protocol or guideline are defined, allows identification of what versions are replaced by a new instance.
     *
     * Completed or terminated request(s) whose function is taken by this new request
     */
    replaces?: string[];
    /**
     * A formal identifier that is used to identify this charge item definition when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the charge item definition
     */
    identifier?: Identifier[];
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate charge item definition instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * The current state of the ChargeItemDefinition.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * A natural language name identifying the ChargeItemDefinition. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this charge item definition (computer friendly)
     */
    name?: string;
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the charge item definition.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * Expressions that describe applicability criteria for the billing code.
     *
     * Whether or not the billing code is applicable
     */
    applicability?: ChargeItemDefinition.ChargeItemDefinitionApplicabilityComponent[];
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * The date on which the resource content was last reviewed. Review happens periodically after approval but does not change the original approval date.
     *
     * When the charge item definition was last reviewed by the publisher
     */
    lastReviewDate?: Date;
    readonly resourceType: string;
    static revive(json: any): ChargeItemDefinition;
    toJSON(): any;
}
export declare namespace ChargeItemDefinition {
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class ChargeItemDefinitionPropertyGroupComponent extends BackboneElement {
        /**
         * Expressions that describe applicability criteria for the priceComponent.
         *
         * Conditions under which the priceComponent is applicable
         */
        applicability?: ChargeItemDefinition.ChargeItemDefinitionApplicabilityComponent[];
        /**
         * The price for a ChargeItem may be calculated as a base price with surcharges/deductions that apply in certain conditions. A ChargeItemDefinition resource that defines the prices, factors and conditions that apply to a billing code is currently under development. The priceComponent element can be used to offer transparency to the recipient of the Invoice of how the prices have been calculated.
         *
         * Components of total line item price
         */
        priceComponent?: MonetaryComponent[];
        static revive(json: any): ChargeItemDefinitionPropertyGroupComponent;
        toJSON(): any;
    }
    class ChargeItemDefinitionApplicabilityComponent extends BackboneElement {
        /**
         * Reference to / quotation of the external source of the group of properties.
         *
         * Reference to / quotation of the external source of the group of properties
         */
        relatedArtifact?: RelatedArtifact;
        /**
         * An expression that returns true or false, indicating whether the condition is satisfied. When using FHIRPath expressions, the %context environment variable must be replaced at runtime with the ChargeItem resource to which this definition is applied.
         *
         * Boolean-valued expression
         */
        condition?: Expression;
        /**
         * The period during which the charge item definition content was or is planned to be in active use.
         *
         * When the charge item definition is expected to be used
         */
        effectivePeriod?: Period;
        static revive(json: any): ChargeItemDefinitionApplicabilityComponent;
        toJSON(): any;
    }
}
