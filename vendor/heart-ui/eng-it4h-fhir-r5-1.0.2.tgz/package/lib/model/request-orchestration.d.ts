import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Age } from '../datatype/age';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { DataRequirement } from '../datatype/data-requirement';
import { Duration } from '../datatype/duration';
import { Expression } from '../datatype/expression';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Range } from '../datatype/range';
import { RelatedArtifact } from '../datatype/related-artifact';
import { Timing } from '../datatype/timing';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DeviceDefinition } from '../model/device-definition';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Endpoint } from '../model/endpoint';
import { Goal } from '../model/goal';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>RequestOrchestration</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/RequestOrchestration">http://hl7.org/fhir/StructureDefinition/RequestOrchestration</a>
 * </p>
 *
 */
export declare class RequestOrchestration extends DomainResource {
    /**
     * A code that identifies what the overall request orchestration is.
     *
     * What's being requested/ordered
     */
    code?: CodeableConcept;
    /**
     * Indicates when the request orchestration was created.
     *
     * When the request orchestration was authored
     */
    authoredOn?: Date;
    /**
     * Goals that are intended to be achieved by following the requests in this RequestOrchestration.
     *
     * What goals
     */
    goal?: Goal[] | Reference[];
    /**
     * Allows a service to provide a unique, business identifier for the request.
     *
     * Business identifier
     */
    identifier?: Identifier[];
    /**
     * Describes the reason for the request orchestration in coded or textual form.
     *
     * Why the request orchestration is needed
     */
    reason?: CodeableReference[];
    /**
     * Provides a mechanism to communicate additional information about the response.
     *
     * Additional notes about the response
     */
    note?: Annotation[];
    /**
     * Completed or terminated request(s) whose function is taken by this new request.
     *
     * Request(s) replaced by this request
     */
    replaces?: Reference[];
    /**
     * The subject for which the request orchestration was created.
     *
     * Who the request orchestration is about
     */
    subject?: CareTeam | Device | Group | HealthcareService | Location | Organization | Patient | Practitioner | PractitionerRole | RelatedPerson | Reference;
    /**
     * Provides a reference to the author of the request orchestration.
     *
     * Device or practitioner that authored the request orchestration
     */
    author?: Device | Practitioner | PractitionerRole | Reference;
    /**
     * Describes the context of the request orchestration, if any.
     *
     * Created as part of
     */
    encounter?: Encounter | Reference;
    /**
     * A URL referencing an externally defined protocol, guideline, orderset or other definition that is adhered to in whole or in part by this request.
     *
     * Instantiates external protocol or definition
     */
    instantiatesUri?: string[];
    /**
     * A canonical URL referencing a FHIR-defined protocol, guideline, orderset or other definition that is adhered to in whole or in part by this request.
     *
     * Instantiates FHIR protocol or definition
     */
    instantiatesCanonical?: string[];
    /**
     * Indicates how quickly the request should be addressed with respect to other requests.
     *
     * routine | urgent | asap | stat
     */
    priority?: string;
    /**
     * Indicates the level of authority/intentionality associated with the request and where the request fits into the workflow chain.
     *
     * proposal | plan | directive | order | original-order | reflex-order | filler-order | instance-order | option
     */
    intent: string;
    /**
     * The actions, if any, produced by the evaluation of the artifact.
     *
     * Proposed actions, if any
     */
    action?: RequestOrchestration.RequestOrchestrationActionComponent[];
    /**
     * A plan, proposal or order that is fulfilled in whole or in part by this request.
     *
     * Fulfills plan, proposal, or order
     */
    basedOn?: Reference[];
    /**
     * The current state of the request. For request orchestrations, the status reflects the status of all the requests in the orchestration.
     *
     * draft | active | on-hold | revoked | completed | entered-in-error | unknown
     */
    status: string;
    /**
     * A shared identifier common to multiple independent Request instances that were activated/authorized more or less simultaneously by a single author.  The presence of the same identifier on each request ties those requests together and may have business ramifications in terms of reporting of results, billing, etc.  E.g. a requisition number shared by a set of lab tests ordered together, or a prescription number shared by all meds ordered at one time.
     *
     * Composite request this is part of
     */
    groupIdentifier?: Identifier;
    readonly resourceType: string;
    static revive(json: any): RequestOrchestration;
    toJSON(): any;
}
export declare namespace RequestOrchestration {
    enum RequestStatus {
        REVOKED,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ACTIVE,
        DRAFT,
        ONHOLD,
        UNKNOWN
    }
    enum RequestIntent {
        ORDER,
        FILLERORDER,
        ORIGINALORDER,
        NULL,
        REFLEXORDER,
        DIRECTIVE,
        OPTION,
        PROPOSAL,
        PLAN,
        INSTANCEORDER
    }
    enum RequestPriority {
        URGENT,
        STAT,
        NULL,
        ROUTINE,
        ASAP
    }
    class RequestOrchestrationActionDynamicValueComponent extends BackboneElement {
        /**
         * An expression specifying the value of the customized element.
         *
         * An expression that provides the dynamic value for the customization
         */
        expression?: Expression;
        /**
         * The path to the element to be customized. This is the path on the resource that will hold the result of the calculation defined by the expression. The specified path SHALL be a FHIRPath resolvable on the specified target type of the ActivityDefinition, and SHALL consist only of identifiers, constant indexers, and a restricted subset of functions. The path is allowed to contain qualifiers (.) to traverse sub-elements, as well as indexers ([x]) to traverse multiple-cardinality sub-elements (see the [Simple FHIRPath Profile](fhirpath.html#simple) for full details).
         *
         * The path to the element to be set dynamically
         */
        path?: string;
        static revive(json: any): RequestOrchestrationActionDynamicValueComponent;
        toJSON(): any;
    }
    class RequestOrchestrationActionParticipantComponent extends BackboneElement {
        /**
         * A reference to the actual participant.
         *
         * Who/what is participating?
         */
        actor?: string | CareTeam | Device | DeviceDefinition | Endpoint | Group | HealthcareService | Location | Organization | Patient | Practitioner | PractitionerRole | RelatedPerson | Reference;
        /**
         * The role the participant should play in performing the described action.
         *
         * E.g. Nurse, Surgeon, Parent, etc
         */
        role?: CodeableConcept;
        /**
         * The type of participant in the action.
         *
         * Who or what can participate
         */
        typeCanonical?: string;
        /**
         * Indicates how the actor will be involved in the action - author, reviewer, witness, etc.
         *
         * E.g. Author, Reviewer, Witness, etc
         */
        function?: CodeableConcept;
        /**
         * The type of participant in the action.
         *
         * Who or what can participate
         */
        typeReference?: CareTeam | Device | DeviceDefinition | Endpoint | Group | HealthcareService | Location | Organization | Patient | Practitioner | PractitionerRole | RelatedPerson | Reference;
        /**
         * The type of participant in the action.
         *
         * careteam | device | group | healthcareservice | location | organization | patient | practitioner | practitionerrole | relatedperson
         */
        type?: string;
        static revive(json: any): RequestOrchestrationActionParticipantComponent;
        toJSON(): any;
    }
    class RequestOrchestrationActionRelatedActionComponent extends BackboneElement {
        /**
         * The relationship of the end of this action to the related action.
         *
         * before | before-start | before-end | concurrent | concurrent-with-start | concurrent-with-end | after | after-start | after-end
         */
        endRelationship?: string;
        /**
         * The relationship of this action to the related action.
         *
         * before | before-start | before-end | concurrent | concurrent-with-start | concurrent-with-end | after | after-start | after-end
         */
        relationship: string;
        /**
         * The element id of the target related action.
         *
         * What action this is related to
         */
        targetId: string;
        /**
         * A duration or range of durations to apply to the relationship. For example, 30-60 minutes before.
         *
         * Time offset for the relationship
         */
        offset?: Duration | Range;
        static revive(json: any): RequestOrchestrationActionRelatedActionComponent;
        toJSON(): any;
    }
    class RequestOrchestrationActionOutputComponent extends BackboneElement {
        /**
         * Points to an existing input or output element that is results as output from the action.
         *
         * What data is provided
         */
        relatedData?: string;
        /**
         * Defines the data that results as output from the action.
         *
         * What data is provided
         */
        requirement?: DataRequirement;
        /**
         * A human-readable label for the data requirement used to label data flows in BPMN or similar diagrams. Also provides a human readable label when rendering the data requirement that conveys its purpose to human readers.
         *
         * User-visible title
         */
        title?: string;
        static revive(json: any): RequestOrchestrationActionOutputComponent;
        toJSON(): any;
    }
    class RequestOrchestrationActionInputComponent extends BackboneElement {
        /**
         * A human-readable label for the data requirement used to label data flows in BPMN or similar diagrams. Also provides a human readable label when rendering the data requirement that conveys its purpose to human readers.
         *
         * User-visible title
         */
        title?: string;
        /**
         * Defines the data that is to be provided as input to the action.
         *
         * What data is provided
         */
        requirement?: DataRequirement;
        /**
         * Points to an existing input or output element that provides data to this input.
         *
         * What data is provided
         */
        relatedData?: string;
        static revive(json: any): RequestOrchestrationActionInputComponent;
        toJSON(): any;
    }
    class RequestOrchestrationActionConditionComponent extends BackboneElement {
        /**
         * An expression that returns true or false, indicating whether or not the condition is satisfied.
         *
         * Boolean-valued expression
         */
        expression?: Expression;
        /**
         * The kind of condition.
         *
         * applicability | start | stop
         */
        kind: string;
        static revive(json: any): RequestOrchestrationActionConditionComponent;
        toJSON(): any;
    }
    class RequestOrchestrationActionComponent extends BackboneElement {
        /**
         * A short description of the action used to provide a summary to display to the user.
         *
         * Short description of the action
         */
        description?: string;
        /**
         * The participant that should perform or be responsible for this action.
         *
         * Who should perform the action
         */
        participant?: RequestOrchestration.RequestOrchestrationActionParticipantComponent[];
        /**
         * Defines the grouping behavior for the action and its children.
         *
         * visual-group | logical-group | sentence-group
         */
        groupingBehavior?: string;
        /**
         * The title of the action displayed to a user.
         *
         * User-visible title
         */
        title?: string;
        /**
         * The type of action to perform (create, update, remove).
         *
         * create | update | remove | fire-event
         */
        type?: CodeableConcept;
        /**
         * A code that provides meaning for the action or action group. For example, a section may have a LOINC code for a section of a documentation template.
         *
         * Code representing the meaning of the action or sub-actions
         */
        code?: CodeableConcept[];
        /**
         * Defines whether the action can be selected multiple times.
         *
         * single | multiple
         */
        cardinalityBehavior?: string;
        /**
         * A user-visible prefix for the action. For example a section or item numbering such as 1. or A.
         *
         * User-visible prefix for the action (e.g. 1. or A.)
         */
        prefix?: string;
        /**
         * A relationship to another action such as "before" or "30-60 minutes after start of".
         *
         * Relationship to another action
         */
        relatedAction?: RequestOrchestration.RequestOrchestrationActionRelatedActionComponent[];
        /**
         * A reference to an ActivityDefinition that describes the action to be taken in detail, a PlanDefinition that describes a series of actions to be taken, a Questionnaire that should be filled out, a SpecimenDefinition describing a specimen to be collected, or an ObservationDefinition that specifies what observation should be captured.
         *
         * Description of the activity to be performed
         */
        definition?: string;
        /**
         * Sub actions.
         *
         * Sub action
         */
        action?: RequestOrchestration.RequestOrchestrationActionComponent[];
        /**
         * Customizations that should be applied to the statically defined resource. For example, if the dosage of a medication must be computed based on the patient's weight, a customization would be used to specify an expression that calculated the weight, and the path on the resource that would contain the result.
         *
         * Dynamic aspects of the definition
         */
        dynamicValue?: RequestOrchestration.RequestOrchestrationActionDynamicValueComponent[];
        /**
         * A reference to a StructureMap resource that defines a transform that can be executed to produce the intent resource using the ActivityDefinition instance as the input.
         *
         * Transform to apply the template
         */
        transform?: string;
        /**
         * Defines the outputs of the action, if any.
         *
         * Output data definition
         */
        output?: RequestOrchestration.RequestOrchestrationActionOutputComponent[];
        /**
         * Indicates how quickly the action should be addressed with respect to other actions.
         *
         * routine | urgent | asap | stat
         */
        priority?: string;
        /**
         * Goals that are intended to be achieved by following the requests in this action.
         *
         * What goals
         */
        goal?: Goal[] | Reference[];
        /**
         * A text equivalent of the action to be performed. This provides a human-interpretable description of the action when the definition is consumed by a system that might not be capable of interpreting it dynamically.
         *
         * Static text equivalent of the action, used if the dynamic aspects cannot be interpreted by the receiving system
         */
        textEquivalent?: string;
        /**
         * Didactic or other informational resources associated with the action that can be provided to the CDS recipient. Information resources can include inline text commentary and links to web resources.
         *
         * Supporting documentation for the intended performer of the action
         */
        documentation?: RelatedArtifact[];
        /**
         * An optional value describing when the action should be performed.
         *
         * When the action should take place
         */
        timing?: Date | Age | Period | Duration | Range | Timing;
        /**
         * The resource that is the target of the action (e.g. CommunicationRequest).
         *
         * The target of the action
         */
        resource?: Reference;
        /**
         * Identifies the facility where the action will occur; e.g. home, hospital, specific clinic, etc.
         *
         * Where it should happen
         */
        location?: CodeableReference;
        /**
         * The linkId of the action from the PlanDefinition that corresponds to this action in the RequestOrchestration resource.
         *
         * Pointer to specific item from the PlanDefinition
         */
        linkId?: string;
        /**
         * Defines the selection behavior for the action and its children.
         *
         * any | all | all-or-none | exactly-one | at-most-one | one-or-more
         */
        selectionBehavior?: string;
        /**
         * An expression that describes applicability criteria, or start/stop conditions for the action.
         *
         * Whether or not the action is applicable
         */
        condition?: RequestOrchestration.RequestOrchestrationActionConditionComponent[];
        /**
         * Defines input data requirements for the action.
         *
         * Input data requirements
         */
        input?: RequestOrchestration.RequestOrchestrationActionInputComponent[];
        /**
         * Defines expectations around whether an action is required.
         *
         * must | could | must-unless-documented
         */
        requiredBehavior?: string;
        /**
         * Defines whether the action should usually be preselected.
         *
         * yes | no
         */
        precheckBehavior?: string;
        static revive(json: any): RequestOrchestrationActionComponent;
        toJSON(): any;
    }
}
