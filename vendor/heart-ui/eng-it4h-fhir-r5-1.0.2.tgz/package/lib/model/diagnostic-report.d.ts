import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { BiologicallyDerivedProduct } from '../model/biologically-derived-product';
import { CarePlan } from '../model/care-plan';
import { CareTeam } from '../model/care-team';
import { Citation } from '../model/citation';
import { Composition } from '../model/composition';
import { Device } from '../model/device';
import { DocumentReference } from '../model/document-reference';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { GenomicStudy } from '../model/genomic-study';
import { Group } from '../model/group';
import { ImagingStudy } from '../model/imaging-study';
import { ImmunizationRecommendation } from '../model/immunization-recommendation';
import { Location } from '../model/location';
import { Medication } from '../model/medication';
import { MedicationRequest } from '../model/medication-request';
import { NutritionOrder } from '../model/nutrition-order';
import { Observation } from '../model/observation';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Procedure } from '../model/procedure';
import { ServiceRequest } from '../model/service-request';
import { Specimen } from '../model/specimen';
import { Substance } from '../model/substance';
/**
 * HAPI/FHIR <b>DiagnosticReport</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/DiagnosticReport">http://hl7.org/fhir/StructureDefinition/DiagnosticReport</a>
 * </p>
 *
 */
export declare class DiagnosticReport extends DomainResource {
    /**
     * The healthcare event  (e.g. a patient and healthcare provider interaction) which this DiagnosticReport is about.
     *
     * Health care event when test ordered
     */
    encounter?: Encounter | Reference;
    /**
     * A list of key images or data associated with this report. The images or data are generally created during the diagnostic process, and may be directly of the patient, or of treated specimens (i.e. slides of interest).
     *
     * Key images or data associated with this report
     */
    media?: DiagnosticReport.DiagnosticReportMediaComponent[];
    /**
     * Rich text representation of the entire result as issued by the diagnostic service. Multiple formats are allowed but they SHALL be semantically equivalent.
     *
     * Entire report as issued
     */
    presentedForm?: Attachment[];
    /**
     * A code or name that describes this diagnostic report.
     *
     * Name/Code for this diagnostic report
     */
    code: CodeableConcept;
    /**
     * The diagnostic service that is responsible for issuing the report.
     *
     * Responsible Diagnostic Service
     */
    performer?: Practitioner[] | PractitionerRole[] | Organization[] | CareTeam[] | Reference[];
    /**
     * One or more links to full details of any study performed during the diagnostic investigation. An ImagingStudy might comprise a set of radiologic images obtained via a procedure that are analyzed as a group. Typically, this is imaging performed by DICOM enabled modalities, but this is not required. A fully enabled PACS viewer can use this information to provide views of the source images. A GenomicStudy might comprise one or more analyses, each serving a specific purpose. These analyses may vary in method (e.g., karyotyping, CNV, or SNV detection), performer, software, devices used, or regions targeted.
     *
     * Reference to full details of an analysis associated with the diagnostic report
     */
    study?: GenomicStudy[] | ImagingStudy[] | Reference[];
    /**
     * Identifiers assigned to this report by the performer or other systems.
     *
     * Business identifier for report
     */
    identifier?: Identifier[];
    /**
     * Comments about the diagnostic report.
     *
     * Comments about the diagnostic report
     */
    note?: Annotation[];
    /**
     * One or more codes that represent the summary conclusion (interpretation/impression) of the diagnostic report.
     *
     * Codes for the clinical conclusion of test results
     */
    conclusionCode?: CodeableConcept[];
    /**
     * The subject of the report. Usually, but not always, this is a patient. However, diagnostic services also perform analyses on specimens collected from a variety of other sources.
     *
     * The subject of the report - usually, but not always, the patient
     */
    subject?: Patient | Group | Device | Location | Organization | Practitioner | Medication | Substance | BiologicallyDerivedProduct | Reference;
    /**
     * The practitioner or organization that is responsible for the report's conclusions and interpretations.
     *
     * Primary result interpreter
     */
    resultsInterpreter?: Practitioner[] | PractitionerRole[] | Organization[] | CareTeam[] | Reference[];
    /**
     * The status of the diagnostic report.
     *
     * registered | partial | preliminary | modified | final | amended | corrected | appended | cancelled | entered-in-error | unknown
     */
    status: string;
    /**
     * Details concerning a service requested.
     *
     * What was requested
     */
    basedOn?: CarePlan[] | ImmunizationRecommendation[] | MedicationRequest[] | NutritionOrder[] | ServiceRequest[] | Reference[];
    /**
     * A code that classifies the clinical discipline, department or diagnostic service that created the report (e.g. cardiology, biochemistry, hematology, MRI). This is used for searching, sorting and display purposes.
     *
     * Service category
     */
    category?: CodeableConcept[];
    /**
     * The date and time that this version of the report was made available to providers, typically after the report was reviewed and verified.
     *
     * DateTime this version was made
     */
    issued?: Date;
    /**
     * The time or time-period the observed values are related to. When the subject of the report is a patient, this is usually either the time of the procedure or of specimen collection(s), but very often the source of the date/time is not known, only the date/time itself.
     *
     * Clinically relevant time/time-period for report
     */
    effective?: Date | Period;
    /**
     * [Observations](observation.html)  that are part of this diagnostic report.
     *
     * Observations
     */
    result?: Observation[] | Reference[];
    /**
     * Concise and clinically contextualized summary conclusion (interpretation/impression) of the diagnostic report.
     *
     * Clinical conclusion (interpretation) of test results
     */
    conclusion?: string;
    /**
     * Details about the specimens on which this diagnostic report is based.
     *
     * Specimens this report is based on
     */
    specimen?: Specimen[] | Reference[];
    /**
     * Reference to a Composition resource instance that provides structure for organizing the contents of the DiagnosticReport.
     *
     * Reference to a Composition resource for the DiagnosticReport structure
     */
    composition?: Composition | Reference;
    /**
     * This backbone element contains supporting information that was used in the creation of the report not included in the results already included in the report.
     *
     * Additional information supporting the diagnostic report
     */
    supportingInfo?: DiagnosticReport.DiagnosticReportSupportingInfoComponent[];
    readonly resourceType: string;
    static revive(json: any): DiagnosticReport;
    toJSON(): any;
}
export declare namespace DiagnosticReport {
    enum DiagnosticReportStatus {
        CANCELLED,
        ENTEREDINERROR,
        NULL,
        AMENDED,
        REGISTERED,
        CORRECTED,
        PRELIMINARY,
        PARTIAL,
        FINAL,
        APPENDED,
        UNKNOWN,
        MODIFIED
    }
    class DiagnosticReportMediaComponent extends BackboneElement {
        /**
         * Reference to the image or data source.
         *
         * Reference to the image or data source
         */
        link: DocumentReference | Reference;
        /**
         * A comment about the image or data. Typically, this is used to provide an explanation for why the image or data is included, or to draw the viewer's attention to important features.
         *
         * Comment about the image or data (e.g. explanation)
         */
        comment?: string;
        static revive(json: any): DiagnosticReportMediaComponent;
        toJSON(): any;
    }
    class DiagnosticReportSupportingInfoComponent extends BackboneElement {
        /**
         * The reference for the supporting information in the diagnostic report.
         *
         * Supporting information reference
         */
        reference: Procedure | Observation | DiagnosticReport | Citation | Reference;
        /**
         * The code value for the role of the supporting information in the diagnostic report.
         *
         * Supporting information role code
         */
        type: CodeableConcept;
        static revive(json: any): DiagnosticReportSupportingInfoComponent;
        toJSON(): any;
    }
}
