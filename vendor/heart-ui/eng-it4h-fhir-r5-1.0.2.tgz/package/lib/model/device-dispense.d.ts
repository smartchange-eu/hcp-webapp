import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { CarePlan } from '../model/care-plan';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DeviceRequest } from '../model/device-request';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Location } from '../model/location';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Procedure } from '../model/procedure';
import { Provenance } from '../model/provenance';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>DeviceDispense</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/DeviceDispense">http://hl7.org/fhir/StructureDefinition/DeviceDispense</a>
 * </p>
 *
 */
export declare class DeviceDispense extends DomainResource {
    /**
     * Indicates the type of dispensing event that is performed.
     *
     * Trial fill, partial fill, emergency fill, etc
     */
    type?: CodeableConcept;
    /**
     * The encounter that establishes the context for this event.
     *
     * Encounter associated with event
     */
    encounter?: Encounter | Reference;
    /**
     * The time the dispensed product was made available to the patient or their representative.
     *
     * When product was given out
     */
    whenHandedOver?: Date;
    /**
     * Additional information that supports the device being dispensed.
     *
     * Information that supports the dispensing of the device
     */
    supportingInformation?: Reference[];
    /**
     * Identification of the facility/location where the device was /should be shipped to, as part of the dispense process.
     *
     * Where the device was sent or should be sent
     */
    destination?: Location | Reference;
    /**
     * A link to a resource representing the person to whom the device is intended.
     *
     * Who the dispense is for
     */
    subject: Patient | Practitioner | Reference;
    /**
     * The time when the dispensed product was packaged and reviewed.
     *
     * When product was packaged and reviewed
     */
    preparedDate?: Date;
    /**
     * Identifies the person who picked up the device or the person or location where the device was delivered.  This may be a patient or their caregiver, but some cases exist where it can be a healthcare professional or a location.
     *
     * Who collected the device or where the medication was delivered
     */
    receiver?: Patient | Practitioner | RelatedPerson | Location | PractitionerRole | Reference;
    /**
     * Indicates who or what performed the event.
     *
     * Who performed event
     */
    performer?: DeviceDispense.DeviceDispensePerformerComponent[];
    /**
     * The number of devices that have been dispensed.
     *
     * Amount dispensed
     */
    quantity?: Quantity;
    /**
     * Business identifier for this dispensation.
     *
     * Business identifier for this dispensation
     */
    identifier?: Identifier[];
    /**
     * The bigger event that this dispense is a part of.
     *
     * The bigger event that this dispense is a part of
     */
    partOf?: Procedure[] | Reference[];
    /**
     * Extra information about the dispense that could not be conveyed in the other attributes.
     *
     * Information about the dispense
     */
    note?: Annotation[];
    /**
     * A code specifying the state of the set of dispense events.
     *
     * preparation | in-progress | cancelled | on-hold | completed | entered-in-error | stopped | declined | unknown
     */
    status: string;
    /**
     * The order or request that this dispense is fulfilling.
     *
     * The order or request that this dispense is fulfilling
     */
    basedOn?: CarePlan[] | DeviceRequest[] | Reference[];
    /**
     * Identifies the device being dispensed. This is either a link to a resource representing the details of the device or a simple attribute carrying a code that identifies the device from a known list of devices.
     *
     * What device was supplied
     */
    device: CodeableReference;
    /**
     * Indicates the type of device dispense.
     *
     * Type of device dispense
     */
    category?: CodeableConcept[];
    /**
     * The principal physical location where the dispense was performed.
     *
     * Where the dispense occurred
     */
    location?: Location | Reference;
    /**
     * The full representation of the instructions.
     *
     * Full representation of the usage instructions
     */
    usageInstruction?: string;
    /**
     * A summary of the events of interest that have occurred, such as when the dispense was verified.
     *
     * A list of relevant lifecycle events
     */
    eventHistory?: Provenance[] | Reference[];
    /**
     * Indicates the reason why a dispense was or was not performed.
     *
     * Why a dispense was or was not performed
     */
    statusReason?: CodeableReference;
    readonly resourceType: string;
    static revive(json: any): DeviceDispense;
    toJSON(): any;
}
export declare namespace DeviceDispense {
    enum DeviceDispenseStatusCodes {
        CANCELLED,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ONHOLD,
        STOPPED,
        INPROGRESS,
        UNKNOWN,
        PREPARATION,
        DECLINED
    }
    class DeviceDispensePerformerComponent extends BackboneElement {
        /**
         * The device, practitioner, etc. who performed the action.  It should be assumed that the actor is the dispenser of the device.
         *
         * Individual who was performing
         */
        actor: Practitioner | PractitionerRole | Organization | Patient | Device | RelatedPerson | CareTeam | Reference;
        /**
         * Distinguishes the type of performer in the dispense.  For example, date enterer, packager, final checker.
         *
         * Who performed the dispense and what they did
         */
        function?: CodeableConcept;
        static revive(json: any): DeviceDispensePerformerComponent;
        toJSON(): any;
    }
}
