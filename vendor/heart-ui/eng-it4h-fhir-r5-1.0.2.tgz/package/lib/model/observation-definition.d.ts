import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Range } from '../datatype/range';
import { UsageContext } from '../datatype/usage-context';
import { Device } from '../model/device';
import { DeviceDefinition } from '../model/device-definition';
import { DomainResource } from '../model/domain-resource';
import { Questionnaire } from '../model/questionnaire';
import { SpecimenDefinition } from '../model/specimen-definition';
/**
 * HAPI/FHIR <b>ObservationDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ObservationDefinition">http://hl7.org/fhir/StructureDefinition/ObservationDefinition</a>
 * </p>
 *
 */
export declare class ObservationDefinition extends DomainResource {
    /**
     * A code that classifies the general type of observation.
     *
     * General type of observation
     */
    category?: CodeableConcept[];
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate ObservationDefinition instances.
     *
     * Content intends to support these contexts
     */
    useContext?: UsageContext[];
    /**
     * The measurement model of device or actual device used to produce observations of this type.
     *
     * Measurement device or model of device
     */
    device?: DeviceDefinition[] | Device[] | Reference[];
    /**
     * The current state of the ObservationDefinition.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The canonical URL pointing to another FHIR-defined ObservationDefinition that is adhered to in whole or in part by this definition.
     *
     * Based on FHIR definition of another observation
     */
    derivedFromCanonical?: string[];
    /**
     * A natural language name identifying the ObservationDefinition. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this ObservationDefinition (computer friendly)
     */
    name?: string;
    /**
     * Helps establish the "authority/credibility" of the ObservationDefinition. May also allow for contact.
     *
     * The name of the individual or organization that published the ObservationDefinition
     */
    publisher?: string;
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * The date on which the asset content was last reviewed. Review happens periodically after that, but doesn't change the original approval date.
     *
     * Date on which the asset content was last reviewed by the publisher
     */
    lastReviewDate?: Date;
    /**
     * The site on the subject's body where the  observation is to be made.
     *
     * Body part to be observed
     */
    bodySite?: CodeableConcept;
    /**
     * Some observations have multiple component observations, expressed as separate code value pairs.
     *
     * Component results
     */
    component?: ObservationDefinition.ObservationDefinitionComponentComponent[];
    /**
     * The identifier that is used to identify this version of the ObservationDefinition when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the ObservationDefinition author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions are orderable.
     *
     * Business version of the ObservationDefinition
     */
    version?: string;
    /**
     * The type of individual/organization/device that is expected to act upon instances of this definition.
     *
     * Desired kind of performer for such kind of observation
     */
    performerType?: CodeableConcept;
    /**
     * The data types allowed for the value element of the instance observations conforming to this ObservationDefinition.
     *
     * Quantity | CodeableConcept | string | boolean | integer | Range | Ratio | SampledData | time | dateTime | Period
     */
    permittedDataType?: string[];
    /**
     * Multiple results allowed for observations conforming to this ObservationDefinition.
     *
     * Multiple results allowed for conforming observations
     */
    multipleResultsAllowed?: boolean;
    /**
     * An absolute URL that is used to identify this ObservationDefinition when it is referenced in a specification, model, design or an instance. This SHALL be a URL, SHOULD be globally unique, and SHOULD be an address at which this ObservationDefinition is (or will be) published. The URL SHOULD include the major version of the ObservationDefinition. For more information see Technical and Business Versions.
     *
     * Logical canonical URL to reference this ObservationDefinition (globally unique)
     */
    url?: string;
    /**
     * The preferred name to be used when reporting the results of observations conforming to this ObservationDefinition.
     *
     * The preferred name to be used when reporting the observation results
     */
    preferredReportName?: string;
    /**
     * The period during which the ObservationDefinition content was or is planned to be effective.
     *
     * The effective date range for the ObservationDefinition
     */
    effectivePeriod?: Period;
    /**
     * The method or technique used to perform the observation.
     *
     * Method used to produce the observation
     */
    method?: CodeableConcept;
    /**
     * This ObservationDefinition defines a group  observation (e.g. a battery, a panel of tests, a set of vital sign measurements) that includes the target as a member of the group.
     *
     * Definitions of related resources belonging to this kind of observation group
     */
    hasMember?: ObservationDefinition[] | Questionnaire[] | Reference[];
    /**
     * Business identifiers assigned to this ObservationDefinition. by the performer and/or other systems. These identifiers remain constant as the resource is updated and propagates from server to server.
     *
     * Business identifier of the ObservationDefinition
     */
    identifier?: Identifier;
    /**
     * The URL pointing to an externally-defined observation definition, guideline or other definition that is adhered to in whole or in part by this definition.
     *
     * Based on external definition
     */
    derivedFromUri?: string[];
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * The kind of specimen that this type of observation is produced on.
     *
     * Kind of specimen used by this type of observation
     */
    specimen?: SpecimenDefinition[] | Reference[];
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * A short, descriptive, user-friendly title for the ObservationDefinition.
     *
     * Name for this ObservationDefinition (human friendly)
     */
    title?: string;
    /**
     * A free text natural language description of the ObservationDefinition from the consumer's perspective.
     *
     * Natural language description of the ObservationDefinition
     */
    description?: string;
    /**
     * Units allowed for the valueQuantity element in the instance observations conforming to this ObservationDefinition.
     *
     * Unit for quantitative results
     */
    permittedUnit?: Coding[];
    /**
     * A flag to indicate that this ObservationDefinition is authored for testing purposes (or education/evaluation/marketing), and is not intended to be used for genuine usage.
     *
     * If for testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * Explains why this ObservationDefinition is needed and why it has been designed as it has.
     *
     * Why this ObservationDefinition is defined
     */
    purpose?: string;
    /**
     * A code that describes the intended kind of subject of Observation instances conforming to this ObservationDefinition.
     *
     * Type of subject for the defined observation
     */
    subject?: CodeableConcept[];
    /**
     * A jurisdiction in which the ObservationDefinition is intended to be used.
     *
     * Intended jurisdiction for this ObservationDefinition (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * The date (and optionally time) when the ObservationDefinition was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the ObservationDefinition changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * A set of qualified values associated with a context and a set of conditions -  provides a range for quantitative and ordinal observations and a collection of value sets for qualitative observations.
     *
     * Set of qualified values for observation results
     */
    qualifiedValue?: ObservationDefinition.ObservationDefinitionQualifiedValueComponent[];
    /**
     * Copyright statement relating to the ObservationDefinition and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the ObservationDefinition.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * The date on which the asset content was approved by the publisher. Approval happens once when the content is officially approved for usage.
     *
     * When ObservationDefinition was approved by publisher
     */
    approvalDate?: Date;
    /**
     * Describes what will be observed. Sometimes this is called the observation "name".
     *
     * Type of observation
     */
    code: CodeableConcept;
    readonly resourceType: string;
    static revive(json: any): ObservationDefinition;
    toJSON(): any;
}
export declare namespace ObservationDefinition {
    enum ObservationRangeCategory {
        ABSOLUTE,
        NULL,
        REFERENCE,
        CRITICAL
    }
    enum ObservationDataType {
        SAMPLEDDATA,
        NULL,
        DATETIME,
        QUANTITY,
        PERIOD,
        STRING,
        RATIO,
        TIME,
        CODEABLECONCEPT,
        BOOLEAN,
        INTEGER,
        RANGE
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class ObservationDefinitionComponentComponent extends BackboneElement {
        /**
         * A set of qualified values associated with a context and a set of conditions -  provides a range for quantitative and ordinal observations and a collection of value sets for qualitative observations.
         *
         * Set of qualified values for observation results
         */
        qualifiedValue?: ObservationDefinition.ObservationDefinitionQualifiedValueComponent[];
        /**
         * Describes what will be observed.
         *
         * Type of observation
         */
        code: CodeableConcept;
        /**
         * The data types allowed for the value element of the instance of this component observations.
         *
         * Quantity | CodeableConcept | string | boolean | integer | Range | Ratio | SampledData | time | dateTime | Period
         */
        permittedDataType?: string[];
        /**
         * Units allowed for the valueQuantity element in the instance observations conforming to this ObservationDefinition.
         *
         * Unit for quantitative results
         */
        permittedUnit?: Coding[];
        static revive(json: any): ObservationDefinitionComponentComponent;
        toJSON(): any;
    }
    class ObservationDefinitionQualifiedValueComponent extends BackboneElement {
        /**
         * The set of normal coded results for qualitative observations  that match the criteria of this set of qualified values.
         *
         * Value set of normal coded values as part of this set of qualified values
         */
        normalCodedValueSet?: string;
        /**
         * The gender this  set of qualified values applies to.
         *
         * male | female | other | unknown
         */
        gender?: string;
        /**
         * The set of valid coded results for qualitative observations  that match the criteria of this set of qualified values.
         *
         * Value set of valid coded values as part of this set of qualified values
         */
        validCodedValueSet?: string;
        /**
         * Text based condition for which the the set of qualified values is valid.
         *
         * Condition associated with the set of qualified values
         */
        condition?: string;
        /**
         * The gestational age this  set of qualified values applies to.
         *
         * Applicable gestational age range for the set of qualified values
         */
        gestationalAge?: Range;
        /**
         * The age range this  set of qualified values applies to.
         *
         * Applicable age range for the set of qualified values
         */
        age?: Range;
        /**
         * The set of critical coded results for qualitative observations  that match the criteria of this set of qualified values.
         *
         * Value set of critical coded values as part of this set of qualified values
         */
        criticalCodedValueSet?: string;
        /**
         * The category of range of values for continuous or ordinal observations that match the criteria of this set of qualified values.
         *
         * reference | critical | absolute
         */
        rangeCategory?: string;
        /**
         * The set of abnormal coded results for qualitative observations  that match the criteria of this set of qualified values.
         *
         * Value set of abnormal coded values as part of this set of qualified values
         */
        abnormalCodedValueSet?: string;
        /**
         * The target population this  set of qualified values applies to.
         *
         * Targetted population for the set of qualified values
         */
        appliesTo?: CodeableConcept[];
        /**
         * The range of values defined for continuous or ordinal observations that match the criteria of this set of qualified values.
         *
         * The range for continuous or ordinal observations
         */
        range?: Range;
        /**
         * A concept defining the context for this set of qualified values.
         *
         * Context qualifier for the set of qualified values
         */
        context?: CodeableConcept;
        static revive(json: any): ObservationDefinitionQualifiedValueComponent;
        toJSON(): any;
    }
}
