import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { UsageContext } from '../datatype/usage-context';
import { CanonicalResource } from '../model/canonical-resource';
/**
 * HAPI/FHIR <b>GraphDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/GraphDefinition">http://hl7.org/fhir/StructureDefinition/GraphDefinition</a>
 * </p>
 *
 */
export declare class GraphDefinition extends CanonicalResource {
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * Potential target for the link.
     *
     * Potential target for the link
     */
    node?: GraphDefinition.GraphDefinitionNodeComponent[];
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate graph definition instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * The status of this graph definition. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the graph definition.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * A natural language name identifying the graph definition. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this graph definition (computer friendly)
     */
    name: string;
    /**
     * Explanation of why this graph definition is needed and why it has been designed as it has.
     *
     * Why this graph definition is defined
     */
    purpose?: string;
    /**
     * A legal or geographic region in which the graph definition is intended to be used.
     *
     * Intended jurisdiction for graph definition (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * A formal identifier that is used to identify this GraphDefinition when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the GraphDefinition (business identifier)
     */
    identifier?: Identifier[];
    /**
     * The date  (and optionally time) when the graph definition was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the graph definition changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * A copyright statement relating to the graph definition and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the graph definition.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * The identifier that is used to identify this version of the graph definition when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the graph definition author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the graph definition
     */
    version?: string;
    /**
     * A short, descriptive, user-friendly title for the capability statement.
     *
     * Name for this graph definition (human friendly)
     */
    title?: string;
    /**
     * An absolute URI that is used to identify this graph definition when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this graph definition is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the graph definition is stored on different servers.
     *
     * Canonical identifier for this graph definition, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * A free text natural language description of the graph definition from a consumer's perspective.
     *
     * Natural language description of the graph definition
     */
    description?: string;
    /**
     * The Node at which instances of this graph start. If there is no nominated start, the graph can start at any of the nodes.
     *
     * Starting Node
     */
    start?: string;
    /**
     * Links this graph makes rules about.
     *
     * Links this graph makes rules about
     */
    link?: GraphDefinition.GraphDefinitionLinkComponent[];
    /**
     * A Boolean value to indicate that this graph definition is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    readonly resourceType: string;
    static revive(json: any): GraphDefinition;
    toJSON(): any;
}
export declare namespace GraphDefinition {
    enum GraphCompartmentUse {
        NULL,
        REQUIRES,
        WHERE
    }
    enum GraphCompartmentRule {
        NULL,
        DIFFERENT,
        MATCHING,
        IDENTICAL,
        CUSTOM
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class GraphDefinitionLinkCompartmentComponent extends BackboneElement {
        /**
         * identical | matching | different | no-rule | custom.
         *
         * identical | matching | different | custom
         */
        rule: string;
        /**
         * Documentation for FHIRPath expression.
         *
         * Documentation for FHIRPath expression
         */
        description?: string;
        /**
         * Identifies the compartment.
         *
         * Patient | Encounter | RelatedPerson | Practitioner | Device | EpisodeOfCare
         */
        code: string;
        /**
         * Custom rule, as a FHIRPath expression.
         *
         * Custom rule, as a FHIRPath expression
         */
        expression?: string;
        /**
         * Defines how the compartment rule is used - whether it it is used to test whether resources are subject to the rule, or whether it is a rule that must be followed.
         *
         * where | requires
         */
        use: string;
        static revive(json: any): GraphDefinitionLinkCompartmentComponent;
        toJSON(): any;
    }
    class GraphDefinitionLinkComponent extends BackboneElement {
        /**
         * Information about why this link is of interest in this graph definition.
         *
         * Why this link is specified
         */
        description?: string;
        /**
         * Compartment Consistency Rules.
         *
         * Compartment Consistency Rules
         */
        compartment?: GraphDefinition.GraphDefinitionLinkCompartmentComponent[];
        /**
         * A set of parameters to look up.
         *
         * Criteria for reverse lookup
         */
        params?: string;
        /**
         * Minimum occurrences for this link.
         *
         * Minimum occurrences for this link
         */
        min?: number;
        /**
         * Which slice (if profiled).
         *
         * Which slice (if profiled)
         */
        sliceName?: string;
        /**
         * A FHIRPath expression that identifies one of FHIR References to other resources.
         *
         * Path in the resource that contains the link
         */
        path?: string;
        /**
         * The source node for this link.
         *
         * Source Node for this link
         */
        sourceId: string;
        /**
         * Maximum occurrences for this link.
         *
         * Maximum occurrences for this link
         */
        max?: string;
        /**
         * The target node for this link.
         *
         * Target Node for this link
         */
        targetId: string;
        static revive(json: any): GraphDefinitionLinkComponent;
        toJSON(): any;
    }
    class GraphDefinitionNodeComponent extends BackboneElement {
        /**
         * Information about why this node is of interest in this graph definition.
         *
         * Why this node is specified
         */
        description?: string;
        /**
         * Type of resource this link refers to.
         *
         * Type of resource this link refers to
         */
        type: string;
        /**
         * Internal ID of node - target for link references.
         *
         * Internal ID - target for link references
         */
        nodeId: string;
        /**
         * Profile for the target resource.
         *
         * Profile for the target resource
         */
        profile?: string;
        static revive(json: any): GraphDefinitionNodeComponent;
        toJSON(): any;
    }
}
