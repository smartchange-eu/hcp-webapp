import { BackboneElement } from '../datatype/backbone-element';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { DomainResource } from '../model/domain-resource';
/**
 * HAPI/FHIR <b>SubstanceNucleicAcid</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/SubstanceNucleicAcid">http://hl7.org/fhir/StructureDefinition/SubstanceNucleicAcid</a>
 * </p>
 *
 */
export declare class SubstanceNucleicAcid extends DomainResource {
    /**
     * The number of linear sequences of nucleotides linked through phosphodiester bonds shall be described. Subunits would be strands of nucleic acids that are tightly associated typically through Watson-Crick base pairing. NOTE: If not specified in the reference source, the assumption is that there is 1 subunit.
     *
     * The number of linear sequences of nucleotides linked through phosphodiester bonds shall be described. Subunits would be strands of nucleic acids that are tightly associated typically through Watson-Crick base pairing. NOTE: If not specified in the reference source, the assumption is that there is 1 subunit
     */
    numberOfSubunits?: number;
    /**
     * The type of the sequence shall be specified based on a controlled vocabulary.
     *
     * The type of the sequence shall be specified based on a controlled vocabulary
     */
    sequenceType?: CodeableConcept;
    /**
     * The area of hybridisation shall be described if applicable for double stranded RNA or DNA. The number associated with the subunit followed by the number associated to the residue shall be specified in increasing order. The underscore “” shall be used as separator as follows: “Subunitnumber Residue”.
     *
     * The area of hybridisation shall be described if applicable for double stranded RNA or DNA. The number associated with the subunit followed by the number associated to the residue shall be specified in increasing order. The underscore “” shall be used as separator as follows: “Subunitnumber Residue”
     */
    areaOfHybridisation?: string;
    /**
     * (TBC).
     *
     * (TBC)
     */
    oligoNucleotideType?: CodeableConcept;
    /**
     * Subunits are listed in order of decreasing length; sequences of the same length will be ordered by molecular weight; subunits that have identical sequences will be repeated multiple times.
     *
     * Subunits are listed in order of decreasing length; sequences of the same length will be ordered by molecular weight; subunits that have identical sequences will be repeated multiple times
     */
    subunit?: SubstanceNucleicAcid.SubstanceNucleicAcidSubunitComponent[];
    readonly resourceType: string;
    static revive(json: any): SubstanceNucleicAcid;
    toJSON(): any;
}
export declare namespace SubstanceNucleicAcid {
    class SubstanceNucleicAcidSubunitSugarComponent extends BackboneElement {
        /**
         * The name of the sugar or sugar-like component that make up the nucleotide.
         *
         * The name of the sugar or sugar-like component that make up the nucleotide
         */
        name?: string;
        /**
         * The residues that contain a given sugar will be captured. The order of given residues will be captured in the 5‘-3‘direction consistent with the base sequences listed above.
         *
         * The residues that contain a given sugar will be captured. The order of given residues will be captured in the 5‘-3‘direction consistent with the base sequences listed above
         */
        residueSite?: string;
        /**
         * The Substance ID of the sugar or sugar-like component that make up the nucleotide.
         *
         * The Substance ID of the sugar or sugar-like component that make up the nucleotide
         */
        identifier?: Identifier;
        static revive(json: any): SubstanceNucleicAcidSubunitSugarComponent;
        toJSON(): any;
    }
    class SubstanceNucleicAcidSubunitLinkageComponent extends BackboneElement {
        /**
         * Each linkage will be registered as a fragment and have at least one name. A single name shall be assigned to each linkage.
         *
         * Each linkage will be registered as a fragment and have at least one name. A single name shall be assigned to each linkage
         */
        name?: string;
        /**
         * Each linkage will be registered as a fragment and have an ID.
         *
         * Each linkage will be registered as a fragment and have an ID
         */
        identifier?: Identifier;
        /**
         * The entity that links the sugar residues together should also be captured for nearly all naturally occurring nucleic acid the linkage is a phosphate group. For many synthetic oligonucleotides phosphorothioate linkages are often seen. Linkage connectivity is assumed to be 3’-5’. If the linkage is either 3’-3’ or 5’-5’ this should be specified.
         *
         * The entity that links the sugar residues together should also be captured for nearly all naturally occurring nucleic acid the linkage is a phosphate group. For many synthetic oligonucleotides phosphorothioate linkages are often seen. Linkage connectivity is assumed to be 3’-5’. If the linkage is either 3’-3’ or 5’-5’ this should be specified
         */
        connectivity?: string;
        /**
         * Residues shall be captured as described in 5.3.6.8.3.
         *
         * Residues shall be captured as described in 5.3.6.8.3
         */
        residueSite?: string;
        static revive(json: any): SubstanceNucleicAcidSubunitLinkageComponent;
        toJSON(): any;
    }
    class SubstanceNucleicAcidSubunitComponent extends BackboneElement {
        /**
         * Index of linear sequences of nucleic acids in order of decreasing length. Sequences of the same length will be ordered by molecular weight. Subunits that have identical sequences will be repeated and have sequential subscripts.
         *
         * Index of linear sequences of nucleic acids in order of decreasing length. Sequences of the same length will be ordered by molecular weight. Subunits that have identical sequences will be repeated and have sequential subscripts
         */
        subunit?: number;
        /**
         * The linkages between sugar residues will also be captured.
         *
         * The linkages between sugar residues will also be captured
         */
        linkage?: SubstanceNucleicAcid.SubstanceNucleicAcidSubunitLinkageComponent[];
        /**
         * The length of the sequence shall be captured.
         *
         * The length of the sequence shall be captured
         */
        length?: number;
        /**
         * The nucleotide present at the 5’ terminal shall be specified based on a controlled vocabulary. Since the sequence is represented from the 5' to the 3' end, the 5’ prime nucleotide is the letter at the first position in the sequence. A separate representation would be redundant.
         *
         * The nucleotide present at the 5’ terminal shall be specified based on a controlled vocabulary. Since the sequence is represented from the 5' to the 3' end, the 5’ prime nucleotide is the letter at the first position in the sequence. A separate representation would be redundant
         */
        fivePrime?: CodeableConcept;
        /**
         * (TBC).
         *
         * (TBC)
         */
        sequenceAttachment?: Attachment;
        /**
         * 5.3.6.8.1 Sugar ID (Mandatory).
         *
         * 5.3.6.8.1 Sugar ID (Mandatory)
         */
        sugar?: SubstanceNucleicAcid.SubstanceNucleicAcidSubunitSugarComponent[];
        /**
         * Actual nucleotide sequence notation from 5' to 3' end using standard single letter codes. In addition to the base sequence, sugar and type of phosphate or non-phosphate linkage should also be captured.
         *
         * Actual nucleotide sequence notation from 5' to 3' end using standard single letter codes. In addition to the base sequence, sugar and type of phosphate or non-phosphate linkage should also be captured
         */
        sequence?: string;
        /**
         * The nucleotide present at the 3’ terminal shall be specified based on a controlled vocabulary. Since the sequence is represented from the 5' to the 3' end, the 5’ prime nucleotide is the letter at the last position in the sequence. A separate representation would be redundant.
         *
         * The nucleotide present at the 3’ terminal shall be specified based on a controlled vocabulary. Since the sequence is represented from the 5' to the 3' end, the 5’ prime nucleotide is the letter at the last position in the sequence. A separate representation would be redundant
         */
        threePrime?: CodeableConcept;
        static revive(json: any): SubstanceNucleicAcidSubunitComponent;
        toJSON(): any;
    }
}
