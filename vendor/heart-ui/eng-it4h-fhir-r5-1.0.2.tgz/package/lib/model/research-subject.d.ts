import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { BiologicallyDerivedProduct } from '../model/biologically-derived-product';
import { Consent } from '../model/consent';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Group } from '../model/group';
import { Medication } from '../model/medication';
import { Patient } from '../model/patient';
import { ResearchStudy } from '../model/research-study';
import { Specimen } from '../model/specimen';
import { Substance } from '../model/substance';
/**
 * HAPI/FHIR <b>ResearchSubject</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ResearchSubject">http://hl7.org/fhir/StructureDefinition/ResearchSubject</a>
 * </p>
 *
 */
export declare class ResearchSubject extends DomainResource {
    /**
     * The current state (status) of the subject and resons for status change where appropriate.
     *
     * Subject status
     */
    progress?: ResearchSubject.ResearchSubjectProgressComponent[];
    /**
     * The publication state of the resource (not of the subject).
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The name of the arm in the study the subject actually followed as part of this study.
     *
     * What path was followed
     */
    actualComparisonGroup?: string;
    /**
     * A record of the patient's informed agreement to participate in the study.
     *
     * Agreement to participate in study
     */
    consent?: Consent[] | Reference[];
    /**
     * The name of the arm in the study the subject is expected to follow as part of this study.
     *
     * What path should be followed
     */
    assignedComparisonGroup?: string;
    /**
     * The dates the subject began and ended their participation in the study.
     *
     * Start and end of participation
     */
    period?: Period;
    /**
     * Reference to the study the subject is participating in.
     *
     * Study subject is part of
     */
    study: ResearchStudy | Reference;
    /**
     * Identifiers assigned to this research subject for a study.
     *
     * Business Identifier for research subject in a study
     */
    identifier?: Identifier[];
    /**
     * The record of the person, animal or other entity involved in the study.
     *
     * Who or what is part of study
     */
    subject: Patient | Group | Specimen | Device | Medication | Substance | BiologicallyDerivedProduct | Reference;
    readonly resourceType: string;
    static revive(json: any): ResearchSubject;
    toJSON(): any;
}
export declare namespace ResearchSubject {
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class ResearchSubjectProgressComponent extends BackboneElement {
        /**
         * The reason for the state change.  If coded it should follow the formal subject state model.
         *
         * State change reason
         */
        reason?: CodeableConcept;
        /**
         * The milestones the subject has passed through.
         *
         * SignedUp | Screened | Randomized
         */
        milestone?: CodeableConcept;
        /**
         * The date when the state ended.
         *
         * State change date
         */
        endDate?: Date;
        /**
         * The current state of the subject.
         *
         * candidate | eligible | follow-up | ineligible | not-registered | off-study | on-study | on-study-intervention | on-study-observation | pending-on-study | potential-candidate | screening | withdrawn
         */
        subjectState?: CodeableConcept;
        /**
         * The date when the new status started.
         *
         * State change date
         */
        startDate?: Date;
        /**
         * Identifies the aspect of the subject's journey that the state refers to.
         *
         * state | milestone
         */
        type?: CodeableConcept;
        static revive(json: any): ResearchSubjectProgressComponent;
        toJSON(): any;
    }
}
