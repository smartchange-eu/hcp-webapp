import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Coding } from '../datatype/coding';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Appointment } from '../model/appointment';
import { AppointmentResponse } from '../model/appointment-response';
import { CarePlan } from '../model/care-plan';
import { CareTeam } from '../model/care-team';
import { Claim } from '../model/claim';
import { CommunicationRequest } from '../model/communication-request';
import { Contract } from '../model/contract';
import { CoverageEligibilityRequest } from '../model/coverage-eligibility-request';
import { Device } from '../model/device';
import { DeviceRequest } from '../model/device-request';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { EnrollmentRequest } from '../model/enrollment-request';
import { EpisodeOfCare } from '../model/episode-of-care';
import { ImmunizationRecommendation } from '../model/immunization-recommendation';
import { MedicationRequest } from '../model/medication-request';
import { NutritionOrder } from '../model/nutrition-order';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
import { RequestOrchestration } from '../model/request-orchestration';
import { ServiceRequest } from '../model/service-request';
import { SupplyRequest } from '../model/supply-request';
import { VisionPrescription } from '../model/vision-prescription';
/**
 * HAPI/FHIR <b>DocumentReference</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/DocumentReference">http://hl7.org/fhir/StructureDefinition/DocumentReference</a>
 * </p>
 *
 */
export declare class DocumentReference extends DomainResource {
    /**
     * This property may convey specifics about the practice setting where the content was created, often reflecting the clinical specialty.
     *
     * Additional details about where the content was created (e.g. clinical specialty)
     */
    practiceSetting?: CodeableConcept;
    /**
     * The anatomic structures included in the document.
     *
     * Body part included
     */
    bodySite?: CodeableReference[];
    /**
     * The status of the underlying document.
     *
     * registered | partial | preliminary | final | amended | corrected | appended | cancelled | entered-in-error | deprecated | unknown
     */
    docStatus?: string;
    /**
     * A categorization for the type of document referenced - helps for indexing and searching. This may be implied by or derived from the code specified in the DocumentReference.type.
     *
     * Categorization of document
     */
    category?: CodeableConcept[];
    /**
     * This list of codes represents the main clinical acts, such as a colonoscopy or an appendectomy, being documented. In some cases, the event is inherent in the type Code, such as a "History and Physical Report" in which the procedure being documented is necessarily a "History and Physical" act.
     *
     * Main clinical acts documented
     */
    event?: CodeableReference[];
    /**
     * Relationships that this document has with other document references that already exist.
     *
     * Relationships to other documents
     */
    relatesTo?: DocumentReference.DocumentReferenceRelatesToComponent[];
    /**
     * A procedure that is fulfilled in whole or in part by the creation of this media.
     *
     * Procedure that caused this media to be created
     */
    basedOn?: Appointment[] | AppointmentResponse[] | CarePlan[] | Claim[] | CommunicationRequest[] | Contract[] | CoverageEligibilityRequest[] | DeviceRequest[] | EnrollmentRequest[] | ImmunizationRecommendation[] | MedicationRequest[] | NutritionOrder[] | RequestOrchestration[] | ServiceRequest[] | SupplyRequest[] | VisionPrescription[] | Reference[];
    /**
     * The status of this document reference.
     *
     * current | superseded | entered-in-error
     */
    status: string;
    /**
     * Describes the clinical encounter or type of care that the document content is associated with.
     *
     * Context of the document content
     */
    context?: Appointment[] | Encounter[] | EpisodeOfCare[] | Reference[];
    /**
     * Identifies the organization or group who is responsible for ongoing maintenance of and access to the document.
     *
     * Organization which maintains the document
     */
    custodian?: Organization | Reference;
    /**
     * The kind of facility where the patient was seen.
     *
     * Kind of facility where patient was seen
     */
    facilityType?: CodeableConcept;
    /**
     * Who or what the document is about. The document can be about a person, (patient or healthcare practitioner), a device (e.g. a machine) or even a group of subjects (such as a document about a herd of farm animals, or a set of patients that share a common exposure).
     *
     * Who/what is the subject of the document
     */
    subject?: Reference;
    /**
     * Identifies who is responsible for adding the information to the document.
     *
     * Who and/or what authored the document
     */
    author?: Practitioner[] | PractitionerRole[] | Organization[] | Device[] | Patient[] | RelatedPerson[] | CareTeam[] | Reference[];
    /**
     * A set of Security-Tag codes specifying the level of privacy/security of the Document found at DocumentReference.content.attachment.url. Note that DocumentReference.meta.security contains the security labels of the data elements in DocumentReference, while DocumentReference.securityLabel contains the security labels for the document the reference refers to. The distinction recognizes that the document may contain sensitive information, while the DocumentReference is metadata about the document and thus might not be as sensitive as the document. For example: a psychotherapy episode may contain highly sensitive information, while the metadata may simply indicate that some episode happened.
     *
     * Document security-tags
     */
    securityLabel?: CodeableConcept[];
    /**
     * When the document reference was created.
     *
     * When this document reference was created
     */
    date?: Date;
    /**
     * Other business identifiers associated with the document, including version independent identifiers.
     *
     * Business identifiers for the document
     */
    identifier?: Identifier[];
    /**
     * The time period over which the service that is described by the document was provided.
     *
     * Time of service that is being documented
     */
    period?: Period;
    /**
     * Imaging modality used. This may include both acquisition and non-acquisition modalities.
     *
     * Imaging modality used
     */
    modality?: CodeableConcept[];
    /**
     * Specifies the particular kind of document referenced  (e.g. History and Physical, Discharge Summary, Progress Note). This usually equates to the purpose of making the document referenced.
     *
     * Kind of document (LOINC if possible)
     */
    type?: CodeableConcept;
    /**
     * An explicitly assigned identifer of a variation of the content in the DocumentReference.
     *
     * An explicitly assigned identifer of a variation of the content in the DocumentReference
     */
    version?: string;
    /**
     * A participant who has authenticated the accuracy of the document.
     *
     * Attests to accuracy of the document
     */
    attester?: DocumentReference.DocumentReferenceAttesterComponent[];
    /**
     * The document and format referenced.  If there are multiple content element repetitions, these must all represent the same document in different format, or attachment metadata.
     *
     * Document referenced
     */
    content: DocumentReference.DocumentReferenceContentComponent[];
    /**
     * Human-readable description of the source document.
     *
     * Human-readable description
     */
    description?: string;
    readonly resourceType: string;
    static revive(json: any): DocumentReference;
    toJSON(): any;
}
export declare namespace DocumentReference {
    enum DocumentReferenceStatus {
        ENTEREDINERROR,
        NULL,
        SUPERSEDED,
        CURRENT
    }
    enum CompositionStatus {
        CANCELLED,
        ENTEREDINERROR,
        NULL,
        AMENDED,
        REGISTERED,
        CORRECTED,
        PRELIMINARY,
        PARTIAL,
        FINAL,
        APPENDED,
        UNKNOWN,
        DEPRECATED
    }
    class DocumentReferenceContentProfileComponent extends BackboneElement {
        /**
         * Code|uri|canonical.
         *
         * Code|uri|canonical
         */
        value: Coding | string;
        static revive(json: any): DocumentReferenceContentProfileComponent;
        toJSON(): any;
    }
    class DocumentReferenceContentComponent extends BackboneElement {
        /**
         * An identifier of the document constraints, encoding, structure, and template that the document conforms to beyond the base format indicated in the mimeType.
         *
         * Content profile rules for the document
         */
        profile?: DocumentReference.DocumentReferenceContentProfileComponent[];
        /**
         * The document or URL of the document along with critical metadata to prove content has integrity.
         *
         * Where to access the document
         */
        attachment: Attachment;
        static revive(json: any): DocumentReferenceContentComponent;
        toJSON(): any;
    }
    class DocumentReferenceRelatesToComponent extends BackboneElement {
        /**
         * The target document of this relationship.
         *
         * Target of the relationship
         */
        target: DocumentReference | Reference;
        /**
         * The type of relationship that this document has with anther document.
         *
         * The relationship type with another document
         */
        code: CodeableConcept;
        static revive(json: any): DocumentReferenceRelatesToComponent;
        toJSON(): any;
    }
    class DocumentReferenceAttesterComponent extends BackboneElement {
        /**
         * The type of attestation the authenticator offers.
         *
         * personal | professional | legal | official
         */
        mode: CodeableConcept;
        /**
         * Who attested the document in the specified way.
         *
         * Who attested the document
         */
        party?: Patient | RelatedPerson | Practitioner | PractitionerRole | Organization | Reference;
        /**
         * When the document was attested by the party.
         *
         * When the document was attested
         */
        time?: Date;
        static revive(json: any): DocumentReferenceAttesterComponent;
        toJSON(): any;
    }
}
