import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
/**
 * HAPI/FHIR <b>VisionPrescription</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/VisionPrescription">http://hl7.org/fhir/StructureDefinition/VisionPrescription</a>
 * </p>
 *
 */
export declare class VisionPrescription extends DomainResource {
    /**
     * A unique identifier assigned to this vision prescription.
     *
     * Business Identifier for vision prescription
     */
    identifier?: Identifier[];
    /**
     * The healthcare professional responsible for authorizing the prescription.
     *
     * Who authorized the vision prescription
     */
    prescriber: Practitioner | PractitionerRole | Reference;
    /**
     * The date this resource was created.
     *
     * Response creation date
     */
    created: Date;
    /**
     * A resource reference to the person to whom the vision prescription applies.
     *
     * Who prescription is for
     */
    patient: Patient | Reference;
    /**
     * A reference to a resource that identifies the particular occurrence of contact between patient and health care provider during which the prescription was issued.
     *
     * Created during encounter / admission / stay
     */
    encounter?: Encounter | Reference;
    /**
     * Contain the details of  the individual lens specifications and serves as the authorization for the fullfillment by certified professionals.
     *
     * Vision lens authorization
     */
    lensSpecification: VisionPrescription.VisionPrescriptionLensSpecificationComponent[];
    /**
     * The status of the resource instance.
     *
     * active | cancelled | draft | entered-in-error
     */
    status: string;
    /**
     * The date (and perhaps time) when the prescription was written.
     *
     * When prescription was authorized
     */
    dateWritten: Date;
    readonly resourceType: string;
    static revive(json: any): VisionPrescription;
    toJSON(): any;
}
export declare namespace VisionPrescription {
    enum VisionEyes {
        NULL,
        LEFT,
        RIGHT
    }
    enum VisionBase {
        DOWN,
        NULL,
        IN,
        UP,
        OUT
    }
    enum FinancialResourceStatusCodes {
        CANCELLED,
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        DRAFT
    }
    class PrismComponent extends BackboneElement {
        /**
         * Amount of prism to compensate for eye alignment in fractional units.
         *
         * Amount of adjustment
         */
        amount: number;
        /**
         * The relative base, or reference lens edge, for the prism.
         *
         * up | down | in | out
         */
        base: string;
        static revive(json: any): PrismComponent;
        toJSON(): any;
    }
    class VisionPrescriptionLensSpecificationComponent extends BackboneElement {
        /**
         * Special color or pattern.
         *
         * Color required
         */
        color?: string;
        /**
         * Back curvature measured in millimetres.
         *
         * Contact lens back curvature
         */
        backCurve?: number;
        /**
         * Identifies the type of vision correction product which is required for the patient.
         *
         * Product to be supplied
         */
        product: CodeableConcept;
        /**
         * Notes for special requirements such as coatings and lens materials.
         *
         * Notes for coatings
         */
        note?: Annotation[];
        /**
         * Power adjustment for multifocal lenses measured in dioptres (0.25 units).
         *
         * Added power for multifocal levels
         */
        add?: number;
        /**
         * Adjustment for astigmatism measured in integer degrees.
         *
         * Lens meridian which contain no power for astigmatism
         */
        axis?: number;
        /**
         * Lens power measured in dioptres (0.25 units).
         *
         * Power of the lens
         */
        sphere?: number;
        /**
         * Contact lens diameter measured in millimetres.
         *
         * Contact lens diameter
         */
        diameter?: number;
        /**
         * The eye for which the lens specification applies.
         *
         * right | left
         */
        eye: string;
        /**
         * The recommended maximum wear period for the lens.
         *
         * Lens wear duration
         */
        duration?: Quantity;
        /**
         * Allows for adjustment on two axis.
         *
         * Eye alignment compensation
         */
        prism?: VisionPrescription.PrismComponent[];
        /**
         * Brand recommendations or restrictions.
         *
         * Brand required
         */
        brand?: string;
        /**
         * Contact lens power measured in dioptres (0.25 units).
         *
         * Contact lens power
         */
        power?: number;
        /**
         * Power adjustment for astigmatism measured in dioptres (0.25 units).
         *
         * Lens power for astigmatism
         */
        cylinder?: number;
        static revive(json: any): VisionPrescriptionLensSpecificationComponent;
        toJSON(): any;
    }
}
