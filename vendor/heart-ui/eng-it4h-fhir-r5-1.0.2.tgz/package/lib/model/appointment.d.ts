import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Coding } from '../datatype/coding';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { VirtualServiceDetail } from '../datatype/virtual-service-detail';
import { Account } from '../model/account';
import { CarePlan } from '../model/care-plan';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DeviceRequest } from '../model/device-request';
import { DomainResource } from '../model/domain-resource';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { Location } from '../model/location';
import { MedicationRequest } from '../model/medication-request';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
import { ServiceRequest } from '../model/service-request';
import { Slot } from '../model/slot';
/**
 * HAPI/FHIR <b>Appointment</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Appointment">http://hl7.org/fhir/StructureDefinition/Appointment</a>
 * </p>
 *
 */
export declare class Appointment extends DomainResource {
    /**
     * The previous appointment in a series of related appointments.
     *
     * The previous appointment in a series
     */
    previousAppointment?: Appointment | Reference;
    /**
     * This appointment varies from the recurring pattern.
     *
     * Indicates that this appointment varies from a recurrence pattern
     */
    occurrenceChanged?: boolean;
    /**
     * The overall status of the Appointment. Each of the participants has their own participation status which indicates their involvement in the process, however this status indicates the shared status.
     *
     * proposed | pending | booked | arrived | fulfilled | cancelled | noshow | entered-in-error | checked-in | waitlist
     */
    status: string;
    /**
     * While Appointment.note contains information for internal use, Appointment.patientInstructions is used to capture patient facing information about the Appointment (e.g. please bring your referral or fast from 8pm night before).
     *
     * Detailed information and instructions for the patient
     */
    patientInstruction?: CodeableReference[];
    /**
     * The originating appointment in a recurring set of related appointments.
     *
     * The originating appointment in a recurring set of appointments
     */
    originatingAppointment?: Appointment | Reference;
    /**
     * The set of accounts that is expected to be used for billing the activities that result from this Appointment.
     *
     * The set of accounts that may be used for billing for this Appointment
     */
    account?: Account[] | Reference[];
    /**
     * This records identifiers associated with this appointment concern that are defined by business processes and/or used to refer to it when a direct URL reference to the resource itself is not appropriate (e.g. in CDA documents, or in written / printed documentation).
     *
     * External Ids for this item
     */
    identifier?: Identifier[];
    /**
     * The style of appointment or patient that has been booked in the slot (not service type).
     *
     * The style of appointment or patient that has been booked in the slot (not service type)
     */
    appointmentType?: CodeableConcept;
    /**
     * The coded reason for the appointment being cancelled. This is often used in reporting/billing/futher processing to determine if further actions are required, or specific fees apply.
     *
     * The coded reason for the appointment being cancelled
     */
    cancellationReason?: CodeableConcept;
    /**
     * Appointment replaced by this Appointment in cases where there is a cancellation, the details of the cancellation can be found in the cancellationReason property (on the referenced resource).
     *
     * Appointment replaced by this Appointment
     */
    replaces?: Appointment[] | Reference[];
    /**
     * The date that this appointment was initially created. This could be different to the meta.lastModified value on the initial entry, as this could have been before the resource was created on the FHIR server, and should remain unchanged over the lifespan of the appointment.
     *
     * The date that this appointment was initially created
     */
    created?: Date;
    /**
     * Concepts representing classification of patient encounter such as ambulatory (outpatient), inpatient, emergency, home health or others due to local variations.
     *
     * Classification when becoming an encounter
     */
    class?: CodeableConcept[];
    /**
     * Additional information to support the appointment provided when making the appointment.
     *
     * Additional information to support the appointment
     */
    supportingInformation?: Reference[];
    /**
     * Date/Time that the appointment is to take place.
     *
     * When appointment is to take place
     */
    start?: Date;
    /**
     * The priority of the appointment. Can be used to make informed decisions if needing to re-prioritize appointments. (The iCal Standard specifies 0 as undefined, 1 as highest, 9 as lowest priority).
     *
     * Used to make informed decisions if needing to re-prioritize
     */
    priority?: CodeableConcept;
    /**
     * The details of the recurrence pattern or template that is used to generate recurring appointments.
     *
     * Details of the recurrence pattern/template used to generate occurrences
     */
    recurrenceTemplate?: Appointment.AppointmentRecurrenceTemplateComponent[];
    /**
     * Date/Time that the appointment is to conclude.
     *
     * When appointment is to conclude
     */
    end?: Date;
    /**
     * The date/time describing when the appointment was cancelled.
     *
     * When the appointment was cancelled
     */
    cancellationDate?: Date;
    /**
     * The request this appointment is allocated to assess (e.g. incoming referral or procedure request).
     *
     * The request this appointment is allocated to assess
     */
    basedOn?: CarePlan[] | DeviceRequest[] | MedicationRequest[] | ServiceRequest[] | Reference[];
    /**
     * The reason that this appointment is being scheduled. This is more clinical than administrative. This can be coded, or as specified using information from another resource. When the patient arrives and the encounter begins it may be used as the admission diagnosis. The indication will typically be a Condition (with other resources referenced in the evidence.detail), or a Procedure.
     *
     * Reason this appointment is scheduled
     */
    reason?: CodeableReference[];
    /**
     * Additional notes/comments about the appointment.
     *
     * Additional comments
     */
    note?: Annotation[];
    /**
     * The specific service that is to be performed during this appointment.
     *
     * The specific service that is to be performed during this appointment
     */
    serviceType?: CodeableReference[];
    /**
     * The specialty of a practitioner that would be required to perform the service requested in this appointment.
     *
     * The specialty of a practitioner that would be required to perform the service requested in this appointment
     */
    specialty?: CodeableConcept[];
    /**
     * Connection details of a virtual service (e.g. conference call).
     *
     * Connection details of a virtual service (e.g. conference call)
     */
    virtualService?: VirtualServiceDetail[];
    /**
     * The patient or group associated with the appointment, if they are to be present (usually) then they should also be included in the participant backbone element.
     *
     * The patient or group associated with the appointment
     */
    subject?: Patient | Group | Reference;
    /**
     * The brief description of the appointment as would be shown on a subject line in a meeting request, or appointment list. Detailed or expanded information should be put in the note field.
     *
     * Shown on a subject line in a meeting request, or appointment list
     */
    description?: string;
    /**
     * Number of minutes that the appointment is to take. This can be less than the duration between the start and end times.  For example, where the actual time of appointment is only an estimate or if a 30 minute appointment is being requested, but any time would work.  Also, if there is, for example, a planned 15 minute break in the middle of a long appointment, the duration may be 15 minutes less than the difference between the start and end.
     *
     * Can be less than start/end (e.g. estimate)
     */
    minutesDuration?: number;
    /**
     * The slots from the participants' schedules that will be filled by the appointment.
     *
     * The slots that this appointment is filling
     */
    slot?: Slot[] | Reference[];
    /**
     * A set of date ranges (potentially including times) that the appointment is preferred to be scheduled within.

The duration (usually in minutes) could also be provided to indicate the length of the appointment to fill and populate the start/end times for the actual allocated time. However, in other situations the duration may be calculated by the scheduling system.
     *
     * Potential date/time interval(s) requested to allocate the appointment within
     */
    requestedPeriod?: Period[];
    /**
     * The sequence number that identifies a specific appointment in a recurring pattern.
     *
     * The sequence number in the recurrence
     */
    recurrenceId?: number;
    /**
     * A broad categorization of the service that is to be performed during this appointment.
     *
     * A broad categorization of the service that is to be performed during this appointment
     */
    serviceCategory?: CodeableConcept[];
    /**
     * List of participants involved in the appointment.
     *
     * Participants involved in appointment
     */
    participant: Appointment.AppointmentParticipantComponent[];
    readonly resourceType: string;
    static revive(json: any): Appointment;
    toJSON(): any;
}
export declare namespace Appointment {
    enum ParticipationStatus {
        NEEDSACTION,
        ACCEPTED,
        TENTATIVE,
        NULL,
        DECLINED
    }
    enum AppointmentStatus {
        FULFILLED,
        CANCELLED,
        ENTEREDINERROR,
        WAITLIST,
        NULL,
        NOSHOW,
        ARRIVED,
        BOOKED,
        PENDING,
        CHECKEDIN,
        PROPOSED
    }
    class AppointmentRecurrenceTemplateYearlyTemplateComponent extends BackboneElement {
        /**
         * Appointment recurs every nth year.
         *
         * Recurs every nth year
         */
        yearInterval: number;
        static revive(json: any): AppointmentRecurrenceTemplateYearlyTemplateComponent;
        toJSON(): any;
    }
    class AppointmentRecurrenceTemplateMonthlyTemplateComponent extends BackboneElement {
        /**
         * Indicates which day of the week the recurring appointments should occur each nth week.
         *
         * Indicates which day of the week the appointment should occur
         */
        dayOfWeek?: Coding;
        /**
         * Indicates which week within a month the appointments in the series of recurring appointments should occur on.
         *
         * Indicates which week of the month the appointment should occur
         */
        nthWeekOfMonth?: Coding;
        /**
         * Indicates that recurring appointments should occur every nth month.
         *
         * Recurs every nth month
         */
        monthInterval: number;
        /**
         * Indicates that appointments in the series of recurring appointments should occur on a specific day of the month.
         *
         * Recurs on a specific day of the month
         */
        dayOfMonth?: number;
        static revive(json: any): AppointmentRecurrenceTemplateMonthlyTemplateComponent;
        toJSON(): any;
    }
    class AppointmentRecurrenceTemplateWeeklyTemplateComponent extends BackboneElement {
        /**
         * Indicates that recurring appointments should occur on Wednesdays.
         *
         * Recurs on Wednesday
         */
        wednesday?: boolean;
        /**
         * Indicates that recurring appointments should occur on Thursdays.
         *
         * Recurs on Thursday
         */
        thursday?: boolean;
        /**
         * Indicates that recurring appointments should occur on Fridays.
         *
         * Recurs on Friday
         */
        friday?: boolean;
        /**
         * Indicates that recurring appointments should occur on Mondays.
         *
         * Recurs on Mondays
         */
        monday?: boolean;
        /**
         * Indicates that recurring appointments should occur on Sundays.
         *
         * Recurs on Sunday
         */
        sunday?: boolean;
        /**
         * Indicates that recurring appointments should occur on Saturdays.
         *
         * Recurs on Saturday
         */
        saturday?: boolean;
        /**
         * Indicates that recurring appointments should occur on Tuesdays.
         *
         * Recurs on Tuesday
         */
        tuesday?: boolean;
        /**
         * The interval defines if the recurrence is every nth week. The default is every week, so it is expected that this value will be 2 or more.

e.g. For recurring every second week this interval would be 2, or every third week the interval would be 3.
         *
         * Recurs every nth week
         */
        weekInterval?: number;
        static revive(json: any): AppointmentRecurrenceTemplateWeeklyTemplateComponent;
        toJSON(): any;
    }
    class AppointmentRecurrenceTemplateComponent extends BackboneElement {
        /**
         * The timezone of the recurring appointment occurrences.
         *
         * The timezone of the occurrences
         */
        timezone?: CodeableConcept;
        /**
         * Recurring appointments will not occur after this date.
         *
         * The date when the recurrence should end
         */
        lastOccurrenceDate?: Date;
        /**
         * Any dates, such as holidays, that should be excluded from the recurrence.
         *
         * Any recurrence IDs that should be excluded from the recurrence
         */
        excludingRecurrenceId?: number[];
        /**
         * The list of specific dates that will have appointments generated.
         *
         * Specific dates for a recurring set of appointments (no template)
         */
        occurrenceDate?: Date[];
        /**
         * Information about yearly recurring appointments.
         *
         * Information about yearly recurring appointments
         */
        yearlyTemplate?: Appointment.AppointmentRecurrenceTemplateYearlyTemplateComponent;
        /**
         * Information about monthly recurring appointments.
         *
         * Information about monthly recurring appointments
         */
        monthlyTemplate?: Appointment.AppointmentRecurrenceTemplateMonthlyTemplateComponent;
        /**
         * How often the appointment series should recur.
         *
         * The frequency of the recurrence
         */
        recurrenceType: CodeableConcept;
        /**
         * How many appointments are planned in the recurrence.
         *
         * The number of planned occurrences
         */
        occurrenceCount?: number;
        /**
         * Any dates, such as holidays, that should be excluded from the recurrence.
         *
         * Any dates that should be excluded from the series
         */
        excludingDate?: Date[];
        /**
         * Information about weekly recurring appointments.
         *
         * Information about weekly recurring appointments
         */
        weeklyTemplate?: Appointment.AppointmentRecurrenceTemplateWeeklyTemplateComponent;
        static revive(json: any): AppointmentRecurrenceTemplateComponent;
        toJSON(): any;
    }
    class AppointmentParticipantComponent extends BackboneElement {
        /**
         * The individual, device, location, or service participating in the appointment.
         *
         * The individual, device, location, or service participating in the appointment
         */
        actor?: Patient | Group | Practitioner | PractitionerRole | CareTeam | RelatedPerson | Device | HealthcareService | Location | Reference;
        /**
         * Participation period of the actor.
         *
         * Participation period of the actor
         */
        period?: Period;
        /**
         * Role of participant in the appointment.
         *
         * Role of participant in the appointment
         */
        type?: CodeableConcept[];
        /**
         * Participation status of the actor.
         *
         * accepted | declined | tentative | needs-action
         */
        status: string;
        /**
         * Whether this participant is required to be present at the meeting. If false, the participant is optional.
         *
         * The participant is required to attend (optional when false)
         */
        required?: boolean;
        static revive(json: any): AppointmentParticipantComponent;
        toJSON(): any;
    }
}
