import { Reference } from '../datatype/reference';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Appointment } from '../model/appointment';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { Location } from '../model/location';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>AppointmentResponse</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/AppointmentResponse">http://hl7.org/fhir/StructureDefinition/AppointmentResponse</a>
 * </p>
 *
 */
export declare class AppointmentResponse extends DomainResource {
    /**
     * The recurrence ID (sequence number) of the specific appointment when responding to a recurring request.
     *
     * The recurrence ID of the specific recurring request
     */
    recurrenceId?: number;
    /**
     * Indicates that the response is proposing a different time that was initially requested.  The new proposed time will be indicated in the start and end properties.
     *
     * Indicator for a counter proposal
     */
    proposedNewTime?: boolean;
    /**
     * Date/Time that the appointment is to take place, or requested new start time.
     *
     * Time from appointment, or requested new start time
     */
    start?: Date;
    /**
     * Role of participant in the appointment.
     *
     * Role of participant in the appointment
     */
    participantType?: CodeableConcept[];
    /**
     * Appointment that this response is replying to.
     *
     * Appointment this response relates to
     */
    appointment: Appointment | Reference;
    /**
     * This may be either the same as the appointment request to confirm the details of the appointment, or alternately a new time to request a re-negotiation of the end time.
     *
     * Time from appointment, or requested new end time
     */
    end?: Date;
    /**
     * Participation status of the participant. When the status is declined or tentative if the start/end times are different to the appointment, then these times should be interpreted as a requested time change. When the status is accepted, the times can either be the time of the appointment (as a confirmation of the time) or can be empty.
     *
     * accepted | declined | tentative | needs-action | entered-in-error
     */
    participantStatus: string;
    /**
     * Additional comments about the appointment.
     *
     * Additional comments
     */
    comment?: string;
    /**
     * Indicates that this AppointmentResponse applies to all occurrences in a recurring request.
     *
     * This response is for all occurrences in a recurring request
     */
    recurring?: boolean;
    /**
     * This records identifiers associated with this appointment response concern that are defined by business processes and/ or used to refer to it when a direct URL reference to the resource itself is not appropriate.
     *
     * External Ids for this item
     */
    identifier?: Identifier[];
    /**
     * A Person, Location, HealthcareService, or Device that is participating in the appointment.
     *
     * Person(s), Location, HealthcareService, or Device
     */
    actor?: Patient | Group | Practitioner | PractitionerRole | RelatedPerson | Device | HealthcareService | Location | Reference;
    /**
     * The original date within a recurring request. This could be used in place of the recurrenceId to be more direct (or where the template is provided through the simple list of dates in `Appointment.occurrenceDate`).
     *
     * Original date within a recurring request
     */
    occurrenceDate?: Date;
    readonly resourceType: string;
    static revive(json: any): AppointmentResponse;
    toJSON(): any;
}
export declare namespace AppointmentResponse {
    enum AppointmentResponseStatus {
        NEEDSACTION,
        ENTEREDINERROR,
        ACCEPTED,
        TENTATIVE,
        NULL,
        DECLINED
    }
}
