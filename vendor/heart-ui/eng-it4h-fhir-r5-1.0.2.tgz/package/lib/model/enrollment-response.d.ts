import { Reference } from '../datatype/reference';
import { Identifier } from '../datatype/identifier';
import { DomainResource } from '../model/domain-resource';
import { EnrollmentRequest } from '../model/enrollment-request';
import { Organization } from '../model/organization';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
/**
 * HAPI/FHIR <b>EnrollmentResponse</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/EnrollmentResponse">http://hl7.org/fhir/StructureDefinition/EnrollmentResponse</a>
 * </p>
 *
 */
export declare class EnrollmentResponse extends DomainResource {
    /**
     * Processing status: error, complete.
     *
     * queued | complete | error | partial
     */
    outcome?: string;
    /**
     * The status of the resource instance.
     *
     * active | cancelled | draft | entered-in-error
     */
    status?: string;
    /**
     * The Response business identifier.
     *
     * Business Identifier
     */
    identifier?: Identifier[];
    /**
     * Original request resource reference.
     *
     * Claim reference
     */
    request?: EnrollmentRequest | Reference;
    /**
     * A description of the status of the adjudication.
     *
     * Disposition Message
     */
    disposition?: string;
    /**
     * The practitioner who is responsible for the services rendered to the patient.
     *
     * Responsible practitioner
     */
    requestProvider?: Practitioner | PractitionerRole | Organization | Reference;
    /**
     * The date when the enclosed suite of services were performed or completed.
     *
     * Creation date
     */
    created?: Date;
    /**
     * The Insurer who produced this adjudicated response.
     *
     * Insurer
     */
    organization?: Organization | Reference;
    readonly resourceType: string;
    static revive(json: any): EnrollmentResponse;
    toJSON(): any;
}
export declare namespace EnrollmentResponse {
    enum EnrollmentOutcome {
        COMPLETE,
        NULL,
        QUEUED,
        PARTIAL,
        ERROR
    }
    enum FinancialResourceStatusCodes {
        CANCELLED,
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        DRAFT
    }
}
