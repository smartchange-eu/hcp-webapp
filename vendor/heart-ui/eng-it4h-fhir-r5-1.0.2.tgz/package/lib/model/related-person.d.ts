import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Address } from '../datatype/address';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { ContactPoint } from '../datatype/contact-point';
import { HumanName } from '../datatype/human-name';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { DomainResource } from '../model/domain-resource';
import { Patient } from '../model/patient';
/**
 * HAPI/FHIR <b>RelatedPerson</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/RelatedPerson">http://hl7.org/fhir/StructureDefinition/RelatedPerson</a>
 * </p>
 *
 */
export declare class RelatedPerson extends DomainResource {
    /**
     * A name associated with the person.
     *
     * A name associated with the person
     */
    name?: HumanName[];
    /**
     * Whether this related person record is in active use.
     *
     * Whether this related person's record is in active use
     */
    active?: boolean;
    /**
     * Image of the person.
     *
     * Image of the person
     */
    photo?: Attachment[];
    /**
     * A contact detail for the person, e.g. a telephone number or an email address.
     *
     * A contact detail for the person
     */
    telecom?: ContactPoint[];
    /**
     * The nature of the relationship between the related person and the patient.
     *
     * The relationship of the related person to the patient
     */
    relationship?: CodeableConcept[];
    /**
     * A language which may be used to communicate with the related person about the patient's health.
     *
     * A language which may be used to communicate with the related person about the patient's health
     */
    communication?: RelatedPerson.RelatedPersonCommunicationComponent[];
    /**
     * The date on which the related person was born.
     *
     * The date on which the related person was born
     */
    birthDate?: Date;
    /**
     * Identifier for a person within a particular scope.
     *
     * A human identifier for this person
     */
    identifier?: Identifier[];
    /**
     * The period of time during which this relationship is or was active. If there are no dates defined, then the interval is unknown.
     *
     * Period of time that this relationship is considered valid
     */
    period?: Period;
    /**
     * Address where the related person can be contacted or visited.
     *
     * Address where the related person can be contacted or visited
     */
    address?: Address[];
    /**
     * Administrative Gender - the gender that the person is considered to have for administration and record keeping purposes.
     *
     * male | female | other | unknown
     */
    gender?: string;
    /**
     * The patient this person is related to.
     *
     * The patient this person is related to
     */
    patient: Patient | Reference;
    readonly resourceType: string;
    static revive(json: any): RelatedPerson;
    toJSON(): any;
}
export declare namespace RelatedPerson {
    enum AdministrativeGender {
        OTHER,
        NULL,
        UNKNOWN,
        MALE,
        FEMALE
    }
    class RelatedPersonCommunicationComponent extends BackboneElement {
        /**
         * The ISO-639-1 alpha 2 code in lower case for the language, optionally followed by a hyphen and the ISO-3166-1 alpha 2 code for the region in upper case; e.g. "en" for English, or "en-US" for American English versus "en-AU" for Australian English.
         *
         * The language which can be used to communicate with the related person about the patient's health
         */
        language: CodeableConcept;
        /**
         * Indicates whether or not the related person prefers this language (over other languages he or she masters up a certain level).
         *
         * Language preference indicator
         */
        preferred?: boolean;
        static revive(json: any): RelatedPersonCommunicationComponent;
        toJSON(): any;
    }
}
