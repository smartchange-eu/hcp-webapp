import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Address } from '../datatype/address';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { Duration } from '../datatype/duration';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { Ratio } from '../datatype/ratio';
import { BiologicallyDerivedProduct } from '../model/biologically-derived-product';
import { Device } from '../model/device';
import { DeviceDefinition } from '../model/device-definition';
import { DomainResource } from '../model/domain-resource';
import { Location } from '../model/location';
import { Medication } from '../model/medication';
import { MedicationKnowledge } from '../model/medication-knowledge';
import { NutritionProduct } from '../model/nutrition-product';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
/**
 * HAPI/FHIR <b>InventoryItem</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/InventoryItem">http://hl7.org/fhir/StructureDefinition/InventoryItem</a>
 * </p>
 *
 */
export declare class InventoryItem extends DomainResource {
    /**
     * Organization(s) responsible for the product.
     *
     * Organization(s) responsible for the product
     */
    responsibleOrganization?: InventoryItem.InventoryItemResponsibleOrganizationComponent[];
    /**
     * The descriptive characteristics of the inventory item.
     *
     * Descriptive characteristics of the item
     */
    description?: InventoryItem.InventoryItemDescriptionComponent;
    /**
     * Association with other items or products.
     *
     * Association with other items or products
     */
    association?: InventoryItem.InventoryItemAssociationComponent[];
    /**
     * Link to a product resource used in clinical workflows.
     *
     * Link to a product resource used in clinical workflows
     */
    productReference?: Medication | Device | NutritionProduct | BiologicallyDerivedProduct | Reference;
    /**
     * The descriptive or identifying characteristics of the item.
     *
     * Characteristic of the item
     */
    characteristic?: InventoryItem.InventoryItemCharacteristicComponent[];
    /**
     * Code designating the specific type of item.
     *
     * Code designating the specific type of item
     */
    code?: CodeableConcept[];
    /**
     * Instances or occurrences of the product.
     *
     * Instances or occurrences of the product
     */
    instance?: InventoryItem.InventoryItemInstanceComponent;
    /**
     * Business identifier for the inventory item.
     *
     * Business identifier for the inventory item
     */
    identifier?: Identifier[];
    /**
     * The usage status e.g. recalled, in use, discarded... This can be used to indicate that the items have been taken out of inventory, or are in use, etc.
     *
     * The usage status like recalled, in use, discarded
     */
    inventoryStatus?: CodeableConcept[];
    /**
     * Net content or amount present in the item.
     *
     * Net content or amount present in the item
     */
    netContent?: Quantity;
    /**
     * The item name(s) - the brand name, or common name, functional name, generic name.
     *
     * The item name(s) - the brand name, or common name, functional name, generic name or others
     */
    name?: InventoryItem.InventoryItemNameComponent[];
    /**
     * Status of the item entry.
     *
     * active | inactive | entered-in-error | unknown
     */
    status: string;
    /**
     * Category or class of the item.
     *
     * Category or class of the item
     */
    category?: CodeableConcept[];
    /**
     * The base unit of measure - the unit in which the product is used or counted.
     *
     * The base unit of measure - the unit in which the product is used or counted
     */
    baseUnit?: CodeableConcept;
    readonly resourceType: string;
    static revive(json: any): InventoryItem;
    toJSON(): any;
}
export declare namespace InventoryItem {
    enum InventoryItemStatusCodes {
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        INACTIVE,
        UNKNOWN
    }
    class InventoryItemInstanceComponent extends BackboneElement {
        /**
         * The lot or batch number of the item.
         *
         * The lot or batch number of the item
         */
        lotNumber?: string;
        /**
         * The expiry date or date and time for the product.
         *
         * The expiry date or date and time for the product
         */
        expiry?: Date;
        /**
         * The location that the item is associated with.
         *
         * The location that the item is associated with
         */
        location?: Location | Reference;
        /**
         * The identifier for the physical instance, typically a serial number.
         *
         * The identifier for the physical instance, typically a serial number
         */
        identifier?: Identifier[];
        /**
         * The subject that the item is associated with.
         *
         * The subject that the item is associated with
         */
        subject?: Patient | Organization | Reference;
        static revive(json: any): InventoryItemInstanceComponent;
        toJSON(): any;
    }
    class InventoryItemCharacteristicComponent extends BackboneElement {
        /**
         * The type of characteristic that is being defined.
         *
         * The characteristic that is being defined
         */
        characteristicType: CodeableConcept;
        /**
         * The value of the attribute.
         *
         * The value of the attribute
         */
        value: string | number | number | boolean | Date | Quantity | Range | Ratio | Annotation | Address | Duration | CodeableConcept;
        static revive(json: any): InventoryItemCharacteristicComponent;
        toJSON(): any;
    }
    class InventoryItemAssociationComponent extends BackboneElement {
        /**
         * The quantity of the related product in this product - Numerator is the quantity of the related product. Denominator is the quantity of the present product. For example a value of 20 means that this product contains 20 units of the related product; a value of 1:20 means the inverse - that the contained product contains 20 units of the present product.
         *
         * The quantity of the product in this product
         */
        quantity: Ratio;
        /**
         * This attribute defined the type of association when establishing associations or relations between items, e.g. 'packaged within' or 'used with' or 'to be mixed with.
         *
         * The type of association between the device and the other item
         */
        associationType: CodeableConcept;
        /**
         * The related item or product.
         *
         * The related item or product
         */
        relatedItem: InventoryItem | Medication | MedicationKnowledge | Device | DeviceDefinition | NutritionProduct | BiologicallyDerivedProduct | Reference;
        static revive(json: any): InventoryItemAssociationComponent;
        toJSON(): any;
    }
    class InventoryItemDescriptionComponent extends BackboneElement {
        /**
         * The language for the item description, when an item must be described in different languages and those languages may be authoritative and not translations of a 'main' language.
         *
         * The language that is used in the item description
         */
        language?: string;
        /**
         * Textual description of the item.
         *
         * Textual description of the item
         */
        description?: string;
        static revive(json: any): InventoryItemDescriptionComponent;
        toJSON(): any;
    }
    class InventoryItemResponsibleOrganizationComponent extends BackboneElement {
        /**
         * An organization that has an association with the item, e.g. manufacturer, distributor, responsible, etc.
         *
         * An organization that is associated with the item
         */
        organization: Organization | Reference;
        /**
         * The role of the organization e.g. manufacturer, distributor, etc.
         *
         * The role of the organization e.g. manufacturer, distributor, or other
         */
        role: CodeableConcept;
        static revive(json: any): InventoryItemResponsibleOrganizationComponent;
        toJSON(): any;
    }
    class InventoryItemNameComponent extends BackboneElement {
        /**
         * The language that the item name is expressed in.
         *
         * The language used to express the item name
         */
        language: string;
        /**
         * The name or designation that the item is given.
         *
         * The name or designation of the item
         */
        name: string;
        /**
         * The type of name e.g. 'brand-name', 'functional-name', 'common-name'.
         *
         * The type of name e.g. 'brand-name', 'functional-name', 'common-name'
         */
        nameType: Coding;
        static revive(json: any): InventoryItemNameComponent;
        toJSON(): any;
    }
}
