import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { UsageContext } from '../datatype/usage-context';
import { CanonicalResource } from '../model/canonical-resource';
import { Organization } from '../model/organization';
/**
 * HAPI/FHIR <b>CapabilityStatement</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/CapabilityStatement">http://hl7.org/fhir/StructureDefinition/CapabilityStatement</a>
 * </p>
 *
 */
export declare class CapabilityStatement extends CanonicalResource {
    /**
     * Identifies a specific implementation instance that is described by the capability statement - i.e. a particular installation, rather than the capabilities of a software program.
     *
     * If this describes a specific instance
     */
    implementation?: CapabilityStatement.CapabilityStatementImplementationComponent;
    /**
     * The way that this statement is intended to be used, to describe an actual running instance of software, a particular product (kind, not instance of software) or a class of implementation (e.g. a desired purchase).
     *
     * instance | capability | requirements
     */
    kind: string;
    /**
     * Reference to a canonical URL of another CapabilityStatement that this software adds to. The capability statement automatically includes everything in the other statement, and it is not duplicated, though the server may repeat the same resources, interactions and operations to add additional details to them.
     *
     * Canonical URL of another capability statement this adds to
     */
    imports?: string[];
    /**
     * A formal identifier that is used to identify this CapabilityStatement when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the CapabilityStatement (business identifier)
     */
    identifier?: Identifier[];
    /**
     * A definition of the restful capabilities of the solution, if any.
     *
     * If the endpoint is a RESTful one
     */
    rest?: CapabilityStatement.CapabilityStatementRestComponent[];
    /**
     * A description of the messaging capabilities of the solution.
     *
     * If messaging is supported
     */
    messaging?: CapabilityStatement.CapabilityStatementMessagingComponent[];
    /**
     * An absolute URI that is used to identify this capability statement when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this capability statement is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the capability statement is stored on different servers.
     *
     * Canonical identifier for this capability statement, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * The identifier that is used to identify this version of the capability statement when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the capability statement author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the capability statement
     */
    version?: string;
    /**
     * A list of the formats supported by this implementation using their content types.
     *
     * formats supported (xml | json | ttl | mime type)
     */
    format: string[];
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * A list of the languages supported by this implementation that are usefully supported in the ```Accept-Language``` header.
     *
     * Languages supported
     */
    acceptLanguage?: string[];
    /**
     * A list of implementation guides that the server does (or should) support in their entirety.
     *
     * Implementation guides supported
     */
    implementationGuide?: string[];
    /**
     * The status of this capability statement. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate capability statement instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the capability statement.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * A natural language name identifying the capability statement. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this capability statement (computer friendly)
     */
    name?: string;
    /**
     * A legal or geographic region in which the capability statement is intended to be used.
     *
     * Intended jurisdiction for capability statement (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * A document definition.
     *
     * Document definition
     */
    document?: CapabilityStatement.CapabilityStatementDocumentComponent[];
    /**
     * Explanation of why this capability statement is needed and why it has been designed as it has.
     *
     * Why this capability statement is defined
     */
    purpose?: string;
    /**
     * Software that is covered by this capability statement.  It is used when the capability statement describes the capabilities of a particular software version, independent of an installation.
     *
     * Software that is covered by this capability statement
     */
    software?: CapabilityStatement.CapabilityStatementSoftwareComponent;
    /**
     * A copyright statement relating to the capability statement and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the capability statement.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * Reference to a canonical URL of another CapabilityStatement that this software implements. This capability statement is a published API description that corresponds to a business service. The server may actually implement a subset of the capability statement it claims to implement, so the capability statement must specify the full capability details.
     *
     * Canonical URL of another capability statement this implements
     */
    instantiates?: string[];
    /**
     * The date  (and optionally time) when the capability statement was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the capability statement changes.
     *
     * Date last changed
     */
    date: Date;
    /**
     * A short, descriptive, user-friendly title for the capability statement.
     *
     * Name for this capability statement (human friendly)
     */
    title?: string;
    /**
     * A Boolean value to indicate that this capability statement is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A free text natural language description of the capability statement from a consumer's perspective. Typically, this is used when the capability statement describes a desired rather than an actual solution, for example as a formal expression of requirements as part of an RFP.
     *
     * Natural language description of the capability statement
     */
    description?: string;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * The version of the FHIR specification that this CapabilityStatement describes (which SHALL be the same as the FHIR version of the CapabilityStatement itself). There is no default value.
     *
     * FHIR Version the system supports
     */
    fhirVersion: string;
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * A list of the patch formats supported by this implementation using their content types.
     *
     * Patch formats supported
     */
    patchFormat?: string[];
    readonly resourceType: string;
    static revive(json: any): CapabilityStatement;
    toJSON(): any;
}
export declare namespace CapabilityStatement {
    enum TypeRestfulInteraction {
        READ,
        DELETE,
        HISTORYINSTANCE,
        HISTORYTYPE,
        NULL,
        CREATE,
        UPDATE,
        SEARCHTYPE,
        VREAD,
        PATCH
    }
    enum SystemRestfulInteraction {
        NULL,
        TRANSACTION,
        BATCH,
        HISTORYSYSTEM,
        SEARCHSYSTEM
    }
    enum RestfulCapabilityMode {
        NULL,
        SERVER,
        CLIENT
    }
    enum ResourceVersionPolicy {
        NOVERSION,
        NULL,
        VERSIONEDUPDATE,
        VERSIONED
    }
    enum ReferenceHandlingPolicy {
        NULL,
        LITERAL,
        LOCAL,
        LOGICAL,
        RESOLVES,
        ENFORCED
    }
    enum EventCapabilityMode {
        NULL,
        SENDER,
        RECEIVER
    }
    enum DocumentMode {
        PRODUCER,
        NULL,
        CONSUMER
    }
    enum ConditionalReadStatus {
        MODIFIEDSINCE,
        FULLSUPPORT,
        NULL,
        NOTMATCH,
        NOTSUPPORTED
    }
    enum ConditionalDeleteStatus {
        SINGLE,
        NULL,
        NOTSUPPORTED,
        MULTIPLE
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    enum CapabilityStatementKind {
        REQUIREMENTS,
        NULL,
        INSTANCE,
        CAPABILITY
    }
    enum FHIRVersion {
        _4_5,
        _4_4,
        _0_05,
        _4_3,
        _4_2,
        _0_06,
        _4_6,
        _0_0,
        _4_3_0SNAPSHOT1,
        _0_5,
        _3_5_0,
        _4_1,
        _0_4,
        _4_0,
        _3_3_0,
        _5_0_0BALLOT,
        _5_0_0CIBUILD,
        _6_0_0,
        _0_0_81,
        _0_0_82,
        _0_01,
        _0_0_80,
        _1_6_0,
        _4_3_0CIBUILD,
        _1_4_0,
        NULL,
        _1_8_0,
        _1_0_2,
        _1_0_0,
        _1_0_1,
        _4_5_0,
        _0_4_0,
        _4_1_0,
        _0_11,
        _4_3_0,
        _1_8,
        _3_0_1,
        _3_0_0,
        _3_5,
        _1_6,
        _3_3,
        _1_0,
        _5_0,
        _1_4,
        _3_0,
        _1_1,
        _3_0_2,
        _5_0_0DRAFTFINAL,
        _6_0_0CIBUILD,
        _5_0_0,
        _1_1_0,
        _4_0_0,
        _0_5_0,
        _5_0_0SNAPSHOT1,
        _5_0_0SNAPSHOT3,
        _5_0_0SNAPSHOT2,
        _4_6_0,
        _4_2_0,
        _4_0_1,
        _4_4_0
    }
    class CapabilityStatementDocumentComponent extends BackboneElement {
        /**
         * Mode of this document declaration - whether an application is a producer or consumer.
         *
         * producer | consumer
         */
        mode: string;
        /**
         * A description of how the application supports or uses the specified document profile.  For example, when documents are created, what action is taken with consumed documents, etc.
         *
         * Description of document support
         */
        documentation?: string;
        /**
         * A profile on the document Bundle that constrains which resources are present, and their contents.
         *
         * Constraint on the resources used in the document
         */
        profile: string;
        static revive(json: any): CapabilityStatementDocumentComponent;
        toJSON(): any;
    }
    class CapabilityStatementMessagingSupportedMessageComponent extends BackboneElement {
        /**
         * Points to a message definition that identifies the messaging event, message structure, allowed responses, etc.
         *
         * Message supported by this system
         */
        definition: string;
        /**
         * The mode of this event declaration - whether application is sender or receiver.
         *
         * sender | receiver
         */
        mode: string;
        static revive(json: any): CapabilityStatementMessagingSupportedMessageComponent;
        toJSON(): any;
    }
    class CapabilityStatementMessagingEndpointComponent extends BackboneElement {
        /**
         * The network address of the endpoint. For solutions that do not use network addresses for routing, it can be just an identifier.
         *
         * Network address or identifier of the end-point
         */
        address: string;
        /**
         * A list of the messaging transport protocol(s) identifiers, supported by this endpoint.
         *
         * http | ftp | mllp +
         */
        protocol: Coding;
        static revive(json: any): CapabilityStatementMessagingEndpointComponent;
        toJSON(): any;
    }
    class CapabilityStatementMessagingComponent extends BackboneElement {
        /**
         * References to message definitions for messages this system can send or receive.
         *
         * Messages supported by this system
         */
        supportedMessage?: CapabilityStatement.CapabilityStatementMessagingSupportedMessageComponent[];
        /**
         * Length if the receiver's reliable messaging cache in minutes (if a receiver) or how long the cache length on the receiver should be (if a sender).
         *
         * Reliable Message Cache Length (min)
         */
        reliableCache?: number;
        /**
         * Documentation about the system's messaging capabilities for this endpoint not otherwise documented by the capability statement.  For example, the process for becoming an authorized messaging exchange partner.
         *
         * Messaging interface behavior details
         */
        documentation?: string;
        /**
         * An endpoint (network accessible address) to which messages and/or replies are to be sent.
         *
         * Where messages should be sent
         */
        endpoint?: CapabilityStatement.CapabilityStatementMessagingEndpointComponent[];
        static revive(json: any): CapabilityStatementMessagingComponent;
        toJSON(): any;
    }
    class SystemInteractionComponent extends BackboneElement {
        /**
         * A coded identifier of the operation, supported by the system.
         *
         * transaction | batch | search-system | history-system
         */
        code: string;
        /**
         * Guidance specific to the implementation of this operation, such as limitations on the kind of transactions allowed, or information about system wide search is implemented.
         *
         * Anything special about operation behavior
         */
        documentation?: string;
        static revive(json: any): SystemInteractionComponent;
        toJSON(): any;
    }
    class CapabilityStatementRestResourceOperationComponent extends BackboneElement {
        /**
         * Where the formal definition can be found. If a server references the base definition of an Operation (i.e. from the specification itself such as ```http://hl7.org/fhir/OperationDefinition/ValueSet-expand```), that means it supports the full capabilities of the operation - e.g. both GET and POST invocation.  If it only supports a subset, it must define its own custom [OperationDefinition](operationdefinition.html#) with a 'base' of the original OperationDefinition.  The custom definition would describe the specific subset of functionality supported.
         *
         * The defined operation/query
         */
        definition: string;
        /**
         * The name of the operation or query. For an operation, this name is prefixed with $ and used in the URL. For a query, this is the name used in the _query parameter when the query is called. This SHOULD be the same as the OperationDefinition.code of the defining OperationDefinition.  However, it can sometimes differ if necessary to disambiguate when a server supports multiple OperationDefinition that happen to share the same code.
         *
         * Name by which the operation/query is invoked
         */
        name: string;
        /**
         * Documentation that describes anything special about the operation behavior, possibly detailing different behavior for system, type and instance-level invocation of the operation.
         *
         * Specific details about operation behavior
         */
        documentation?: string;
        static revive(json: any): CapabilityStatementRestResourceOperationComponent;
        toJSON(): any;
    }
    class CapabilityStatementRestResourceSearchParamComponent extends BackboneElement {
        /**
         * The label used for the search parameter in this particular system's API - i.e. the 'name' portion of the name-value pair that will appear as part of the search URL.  This SHOULD be the same as the SearchParameter.code of the defining SearchParameter.  However, it can sometimes differ if necessary to disambiguate when a server supports multiple SearchParameters that happen to share the same code.
         *
         * Name for parameter in search url
         */
        name: string;
        /**
         * An absolute URI that is a formal reference to where this parameter was first defined, so that a client can be confident of the meaning of the search parameter (a reference to [SearchParameter.url](searchparameter-definitions.html#SearchParameter.url)). This element SHALL be populated if the search parameter refers to a SearchParameter defined by the FHIR core specification or externally defined IGs.
         *
         * Source of definition for parameter
         */
        definition?: string;
        /**
         * The type of value a search parameter refers to, and how the content is interpreted.
         *
         * number | date | string | token | reference | composite | quantity | uri | special
         */
        type: string;
        /**
         * This allows documentation of any distinct behaviors about how the search parameter is used.  For example, text matching algorithms.
         *
         * Server-specific usage
         */
        documentation?: string;
        static revive(json: any): CapabilityStatementRestResourceSearchParamComponent;
        toJSON(): any;
    }
    class ResourceInteractionComponent extends BackboneElement {
        /**
         * Guidance specific to the implementation of this operation, such as 'delete is a logical delete' or 'updates are only allowed with version id' or 'creates permitted from pre-authorized certificates only'.
         *
         * Anything special about operation behavior
         */
        documentation?: string;
        /**
         * Coded identifier of the operation, supported by the system resource.
         *
         * read | vread | update | patch | delete | history-instance | history-type | create | search-type
         */
        code: string;
        static revive(json: any): ResourceInteractionComponent;
        toJSON(): any;
    }
    class CapabilityStatementRestResourceComponent extends BackboneElement {
        /**
         * A set of flags that defines how references are supported.
         *
         * literal | logical | resolves | enforced | local
         */
        referencePolicy?: string[];
        /**
         * A type of resource exposed via the restful interface.
         *
         * A resource type that is supported
         */
        type: string;
        /**
         * A flag that indicates that the server supports conditional patch.
         *
         * If allows/uses conditional patch
         */
        conditionalPatch?: boolean;
        /**
         * This field is set to no-version to specify that the system does not support (server) or use (client) versioning for this resource type. If this has some other value, the server must at least correctly track and populate the versionId meta-property on resources. If the value is 'versioned-update', then the server supports all the versioning features, including using e-tags for version integrity in the API.
         *
         * no-version | versioned | versioned-update
         */
        versioning?: string;
        /**
         * A flag that indicates that the server supports conditional create.
         *
         * If allows/uses conditional create
         */
        conditionalCreate?: boolean;
        /**
         * A flag to indicate that the server allows or needs to allow the client to create new identities on the server (that is, the client PUTs to a location where there is no existing resource). Allowing this operation means that the server allows the client to create new identities on the server.
         *
         * If update can commit to a new identity
         */
        updateCreate?: boolean;
        /**
         * A list of _include values supported by the server.
         *
         * _include values supported by the server
         */
        searchInclude?: string[];
        /**
         * A system-wide profile that is applied across *all* instances of the resource supported by the system. For example, if declared on Observation, this profile is the "superset" of capabilities for laboratory *and* vitals *and* other domains. See further discussion in [Using Profiles](profiling.html#profile-uses).
         *
         * System-wide profile
         */
        profile?: string;
        /**
         * Additional information about the resource type used by the system.
         *
         * Additional information about the use of the resource type
         */
        documentation?: string;
        /**
         * A list of _revinclude (reverse include) values supported by the server.
         *
         * _revinclude values supported by the server
         */
        searchRevInclude?: string[];
        /**
         * Search parameters for implementations to support and/or make use of - either references to ones defined in the specification, or additional ones defined for/by the implementation.
         *
         * Search parameters supported by implementation
         */
        searchParam?: CapabilityStatement.CapabilityStatementRestResourceSearchParamComponent[];
        /**
         * Identifies a restful operation supported by the solution.
         *
         * What operations are supported?
         */
        interaction?: CapabilityStatement.ResourceInteractionComponent[];
        /**
         * Definition of an operation or a named query together with its parameters and their meaning and type. Consult the definition of the operation for details about how to invoke the operation, and the parameters.
         *
         * Definition of a resource operation
         */
        operation?: CapabilityStatement.CapabilityStatementRestResourceOperationComponent[];
        /**
         * A flag for whether the server is able to return past versions as part of the vRead operation.
         *
         * Whether vRead can return past versions
         */
        readHistory?: boolean;
        /**
         * A flag that indicates that the server supports conditional update.
         *
         * If allows/uses conditional update
         */
        conditionalUpdate?: boolean;
        /**
         * A code that indicates how the server supports conditional delete.
         *
         * not-supported | single | multiple - how conditional delete is supported
         */
        conditionalDelete?: string;
        /**
         * A list of profiles representing different use cases the system hosts/produces. A supported profile is a statement about the functionality of the data and services provided by the server (or the client) for supported use cases. For example, a system can define and declare multiple Observation profiles for laboratory observations, vital sign observations, etc. By declaring supported profiles, systems provide a way to determine whether individual resources are conformant. See further discussion in [Using Profiles](profiling.html#profile-uses).
         *
         * Use-case specific profiles
         */
        supportedProfile?: string[];
        /**
         * A code that indicates how the server supports conditional read.
         *
         * not-supported | modified-since | not-match | full-support
         */
        conditionalRead?: string;
        static revive(json: any): CapabilityStatementRestResourceComponent;
        toJSON(): any;
    }
    class CapabilityStatementRestSecurityComponent extends BackboneElement {
        /**
         * Types of security services that are supported/required by the system.
         *
         * OAuth | SMART-on-FHIR | NTLM | Basic | Kerberos | Certificates
         */
        service?: CodeableConcept[];
        /**
         * Server adds CORS headers when responding to requests - this enables Javascript applications to use the server.
         *
         * Adds CORS Headers (http://enable-cors.org/)
         */
        cors?: boolean;
        /**
         * General description of how security works.
         *
         * General description of how security works
         */
        description?: string;
        static revive(json: any): CapabilityStatementRestSecurityComponent;
        toJSON(): any;
    }
    class CapabilityStatementRestComponent extends BackboneElement {
        /**
         * Information about security implementation from an interface perspective - what a client needs to know.
         *
         * Information about security of implementation
         */
        security?: CapabilityStatement.CapabilityStatementRestSecurityComponent;
        /**
         * Identifies whether this portion of the statement is describing the ability to initiate or receive restful operations.
         *
         * client | server
         */
        mode: string;
        /**
         * Information about the system's restful capabilities that apply across all applications, such as security.
         *
         * General description of implementation
         */
        documentation?: string;
        /**
         * A specification of the restful capabilities of the solution for a specific resource type.
         *
         * Resource served on the REST interface
         */
        resource?: CapabilityStatement.CapabilityStatementRestResourceComponent[];
        /**
         * Search parameters that are supported for searching all resources for implementations to support and/or make use of - either references to ones defined in the specification, or additional ones defined for/by the implementation. This is only for searches executed against the system-level endpoint.
         *
         * Search parameters for searching all resources
         */
        searchParam?: CapabilityStatement.CapabilityStatementRestResourceSearchParamComponent[];
        /**
         * A specification of restful operations supported by the system.
         *
         * What operations are supported?
         */
        interaction?: CapabilityStatement.SystemInteractionComponent[];
        /**
         * An absolute URI which is a reference to the definition of a compartment that the system supports. The reference is to a CompartmentDefinition resource by its canonical URL .
         *
         * Compartments served/used by system
         */
        compartment?: string[];
        /**
         * Definition of an operation or a named query together with its parameters and their meaning and type.
         *
         * Definition of a system level operation
         */
        operation?: CapabilityStatement.CapabilityStatementRestResourceOperationComponent[];
        static revive(json: any): CapabilityStatementRestComponent;
        toJSON(): any;
    }
    class CapabilityStatementImplementationComponent extends BackboneElement {
        /**
         * The organization responsible for the management of the instance and oversight of the data on the server at the specified URL.
         *
         * Organization that manages the data
         */
        custodian?: Organization | Reference;
        /**
         * Information about the specific installation that this capability statement relates to.
         *
         * Describes this specific instance
         */
        description: string;
        /**
         * An absolute base URL for the implementation.  This forms the base for REST interfaces as well as the mailbox and document interfaces.
         *
         * Base URL for the installation
         */
        url?: string;
        static revive(json: any): CapabilityStatementImplementationComponent;
        toJSON(): any;
    }
    class CapabilityStatementSoftwareComponent extends BackboneElement {
        /**
         * Date this version of the software was released.
         *
         * Date this version was released
         */
        releaseDate?: Date;
        /**
         * The version identifier for the software covered by this statement.
         *
         * Version covered by this statement
         */
        version?: string;
        /**
         * Name the software is known by.
         *
         * A name the software is known by
         */
        name: string;
        static revive(json: any): CapabilityStatementSoftwareComponent;
        toJSON(): any;
    }
}
