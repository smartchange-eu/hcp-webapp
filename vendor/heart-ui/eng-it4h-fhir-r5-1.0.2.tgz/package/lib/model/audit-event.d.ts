import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { Ratio } from '../datatype/ratio';
import { CarePlan } from '../model/care-plan';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DeviceRequest } from '../model/device-request';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Endpoint } from '../model/endpoint';
import { ImmunizationRecommendation } from '../model/immunization-recommendation';
import { Location } from '../model/location';
import { MedicationRequest } from '../model/medication-request';
import { NutritionOrder } from '../model/nutrition-order';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
import { ServiceRequest } from '../model/service-request';
import { Task } from '../model/task';
/**
 * HAPI/FHIR <b>AuditEvent</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/AuditEvent">http://hl7.org/fhir/StructureDefinition/AuditEvent</a>
 * </p>
 *
 */
export declare class AuditEvent extends DomainResource {
    /**
     * Describes what happened. The most specific code for the event.
     *
     * Specific type of event
     */
    code: CodeableConcept;
    /**
     * An actor taking an active role in the event or activity that is logged.
     *
     * Actor involved in the event
     */
    agent: AuditEvent.AuditEventAgentComponent[];
    /**
     * Indicates and enables segmentation of various severity including debugging from critical.
     *
     * emergency | alert | critical | error | warning | notice | informational | debug
     */
    severity?: string;
    /**
     * The time or period during which the activity occurred.
     *
     * When the activity occurred
     */
    occurred?: Period | Date;
    /**
     * This will typically be the encounter the event occurred, but some events may be initiated prior to or after the official completion of an encounter but still be tied to the context of the encounter (e.g. pre-admission lab tests).
     *
     * Encounter within which this event occurred or which the event is tightly associated
     */
    encounter?: Encounter | Reference;
    /**
     * The actor that is reporting the event.
     *
     * Audit Event Reporter
     */
    source: AuditEvent.AuditEventSourceComponent;
    /**
     * The time when the event was recorded.
     *
     * Time when the event was recorded
     */
    recorded: Date;
    /**
     * The authorization (e.g., PurposeOfUse) that was used during the event being recorded.
     *
     * Authorization related to the event
     */
    authorization?: CodeableConcept[];
    /**
     * The patient element is available to enable deterministic tracking of activities that involve the patient as the subject of the data used in an activity.
     *
     * The patient is the subject of the data used/created/updated/deleted during the activity
     */
    patient?: Patient | Reference;
    /**
     * Indicator for type of action performed during the event that generated the audit.
     *
     * Type of action performed during the event
     */
    action?: string;
    /**
     * Indicates whether the event succeeded or failed. A free text descripiton can be given in outcome.text.
     *
     * Whether the event succeeded or failed
     */
    outcome?: AuditEvent.AuditEventOutcomeComponent;
    /**
     * Allows tracing of authorizatino for the events and tracking whether proposals/recommendations were acted upon.
     *
     * Workflow authorization within which this event occurred
     */
    basedOn?: CarePlan[] | DeviceRequest[] | ImmunizationRecommendation[] | MedicationRequest[] | NutritionOrder[] | ServiceRequest[] | Task[] | Reference[];
    /**
     * Specific instances of data or objects that have been accessed.
     *
     * Data or objects used
     */
    entity?: AuditEvent.AuditEventEntityComponent[];
    /**
     * Classification of the type of event.
     *
     * Type/identifier of event
     */
    category?: CodeableConcept[];
    readonly resourceType: string;
    static revive(json: any): AuditEvent;
    toJSON(): any;
}
export declare namespace AuditEvent {
    enum AuditEventSeverity {
        EMERGENCY,
        NOTICE,
        NULL,
        ERROR,
        ALERT,
        INFORMATIONAL,
        WARNING,
        DEBUG,
        CRITICAL
    }
    enum AuditEventAction {
        R,
        C,
        NULL,
        D,
        U,
        E
    }
    class AuditEventEntityDetailComponent extends BackboneElement {
        /**
         * The type of extra detail provided in the value.
         *
         * Name of the property
         */
        type: CodeableConcept;
        /**
         * The  value of the extra detail.
         *
         * Property value
         */
        value: Quantity | CodeableConcept | string | boolean | number | Range | Ratio | Date | Date | Period;
        static revive(json: any): AuditEventEntityDetailComponent;
        toJSON(): any;
    }
    class AuditEventEntityComponent extends BackboneElement {
        /**
         * Tagged value pairs for conveying additional information about the entity.
         *
         * Additional Information about the entity
         */
        detail?: AuditEvent.AuditEventEntityDetailComponent[];
        /**
         * The entity is attributed to an agent to express the agent's responsibility for that entity in the activity. This is most used to indicate when persistence media (the entity) are used by an agent. For example when importing data from a device, the device would be described in an entity, and the user importing data from that media would be indicated as the entity.agent.
         *
         * Entity is attributed to this agent
         */
        agent?: AuditEvent.AuditEventAgentComponent[];
        /**
         * Identifies a specific instance of the entity. The reference should be version specific. This is allowed to be a Parameters resource.
         *
         * Specific instance of resource
         */
        what?: Reference;
        /**
         * Code representing the role the entity played in the event being audited.
         *
         * What role the entity played
         */
        role?: CodeableConcept;
        /**
         * Security labels for the identified entity.
         *
         * Security labels on the entity
         */
        securityLabel?: CodeableConcept[];
        /**
         * The query parameters for a query-type entities.
         *
         * Query parameters
         */
        query?: string;
        static revive(json: any): AuditEventEntityComponent;
        toJSON(): any;
    }
    class AuditEventSourceComponent extends BackboneElement {
        /**
         * Logical source location within the healthcare enterprise network.  For example, a hospital or other provider location within a multi-entity provider group.
         *
         * Logical source location within the enterprise
         */
        site?: Location | Reference;
        /**
         * Identifier of the source where the event was detected.
         *
         * The identity of source detecting the event
         */
        observer: Practitioner | PractitionerRole | Organization | CareTeam | Patient | Device | RelatedPerson | Reference;
        /**
         * Code specifying the type of source where event originated.
         *
         * The type of source where event originated
         */
        type?: CodeableConcept[];
        static revive(json: any): AuditEventSourceComponent;
        toJSON(): any;
    }
    class AuditEventAgentComponent extends BackboneElement {
        /**
         * Where the agent location is known, the agent location when the event occurred.
         *
         * The agent location when the event occurred
         */
        location?: Location | Reference;
        /**
         * The Functional Role of the user when performing the event.
         *
         * How agent participated
         */
        type?: CodeableConcept;
        /**
         * Indicator that the user is or is not the requestor, or initiator, for the event being audited.
         *
         * Whether user is initiator
         */
        requestor?: boolean;
        /**
         * Reference to who this agent is that was involved in the event.
         *
         * Identifier of who
         */
        who: Practitioner | PractitionerRole | Organization | CareTeam | Patient | Device | RelatedPerson | Reference;
        /**
         * Where the policy(ies) are known that authorized the agent participation in the event. Typically, a single activity may have multiple applicable policies, such as patient consent, guarantor funding, etc. The policy would also indicate the security token used.
         *
         * Policy that authorized the agent participation in the event
         */
        policy?: string[];
        /**
         * When the event utilizes a network there should be an agent describing the local system, and an agent describing remote system, with the network interface details.
         *
         * This agent network location for the activity
         */
        network?: Endpoint | string | Reference;
        /**
         * The authorization (e.g., PurposeOfUse) that was used during the event being recorded.
         *
         * Allowable authorization for this agent
         */
        authorization?: CodeableConcept[];
        /**
         * The structural roles of the agent indicating the agent's competency. The security role enabling the agent with respect to the activity.
         *
         * Agent role in the event
         */
        role?: CodeableConcept[];
        static revive(json: any): AuditEventAgentComponent;
        toJSON(): any;
    }
    class AuditEventOutcomeComponent extends BackboneElement {
        /**
         * Additional details about the error. This may be a text description of the error or a system code that identifies the error.
         *
         * Additional outcome detail
         */
        detail?: CodeableConcept[];
        /**
         * Indicates whether the event succeeded or failed.
         *
         * Whether the event succeeded or failed
         */
        code: Coding;
        static revive(json: any): AuditEventOutcomeComponent;
        toJSON(): any;
    }
}
