import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Money } from '../datatype/money';
import { Period } from '../datatype/period';
import { Coverage } from '../model/coverage';
import { CoverageEligibilityRequest } from '../model/coverage-eligibility-request';
import { DomainResource } from '../model/domain-resource';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
/**
 * HAPI/FHIR <b>CoverageEligibilityResponse</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/CoverageEligibilityResponse">http://hl7.org/fhir/StructureDefinition/CoverageEligibilityResponse</a>
 * </p>
 *
 */
export declare class CoverageEligibilityResponse extends DomainResource {
    /**
     * Errors encountered during the processing of the request.
     *
     * Processing errors
     */
    error?: CoverageEligibilityResponse.ErrorsComponent[];
    /**
     * The provider which is responsible for the request.
     *
     * Party responsible for the request
     */
    requestor?: Practitioner | PractitionerRole | Organization | Reference;
    /**
     * A reference from the Insurer to which these services pertain to be used on further communication and as proof that the request occurred.
     *
     * Preauthorization reference
     */
    preAuthRef?: string;
    /**
     * Code to specify whether requesting: prior authorization requirements for some service categories or billing codes; benefits for coverages specified or discovered; discovery and return of coverages for the patient; and/or validation that the specified coverage is in-force at the date/period specified or 'now' if not specified.
     *
     * auth-requirements | benefits | discovery | validation
     */
    purpose: string[];
    /**
     * The date this resource was created.
     *
     * Response creation date
     */
    created: Date;
    /**
     * Financial instruments for reimbursement for the health care products and services.
     *
     * Patient insurance information
     */
    insurance?: CoverageEligibilityResponse.InsuranceComponent[];
    /**
     * A unique identifier assigned to this coverage eligiblity request.
     *
     * Business Identifier for coverage eligiblity request
     */
    identifier?: Identifier[];
    /**
     * Reference to the original request resource.
     *
     * Eligibility request reference
     */
    request: CoverageEligibilityRequest | Reference;
    /**
     * Information code for an event with a corresponding date or period.
     *
     * Event information
     */
    event?: CoverageEligibilityResponse.CoverageEligibilityResponseEventComponent[];
    /**
     * The outcome of the request processing.
     *
     * queued | complete | error | partial
     */
    outcome: string;
    /**
     * The status of the resource instance.
     *
     * active | cancelled | draft | entered-in-error
     */
    status: string;
    /**
     * The date or dates when the enclosed suite of services were performed or completed.
     *
     * Estimated date or dates of service
     */
    serviced?: Date | Period;
    /**
     * A code for the form to be used for printing the content.
     *
     * Printed form identifier
     */
    form?: CodeableConcept;
    /**
     * The party who is the beneficiary of the supplied coverage and for whom eligibility is sought.
     *
     * Intended recipient of products and services
     */
    patient: Patient | Reference;
    /**
     * The Insurer who issued the coverage in question and is the author of the response.
     *
     * Coverage issuer
     */
    insurer: Organization | Reference;
    /**
     * A human readable description of the status of the adjudication.
     *
     * Disposition Message
     */
    disposition?: string;
    readonly resourceType: string;
    static revive(json: any): CoverageEligibilityResponse;
    toJSON(): any;
}
export declare namespace CoverageEligibilityResponse {
    enum EligibilityResponsePurpose {
        NULL,
        VALIDATION,
        AUTHREQUIREMENTS,
        BENEFITS,
        DISCOVERY
    }
    enum EligibilityOutcome {
        COMPLETE,
        NULL,
        QUEUED,
        PARTIAL,
        ERROR
    }
    enum FinancialResourceStatusCodes {
        CANCELLED,
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        DRAFT
    }
    class ErrorsComponent extends BackboneElement {
        /**
         * An error code,from a specified code system, which details why the eligibility check could not be performed.
         *
         * Error code detailing processing issues
         */
        code: CodeableConcept;
        /**
         * A [simple subset of FHIRPath](fhirpath.html#simple) limited to element names, repetition indicators and the default child accessor that identifies one of the elements in the resource that caused this issue to be raised.
         *
         * FHIRPath of element(s) related to issue
         */
        expression?: string[];
        static revive(json: any): ErrorsComponent;
        toJSON(): any;
    }
    class BenefitComponent extends BackboneElement {
        /**
         * The quantity of the benefit which have been consumed to date.
         *
         * Benefits used
         */
        used?: number | string | Money;
        /**
         * Classification of benefit being provided.
         *
         * Benefit classification
         */
        type: CodeableConcept;
        /**
         * The quantity of the benefit which is permitted under the coverage.
         *
         * Benefits allowed
         */
        allowed?: number | string | Money;
        static revive(json: any): BenefitComponent;
        toJSON(): any;
    }
    class ItemsComponent extends BackboneElement {
        /**
         * A web location for obtaining requirements or descriptive information regarding the preauthorization.
         *
         * Preauthorization requirements endpoint
         */
        authorizationUrl?: string;
        /**
         * The practitioner who is eligible for the provision of the product or service.
         *
         * Performing practitioner
         */
        provider?: Practitioner | PractitionerRole | Reference;
        /**
         * A boolean flag indicating whether a preauthorization is required prior to actual service delivery.
         *
         * Authorization required flag
         */
        authorizationRequired?: boolean;
        /**
         * Indicates if the benefits apply to an individual or to the family.
         *
         * Individual or family
         */
        unit?: CodeableConcept;
        /**
         * True if the indicated class of service is excluded from the plan, missing or False indicates the product or service is included in the coverage.
         *
         * Excluded from the plan
         */
        excluded?: boolean;
        /**
         * Code to identify the general type of benefits under which products and services are provided.
         *
         * Benefit classification
         */
        category?: CodeableConcept;
        /**
         * The term or period of the values such as 'maximum lifetime benefit' or 'maximum annual visits'.
         *
         * Annual or lifetime
         */
        term?: CodeableConcept;
        /**
         * A short name or tag for the benefit.
         *
         * Short name for the benefit
         */
        name?: string;
        /**
         * Item typification or modifiers codes to convey additional context for the product or service.
         *
         * Product or service billing modifiers
         */
        modifier?: CodeableConcept[];
        /**
         * Benefits used to date.
         *
         * Benefit Summary
         */
        benefit?: CoverageEligibilityResponse.BenefitComponent[];
        /**
         * Is a flag to indicate whether the benefits refer to in-network providers or out-of-network providers.
         *
         * In or out of network
         */
        network?: CodeableConcept;
        /**
         * This contains the product, service, drug or other billing code for the item.
         *
         * Billing, service, product, or drug code
         */
        productOrService?: CodeableConcept;
        /**
         * A richer description of the benefit or services covered.
         *
         * Description of the benefit or services covered
         */
        description?: string;
        /**
         * Codes or comments regarding information or actions associated with the preauthorization.
         *
         * Type of required supporting materials
         */
        authorizationSupporting?: CodeableConcept[];
        static revive(json: any): ItemsComponent;
        toJSON(): any;
    }
    class InsuranceComponent extends BackboneElement {
        /**
         * Flag indicating if the coverage provided is inforce currently if no service date(s) specified or for the whole duration of the service dates.
         *
         * Coverage inforce indicator
         */
        inforce?: boolean;
        /**
         * Benefits and optionally current balances, and authorization details by category or service.
         *
         * Benefits and authorization details
         */
        item?: CoverageEligibilityResponse.ItemsComponent[];
        /**
         * Reference to the insurance card level information contained in the Coverage resource. The coverage issuing insurer will use these details to locate the patient's actual coverage within the insurer's information system.
         *
         * Insurance information
         */
        coverage: Coverage | Reference;
        /**
         * The term of the benefits documented in this response.
         *
         * When the benefits are applicable
         */
        benefitPeriod?: Period;
        static revive(json: any): InsuranceComponent;
        toJSON(): any;
    }
    class CoverageEligibilityResponseEventComponent extends BackboneElement {
        /**
         * A coded event such as when a service is expected or a card printed.
         *
         * Specific event
         */
        type: CodeableConcept;
        /**
         * A date or period in the past or future indicating when the event occurred or is expectd to occur.
         *
         * Occurance date or period
         */
        when: Date | Period;
        static revive(json: any): CoverageEligibilityResponseEventComponent;
        toJSON(): any;
    }
}
