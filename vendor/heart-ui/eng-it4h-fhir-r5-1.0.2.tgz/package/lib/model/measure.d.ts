import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Expression } from '../datatype/expression';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { RelatedArtifact } from '../datatype/related-artifact';
import { UsageContext } from '../datatype/usage-context';
import { Group } from '../model/group';
import { MetadataResource } from '../model/metadata-resource';
/**
 * HAPI/FHIR <b>Measure</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Measure">http://hl7.org/fhir/StructureDefinition/Measure</a>
 * </p>
 *
 */
export declare class Measure extends MetadataResource {
    /**
     * The identifier that is used to identify this version of the measure when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the measure author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence. To provide a version consistent with the Decision Support Service specification, use the format Major.Minor.Revision (e.g. 1.0.0). For more information on versioning knowledge assets, refer to the Decision Support Service specification. Note that a version is required for non-experimental active artifacts.
     *
     * Business version of the measure
     */
    version?: string;
    /**
     * Provides a succinct statement of the need for the measure. Usually includes statements pertaining to importance criterion: impact, gap in care, and evidence.
     *
     * Detailed description of why the measure exists
     */
    rationale?: string;
    /**
     * The population basis specifies the type of elements in the population. For a subject-based measure, this is boolean (because the subject and the population basis are the same, and the population criteria define yes/no values for each individual in the population). For measures that have a population basis that is different than the subject, this element specifies the type of the population basis. For example, an encounter-based measure has a subject of Patient and a population basis of Encounter, and the population criteria all return lists of Encounters.
     *
     * Population basis
     */
    basis?: string;
    /**
     * An absolute URI that is used to identify this measure when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this measure is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the measure is stored on different servers.
     *
     * Canonical identifier for this measure, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * The supplemental data criteria for the measure report, specified as either the name of a valid CQL expression within a referenced library, or a valid FHIR Resource Path.
     *
     * What other data should be reported with the measure
     */
    supplementalData?: Measure.MeasureSupplementalDataComponent[];
    /**
     * An individual or organization asserted by the publisher to be primarily responsible for review of some aspect of the content.
     *
     * Who reviewed the content
     */
    reviewer?: ContactDetail[];
    /**
     * The period during which the measure content was or is planned to be in active use.
     *
     * When the measure is expected to be used
     */
    effectivePeriod?: Period;
    /**
     * Describes how to combine the information calculated, based on logic in each of several populations, into one summarized result.
     *
     * How is rate aggregation performed for this measure
     */
    rateAggregation?: string;
    /**
     * If this is a composite measure, the scoring method used to combine the component measures to determine the composite score.
     *
     * opportunity | all-or-nothing | linear | weighted
     */
    compositeScoring?: CodeableConcept;
    /**
     * An individiual or organization primarily involved in the creation and maintenance of the content.
     *
     * Who authored the content
     */
    author?: ContactDetail[];
    /**
     * A formal identifier that is used to identify this measure when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the measure
     */
    identifier?: Identifier[];
    /**
     * An individual or organization primarily responsible for internal coherence of the content.
     *
     * Who edited the content
     */
    editor?: ContactDetail[];
    /**
     * Related artifacts such as additional documentation, justification, or bibliographic references.
     *
     * Additional documentation, citations, etc
     */
    relatedArtifact?: RelatedArtifact[];
    /**
     * Indicates how the calculation is performed for the measure, including proportion, ratio, continuous-variable, and cohort. The value set is extensible, allowing additional measure scoring types to be represented.
     *
     * proportion | ratio | continuous-variable | cohort
     */
    scoring?: CodeableConcept;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate measure instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * The status of this measure. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * Defines the expected units of measure for the measure score. This element SHOULD be specified as a UCUM unit.
     *
     * What units?
     */
    scoringUnit?: CodeableConcept;
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the measure.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * Descriptive topics related to the content of the measure. Topics provide a high-level categorization grouping types of measures that can be useful for filtering and searching.
     *
     * The category of the measure, such as Education, Treatment, Assessment, etc
     */
    topic?: CodeableConcept[];
    /**
     * A natural language name identifying the measure. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this measure (computer friendly)
     */
    name?: string;
    /**
     * Additional guidance for the measure including how it can be used in a clinical context, and the intent of the measure.
     *
     * Additional guidance for implementers (deprecated)
     */
    guidance?: string;
    /**
     * An explanatory or alternate title for the measure giving additional information about its content.
     *
     * Subordinate title of the measure
     */
    subtitle?: string;
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * The date on which the resource content was last reviewed. Review happens periodically after approval but does not change the original approval date.
     *
     * When the measure was last reviewed by the publisher
     */
    lastReviewDate?: Date;
    /**
     * A short, descriptive, user-friendly title for the measure.
     *
     * Name for this measure (human friendly)
     */
    title?: string;
    /**
     * Indicates whether the measure is used to examine a process, an outcome over time, a patient-reported outcome, or a structure measure such as utilization.
     *
     * process | outcome | structure | patient-reported-outcome | composite
     */
    type?: CodeableConcept[];
    /**
     * A free text natural language description of the measure from a consumer's perspective.
     *
     * Natural language description of the measure
     */
    description?: string;
    /**
     * A Boolean value to indicate that this measure is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * Information on whether an increase or decrease in score is the preferred result (e.g., a higher score indicates better quality OR a lower score indicates better quality OR quality is within a range).
     *
     * increase | decrease
     */
    improvementNotation?: CodeableConcept;
    /**
     * Explanation of why this measure is needed and why it has been designed as it has.
     *
     * Why this measure is defined
     */
    purpose?: string;
    /**
     * A legal or geographic region in which the measure is intended to be used.
     *
     * Intended jurisdiction for measure (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * A detailed description, from a clinical perspective, of how the measure is used.
     *
     * Describes the clinical usage of the measure
     */
    usage?: string;
    /**
     * The intended subjects for the measure. If this element is not provided, a Patient subject is assumed, but the subject of the measure can be anything.
     *
     * E.g. Patient, Practitioner, RelatedPerson, Organization, Location, Device
     */
    subject?: CodeableConcept | Group | Reference;
    /**
     * The date  (and optionally time) when the measure was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the measure changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * Provides a summary of relevant clinical guidelines or other clinical recommendations supporting the measure.
     *
     * Summary of clinical guidelines
     */
    clinicalRecommendationStatement?: string;
    /**
     * The date on which the resource content was approved by the publisher. Approval happens once when the content is officially approved for usage.
     *
     * When the measure was approved by publisher
     */
    approvalDate?: Date;
    /**
     * A copyright statement relating to the measure and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the measure.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * A group of population criteria for the measure.
     *
     * Population criteria group
     */
    group?: Measure.MeasureGroupComponent[];
    /**
     * Notices and disclaimers regarding the use of the measure or related to intellectual property (such as code systems) referenced by the measure.
     *
     * Disclaimer for use of the measure or its referenced content
     */
    disclaimer?: string;
    /**
     * An individual or organization asserted by the publisher to be responsible for officially endorsing the content for use in some setting.
     *
     * Who endorsed the content
     */
    endorser?: ContactDetail[];
    /**
     * Provides a description of an individual term used within the measure.
     *
     * Defined terms used in the measure documentation
     */
    term?: Measure.MeasureTermComponent[];
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * A reference to a Library resource containing the formal logic used by the measure.
     *
     * Logic used by the measure
     */
    library?: string[];
    /**
     * A description of the risk adjustment factors that may impact the resulting score for the measure and how they may be accounted for when computing and reporting measure results.
     *
     * How risk adjustment is applied for this measure
     */
    riskAdjustment?: string;
    readonly resourceType: string;
    static revive(json: any): Measure;
    toJSON(): any;
}
export declare namespace Measure {
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    enum FHIRTypes {
        STRUCTUREMAP,
        RELATEDPERSON,
        MARKETINGSTATUS,
        MEDICINALPRODUCTDEFINITION,
        USAGECONTEXT,
        BIOLOGICALLYDERIVEDPRODUCT,
        REQUESTORCHESTRATION,
        SUBSTANCEPOLYMER,
        META,
        DISTANCE,
        MANUFACTUREDITEMDEFINITION,
        METADATARESOURCE,
        LIBRARY,
        UNSIGNEDINT,
        SUPPLYREQUEST,
        VISIONPRESCRIPTION,
        CONDITION,
        DOSAGE,
        IMAGINGSTUDY,
        NARRATIVE,
        CITATION,
        LOCATION,
        COVERAGE,
        NAMINGSYSTEM,
        CONTACTPOINT,
        COMPARTMENTDEFINITION,
        CONDITIONDEFINITION,
        MEDICATIONADMINISTRATION,
        TESTSCRIPT,
        HEALTHCARESERVICE,
        GROUP,
        RESOURCE,
        PROCEDURE,
        PRIMITIVETYPE,
        INSURANCEPLAN,
        MESSAGEDEFINITION,
        DEVICEREQUEST,
        AVAILABILITY,
        CONCEPTMAP,
        CONSENT,
        STRING,
        DURATION,
        DEVICEDEFINITION,
        PAYMENTRECONCILIATION,
        HUMANNAME,
        QUANTITY,
        ARTIFACTASSESSMENT,
        FAMILYMEMBERHISTORY,
        SPECIMEN,
        SIGNATURE,
        ACCOUNT,
        DATAREQUIREMENT,
        INVENTORYITEM,
        NUTRITIONPRODUCT,
        SUBSTANCEPROTEIN,
        ADVERSEEVENT,
        APPOINTMENTRESPONSE,
        EPISODEOFCARE,
        QUESTIONNAIRE,
        INTEGER,
        SERVICEREQUEST,
        CLAIMRESPONSE,
        RELATEDARTIFACT,
        ACTIVITYDEFINITION,
        CARETEAM,
        EVIDENCEVARIABLE,
        INVOICE,
        BOOLEAN,
        ACTORDEFINITION,
        BACKBONETYPE,
        DATATYPE,
        CAPABILITYSTATEMENT,
        INSTANT,
        CODESYSTEM,
        CHARGEITEM,
        LIST,
        MEDICATION,
        ATTACHMENT,
        MONEY,
        BINARY,
        RESEARCHSTUDY,
        SEARCHPARAMETER,
        BASE,
        ORGANIZATIONAFFILIATION,
        IMMUNIZATION,
        GENOMICSTUDY,
        ADMINISTRABLEPRODUCTDEFINITION,
        EVENTDEFINITION,
        IDENTIFIER,
        REGULATEDAUTHORIZATION,
        MESSAGEHEADER,
        AGE,
        IMPLEMENTATIONGUIDE,
        TESTPLAN,
        MEDICATIONREQUEST,
        PAYMENTNOTICE,
        CONTACTDETAIL,
        TIME,
        EXAMPLESCENARIO,
        OBSERVATIONDEFINITION,
        ELEMENTDEFINITION,
        DATETIME,
        MONETARYCOMPONENT,
        XHTML,
        PROVENANCE,
        SUBSTANCE,
        MEASUREREPORT,
        REQUIREMENTS,
        BIOLOGICALLYDERIVEDPRODUCTDISPENSE,
        ENCOUNTERHISTORY,
        MOLECULARSEQUENCE,
        MEDICATIONSTATEMENT,
        ANNOTATION,
        APPOINTMENT,
        ID,
        PERSON,
        DOMAINRESOURCE,
        INTEGER64,
        EVIDENCE,
        TERMINOLOGYCAPABILITIES,
        SAMPLEDDATA,
        PRACTITIONERROLE,
        GOAL,
        VIRTUALSERVICEDETAIL,
        TIMING,
        SUBSTANCEDEFINITION,
        COUNT,
        BASE64BINARY,
        VERIFICATIONRESULT,
        BACKBONEELEMENT,
        IMMUNIZATIONEVALUATION,
        STRUCTUREDEFINITION,
        PRACTITIONER,
        DOCUMENTREFERENCE,
        RATIO,
        FLAG,
        URI,
        INGREDIENT,
        PLANDEFINITION,
        URL,
        QUESTIONNAIRERESPONSE,
        ORGANIZATION,
        NUTRITIONORDER,
        ALLERGYINTOLERANCE,
        PRODUCTSHELFLIFE,
        FORMULARYITEM,
        SUPPLYDELIVERY,
        COMMUNICATIONREQUEST,
        CANONICALRESOURCE,
        BODYSTRUCTURE,
        SUBSCRIPTION,
        ELEMENT,
        GRAPHDEFINITION,
        MEDICATIONKNOWLEDGE,
        CODEABLEREFERENCE,
        DEVICEUSAGE,
        NUTRITIONINTAKE,
        PATIENT,
        SUBSCRIPTIONSTATUS,
        EXPRESSION,
        COVERAGEELIGIBILITYRESPONSE,
        MEASURE,
        PARAMETERDEFINITION,
        DECIMAL,
        EXTENSION,
        INVENTORYREPORT,
        OBSERVATION,
        SPECIMENDEFINITION,
        SCHEDULE,
        UUID,
        TRIGGERDEFINITION,
        TASK,
        CANONICAL,
        OPERATIONDEFINITION,
        NULL,
        RESEARCHSUBJECT,
        CODING,
        SUBSTANCEREFERENCEINFORMATION,
        DEVICE,
        CODEABLECONCEPT,
        OID,
        PARAMETERS,
        DATE,
        TESTREPORT,
        MARKDOWN,
        PACKAGEDPRODUCTDEFINITION,
        SUBSTANCESOURCEMATERIAL,
        GUIDANCERESPONSE,
        ADDRESS,
        PERIOD,
        POSITIVEINT,
        COMMUNICATION,
        RANGE,
        AUDITEVENT,
        CLINICALUSEDEFINITION,
        ENROLLMENTRESPONSE,
        PERMISSION,
        CONTRACT,
        VALUESET,
        BASIC,
        CLAIM,
        SUBSTANCENUCLEICACID,
        TRANSPORT,
        REFERENCE,
        COMPOSITION,
        SLOT,
        DEVICEDISPENSE,
        MEDICATIONDISPENSE,
        DIAGNOSTICREPORT,
        DEVICEMETRIC,
        EXPLANATIONOFBENEFIT,
        CONTRIBUTOR,
        DETECTEDISSUE,
        ENCOUNTER,
        EXTENDEDCONTACTDETAIL,
        DEVICEASSOCIATION,
        ENROLLMENTREQUEST,
        RISKASSESSMENT,
        IMMUNIZATIONRECOMMENDATION,
        CLINICALIMPRESSION,
        BUNDLE,
        CODE,
        RATIORANGE,
        CHARGEITEMDEFINITION,
        IMAGINGSELECTION,
        OPERATIONOUTCOME,
        ENDPOINT,
        CAREPLAN,
        COVERAGEELIGIBILITYREQUEST,
        LINKAGE,
        SUBSCRIPTIONTOPIC,
        EVIDENCEREPORT
    }
    class MeasureSupplementalDataComponent extends BackboneElement {
        /**
         * The human readable description of this supplemental data.
         *
         * The human readable description of this supplemental data
         */
        description?: string;
        /**
         * An identifier that is unique within the Measure allowing linkage to the equivalent item in a MeasureReport resource.
         *
         * Unique id for supplementalData in measure
         */
        linkId?: string;
        /**
         * Indicates a meaning for the supplemental data. This can be as simple as a unique identifier, or it can establish meaning in a broader context by drawing from a terminology, allowing supplemental data to be correlated across measures.
         *
         * Meaning of the supplemental data
         */
        code?: CodeableConcept;
        /**
         * The criteria for the supplemental data. This is typically the name of a valid expression defined within a referenced library, but it may also be a path to a specific data element. The criteria defines the data to be returned for this element.
         *
         * Expression describing additional data to be reported
         */
        criteria: Expression;
        /**
         * An indicator of the intended usage for the supplemental data element. Supplemental data indicates the data is additional information requested to augment the measure information. Risk adjustment factor indicates the data is additional information used to calculate risk adjustment factors when applying a risk model to the measure calculation.
         *
         * supplemental-data | risk-adjustment-factor
         */
        usage?: CodeableConcept[];
        static revive(json: any): MeasureSupplementalDataComponent;
        toJSON(): any;
    }
    class MeasureGroupStratifierComponentComponent extends BackboneElement {
        /**
         * An identifier that is unique within the Measure allowing linkage to the equivalent item in a MeasureReport resource.
         *
         * Unique id for stratifier component in measure
         */
        linkId?: string;
        /**
         * Indicates a meaning for the stratifier component. This can be as simple as a unique identifier, or it can establish meaning in a broader context by drawing from a terminology, allowing stratifiers to be correlated across measures.
         *
         * Meaning of the stratifier component
         */
        code?: CodeableConcept;
        /**
         * A Group resource that defines this population as a set of characteristics.
         *
         * A group resource that defines this population
         */
        groupDefinition?: Group | Reference;
        /**
         * An expression that specifies the criteria for this component of the stratifier. This is typically the name of an expression defined within a referenced library, but it may also be a path to a stratifier element.
         *
         * Component of how the measure should be stratified
         */
        criteria?: Expression;
        /**
         * The human readable description of this stratifier criteria component.
         *
         * The human readable description of this stratifier component
         */
        description?: string;
        static revive(json: any): MeasureGroupStratifierComponentComponent;
        toJSON(): any;
    }
    class MeasureGroupStratifierComponent extends BackboneElement {
        /**
         * The human readable description of this stratifier criteria.
         *
         * The human readable description of this stratifier
         */
        description?: string;
        /**
         * An identifier that is unique within the Measure allowing linkage to the equivalent item in a MeasureReport resource.
         *
         * Unique id for stratifier in measure
         */
        linkId?: string;
        /**
         * Indicates a meaning for the stratifier. This can be as simple as a unique identifier, or it can establish meaning in a broader context by drawing from a terminology, allowing stratifiers to be correlated across measures.
         *
         * Meaning of the stratifier
         */
        code?: CodeableConcept;
        /**
         * A component of the stratifier criteria for the measure report, specified as either the name of a valid CQL expression defined within a referenced library or a valid FHIR Resource Path.
         *
         * Stratifier criteria component for the measure
         */
        component?: Measure.MeasureGroupStratifierComponentComponent[];
        /**
         * A Group resource that defines this population as a set of characteristics.
         *
         * A group resource that defines this population
         */
        groupDefinition?: Group | Reference;
        /**
         * An expression that specifies the criteria for the stratifier. This is typically the name of an expression defined within a referenced library, but it may also be a path to a stratifier element.
         *
         * How the measure should be stratified
         */
        criteria?: Expression;
        static revive(json: any): MeasureGroupStratifierComponent;
        toJSON(): any;
    }
    class MeasureGroupPopulationComponent extends BackboneElement {
        /**
         * The human readable description of this population criteria.
         *
         * The human readable description of this population criteria
         */
        description?: string;
        /**
         * An expression that specifies the criteria for the population, typically the name of an expression in a library.
         *
         * The criteria that defines this population
         */
        criteria?: Expression;
        /**
         * A Group resource that defines this population as a set of characteristics.
         *
         * A group resource that defines this population
         */
        groupDefinition?: Group | Reference;
        /**
         * An identifier that is unique within the Measure allowing linkage to the equivalent population in a MeasureReport resource.
         *
         * Unique id for population in measure
         */
        linkId?: string;
        /**
         * The type of population criteria.
         *
         * initial-population | numerator | numerator-exclusion | denominator | denominator-exclusion | denominator-exception | measure-population | measure-population-exclusion | measure-observation
         */
        code?: CodeableConcept;
        /**
         * The id of a population element in this measure that provides the input for this population criteria. In most cases, the scoring structure of the measure implies specific relationships (e.g. the Numerator uses the Denominator as the source in a proportion scoring). In some cases, however, multiple possible choices exist and must be resolved explicitly. For example in a ratio measure with multiple initial populations, the denominator must specify which population should be used as the starting point.
         *
         * Which population
         */
        inputPopulationId?: string;
        /**
         * Specifies which method should be used to aggregate measure observation values. For most scoring types, this is implied by scoring (e.g. a proportion measure counts members of the populations). For continuous variables, however, this information must be specified to ensure correct calculation.
         *
         * Aggregation method for a measure score (e.g. sum, average, median, minimum, maximum, count)
         */
        aggregateMethod?: CodeableConcept;
        static revive(json: any): MeasureGroupPopulationComponent;
        toJSON(): any;
    }
    class MeasureGroupComponent extends BackboneElement {
        /**
         * Defines the expected units of measure for the measure score. This element SHOULD be specified as a UCUM unit.
         *
         * What units?
         */
        scoringUnit?: CodeableConcept;
        /**
         * The stratifier criteria for the measure report, specified as either the name of a valid CQL expression defined within a referenced library or a valid FHIR Resource Path.
         *
         * Stratifier criteria for the measure
         */
        stratifier?: Measure.MeasureGroupStratifierComponent[];
        /**
         * An identifier that is unique within the Measure allowing linkage to the equivalent item in a MeasureReport resource.
         *
         * Unique id for group in measure
         */
        linkId?: string;
        /**
         * A reference to a Library resource containing the formal logic used by the measure group.
         *
         * Logic used by the measure group
         */
        library?: string[];
        /**
         * A population criteria for the measure.
         *
         * Population criteria
         */
        population?: Measure.MeasureGroupPopulationComponent[];
        /**
         * Indicates whether the measure is used to examine a process, an outcome over time, a patient-reported outcome, or a structure measure such as utilization.
         *
         * process | outcome | structure | patient-reported-outcome | composite
         */
        type?: CodeableConcept[];
        /**
         * The population basis specifies the type of elements in the population. For a subject-based measure, this is boolean (because the subject and the population basis are the same, and the population criteria define yes/no values for each individual in the population). For measures that have a population basis that is different than the subject, this element specifies the type of the population basis. For example, an encounter-based measure has a subject of Patient and a population basis of Encounter, and the population criteria all return lists of Encounters.
         *
         * Population basis
         */
        basis?: string;
        /**
         * Information on whether an increase or decrease in score is the preferred result (e.g., a higher score indicates better quality OR a lower score indicates better quality OR quality is within a range).
         *
         * increase | decrease
         */
        improvementNotation?: CodeableConcept;
        /**
         * The human readable description of this population group.
         *
         * Summary description
         */
        description?: string;
        /**
         * The intended subjects for the measure. If this element is not provided, a Patient subject is assumed, but the subject of the measure can be anything.
         *
         * E.g. Patient, Practitioner, RelatedPerson, Organization, Location, Device
         */
        subject?: CodeableConcept | Group | Reference;
        /**
         * Describes how to combine the information calculated, based on logic in each of several populations, into one summarized result.
         *
         * How is rate aggregation performed for this measure
         */
        rateAggregation?: string;
        /**
         * Indicates a meaning for the group. This can be as simple as a unique identifier, or it can establish meaning in a broader context by drawing from a terminology, allowing groups to be correlated across measures.
         *
         * Meaning of the group
         */
        code?: CodeableConcept;
        /**
         * Indicates how the calculation is performed for the measure, including proportion, ratio, continuous-variable, and cohort. The value set is extensible, allowing additional measure scoring types to be represented.
         *
         * proportion | ratio | continuous-variable | cohort
         */
        scoring?: CodeableConcept;
        static revive(json: any): MeasureGroupComponent;
        toJSON(): any;
    }
    class MeasureTermComponent extends BackboneElement {
        /**
         * Provides a definition for the term as used within the measure.
         *
         * Meaning of the term
         */
        definition?: string;
        /**
         * A codeable representation of the defined term.
         *
         * What term?
         */
        code?: CodeableConcept;
        static revive(json: any): MeasureTermComponent;
        toJSON(): any;
    }
}
