import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { MonetaryComponent } from '../datatype/monetary-component';
import { Money } from '../datatype/money';
import { Period } from '../datatype/period';
import { Account } from '../model/account';
import { ChargeItem } from '../model/charge-item';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Group } from '../model/group';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Invoice</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Invoice">http://hl7.org/fhir/StructureDefinition/Invoice</a>
 * </p>
 *
 */
export declare class Invoice extends DomainResource {
    /**
     * Each line item represents one charge for goods and services rendered. Details such.ofType(date), code and amount are found in the referenced ChargeItem resource.
     *
     * Line items of this Invoice
     */
    lineItem?: Invoice.InvoiceLineItemComponent[];
    /**
     * The individual or Organization responsible for balancing of this invoice.
     *
     * Recipient of this invoice
     */
    recipient?: Organization | Patient | RelatedPerson | Reference;
    /**
     * In case of Invoice cancellation a reason must be given (entered in error, superseded by corrected invoice etc.).
     *
     * Reason for cancellation of this Invoice
     */
    cancelledReason?: string;
    /**
     * The current state of the Invoice.
     *
     * draft | issued | balanced | cancelled | entered-in-error
     */
    status: string;
    /**
     * Date/time(s) of when this Invoice was posted.
     *
     * When posted
     */
    creation?: Date;
    /**
     * Account which is supposed to be balanced with this Invoice.
     *
     * Account that is being balanced
     */
    account?: Account | Reference;
    /**
     * Payment details such as banking details, period of payment, deductibles, methods of payment.
     *
     * Payment details
     */
    paymentTerms?: string;
    /**
     * Identifier of this Invoice, often used for reference in correspondence about this invoice or for tracking of payments.
     *
     * Business Identifier for item
     */
    identifier?: Identifier[];
    /**
     * Invoice total, tax included.
     *
     * Gross total of this Invoice
     */
    totalGross?: Money;
    /**
     * Comments made about the invoice by the issuer, subject, or other participants.
     *
     * Comments made about the invoice
     */
    note?: Annotation[];
    /**
     * Depricared by the element below.
     *
     * DEPRICATED
     */
    date?: Date;
    /**
     * Date/time(s) range of services included in this invoice.
     *
     * Billing date or period
     */
    period?: Date | Period;
    /**
     * The individual or set of individuals receiving the goods and services billed in this invoice.
     *
     * Recipient(s) of goods and services
     */
    subject?: Patient | Group | Reference;
    /**
     * Type of Invoice depending on domain, realm an usage (e.g. internal/external, dental, preliminary).
     *
     * Type of Invoice
     */
    type?: CodeableConcept;
    /**
     * The total amount for the Invoice may be calculated as the sum of the line items with surcharges/deductions that apply in certain conditions.  The priceComponent element can be used to offer transparency to the recipient of the Invoice of how the total price was calculated.
     *
     * Components of Invoice total
     */
    totalPriceComponent?: MonetaryComponent[];
    /**
     * Indicates who or what performed or participated in the charged service.
     *
     * Participant in creation of this Invoice
     */
    participant?: Invoice.InvoiceParticipantComponent[];
    /**
     * The organizationissuing the Invoice.
     *
     * Issuing Organization of Invoice
     */
    issuer?: Organization | Reference;
    /**
     * Invoice total , taxes excluded.
     *
     * Net total of this Invoice
     */
    totalNet?: Money;
    readonly resourceType: string;
    static revive(json: any): Invoice;
    toJSON(): any;
}
export declare namespace Invoice {
    enum InvoiceStatus {
        ISSUED,
        CANCELLED,
        ENTEREDINERROR,
        BALANCED,
        NULL,
        DRAFT
    }
    class InvoiceLineItemComponent extends BackboneElement {
        /**
         * Date/time(s) range when this service was delivered or completed.
         *
         * Service data or period
         */
        serviced?: Date | Period;
        /**
         * The price for a ChargeItem may be calculated as a base price with surcharges/deductions that apply in certain conditions. A ChargeItemDefinition resource that defines the prices, factors and conditions that apply to a billing code is currently under development. The priceComponent element can be used to offer transparency to the recipient of the Invoice as to how the prices have been calculated.
         *
         * Components of total line item price
         */
        priceComponent?: MonetaryComponent[];
        /**
         * Sequence in which the items appear on the invoice.
         *
         * Sequence number of line item
         */
        sequence?: number;
        /**
         * The ChargeItem contains information such as the billing code, date, amount etc. If no further details are required for the lineItem, inline billing codes can be added using the CodeableConcept data type instead of the Reference.
         *
         * Reference to ChargeItem containing details of this line item or an inline billing code
         */
        chargeItem: ChargeItem | CodeableConcept | Reference;
        static revive(json: any): InvoiceLineItemComponent;
        toJSON(): any;
    }
    class InvoiceParticipantComponent extends BackboneElement {
        /**
         * The device, practitioner, etc. who performed or participated in the service.
         *
         * Individual who was involved
         */
        actor: Practitioner | Organization | Patient | PractitionerRole | Device | RelatedPerson | Reference;
        /**
         * Describes the type of involvement (e.g. transcriptionist, creator etc.). If the invoice has been created automatically, the Participant may be a billing engine or another kind of device.
         *
         * Type of involvement in creation of this Invoice
         */
        role?: CodeableConcept;
        static revive(json: any): InvoiceParticipantComponent;
        toJSON(): any;
    }
}
