import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { Ratio } from '../datatype/ratio';
import { DomainResource } from '../model/domain-resource';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { ServiceRequest } from '../model/service-request';
/**
 * HAPI/FHIR <b>BiologicallyDerivedProduct</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/BiologicallyDerivedProduct">http://hl7.org/fhir/StructureDefinition/BiologicallyDerivedProduct</a>
 * </p>
 *
 */
export declare class BiologicallyDerivedProduct extends DomainResource {
    /**
     * A property that is specific to this BiologicallyDerviedProduct instance.
     *
     * A property that is specific to this BiologicallyDerviedProduct instance
     */
    property?: BiologicallyDerivedProduct.BiologicallyDerivedProductPropertyComponent[];
    /**
     * Date, and where relevant time, of expiration.
     *
     * Date, and where relevant time, of expiration
     */
    expirationDate?: Date;
    /**
     * A unique identifier for an aliquot of a product.  Used to distinguish individual aliquots of a product carrying the same biologicalSource and productCode identifiers.
     *
     * A unique identifier for an aliquot of a product
     */
    division?: string;
    /**
     * A codified value that systematically supports characterization and classification of medical products of human origin inclusive of processing conditions such as additives, volumes and handling conditions.
     *
     * A code that identifies the kind of this biologically derived product
     */
    productCode?: CodeableConcept;
    /**
     * Whether the product is currently available.
     *
     * available | unavailable
     */
    productStatus?: Coding;
    /**
     * The temperature requirements for storage of the biologically-derived product.
     *
     * Product storage temperature requirements
     */
    storageTempRequirements?: Range;
    /**
     * How this product was collected.
     *
     * How this product was collected
     */
    collection?: BiologicallyDerivedProduct.BiologicallyDerivedProductCollectionComponent;
    /**
     * Broad category of this product.
     *
     * organ | tissue | fluid | cells | biologicalAgent
     */
    productCategory?: Coding;
    /**
     * Processing facilities responsible for the labeling and distribution of this biologically derived product.
     *
     * Processing facilities responsible for the labeling and distribution of this biologically derived product
     */
    processingFacility?: Organization[] | Reference[];
    /**
     * Parent product (if any) for this biologically-derived product.
     *
     * The parent biologically-derived product
     */
    parent?: BiologicallyDerivedProduct[] | Reference[];
    /**
     * Request to obtain and/or infuse this biologically derived product.
     *
     * Request to obtain and/or infuse this product
     */
    request?: ServiceRequest[] | Reference[];
    /**
     * Unique instance identifiers assigned to a biologically derived product. Note: This is a business identifier, not a resource identifier.
     *
     * Instance identifier
     */
    identifier?: Identifier[];
    /**
     * An identifier that supports traceability to the event during which material in this product from one or more biological entities was obtained or pooled.
     *
     * An identifier that supports traceability to the event during which material in this product from one or more biological entities was obtained or pooled
     */
    biologicalSourceEvent?: Identifier;
    readonly resourceType: string;
    static revive(json: any): BiologicallyDerivedProduct;
    toJSON(): any;
}
export declare namespace BiologicallyDerivedProduct {
    class BiologicallyDerivedProductPropertyComponent extends BackboneElement {
        /**
         * Code that specifies the property. It should reference an established coding system.
         *
         * Code that specifies the property
         */
        type: CodeableConcept;
        /**
         * Property values.
         *
         * Property values
         */
        value: boolean | number | CodeableConcept | Period | Quantity | Range | Ratio | string | Attachment;
        static revive(json: any): BiologicallyDerivedProductPropertyComponent;
        toJSON(): any;
    }
    class BiologicallyDerivedProductCollectionComponent extends BackboneElement {
        /**
         * The patient or entity, such as a hospital or vendor in the case of a processed/manipulated/manufactured product, providing the product.
         *
         * The patient who underwent the medical procedure to collect the product or the organization that facilitated the collection
         */
        source?: Patient | Organization | Reference;
        /**
         * Time of product collection.
         *
         * Time of product collection
         */
        collected?: Date | Period;
        /**
         * Healthcare professional who is performing the collection.
         *
         * Individual performing collection
         */
        collector?: Practitioner | PractitionerRole | Reference;
        static revive(json: any): BiologicallyDerivedProductCollectionComponent;
        toJSON(): any;
    }
}
