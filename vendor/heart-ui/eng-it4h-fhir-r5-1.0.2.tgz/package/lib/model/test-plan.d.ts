import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { UsageContext } from '../datatype/usage-context';
import { CanonicalResource } from '../model/canonical-resource';
/**
 * HAPI/FHIR <b>TestPlan</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/TestPlan">http://hl7.org/fhir/StructureDefinition/TestPlan</a>
 * </p>
 *
 */
export declare class TestPlan extends CanonicalResource {
    /**
     * The status of this test plan. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The individual test cases that are part of this plan, when they they are made explicit.
     *
     * The test cases that constitute this plan
     */
    testCase?: TestPlan.TestPlanTestCaseComponent[];
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate test plan instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * The category of the Test Plan - can be acceptance, unit, performance, etc.
     *
     * The category of the Test Plan - can be acceptance, unit, performance
     */
    category?: CodeableConcept[];
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the test plan.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * A natural language name identifying the test plan. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this test plan (computer friendly)
     */
    name?: string;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * What is being tested with this Test Plan - a conformance resource, or narrative criteria, or an external reference...
     *
     * What is being tested with this Test Plan - a conformance resource, or narrative criteria, or an external reference
     */
    scope?: Reference[];
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * An absolute URI that is used to identify this test plan when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this test plan is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the test plan is stored on different servers.
     *
     * Canonical identifier for this test plan, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * The identifier that is used to identify this version of the test plan when it is referenced in a specification, model, design or instance.  This is an arbitrary value managed by the test plan author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the test plan
     */
    version?: string;
    /**
     * A short, descriptive, user-friendly title for the test plan.
     *
     * Name for this test plan (human friendly)
     */
    title?: string;
    /**
     * A Boolean value to indicate that this test plan is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A free text natural language description of the test plan from a consumer's perspective.
     *
     * Natural language description of the test plan
     */
    description?: string;
    /**
     * A legal or geographic region in which the test plan is intended to be used.
     *
     * Intended jurisdiction where the test plan applies (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * Explanation of why this test plan is needed and why it has been designed as it has.
     *
     * Why this test plan is defined
     */
    purpose?: string;
    /**
     * The required criteria to execute the test plan - e.g. preconditions, previous tests...
     *
     * The required criteria to execute the test plan - e.g. preconditions, previous tests
     */
    dependency?: TestPlan.TestPlanDependencyComponent[];
    /**
     * A copyright statement relating to the test plan and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the test plan. The short copyright declaration (e.g. (c) '2015+ xyz organization' should be sent in the copyrightLabel element.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * A description of test tools to be used in the test plan.
     *
     * A description of test tools to be used in the test plan - narrative for now
     */
    testTools?: string;
    /**
     * The threshold or criteria for the test plan to be considered successfully executed - narrative.
     *
     * The threshold or criteria for the test plan to be considered successfully executed - narrative
     */
    exitCriteria?: string;
    /**
     * A formal identifier that is used to identify this test plan when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Business identifier identifier for the test plan
     */
    identifier?: Identifier[];
    /**
     * The date (and optionally time) when the test plan was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the test plan changes.
     *
     * Date last changed
     */
    date?: Date;
    readonly resourceType: string;
    static revive(json: any): TestPlan;
    toJSON(): any;
}
export declare namespace TestPlan {
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class TestPlanTestCaseAssertionComponent extends BackboneElement {
        /**
         * The focus or object of the assertion i.e. a resource.
         *
         * The focus or object of the assertion
         */
        object?: CodeableReference[];
        /**
         * The test assertion type - this can be used to group assertions as 'required' or 'optional', or can be used for other classification of the assertion.
         *
         * Assertion type - for example 'informative' or 'required'
         */
        type?: CodeableConcept[];
        /**
         * The test assertion - the expected outcome from the test case execution.
         *
         * The actual result assertion
         */
        result?: CodeableReference[];
        static revive(json: any): TestPlanTestCaseAssertionComponent;
        toJSON(): any;
    }
    class TestPlanTestCaseTestDataComponent extends BackboneElement {
        /**
         * Pointer to a definition of test resources - narrative or structured e.g. synthetic data generation, etc.
         *
         * Pointer to a definition of test resources - narrative or structured e.g. synthetic data generation, etc
         */
        source?: string | Reference;
        /**
         * The actual test resources when they exist.
         *
         * The actual test resources when they exist
         */
        content?: Reference;
        /**
         * The type of test data description, e.g. 'synthea'.
         *
         * The type of test data description, e.g. 'synthea'
         */
        type: Coding;
        static revive(json: any): TestPlanTestCaseTestDataComponent;
        toJSON(): any;
    }
    class TestPlanTestCaseTestRunScriptComponent extends BackboneElement {
        /**
         * The actual content of the cases - references to TestScripts or externally defined content.
         *
         * The actual content of the cases - references to TestScripts or externally defined content
         */
        source?: string | Reference;
        /**
         * The language for the test cases e.g. 'gherkin', 'testscript'.
         *
         * The language for the test cases e.g. 'gherkin', 'testscript'
         */
        language?: CodeableConcept;
        static revive(json: any): TestPlanTestCaseTestRunScriptComponent;
        toJSON(): any;
    }
    class TestPlanTestCaseTestRunComponent extends BackboneElement {
        /**
         * The narrative description of the tests.
         *
         * The narrative description of the tests
         */
        narrative?: string;
        /**
         * The test cases in a structured language e.g. gherkin, Postman, or FHIR TestScript.
         *
         * The test cases in a structured language e.g. gherkin, Postman, or FHIR TestScript
         */
        script?: TestPlan.TestPlanTestCaseTestRunScriptComponent;
        static revive(json: any): TestPlanTestCaseTestRunComponent;
        toJSON(): any;
    }
    class TestCaseDependencyComponent extends BackboneElement {
        /**
         * Description of the criteria.
         *
         * Description of the criteria
         */
        description?: string;
        /**
         * Link to predecessor test plans.
         *
         * Link to predecessor test plans
         */
        predecessor?: Reference;
        static revive(json: any): TestCaseDependencyComponent;
        toJSON(): any;
    }
    class TestPlanTestCaseComponent extends BackboneElement {
        /**
         * The actual test to be executed.
         *
         * The actual test to be executed
         */
        testRun?: TestPlan.TestPlanTestCaseTestRunComponent[];
        /**
         * The test assertions - the expectations of test results from the execution of the test case.
         *
         * Test assertions or expectations
         */
        assertion?: TestPlan.TestPlanTestCaseAssertionComponent[];
        /**
         * The required criteria to execute the test case - e.g. preconditions, previous tests.
         *
         * Required criteria to execute the test case
         */
        dependency?: TestPlan.TestCaseDependencyComponent[];
        /**
         * The scope or artifact covered by the case, when the individual test case is associated with a testable artifact.
         *
         * The scope or artifact covered by the case
         */
        scope?: Reference[];
        /**
         * Sequence of test case - an ordinal number that indicates the order for the present test case in the test plan.
         *
         * Sequence of test case in the test plan
         */
        sequence?: number;
        /**
         * The test data used in the test case.
         *
         * The test data used in the test case
         */
        testData?: TestPlan.TestPlanTestCaseTestDataComponent[];
        static revive(json: any): TestPlanTestCaseComponent;
        toJSON(): any;
    }
    class TestPlanDependencyComponent extends BackboneElement {
        /**
         * Predecessor test plans - those that are expected to be successfully performed as a dependency for the execution of this test plan.
         *
         * Link to predecessor test plans
         */
        predecessor?: Reference;
        /**
         * A textual description of the criterium - what is needed for the dependency to be considered met.
         *
         * Description of the dependency criterium
         */
        description?: string;
        static revive(json: any): TestPlanDependencyComponent;
        toJSON(): any;
    }
}
