import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { Ratio } from '../datatype/ratio';
import { Timing } from '../datatype/timing';
import { BodyStructure } from '../model/body-structure';
import { CarePlan } from '../model/care-plan';
import { CareTeam } from '../model/care-team';
import { ClaimResponse } from '../model/claim-response';
import { Coverage } from '../model/coverage';
import { Device } from '../model/device';
import { DocumentReference } from '../model/document-reference';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { Location } from '../model/location';
import { MedicationRequest } from '../model/medication-request';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Provenance } from '../model/provenance';
import { RelatedPerson } from '../model/related-person';
import { Specimen } from '../model/specimen';
/**
 * HAPI/FHIR <b>ServiceRequest</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ServiceRequest">http://hl7.org/fhir/StructureDefinition/ServiceRequest</a>
 * </p>
 *
 */
export declare class ServiceRequest extends DomainResource {
    /**
     * Anatomic location where the procedure should be performed. This is the target site.
     *
     * Coded location on Body
     */
    bodySite?: CodeableConcept[];
    /**
     * A code that classifies the service for searching, sorting and display purposes (e.g. "Surgical Procedure").
     *
     * Classification of service
     */
    category?: CodeableConcept[];
    /**
     * The status of the order.
     *
     * draft | active | on-hold | revoked | completed | entered-in-error | unknown
     */
    status: string;
    /**
     * Instructions in terms that are understood by the patient or consumer.
     *
     * Patient or consumer-oriented instructions
     */
    patientInstruction?: ServiceRequest.ServiceRequestPatientInstructionComponent[];
    /**
     * Additional details and instructions about the how the services are to be delivered.   For example, and order for a urinary catheter may have an order detail for an external or indwelling catheter, or an order for a bandage may require additional instructions specifying how the bandage should be applied.
     *
     * Additional order information
     */
    orderDetail?: ServiceRequest.ServiceRequestOrderDetailComponent[];
    /**
     * The preferred location(s) where the procedure should actually happen in coded or free text form. E.g. at home or nursing day care center.
     *
     * Requested location
     */
    location?: CodeableReference[];
    /**
     * Anatomic location where the procedure should be performed. This is the target site.
     *
     * BodyStructure-based location on the body
     */
    bodyStructure?: BodyStructure | Reference;
    /**
     * The request takes the place of the referenced completed or terminated request(s).
     *
     * What request replaces
     */
    replaces?: ServiceRequest[] | Reference[];
    /**
     * The individual who initiated the request and has responsibility for its activation.
     *
     * Who/what is requesting service
     */
    requester?: Practitioner | PractitionerRole | Organization | Patient | RelatedPerson | Device | Reference;
    /**
     * Identifiers assigned to this order instance by the orderer and/or the receiver and/or order fulfiller.
     *
     * Identifiers assigned to this order
     */
    identifier?: Identifier[];
    /**
     * An amount of service being requested which can be a quantity ( for example $1,500 home modification), a ratio ( for example, 20 half day visits per month), or a range (2.0 to 1.8 Gy per fraction).
     *
     * Service amount
     */
    quantity?: Quantity | Ratio | Range;
    /**
     * When the request transitioned to being actionable.
     *
     * Date request signed
     */
    authoredOn?: Date;
    /**
     * The desired performer for doing the requested service.  For example, the surgeon, dermatopathologist, endoscopist, etc.
     *
     * Requested performer
     */
    performer?: Practitioner[] | PractitionerRole[] | Organization[] | CareTeam[] | HealthcareService[] | Patient[] | Device[] | RelatedPerson[] | Reference[];
    /**
     * The URL pointing to a FHIR-defined protocol, guideline, orderset or other definition that is adhered to in whole or in part by this ServiceRequest.
     *
     * Instantiates FHIR protocol or definition
     */
    instantiatesCanonical?: string[];
    /**
     * Indicates how quickly the ServiceRequest should be addressed with respect to other requests.
     *
     * routine | urgent | asap | stat
     */
    priority?: string;
    /**
     * Whether the request is a proposal, plan, an original order or a reflex order.
     *
     * proposal | plan | directive | order +
     */
    intent: string;
    /**
     * Desired type of performer for doing the requested service.
     *
     * Performer role
     */
    performerType?: CodeableConcept;
    /**
     * An encounter that provides additional information about the healthcare context in which this request is made.
     *
     * Encounter in which the request was created
     */
    encounter?: Encounter | Reference;
    /**
     * Additional clinical information about the patient or specimen that may influence the services or their interpretations.     This information includes diagnosis, clinical findings and other observations.  In laboratory ordering these are typically referred to as "ask at order entry questions (AOEs)".  This includes observations explicitly requested by the producer (filler) to provide context or supporting information needed to complete the order. For example,  reporting the amount of inspired oxygen for blood gas measurements.
     *
     * Additional clinical information
     */
    supportingInfo?: CodeableReference[];
    /**
     * One or more specimens that the laboratory procedure will use.
     *
     * Procedure Samples
     */
    specimen?: Specimen[] | Reference[];
    /**
     * If a CodeableConcept is present, it indicates the pre-condition for performing the service.  For example "pain", "on flare-up", etc.
     *
     * Preconditions for service
     */
    asNeeded?: boolean | CodeableConcept;
    /**
     * Set this to true if the record is saying that the service/procedure should NOT be performed.
     *
     * True if service/procedure should not be performed
     */
    doNotPerform?: boolean;
    /**
     * Plan/proposal/order fulfilled by this request.
     *
     * What request fulfills
     */
    basedOn?: CarePlan[] | ServiceRequest[] | MedicationRequest[] | Reference[];
    /**
     * A shared identifier common to all service requests that were authorized more or less simultaneously by a single author, representing the composite or group identifier.
     *
     * Composite Request ID
     */
    requisition?: Identifier;
    /**
     * On whom or what the service is to be performed. This is usually a human patient, but can also be requested on animals, groups of humans or animals, devices such as dialysis machines, or even locations (typically for environmental scans).
     *
     * Individual or Entity the service is ordered for
     */
    subject: Patient | Group | Location | Device | Reference;
    /**
     * Insurance plans, coverage extensions, pre-authorizations and/or pre-determinations that may be needed for delivering the requested service.
     *
     * Associated insurance coverage
     */
    insurance?: Coverage[] | ClaimResponse[] | Reference[];
    /**
     * An explanation or justification for why this service is being requested in coded or textual form.   This is often for billing purposes.  May relate to the resources referred to in `supportingInfo`.
     *
     * Explanation/Justification for procedure or service
     */
    reason?: CodeableReference[];
    /**
     * Any other notes and comments made about the service request. For example, internal billing notes.
     *
     * Comments
     */
    note?: Annotation[];
    /**
     * A code or reference that identifies a particular service (i.e., procedure, diagnostic investigation, or panel of investigations) that have been requested.
     *
     * What is being requested/ordered
     */
    code?: CodeableReference;
    /**
     * The URL pointing to an externally maintained protocol, guideline, orderset or other definition that is adhered to in whole or in part by this ServiceRequest.
     *
     * Instantiates external protocol or definition
     */
    instantiatesUri?: string[];
    /**
     * Key events in the history of the request.
     *
     * Request provenance
     */
    relevantHistory?: Provenance[] | Reference[];
    /**
     * The actual focus of a service request when it is not the subject of record representing something or someone associated with the subject such as a spouse, parent, fetus, or donor. The focus of a service request could also be an existing condition,  an intervention, the subject's diet,  another service request on the subject,  or a body structure such as tumor or implanted device.
     *
     * What the service request is about, when it is not about the subject of record
     */
    focus?: Reference[];
    /**
     * The date/time at which the requested service should occur.
     *
     * When service should occur
     */
    occurrence?: Date | Period | Timing;
    readonly resourceType: string;
    static revive(json: any): ServiceRequest;
    toJSON(): any;
}
export declare namespace ServiceRequest {
    enum RequestStatus {
        REVOKED,
        ENTEREDINERROR,
        COMPLETED,
        NULL,
        ACTIVE,
        DRAFT,
        ONHOLD,
        UNKNOWN
    }
    enum RequestIntent {
        ORDER,
        FILLERORDER,
        ORIGINALORDER,
        NULL,
        REFLEXORDER,
        DIRECTIVE,
        OPTION,
        PROPOSAL,
        PLAN,
        INSTANCEORDER
    }
    enum RequestPriority {
        URGENT,
        STAT,
        NULL,
        ROUTINE,
        ASAP
    }
    class ServiceRequestPatientInstructionComponent extends BackboneElement {
        /**
         * Instructions in terms that are understood by the patient or consumer.
         *
         * Patient or consumer-oriented instructions
         */
        instruction?: string | DocumentReference | Reference;
        static revive(json: any): ServiceRequestPatientInstructionComponent;
        toJSON(): any;
    }
    class ServiceRequestOrderDetailParameterComponent extends BackboneElement {
        /**
         * A value representing the additional detail or instructions for the order (e.g., catheter insertion, body elevation, descriptive device configuration and/or setting instructions).
         *
         * The detail of the order being requested
         */
        code: CodeableConcept;
        /**
         * Indicates a value for the order detail.
         *
         * The value for the order detail
         */
        value: Quantity | Ratio | Range | boolean | CodeableConcept | string | Period;
        static revive(json: any): ServiceRequestOrderDetailParameterComponent;
        toJSON(): any;
    }
    class ServiceRequestOrderDetailComponent extends BackboneElement {
        /**
         * Indicates the context of the order details by reference.
         *
         * The context of the order details by reference
         */
        parameterFocus?: CodeableReference;
        /**
         * The parameter details for the service being requested.
         *
         * The parameter details for the service being requested
         */
        parameter: ServiceRequest.ServiceRequestOrderDetailParameterComponent[];
        static revive(json: any): ServiceRequestOrderDetailComponent;
        toJSON(): any;
    }
}
