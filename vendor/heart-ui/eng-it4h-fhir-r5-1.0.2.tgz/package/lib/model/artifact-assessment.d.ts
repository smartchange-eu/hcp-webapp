import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { RelatedArtifact } from '../datatype/related-artifact';
import { Citation } from '../model/citation';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
/**
 * HAPI/FHIR <b>ArtifactAssessment</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ArtifactAssessment">http://hl7.org/fhir/StructureDefinition/ArtifactAssessment</a>
 * </p>
 *
 */
export declare class ArtifactAssessment extends DomainResource {
    /**
     * Display of or reference to the bibliographic citation of the comment, classifier, or rating.
     *
     * How to cite the comment or rating
     */
    citeAs?: Citation | string | Reference;
    /**
     * The date on which the resource content was last reviewed. Review happens periodically after approval but does not change the original approval date.
     *
     * When the artifact assessment was last reviewed by the publisher
     */
    lastReviewDate?: Date;
    /**
     * Indicates the workflow status of the comment or change request.
     *
     * submitted | triaged | waiting-for-input | resolved-no-change | resolved-change-required | deferred | duplicate | applied | published | entered-in-error
     */
    workflowStatus?: string;
    /**
     * A formal identifier that is used to identify this artifact assessment when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the artifact assessment
     */
    identifier?: Identifier[];
    /**
     * The date  (and optionally time) when the artifact assessment was published. The date must change when the disposition changes and it must change if the workflow status code changes. In addition, it should change when the substantive content of the artifact assessment changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * A reference to a resource, canonical resource, or non-FHIR resource which the comment or assessment is about.
     *
     * The artifact assessed, commented upon or rated
     */
    artifact: Reference | string;
    /**
     * The date on which the resource content was approved by the publisher. Approval happens once when the content is officially approved for usage.
     *
     * When the artifact assessment was approved by publisher
     */
    approvalDate?: Date;
    /**
     * A copyright statement relating to the artifact assessment and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the artifact assessment.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * Indicates the disposition of the responsible party to the comment or change request.
     *
     * unresolved | not-persuasive | persuasive | persuasive-with-modification | not-persuasive-with-modification
     */
    disposition?: string;
    /**
     * A short title for the assessment for use in displaying and selecting.
     *
     * A short title for the assessment for use in displaying and selecting
     */
    title?: string;
    /**
     * A component comment, classifier, or rating of the artifact.
     *
     * Comment, classifier, or rating content
     */
    content?: ArtifactAssessment.ArtifactAssessmentContentComponent[];
    readonly resourceType: string;
    static revive(json: any): ArtifactAssessment;
    toJSON(): any;
}
export declare namespace ArtifactAssessment {
    enum ArtifactAssessmentWorkflowStatus {
        WAITINGFORINPUT,
        ENTEREDINERROR,
        DUPLICATE,
        PUBLISHED,
        NULL,
        RESOLVEDNOCHANGE,
        SUBMITTED,
        TRIAGED,
        RESOLVEDCHANGEREQUIRED,
        DEFERRED,
        APPLIED
    }
    enum ArtifactAssessmentInformationType {
        CLASSIFIER,
        NULL,
        RATING,
        CHANGEREQUEST,
        CONTAINER,
        RESPONSE,
        COMMENT
    }
    enum ArtifactAssessmentDisposition {
        NOTPERSUASIVE,
        NULL,
        PERSUASIVE,
        PERSUASIVEWITHMODIFICATION,
        UNRESOLVED,
        NOTPERSUASIVEWITHMODIFICATION
    }
    class ArtifactAssessmentContentComponent extends BackboneElement {
        /**
         * The type of information this component of the content represents.
         *
         * comment | classifier | rating | container | response | change-request
         */
        informationType?: string;
        /**
         * Indicates what type of content this component represents.
         *
         * What type of content
         */
        type?: CodeableConcept;
        /**
         * Acceptable to publicly share the comment, classifier or rating.
         *
         * Acceptable to publicly share the resource content
         */
        freeToShare?: boolean;
        /**
         * Represents a rating, classifier, or assessment of the artifact.
         *
         * Rating, classifier, or assessment
         */
        classifier?: CodeableConcept[];
        /**
         * Indicates who or what authored the content.
         *
         * Who authored the content
         */
        author?: Patient | Practitioner | PractitionerRole | Organization | Device | Reference;
        /**
         * A quantitative rating of the artifact.
         *
         * Quantitative rating
         */
        quantity?: Quantity;
        /**
         * Additional related artifacts that provide supporting documentation, additional evidence, or further information related to the content.
         *
         * Additional information
         */
        relatedArtifact?: RelatedArtifact[];
        /**
         * If the informationType is container, the components of the content.
         *
         * Contained content
         */
        component?: ArtifactAssessment.ArtifactAssessmentContentComponent[];
        /**
         * A URI that points to what the comment is about, such as a line of text in the CQL, or a specific element in a resource.
         *
         * What the comment is directed to
         */
        path?: string[];
        /**
         * A brief summary of the content of this component.
         *
         * Brief summary of the content
         */
        summary?: string;
        static revive(json: any): ArtifactAssessmentContentComponent;
        toJSON(): any;
    }
}
