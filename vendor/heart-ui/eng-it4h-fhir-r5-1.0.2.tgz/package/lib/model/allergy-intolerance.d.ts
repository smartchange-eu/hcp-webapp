import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Age } from '../datatype/age';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Range } from '../datatype/range';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>AllergyIntolerance</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/AllergyIntolerance">http://hl7.org/fhir/StructureDefinition/AllergyIntolerance</a>
 * </p>
 *
 */
export declare class AllergyIntolerance extends DomainResource {
    /**
     * The patient who has the allergy or intolerance.
     *
     * Who the allergy or intolerance is for
     */
    patient: Patient | Reference;
    /**
     * Represents the date and/or time of the last known occurrence of a reaction event.
     *
     * Date(/time) of last known occurrence of a reaction
     */
    lastOccurrence?: Date;
    /**
     * Category of the identified substance.
     *
     * food | medication | environment | biologic
     */
    category?: string[];
    /**
     * Business identifiers assigned to this AllergyIntolerance by the performer or other systems which remain constant as the resource is updated and propagates from server to server.
     *
     * External ids for this item
     */
    identifier?: Identifier[];
    /**
     * Additional narrative about the propensity for the Adverse Reaction, not captured in other fields.
     *
     * Additional text not captured in other fields
     */
    note?: Annotation[];
    /**
     * Code for an allergy or intolerance statement (either a positive or a negated/excluded statement).  This may be a code for a substance or pharmaceutical product that is considered to be responsible for the adverse reaction risk (e.g., "Latex"), an allergy or intolerance condition (e.g., "Latex allergy"), or a negated/excluded code for a specific substance or class (e.g., "No latex allergy") or a general or categorical negated statement (e.g.,  "No known allergy", "No known drug allergies").  Note: the substance for a specific reaction may be different from the substance identified as the cause of the risk, but it must be consistent with it. For instance, it may be a more specific substance (e.g. a brand medication) or a composite product that includes the identified substance. It must be clinically safe to only process the 'code' and ignore the 'reaction.substance'.  If a receiving system is unable to confirm that AllergyIntolerance.reaction.substance falls within the semantic scope of AllergyIntolerance.code, then the receiving system should ignore AllergyIntolerance.reaction.substance.
     *
     * Code that identifies the allergy or intolerance
     */
    code?: CodeableConcept;
    /**
     * Details about each adverse reaction event linked to exposure to the identified substance.
     *
     * Adverse Reaction Events linked to exposure to substance
     */
    reaction?: AllergyIntolerance.AllergyIntoleranceReactionComponent[];
    /**
     * Assertion about certainty associated with the propensity, or potential risk, of a reaction to the identified substance (including pharmaceutical product).  The verification status pertains to the allergy or intolerance, itself, not to any specific AllergyIntolerance attribute.
     *
     * unconfirmed | presumed | confirmed | refuted | entered-in-error
     */
    verificationStatus?: CodeableConcept;
    /**
     * The recordedDate represents when this particular AllergyIntolerance record was created in the system, which is often a system-generated date.
     *
     * Date allergy or intolerance was first recorded
     */
    recordedDate?: Date;
    /**
     * Estimate of the potential clinical harm, or seriousness, of the reaction to the identified substance.
     *
     * low | high | unable-to-assess
     */
    criticality?: string;
    /**
     * The encounter when the allergy or intolerance was asserted.
     *
     * Encounter when the allergy or intolerance was asserted
     */
    encounter?: Encounter | Reference;
    /**
     * The clinical status of the allergy or intolerance.
     *
     * active | inactive | resolved
     */
    clinicalStatus?: CodeableConcept;
    /**
     * Identification of the underlying physiological mechanism for the reaction risk.
     *
     * allergy | intolerance - Underlying mechanism (if known)
     */
    type?: CodeableConcept;
    /**
     * Estimated or actual date,  date-time, or age when allergy or intolerance was identified.
     *
     * When allergy or intolerance was identified
     */
    onset?: Date | Age | Period | Range | string;
    /**
     * Indicates who or what participated in the activities related to the allergy or intolerance and how they were involved.
     *
     * Who or what participated in the activities related to the allergy or intolerance and how they were involved
     */
    participant?: AllergyIntolerance.AllergyIntoleranceParticipantComponent[];
    readonly resourceType: string;
    static revive(json: any): AllergyIntolerance;
    toJSON(): any;
}
export declare namespace AllergyIntolerance {
    enum AllergyIntoleranceSeverity {
        MILD,
        MODERATE,
        SEVERE,
        NULL
    }
    enum AllergyIntoleranceCriticality {
        UNABLETOASSESS,
        HIGH,
        NULL,
        LOW
    }
    enum AllergyIntoleranceCategory {
        MEDICATION,
        BIOLOGIC,
        NULL,
        ENVIRONMENT,
        FOOD
    }
    class AllergyIntoleranceReactionComponent extends BackboneElement {
        /**
         * Text description about the reaction as a whole, including details of the manifestation if required.
         *
         * Description of the event as a whole
         */
        description?: string;
        /**
         * Identification of the route by which the subject was exposed to the substance.
         *
         * How the subject was exposed to the substance
         */
        exposureRoute?: CodeableConcept;
        /**
         * Record of the date and/or time of the onset of the Reaction.
         *
         * Date(/time) when manifestations showed
         */
        onset?: Date;
        /**
         * Clinical symptoms and/or signs that are observed or associated with the adverse reaction event.
         *
         * Clinical symptoms/signs associated with the Event
         */
        manifestation: CodeableReference[];
        /**
         * Additional text about the adverse reaction event not captured in other fields.
         *
         * Text about event not captured in other fields
         */
        note?: Annotation[];
        /**
         * Clinical assessment of the severity of the reaction event as a whole, potentially considering multiple different manifestations.
         *
         * mild | moderate | severe (of event as a whole)
         */
        severity?: string;
        /**
         * Identification of the specific substance (or pharmaceutical product) considered to be responsible for the Adverse Reaction event. Note: the substance for a specific reaction may be different from the substance identified as the cause of the risk, but it must be consistent with it. For instance, it may be a more specific substance (e.g. a brand medication) or a composite product that includes the identified substance. It must be clinically safe to only process the 'code' and ignore the 'reaction.substance'.  If a receiving system is unable to confirm that AllergyIntolerance.reaction.substance falls within the semantic scope of AllergyIntolerance.code, then the receiving system should ignore AllergyIntolerance.reaction.substance.
         *
         * Specific substance or pharmaceutical product considered to be responsible for event
         */
        substance?: CodeableConcept;
        static revive(json: any): AllergyIntoleranceReactionComponent;
        toJSON(): any;
    }
    class AllergyIntoleranceParticipantComponent extends BackboneElement {
        /**
         * Distinguishes the type of involvement of the actor in the activities related to the allergy or intolerance.
         *
         * Type of involvement
         */
        function?: CodeableConcept;
        /**
         * Indicates who or what participated in the activities related to the allergy or intolerance.
         *
         * Who or what participated in the activities related to the allergy or intolerance
         */
        actor: Practitioner | PractitionerRole | Patient | RelatedPerson | Device | Organization | CareTeam | Reference;
        static revive(json: any): AllergyIntoleranceParticipantComponent;
        toJSON(): any;
    }
}
