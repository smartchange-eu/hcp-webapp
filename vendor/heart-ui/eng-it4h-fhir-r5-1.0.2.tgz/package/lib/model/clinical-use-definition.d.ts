import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Expression } from '../datatype/expression';
import { Identifier } from '../datatype/identifier';
import { Range } from '../datatype/range';
import { ActivityDefinition } from '../model/activity-definition';
import { BiologicallyDerivedProduct } from '../model/biologically-derived-product';
import { Device } from '../model/device';
import { DeviceDefinition } from '../model/device-definition';
import { DomainResource } from '../model/domain-resource';
import { Group } from '../model/group';
import { Medication } from '../model/medication';
import { MedicinalProductDefinition } from '../model/medicinal-product-definition';
import { NutritionProduct } from '../model/nutrition-product';
import { ObservationDefinition } from '../model/observation-definition';
import { PlanDefinition } from '../model/plan-definition';
import { Substance } from '../model/substance';
/**
 * HAPI/FHIR <b>ClinicalUseDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ClinicalUseDefinition">http://hl7.org/fhir/StructureDefinition/ClinicalUseDefinition</a>
 * </p>
 *
 */
export declare class ClinicalUseDefinition extends DomainResource {
    /**
     * Logic used by the clinical use definition.
     *
     * Logic used by the clinical use definition
     */
    library?: string[];
    /**
     * Business identifier for this issue.
     *
     * Business identifier for this issue
     */
    identifier?: Identifier[];
    /**
     * Describe the possible undesirable effects (negative outcomes) from the use of the medicinal product as treatment.
     *
     * A possible negative outcome from the use of this treatment
     */
    undesirableEffect?: ClinicalUseDefinition.ClinicalUseDefinitionUndesirableEffectComponent;
    /**
     * The medication, product, substance, device, procedure etc. for which this is an indication.
     *
     * The medication, product, substance, device, procedure etc. for which this is an indication
     */
    subject?: MedicinalProductDefinition[] | Medication[] | ActivityDefinition[] | PlanDefinition[] | Device[] | DeviceDefinition[] | Substance[] | NutritionProduct[] | BiologicallyDerivedProduct[] | Reference[];
    /**
     * Specifics for when this is an indication.
     *
     * Specifics for when this is an indication
     */
    indication?: ClinicalUseDefinition.ClinicalUseDefinitionIndicationComponent;
    /**
     * A critical piece of information about environmental, health or physical risks or hazards that serve as caution to the user. For example 'Do not operate heavy machinery', 'May cause drowsiness', or 'Get medical advice/attention if you feel unwell'.
     *
     * Critical environmental, health or physical risks or hazards. For example 'Do not operate heavy machinery', 'May cause drowsiness'
     */
    warning?: ClinicalUseDefinition.ClinicalUseDefinitionWarningComponent;
    /**
     * Specifics for when this is an interaction.
     *
     * Specifics for when this is an interaction
     */
    interaction?: ClinicalUseDefinition.ClinicalUseDefinitionInteractionComponent;
    /**
     * Whether this is a current issue or one that has been retired etc.
     *
     * Whether this is a current issue or one that has been retired etc
     */
    status?: CodeableConcept;
    /**
     * Specifics for when this is a contraindication.
     *
     * Specifics for when this is a contraindication
     */
    contraindication?: ClinicalUseDefinition.ClinicalUseDefinitionContraindicationComponent;
    /**
     * The population group to which this applies.
     *
     * The population group to which this applies
     */
    population?: Group[] | Reference[];
    /**
     * indication | contraindication | interaction | undesirable-effect | warning.
     *
     * indication | contraindication | interaction | undesirable-effect | warning
     */
    type: string;
    /**
     * A categorisation of the issue, primarily for dividing warnings into subject heading areas such as "Pregnancy and Lactation", "Overdose", "Effects on Ability to Drive and Use Machines".
     *
     * A categorisation of the issue, primarily for dividing warnings into subject heading areas such as "Pregnancy", "Overdose"
     */
    category?: CodeableConcept[];
    readonly resourceType: string;
    static revive(json: any): ClinicalUseDefinition;
    toJSON(): any;
}
export declare namespace ClinicalUseDefinition {
    enum ClinicalUseDefinitionType {
        CONTRAINDICATION,
        NULL,
        UNDESIRABLEEFFECT,
        INTERACTION,
        INDICATION,
        WARNING
    }
    class ClinicalUseDefinitionWarningComponent extends BackboneElement {
        /**
         * A textual definition of this warning, with formatting.
         *
         * A textual definition of this warning, with formatting
         */
        description?: string;
        /**
         * A coded or unformatted textual definition of this warning.
         *
         * A coded or unformatted textual definition of this warning
         */
        code?: CodeableConcept;
        static revive(json: any): ClinicalUseDefinitionWarningComponent;
        toJSON(): any;
    }
    class ClinicalUseDefinitionUndesirableEffectComponent extends BackboneElement {
        /**
         * The situation in which the undesirable effect may manifest.
         *
         * The situation in which the undesirable effect may manifest
         */
        symptomConditionEffect?: CodeableReference;
        /**
         * High level classification of the effect.
         *
         * High level classification of the effect
         */
        classification?: CodeableConcept;
        /**
         * How often the effect is seen.
         *
         * How often the effect is seen
         */
        frequencyOfOccurrence?: CodeableConcept;
        static revive(json: any): ClinicalUseDefinitionUndesirableEffectComponent;
        toJSON(): any;
    }
    class ClinicalUseDefinitionInteractionInteractantComponent extends BackboneElement {
        /**
         * The specific medication, product, food, substance etc. or laboratory test that interacts.
         *
         * The specific medication, product, food etc. or laboratory test that interacts
         */
        item: MedicinalProductDefinition | Medication | Substance | NutritionProduct | BiologicallyDerivedProduct | ObservationDefinition | CodeableConcept | Reference;
        static revive(json: any): ClinicalUseDefinitionInteractionInteractantComponent;
        toJSON(): any;
    }
    class ClinicalUseDefinitionInteractionComponent extends BackboneElement {
        /**
         * The type of the interaction e.g. drug-drug interaction, drug-food interaction, drug-lab test interaction.
         *
         * The type of the interaction e.g. drug-drug interaction, drug-lab test interaction
         */
        type?: CodeableConcept;
        /**
         * The incidence of the interaction, e.g. theoretical, observed.
         *
         * The incidence of the interaction, e.g. theoretical, observed
         */
        incidence?: CodeableConcept;
        /**
         * The specific medication, product, food, substance etc. or laboratory test that interacts.
         *
         * The specific medication, product, food etc. or laboratory test that interacts
         */
        interactant?: ClinicalUseDefinition.ClinicalUseDefinitionInteractionInteractantComponent[];
        /**
         * Actions for managing the interaction.
         *
         * Actions for managing the interaction
         */
        management?: CodeableConcept[];
        /**
         * The effect of the interaction, for example "reduced gastric absorption of primary medication".
         *
         * The effect of the interaction, for example "reduced gastric absorption of primary medication"
         */
        effect?: CodeableReference;
        static revive(json: any): ClinicalUseDefinitionInteractionComponent;
        toJSON(): any;
    }
    class ClinicalUseDefinitionIndicationComponent extends BackboneElement {
        /**
         * An unwanted side effect or negative outcome that may happen if you use the drug (or other subject of this resource) for this indication.
         *
         * An unwanted side effect or negative outcome of the subject of this resource when being used for this indication
         */
        undesirableEffect?: ClinicalUseDefinition[] | Reference[];
        /**
         * The status of the disease or symptom for the indication, for example "chronic" or "metastatic".
         *
         * The status of the disease or symptom for the indication
         */
        diseaseStatus?: CodeableReference;
        /**
         * Timing or duration information, that may be associated with use with the indicated condition e.g. Adult patients suffering from myocardial infarction (from a few days until less than 35 days), ischaemic stroke (from 7 days until less than 6 months).
         *
         * Timing or duration information
         */
        duration?: Range | string;
        /**
         * A comorbidity (concurrent condition) or coinfection as part of the indication.
         *
         * A comorbidity or coinfection as part of the indication
         */
        comorbidity?: CodeableReference[];
        /**
         * Information about the use of the medicinal product in relation to other therapies described as part of the indication.
         *
         * The use of the medicinal product in relation to other therapies described as part of the indication
         */
        otherTherapy?: ClinicalUseDefinition.ClinicalUseDefinitionContraindicationOtherTherapyComponent[];
        /**
         * The intended effect, aim or strategy to be achieved.
         *
         * The intended effect, aim or strategy to be achieved
         */
        intendedEffect?: CodeableReference;
        /**
         * The situation that is being documented as an indicaton for this item.
         *
         * The situation that is being documented as an indicaton for this item
         */
        diseaseSymptomProcedure?: CodeableReference;
        /**
         * An expression that returns true or false, indicating whether the indication is applicable or not, after having applied its other elements.
         *
         * An expression that returns true or false, indicating whether the indication is applicable or not, after having applied its other elements
         */
        applicability?: Expression;
        static revive(json: any): ClinicalUseDefinitionIndicationComponent;
        toJSON(): any;
    }
    class ClinicalUseDefinitionContraindicationOtherTherapyComponent extends BackboneElement {
        /**
         * Reference to a specific medication (active substance, medicinal product or class of products, biological, food etc.) as part of an indication or contraindication.
         *
         * Reference to a specific medication, substance etc. as part of an indication or contraindication
         */
        treatment: CodeableReference;
        /**
         * The type of relationship between the medicinal product indication or contraindication and another therapy.
         *
         * The type of relationship between the product indication/contraindication and another therapy
         */
        relationshipType: CodeableConcept;
        static revive(json: any): ClinicalUseDefinitionContraindicationOtherTherapyComponent;
        toJSON(): any;
    }
    class ClinicalUseDefinitionContraindicationComponent extends BackboneElement {
        /**
         * An expression that returns true or false, indicating whether the indication is applicable or not, after having applied its other elements.
         *
         * An expression that returns true or false, indicating whether the indication is applicable or not, after having applied its other elements
         */
        applicability?: Expression;
        /**
         * The indication which this is a contraidication for.
         *
         * The indication which this is a contraidication for
         */
        indication?: ClinicalUseDefinition[] | Reference[];
        /**
         * The situation that is being documented as contraindicating against this item.
         *
         * The situation that is being documented as contraindicating against this item
         */
        diseaseSymptomProcedure?: CodeableReference;
        /**
         * Information about the use of the medicinal product in relation to other therapies described as part of the contraindication.
         *
         * Information about use of the product in relation to other therapies described as part of the contraindication
         */
        otherTherapy?: ClinicalUseDefinition.ClinicalUseDefinitionContraindicationOtherTherapyComponent[];
        /**
         * A comorbidity (concurrent condition) or coinfection.
         *
         * A comorbidity (concurrent condition) or coinfection
         */
        comorbidity?: CodeableReference[];
        /**
         * The status of the disease or symptom for the contraindication, for example "chronic" or "metastatic".
         *
         * The status of the disease or symptom for the contraindication
         */
        diseaseStatus?: CodeableReference;
        static revive(json: any): ClinicalUseDefinitionContraindicationComponent;
        toJSON(): any;
    }
}
