import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Address } from '../datatype/address';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Coding } from '../datatype/coding';
import { Identifier } from '../datatype/identifier';
import { Money } from '../datatype/money';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Claim } from '../model/claim';
import { ClaimResponse } from '../model/claim-response';
import { Condition } from '../model/condition';
import { Coverage } from '../model/coverage';
import { Device } from '../model/device';
import { DeviceRequest } from '../model/device-request';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Location } from '../model/location';
import { MedicationRequest } from '../model/medication-request';
import { NutritionOrder } from '../model/nutrition-order';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Procedure } from '../model/procedure';
import { RelatedPerson } from '../model/related-person';
import { ServiceRequest } from '../model/service-request';
import { SupplyRequest } from '../model/supply-request';
import { VisionPrescription } from '../model/vision-prescription';
/**
 * HAPI/FHIR <b>ExplanationOfBenefit</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ExplanationOfBenefit">http://hl7.org/fhir/StructureDefinition/ExplanationOfBenefit</a>
 * </p>
 *
 */
export declare class ExplanationOfBenefit extends DomainResource {
    /**
     * Trace number for tracking purposes. May be defined at the jurisdiction level or between trading partners.
     *
     * Number for tracking
     */
    traceNumber?: Identifier[];
    /**
     * The business identifier for the instance of the adjudication response: claim, predetermination or preauthorization response.
     *
     * Claim response reference
     */
    claimResponse?: ClaimResponse | Reference;
    /**
     * A code to indicate whether the nature of the request is: Claim - A request to an Insurer to adjudicate the supplied charges for health care goods and services under the identified policy and to pay the determined Benefit amount, if any; Preauthorization - A request to an Insurer to adjudicate the supplied proposed future charges for health care goods and services under the identified policy and to approve the services and provide the expected benefit amounts and potentially to reserve funds to pay the benefits when Claims for the indicated services are later submitted; or, Pre-determination - A request to an Insurer to adjudicate the supplied 'what if' charges for health care goods and services under the identified policy and report back what the Benefit payable would be had the services actually been provided.
     *
     * claim | preauthorization | predetermination
     */
    use: string;
    /**
     * Financial instruments for reimbursement for the health care products and services specified on the claim.
     *
     * Patient insurance information
     */
    insurance?: ExplanationOfBenefit.InsuranceComponent[];
    /**
     * The term of the benefits documented in this response.
     *
     * When the benefits are applicable
     */
    benefitPeriod?: Period;
    /**
     * The category of claim, e.g. oral, pharmacy, vision, institutional, professional.
     *
     * Category or discipline
     */
    type: CodeableConcept;
    /**
     * This indicates the relative order of a series of EOBs related to different coverages for the same suite of services.
     *
     * Precedence (primary, secondary, etc.)
     */
    precedence?: number;
    /**
     * A note that describes or explains adjudication results in a human readable form.
     *
     * Note concerning adjudication
     */
    processNote?: ExplanationOfBenefit.NoteComponent[];
    /**
     * Reference from the Insurer which is used in later communications which refers to this adjudication.
     *
     * Preauthorization reference
     */
    preAuthRef?: string[];
    /**
     * A package billing code or bundle code used to group products and services to a particular health condition (such as heart attack) which is based on a predetermined grouping code system.
     *
     * Package billing code
     */
    diagnosisRelatedGroup?: CodeableConcept;
    /**
     * Additional information codes regarding exceptions, special considerations, the condition, situation, prior or concurrent issues.
     *
     * Supporting information
     */
    supportingInfo?: ExplanationOfBenefit.SupportingInformationComponent[];
    /**
     * The party to be reimbursed for cost of the products and services according to the terms of the policy.
     *
     * Recipient of benefits payable
     */
    payee?: ExplanationOfBenefit.PayeeComponent;
    /**
     * The members of the team who provided the products and services.
     *
     * Care Team members
     */
    careTeam?: ExplanationOfBenefit.CareTeamComponent[];
    /**
     * Individual who created the claim, predetermination or preauthorization.
     *
     * Author of the claim
     */
    enterer?: Practitioner | PractitionerRole | Patient | RelatedPerson | Reference;
    /**
     * The business identifier for the instance of the adjudication request: claim predetermination or preauthorization.
     *
     * Claim reference
     */
    claim?: Claim | Reference;
    /**
     * Payment details for the adjudication of the claim.
     *
     * Payment Details
     */
    payment?: ExplanationOfBenefit.PaymentComponent;
    /**
     * The date this resource was created.
     *
     * Response creation date
     */
    created: Date;
    /**
     * A unique identifier assigned to this explanation of benefit.
     *
     * Business Identifier for the resource
     */
    identifier?: Identifier[];
    /**
     * A claim line. Either a simple (a product or service) or a 'group' of details which can also be a simple items or groups of sub-details.
     *
     * Product or service provided
     */
    item?: ExplanationOfBenefit.ItemComponent[];
    /**
     * The amount paid by the patient, in total at the claim claim level or specifically for the item and detail level, to the provider for goods and services.
     *
     * Paid by the patient
     */
    patientPaid?: Money;
    /**
     * The provider-required urgency of processing the request. Typical values include: stat, normal deferred.
     *
     * Desired processing urgency
     */
    priority?: CodeableConcept;
    /**
     * Information about diagnoses relevant to the claim items.
     *
     * Pertinent diagnosis information
     */
    diagnosis?: ExplanationOfBenefit.DiagnosisComponent[];
    /**
     * The period for which charges are being submitted.
     *
     * Relevant time frame for the claim
     */
    billablePeriod?: Period;
    /**
     * The timeframe during which the supplied preauthorization reference may be quoted on claims to obtain the adjudication as provided.
     *
     * Preauthorization in-effect period
     */
    preAuthRefPeriod?: Period[];
    /**
     * The status of the resource instance.
     *
     * active | cancelled | draft | entered-in-error
     */
    status: string;
    /**
     * A finer grained suite of claim type codes which may convey additional information such as Inpatient vs Outpatient and/or a specialty service.
     *
     * More granular claim type
     */
    subType?: CodeableConcept;
    /**
     * Balance by Benefit Category.
     *
     * Balance by Benefit Category
     */
    benefitBalance?: ExplanationOfBenefit.BenefitBalanceComponent[];
    /**
     * Details of a accident which resulted in injuries which required the products and services listed in the claim.
     *
     * Details of the event
     */
    accident?: ExplanationOfBenefit.AccidentComponent;
    /**
     * Other claims which are related to this claim such as prior submissions or claims for related services or for the same event.
     *
     * Prior or corollary claims
     */
    related?: ExplanationOfBenefit.RelatedClaimComponent[];
    /**
     * The provider which is responsible for the claim, predetermination or preauthorization.
     *
     * Party responsible for the claim
     */
    provider?: Practitioner | PractitionerRole | Organization | Reference;
    /**
     * A code to indicate whether and for whom funds are to be reserved for future claims.
     *
     * For whom to reserve funds
     */
    fundsReserveRequested?: CodeableConcept;
    /**
     * A code, used only on a response to a preauthorization, to indicate whether the benefits payable have been reserved and for whom.
     *
     * Funds reserved status
     */
    fundsReserve?: CodeableConcept;
    /**
     * The party to whom the professional services and/or products have been supplied or are being considered and for whom actual for forecast reimbursement is sought.
     *
     * The recipient of the products and services
     */
    patient: Patient | Reference;
    /**
     * The party responsible for authorization, adjudication and reimbursement.
     *
     * Party responsible for reimbursement
     */
    insurer?: Organization | Reference;
    /**
     * The adjudication results which are presented at the header level rather than at the line-item or add-item levels.
     *
     * Header-level adjudication
     */
    adjudication?: ExplanationOfBenefit.AdjudicationComponent[];
    /**
     * The first-tier service adjudications for payor added product or service lines.
     *
     * Insurer added line items
     */
    addItem?: ExplanationOfBenefit.AddedItemComponent[];
    /**
     * Categorized monetary totals for the adjudication.
     *
     * Adjudication totals
     */
    total?: ExplanationOfBenefit.TotalComponent[];
    /**
     * Information code for an event with a corresponding date or period.
     *
     * Event information
     */
    event?: ExplanationOfBenefit.ExplanationOfBenefitEventComponent[];
    /**
     * The outcome of the claim, predetermination, or preauthorization processing.
     *
     * queued | complete | error | partial
     */
    outcome: string;
    /**
     * The result of the claim, predetermination, or preauthorization adjudication.
     *
     * Result of the adjudication
     */
    decision?: CodeableConcept;
    /**
     * A code for the form to be used for printing the content.
     *
     * Printed form identifier
     */
    formCode?: CodeableConcept;
    /**
     * Original prescription which has been superseded by this prescription to support the dispensing of pharmacy services, medications or products.
     *
     * Original prescription if superceded by fulfiller
     */
    originalPrescription?: MedicationRequest | Reference;
    /**
     * Healthcare encounters related to this claim.
     *
     * Encounters associated with the listed treatments
     */
    encounter?: Encounter[] | Reference[];
    /**
     * Procedures performed on the patient relevant to the billing items with the claim.
     *
     * Clinical procedures performed
     */
    procedure?: ExplanationOfBenefit.ProcedureComponent[];
    /**
     * The actual form, by reference or inclusion, for printing the content or an EOB.
     *
     * Printed reference or actual form
     */
    form?: Attachment;
    /**
     * Prescription is the document/authorization given to the claim author for them to provide products and services for which consideration (reimbursement) is sought. Could be a RX for medications, an 'order' for oxygen or wheelchair or physiotherapy treatments.
     *
     * Prescription authorizing services or products
     */
    prescription?: MedicationRequest | VisionPrescription | Reference;
    /**
     * A human readable description of the status of the adjudication.
     *
     * Disposition Message
     */
    disposition?: string;
    /**
     * The referral information received by the claim author, it is not to be used when the author generates a referral for a patient. A copy of that referral may be provided as supporting information. Some insurers require proof of referral to pay for services or to pay specialist rates for services.
     *
     * Treatment Referral
     */
    referral?: ServiceRequest | Reference;
    /**
     * Facility where the services were provided.
     *
     * Servicing Facility
     */
    facility?: Location | Organization | Reference;
    readonly resourceType: string;
    static revive(json: any): ExplanationOfBenefit;
    toJSON(): any;
}
export declare namespace ExplanationOfBenefit {
    enum ExplanationOfBenefitStatus {
        CANCELLED,
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        DRAFT
    }
    enum Use {
        NULL,
        PREAUTHORIZATION,
        PREDETERMINATION,
        CLAIM
    }
    enum ClaimProcessingCodes {
        COMPLETE,
        NULL,
        QUEUED,
        PARTIAL,
        ERROR
    }
    class BenefitComponent extends BackboneElement {
        /**
         * The quantity of the benefit which is permitted under the coverage.
         *
         * Benefits allowed
         */
        allowed?: number | string | Money;
        /**
         * The quantity of the benefit which have been consumed to date.
         *
         * Benefits used
         */
        used?: number | Money;
        /**
         * Classification of benefit being provided.
         *
         * Benefit classification
         */
        type: CodeableConcept;
        static revive(json: any): BenefitComponent;
        toJSON(): any;
    }
    class BenefitBalanceComponent extends BackboneElement {
        /**
         * True if the indicated class of service is excluded from the plan, missing or False indicates the product or service is included in the coverage.
         *
         * Excluded from the plan
         */
        excluded?: boolean;
        /**
         * Indicates if the benefits apply to an individual or to the family.
         *
         * Individual or family
         */
        unit?: CodeableConcept;
        /**
         * Benefits Used to date.
         *
         * Benefit Summary
         */
        financial?: ExplanationOfBenefit.BenefitComponent[];
        /**
         * A richer description of the benefit or services covered.
         *
         * Description of the benefit or services covered
         */
        description?: string;
        /**
         * A short name or tag for the benefit.
         *
         * Short name for the benefit
         */
        name?: string;
        /**
         * The term or period of the values such as 'maximum lifetime benefit' or 'maximum annual visits'.
         *
         * Annual or lifetime
         */
        term?: CodeableConcept;
        /**
         * Code to identify the general type of benefits under which products and services are provided.
         *
         * Benefit classification
         */
        category: CodeableConcept;
        /**
         * Is a flag to indicate whether the benefits refer to in-network providers or out-of-network providers.
         *
         * In or out of network
         */
        network?: CodeableConcept;
        static revive(json: any): BenefitBalanceComponent;
        toJSON(): any;
    }
    class NoteComponent extends BackboneElement {
        /**
         * The business purpose of the note text.
         *
         * Note purpose
         */
        type?: CodeableConcept;
        /**
         * The explanation or description associated with the processing.
         *
         * Note explanatory text
         */
        text?: string;
        /**
         * A code to define the language used in the text of the note.
         *
         * Language of the text
         */
        language?: CodeableConcept;
        /**
         * A number to uniquely identify a note entry.
         *
         * Note instance identifier
         */
        number?: number;
        static revive(json: any): NoteComponent;
        toJSON(): any;
    }
    class PaymentComponent extends BackboneElement {
        /**
         * Issuer's unique identifier for the payment instrument.
         *
         * Business identifier for the payment
         */
        identifier?: Identifier;
        /**
         * Estimated date the payment will be issued or the actual issue date of payment.
         *
         * Expected date of payment
         */
        date?: Date;
        /**
         * Reason for the payment adjustment.
         *
         * Explanation for the variance
         */
        adjustmentReason?: CodeableConcept;
        /**
         * Benefits payable less any payment adjustment.
         *
         * Payable amount after adjustment
         */
        amount?: Money;
        /**
         * Total amount of all adjustments to this payment included in this transaction which are not related to this claim's adjudication.
         *
         * Payment adjustment for non-claim issues
         */
        adjustment?: Money;
        /**
         * Whether this represents partial or complete payment of the benefits payable.
         *
         * Partial or complete payment
         */
        type?: CodeableConcept;
        static revive(json: any): PaymentComponent;
        toJSON(): any;
    }
    class TotalComponent extends BackboneElement {
        /**
         * Monetary total amount associated with the category.
         *
         * Financial total for the category
         */
        amount: Money;
        /**
         * A code to indicate the information type of this adjudication record. Information types may include: the value submitted, maximum values or percentages allowed or payable under the plan, amounts that the patient is responsible for in aggregate or pertaining to this item, amounts paid by other coverages, and the benefit payable for this item.
         *
         * Type of adjudication information
         */
        category: CodeableConcept;
        static revive(json: any): TotalComponent;
        toJSON(): any;
    }
    class AddedItemDetailSubDetailComponent extends BackboneElement {
        /**
         * The numbers associated with notes below which apply to the adjudication of this item.
         *
         * Applicable note numbers
         */
        noteNumber?: number[];
        /**
         * When the value is a group code then this item collects a set of related item details, otherwise this contains the product, service, drug or other billing code for the item. This element may be the start of a range of .productOrService codes used in conjunction with .productOrServiceEnd or it may be a solo element where .productOrServiceEnd is not used.
         *
         * Billing, service, product, or drug code
         */
        productOrService?: CodeableConcept;
        /**
         * The total of taxes applicable for this product or service.
         *
         * Total tax
         */
        tax?: Money;
        /**
         * Item typification or modifiers codes to convey additional context for the product or service.
         *
         * Service/Product billing modifiers
         */
        modifier?: CodeableConcept[];
        /**
         * Trace number for tracking purposes. May be defined at the jurisdiction level or between trading partners.
         *
         * Number for tracking
         */
        traceNumber?: Identifier[];
        /**
         * This contains the end of a range of product, service, drug or other billing codes for the item. This element is not used when the .productOrService is a group code. This value may only be present when a .productOfService code has been provided to convey the start of the range. Typically this value may be used only with preauthorizations and not with claims.
         *
         * End of a range of codes
         */
        productOrServiceEnd?: CodeableConcept;
        /**
         * The amount paid by the patient, in total at the claim claim level or specifically for the item and detail level, to the provider for goods and services.
         *
         * Paid by the patient
         */
        patientPaid?: Money;
        /**
         * The number of repetitions of a service or product.
         *
         * Count of products or services
         */
        quantity?: Quantity;
        /**
         * If the item is not a group then this is the fee for the product or service, otherwise this is the total of the fees for the details of the group.
         *
         * Fee, charge or cost per item
         */
        unitPrice?: Money;
        /**
         * A real number that represents a multiplier used in determining the overall value of services delivered and/or goods received. The concept of a Factor allows for a discount or surcharge multiplier to be applied to a monetary amount.
         *
         * Price scaling factor
         */
        factor?: number;
        /**
         * The total amount claimed for the addItem.detail.subDetail. Net = unit price * quantity * factor.
         *
         * Total item cost
         */
        net?: Money;
        /**
         * The high-level results of the adjudication if adjudication has been performed.
         *
         * Additem subdetail level adjudication results
         */
        reviewOutcome?: ExplanationOfBenefit.ItemReviewOutcomeComponent;
        /**
         * The type of revenue or cost center providing the product and/or service.
         *
         * Revenue or cost center code
         */
        revenue?: CodeableConcept;
        /**
         * The adjudication results.
         *
         * Added items adjudication
         */
        adjudication?: ExplanationOfBenefit.AdjudicationComponent[];
        static revive(json: any): AddedItemDetailSubDetailComponent;
        toJSON(): any;
    }
    class AddedItemDetailComponent extends BackboneElement {
        /**
         * The numbers associated with notes below which apply to the adjudication of this item.
         *
         * Applicable note numbers
         */
        noteNumber?: number[];
        /**
         * The third-tier service adjudications for payor added services.
         *
         * Insurer added line items
         */
        subDetail?: ExplanationOfBenefit.AddedItemDetailSubDetailComponent[];
        /**
         * When the value is a group code then this item collects a set of related item details, otherwise this contains the product, service, drug or other billing code for the item. This element may be the start of a range of .productOrService codes used in conjunction with .productOrServiceEnd or it may be a solo element where .productOrServiceEnd is not used.
         *
         * Billing, service, product, or drug code
         */
        productOrService?: CodeableConcept;
        /**
         * The total of taxes applicable for this product or service.
         *
         * Total tax
         */
        tax?: Money;
        /**
         * Trace number for tracking purposes. May be defined at the jurisdiction level or between trading partners.
         *
         * Number for tracking
         */
        traceNumber?: Identifier[];
        /**
         * This contains the end of a range of product, service, drug or other billing codes for the item. This element is not used when the .productOrService is a group code. This value may only be present when a .productOfService code has been provided to convey the start of the range. Typically this value may be used only with preauthorizations and not with claims.
         *
         * End of a range of codes
         */
        productOrServiceEnd?: CodeableConcept;
        /**
         * Item typification or modifiers codes to convey additional context for the product or service.
         *
         * Service/Product billing modifiers
         */
        modifier?: CodeableConcept[];
        /**
         * If the item is not a group then this is the fee for the product or service, otherwise this is the total of the fees for the details of the group.
         *
         * Fee, charge or cost per item
         */
        unitPrice?: Money;
        /**
         * The amount paid by the patient, in total at the claim claim level or specifically for the item and detail level, to the provider for goods and services.
         *
         * Paid by the patient
         */
        patientPaid?: Money;
        /**
         * The number of repetitions of a service or product.
         *
         * Count of products or services
         */
        quantity?: Quantity;
        /**
         * A real number that represents a multiplier used in determining the overall value of services delivered and/or goods received. The concept of a Factor allows for a discount or surcharge multiplier to be applied to a monetary amount.
         *
         * Price scaling factor
         */
        factor?: number;
        /**
         * The total amount claimed for the group (if a grouper) or the addItem.detail. Net = unit price * quantity * factor.
         *
         * Total item cost
         */
        net?: Money;
        /**
         * The adjudication results.
         *
         * Added items adjudication
         */
        adjudication?: ExplanationOfBenefit.AdjudicationComponent[];
        /**
         * The high-level results of the adjudication if adjudication has been performed.
         *
         * Additem detail level adjudication results
         */
        reviewOutcome?: ExplanationOfBenefit.ItemReviewOutcomeComponent;
        /**
         * The type of revenue or cost center providing the product and/or service.
         *
         * Revenue or cost center code
         */
        revenue?: CodeableConcept;
        static revive(json: any): AddedItemDetailComponent;
        toJSON(): any;
    }
    class AddedItemBodySiteComponent extends BackboneElement {
        /**
         * Physical service site on the patient (limb, tooth, etc.).
         *
         * Location
         */
        site: CodeableReference[];
        /**
         * A region or surface of the bodySite, e.g. limb region or tooth surface(s).
         *
         * Sub-location
         */
        subSite?: CodeableConcept[];
        static revive(json: any): AddedItemBodySiteComponent;
        toJSON(): any;
    }
    class AddedItemComponent extends BackboneElement {
        /**
         * The date or dates when the service or product was supplied, performed or completed.
         *
         * Date or dates of service or product delivery
         */
        serviced?: Date | Period;
        /**
         * Where the product or service was provided.
         *
         * Place of service or where product was supplied
         */
        location?: CodeableConcept | Address | Location | Reference;
        /**
         * The second-tier service adjudications for payor added services.
         *
         * Insurer added line items
         */
        detail?: ExplanationOfBenefit.AddedItemDetailComponent[];
        /**
         * A real number that represents a multiplier used in determining the overall value of services delivered and/or goods received. The concept of a Factor allows for a discount or surcharge multiplier to be applied to a monetary amount.
         *
         * Price scaling factor
         */
        factor?: number;
        /**
         * The total amount claimed for the group (if a grouper) or the addItem. Net = unit price * quantity * factor.
         *
         * Total item cost
         */
        net?: Money;
        /**
         * The type of revenue or cost center providing the product and/or service.
         *
         * Revenue or cost center code
         */
        revenue?: CodeableConcept;
        /**
         * Physical location where the service is performed or applies.
         *
         * Anatomical location
         */
        bodySite?: ExplanationOfBenefit.AddedItemBodySiteComponent[];
        /**
         * The high-level results of the adjudication if adjudication has been performed.
         *
         * Additem level adjudication results
         */
        reviewOutcome?: ExplanationOfBenefit.ItemReviewOutcomeComponent;
        /**
         * The sequence number of the sub-details woithin the details within the claim item which this line is intended to replace.
         *
         * Subdetail sequence number
         */
        subDetailSequence?: number[];
        /**
         * The adjudication results.
         *
         * Added items adjudication
         */
        adjudication?: ExplanationOfBenefit.AdjudicationComponent[];
        /**
         * Claim items which this service line is intended to replace.
         *
         * Item sequence number
         */
        itemSequence?: number[];
        /**
         * The sequence number of the details within the claim item which this line is intended to replace.
         *
         * Detail sequence number
         */
        detailSequence?: number[];
        /**
         * The providers who are authorized for the services rendered to the patient.
         *
         * Authorized providers
         */
        provider?: Practitioner[] | PractitionerRole[] | Organization[] | Reference[];
        /**
         * The total of taxes applicable for this product or service.
         *
         * Total tax
         */
        tax?: Money;
        /**
         * When the value is a group code then this item collects a set of related item details, otherwise this contains the product, service, drug or other billing code for the item. This element may be the start of a range of .productOrService codes used in conjunction with .productOrServiceEnd or it may be a solo element where .productOrServiceEnd is not used.
         *
         * Billing, service, product, or drug code
         */
        productOrService?: CodeableConcept;
        /**
         * The numbers associated with notes below which apply to the adjudication of this item.
         *
         * Applicable note numbers
         */
        noteNumber?: number[];
        /**
         * The amount paid by the patient, in total at the claim claim level or specifically for the item and detail level, to the provider for goods and services.
         *
         * Paid by the patient
         */
        patientPaid?: Money;
        /**
         * The number of repetitions of a service or product.
         *
         * Count of products or services
         */
        quantity?: Quantity;
        /**
         * If the item is not a group then this is the fee for the product or service, otherwise this is the total of the fees for the details of the group.
         *
         * Fee, charge or cost per item
         */
        unitPrice?: Money;
        /**
         * Request or Referral for Goods or Service to be rendered.
         *
         * Request or Referral for Service
         */
        request?: DeviceRequest[] | MedicationRequest[] | NutritionOrder[] | ServiceRequest[] | SupplyRequest[] | VisionPrescription[] | Reference[];
        /**
         * Item typification or modifiers codes to convey additional context for the product or service.
         *
         * Service/Product billing modifiers
         */
        modifier?: CodeableConcept[];
        /**
         * Trace number for tracking purposes. May be defined at the jurisdiction level or between trading partners.
         *
         * Number for tracking
         */
        traceNumber?: Identifier[];
        /**
         * This contains the end of a range of product, service, drug or other billing codes for the item. This element is not used when the .productOrService is a group code. This value may only be present when a .productOfService code has been provided to convey the start of the range. Typically this value may be used only with preauthorizations and not with claims.
         *
         * End of a range of codes
         */
        productOrServiceEnd?: CodeableConcept;
        /**
         * Identifies the program under which this may be recovered.
         *
         * Program the product or service is provided under
         */
        programCode?: CodeableConcept[];
        static revive(json: any): AddedItemComponent;
        toJSON(): any;
    }
    class SubDetailComponent extends BackboneElement {
        /**
         * A claim detail line. Either a simple (a product or service) or a 'group' of sub-details which are simple items.
         *
         * Product or service provided
         */
        sequence: number;
        /**
         * The adjudication results.
         *
         * Subdetail level adjudication details
         */
        adjudication?: ExplanationOfBenefit.AdjudicationComponent[];
        /**
         * The high-level results of the adjudication if adjudication has been performed.
         *
         * Subdetail level adjudication results
         */
        reviewOutcome?: ExplanationOfBenefit.ItemReviewOutcomeComponent;
        /**
         * The type of revenue or cost center providing the product and/or service.
         *
         * Revenue or cost center code
         */
        revenue?: CodeableConcept;
        /**
         * Unique Device Identifiers associated with this line item.
         *
         * Unique device identifier
         */
        udi?: Device[] | Reference[];
        /**
         * Code to identify the general type of benefits under which products and services are provided.
         *
         * Benefit classification
         */
        category?: CodeableConcept;
        /**
         * A real number that represents a multiplier used in determining the overall value of services delivered and/or goods received. The concept of a Factor allows for a discount or surcharge multiplier to be applied to a monetary amount.
         *
         * Price scaling factor
         */
        factor?: number;
        /**
         * The total amount claimed for the line item.detail.subDetail. Net = unit price * quantity * factor.
         *
         * Total item cost
         */
        net?: Money;
        /**
         * If the item is not a group then this is the fee for the product or service, otherwise this is the total of the fees for the details of the group.
         *
         * Fee, charge or cost per item
         */
        unitPrice?: Money;
        /**
         * The amount paid by the patient, in total at the claim claim level or specifically for the item and detail level, to the provider for goods and services.
         *
         * Paid by the patient
         */
        patientPaid?: Money;
        /**
         * The number of repetitions of a service or product.
         *
         * Count of products or services
         */
        quantity?: Quantity;
        /**
         * Identifies the program under which this may be recovered.
         *
         * Program the product or service is provided under
         */
        programCode?: CodeableConcept[];
        /**
         * Trace number for tracking purposes. May be defined at the jurisdiction level or between trading partners.
         *
         * Number for tracking
         */
        traceNumber?: Identifier[];
        /**
         * This contains the end of a range of product, service, drug or other billing codes for the item. This element is not used when the .productOrService is a group code. This value may only be present when a .productOfService code has been provided to convey the start of the range. Typically this value may be used only with preauthorizations and not with claims.
         *
         * End of a range of codes
         */
        productOrServiceEnd?: CodeableConcept;
        /**
         * Item typification or modifiers codes to convey additional context for the product or service.
         *
         * Service/Product billing modifiers
         */
        modifier?: CodeableConcept[];
        /**
         * When the value is a group code then this item collects a set of related item details, otherwise this contains the product, service, drug or other billing code for the item. This element may be the start of a range of .productOrService codes used in conjunction with .productOrServiceEnd or it may be a solo element where .productOrServiceEnd is not used.
         *
         * Billing, service, product, or drug code
         */
        productOrService?: CodeableConcept;
        /**
         * The total of taxes applicable for this product or service.
         *
         * Total tax
         */
        tax?: Money;
        /**
         * The numbers associated with notes below which apply to the adjudication of this item.
         *
         * Applicable note numbers
         */
        noteNumber?: number[];
        static revive(json: any): SubDetailComponent;
        toJSON(): any;
    }
    class DetailComponent extends BackboneElement {
        /**
         * A claim detail line. Either a simple (a product or service) or a 'group' of sub-details which are simple items.
         *
         * Product or service provided
         */
        sequence: number;
        /**
         * The adjudication results.
         *
         * Detail level adjudication details
         */
        adjudication?: ExplanationOfBenefit.AdjudicationComponent[];
        /**
         * The high-level results of the adjudication if adjudication has been performed.
         *
         * Detail level adjudication results
         */
        reviewOutcome?: ExplanationOfBenefit.ItemReviewOutcomeComponent;
        /**
         * The type of revenue or cost center providing the product and/or service.
         *
         * Revenue or cost center code
         */
        revenue?: CodeableConcept;
        /**
         * Code to identify the general type of benefits under which products and services are provided.
         *
         * Benefit classification
         */
        category?: CodeableConcept;
        /**
         * A real number that represents a multiplier used in determining the overall value of services delivered and/or goods received. The concept of a Factor allows for a discount or surcharge multiplier to be applied to a monetary amount.
         *
         * Price scaling factor
         */
        factor?: number;
        /**
         * The total amount claimed for the group (if a grouper) or the line item.detail. Net = unit price * quantity * factor.
         *
         * Total item cost
         */
        net?: Money;
        /**
         * Unique Device Identifiers associated with this line item.
         *
         * Unique device identifier
         */
        udi?: Device[] | Reference[];
        /**
         * Identifies the program under which this may be recovered.
         *
         * Program the product or service is provided under
         */
        programCode?: CodeableConcept[];
        /**
         * Trace number for tracking purposes. May be defined at the jurisdiction level or between trading partners.
         *
         * Number for tracking
         */
        traceNumber?: Identifier[];
        /**
         * This contains the end of a range of product, service, drug or other billing codes for the item. This element is not used when the .productOrService is a group code. This value may only be present when a .productOfService code has been provided to convey the start of the range. Typically this value may be used only with preauthorizations and not with claims.
         *
         * End of a range of codes
         */
        productOrServiceEnd?: CodeableConcept;
        /**
         * Item typification or modifiers codes to convey additional context for the product or service.
         *
         * Service/Product billing modifiers
         */
        modifier?: CodeableConcept[];
        /**
         * If the item is not a group then this is the fee for the product or service, otherwise this is the total of the fees for the details of the group.
         *
         * Fee, charge or cost per item
         */
        unitPrice?: Money;
        /**
         * The amount paid by the patient, in total at the claim claim level or specifically for the item and detail level, to the provider for goods and services.
         *
         * Paid by the patient
         */
        patientPaid?: Money;
        /**
         * The number of repetitions of a service or product.
         *
         * Count of products or services
         */
        quantity?: Quantity;
        /**
         * The numbers associated with notes below which apply to the adjudication of this item.
         *
         * Applicable note numbers
         */
        noteNumber?: number[];
        /**
         * Third-tier of goods and services.
         *
         * Additional items
         */
        subDetail?: ExplanationOfBenefit.SubDetailComponent[];
        /**
         * When the value is a group code then this item collects a set of related item details, otherwise this contains the product, service, drug or other billing code for the item. This element may be the start of a range of .productOrService codes used in conjunction with .productOrServiceEnd or it may be a solo element where .productOrServiceEnd is not used.
         *
         * Billing, service, product, or drug code
         */
        productOrService?: CodeableConcept;
        /**
         * The total of taxes applicable for this product or service.
         *
         * Total tax
         */
        tax?: Money;
        static revive(json: any): DetailComponent;
        toJSON(): any;
    }
    class AdjudicationComponent extends BackboneElement {
        /**
         * A code to indicate the information type of this adjudication record. Information types may include: the value submitted, maximum values or percentages allowed or payable under the plan, amounts that the patient is responsible for in-aggregate or pertaining to this item, amounts paid by other coverages, and the benefit payable for this item.
         *
         * Type of adjudication information
         */
        category: CodeableConcept;
        /**
         * A code supporting the understanding of the adjudication result and explaining variance from expected amount.
         *
         * Explanation of adjudication outcome
         */
        reason?: CodeableConcept;
        /**
         * Monetary amount associated with the category.
         *
         * Monetary amount
         */
        amount?: Money;
        /**
         * A non-monetary value associated with the category. Mutually exclusive to the amount element above.
         *
         * Non-monitary value
         */
        quantity?: Quantity;
        static revive(json: any): AdjudicationComponent;
        toJSON(): any;
    }
    class ItemReviewOutcomeComponent extends BackboneElement {
        /**
         * The time frame during which this authorization is effective.
         *
         * Preauthorization reference effective period
         */
        preAuthPeriod?: Period;
        /**
         * The reasons for the result of the claim, predetermination, or preauthorization adjudication.
         *
         * Reason for result of the adjudication
         */
        reason?: CodeableConcept[];
        /**
         * The result of the claim, predetermination, or preauthorization adjudication.
         *
         * Result of the adjudication
         */
        decision?: CodeableConcept;
        /**
         * Reference from the Insurer which is used in later communications which refers to this adjudication.
         *
         * Preauthorization reference
         */
        preAuthRef?: string;
        static revive(json: any): ItemReviewOutcomeComponent;
        toJSON(): any;
    }
    class ItemBodySiteComponent extends BackboneElement {
        /**
         * A region or surface of the bodySite, e.g. limb region or tooth surface(s).
         *
         * Sub-location
         */
        subSite?: CodeableConcept[];
        /**
         * Physical service site on the patient (limb, tooth, etc.).
         *
         * Location
         */
        site: CodeableReference[];
        static revive(json: any): ItemBodySiteComponent;
        toJSON(): any;
    }
    class ItemComponent extends BackboneElement {
        /**
         * Request or Referral for Goods or Service to be rendered.
         *
         * Request or Referral for Service
         */
        request?: DeviceRequest[] | MedicationRequest[] | NutritionOrder[] | ServiceRequest[] | SupplyRequest[] | VisionPrescription[] | Reference[];
        /**
         * Item typification or modifiers codes to convey additional context for the product or service.
         *
         * Product or service billing modifiers
         */
        modifier?: CodeableConcept[];
        /**
         * Trace number for tracking purposes. May be defined at the jurisdiction level or between trading partners.
         *
         * Number for tracking
         */
        traceNumber?: Identifier[];
        /**
         * This contains the end of a range of product, service, drug or other billing codes for the item. This element is not used when the .productOrService is a group code. This value may only be present when a .productOfService code has been provided to convey the start of the range. Typically this value may be used only with preauthorizations and not with claims.
         *
         * End of a range of codes
         */
        productOrServiceEnd?: CodeableConcept;
        /**
         * When the value is a group code then this item collects a set of related item details, otherwise this contains the product, service, drug or other billing code for the item. This element may be the start of a range of .productOrService codes used in conjunction with .productOrServiceEnd or it may be a solo element where .productOrServiceEnd is not used.
         *
         * Billing, service, product, or drug code
         */
        productOrService?: CodeableConcept;
        /**
         * The numbers associated with notes below which apply to the adjudication of this item.
         *
         * Applicable note numbers
         */
        noteNumber?: number[];
        /**
         * Exceptions, special conditions and supporting information applicable for this service or product.
         *
         * Applicable exception and supporting information
         */
        informationSequence?: number[];
        /**
         * The type of revenue or cost center providing the product and/or service.
         *
         * Revenue or cost center code
         */
        revenue?: CodeableConcept;
        /**
         * If this item is a group then the values here are a summary of the adjudication of the detail items. If this item is a simple product or service then this is the result of the adjudication of this item.
         *
         * Adjudication details
         */
        adjudication?: ExplanationOfBenefit.AdjudicationComponent[];
        /**
         * Diagnoses applicable for this service or product.
         *
         * Applicable diagnoses
         */
        diagnosisSequence?: number[];
        /**
         * A real number that represents a multiplier used in determining the overall value of services delivered and/or goods received. The concept of a Factor allows for a discount or surcharge multiplier to be applied to a monetary amount.
         *
         * Price scaling factor
         */
        factor?: number;
        /**
         * The total amount claimed for the group (if a grouper) or the line item. Net = unit price * quantity * factor.
         *
         * Total item cost
         */
        net?: Money;
        /**
         * The amount paid by the patient, in total at the claim claim level or specifically for the item and detail level, to the provider for goods and services.
         *
         * Paid by the patient
         */
        patientPaid?: Money;
        /**
         * The number of repetitions of a service or product.
         *
         * Count of products or services
         */
        quantity?: Quantity;
        /**
         * If the item is not a group then this is the fee for the product or service, otherwise this is the total of the fees for the details of the group.
         *
         * Fee, charge or cost per item
         */
        unitPrice?: Money;
        /**
         * Care team members related to this service or product.
         *
         * Applicable care team members
         */
        careTeamSequence?: number[];
        /**
         * Identifies the program under which this may be recovered.
         *
         * Program the product or service is provided under
         */
        programCode?: CodeableConcept[];
        /**
         * The total of taxes applicable for this product or service.
         *
         * Total tax
         */
        tax?: Money;
        /**
         * Healthcare encounters related to this claim.
         *
         * Encounters associated with the listed treatments
         */
        encounter?: Encounter[] | Reference[];
        /**
         * Physical location where the service is performed or applies.
         *
         * Anatomical location
         */
        bodySite?: ExplanationOfBenefit.ItemBodySiteComponent[];
        /**
         * The high-level results of the adjudication if adjudication has been performed.
         *
         * Adjudication results
         */
        reviewOutcome?: ExplanationOfBenefit.ItemReviewOutcomeComponent;
        /**
         * A number to uniquely identify item entries.
         *
         * Item instance identifier
         */
        sequence: number;
        /**
         * The date or dates when the service or product was supplied, performed or completed.
         *
         * Date or dates of service or product delivery
         */
        serviced?: Date | Period;
        /**
         * Where the product or service was provided.
         *
         * Place of service or where product was supplied
         */
        location?: CodeableConcept | Address | Location | Reference;
        /**
         * Unique Device Identifiers associated with this line item.
         *
         * Unique device identifier
         */
        udi?: Device[] | Reference[];
        /**
         * Second-tier of goods and services.
         *
         * Additional items
         */
        detail?: ExplanationOfBenefit.DetailComponent[];
        /**
         * Procedures applicable for this service or product.
         *
         * Applicable procedures
         */
        procedureSequence?: number[];
        /**
         * Code to identify the general type of benefits under which products and services are provided.
         *
         * Benefit classification
         */
        category?: CodeableConcept;
        static revive(json: any): ItemComponent;
        toJSON(): any;
    }
    class AccidentComponent extends BackboneElement {
        /**
         * Date of an accident event  related to the products and services contained in the claim.
         *
         * When the incident occurred
         */
        date?: Date;
        /**
         * The type or context of the accident event for the purposes of selection of potential insurance coverages and determination of coordination between insurers.
         *
         * The nature of the accident
         */
        type?: CodeableConcept;
        /**
         * The physical location of the accident event.
         *
         * Where the event occurred
         */
        location?: Address | Location | Reference;
        static revive(json: any): AccidentComponent;
        toJSON(): any;
    }
    class InsuranceComponent extends BackboneElement {
        /**
         * Reference to the insurance card level information contained in the Coverage resource. The coverage issuing insurer will use these details to locate the patient's actual coverage within the insurer's information system.
         *
         * Insurance information
         */
        coverage: Coverage | Reference;
        /**
         * A flag to indicate that this Coverage is to be used for adjudication of this claim when set to true.
         *
         * Coverage to be used for adjudication
         */
        focal: boolean;
        /**
         * Reference numbers previously provided by the insurer to the provider to be quoted on subsequent claims containing services or products related to the prior authorization.
         *
         * Prior authorization reference number
         */
        preAuthRef?: string[];
        static revive(json: any): InsuranceComponent;
        toJSON(): any;
    }
    class ProcedureComponent extends BackboneElement {
        /**
         * Date and optionally time the procedure was performed.
         *
         * When the procedure was performed
         */
        date?: Date;
        /**
         * A number to uniquely identify procedure entries.
         *
         * Procedure instance identifier
         */
        sequence: number;
        /**
         * The code or reference to a Procedure resource which identifies the clinical intervention performed.
         *
         * Specific clinical procedure
         */
        procedure: CodeableConcept | Procedure | Reference;
        /**
         * Unique Device Identifiers associated with this line item.
         *
         * Unique device identifier
         */
        udi?: Device[] | Reference[];
        /**
         * When the condition was observed or the relative ranking.
         *
         * Category of Procedure
         */
        type?: CodeableConcept[];
        static revive(json: any): ProcedureComponent;
        toJSON(): any;
    }
    class DiagnosisComponent extends BackboneElement {
        /**
         * The nature of illness or problem in a coded form or as a reference to an external defined Condition.
         *
         * Nature of illness or problem
         */
        diagnosis: CodeableConcept | Condition | Reference;
        /**
         * When the condition was observed or the relative ranking.
         *
         * Timing or nature of the diagnosis
         */
        type?: CodeableConcept[];
        /**
         * A number to uniquely identify diagnosis entries.
         *
         * Diagnosis instance identifier
         */
        sequence: number;
        /**
         * Indication of whether the diagnosis was present on admission to a facility.
         *
         * Present on admission
         */
        onAdmission?: CodeableConcept;
        static revive(json: any): DiagnosisComponent;
        toJSON(): any;
    }
    class SupportingInformationComponent extends BackboneElement {
        /**
         * System and code pertaining to the specific information regarding special conditions relating to the setting, treatment or patient  for which care is sought.
         *
         * Type of information
         */
        code?: CodeableConcept;
        /**
         * A number to uniquely identify supporting information entries.
         *
         * Information instance identifier
         */
        sequence: number;
        /**
         * Provides the reason in the situation where a reason code is required in addition to the content.
         *
         * Explanation for the information
         */
        reason?: Coding;
        /**
         * The date when or period to which this information refers.
         *
         * When it occurred
         */
        timing?: Date | Period;
        /**
         * Additional data or information such as resources, documents, images etc. including references to the data or the actual inclusion of the data.
         *
         * Data to be provided
         */
        value?: boolean | string | Quantity | Attachment | Reference | Identifier;
        /**
         * The general class of the information supplied: information; exception; accident, employment; onset, etc.
         *
         * Classification of the supplied information
         */
        category: CodeableConcept;
        static revive(json: any): SupportingInformationComponent;
        toJSON(): any;
    }
    class CareTeamComponent extends BackboneElement {
        /**
         * A number to uniquely identify care team entries.
         *
         * Order of care team
         */
        sequence: number;
        /**
         * The specialization of the practitioner or provider which is applicable for this service.
         *
         * Practitioner or provider specialization
         */
        specialty?: CodeableConcept;
        /**
         * The lead, assisting or supervising practitioner and their discipline if a multidisciplinary team.
         *
         * Function within the team
         */
        role?: CodeableConcept;
        /**
         * Member of the team who provided the product or service.
         *
         * Practitioner or organization
         */
        provider: Practitioner | PractitionerRole | Organization | Reference;
        /**
         * The party who is billing and/or responsible for the claimed products or services.
         *
         * Indicator of the lead practitioner
         */
        responsible?: boolean;
        static revive(json: any): CareTeamComponent;
        toJSON(): any;
    }
    class PayeeComponent extends BackboneElement {
        /**
         * Type of Party to be reimbursed: Subscriber, provider, other.
         *
         * Category of recipient
         */
        type?: CodeableConcept;
        /**
         * Reference to the individual or organization to whom any payment will be made.
         *
         * Recipient reference
         */
        party?: Practitioner | PractitionerRole | Organization | Patient | RelatedPerson | Reference;
        static revive(json: any): PayeeComponent;
        toJSON(): any;
    }
    class ExplanationOfBenefitEventComponent extends BackboneElement {
        /**
         * A date or period in the past or future indicating when the event occurred or is expectd to occur.
         *
         * Occurance date or period
         */
        when: Date | Period;
        /**
         * A coded event such as when a service is expected or a card printed.
         *
         * Specific event
         */
        type: CodeableConcept;
        static revive(json: any): ExplanationOfBenefitEventComponent;
        toJSON(): any;
    }
    class RelatedClaimComponent extends BackboneElement {
        /**
         * Reference to a related claim.
         *
         * Reference to the related claim
         */
        claim?: Claim | Reference;
        /**
         * A code to convey how the claims are related.
         *
         * How the reference claim is related
         */
        relationship?: CodeableConcept;
        /**
         * An alternate organizational reference to the case or file to which this particular claim pertains.
         *
         * File or case reference
         */
        reference?: Identifier;
        static revive(json: any): RelatedClaimComponent;
        toJSON(): any;
    }
}
