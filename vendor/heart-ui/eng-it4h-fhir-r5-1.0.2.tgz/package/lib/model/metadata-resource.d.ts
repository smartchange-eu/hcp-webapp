import { CanonicalResource } from '../model/canonical-resource';
/**
 * HAPI/FHIR <b>MetadataResource</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 */
export declare class MetadataResource extends CanonicalResource {
    readonly resourceType: string;
    static revive(json: any): MetadataResource;
    toJSON(): any;
}
