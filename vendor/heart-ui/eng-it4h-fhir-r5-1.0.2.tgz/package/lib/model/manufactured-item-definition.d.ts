import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { MarketingStatus } from '../datatype/marketing-status';
import { Quantity } from '../datatype/quantity';
import { DomainResource } from '../model/domain-resource';
import { Organization } from '../model/organization';
/**
 * HAPI/FHIR <b>ManufacturedItemDefinition</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ManufacturedItemDefinition">http://hl7.org/fhir/StructureDefinition/ManufacturedItemDefinition</a>
 * </p>
 *
 */
export declare class ManufacturedItemDefinition extends DomainResource {
    /**
     * A descriptive name applied to this item.
     *
     * A descriptive name applied to this item
     */
    name?: string;
    /**
     * General characteristics of this item.
     *
     * General characteristics of this item
     */
    property?: ManufacturedItemDefinition.ManufacturedItemDefinitionPropertyComponent[];
    /**
     * Dose form as manufactured and before any transformation into the pharmaceutical product.
     *
     * Dose form as manufactured (before any necessary transformation)
     */
    manufacturedDoseForm: CodeableConcept;
    /**
     * The status of this item. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * Manufacturer of the item, one of several possible.
     *
     * Manufacturer of the item, one of several possible
     */
    manufacturer?: Organization[] | Reference[];
    /**
     * Allows specifying that an item is on the market for sale, or that it is not available, and the dates and locations associated.
     *
     * Allows specifying that an item is on the market for sale, or that it is not available, and the dates and locations associated
     */
    marketingStatus?: MarketingStatus[];
    /**
     * Physical parts of the manufactured item, that it is intrisically made from. This is distinct from the ingredients that are part of its chemical makeup.
     *
     * Physical parts of the manufactured item, that it is intrisically made from. This is distinct from the ingredients that are part of its chemical makeup
     */
    component?: ManufacturedItemDefinition.ManufacturedItemDefinitionComponentComponent[];
    /**
     * The “real-world” units in which the quantity of the manufactured item is described.
     *
     * The “real-world” units in which the quantity of the item is described
     */
    unitOfPresentation?: CodeableConcept;
    /**
     * The ingredients of this manufactured item. This is only needed if the ingredients are not specified by incoming references from the Ingredient resource.
     *
     * The ingredients of this manufactured item. Only needed if these are not specified by incoming references from the Ingredient resource
     */
    ingredient?: CodeableConcept[];
    /**
     * Unique identifier.
     *
     * Unique identifier
     */
    identifier?: Identifier[];
    readonly resourceType: string;
    static revive(json: any): ManufacturedItemDefinition;
    toJSON(): any;
}
export declare namespace ManufacturedItemDefinition {
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class ManufacturedItemDefinitionComponentConstituentComponent extends BackboneElement {
        /**
         * The function of this constituent within the component e.g. binder.
         *
         * The function of this constituent within the component e.g. binder
         */
        function?: CodeableConcept[];
        /**
         * The measurable amount of the substance, expressable in different ways (e.g. by mass or volume).
         *
         * The measurable amount of the substance, expressable in different ways (e.g. by mass or volume)
         */
        amount?: Quantity[];
        /**
         * The ingredient that is the constituent of the given component.
         *
         * The ingredient that is the constituent of the given component
         */
        hasIngredient?: CodeableReference[];
        /**
         * The physical location of the constituent/ingredient within the component. Example – if the component is the bead in the capsule, then the location would be where the ingredient resides within the product part – intragranular, extra-granular, etc.
         *
         * The physical location of the constituent/ingredient within the component
         */
        location?: CodeableConcept[];
        static revive(json: any): ManufacturedItemDefinitionComponentConstituentComponent;
        toJSON(): any;
    }
    class ManufacturedItemDefinitionComponentComponent extends BackboneElement {
        /**
         * General characteristics of this component.
         *
         * General characteristics of this component
         */
        property?: ManufacturedItemDefinition.ManufacturedItemDefinitionPropertyComponent[];
        /**
         * Defining type of the component e.g. shell, layer, ink.
         *
         * Defining type of the component e.g. shell, layer, ink
         */
        type: CodeableConcept;
        /**
         * The measurable amount of total quantity of all substances in the component, expressable in different ways (e.g. by mass or volume).
         *
         * The measurable amount of total quantity of all substances in the component, expressable in different ways (e.g. by mass or volume)
         */
        amount?: Quantity[];
        /**
         * A component that this component contains or is made from.
         *
         * A component that this component contains or is made from
         */
        component?: ManufacturedItemDefinition.ManufacturedItemDefinitionComponentComponent[];
        /**
         * A reference to a constituent of the manufactured item as a whole, linked here so that its component location within the item can be indicated. This not where the item's ingredient are primarily stated (for which see Ingredient.for or ManufacturedItemDefinition.ingredient).
         *
         * A reference to a constituent of the manufactured item as a whole, linked here so that its component location within the item can be indicated. This not where the item's ingredient are primarily stated (for which see Ingredient.for or ManufacturedItemDefinition.ingredient)
         */
        constituent?: ManufacturedItemDefinition.ManufacturedItemDefinitionComponentConstituentComponent[];
        /**
         * The function of this component within the item e.g. delivers active ingredient, masks taste.
         *
         * The function of this component within the item e.g. delivers active ingredient, masks taste
         */
        function?: CodeableConcept[];
        static revive(json: any): ManufacturedItemDefinitionComponentComponent;
        toJSON(): any;
    }
    class ManufacturedItemDefinitionPropertyComponent extends BackboneElement {
        /**
         * A code expressing the type of characteristic.
         *
         * A code expressing the type of characteristic
         */
        type: CodeableConcept;
        /**
         * A value for the characteristic.
         *
         * A value for the characteristic
         */
        value?: CodeableConcept | Quantity | Date | boolean | string | Attachment;
        static revive(json: any): ManufacturedItemDefinitionPropertyComponent;
        toJSON(): any;
    }
}
