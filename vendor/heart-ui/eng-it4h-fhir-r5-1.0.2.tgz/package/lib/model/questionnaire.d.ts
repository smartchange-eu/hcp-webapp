import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { UsageContext } from '../datatype/usage-context';
import { MetadataResource } from '../model/metadata-resource';
/**
 * HAPI/FHIR <b>Questionnaire</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Questionnaire">http://hl7.org/fhir/StructureDefinition/Questionnaire</a>
 * </p>
 *
 */
export declare class Questionnaire extends MetadataResource {
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the questionnaire.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * A natural language name identifying the questionnaire. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this questionnaire (computer friendly)
     */
    name?: string;
    /**
     * The URL of a Questionnaire that this Questionnaire is based on.
     *
     * Based on Questionnaire
     */
    derivedFrom?: string[];
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate questionnaires.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * The current state of this questionnaire.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * The date on which the resource content was last reviewed. Review happens periodically after approval but does not change the original approval date.
     *
     * When the questionnaire was last reviewed by the publisher
     */
    lastReviewDate?: Date;
    /**
     * A free text natural language description of the questionnaire from a consumer's perspective.
     *
     * Natural language description of the questionnaire
     */
    description?: string;
    /**
     * A Boolean value to indicate that this questionnaire is authored for testing purposes (or education/evaluation/marketing) and is not intended for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * The identifier that is used to identify this version of the questionnaire when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the questionnaire author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the questionnaire
     */
    version?: string;
    /**
     * The types of subjects that can be the subject of responses created for the questionnaire.
     *
     * Resource that can be subject of QuestionnaireResponse
     */
    subjectType?: string[];
    /**
     * A short, descriptive, user-friendly title for the questionnaire.
     *
     * Name for this questionnaire (human friendly)
     */
    title?: string;
    /**
     * An absolute URI that is used to identify this questionnaire when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this questionnaire is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the questionnaire is stored on different servers.
     *
     * Canonical identifier for this questionnaire, represented as an absolute URI (globally unique)
     */
    url?: string;
    /**
     * A formal identifier that is used to identify this questionnaire when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Business identifier for questionnaire
     */
    identifier?: Identifier[];
    /**
     * The date  (and optionally time) when the questionnaire was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the questionnaire changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * The date on which the resource content was approved by the publisher. Approval happens once when the content is officially approved for usage.
     *
     * When the questionnaire was approved by publisher
     */
    approvalDate?: Date;
    /**
     * An identifier for this collection of questions in a particular terminology such as LOINC.
     *
     * Concept that represents the overall questionnaire
     */
    code?: Coding[];
    /**
     * A copyright statement relating to the questionnaire and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the questionnaire.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * A particular question, question grouping or display text that is part of the questionnaire.
     *
     * Questions and sections within the Questionnaire
     */
    item?: Questionnaire.QuestionnaireItemComponent[];
    /**
     * Explanation of why this questionnaire is needed and why it has been designed as it has.
     *
     * Why this questionnaire is defined
     */
    purpose?: string;
    /**
     * The period during which the questionnaire content was or is planned to be in active use.
     *
     * When the questionnaire is expected to be used
     */
    effectivePeriod?: Period;
    /**
     * A legal or geographic region in which the questionnaire is intended to be used.
     *
     * Intended jurisdiction for questionnaire (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    readonly resourceType: string;
    static revive(json: any): Questionnaire;
    toJSON(): any;
}
export declare namespace Questionnaire {
    enum QuestionnaireItemType {
        ATTACHMENT,
        NULL,
        QUANTITY,
        CODING,
        DECIMAL,
        TIME,
        TEXT,
        QUESTION,
        BOOLEAN,
        URL,
        GROUP,
        DATE,
        DISPLAY,
        DATETIME,
        REFERENCE,
        STRING,
        INTEGER
    }
    enum QuestionnaireItemOperator {
        GREATER_OR_EQUAL,
        LESS_OR_EQUAL,
        NULL,
        EXISTS,
        EQUAL,
        GREATER_THAN,
        NOT_EQUAL,
        LESS_THAN
    }
    enum QuestionnaireItemDisabledDisplay {
        NULL,
        HIDDEN,
        PROTECTED
    }
    enum QuestionnaireAnswerConstraint {
        OPTIONSORSTRING,
        NULL,
        OPTIONSONLY,
        OPTIONSORTYPE
    }
    enum EnableWhenBehavior {
        ALL,
        NULL,
        ANY
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class QuestionnaireItemInitialComponent extends BackboneElement {
        /**
         * The actual value to for an initial answer.
         *
         * Actual value for initializing the question
         */
        value: boolean | number | number | Date | Date | Date | string | Attachment | Coding | Quantity | Reference;
        static revive(json: any): QuestionnaireItemInitialComponent;
        toJSON(): any;
    }
    class QuestionnaireItemAnswerOptionComponent extends BackboneElement {
        /**
         * A potential answer that's allowed as the answer to this question.
         *
         * Answer value
         */
        value: number | Date | Date | string | Coding | Reference;
        /**
         * Indicates whether the answer value is selected when the list of possible answers is initially shown.
         *
         * Whether option is selected by default
         */
        initialSelected?: boolean;
        static revive(json: any): QuestionnaireItemAnswerOptionComponent;
        toJSON(): any;
    }
    class QuestionnaireItemEnableWhenComponent extends BackboneElement {
        /**
         * The linkId for the question whose answer (or lack of answer) governs whether this item is enabled.
         *
         * The linkId of question that determines whether item is enabled/disabled
         */
        question: string;
        /**
         * A value that the referenced question is tested using the specified operator in order for the item to be enabled.  If there are multiple answers, a match on any of the answers suffices.  If different behavior is desired (all must match, at least 2 must match, etc.), consider using the enableWhenExpression extension.
         *
         * Value for question comparison based on operator
         */
        answer: boolean | number | number | Date | Date | Date | string | Coding | Quantity | Reference;
        /**
         * Specifies the criteria by which the question is enabled.
         *
         * exists | = | != | > | < | >= | <=
         */
        operator: string;
        static revive(json: any): QuestionnaireItemEnableWhenComponent;
        toJSON(): any;
    }
    class QuestionnaireItemComponent extends BackboneElement {
        /**
         * The name of a section, the text of a question or text content for a display item.
         *
         * Primary text for the item
         */
        text?: string;
        /**
         * Controls how multiple enableWhen values are interpreted -  whether all or any must be true.
         *
         * all | any
         */
        enableBehavior?: string;
        /**
         * This element is a URI that refers to an [ElementDefinition](elementdefinition.html) or to an [ObservationDefinition](observationdefinition.html) that provides information about this item, including information that might otherwise be included in the instance of the Questionnaire resource. A detailed description of the construction of the URI is shown in [Comments](questionnaire.html#definition), below.
         *
         * ElementDefinition - details for the item
         */
        definition?: string;
        /**
         * The maximum number of characters that are permitted in the answer to be considered a "valid" QuestionnaireResponse.
         *
         * No more than these many characters
         */
        maxLength?: number;
        /**
         * A reference to a value set containing a list of values representing permitted answers for a question.
         *
         * ValueSet containing permitted answers
         */
        answerValueSet?: string;
        /**
         * One of the permitted answers for the question.
         *
         * Permitted answer
         */
        answerOption?: Questionnaire.QuestionnaireItemAnswerOptionComponent[];
        /**
         * An identifier that is unique within the Questionnaire allowing linkage to the equivalent item in a QuestionnaireResponse resource.
         *
         * Unique id for item in questionnaire
         */
        linkId: string;
        /**
         * Indicates if and how items that are disabled (because enableWhen evaluates to 'false') should be displayed.
         *
         * hidden | protected
         */
        disabledDisplay?: string;
        /**
         * An indication, when true, that the value cannot be changed by a human respondent to the Questionnaire.
         *
         * Don't allow human editing
         */
        readOnly?: boolean;
        /**
         * An indication, if true, that the item must be present in a "completed" QuestionnaireResponse.  If false, the item may be skipped when answering the questionnaire.
         *
         * Whether the item must be included in data results
         */
        required?: boolean;
        /**
         * The type of questionnaire item this is - whether text for display, a grouping of other items or a particular type of data to be captured (string, integer, Coding, etc.).
         *
         * group | display | boolean | decimal | integer | date | dateTime +
         */
        type: string;
        /**
         * A terminology code that corresponds to this group or question (e.g. a code from LOINC, which defines many questions and answers).
         *
         * Corresponding concept for this item in a terminology
         */
        code?: Coding[];
        /**
         * Text, questions and other groups to be nested beneath a question or group.
         *
         * Nested questionnaire items
         */
        item?: Questionnaire.QuestionnaireItemComponent[];
        /**
         * An indication, if true, that a QuestionnaireResponse for this item may include multiple answers associated with a single instance of this item (for question-type items) or multiple repetitions of the item (for group-type items).
         *
         * Whether the item may repeat
         */
        repeats?: boolean;
        /**
         * A short label for a particular group, question or set of display text within the questionnaire used for reference by the individual completing the questionnaire.
         *
         * E.g. "1(a)", "2.5.3"
         */
        prefix?: string;
        /**
         * For items that have a defined set of allowed answers (via answerOption or answerValueSet), indicates whether values *other* than those specified can be selected.
         *
         * optionsOnly | optionsOrType | optionsOrString
         */
        answerConstraint?: string;
        /**
         * One or more values that should be pre-populated in the answer when initially rendering the questionnaire for user input.
         *
         * Initial value(s) when item is first rendered
         */
        initial?: Questionnaire.QuestionnaireItemInitialComponent[];
        /**
         * A constraint indicating that this item should only be enabled (displayed/allow answers to be captured) when the specified condition is true.
         *
         * Only allow data when
         */
        enableWhen?: Questionnaire.QuestionnaireItemEnableWhenComponent[];
        static revive(json: any): QuestionnaireItemComponent;
        toJSON(): any;
    }
}
