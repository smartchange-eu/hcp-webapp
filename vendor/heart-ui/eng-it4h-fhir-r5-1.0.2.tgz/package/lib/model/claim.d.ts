import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Address } from '../datatype/address';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Money } from '../datatype/money';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { ClaimResponse } from '../model/claim-response';
import { Condition } from '../model/condition';
import { Coverage } from '../model/coverage';
import { Device } from '../model/device';
import { DeviceRequest } from '../model/device-request';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Location } from '../model/location';
import { MedicationRequest } from '../model/medication-request';
import { NutritionOrder } from '../model/nutrition-order';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Procedure } from '../model/procedure';
import { RelatedPerson } from '../model/related-person';
import { ServiceRequest } from '../model/service-request';
import { SupplyRequest } from '../model/supply-request';
import { VisionPrescription } from '../model/vision-prescription';
/**
 * HAPI/FHIR <b>Claim</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Claim">http://hl7.org/fhir/StructureDefinition/Claim</a>
 * </p>
 *
 */
export declare class Claim extends DomainResource {
    /**
     * Facility where the services were provided.
     *
     * Servicing facility
     */
    facility?: Location | Organization | Reference;
    /**
     * The status of the resource instance.
     *
     * active | cancelled | draft | entered-in-error
     */
    status: string;
    /**
     * A finer grained suite of claim type codes which may convey additional information such as Inpatient vs Outpatient and/or a specialty service.
     *
     * More granular claim type
     */
    subType?: CodeableConcept;
    /**
     * Prescription is the document/authorization given to the claim author for them to provide products and services for which consideration (reimbursement) is sought. Could be a RX for medications, an 'order' for oxygen or wheelchair or physiotherapy treatments.
     *
     * Prescription authorizing services and products
     */
    prescription?: DeviceRequest | MedicationRequest | VisionPrescription | Reference;
    /**
     * The period for which charges are being submitted.
     *
     * Relevant time frame for the claim
     */
    billablePeriod?: Period;
    /**
     * The referral information received by the claim author, it is not to be used when the author generates a referral for a patient. A copy of that referral may be provided as supporting information. Some insurers require proof of referral to pay for services or to pay specialist rates for services.
     *
     * Treatment referral
     */
    referral?: ServiceRequest | Reference;
    /**
     * The provider-required urgency of processing the request. Typical values include: stat, normal, deferred.
     *
     * Desired processing urgency
     */
    priority?: CodeableConcept;
    /**
     * Information about diagnoses relevant to the claim items.
     *
     * Pertinent diagnosis information
     */
    diagnosis?: Claim.DiagnosisComponent[];
    /**
     * Original prescription which has been superseded by this prescription to support the dispensing of pharmacy services, medications or products.
     *
     * Original prescription if superseded by fulfiller
     */
    originalPrescription?: DeviceRequest | MedicationRequest | VisionPrescription | Reference;
    /**
     * Healthcare encounters related to this claim.
     *
     * Encounters associated with the listed treatments
     */
    encounter?: Encounter[] | Reference[];
    /**
     * Procedures performed on the patient relevant to the billing items with the claim.
     *
     * Clinical procedures performed
     */
    procedure?: Claim.ProcedureComponent[];
    /**
     * The date this resource was created.
     *
     * Resource creation date
     */
    created: Date;
    /**
     * A unique identifier assigned to this claim.
     *
     * Business Identifier for claim
     */
    identifier?: Identifier[];
    /**
     * The amount paid by the patient, in total at the claim claim level or specifically for the item and detail level, to the provider for goods and services.
     *
     * Paid by the patient
     */
    patientPaid?: Money;
    /**
     * A claim line. Either a simple  product or service or a 'group' of details which can each be a simple items or groups of sub-details.
     *
     * Product or service provided
     */
    item?: Claim.ItemComponent[];
    /**
     * Information code for an event with a corresponding date or period.
     *
     * Event information
     */
    event?: Claim.ClaimEventComponent[];
    /**
     * The members of the team who provided the products and services.
     *
     * Members of the care team
     */
    careTeam?: Claim.CareTeamComponent[];
    /**
     * Individual who created the claim, predetermination or preauthorization.
     *
     * Author of the claim
     */
    enterer?: Practitioner | PractitionerRole | Patient | RelatedPerson | Reference;
    /**
     * The provider which is responsible for the claim, predetermination or preauthorization.
     *
     * Party responsible for the claim
     */
    provider?: Practitioner | PractitionerRole | Organization | Reference;
    /**
     * A code to indicate whether and for whom funds are to be reserved for future claims.
     *
     * For whom to reserve funds
     */
    fundsReserve?: CodeableConcept;
    /**
     * Other claims which are related to this claim such as prior submissions or claims for related services or for the same event.
     *
     * Prior or corollary claims
     */
    related?: Claim.RelatedClaimComponent[];
    /**
     * Additional information codes regarding exceptions, special considerations, the condition, situation, prior or concurrent issues.
     *
     * Supporting information
     */
    supportingInfo?: Claim.SupportingInformationComponent[];
    /**
     * The party to whom the professional services and/or products have been supplied or are being considered and for whom actual or forecast reimbursement is sought.
     *
     * The recipient of the products and services
     */
    patient: Patient | Reference;
    /**
     * The Insurer who is target of the request.
     *
     * Target
     */
    insurer?: Organization | Reference;
    /**
     * The party to be reimbursed for cost of the products and services according to the terms of the policy.
     *
     * Recipient of benefits payable
     */
    payee?: Claim.PayeeComponent;
    /**
     * The total value of the all the items in the claim.
     *
     * Total claim cost
     */
    total?: Money;
    /**
     * The category of claim, e.g. oral, pharmacy, vision, institutional, professional.
     *
     * Category or discipline
     */
    type: CodeableConcept;
    /**
     * Details of an accident which resulted in injuries which required the products and services listed in the claim.
     *
     * Details of the event
     */
    accident?: Claim.AccidentComponent;
    /**
     * A package billing code or bundle code used to group products and services to a particular health condition (such as heart attack) which is based on a predetermined grouping code system.
     *
     * Package billing code
     */
    diagnosisRelatedGroup?: CodeableConcept;
    /**
     * Trace number for tracking purposes. May be defined at the jurisdiction level or between trading partners.
     *
     * Number for tracking
     */
    traceNumber?: Identifier[];
    /**
     * A code to indicate whether the nature of the request is: Claim - A request to an Insurer to adjudicate the supplied charges for health care goods and services under the identified policy and to pay the determined Benefit amount, if any; Preauthorization - A request to an Insurer to adjudicate the supplied proposed future charges for health care goods and services under the identified policy and to approve the services and provide the expected benefit amounts and potentially to reserve funds to pay the benefits when Claims for the indicated services are later submitted; or, Pre-determination - A request to an Insurer to adjudicate the supplied 'what if' charges for health care goods and services under the identified policy and report back what the Benefit payable would be had the services actually been provided.
     *
     * claim | preauthorization | predetermination
     */
    use: string;
    /**
     * Financial instruments for reimbursement for the health care products and services specified on the claim.
     *
     * Patient insurance information
     */
    insurance?: Claim.InsuranceComponent[];
    readonly resourceType: string;
    static revive(json: any): Claim;
    toJSON(): any;
}
export declare namespace Claim {
    enum FinancialResourceStatusCodes {
        CANCELLED,
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        DRAFT
    }
    enum Use {
        NULL,
        PREAUTHORIZATION,
        PREDETERMINATION,
        CLAIM
    }
    class SubDetailComponent extends BackboneElement {
        /**
         * If the item is not a group then this is the fee for the product or service, otherwise this is the total of the fees for the details of the group.
         *
         * Fee, charge or cost per item
         */
        unitPrice?: Money;
        /**
         * The amount paid by the patient, in total at the claim claim level or specifically for the item and detail level, to the provider for goods and services.
         *
         * Paid by the patient
         */
        patientPaid?: Money;
        /**
         * The number of repetitions of a service or product.
         *
         * Count of products or services
         */
        quantity?: Quantity;
        /**
         * Identifies the program under which this may be recovered.
         *
         * Program the product or service is provided under
         */
        programCode?: CodeableConcept[];
        /**
         * Trace number for tracking purposes. May be defined at the jurisdiction level or between trading partners.
         *
         * Number for tracking
         */
        traceNumber?: Identifier[];
        /**
         * This contains the end of a range of product, service, drug or other billing codes for the item. This element is not used when the .productOrService is a group code. This value may only be present when a .productOfService code has been provided to convey the start of the range. Typically this value may be used only with preauthorizations and not with claims.
         *
         * End of a range of codes
         */
        productOrServiceEnd?: CodeableConcept;
        /**
         * Item typification or modifiers codes to convey additional context for the product or service.
         *
         * Service/Product billing modifiers
         */
        modifier?: CodeableConcept[];
        /**
         * When the value is a group code then this item collects a set of related item details, otherwise this contains the product, service, drug or other billing code for the item. This element may be the start of a range of .productOrService codes used in conjunction with .productOrServiceEnd or it may be a solo element where .productOrServiceEnd is not used.
         *
         * Billing, service, product, or drug code
         */
        productOrService?: CodeableConcept;
        /**
         * The total of taxes applicable for this product or service.
         *
         * Total tax
         */
        tax?: Money;
        /**
         * A number to uniquely identify item entries.
         *
         * Item instance identifier
         */
        sequence: number;
        /**
         * The type of revenue or cost center providing the product and/or service.
         *
         * Revenue or cost center code
         */
        revenue?: CodeableConcept;
        /**
         * Unique Device Identifiers associated with this line item.
         *
         * Unique device identifier
         */
        udi?: Device[] | Reference[];
        /**
         * Code to identify the general type of benefits under which products and services are provided.
         *
         * Benefit classification
         */
        category?: CodeableConcept;
        /**
         * A real number that represents a multiplier used in determining the overall value of services delivered and/or goods received. The concept of a Factor allows for a discount or surcharge multiplier to be applied to a monetary amount.
         *
         * Price scaling factor
         */
        factor?: number;
        /**
         * The total amount claimed for line item.detail.subDetail. Net = unit price * quantity * factor.
         *
         * Total item cost
         */
        net?: Money;
        static revive(json: any): SubDetailComponent;
        toJSON(): any;
    }
    class DetailComponent extends BackboneElement {
        /**
         * Item typification or modifiers codes to convey additional context for the product or service.
         *
         * Service/Product billing modifiers
         */
        modifier?: CodeableConcept[];
        /**
         * Identifies the program under which this may be recovered.
         *
         * Program the product or service is provided under
         */
        programCode?: CodeableConcept[];
        /**
         * Trace number for tracking purposes. May be defined at the jurisdiction level or between trading partners.
         *
         * Number for tracking
         */
        traceNumber?: Identifier[];
        /**
         * This contains the end of a range of product, service, drug or other billing codes for the item. This element is not used when the .productOrService is a group code. This value may only be present when a .productOfService code has been provided to convey the start of the range. Typically this value may be used only with preauthorizations and not with claims.
         *
         * End of a range of codes
         */
        productOrServiceEnd?: CodeableConcept;
        /**
         * The amount paid by the patient, in total at the claim claim level or specifically for the item and detail level, to the provider for goods and services.
         *
         * Paid by the patient
         */
        patientPaid?: Money;
        /**
         * The number of repetitions of a service or product.
         *
         * Count of products or services
         */
        quantity?: Quantity;
        /**
         * If the item is not a group then this is the fee for the product or service, otherwise this is the total of the fees for the details of the group.
         *
         * Fee, charge or cost per item
         */
        unitPrice?: Money;
        /**
         * When the value is a group code then this item collects a set of related item details, otherwise this contains the product, service, drug or other billing code for the item. This element may be the start of a range of .productOrService codes used in conjunction with .productOrServiceEnd or it may be a solo element where .productOrServiceEnd is not used.
         *
         * Billing, service, product, or drug code
         */
        productOrService?: CodeableConcept;
        /**
         * The total of taxes applicable for this product or service.
         *
         * Total tax
         */
        tax?: Money;
        /**
         * A claim detail line. Either a simple (a product or service) or a 'group' of sub-details which are simple items.
         *
         * Product or service provided
         */
        subDetail?: Claim.SubDetailComponent[];
        /**
         * The type of revenue or cost center providing the product and/or service.
         *
         * Revenue or cost center code
         */
        revenue?: CodeableConcept;
        /**
         * A number to uniquely identify item entries.
         *
         * Item instance identifier
         */
        sequence: number;
        /**
         * Code to identify the general type of benefits under which products and services are provided.
         *
         * Benefit classification
         */
        category?: CodeableConcept;
        /**
         * A real number that represents a multiplier used in determining the overall value of services delivered and/or goods received. The concept of a Factor allows for a discount or surcharge multiplier to be applied to a monetary amount.
         *
         * Price scaling factor
         */
        factor?: number;
        /**
         * The total amount claimed for the group (if a grouper) or the line item.detail. Net = unit price * quantity * factor.
         *
         * Total item cost
         */
        net?: Money;
        /**
         * Unique Device Identifiers associated with this line item.
         *
         * Unique device identifier
         */
        udi?: Device[] | Reference[];
        static revive(json: any): DetailComponent;
        toJSON(): any;
    }
    class BodySiteComponent extends BackboneElement {
        /**
         * Physical service site on the patient (limb, tooth, etc.).
         *
         * Location
         */
        site: CodeableReference[];
        /**
         * A region or surface of the bodySite, e.g. limb region or tooth surface(s).
         *
         * Sub-location
         */
        subSite?: CodeableConcept[];
        static revive(json: any): BodySiteComponent;
        toJSON(): any;
    }
    class ItemComponent extends BackboneElement {
        /**
         * Exceptions, special conditions and supporting information applicable for this service or product.
         *
         * Applicable exception and supporting information
         */
        informationSequence?: number[];
        /**
         * The type of revenue or cost center providing the product and/or service.
         *
         * Revenue or cost center code
         */
        revenue?: CodeableConcept;
        /**
         * Diagnosis applicable for this service or product.
         *
         * Applicable diagnoses
         */
        diagnosisSequence?: number[];
        /**
         * A real number that represents a multiplier used in determining the overall value of services delivered and/or goods received. The concept of a Factor allows for a discount or surcharge multiplier to be applied to a monetary amount.
         *
         * Price scaling factor
         */
        factor?: number;
        /**
         * The total amount claimed for the group (if a grouper) or the line item. Net = unit price * quantity * factor.
         *
         * Total item cost
         */
        net?: Money;
        /**
         * Request or Referral for Goods or Service to be rendered.
         *
         * Request or Referral for Service
         */
        request?: DeviceRequest[] | MedicationRequest[] | NutritionOrder[] | ServiceRequest[] | SupplyRequest[] | VisionPrescription[] | Reference[];
        /**
         * Trace number for tracking purposes. May be defined at the jurisdiction level or between trading partners.
         *
         * Number for tracking
         */
        traceNumber?: Identifier[];
        /**
         * This contains the end of a range of product, service, drug or other billing codes for the item. This element is not used when the .productOrService is a group code. This value may only be present when a .productOfService code has been provided to convey the start of the range. Typically this value may be used only with preauthorizations and not with claims.
         *
         * End of a range of codes
         */
        productOrServiceEnd?: CodeableConcept;
        /**
         * Item typification or modifiers codes to convey additional context for the product or service.
         *
         * Product or service billing modifiers
         */
        modifier?: CodeableConcept[];
        /**
         * When the value is a group code then this item collects a set of related item details, otherwise this contains the product, service, drug or other billing code for the item. This element may be the start of a range of .productOrService codes used in conjunction with .productOrServiceEnd or it may be a solo element where .productOrServiceEnd is not used.
         *
         * Billing, service, product, or drug code
         */
        productOrService?: CodeableConcept;
        /**
         * A number to uniquely identify item entries.
         *
         * Item instance identifier
         */
        sequence: number;
        /**
         * Physical location where the service is performed or applies.
         *
         * Anatomical location
         */
        bodySite?: Claim.BodySiteComponent[];
        /**
         * The date or dates when the service or product was supplied, performed or completed.
         *
         * Date or dates of service or product delivery
         */
        serviced?: Date | Period;
        /**
         * Where the product or service was provided.
         *
         * Place of service or where product was supplied
         */
        location?: CodeableConcept | Address | Location | Reference;
        /**
         * Unique Device Identifiers associated with this line item.
         *
         * Unique device identifier
         */
        udi?: Device[] | Reference[];
        /**
         * A claim detail line. Either a simple (a product or service) or a 'group' of sub-details which are simple items.
         *
         * Product or service provided
         */
        detail?: Claim.DetailComponent[];
        /**
         * Procedures applicable for this service or product.
         *
         * Applicable procedures
         */
        procedureSequence?: number[];
        /**
         * Code to identify the general type of benefits under which products and services are provided.
         *
         * Benefit classification
         */
        category?: CodeableConcept;
        /**
         * If the item is not a group then this is the fee for the product or service, otherwise this is the total of the fees for the details of the group.
         *
         * Fee, charge or cost per item
         */
        unitPrice?: Money;
        /**
         * The amount paid by the patient, in total at the claim claim level or specifically for the item and detail level, to the provider for goods and services.
         *
         * Paid by the patient
         */
        patientPaid?: Money;
        /**
         * The number of repetitions of a service or product.
         *
         * Count of products or services
         */
        quantity?: Quantity;
        /**
         * Identifies the program under which this may be recovered.
         *
         * Program the product or service is provided under
         */
        programCode?: CodeableConcept[];
        /**
         * CareTeam members related to this service or product.
         *
         * Applicable careTeam members
         */
        careTeamSequence?: number[];
        /**
         * The total of taxes applicable for this product or service.
         *
         * Total tax
         */
        tax?: Money;
        /**
         * Healthcare encounters related to this claim.
         *
         * Encounters associated with the listed treatments
         */
        encounter?: Encounter[] | Reference[];
        static revive(json: any): ItemComponent;
        toJSON(): any;
    }
    class AccidentComponent extends BackboneElement {
        /**
         * Date of an accident event  related to the products and services contained in the claim.
         *
         * When the incident occurred
         */
        date: Date;
        /**
         * The type or context of the accident event for the purposes of selection of potential insurance coverages and determination of coordination between insurers.
         *
         * The nature of the accident
         */
        type?: CodeableConcept;
        /**
         * The physical location of the accident event.
         *
         * Where the event occurred
         */
        location?: Address | Location | Reference;
        static revive(json: any): AccidentComponent;
        toJSON(): any;
    }
    class InsuranceComponent extends BackboneElement {
        /**
         * Reference to the insurance card level information contained in the Coverage resource. The coverage issuing insurer will use these details to locate the patient's actual coverage within the insurer's information system.
         *
         * Insurance information
         */
        coverage: Coverage | Reference;
        /**
         * A number to uniquely identify insurance entries and provide a sequence of coverages to convey coordination of benefit order.
         *
         * Insurance instance identifier
         */
        sequence: number;
        /**
         * The business identifier to be used when the claim is sent for adjudication against this insurance policy.
         *
         * Pre-assigned Claim number
         */
        identifier?: Identifier;
        /**
         * A flag to indicate that this Coverage is to be used for adjudication of this claim when set to true.
         *
         * Coverage to be used for adjudication
         */
        focal: boolean;
        /**
         * A business agreement number established between the provider and the insurer for special business processing purposes.
         *
         * Additional provider contract number
         */
        businessArrangement?: string;
        /**
         * The result of the adjudication of the line items for the Coverage specified in this insurance.
         *
         * Adjudication results
         */
        claimResponse?: ClaimResponse | Reference;
        /**
         * Reference numbers previously provided by the insurer to the provider to be quoted on subsequent claims containing services or products related to the prior authorization.
         *
         * Prior authorization reference number
         */
        preAuthRef?: string[];
        static revive(json: any): InsuranceComponent;
        toJSON(): any;
    }
    class ProcedureComponent extends BackboneElement {
        /**
         * A number to uniquely identify procedure entries.
         *
         * Procedure instance identifier
         */
        sequence: number;
        /**
         * Date and optionally time the procedure was performed.
         *
         * When the procedure was performed
         */
        date?: Date;
        /**
         * The code or reference to a Procedure resource which identifies the clinical intervention performed.
         *
         * Specific clinical procedure
         */
        procedure: CodeableConcept | Procedure | Reference;
        /**
         * Unique Device Identifiers associated with this line item.
         *
         * Unique device identifier
         */
        udi?: Device[] | Reference[];
        /**
         * When the condition was observed or the relative ranking.
         *
         * Category of Procedure
         */
        type?: CodeableConcept[];
        static revive(json: any): ProcedureComponent;
        toJSON(): any;
    }
    class DiagnosisComponent extends BackboneElement {
        /**
         * The nature of illness or problem in a coded form or as a reference to an external defined Condition.
         *
         * Nature of illness or problem
         */
        diagnosis: CodeableConcept | Condition | Reference;
        /**
         * When the condition was observed or the relative ranking.
         *
         * Timing or nature of the diagnosis
         */
        type?: CodeableConcept[];
        /**
         * A number to uniquely identify diagnosis entries.
         *
         * Diagnosis instance identifier
         */
        sequence: number;
        /**
         * Indication of whether the diagnosis was present on admission to a facility.
         *
         * Present on admission
         */
        onAdmission?: CodeableConcept;
        static revive(json: any): DiagnosisComponent;
        toJSON(): any;
    }
    class SupportingInformationComponent extends BackboneElement {
        /**
         * The date when or period to which this information refers.
         *
         * When it occurred
         */
        timing?: Date | Period;
        /**
         * System and code pertaining to the specific information regarding special conditions relating to the setting, treatment or patient  for which care is sought.
         *
         * Type of information
         */
        code?: CodeableConcept;
        /**
         * A number to uniquely identify supporting information entries.
         *
         * Information instance identifier
         */
        sequence: number;
        /**
         * Provides the reason in the situation where a reason code is required in addition to the content.
         *
         * Explanation for the information
         */
        reason?: CodeableConcept;
        /**
         * Additional data or information such as resources, documents, images etc. including references to the data or the actual inclusion of the data.
         *
         * Data to be provided
         */
        value?: boolean | string | Quantity | Attachment | Reference | Identifier;
        /**
         * The general class of the information supplied: information; exception; accident, employment; onset, etc.
         *
         * Classification of the supplied information
         */
        category: CodeableConcept;
        static revive(json: any): SupportingInformationComponent;
        toJSON(): any;
    }
    class CareTeamComponent extends BackboneElement {
        /**
         * A number to uniquely identify care team entries.
         *
         * Order of care team
         */
        sequence: number;
        /**
         * The specialization of the practitioner or provider which is applicable for this service.
         *
         * Practitioner or provider specialization
         */
        specialty?: CodeableConcept;
        /**
         * The lead, assisting or supervising practitioner and their discipline if a multidisciplinary team.
         *
         * Function within the team
         */
        role?: CodeableConcept;
        /**
         * Member of the team who provided the product or service.
         *
         * Practitioner or organization
         */
        provider: Practitioner | PractitionerRole | Organization | Reference;
        /**
         * The party who is billing and/or responsible for the claimed products or services.
         *
         * Indicator of the lead practitioner
         */
        responsible?: boolean;
        static revive(json: any): CareTeamComponent;
        toJSON(): any;
    }
    class ClaimEventComponent extends BackboneElement {
        /**
         * A coded event such as when a service is expected or a card printed.
         *
         * Specific event
         */
        type: CodeableConcept;
        /**
         * A date or period in the past or future indicating when the event occurred or is expectd to occur.
         *
         * Occurance date or period
         */
        when: Date | Period;
        static revive(json: any): ClaimEventComponent;
        toJSON(): any;
    }
    class PayeeComponent extends BackboneElement {
        /**
         * Reference to the individual or organization to whom any payment will be made.
         *
         * Recipient reference
         */
        party?: Practitioner | PractitionerRole | Organization | Patient | RelatedPerson | Reference;
        /**
         * Type of Party to be reimbursed: subscriber, provider, other.
         *
         * Category of recipient
         */
        type: CodeableConcept;
        static revive(json: any): PayeeComponent;
        toJSON(): any;
    }
    class RelatedClaimComponent extends BackboneElement {
        /**
         * Reference to a related claim.
         *
         * Reference to the related claim
         */
        claim?: Claim | Reference;
        /**
         * A code to convey how the claims are related.
         *
         * How the reference claim is related
         */
        relationship?: CodeableConcept;
        /**
         * An alternate organizational reference to the case or file to which this particular claim pertains.
         *
         * File or case reference
         */
        reference?: Identifier;
        static revive(json: any): RelatedClaimComponent;
        toJSON(): any;
    }
}
