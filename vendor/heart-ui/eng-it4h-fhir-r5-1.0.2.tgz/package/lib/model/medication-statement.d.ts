import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Dosage } from '../datatype/dosage';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Timing } from '../datatype/timing';
import { Condition } from '../model/condition';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Group } from '../model/group';
import { Observation } from '../model/observation';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Procedure } from '../model/procedure';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>MedicationStatement</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/MedicationStatement">http://hl7.org/fhir/StructureDefinition/MedicationStatement</a>
 * </p>
 *
 */
export declare class MedicationStatement extends DomainResource {
    /**
     * A code representing the status of recording the medication statement.
     *
     * recorded | entered-in-error | draft
     */
    status: string;
    /**
     * Type of medication statement (for example, drug classification like ATC, where meds would be administered, legal category of the medication.).
     *
     * Type of medication statement
     */
    category?: CodeableConcept[];
    /**
     * The date when the Medication Statement was asserted by the information source.
     *
     * When the usage was asserted?
     */
    dateAsserted?: Date;
    /**
     * Allows linking the MedicationStatement to the underlying MedicationRequest, or to other information that supports or is used to derive the MedicationStatement.
     *
     * Link to information used to derive the MedicationStatement
     */
    derivedFrom?: Reference[];
    /**
     * The full representation of the dose of the medication included in all dosage instructions.  To be used when multiple dosage instructions are included to represent complex dosing such as increasing or tapering doses.
     *
     * Full representation of the dosage instructions
     */
    renderedDosageInstruction?: string;
    /**
     * The person or organization that provided the information about the taking of this medication. Note: Use derivedFrom when a MedicationStatement is derived from other resources, e.g. Claim or MedicationRequest.
     *
     * Person or organization that provided the information about the taking of this medication
     */
    informationSource?: Patient[] | Practitioner[] | PractitionerRole[] | RelatedPerson[] | Organization[] | Reference[];
    /**
     * The interval of time during which it is being asserted that the patient is/was/will be taking the medication (or was not taking, when the MedicationStatement.adherence element is Not Taking).
     *
     * The date/time or interval when the medication is/was/will be taken
     */
    effective?: Date | Period | Timing;
    /**
     * Identifies the medication being administered. This is either a link to a resource representing the details of the medication or a simple attribute carrying a code that identifies the medication from a known list of medications.
     *
     * What medication was taken
     */
    medication: CodeableReference;
    /**
     * The encounter that establishes the context for this MedicationStatement.
     *
     * Encounter associated with MedicationStatement
     */
    encounter?: Encounter | Reference;
    /**
     * The person, animal or group who is/was taking the medication.
     *
     * Who is/was taking  the medication
     */
    subject: Patient | Group | Reference;
    /**
     * Indicates whether the medication is or is not being consumed or administered.
     *
     * Indicates whether the medication is or is not being consumed or administered
     */
    adherence?: MedicationStatement.MedicationStatementAdherenceComponent;
    /**
     * Link to information that is relevant to a medication statement, for example, illicit drug use, gestational age, etc.
     *
     * Link to information relevant to the usage of a medication
     */
    relatedClinicalInformation?: Observation[] | Condition[] | Reference[];
    /**
     * Identifiers associated with this Medication Statement that are defined by business processes and/or used to refer to it when a direct URL reference to the resource itself is not appropriate. They are business identifiers assigned to this resource by the performer or other systems and remain constant as the resource is updated and propagates from server to server.
     *
     * External identifier
     */
    identifier?: Identifier[];
    /**
     * A larger event of which this particular MedicationStatement is a component or step.
     *
     * Part of referenced event
     */
    partOf?: Procedure[] | MedicationStatement[] | Reference[];
    /**
     * A concept, Condition or observation that supports why the medication is being/was taken.
     *
     * Reason for why the medication is being/was taken
     */
    reason?: CodeableReference[];
    /**
     * Provides extra information about the Medication Statement that is not conveyed by the other attributes.
     *
     * Further information about the usage
     */
    note?: Annotation[];
    /**
     * Indicates how the medication is/was or should be taken by the patient.
     *
     * Details of how medication is/was taken or should be taken
     */
    dosage?: Dosage[];
    readonly resourceType: string;
    static revive(json: any): MedicationStatement;
    toJSON(): any;
}
export declare namespace MedicationStatement {
    enum MedicationStatementStatusCodes {
        ENTEREDINERROR,
        RECORDED,
        NULL,
        DRAFT
    }
    class MedicationStatementAdherenceComponent extends BackboneElement {
        /**
         * Type of the adherence for the medication.
         *
         * Type of adherence
         */
        code: CodeableConcept;
        /**
         * Captures the reason for the current use or adherence of a medication.
         *
         * Details of the reason for the current use of the medication
         */
        reason?: CodeableConcept;
        static revive(json: any): MedicationStatementAdherenceComponent;
        toJSON(): any;
    }
}
