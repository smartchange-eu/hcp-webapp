import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Address } from '../datatype/address';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Money } from '../datatype/money';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Claim } from '../model/claim';
import { CommunicationRequest } from '../model/communication-request';
import { Coverage } from '../model/coverage';
import { DeviceRequest } from '../model/device-request';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { Location } from '../model/location';
import { MedicationRequest } from '../model/medication-request';
import { NutritionOrder } from '../model/nutrition-order';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { ServiceRequest } from '../model/service-request';
import { SupplyRequest } from '../model/supply-request';
import { VisionPrescription } from '../model/vision-prescription';
/**
 * HAPI/FHIR <b>ClaimResponse</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ClaimResponse">http://hl7.org/fhir/StructureDefinition/ClaimResponse</a>
 * </p>
 *
 */
export declare class ClaimResponse extends DomainResource {
    /**
     * A package billing code or bundle code used to group products and services to a particular health condition (such as heart attack) which is based on a predetermined grouping code system.
     *
     * Package billing code
     */
    diagnosisRelatedGroup?: CodeableConcept;
    /**
     * Reference from the Insurer which is used in later communications which refers to this adjudication.
     *
     * Preauthorization reference
     */
    preAuthRef?: string;
    /**
     * A note that describes or explains adjudication results in a human readable form.
     *
     * Note concerning adjudication
     */
    processNote?: ClaimResponse.NoteComponent[];
    /**
     * A finer grained suite of claim type codes which may convey additional information such as Inpatient vs Outpatient and/or a specialty service.
     *
     * More granular claim type
     */
    type: CodeableConcept;
    /**
     * Errors encountered during the processing of the adjudication.
     *
     * Processing errors
     */
    error?: ClaimResponse.ErrorComponent[];
    /**
     * Original request resource reference.
     *
     * Id of resource triggering adjudication
     */
    request?: Claim | Reference;
    /**
     * Financial instruments for reimbursement for the health care products and services specified on the claim.
     *
     * Patient insurance information
     */
    insurance?: ClaimResponse.InsuranceComponent[];
    /**
     * Type of Party to be reimbursed: subscriber, provider, other.
     *
     * Party to be paid any benefits payable
     */
    payeeType?: CodeableConcept;
    /**
     * A code to indicate whether the nature of the request is: Claim - A request to an Insurer to adjudicate the supplied charges for health care goods and services under the identified policy and to pay the determined Benefit amount, if any; Preauthorization - A request to an Insurer to adjudicate the supplied proposed future charges for health care goods and services under the identified policy and to approve the services and provide the expected benefit amounts and potentially to reserve funds to pay the benefits when Claims for the indicated services are later submitted; or, Pre-determination - A request to an Insurer to adjudicate the supplied 'what if' charges for health care goods and services under the identified policy and report back what the Benefit payable would be had the services actually been provided.
     *
     * claim | preauthorization | predetermination
     */
    use: string;
    /**
     * Trace number for tracking purposes. May be defined at the jurisdiction level or between trading partners.
     *
     * Number for tracking
     */
    traceNumber?: Identifier[];
    /**
     * Payment details for the adjudication of the claim.
     *
     * Payment Details
     */
    payment?: ClaimResponse.PaymentComponent;
    /**
     * Request for additional supporting or authorizing information.
     *
     * Request for additional information
     */
    communicationRequest?: CommunicationRequest[] | Reference[];
    /**
     * The outcome of the claim, predetermination, or preauthorization processing.
     *
     * queued | complete | error | partial
     */
    outcome: string;
    /**
     * Information code for an event with a corresponding date or period.
     *
     * Event information
     */
    event?: ClaimResponse.ClaimResponseEventComponent[];
    /**
     * Categorized monetary totals for the adjudication.
     *
     * Adjudication totals
     */
    total?: ClaimResponse.TotalComponent[];
    /**
     * The first-tier service adjudications for payor added product or service lines.
     *
     * Insurer added line items
     */
    addItem?: ClaimResponse.AddedItemComponent[];
    /**
     * The adjudication results which are presented at the header level rather than at the line-item or add-item levels.
     *
     * Header-level adjudication
     */
    adjudication?: ClaimResponse.AdjudicationComponent[];
    /**
     * The party to whom the professional services and/or products have been supplied or are being considered and for whom actual for facast reimbursement is sought.
     *
     * The recipient of the products and services
     */
    patient: Patient | Reference;
    /**
     * The party responsible for authorization, adjudication and reimbursement.
     *
     * Party responsible for reimbursement
     */
    insurer?: Organization | Reference;
    /**
     * A code, used only on a response to a preauthorization, to indicate whether the benefits payable have been reserved and for whom.
     *
     * Funds reserved status
     */
    fundsReserve?: CodeableConcept;
    /**
     * Healthcare encounters related to this claim.
     *
     * Encounters associated with the listed treatments
     */
    encounter?: Encounter[] | Reference[];
    /**
     * The provider which is responsible for the claim, predetermination or preauthorization.
     *
     * Party responsible for the claim
     */
    requestor?: Practitioner | PractitionerRole | Organization | Reference;
    /**
     * The time frame during which this authorization is effective.
     *
     * Preauthorization reference effective period
     */
    preAuthPeriod?: Period;
    /**
     * A claim line. Either a simple (a product or service) or a 'group' of details which can also be a simple items or groups of sub-details.
     *
     * Adjudication for claim line items
     */
    item?: ClaimResponse.ItemComponent[];
    /**
     * A unique identifier assigned to this claim response.
     *
     * Business Identifier for a claim response
     */
    identifier?: Identifier[];
    /**
     * The date this resource was created.
     *
     * Response creation date
     */
    created: Date;
    /**
     * A code for the form to be used for printing the content.
     *
     * Printed form identifier
     */
    formCode?: CodeableConcept;
    /**
     * The result of the claim, predetermination, or preauthorization adjudication.
     *
     * Result of the adjudication
     */
    decision?: CodeableConcept;
    /**
     * A finer grained suite of claim type codes which may convey additional information such as Inpatient vs Outpatient and/or a specialty service.
     *
     * More granular claim type
     */
    subType?: CodeableConcept;
    /**
     * The status of the resource instance.
     *
     * active | cancelled | draft | entered-in-error
     */
    status: string;
    /**
     * A human readable description of the status of the adjudication.
     *
     * Disposition Message
     */
    disposition?: string;
    /**
     * The actual form, by reference or inclusion, for printing the content or an EOB.
     *
     * Printed reference or actual form
     */
    form?: Attachment;
    readonly resourceType: string;
    static revive(json: any): ClaimResponse;
    toJSON(): any;
}
export declare namespace ClaimResponse {
    enum FinancialResourceStatusCodes {
        CANCELLED,
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        DRAFT
    }
    enum Use {
        NULL,
        PREAUTHORIZATION,
        PREDETERMINATION,
        CLAIM
    }
    enum ClaimProcessingCodes {
        COMPLETE,
        NULL,
        QUEUED,
        PARTIAL,
        ERROR
    }
    class ErrorComponent extends BackboneElement {
        /**
         * The sequence number of the detail within the line item submitted which contains the error. This value is omitted when the error occurs outside of the item structure.
         *
         * Detail sequence number
         */
        detailSequence?: number;
        /**
         * An error code, from a specified code system, which details why the claim could not be adjudicated.
         *
         * Error code detailing processing issues
         */
        code: CodeableConcept;
        /**
         * A [simple subset of FHIRPath](fhirpath.html#simple) limited to element names, repetition indicators and the default child accessor that identifies one of the elements in the resource that caused this issue to be raised.
         *
         * FHIRPath of element(s) related to issue
         */
        expression?: string[];
        /**
         * The sequence number of the sub-detail within the detail within the line item submitted which contains the error. This value is omitted when the error occurs outside of the item structure.
         *
         * Subdetail sequence number
         */
        subDetailSequence?: number;
        /**
         * The sequence number of the line item submitted which contains the error. This value is omitted when the error occurs outside of the item structure.
         *
         * Item sequence number
         */
        itemSequence?: number;
        static revive(json: any): ErrorComponent;
        toJSON(): any;
    }
    class InsuranceComponent extends BackboneElement {
        /**
         * A flag to indicate that this Coverage is to be used for adjudication of this claim when set to true.
         *
         * Coverage to be used for adjudication
         */
        focal: boolean;
        /**
         * A business agreement number established between the provider and the insurer for special business processing purposes.
         *
         * Additional provider contract number
         */
        businessArrangement?: string;
        /**
         * The result of the adjudication of the line items for the Coverage specified in this insurance.
         *
         * Adjudication results
         */
        claimResponse?: ClaimResponse | Reference;
        /**
         * Reference to the insurance card level information contained in the Coverage resource. The coverage issuing insurer will use these details to locate the patient's actual coverage within the insurer's information system.
         *
         * Insurance information
         */
        coverage: Coverage | Reference;
        /**
         * A number to uniquely identify insurance entries and provide a sequence of coverages to convey coordination of benefit order.
         *
         * Insurance instance identifier
         */
        sequence: number;
        static revive(json: any): InsuranceComponent;
        toJSON(): any;
    }
    class NoteComponent extends BackboneElement {
        /**
         * The business purpose of the note text.
         *
         * Note purpose
         */
        type?: CodeableConcept;
        /**
         * A code to define the language used in the text of the note.
         *
         * Language of the text
         */
        language?: CodeableConcept;
        /**
         * The explanation or description associated with the processing.
         *
         * Note explanatory text
         */
        text: string;
        /**
         * A number to uniquely identify a note entry.
         *
         * Note instance identifier
         */
        number?: number;
        static revive(json: any): NoteComponent;
        toJSON(): any;
    }
    class PaymentComponent extends BackboneElement {
        /**
         * Reason for the payment adjustment.
         *
         * Explanation for the adjustment
         */
        adjustmentReason?: CodeableConcept;
        /**
         * Benefits payable less any payment adjustment.
         *
         * Payable amount after adjustment
         */
        amount: Money;
        /**
         * Estimated date the payment will be issued or the actual issue date of payment.
         *
         * Expected date of payment
         */
        date?: Date;
        /**
         * Issuer's unique identifier for the payment instrument.
         *
         * Business identifier for the payment
         */
        identifier?: Identifier;
        /**
         * Total amount of all adjustments to this payment included in this transaction which are not related to this claim's adjudication.
         *
         * Payment adjustment for non-claim issues
         */
        adjustment?: Money;
        /**
         * Whether this represents partial or complete payment of the benefits payable.
         *
         * Partial or complete payment
         */
        type: CodeableConcept;
        static revive(json: any): PaymentComponent;
        toJSON(): any;
    }
    class TotalComponent extends BackboneElement {
        /**
         * A code to indicate the information type of this adjudication record. Information types may include: the value submitted, maximum values or percentages allowed or payable under the plan, amounts that the patient is responsible for in aggregate or pertaining to this item, amounts paid by other coverages, and the benefit payable for this item.
         *
         * Type of adjudication information
         */
        category: CodeableConcept;
        /**
         * Monetary total amount associated with the category.
         *
         * Financial total for the category
         */
        amount: Money;
        static revive(json: any): TotalComponent;
        toJSON(): any;
    }
    class AddedItemSubDetailComponent extends BackboneElement {
        /**
         * A real number that represents a multiplier used in determining the overall value of services delivered and/or goods received. The concept of a Factor allows for a discount or surcharge multiplier to be applied to a monetary amount.
         *
         * Price scaling factor
         */
        factor?: number;
        /**
         * The total amount claimed for the addItem.detail.subDetail. Net = unit price * quantity * factor.
         *
         * Total item cost
         */
        net?: Money;
        /**
         * The adjudication results.
         *
         * Added items subdetail adjudication
         */
        adjudication?: ClaimResponse.AdjudicationComponent[];
        /**
         * The high-level results of the adjudication if adjudication has been performed.
         *
         * Added items subdetail level adjudication results
         */
        reviewOutcome?: ClaimResponse.ReviewOutcomeComponent;
        /**
         * The type of revenue or cost center providing the product and/or service.
         *
         * Revenue or cost center code
         */
        revenue?: CodeableConcept;
        /**
         * The numbers associated with notes below which apply to the adjudication of this item.
         *
         * Applicable note numbers
         */
        noteNumber?: number[];
        /**
         * When the value is a group code then this item collects a set of related item details, otherwise this contains the product, service, drug or other billing code for the item. This element may be the start of a range of .productOrService codes used in conjunction with .productOrServiceEnd or it may be a solo element where .productOrServiceEnd is not used.
         *
         * Billing, service, product, or drug code
         */
        productOrService?: CodeableConcept;
        /**
         * The total of taxes applicable for this product or service.
         *
         * Total tax
         */
        tax?: Money;
        /**
         * Trace number for tracking purposes. May be defined at the jurisdiction level or between trading partners.
         *
         * Number for tracking
         */
        traceNumber?: Identifier[];
        /**
         * This contains the end of a range of product, service, drug or other billing codes for the item. This element is not used when the .productOrService is a group code. This value may only be present when a .productOfService code has been provided to convey the start of the range. Typically this value may be used only with preauthorizations and not with claims.
         *
         * End of a range of codes
         */
        productOrServiceEnd?: CodeableConcept;
        /**
         * Item typification or modifiers codes to convey additional context for the product or service.
         *
         * Service/Product billing modifiers
         */
        modifier?: CodeableConcept[];
        /**
         * If the item is not a group then this is the fee for the product or service, otherwise this is the total of the fees for the details of the group.
         *
         * Fee, charge or cost per item
         */
        unitPrice?: Money;
        /**
         * The number of repetitions of a service or product.
         *
         * Count of products or services
         */
        quantity?: Quantity;
        static revive(json: any): AddedItemSubDetailComponent;
        toJSON(): any;
    }
    class AddedItemDetailComponent extends BackboneElement {
        /**
         * The third-tier service adjudications for payor added services.
         *
         * Insurer added line items
         */
        subDetail?: ClaimResponse.AddedItemSubDetailComponent[];
        /**
         * When the value is a group code then this item collects a set of related item details, otherwise this contains the product, service, drug or other billing code for the item. This element may be the start of a range of .productOrService codes used in conjunction with .productOrServiceEnd or it may be a solo element where .productOrServiceEnd is not used.
         *
         * Billing, service, product, or drug code
         */
        productOrService?: CodeableConcept;
        /**
         * The total of taxes applicable for this product or service.
         *
         * Total tax
         */
        tax?: Money;
        /**
         * The numbers associated with notes below which apply to the adjudication of this item.
         *
         * Applicable note numbers
         */
        noteNumber?: number[];
        /**
         * If the item is not a group then this is the fee for the product or service, otherwise this is the total of the fees for the details of the group.
         *
         * Fee, charge or cost per item
         */
        unitPrice?: Money;
        /**
         * The number of repetitions of a service or product.
         *
         * Count of products or services
         */
        quantity?: Quantity;
        /**
         * Trace number for tracking purposes. May be defined at the jurisdiction level or between trading partners.
         *
         * Number for tracking
         */
        traceNumber?: Identifier[];
        /**
         * This contains the end of a range of product, service, drug or other billing codes for the item. This element is not used when the .productOrService is a group code. This value may only be present when a .productOfService code has been provided to convey the start of the range. Typically this value may be used only with preauthorizations and not with claims.
         *
         * End of a range of codes
         */
        productOrServiceEnd?: CodeableConcept;
        /**
         * Item typification or modifiers codes to convey additional context for the product or service.
         *
         * Service/Product billing modifiers
         */
        modifier?: CodeableConcept[];
        /**
         * A real number that represents a multiplier used in determining the overall value of services delivered and/or goods received. The concept of a Factor allows for a discount or surcharge multiplier to be applied to a monetary amount.
         *
         * Price scaling factor
         */
        factor?: number;
        /**
         * The total amount claimed for the group (if a grouper) or the addItem.detail. Net = unit price * quantity * factor.
         *
         * Total item cost
         */
        net?: Money;
        /**
         * The adjudication results.
         *
         * Added items detail adjudication
         */
        adjudication?: ClaimResponse.AdjudicationComponent[];
        /**
         * The high-level results of the adjudication if adjudication has been performed.
         *
         * Added items detail level adjudication results
         */
        reviewOutcome?: ClaimResponse.ReviewOutcomeComponent;
        /**
         * The type of revenue or cost center providing the product and/or service.
         *
         * Revenue or cost center code
         */
        revenue?: CodeableConcept;
        static revive(json: any): AddedItemDetailComponent;
        toJSON(): any;
    }
    class BodySiteComponent extends BackboneElement {
        /**
         * Physical service site on the patient (limb, tooth, etc.).
         *
         * Location
         */
        site: CodeableReference[];
        /**
         * A region or surface of the bodySite, e.g. limb region or tooth surface(s).
         *
         * Sub-location
         */
        subSite?: CodeableConcept[];
        static revive(json: any): BodySiteComponent;
        toJSON(): any;
    }
    class AddedItemComponent extends BackboneElement {
        /**
         * Claim items which this service line is intended to replace.
         *
         * Item sequence number
         */
        itemSequence?: number[];
        /**
         * The adjudication results.
         *
         * Added items adjudication
         */
        adjudication?: ClaimResponse.AdjudicationComponent[];
        /**
         * The high-level results of the adjudication if adjudication has been performed.
         *
         * Added items adjudication results
         */
        reviewOutcome?: ClaimResponse.ReviewOutcomeComponent;
        /**
         * The type of revenue or cost center providing the product and/or service.
         *
         * Revenue or cost center code
         */
        revenue?: CodeableConcept;
        /**
         * Physical location where the service is performed or applies.
         *
         * Anatomical location
         */
        bodySite?: ClaimResponse.BodySiteComponent[];
        /**
         * The providers who are authorized for the services rendered to the patient.
         *
         * Authorized providers
         */
        provider?: Practitioner[] | PractitionerRole[] | Organization[] | Reference[];
        /**
         * The sequence number of the details within the claim item which this line is intended to replace.
         *
         * Detail sequence number
         */
        detailSequence?: number[];
        /**
         * The second-tier service adjudications for payor added services.
         *
         * Insurer added line details
         */
        detail?: ClaimResponse.AddedItemDetailComponent[];
        /**
         * The date or dates when the service or product was supplied, performed or completed.
         *
         * Date or dates of service or product delivery
         */
        serviced?: Date | Period;
        /**
         * Where the product or service was provided.
         *
         * Place of service or where product was supplied
         */
        location?: CodeableConcept | Address | Location | Reference;
        /**
         * A real number that represents a multiplier used in determining the overall value of services delivered and/or goods received. The concept of a Factor allows for a discount or surcharge multiplier to be applied to a monetary amount.
         *
         * Price scaling factor
         */
        factor?: number;
        /**
         * The total amount claimed for the group (if a grouper) or the addItem. Net = unit price * quantity * factor.
         *
         * Total item cost
         */
        net?: Money;
        /**
         * Request or Referral for Goods or Service to be rendered.
         *
         * Request or Referral for Service
         */
        request?: DeviceRequest[] | MedicationRequest[] | NutritionOrder[] | ServiceRequest[] | SupplyRequest[] | VisionPrescription[] | Reference[];
        /**
         * If the item is not a group then this is the fee for the product or service, otherwise this is the total of the fees for the details of the group.
         *
         * Fee, charge or cost per item
         */
        unitPrice?: Money;
        /**
         * The number of repetitions of a service or product.
         *
         * Count of products or services
         */
        quantity?: Quantity;
        /**
         * Identifies the program under which this may be recovered.
         *
         * Program the product or service is provided under
         */
        programCode?: CodeableConcept[];
        /**
         * Trace number for tracking purposes. May be defined at the jurisdiction level or between trading partners.
         *
         * Number for tracking
         */
        traceNumber?: Identifier[];
        /**
         * This contains the end of a range of product, service, drug or other billing codes for the item. This element is not used when the .productOrService is a group code. This value may only be present when a .productOfService code has been provided to convey the start of the range. Typically this value may be used only with preauthorizations and not with claims.
         *
         * End of a range of codes
         */
        productOrServiceEnd?: CodeableConcept;
        /**
         * Item typification or modifiers codes to convey additional context for the product or service.
         *
         * Service/Product billing modifiers
         */
        modifier?: CodeableConcept[];
        /**
         * The sequence number of the sub-details within the details within the claim item which this line is intended to replace.
         *
         * Subdetail sequence number
         */
        subdetailSequence?: number[];
        /**
         * When the value is a group code then this item collects a set of related item details, otherwise this contains the product, service, drug or other billing code for the item. This element may be the start of a range of .productOrService codes used in conjunction with .productOrServiceEnd or it may be a solo element where .productOrServiceEnd is not used.
         *
         * Billing, service, product, or drug code
         */
        productOrService?: CodeableConcept;
        /**
         * The total of taxes applicable for this product or service.
         *
         * Total tax
         */
        tax?: Money;
        /**
         * The numbers associated with notes below which apply to the adjudication of this item.
         *
         * Applicable note numbers
         */
        noteNumber?: number[];
        static revive(json: any): AddedItemComponent;
        toJSON(): any;
    }
    class SubDetailComponent extends BackboneElement {
        /**
         * The numbers associated with notes below which apply to the adjudication of this item.
         *
         * Applicable note numbers
         */
        noteNumber?: number[];
        /**
         * Trace number for tracking purposes. May be defined at the jurisdiction level or between trading partners.
         *
         * Number for tracking
         */
        traceNumber?: Identifier[];
        /**
         * The high-level results of the adjudication if adjudication has been performed.
         *
         * Subdetail level adjudication results
         */
        reviewOutcome?: ClaimResponse.ReviewOutcomeComponent;
        /**
         * A number to uniquely reference the claim sub-detail entry.
         *
         * Claim sub-detail instance identifier
         */
        subDetailSequence: number;
        /**
         * The adjudication results.
         *
         * Subdetail level adjudication details
         */
        adjudication?: ClaimResponse.AdjudicationComponent[];
        static revive(json: any): SubDetailComponent;
        toJSON(): any;
    }
    class ItemDetailComponent extends BackboneElement {
        /**
         * Trace number for tracking purposes. May be defined at the jurisdiction level or between trading partners.
         *
         * Number for tracking
         */
        traceNumber?: Identifier[];
        /**
         * A number to uniquely reference the claim detail entry.
         *
         * Claim detail instance identifier
         */
        detailSequence: number;
        /**
         * The adjudication results.
         *
         * Detail level adjudication details
         */
        adjudication?: ClaimResponse.AdjudicationComponent[];
        /**
         * The high-level results of the adjudication if adjudication has been performed.
         *
         * Detail level adjudication results
         */
        reviewOutcome?: ClaimResponse.ReviewOutcomeComponent;
        /**
         * The numbers associated with notes below which apply to the adjudication of this item.
         *
         * Applicable note numbers
         */
        noteNumber?: number[];
        /**
         * A sub-detail adjudication of a simple product or service.
         *
         * Adjudication for claim sub-details
         */
        subDetail?: ClaimResponse.SubDetailComponent[];
        static revive(json: any): ItemDetailComponent;
        toJSON(): any;
    }
    class AdjudicationComponent extends BackboneElement {
        /**
         * A code supporting the understanding of the adjudication result and explaining variance from expected amount.
         *
         * Explanation of adjudication outcome
         */
        reason?: CodeableConcept;
        /**
         * A non-monetary value associated with the category. Mutually exclusive to the amount element above.
         *
         * Non-monetary value
         */
        quantity?: Quantity;
        /**
         * Monetary amount associated with the category.
         *
         * Monetary amount
         */
        amount?: Money;
        /**
         * A code to indicate the information type of this adjudication record. Information types may include the value submitted, maximum values or percentages allowed or payable under the plan, amounts that: the patient is responsible for in aggregate or pertaining to this item; amounts paid by other coverages; and, the benefit payable for this item.
         *
         * Type of adjudication information
         */
        category: CodeableConcept;
        static revive(json: any): AdjudicationComponent;
        toJSON(): any;
    }
    class ReviewOutcomeComponent extends BackboneElement {
        /**
         * Reference from the Insurer which is used in later communications which refers to this adjudication.
         *
         * Preauthorization reference
         */
        preAuthRef?: string;
        /**
         * The result of the claim, predetermination, or preauthorization adjudication.
         *
         * Result of the adjudication
         */
        decision?: CodeableConcept;
        /**
         * The time frame during which this authorization is effective.
         *
         * Preauthorization reference effective period
         */
        preAuthPeriod?: Period;
        /**
         * The reasons for the result of the claim, predetermination, or preauthorization adjudication.
         *
         * Reason for result of the adjudication
         */
        reason?: CodeableConcept[];
        static revive(json: any): ReviewOutcomeComponent;
        toJSON(): any;
    }
    class ItemComponent extends BackboneElement {
        /**
         * The numbers associated with notes below which apply to the adjudication of this item.
         *
         * Applicable note numbers
         */
        noteNumber?: number[];
        /**
         * A claim detail. Either a simple (a product or service) or a 'group' of sub-details which are simple items.
         *
         * Adjudication for claim details
         */
        detail?: ClaimResponse.ItemDetailComponent[];
        /**
         * Trace number for tracking purposes. May be defined at the jurisdiction level or between trading partners.
         *
         * Number for tracking
         */
        traceNumber?: Identifier[];
        /**
         * A number to uniquely reference the claim item entries.
         *
         * Claim item instance identifier
         */
        itemSequence: number;
        /**
         * If this item is a group then the values here are a summary of the adjudication of the detail items. If this item is a simple product or service then this is the result of the adjudication of this item.
         *
         * Adjudication details
         */
        adjudication?: ClaimResponse.AdjudicationComponent[];
        /**
         * The high-level results of the adjudication if adjudication has been performed.
         *
         * Adjudication results
         */
        reviewOutcome?: ClaimResponse.ReviewOutcomeComponent;
        static revive(json: any): ItemComponent;
        toJSON(): any;
    }
    class ClaimResponseEventComponent extends BackboneElement {
        /**
         * A date or period in the past or future indicating when the event occurred or is expectd to occur.
         *
         * Occurance date or period
         */
        when: Date | Period;
        /**
         * A coded event such as when a service is expected or a card printed.
         *
         * Specific event
         */
        type: CodeableConcept;
        static revive(json: any): ClaimResponseEventComponent;
        toJSON(): any;
    }
}
