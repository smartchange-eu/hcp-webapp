import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Coding } from '../datatype/coding';
import { Identifier } from '../datatype/identifier';
import { Appointment } from '../model/appointment';
import { AppointmentResponse } from '../model/appointment-response';
import { CarePlan } from '../model/care-plan';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { DocumentReference } from '../model/document-reference';
import { DomainResource } from '../model/domain-resource';
import { Endpoint } from '../model/endpoint';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { ImagingStudy } from '../model/imaging-study';
import { Location } from '../model/location';
import { Medication } from '../model/medication';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { Procedure } from '../model/procedure';
import { RelatedPerson } from '../model/related-person';
import { ServiceRequest } from '../model/service-request';
import { Specimen } from '../model/specimen';
import { Substance } from '../model/substance';
import { Task } from '../model/task';
/**
 * HAPI/FHIR <b>ImagingSelection</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ImagingSelection">http://hl7.org/fhir/StructureDefinition/ImagingSelection</a>
 * </p>
 *
 */
export declare class ImagingSelection extends DomainResource {
    /**
     * The Series Instance UID for the DICOM Series from which the images were selected.
     *
     * DICOM Series Instance UID
     */
    seriesUid?: string;
    /**
     * The network service providing retrieval access to the selected images, frames, etc. See implementation notes for information about using DICOM endpoints.
     *
     * The network service providing retrieval for the images referenced in the imaging selection
     */
    endpoint?: Endpoint[] | Reference[];
    /**
     * The anatomic structures examined. See DICOM Part 16 Annex L (http://dicom.nema.org/medical/dicom/current/output/chtml/part16/chapter_L.html) for DICOM to SNOMED-CT mappings.
     *
     * Body part examined
     */
    bodySite?: CodeableReference;
    /**
     * The current state of the ImagingSelection resource. This is not the status of any ImagingStudy, ServiceRequest, or Task resources associated with the ImagingSelection.
     *
     * available | entered-in-error | unknown
     */
    status: string;
    /**
     * A list of the diagnostic requests that resulted in this imaging selection being performed.
     *
     * Associated request
     */
    basedOn?: CarePlan[] | ServiceRequest[] | Appointment[] | AppointmentResponse[] | Task[] | Reference[];
    /**
     * The Study Instance UID for the DICOM Study from which the images were selected.
     *
     * DICOM Study Instance UID
     */
    studyUid?: string;
    /**
     * The date and time this imaging selection was created.
     *
     * Date / Time when this imaging selection was created
     */
    issued?: Date;
    /**
     * Classifies the imaging selection.
     *
     * Classifies the imaging selection
     */
    category?: CodeableConcept[];
    /**
     * The imaging study from which the imaging selection is made.
     *
     * The imaging study from which the imaging selection is derived
     */
    derivedFrom?: ImagingStudy[] | DocumentReference[] | Reference[];
    /**
     * The patient, or group of patients, location, device, organization, procedure or practitioner this imaging selection is about and into whose or what record the imaging selection is placed.
     *
     * Subject of the selected instances
     */
    subject?: Patient | Group | Device | Location | Organization | Procedure | Practitioner | Medication | Substance | Specimen | Reference;
    /**
     * Selector of the instances – human or machine.
     *
     * Selector of the instances (human or machine)
     */
    performer?: ImagingSelection.ImagingSelectionPerformerComponent[];
    /**
     * Reason for referencing the selected content.
     *
     * Imaging Selection purpose text or code
     */
    code: CodeableConcept;
    /**
     * Each imaging selection includes one or more selected DICOM SOP instances.
     *
     * The selected instances
     */
    instance?: ImagingSelection.ImagingSelectionInstanceComponent[];
    /**
     * A unique identifier assigned to this imaging selection.
     *
     * Business Identifier for Imaging Selection
     */
    identifier?: Identifier[];
    /**
     * The Series Number for the DICOM Series from which the images were selected.
     *
     * DICOM Series Number
     */
    seriesNumber?: number;
    /**
     * The Frame of Reference UID identifying the coordinate system that conveys spatial and/or temporal information for the selected images or frames.
     *
     * The Frame of Reference UID for the selected images
     */
    frameOfReferenceUid?: string;
    /**
     * The actual focus of an observation when it is not the patient of record representing something or someone associated with the patient such as a spouse, parent, fetus, or donor. For example, fetus observations in a mother's record.  The focus of an observation could also be an existing condition,  an intervention, the subject's diet,  another observation of the subject,  or a body structure such as tumor or implanted device.   An example use case would be using the Observation resource to capture whether the mother is trained to change her child's tracheostomy tube. In this example, the child is the patient of record and the mother is the focus.
     *
     * Related resource that is the focus for the imaging selection
     */
    focus?: ImagingSelection[] | Reference[];
    readonly resourceType: string;
    static revive(json: any): ImagingSelection;
    toJSON(): any;
}
export declare namespace ImagingSelection {
    enum ImagingSelectionStatus {
        AVAILABLE,
        ENTEREDINERROR,
        NULL,
        UNKNOWN
    }
    enum ImagingSelection3DGraphicType {
        ELLIPSE,
        POLYGON,
        NULL,
        POLYLINE,
        MULTIPOINT,
        ELLIPSOID,
        POINT
    }
    enum ImagingSelection2DGraphicType {
        ELLIPSE,
        INTERPOLATED,
        NULL,
        POLYLINE,
        POINT,
        CIRCLE
    }
    class ImageRegion3DComponent extends BackboneElement {
        /**
         * The coordinates describing the image region. Encoded as an ordered set of (x,y,z) triplets (in mm and may be negative) that define a region of interest in the patient-relative Reference Coordinate System defined by ImagingSelection.frameOfReferenceUid element.
         *
         * Specifies the coordinates that define the image region
         */
        coordinate: number[];
        /**
         * Specifies the type of image region.
         *
         * point | multipoint | polyline | polygon | ellipse | ellipsoid
         */
        regionType: string;
        static revive(json: any): ImageRegion3DComponent;
        toJSON(): any;
    }
    class ImageRegion2DComponent extends BackboneElement {
        /**
         * The coordinates describing the image region. Encoded as a set of (column, row) pairs that denote positions in the selected image / frames specified with sub-pixel resolution.
       The origin at the TLHC of the TLHC pixel is 0.0\0.0, the BRHC of the TLHC pixel is 1.0\1.0, and the BRHC of the BRHC pixel is the number of columns\rows in the image / frames. The values must be within the range 0\0 to the number of columns\rows in the image / frames.
         *
         * Specifies the coordinates that define the image region
         */
        coordinate: number[];
        /**
         * Specifies the type of image region.
         *
         * point | polyline | interpolated | circle | ellipse
         */
        regionType: string;
        static revive(json: any): ImageRegion2DComponent;
        toJSON(): any;
    }
    class ImagingSelectionInstanceComponent extends BackboneElement {
        /**
         * Selected subset of the SOP Instance. The content and format of the subset item is determined by the SOP Class of the selected instance.
       May be one of:
       - A list of frame numbers selected from a multiframe SOP Instance.
       - A list of Content Item Observation UID values selected from a DICOM SR or other structured document SOP Instance.
       - A list of segment numbers selected from a segmentation SOP Instance.
       - A list of Region of Interest (ROI) numbers selected from a radiotherapy structure set SOP Instance.
         *
         * The selected subset of the SOP Instance
         */
        subset?: string[];
        /**
         * The SOP Class UID for the selected DICOM instance.
         *
         * DICOM SOP Class UID
         */
        sopClass?: Coding;
        /**
         * Each imaging selection instance or frame list might includes an image region, specified by a region type and a set of 2D coordinates.
       If the parent imagingSelection.instance contains a subset element of type frame, the image region applies to all frames in the subset list.
         *
         * A specific 2D region in a DICOM image / frame
         */
        imageRegion2D?: ImagingSelection.ImageRegion2DComponent[];
        /**
         * Each imaging selection might includes a 3D image region, specified by a region type and a set of 3D coordinates.
         *
         * A specific 3D region in a DICOM frame of reference
         */
        imageRegion3D?: ImagingSelection.ImageRegion3DComponent[];
        /**
         * The SOP Instance UID for the selected DICOM instance.
         *
         * DICOM SOP Instance UID
         */
        uid: string;
        /**
         * The Instance Number for the selected DICOM instance.
         *
         * DICOM Instance Number
         */
        number?: number;
        static revive(json: any): ImagingSelectionInstanceComponent;
        toJSON(): any;
    }
    class ImagingSelectionPerformerComponent extends BackboneElement {
        /**
         * Author – human or machine.
         *
         * Author (human or machine)
         */
        actor?: Practitioner | PractitionerRole | Device | Organization | CareTeam | Patient | RelatedPerson | HealthcareService | Reference;
        /**
         * Distinguishes the type of involvement of the performer.
         *
         * Type of performer
         */
        function?: CodeableConcept;
        static revive(json: any): ImagingSelectionPerformerComponent;
        toJSON(): any;
    }
}
