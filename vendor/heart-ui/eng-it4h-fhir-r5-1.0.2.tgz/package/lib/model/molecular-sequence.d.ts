import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Identifier } from '../datatype/identifier';
import { Range } from '../datatype/range';
import { BiologicallyDerivedProduct } from '../model/biologically-derived-product';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Group } from '../model/group';
import { NutritionProduct } from '../model/nutrition-product';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Specimen } from '../model/specimen';
import { Substance } from '../model/substance';
/**
 * HAPI/FHIR <b>MolecularSequence</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/MolecularSequence">http://hl7.org/fhir/StructureDefinition/MolecularSequence</a>
 * </p>
 *
 */
export declare class MolecularSequence extends DomainResource {
    /**
     * Amino Acid Sequence/ DNA Sequence / RNA Sequence.
     *
     * aa | dna | rna
     */
    type?: string;
    /**
     * The method for sequencing, for example, chip information.
     *
     * The method for sequencing
     */
    device?: Device | Reference;
    /**
     * Sequence that was observed.
     *
     * Sequence that was observed
     */
    literal?: string;
    /**
     * A sequence defined relative to another sequence.
     *
     * A sequence defined relative to another sequence
     */
    relative?: MolecularSequence.MolecularSequenceRelativeComponent[];
    /**
     * The actual focus of a molecular sequence when it is not the patient of record representing something or someone associated with the patient such as a spouse, parent, child, or sibling. For example, in trio testing, the subject would be the child (proband) and the focus would be the parent.
     *
     * What the molecular sequence is about, when it is not about the subject of record
     */
    focus?: Reference[];
    /**
     * Indicates the subject this sequence is associated too.
     *
     * Subject this sequence is associated too
     */
    subject?: Patient | Group | Substance | BiologicallyDerivedProduct | NutritionProduct | Reference;
    /**
     * Sequence that was observed as file content. Can be an actual file contents, or referenced by a URL to an external system.
     *
     * Embedded file or a link (URL) which contains content to represent the sequence
     */
    formatted?: Attachment[];
    /**
     * Specimen used for sequencing.
     *
     * Specimen used for sequencing
     */
    specimen?: Specimen | Reference;
    /**
     * A unique identifier for this particular sequence instance.
     *
     * Unique ID for this particular sequence
     */
    identifier?: Identifier[];
    /**
     * The organization or lab that should be responsible for this result.
     *
     * Who should be responsible for test result
     */
    performer?: Organization | Reference;
    readonly resourceType: string;
    static revive(json: any): MolecularSequence;
    toJSON(): any;
}
export declare namespace MolecularSequence {
    enum StrandType {
        NULL,
        CRICK,
        WATSON
    }
    enum SequenceType {
        AA,
        NULL,
        RNA,
        DNA
    }
    enum OrientationType {
        NULL,
        ANTISENSE,
        SENSE
    }
    class MolecularSequenceRelativeEditComponent extends BackboneElement {
        /**
         * Allele in the starting sequence. Nucleotide(s)/amino acids from start position of sequence to stop position of sequence on the positive (+) strand of the starting sequence. When the sequence  type is DNA, it should be the sequence on the positive (+) strand. This will lay in the range between variant.start and variant.end.
         *
         * Allele in the starting sequence
         */
        replacedSequence?: string;
        /**
         * End position of the edit on the starting sequence. If the coordinate system is 0-based then end is exclusive and does not include the last position. If the coordinate system is 1-base, then end is inclusive and includes the last position.
         *
         * End position of the edit on the starting sequence
         */
        end?: number;
        /**
         * Start position of the edit on the starting sequence. If the coordinate system is either 0-based or 1-based, then start position is inclusive.
         *
         * Start position of the edit on the starting sequence
         */
        start?: number;
        /**
         * Allele that was observed. Nucleotide(s)/amino acids from start position of sequence to stop position of sequence on the positive (+) strand of the observed sequence. When the sequence type is DNA, it should be the sequence on the positive (+) strand. This will lay in the range between variant.start and variant.end.
         *
         * Allele that was observed
         */
        replacementSequence?: string;
        static revive(json: any): MolecularSequenceRelativeEditComponent;
        toJSON(): any;
    }
    class MolecularSequenceRelativeStartingSequenceComponent extends BackboneElement {
        /**
         * The reference sequence that represents the starting sequence.
         *
         * The reference sequence that represents the starting sequence
         */
        sequence?: CodeableConcept | string | MolecularSequence | Reference;
        /**
         * A relative reference to a DNA strand based on gene orientation. The strand that contains the open reading frame of the gene is the "sense" strand, and the opposite complementary strand is the "antisense" strand.
         *
         * sense | antisense
         */
        orientation?: string;
        /**
         * An absolute reference to a strand. The Watson strand is the strand whose 5'-end is on the short arm of the chromosome, and the Crick strand as the one whose 5'-end is on the long arm.
         *
         * watson | crick
         */
        strand?: string;
        /**
         * The genome assembly used for starting sequence, e.g. GRCh38.
         *
         * The genome assembly used for starting sequence, e.g. GRCh38
         */
        genomeAssembly?: CodeableConcept;
        /**
         * Start position of the window on the starting sequence. This value should honor the rules of the coordinateSystem.
         *
         * Start position of the window on the starting sequence
         */
        windowStart?: number;
        /**
         * Structural unit composed of a nucleic acid molecule which controls its own replication through the interaction of specific proteins at one or more origins of replication ([SO:0000340](http://www.sequenceontology.org/browser/current_svn/term/SO:0000340)).
         *
         * Chromosome Identifier
         */
        chromosome?: CodeableConcept;
        /**
         * End position of the window on the starting sequence. This value should honor the rules of the  coordinateSystem.
         *
         * End position of the window on the starting sequence
         */
        windowEnd?: number;
        static revive(json: any): MolecularSequenceRelativeStartingSequenceComponent;
        toJSON(): any;
    }
    class MolecularSequenceRelativeComponent extends BackboneElement {
        /**
         * A sequence that is used as a starting sequence to describe variants that are present in a sequence analyzed.
         *
         * A sequence used as starting sequence
         */
        startingSequence?: MolecularSequence.MolecularSequenceRelativeStartingSequenceComponent;
        /**
         * Indicates the nucleotide range in the composed sequence when multiple 'relative' elements are used together.
         *
         * Indicates the nucleotide range in the composed sequence when multiple 'relative' elements are used together
         */
        sequenceRange?: Range;
        /**
         * Changes in sequence from the starting sequence.
         *
         * Changes in sequence from the starting sequence
         */
        edit?: MolecularSequence.MolecularSequenceRelativeEditComponent[];
        /**
         * These are different ways of identifying nucleotides or amino acids within a sequence. Different databases and file types may use different systems. For detail definitions, see https://loinc.org/92822-6/ for more detail.
         *
         * Ways of identifying nucleotides or amino acids within a sequence
         */
        coordinateSystem: CodeableConcept;
        /**
         * Indicates the order in which the sequence should be considered when putting multiple 'relative' elements together.
         *
         * Indicates the order in which the sequence should be considered when putting multiple 'relative' elements together
         */
        ordinalPosition?: number;
        static revive(json: any): MolecularSequenceRelativeComponent;
        toJSON(): any;
    }
}
