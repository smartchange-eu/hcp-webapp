import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { Expression } from '../datatype/expression';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { CareTeam } from '../model/care-team';
import { Contract } from '../model/contract';
import { Device } from '../model/device';
import { DocumentReference } from '../model/document-reference';
import { DomainResource } from '../model/domain-resource';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { QuestionnaireResponse } from '../model/questionnaire-response';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Consent</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Consent">http://hl7.org/fhir/StructureDefinition/Consent</a>
 * </p>
 *
 */
export declare class Consent extends DomainResource {
    /**
     * Effective period for this Consent Resource and all provisions unless specified in that provision.
     *
     * Effective period for this Consent
     */
    period?: Period;
    /**
     * The actor that controls/enforces the access according to the consent.
     *
     * Consent Enforcer
     */
    controller?: HealthcareService[] | Organization[] | Patient[] | Practitioner[] | Reference[];
    /**
     * Date the consent instance was agreed to.
     *
     * Fully executed date of the consent
     */
    date?: Date;
    /**
     * A reference to a consent that links back to such a source, a reference to a document repository (e.g. XDS) that stores the original consent document.
     *
     * Source from which this consent is taken
     */
    sourceReference?: Consent[] | DocumentReference[] | Contract[] | QuestionnaireResponse[] | Reference[];
    /**
     * Unique identifier for this copy of the Consent Statement.
     *
     * Identifier for this record (external references)
     */
    identifier?: Identifier[];
    /**
     * The patient/healthcare practitioner or group of persons to whom this consent applies.
     *
     * Who the consent applies to
     */
    subject?: Patient | Practitioner | Group | Reference;
    /**
     * The actor that manages the consent through its lifecycle.
     *
     * Consent workflow management
     */
    manager?: HealthcareService[] | Organization[] | Patient[] | Practitioner[] | Reference[];
    /**
     * A set of codes that indicate the regulatory basis (if any) that this consent supports.
     *
     * Regulations establishing base Consent
     */
    regulatoryBasis?: CodeableConcept[];
    /**
     * A Reference to the human readable policy explaining the basis for the Consent.
     *
     * Human Readable Policy
     */
    policyText?: DocumentReference[] | Reference[];
    /**
     * Action to take - permit or deny - as default.
     *
     * deny | permit
     */
    decision?: string;
    /**
     * The entity responsible for granting the rights listed in a Consent Directive.
     *
     * Who is granting rights according to the policy and rules
     */
    grantor?: CareTeam[] | HealthcareService[] | Organization[] | Patient[] | Practitioner[] | RelatedPerson[] | PractitionerRole[] | Reference[];
    /**
     * The entity responsible for complying with the Consent Directive, including any obligations or limitations on authorizations and enforcement of prohibitions.
     *
     * Who is agreeing to the policy and rules
     */
    grantee?: CareTeam[] | HealthcareService[] | Organization[] | Patient[] | Practitioner[] | RelatedPerson[] | PractitionerRole[] | Reference[];
    /**
     * The source on which this consent statement is based. The source might be a scanned original paper form.
     *
     * Source from which this consent is taken
     */
    sourceAttachment?: Attachment[];
    /**
     * An exception to the base policy of this consent. An exception can be an addition or removal of access permissions.
     *
     * Constraints to the base Consent.policyRule/Consent.policy
     */
    provision?: Consent.ProvisionComponent[];
    /**
     * Whether a treatment instruction (e.g. artificial respiration: yes or no) was verified with the patient, his/her family or another authorized person.
     *
     * Consent Verified by patient or family
     */
    verification?: Consent.ConsentVerificationComponent[];
    /**
     * Indicates the current state of this Consent resource.
     *
     * draft | active | inactive | not-done | entered-in-error | unknown
     */
    status: string;
    /**
     * A Reference or URL used to uniquely identify the policy the organization will enforce for this Consent. This Reference or URL should be specific to the version of the policy and should be dereferencable to a computable policy of some form.
     *
     * Computable version of the backing policy
     */
    policyBasis?: Consent.ConsentPolicyBasisComponent;
    /**
     * A classification of the type of consents found in the statement. This element supports indexing and retrieval of consent statements.
     *
     * Classification of the consent statement - for indexing/retrieval
     */
    category?: CodeableConcept[];
    readonly resourceType: string;
    static revive(json: any): Consent;
    toJSON(): any;
}
export declare namespace Consent {
    enum ConsentState {
        NOTDONE,
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        DRAFT,
        INACTIVE,
        UNKNOWN
    }
    enum ConsentProvisionType {
        DENY,
        NULL,
        PERMIT
    }
    class ProvisionDataComponent extends BackboneElement {
        /**
         * How the resource reference is interpreted when testing consent restrictions.
         *
         * instance | related | dependents | authoredby
         */
        meaning: string;
        /**
         * A reference to a specific resource that defines which resources are covered by this consent.
         *
         * The actual data reference
         */
        reference: Reference;
        static revive(json: any): ProvisionDataComponent;
        toJSON(): any;
    }
    class ProvisionActorComponent extends BackboneElement {
        /**
         * How the individual is involved in the resources content that is described in the exception.
         *
         * How the actor is involved
         */
        role?: CodeableConcept;
        /**
         * The resource that identifies the actor. To identify actors by type, use group to identify a set of actors by some property they share (e.g. 'admitting officers').
         *
         * Resource for the actor (or group, by role)
         */
        reference?: Device | Group | CareTeam | Organization | Patient | Practitioner | RelatedPerson | PractitionerRole | Reference;
        static revive(json: any): ProvisionActorComponent;
        toJSON(): any;
    }
    class ProvisionComponent extends BackboneElement {
        /**
         * The resourceType(s) covered by this provision. The type can be a FHIR resource type or a profile on a type that indicates what information the consent relates to.
         *
         * e.g. Resource Type, Profile, etc
         */
        resourceType?: Coding[];
        /**
         * Actions controlled by this provision.
         *
         * Actions controlled by this provision
         */
        action?: CodeableConcept[];
        /**
         * The context of the activities a user is taking - why the user is accessing the data - that are controlled by this provision.
         *
         * Context of activities covered by this provision
         */
        purpose?: Coding[];
        /**
         * The documentType(s) covered by this provision. The type can be a CDA document, or some other type that indicates what sort of information the consent relates to.
         *
         * e.g. Resource Type, Profile, CDA, etc
         */
        documentType?: Coding[];
        /**
         * The resources controlled by this provision if specific resources are referenced.
         *
         * Data controlled by this provision
         */
        data?: Consent.ProvisionDataComponent[];
        /**
         * A security label, comprised of 0..* security label fields (Privacy tags), which define which resources are controlled by this exception.
         *
         * Security Labels that define affected resources
         */
        securityLabel?: Coding[];
        /**
         * Provisions which provide exceptions to the base provision or subprovisions.
         *
         * Nested Exception Provisions
         */
        provision?: Consent.ProvisionComponent[];
        /**
         * Who or what is controlled by this provision. Use group to identify a set of actors by some property they share (e.g. 'admitting officers').
         *
         * Who|what controlled by this provision (or group, by role)
         */
        actor?: Consent.ProvisionActorComponent[];
        /**
         * Clinical or Operational Relevant period of time that bounds the data controlled by this provision.
         *
         * Timeframe for data controlled by this provision
         */
        dataPeriod?: Period;
        /**
         * If this code is found in an instance, then the provision applies.
         *
         * e.g. LOINC or SNOMED CT code, etc. in the content
         */
        code?: CodeableConcept[];
        /**
         * A computable (FHIRPath or other) definition of what is controlled by this consent.
         *
         * A computable expression of the consent
         */
        expression?: Expression;
        /**
         * Timeframe for this provision.
         *
         * Timeframe for this provision
         */
        period?: Period;
        static revive(json: any): ProvisionComponent;
        toJSON(): any;
    }
    class ConsentVerificationComponent extends BackboneElement {
        /**
         * The person who conducted the verification/validation of the Grantor decision.
         *
         * Person conducting verification
         */
        verifiedBy?: Organization | Practitioner | PractitionerRole | Reference;
        /**
         * Date(s) verification was collected.
         *
         * When consent verified
         */
        verificationDate?: Date[];
        /**
         * Has the instruction been verified.
         *
         * Has been verified
         */
        verified: boolean;
        /**
         * Extensible list of verification type starting with verification and re-validation.
         *
         * Business case of verification
         */
        verificationType?: CodeableConcept;
        /**
         * Who verified the instruction (Patient, Relative or other Authorized Person).
         *
         * Person who verified
         */
        verifiedWith?: Patient | RelatedPerson | Reference;
        static revive(json: any): ConsentVerificationComponent;
        toJSON(): any;
    }
    class ConsentPolicyBasisComponent extends BackboneElement {
        /**
         * A Reference that identifies the policy the organization will enforce for this Consent.
         *
         * Reference backing policy resource
         */
        reference?: Reference;
        /**
         * A URL that links to a computable version of the policy the organization will enforce for this Consent.
         *
         * URL to a computable backing policy
         */
        url?: string;
        static revive(json: any): ConsentPolicyBasisComponent;
        toJSON(): any;
    }
}
