import { Reference } from '../datatype/reference';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { DataRequirement } from '../datatype/data-requirement';
import { Identifier } from '../datatype/identifier';
import { Appointment } from '../model/appointment';
import { AppointmentResponse } from '../model/appointment-response';
import { CarePlan } from '../model/care-plan';
import { Claim } from '../model/claim';
import { CommunicationRequest } from '../model/communication-request';
import { Contract } from '../model/contract';
import { CoverageEligibilityRequest } from '../model/coverage-eligibility-request';
import { Device } from '../model/device';
import { DeviceRequest } from '../model/device-request';
import { DomainResource } from '../model/domain-resource';
import { Encounter } from '../model/encounter';
import { EnrollmentRequest } from '../model/enrollment-request';
import { Group } from '../model/group';
import { ImmunizationRecommendation } from '../model/immunization-recommendation';
import { MedicationRequest } from '../model/medication-request';
import { NutritionOrder } from '../model/nutrition-order';
import { OperationOutcome } from '../model/operation-outcome';
import { Patient } from '../model/patient';
import { RequestOrchestration } from '../model/request-orchestration';
import { ServiceRequest } from '../model/service-request';
import { SupplyRequest } from '../model/supply-request';
import { Task } from '../model/task';
import { VisionPrescription } from '../model/vision-prescription';
/**
 * HAPI/FHIR <b>GuidanceResponse</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/GuidanceResponse">http://hl7.org/fhir/StructureDefinition/GuidanceResponse</a>
 * </p>
 *
 */
export declare class GuidanceResponse extends DomainResource {
    /**
     * The encounter during which this response was created or to which the creation of this record is tightly associated.
     *
     * Encounter during which the response was returned
     */
    encounter?: Encounter | Reference;
    /**
     * Allows a service to provide  unique, business identifiers for the response.
     *
     * Business identifier
     */
    identifier?: Identifier[];
    /**
     * Describes the reason for the guidance response in coded or textual form, or Indicates the reason the request was initiated. This is typically provided as a parameter to the evaluation and echoed by the service, although for some use cases, such as subscription- or event-based scenarios, it may provide an indication of the cause for the response.
     *
     * Why guidance is needed
     */
    reason?: CodeableReference[];
    /**
     * Provides a mechanism to communicate additional information about the response.
     *
     * Additional notes about the response
     */
    note?: Annotation[];
    /**
     * Provides a reference to the device that performed the guidance.
     *
     * Device returning the guidance
     */
    performer?: Device | Reference;
    /**
     * An identifier, CodeableConcept or canonical reference to the guidance that was requested.
     *
     * What guidance was requested
     */
    module: string | CodeableConcept;
    /**
     * The patient for which the request was processed.
     *
     * Patient the request was performed for
     */
    subject?: Patient | Group | Reference;
    /**
     * If the evaluation could not be completed due to lack of information, or additional information would potentially result in a more accurate response, this element will a description of the data required in order to proceed with the evaluation. A subsequent request to the service should include this data.
     *
     * Additional required data
     */
    dataRequirement?: DataRequirement[];
    /**
     * The identifier of the request associated with this response. If an identifier was given as part of the request, it will be reproduced here to enable the requester to more easily identify the response in a multi-request scenario.
     *
     * The identifier of the request associated with this response, if any
     */
    requestIdentifier?: Identifier;
    /**
     * Indicates when the guidance response was processed.
     *
     * When the guidance response was processed
     */
    occurrenceDateTime?: Date;
    /**
     * The status of the response. If the evaluation is completed successfully, the status will indicate success. However, in order to complete the evaluation, the engine may require more information. In this case, the status will be data-required, and the response will contain a description of the additional required information. If the evaluation completed successfully, but the engine determines that a potentially more accurate response could be provided if more data was available, the status will be data-requested, and the response will contain a description of the additional requested information.
     *
     * success | data-requested | data-required | in-progress | failure | entered-in-error
     */
    status: string;
    /**
     * The output parameters of the evaluation, if any. Many modules will result in the return of specific resources such as procedure or communication requests that are returned as part of the operation result. However, modules may define specific outputs that would be returned as the result of the evaluation, and these would be returned in this element.
     *
     * The output parameters of the evaluation, if any
     */
    outputParameters?: any;
    /**
     * The actions, if any, produced by the evaluation of the artifact.
     *
     * Proposed actions, if any
     */
    result?: Appointment[] | AppointmentResponse[] | CarePlan[] | Claim[] | CommunicationRequest[] | Contract[] | CoverageEligibilityRequest[] | DeviceRequest[] | EnrollmentRequest[] | ImmunizationRecommendation[] | MedicationRequest[] | NutritionOrder[] | RequestOrchestration[] | ServiceRequest[] | SupplyRequest[] | Task[] | VisionPrescription[] | Reference[];
    /**
     * Messages resulting from the evaluation of the artifact or artifacts. As part of evaluating the request, the engine may produce informational or warning messages. These messages will be provided by this element.
     *
     * Messages resulting from the evaluation of the artifact or artifacts
     */
    evaluationMessage?: OperationOutcome | Reference;
    readonly resourceType: string;
    static revive(json: any): GuidanceResponse;
    toJSON(): any;
}
export declare namespace GuidanceResponse {
    enum GuidanceResponseStatus {
        ENTEREDINERROR,
        SUCCESS,
        NULL,
        INPROGRESS,
        DATAREQUIRED,
        DATAREQUESTED,
        FAILURE
    }
}
