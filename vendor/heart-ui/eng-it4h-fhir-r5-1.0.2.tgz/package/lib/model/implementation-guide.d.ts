import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { UsageContext } from '../datatype/usage-context';
import { CanonicalResource } from '../model/canonical-resource';
/**
 * HAPI/FHIR <b>ImplementationGuide</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/ImplementationGuide">http://hl7.org/fhir/StructureDefinition/ImplementationGuide</a>
 * </p>
 *
 */
export declare class ImplementationGuide extends CanonicalResource {
    /**
     * The information needed by an IG publisher tool to publish the whole implementation guide.
     *
     * Information needed to build the IG
     */
    definition?: ImplementationGuide.ImplementationGuideDefinitionComponent;
    /**
     * A natural language name identifying the implementation guide. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this implementation guide (computer friendly)
     */
    name: string;
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the implementation guide.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * The status of this implementation guide. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate implementation guide instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * The license that applies to this Implementation Guide, using an SPDX license code, or 'not-open-source'.
     *
     * SPDX license code for this IG (or not-open-source)
     */
    license?: string;
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * The version(s) of the FHIR specification that this ImplementationGuide targets - e.g. describes how to use. The value of this element is the formal version of the specification, without the revision number, e.g. [publication].[major].[minor], which is 4.6.0. for this version.
     *
     * FHIR Version(s) this Implementation Guide targets
     */
    fhirVersion: string[];
    /**
     * A Boolean value to indicate that this implementation guide is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * A set of profiles that all resources covered by this implementation guide must conform to.
     *
     * Profiles that apply globally
     */
    global?: ImplementationGuide.ImplementationGuideGlobalComponent[];
    /**
     * The NPM package name for this Implementation Guide, used in the NPM package distribution, which is the primary mechanism by which FHIR based tooling manages IG dependencies. This value must be globally unique, and should be assigned with care.
     *
     * NPM Package name for IG
     */
    packageId: string;
    /**
     * A free text natural language description of the implementation guide from a consumer's perspective.
     *
     * Natural language description of the implementation guide
     */
    description?: string;
    /**
     * An absolute URI that is used to identify this implementation guide when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this implementation guide is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the implementation guide is stored on different servers.
     *
     * Canonical identifier for this implementation guide, represented as a URI (globally unique)
     */
    url: string;
    /**
     * A short, descriptive, user-friendly title for the implementation guide.
     *
     * Name for this implementation guide (human friendly)
     */
    title?: string;
    /**
     * The identifier that is used to identify this version of the implementation guide when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the implementation guide author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the implementation guide
     */
    version?: string;
    /**
     * A copyright statement relating to the implementation guide and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the implementation guide.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * The date  (and optionally time) when the implementation guide was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the implementation guide changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * A formal identifier that is used to identify this implementation guide when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the implementation guide (business identifier)
     */
    identifier?: Identifier[];
    /**
     * Information about an assembled implementation guide, created by the publication tooling.
     *
     * Information about an assembled IG
     */
    manifest?: ImplementationGuide.ImplementationGuideManifestComponent;
    /**
     * A legal or geographic region in which the implementation guide is intended to be used.
     *
     * Intended jurisdiction for implementation guide (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * Another implementation guide that this implementation depends on. Typically, an implementation guide uses value sets, profiles etc.defined in other implementation guides.
     *
     * Another Implementation guide this depends on
     */
    dependsOn?: ImplementationGuide.ImplementationGuideDependsOnComponent[];
    /**
     * Explanation of why this implementation guide is needed and why it has been designed as it has.
     *
     * Why this implementation guide is defined
     */
    purpose?: string;
    readonly resourceType: string;
    static revive(json: any): ImplementationGuide;
    toJSON(): any;
}
export declare namespace ImplementationGuide {
    enum SPDXLicense {
        GPL_2_0_WITH_CLASSPATH_EXCEPTION,
        OPL_1_0,
        BSD_3_CLAUSE_NO_NUCLEAR_WARRANTY,
        STANDARDML_NJ,
        BSD_ATTRIBUTION_HPND_DISCLAIMER,
        LGPL_3_0_ONLY,
        HIPPOCRATIC_2_1,
        NTP_0,
        BSD_3_CLAUSE_LBNL,
        LGPL_3_0,
        DRL_1_0,
        IMAGEMAGICK,
        CMU_MACH,
        CC_BY_3_0_DE,
        ELASTIC_2_0,
        CAL_1_0,
        ANTLR_PD,
        FREEBSD_DOC,
        OGDL_TAIWAN_1_0,
        XSKAT,
        NLPL,
        OFL_1_0_NO_RFN,
        DVIPDFM,
        OGL_UK_2_0,
        TPDL,
        DOTSEQN,
        SNPRINTF,
        GPL_3_0_WITH_GCC_EXCEPTION,
        D_FSL_1_0,
        CUBE,
        AAL,
        AGPL_3_0_ONLY,
        BSD_4_CLAUSE,
        SENDMAIL,
        WTFPL,
        GFDL_1_3_INVARIANTS_ONLY,
        MIT_CMU,
        UNIXCRYPT,
        LINUX_MAN_PAGES_COPYLEFT,
        POSTGRESQL,
        CNRI_JYTHON,
        UCL_1_0,
        LATEX2E,
        IBM_PIBS,
        OSL_3_0,
        RDISC,
        MPI_PERMISSIVE,
        POLYFORM_NONCOMMERCIAL_1_0_0,
        GFDL_1_3_OR_LATER,
        LGPL_2_0,
        MPICH2,
        VOSTROM,
        LGPL_2_1,
        CC_BY_NC_SA_2_0_DE,
        LIBPNG,
        TERMREADKEY,
        W3C_20150513,
        KNUTH_CTAN,
        LZMA_SDK_9_11_TO_9_20,
        LIBPNG_2_0,
        ISC,
        TPL_1_0,
        XPP,
        GPL_2_0_WITH_GCC_EXCEPTION,
        X11_DISTRIBUTE_MODIFICATIONS_VARIANT,
        GSOAP_1_3B,
        OGL_UK_3_0,
        SAXPATH,
        CALDERA,
        NETCDF,
        UNICODE_TOU,
        ADOBE_GLYPH,
        RPSL_1_0,
        COPYLEFT_NEXT_0_3_1,
        O_UDA_1_0,
        COPYLEFT_NEXT_0_3_0,
        NAIST_2003,
        NOT_OPEN_SOURCE,
        X11,
        BSD_3_CLAUSE_ATTRIBUTION,
        ZEND_2_0,
        CC_BY_1_0,
        OLDAP_2_3,
        OLDAP_2_2,
        ZIMBRA_1_3,
        CDLA_PERMISSIVE_2_0,
        OLDAP_2_5,
        ZIMBRA_1_4,
        OLDAP_2_4,
        OSL_2_1,
        OSL_2_0,
        LGPL_2_1_OR_LATER,
        OLDAP_2_1,
        OLDAP_2_0,
        SSH_SHORT,
        RSA_MD,
        ADOBE_2006,
        SYMLINKS,
        YPL_1_1,
        YPL_1_0,
        LILIQ_RPLUS_1_1,
        CC_BY_NC_SA_3_0_IGO,
        SNIA,
        CC_BY_NC_SA_4_0,
        BSD_4_3TAHOE,
        NLOD_2_0,
        BITSTREAM_VERA,
        HPND,
        INTEL,
        XFIG,
        CC_BY_ND_3_0_DE,
        SGI_B_2_0,
        BUSL_1_1,
        BSD_3_CLAUSE_MODIFICATION,
        OGTSL,
        BSD_PROTECTION,
        BZIP2_1_0_6,
        BZIP2_1_0_5,
        MIT_FESTIVAL,
        GPL_1_0PLUS,
        DIFFMARK,
        INNER_NET_2_0,
        SSPL_1_0,
        OLDAP_2_7,
        OLDAP_2_6,
        OLDAP_2_8,
        POLYFORM_SMALL_BUSINESS_1_0_0,
        TU_BERLIN_1_0,
        OLDAP_1_4,
        OLDAP_1_3,
        OSL_1_0,
        CC_BY_2_0,
        CDLA_PERMISSIVE_1_0,
        OSL_1_1,
        CC_BY_2_5,
        NIST_PD,
        OLDAP_1_2,
        OLDAP_1_1,
        JSON,
        MULANPSL_2_0,
        CLIPS,
        MIT_ENNA,
        CDLA_SHARING_1_0,
        NLOD_1_0,
        GD,
        ODBL_1_0,
        PHP_3_0,
        PHP_3_01,
        OGL_UK_1_0,
        COMMUNITY_SPEC_1_0,
        OPENSSL,
        GPL_2_0_ONLY,
        LINUX_MAN_PAGES_1_PARA,
        SGI_B_1_1,
        CC_BY_SA_3_0_DE,
        BSD_1_CLAUSE,
        SGI_B_1_0,
        EFL_1_0,
        W3C,
        GPL_3_0PLUS,
        SMPPL,
        MINPACK,
        NPOSL_3_0,
        MS_LPL,
        MULANPSL_1_0,
        W3M,
        CC_BY_NC_SA_2_0,
        OFL_1_0_RFN,
        ERLPL_1_1,
        DOC,
        CC_BY_NC_SA_2_5,
        GPL_2_0,
        CC_BY_SA_3_0,
        PYTHON_2_0,
        OPUBL_1_0,
        LINUX_MAN_PAGES_COPYLEFT_VAR,
        SCHEMEREPORT,
        ENTESSA,
        NOKIA,
        APL_1_0,
        EFL_2_0,
        BSD_4_CLAUSE_UC,
        PYTHON_2_0_1,
        NCGL_UK_2_0,
        APP_S2P,
        FTL,
        SSH_OPENSSH,
        MTLL,
        QPL_1_0_INRIA_2004,
        GFDL_1_3_NO_INVARIANTS_OR_LATER,
        MIT_MODERN_VARIANT,
        FSFULLRWD,
        ASWF_DIGITAL_ASSETS_1_0,
        ASWF_DIGITAL_ASSETS_1_1,
        WSUIPA,
        NIST_PD_FALLBACK,
        NGPL,
        DL_DE_BY_2_0,
        CC_BY_NC_SA_3_0,
        JASPER_2_0,
        GPL_1_0,
        IMLIB2,
        CC_BY_SA_4_0,
        HP_1986,
        HTMLTIDY,
        LIBTIFF,
        FSFUL,
        TTWL,
        EUDATAGRID,
        ZLIB_ACKNOWLEDGEMENT,
        UNLICENSE,
        XLOCK,
        DSDP,
        CAL_1_0_COMBINED_WORK_EXCEPTION,
        BSD_2_CLAUSE_VIEWS,
        CERN_OHL_1_1,
        CERN_OHL_1_2,
        OFL_1_1_RFN,
        SPENCER_94,
        CNRI_PYTHON,
        SPENCER_99,
        CC_BY_NC_SA_2_0_FR,
        EPL_1_0,
        GFDL_1_3_INVARIANTS_OR_LATER,
        GPL_3_0_OR_LATER,
        _0BSD,
        SIMPL_2_0,
        FRAMEWORX_1_0,
        KAZLIB,
        MAKEINDEX,
        CC_BY_SA_2_5,
        TMATE,
        CC_BY_NC_ND_3_0_DE,
        CC_BY_NC_ND_3_0_IGO,
        AML,
        LZMA_SDK_9_22,
        NAUMEN,
        ADSL,
        CC_BY_SA_1_0,
        NOWEB,
        NULL,
        GPL_1_0_ONLY,
        CC_BY_3_0_AT,
        AFL_2_0,
        ANTLR_PD_FALLBACK,
        CC_BY_2_5_AU,
        INTERBASE_1_0,
        AFL_2_1,
        ABSTYLES,
        BSD_2_CLAUSE_NETBSD,
        SISSL_1_2,
        PDDL_1_0,
        AFMPARSE,
        CPL_1_0,
        GFDL_1_3_NO_INVARIANTS_ONLY,
        LGPLLR,
        GFDL_1_1_NO_INVARIANTS_ONLY,
        TCP_WRAPPERS,
        CERN_OHL_P_2_0,
        EPL_2_0,
        CDL_1_0,
        HPND_SELL_VARIANT,
        PARITY_6_0_0,
        CC_BY_NC_SA_1_0,
        NICTA_1_0,
        GPL_3_0,
        MIT_WU,
        MIT_ADVERTISING,
        GFDL_1_1_INVARIANTS_OR_LATER,
        UNICODE_DFS_2015,
        UNICODE_DFS_2016,
        CC_BY_SA_2_0,
        SPENCER_86,
        SHL_0_5,
        CC_BY_NC_3_0_DE,
        GFDL_1_2_ONLY,
        MULTICS,
        AFL_3_0,
        CECILL_B,
        LGPL_3_0PLUS,
        BSD_2_CLAUSE_FREEBSD,
        CECILL_C,
        JAM,
        RUBY,
        CC_PDDC,
        PSUTILS,
        SUGARCRM_1_1_3,
        LINUX_MAN_PAGES_COPYLEFT_2_PARA,
        WATCOM_1_0,
        CC_BY_NC_1_0,
        XNET,
        OCCT_PL,
        BSD_2_CLAUSE_PATENT,
        LGPL_2_1_ONLY,
        COIL_1_0,
        CC_BY_3_0_IGO,
        EPICS,
        AGPL_1_0_ONLY,
        UPL_1_0,
        BSL_1_0,
        BEERWARE,
        BRIAN_GLADMAN_3_CLAUSE,
        LGPL_2_0PLUS,
        HASKELLREPORT,
        BITSTREAM_CHARTER,
        BSD_2_CLAUSE,
        OML,
        CC_BY_3_0_US,
        CURL,
        TOSL,
        ARTISTIC_2_0,
        LPPL_1_3C,
        MIT,
        XDEBUG_1_03,
        LPPL_1_3A,
        DTOA,
        APAFML,
        CC_BY_NC_2_5,
        MARTIN_BIRGMEIER,
        BITTORRENT_1_1,
        BITTORRENT_1_0,
        CC_BY_NC_2_0,
        CROSSWORD,
        PARITY_7_0_0,
        PSF_2_0,
        PLEXUS,
        HPND_SELL_VARIANT_MIT_DISCLAIMER,
        AGPL_1_0,
        GFDL_1_2_NO_INVARIANTS_OR_LATER,
        AFL_1_1,
        SWL,
        BAEKMUK,
        GPL_2_0_WITH_AUTOCONF_EXCEPTION,
        OLFL_1_3,
        FSFULLR,
        AFL_1_2,
        HPND_EXPORT_US,
        GFDL_1_1_OR_LATER,
        IEC_CODE_COMPONENTS_EULA,
        ZPL_1_1,
        BSD_3_CLAUSE_NO_NUCLEAR_LICENSE_2014,
        CDDL_1_0,
        CDDL_1_1,
        SHL_0_51,
        ZED,
        APACHE_1_1,
        APACHE_1_0,
        ICU,
        GPL_3_0_WITH_AUTOCONF_EXCEPTION,
        MIT_FEH,
        GLWTPL,
        CC_BY_SA_2_0_UK,
        FREEIMAGE,
        LOOP,
        XINETD,
        GFDL_1_2_INVARIANTS_ONLY,
        CC_BY_NC_3_0,
        EUPL_1_0,
        LIBSELINUX_1_0,
        EUPL_1_2,
        EUPL_1_1,
        SLEEPYCAT,
        SUNPRO,
        CC_BY_ND_1_0,
        LGPL_2_1PLUS,
        NUNIT,
        BARR,
        ETALAB_2_0,
        INFO_ZIP,
        BSD_4_3RENO,
        LPL_1_02,
        CPOL_1_02,
        ZPL_2_1,
        GPL_2_0_WITH_FONT_EXCEPTION,
        ZPL_2_0,
        GL2PS,
        LGPL_2_0_OR_LATER,
        LEPTONICA,
        OFFIS,
        MIROS,
        AGPL_1_0_OR_LATER,
        CC_BY_NC_4_0,
        LPPL_1_0,
        SCEA,
        CFITSIO,
        OGL_CANADA_2_0,
        ARTISTIC_1_0_PERL,
        LPPL_1_1,
        LPPL_1_2,
        CNRI_PYTHON_GPL_COMPATIBLE,
        CRYSTALSTACKER,
        CATOSL_1_1,
        CC_BY_ND_2_5,
        ARPHIC_1999,
        CC_BY_ND_2_0,
        JPNIC,
        OPENPBS_2_3,
        TORQUE_1_1,
        MIT_OPEN_GROUP,
        SMLNJ,
        GPL_2_0PLUS,
        NEWSLETR,
        OGC_1_0,
        AGPL_3_0,
        GFDL_1_2_OR_LATER,
        BSD_3_CLAUSE_NO_NUCLEAR_LICENSE,
        NCSA,
        METAMAIL,
        IPL_1_0,
        MPL_2_0_NO_COPYLEFT_EXCEPTION,
        GIFTWARE,
        AGPL_3_0_OR_LATER,
        OLDAP_2_0_1,
        CLARTISTIC,
        EGENIX,
        CERN_OHL_W_2_0,
        CC_BY_3_0,
        GFDL_1_1_NO_INVARIANTS_OR_LATER,
        GFDL_1_1_ONLY,
        FAIR,
        MPLUS,
        FSFAP,
        NRL,
        LPL_1_0,
        MS_RL,
        LGPL_2_0_ONLY,
        UCAR,
        CC_BY_SA_3_0_AT,
        CPAL_1_0,
        CC_BY_NC_ND_1_0,
        SGP4,
        CC_BY_ND_3_0,
        OFL_1_1_NO_RFN,
        ADACORE_DOC,
        CC_BY_NC_ND_2_5,
        OCLC_2_0,
        CECILL_2_1,
        CECILL_2_0,
        HPND_MARKUS_KUHN,
        LILIQ_P_1_1,
        IMATIX,
        RPL_1_5,
        LIBUTIL_DAVID_NUGENT,
        RPL_1_1,
        CERN_OHL_S_2_0,
        MPL_2_0,
        RSCPL,
        AMDPLPA,
        BSD_4_CLAUSE_SHORTENED,
        INTEL_ACPI,
        LAL_1_3,
        LAL_1_2,
        PSFRAG,
        CC_BY_4_0,
        JPL_IMAGE,
        NBPL_1_0,
        IJG,
        ARTISTIC_1_0_CL8,
        BLUEOAK_1_0_0,
        NTP,
        BOEHM_GC,
        MS_PL,
        BSD_SOURCE_CODE,
        GFDL_1_3_ONLY,
        SENDMAIL_8_23,
        XEROX,
        GLULXE,
        EUROSYM,
        RHECOS_1_1,
        LATEX2E_TRANSLATED_NOTICE,
        CC_BY_ND_4_0,
        CC_BY_NC_ND_2_0,
        BSD_3_CLAUSE_NO_MILITARY_LICENSE,
        OFL_1_0,
        SISSL,
        OFL_1_1,
        GPL_1_0_OR_LATER,
        BORCEUX,
        IJG_SHORT,
        MOTOSOTO,
        AMPAS,
        BSD_3_CLAUSE,
        APSL_2_0,
        CONDOR_1_1,
        SPL_1_0,
        MPL_1_0,
        MPL_1_1,
        CC_BY_SA_3_0_IGO,
        CORNELL_LOSSLESS_JPEG,
        GPL_2_0_OR_LATER,
        OLDAP_2_2_1,
        TU_BERLIN_2_0,
        OLDAP_2_2_2,
        FDK_AAC,
        GFDL_1_2_NO_INVARIANTS_ONLY,
        OPL_UK_3_0,
        WXWINDOWS,
        GLIDE,
        QHULL,
        CHECKMK,
        LINUX_OPENIB,
        CC_BY_NC_ND_3_0,
        BSD_ADVERTISING_ACKNOWLEDGEMENT,
        GFDL_1_2_INVARIANTS_OR_LATER,
        GPL_3_0_ONLY,
        NET_SNMP,
        CUA_OPL_1_0,
        MUP,
        NPL_1_0,
        NPL_1_1,
        NIST_SOFTWARE,
        LGPL_3_0_OR_LATER,
        ECL_2_0,
        APSL_1_1,
        APSL_1_2,
        CC_BY_SA_2_1_JP,
        MIT_0,
        APSL_1_0,
        XFREE86_1_1,
        APACHE_2_0,
        TCL,
        CC_BY_NC_SA_2_0_UK,
        GFDL_1_2,
        MITNFA,
        GFDL_1_3,
        GPL_2_0_WITH_BISON_EXCEPTION,
        ALADDIN,
        GFDL_1_1,
        QPL_1_0,
        VSL_1_0,
        C_UDA_1_0,
        OSET_PL_2_1,
        GRAPHICS_GEMS,
        LILIQ_R_1_1,
        CC_BY_3_0_NL,
        CC0_1_0,
        NASA_1_3,
        SAX_PD,
        BLESSING,
        CC_BY_NC_ND_4_0,
        ECOS_2_0,
        GFDL_1_1_INVARIANTS_ONLY,
        BAHYPH,
        W3C_19980720,
        CECILL_1_0,
        ZLIB,
        ODC_BY_1_0,
        CECILL_1_1,
        GNUPLOT,
        TAPR_OHL_1_0,
        ECL_1_0,
        WIDGET_WORKSHOP,
        BSD_3_CLAUSE_OPEN_MPI,
        ARTISTIC_1_0,
        IPA,
        VIM,
        CC_BY_NC_SA_3_0_DE,
        NOSL,
        BSD_3_CLAUSE_CLEAR
    }
    enum GuidePageGeneration {
        MARKDOWN,
        NULL,
        XML,
        HTML,
        GENERATED
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class ManifestPageComponent extends BackboneElement {
        /**
         * Label for the page intended for human display.
         *
         * Title of the page, for references
         */
        title?: string;
        /**
         * Relative path to the page.
         *
         * HTML page name
         */
        name: string;
        /**
         * The name of an anchor available on the page.
         *
         * Anchor available on the page
         */
        anchor?: string[];
        static revive(json: any): ManifestPageComponent;
        toJSON(): any;
    }
    class ManifestResourceComponent extends BackboneElement {
        /**
         * Where this resource is found.
         *
         * Location of the resource
         */
        reference: Reference;
        /**
         * If present, indicates profile(s) the instance is valid against.
         *
         * Profile(s) this is an example of
         */
        profile?: string[];
        /**
         * If true, indicates the resource is an example instance.
         *
         * Is this an example
         */
        isExample?: boolean;
        /**
         * The relative path for primary page for this resource within the IG.
         *
         * Relative path for page in IG
         */
        relativePath?: string;
        static revive(json: any): ManifestResourceComponent;
        toJSON(): any;
    }
    class ImplementationGuideManifestComponent extends BackboneElement {
        /**
         * Indicates the relative path of an additional non-page, non-image file that is part of the IG - e.g. zip, jar and similar files that could be the target of a hyperlink in a derived IG.
         *
         * Additional linkable file in IG
         */
        other?: string[];
        /**
         * Indicates a relative path to an image that exists within the IG.
         *
         * Image within the IG
         */
        image?: string[];
        /**
         * A resource that is part of the implementation guide. Conformance resources (value set, structure definition, capability statements etc.) are obvious candidates for inclusion, but any kind of resource can be included as an example resource.
         *
         * Resource in the implementation guide
         */
        resource: ImplementationGuide.ManifestResourceComponent[];
        /**
         * A pointer to official web page, PDF or other rendering of the implementation guide.
         *
         * Location of rendered implementation guide
         */
        rendering?: string;
        /**
         * Information about a page within the IG.
         *
         * HTML page within the parent IG
         */
        page?: ImplementationGuide.ManifestPageComponent[];
        static revive(json: any): ImplementationGuideManifestComponent;
        toJSON(): any;
    }
    class ImplementationGuideDefinitionTemplateComponent extends BackboneElement {
        /**
         * Type of template specified.
         *
         * Type of template specified
         */
        code: string;
        /**
         * The scope in which the template applies.
         *
         * The scope in which the template applies
         */
        scope?: string;
        /**
         * The source location for the template.
         *
         * The source location for the template
         */
        source: string;
        static revive(json: any): ImplementationGuideDefinitionTemplateComponent;
        toJSON(): any;
    }
    class ImplementationGuideDefinitionParameterComponent extends BackboneElement {
        /**
         * Value for named type.
         *
         * Value for named type
         */
        value: string;
        /**
         * A tool-specific code that defines the parameter.
         *
         * Code that identifies parameter
         */
        code: Coding;
        static revive(json: any): ImplementationGuideDefinitionParameterComponent;
        toJSON(): any;
    }
    class ImplementationGuideDefinitionPageComponent extends BackboneElement {
        /**
         * A short title used to represent this page in navigational structures such as table of contents, bread crumbs, etc.
         *
         * Short title shown for navigational assistance
         */
        title: string;
        /**
         * Indicates the URL or the actual content to provide for the page.
         *
         * Source for page
         */
        source?: string;
        /**
         * Nested Pages/Sections under this page.
         *
         * Nested Pages / Sections
         */
        page?: ImplementationGuide.ImplementationGuideDefinitionPageComponent[];
        /**
         * The url by which the page should be known when published.
         *
         * Name of the page when published
         */
        name: string;
        /**
         * A code that indicates how the page is generated.
         *
         * html | markdown | xml | generated
         */
        generation: string;
        static revive(json: any): ImplementationGuideDefinitionPageComponent;
        toJSON(): any;
    }
    class ImplementationGuideDefinitionResourceComponent extends BackboneElement {
        /**
         * Reference to the id of the grouping this resource appears in.
         *
         * Grouping this is part of
         */
        groupingId?: string;
        /**
         * If true, indicates the resource is an example instance.
         *
         * Is this an example
         */
        isExample?: boolean;
        /**
         * Indicates the FHIR Version(s) this artifact is intended to apply to. If no versions are specified, the resource is assumed to apply to all the versions stated in ImplementationGuide.fhirVersion.
         *
         * Versions this applies to (if different to IG)
         */
        fhirVersion?: string[];
        /**
         * If present, indicates profile(s) the instance is valid against.
         *
         * Profile(s) this is an example of
         */
        profile?: string[];
        /**
         * Where this resource is found.
         *
         * Location of the resource
         */
        reference: Reference;
        /**
         * A human assigned name for the resource. All resources SHOULD have a name, but the name may be extracted from the resource (e.g. ValueSet.name).
         *
         * Human readable name for the resource
         */
        name?: string;
        /**
         * A description of the reason that a resource has been included in the implementation guide.
         *
         * Reason why included in guide
         */
        description?: string;
        static revive(json: any): ImplementationGuideDefinitionResourceComponent;
        toJSON(): any;
    }
    class ImplementationGuideDefinitionGroupingComponent extends BackboneElement {
        /**
         * Human readable text describing the package.
         *
         * Human readable text describing the package
         */
        description?: string;
        /**
         * The human-readable title to display for the package of resources when rendering the implementation guide.
         *
         * Descriptive name for the package
         */
        name: string;
        static revive(json: any): ImplementationGuideDefinitionGroupingComponent;
        toJSON(): any;
    }
    class ImplementationGuideDefinitionComponent extends BackboneElement {
        /**
         * A logical group of resources. Logical groups can be used when building pages.
         *
         * Grouping used to present related resources in the IG
         */
        grouping?: ImplementationGuide.ImplementationGuideDefinitionGroupingComponent[];
        /**
         * A page / section in the implementation guide. The root page is the implementation guide home page.
         *
         * Page/Section in the Guide
         */
        page?: ImplementationGuide.ImplementationGuideDefinitionPageComponent;
        /**
         * A resource that is part of the implementation guide. Conformance resources (value set, structure definition, capability statements etc.) are obvious candidates for inclusion, but any kind of resource can be included as an example resource.
         *
         * Resource in the implementation guide
         */
        resource?: ImplementationGuide.ImplementationGuideDefinitionResourceComponent[];
        /**
         * A set of parameters that defines how the implementation guide is built. The parameters are defined by the relevant tools that build the implementation guides.
         *
         * Defines how IG is built by tools
         */
        parameter?: ImplementationGuide.ImplementationGuideDefinitionParameterComponent[];
        /**
         * A template for building resources.
         *
         * A template for building resources
         */
        template?: ImplementationGuide.ImplementationGuideDefinitionTemplateComponent[];
        static revive(json: any): ImplementationGuideDefinitionComponent;
        toJSON(): any;
    }
    class ImplementationGuideGlobalComponent extends BackboneElement {
        /**
         * The type of resource that all instances must conform to.
         *
         * Type this profile applies to
         */
        type: string;
        /**
         * A reference to the profile that all instances must conform to.
         *
         * Profile that all resources must conform to
         */
        profile: string;
        static revive(json: any): ImplementationGuideGlobalComponent;
        toJSON(): any;
    }
    class ImplementationGuideDependsOnComponent extends BackboneElement {
        /**
         * The NPM package name for the Implementation Guide that this IG depends on.
         *
         * NPM Package name for IG this depends on
         */
        packageId?: string;
        /**
         * A canonical reference to the Implementation guide for the dependency.
         *
         * Identity of the IG that this depends on
         */
        uri: string;
        /**
         * The version of the IG that is depended on, when the correct version is required to understand the IG correctly.
         *
         * Version of the IG
         */
        version?: string;
        /**
         * A description explaining the nature of the dependency on the listed IG.
         *
         * Why dependency exists
         */
        reason?: string;
        static revive(json: any): ImplementationGuideDependsOnComponent;
        toJSON(): any;
    }
}
