import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { UsageContext } from '../datatype/usage-context';
import { CanonicalResource } from '../model/canonical-resource';
import { CareTeam } from '../model/care-team';
import { Device } from '../model/device';
import { Group } from '../model/group';
import { HealthcareService } from '../model/healthcare-service';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>Requirements</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Requirements">http://hl7.org/fhir/StructureDefinition/Requirements</a>
 * </p>
 *
 */
export declare class Requirements extends CanonicalResource {
    /**
     * Explanation of why this Requirements is needed and why it has been designed as it has.
     *
     * Why this Requirements is defined
     */
    purpose?: string;
    /**
     * A legal or geographic region in which the Requirements is intended to be used.
     *
     * Intended jurisdiction for Requirements (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * A formal identifier that is used to identify this Requirements when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Additional identifier for the Requirements (business identifier)
     */
    identifier?: Identifier[];
    /**
     * The date  (and optionally time) when the Requirements was published. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the Requirements changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * A copyright statement relating to the Requirements and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the Requirements.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * The identifier that is used to identify this version of the Requirements when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the Requirements author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence.
     *
     * Business version of the Requirements
     */
    version?: string;
    /**
     * A short, descriptive, user-friendly title for the Requirements.
     *
     * Name for this Requirements (human friendly)
     */
    title?: string;
    /**
     * An absolute URI that is used to identify this Requirements when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this Requirements is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the Requirements is stored on different servers.
     *
     * Canonical identifier for this Requirements, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * A free text natural language description of the requirements.
     *
     * Natural language description of the requirements
     */
    description?: string;
    /**
     * A Boolean value to indicate that this Requirements is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * A reference to another artifact that created this set of requirements. This could be a Profile, etc., or external regulation, or business requirements expressed elsewhere.
     *
     * External artifact (rule/document etc. that) created this set of requirements
     */
    reference?: string[];
    /**
     * An actor these requirements are in regard to.
     *
     * Actor for these requirements
     */
    actor?: string[];
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate Requirements instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * The status of this Requirements. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the Requirements.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * A natural language name identifying the Requirements. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this Requirements (computer friendly)
     */
    name?: string;
    /**
     * Another set of Requirements that this set of Requirements builds on and updates.
     *
     * Other set of Requirements this builds on
     */
    derivedFrom?: string[];
    /**
     * The actual statement of requirement, in markdown format.
     *
     * Actual statement as markdown
     */
    statement?: Requirements.RequirementsStatementComponent[];
    readonly resourceType: string;
    static revive(json: any): Requirements;
    toJSON(): any;
}
export declare namespace Requirements {
    enum ConformanceExpectation {
        NULL,
        MAY,
        SHOULDNOT,
        SHOULD,
        SHALL
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class RequirementsStatementComponent extends BackboneElement {
        /**
         * Another statement on one of the requirements that this requirement clarifies or restricts.
         *
         * Another statement this clarifies/restricts ([url#]key)
         */
        derivedFrom?: string;
        /**
         * A short human usable label for this statement.
         *
         * Short Human label for this statement
         */
        label?: string;
        /**
         * The actual requirement for human consumption.
         *
         * The actual requirement
         */
        requirement: string;
        /**
         * Who asked for this statement to be a requirement. By default, it's assumed that the publisher knows who it is if it matters.
         *
         * Who asked for this statement
         */
        source?: CareTeam[] | Device[] | Group[] | HealthcareService[] | Organization[] | Patient[] | Practitioner[] | PractitionerRole[] | RelatedPerson[] | Reference[];
        /**
         * Key that identifies this statement (unique within this resource).
         *
         * Key that identifies this statement
         */
        key: string;
        /**
         * A reference to another artifact that created this requirement. This could be a Profile, etc., or external regulation, or business requirements expressed elsewhere.
         *
         * External artifact (rule/document etc. that) created this requirement
         */
        reference?: string[];
        /**
         * A larger requirement that this requirement helps to refine and enable.
         *
         * A larger requirement that this requirement helps to refine and enable
         */
        parent?: string;
        /**
         * A reference to another artifact that satisfies this requirement. This could be a Profile, extension, or an element in one of those, or a CapabilityStatement, OperationDefinition, SearchParameter, CodeSystem(/code), ValueSet, Libary etc.
         *
         * Design artifact that satisfies this requirement
         */
        satisfiedBy?: string[];
        /**
         * A short human usable label for this statement.
         *
         * SHALL | SHOULD | MAY | SHOULD-NOT
         */
        conformance?: string[];
        /**
         * This boolean flag is set to true of the text of the requirement is conditional on something e.g. it includes lanauage like 'if x then y'. This conditionality flag is introduced for purposes of filtering and colour highlighting etc.
         *
         * Set to true if requirements statement is conditional
         */
        conditionality?: boolean;
        static revive(json: any): RequirementsStatementComponent;
        toJSON(): any;
    }
}
