import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Quantity } from '../datatype/quantity';
import { Ratio } from '../datatype/ratio';
import { DomainResource } from '../model/domain-resource';
import { MedicationKnowledge } from '../model/medication-knowledge';
import { Organization } from '../model/organization';
/**
 * HAPI/FHIR <b>Medication</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Medication">http://hl7.org/fhir/StructureDefinition/Medication</a>
 * </p>
 *
 */
export declare class Medication extends DomainResource {
    /**
     * A code (or set of codes) that specify this medication, or a textual description if no code is available. Usage note: This could be a standard medication code such as a code from RxNorm, SNOMED CT, IDMP etc. It could also be a national or local formulary code, optionally with translations to other code systems.
     *
     * Codes that identify this medication
     */
    code?: CodeableConcept;
    /**
     * Identifies a particular constituent of interest in the product.
     *
     * Active or inactive ingredient
     */
    ingredient?: Medication.MedicationIngredientComponent[];
    /**
     * When the specified product code does not infer a package size, this is the specific amount of drug in the product.  For example, when specifying a product that has the same strength (For example, Insulin glargine 100 unit per mL solution for injection), this attribute provides additional clarification of the package amount (For example, 3 mL, 10mL, etc.).
     *
     * When the specified product code does not infer a package size, this is the specific amount of drug in the product
     */
    totalVolume?: Quantity;
    /**
     * Business identifier for this medication.
     *
     * Business identifier for this medication
     */
    identifier?: Identifier[];
    /**
     * The company or other legal entity that has authorization, from the appropriate drug regulatory authority,  to market a medicine in one or more jurisdictions.  Typically abbreviated MAH.Note:  The MAH may manufacture the product and may also contract the manufacturing of the product to one or more companies (organizations).
     *
     * Organization that has authorization to market medication
     */
    marketingAuthorizationHolder?: Organization | Reference;
    /**
     * Describes the form of the item.  Powder; tablets; capsule.
     *
     * powder | tablets | capsule +
     */
    doseForm?: CodeableConcept;
    /**
     * A reference to a knowledge resource that provides more information about this medication.
     *
     * Knowledge about this medication
     */
    definition?: MedicationKnowledge | Reference;
    /**
     * Information that only applies to packages (not products).
     *
     * Details about packaged medications
     */
    batch?: Medication.MedicationBatchComponent;
    /**
     * A code to indicate if the medication is in active use.
     *
     * active | inactive | entered-in-error
     */
    status?: string;
    readonly resourceType: string;
    static revive(json: any): Medication;
    toJSON(): any;
}
export declare namespace Medication {
    enum MedicationStatusCodes {
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        INACTIVE
    }
    class MedicationBatchComponent extends BackboneElement {
        /**
         * The assigned lot number of a batch of the specified product.
         *
         * Identifier assigned to batch
         */
        lotNumber?: string;
        /**
         * When this specific batch of product will expire.
         *
         * When batch will expire
         */
        expirationDate?: Date;
        static revive(json: any): MedicationBatchComponent;
        toJSON(): any;
    }
    class MedicationIngredientComponent extends BackboneElement {
        /**
         * Indication of whether this ingredient affects the therapeutic action of the drug.
         *
         * Active ingredient indicator
         */
        isActive?: boolean;
        /**
         * The ingredient (substance or medication) that the ingredient.strength relates to.  This is represented as a concept from a code system or described in another resource (Substance or Medication).
         *
         * The ingredient (substance or medication) that the ingredient.strength relates to
         */
        item: CodeableReference;
        /**
         * Specifies how many (or how much) of the items there are in this Medication.  For example, 250 mg per tablet.  This is expressed as a ratio where the numerator is 250mg and the denominator is 1 tablet but can also be expressed a quantity when the denominator is assumed to be 1 tablet.
         *
         * Quantity of ingredient present
         */
        strength?: Ratio | CodeableConcept | Quantity;
        static revive(json: any): MedicationIngredientComponent;
        toJSON(): any;
    }
}
