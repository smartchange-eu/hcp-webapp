import { Reference } from '../datatype/reference';
import { Attachment } from '../datatype/attachment';
import { CodeableConcept } from '../datatype/codeable-concept';
import { Coding } from '../datatype/coding';
import { ContactDetail } from '../datatype/contact-detail';
import { DataRequirement } from '../datatype/data-requirement';
import { Identifier } from '../datatype/identifier';
import { ParameterDefinition } from '../datatype/parameter-definition';
import { Period } from '../datatype/period';
import { RelatedArtifact } from '../datatype/related-artifact';
import { UsageContext } from '../datatype/usage-context';
import { Group } from '../model/group';
import { MetadataResource } from '../model/metadata-resource';
/**
 * HAPI/FHIR <b>Library</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/Library">http://hl7.org/fhir/StructureDefinition/Library</a>
 * </p>
 *
 */
export declare class Library extends MetadataResource {
    /**
     * An explanatory or alternate title for the library giving additional information about its content.
     *
     * Subordinate title of the library
     */
    subtitle?: string;
    /**
     * A short string (<50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved').
     *
     * Copyright holder and year(s)
     */
    copyrightLabel?: string;
    /**
     * The date on which the resource content was last reviewed. Review happens periodically after approval but does not change the original approval date.
     *
     * When the library was last reviewed by the publisher
     */
    lastReviewDate?: Date;
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate library instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    /**
     * The status of this library. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the library.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * Descriptive topics related to the content of the library. Topics provide a high-level categorization of the library that can be useful for filtering and searching.
     *
     * E.g. Education, Treatment, Assessment, etc
     */
    topic?: CodeableConcept[];
    /**
     * Describes a set of data that must be provided in order to be able to successfully perform the computations defined by the library.
     *
     * What data is referenced by this library
     */
    dataRequirement?: DataRequirement[];
    /**
     * A natural language name identifying the library. This name should be usable as an identifier for the module by machine processing applications such as code generation.
     *
     * Name for this library (computer friendly)
     */
    name?: string;
    /**
     * The period during which the library content was or is planned to be in active use.
     *
     * When the library is expected to be used
     */
    effectivePeriod?: Period;
    /**
     * An individiual or organization primarily involved in the creation and maintenance of the content.
     *
     * Who authored the content
     */
    author?: ContactDetail[];
    /**
     * A formal identifier that is used to identify this library when it is represented in other formats, or referenced in a specification, model, design or an instance. e.g. CMS or NQF identifiers for a measure artifact. Note that at least one identifier is required for non-experimental active artifacts.
     *
     * Additional identifier for the library
     */
    identifier?: Identifier[];
    /**
     * An individual or organization primarily responsible for internal coherence of the content.
     *
     * Who edited the content
     */
    editor?: ContactDetail[];
    /**
     * Related artifacts such as additional documentation, justification, or bibliographic references.
     *
     * Additional documentation, citations, etc
     */
    relatedArtifact?: RelatedArtifact[];
    /**
     * The identifier that is used to identify this version of the library when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the library author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence. To provide a version consistent with the Decision Support Service specification, use the format Major.Minor.Revision (e.g. 1.0.0). For more information on versioning knowledge assets, refer to the Decision Support Service specification. Note that a version is required for non-experimental active artifacts.
     *
     * Business version of the library
     */
    version?: string;
    /**
     * An absolute URI that is used to identify this library when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this library is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the library is stored on different servers.
     *
     * Canonical identifier for this library, represented as a URI (globally unique)
     */
    url?: string;
    /**
     * An individual or organization asserted by the publisher to be primarily responsible for review of some aspect of the content.
     *
     * Who reviewed the content
     */
    reviewer?: ContactDetail[];
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * The parameter element defines parameters used by the library.
     *
     * Parameters defined by the library
     */
    parameter?: ParameterDefinition[];
    /**
     * Indicates the mechanism used to compare versions to determine which is more current.
     *
     * How to compare versions
     */
    versionAlgorithm?: string | Coding;
    /**
     * An individual or organization asserted by the publisher to be responsible for officially endorsing the content for use in some setting.
     *
     * Who endorsed the content
     */
    endorser?: ContactDetail[];
    /**
     * Explanation of why this library is needed and why it has been designed as it has.
     *
     * Why this library is defined
     */
    purpose?: string;
    /**
     * A legal or geographic region in which the library is intended to be used.
     *
     * Intended jurisdiction for library (if applicable)
     */
    jurisdiction?: CodeableConcept[];
    /**
     * A detailed description of how the library is used from a clinical perspective.
     *
     * Describes the clinical usage of the library
     */
    usage?: string;
    /**
     * A code or group definition that describes the intended subject of the contents of the library.
     *
     * Type of individual the library content is focused on
     */
    subject?: CodeableConcept | Group | Reference;
    /**
     * The date  (and optionally time) when the library was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the library changes.
     *
     * Date last changed
     */
    date?: Date;
    /**
     * The date on which the resource content was approved by the publisher. Approval happens once when the content is officially approved for usage.
     *
     * When the library was approved by publisher
     */
    approvalDate?: Date;
    /**
     * A copyright statement relating to the library and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the library.
     *
     * Use and/or publishing restrictions
     */
    copyright?: string;
    /**
     * A short, descriptive, user-friendly title for the library.
     *
     * Name for this library (human friendly)
     */
    title?: string;
    /**
     * Identifies the type of library such as a Logic Library, Model Definition, Asset Collection, or Module Definition.
     *
     * logic-library | model-definition | asset-collection | module-definition
     */
    type: CodeableConcept;
    /**
     * The content of the library as an Attachment. The content may be a reference to a url, or may be directly embedded as a base-64 string. Either way, the contentType of the attachment determines how to interpret the content.
     *
     * Contents of the library, either embedded or referenced
     */
    content?: Attachment[];
    /**
     * A free text natural language description of the library from a consumer's perspective.
     *
     * Natural language description of the library
     */
    description?: string;
    /**
     * A Boolean value to indicate that this library is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage.
     *
     * For testing purposes, not real usage
     */
    experimental?: boolean;
    readonly resourceType: string;
    static revive(json: any): Library;
    toJSON(): any;
}
export declare namespace Library {
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
}
