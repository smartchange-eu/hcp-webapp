import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { CodeableReference } from '../datatype/codeable-reference';
import { Identifier } from '../datatype/identifier';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Device } from '../model/device';
import { DomainResource } from '../model/domain-resource';
import { Location } from '../model/location';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>InventoryReport</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/InventoryReport">http://hl7.org/fhir/StructureDefinition/InventoryReport</a>
 * </p>
 *
 */
export declare class InventoryReport extends DomainResource {
    /**
     * Whether the report is about the current inventory count (snapshot) or a differential change in inventory (change).
     *
     * snapshot | difference
     */
    countType: string;
    /**
     * What type of operation is being performed - addition or subtraction.
     *
     * addition | subtraction
     */
    operationType?: CodeableConcept;
    /**
     * When the report has been submitted.
     *
     * When the report has been submitted
     */
    reportedDateTime: Date;
    /**
     * Who submits the report.
     *
     * Who submits the report
     */
    reporter?: Practitioner | Patient | RelatedPerson | Device | Reference;
    /**
     * The reason for this count - regular count, ad-hoc count, new arrivals, etc.
     *
     * The reason for this count - regular count, ad-hoc count, new arrivals, etc
     */
    operationTypeReason?: CodeableConcept;
    /**
     * The status of the inventory check or notification - whether this is draft (e.g. the report is still pending some updates) or active.
     *
     * draft | requested | active | entered-in-error
     */
    status: string;
    /**
     * Business identifier for the InventoryReport.
     *
     * Business identifier for the report
     */
    identifier?: Identifier[];
    /**
     * A note associated with the InventoryReport.
     *
     * A note associated with the InventoryReport
     */
    note?: Annotation[];
    /**
     * An inventory listing section (grouped by any of the attributes).
     *
     * An inventory listing section (grouped by any of the attributes)
     */
    inventoryListing?: InventoryReport.InventoryReportInventoryListingComponent[];
    /**
     * The period the report refers to.
     *
     * The period the report refers to
     */
    reportingPeriod?: Period;
    readonly resourceType: string;
    static revive(json: any): InventoryReport;
    toJSON(): any;
}
export declare namespace InventoryReport {
    enum InventoryReportStatus {
        ENTEREDINERROR,
        NULL,
        ACTIVE,
        DRAFT,
        REQUESTED
    }
    enum InventoryCountType {
        DIFFERENCE,
        NULL,
        SNAPSHOT
    }
    class InventoryReportInventoryListingItemComponent extends BackboneElement {
        /**
         * The inventory category or classification of the items being reported. This is meant not for defining the product, but for inventory categories e.g. 'pending recount' or 'damaged'.
         *
         * The inventory category or classification of the items being reported
         */
        category?: CodeableConcept;
        /**
         * The code or reference to the item type.
         *
         * The code or reference to the item type
         */
        item: CodeableReference;
        /**
         * The quantity of the item or items being reported.
         *
         * The quantity of the item or items being reported
         */
        quantity: Quantity;
        static revive(json: any): InventoryReportInventoryListingItemComponent;
        toJSON(): any;
    }
    class InventoryReportInventoryListingComponent extends BackboneElement {
        /**
         * Location of the inventory items.
         *
         * Location of the inventory items
         */
        location?: Location | Reference;
        /**
         * The status of the items.
         *
         * The status of the items that are being reported
         */
        itemStatus?: CodeableConcept;
        /**
         * The date and time when the items were counted.
         *
         * The date and time when the items were counted
         */
        countingDateTime?: Date;
        /**
         * The item or items in this listing.
         *
         * The item or items in this listing
         */
        item?: InventoryReport.InventoryReportInventoryListingItemComponent[];
        static revive(json: any): InventoryReportInventoryListingComponent;
        toJSON(): any;
    }
}
