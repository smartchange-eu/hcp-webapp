import { Reference } from '../datatype/reference';
import { BackboneElement } from '../datatype/backbone-element';
import { Annotation } from '../datatype/annotation';
import { CodeableConcept } from '../datatype/codeable-concept';
import { ContactDetail } from '../datatype/contact-detail';
import { Identifier } from '../datatype/identifier';
import { Narrative } from '../datatype/narrative';
import { Period } from '../datatype/period';
import { Quantity } from '../datatype/quantity';
import { Range } from '../datatype/range';
import { RelatedArtifact } from '../datatype/related-artifact';
import { UsageContext } from '../datatype/usage-context';
import { Citation } from '../model/citation';
import { Device } from '../model/device';
import { Group } from '../model/group';
import { MetadataResource } from '../model/metadata-resource';
import { Organization } from '../model/organization';
import { Patient } from '../model/patient';
import { Practitioner } from '../model/practitioner';
import { PractitionerRole } from '../model/practitioner-role';
import { RelatedPerson } from '../model/related-person';
/**
 * HAPI/FHIR <b>EvidenceReport</b> Resource
 *
 * <p>
 * <b>Definition:</b>
 *
 * </p>
 *
 *
 * <p>
 * <b>Profile Definition:</b>
 * <a href="http://hl7.org/fhir/StructureDefinition/EvidenceReport">http://hl7.org/fhir/StructureDefinition/EvidenceReport</a>
 * </p>
 *
 */
export declare class EvidenceReport extends MetadataResource {
    /**
     * Link, description or reference to artifact associated with the report.
     *
     * Link, description or reference to artifact associated with the report
     */
    relatedArtifact?: RelatedArtifact[];
    /**
     * A formal identifier that is used to identify this EvidenceReport when it is represented in other formats, or referenced in a specification, model, design or an instance.
     *
     * Unique identifier for the evidence report
     */
    identifier?: Identifier[];
    /**
     * Used for footnotes and annotations.
     *
     * Used for footnotes and annotations
     */
    note?: Annotation[];
    /**
     * An individiual, organization, or device primarily responsible for internal coherence of the content.
     *
     * Who edited the content
     */
    editor?: ContactDetail[];
    /**
     * Specifies the subject or focus of the report. Answers "What is this report about?".
     *
     * Focus of the report
     */
    subject: EvidenceReport.EvidenceReportSubjectComponent;
    /**
     * An individiual, organization, or device primarily involved in the creation and maintenance of the content.
     *
     * Who authored the content
     */
    author?: ContactDetail[];
    /**
     * Citation Resource or display of suggested citation for this report.
     *
     * Citation for this report
     */
    citeAs?: Citation | string | Reference;
    /**
     * A formal identifier that is used to identify things closely related to this EvidenceReport.
     *
     * Identifiers for articles that may relate to more than one evidence report
     */
    relatedIdentifier?: Identifier[];
    /**
     * The root of the sections that make up the composition.
     *
     * Composition is broken into sections
     */
    section?: EvidenceReport.SectionComponent[];
    /**
     * An individiual, organization, or device primarily responsible for review of some aspect of the content.
     *
     * Who reviewed the content
     */
    reviewer?: ContactDetail[];
    /**
     * An absolute URI that is used to identify this EvidenceReport when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this summary is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the summary is stored on different servers.
     *
     * Canonical identifier for this EvidenceReport, represented as a globally unique URI
     */
    url?: string;
    /**
     * Specifies the kind of report, such as grouping of classifiers, search results, or human-compiled expression.
     *
     * Kind of report
     */
    type?: CodeableConcept;
    /**
     * Contact details to assist a user in finding and communicating with the publisher.
     *
     * Contact details for the publisher
     */
    contact?: ContactDetail[];
    /**
     * An individiual, organization, or device responsible for officially endorsing the content for use in some setting.
     *
     * Who endorsed the content
     */
    endorser?: ContactDetail[];
    /**
     * The name of the organization or individual responsible for the release and ongoing maintenance of the evidence report.
     *
     * Name of the publisher/steward (organization or individual)
     */
    publisher?: string;
    /**
     * The status of this summary. Enables tracking the life-cycle of the content.
     *
     * draft | active | retired | unknown
     */
    status: string;
    /**
     * Relationships that this composition has with other compositions or documents that already exist.
     *
     * Relationships to other compositions/documents
     */
    relatesTo?: EvidenceReport.EvidenceReportRelatesToComponent[];
    /**
     * The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate evidence report instances.
     *
     * The context that the content is intended to support
     */
    useContext?: UsageContext[];
    readonly resourceType: string;
    static revive(json: any): EvidenceReport;
    toJSON(): any;
}
export declare namespace EvidenceReport {
    enum ReportRelationshipType {
        REPLACES,
        NULL,
        REPLACEDWITH,
        AMENDEDWITH,
        APPENDS,
        AMENDS,
        TRANSFORMEDWITH,
        TRANSFORMS,
        APPENDEDWITH
    }
    enum PublicationStatus {
        NULL,
        ACTIVE,
        DRAFT,
        RETIRED,
        UNKNOWN
    }
    class SectionComponent extends BackboneElement {
        /**
         * Specifies the order applied to the items in the section entries.
         *
         * Order of section entries
         */
        orderedBy?: CodeableConcept;
        /**
         * If the section is empty, why the list is empty. An empty section typically has some text explaining the empty reason.
         *
         * Why the section is empty
         */
        emptyReason?: CodeableConcept;
        /**
         * Identifies who is responsible for the information in this section, not necessarily who typed it in.
         *
         * Who and/or what authored the section
         */
        author?: Patient[] | Practitioner[] | PractitionerRole[] | RelatedPerson[] | Device[] | Group[] | Organization[] | Reference[];
        /**
         * How the entry list was prepared - whether it is a working list that is suitable for being maintained on an ongoing basis, or if it represents a snapshot of a list of items from another source, or whether it is a prepared list where items may be marked as added, modified or deleted.
         *
         * working | snapshot | changes
         */
        mode?: string;
        /**
         * A definitional Resource identifying the kind of content contained within the section. This should be consistent with the section title.
         *
         * Classification of section by Resource
         */
        focusReference?: Reference;
        /**
         * The label for this particular section.  This will be part of the rendered content for the document, and is often used to build a table of contents.
         *
         * Label for section (e.g. for ToC)
         */
        title?: string;
        /**
         * A reference to the actual resource from which the narrative in the section is derived.
         *
         * Reference to resources as content
         */
        entryReference?: Reference[];
        /**
         * Specifies any type of classification of the evidence report.
         *
         * Extensible classifiers as content
         */
        entryClassifier?: CodeableConcept[];
        /**
         * A code identifying the kind of content contained within the section. This should be consistent with the section title.
         *
         * Classification of section (recommended)
         */
        focus?: CodeableConcept;
        /**
         * Quantity as content.
         *
         * Quantity as content
         */
        entryQuantity?: Quantity[];
        /**
         * A nested sub-section within this section.
         *
         * Nested Section
         */
        section?: EvidenceReport.SectionComponent[];
        /**
         * A human-readable narrative that contains the attested content of the section, used to represent the content of the resource to a human. The narrative need not encode all the structured data, but is peferred to contain sufficient detail to make it acceptable for a human to just read the narrative.
         *
         * Text summary of the section, for human interpretation
         */
        text?: Narrative;
        static revive(json: any): SectionComponent;
        toJSON(): any;
    }
    class EvidenceReportRelatesToTargetComponent extends BackboneElement {
        /**
         * Target of the relationship URL.
         *
         * Target of the relationship URL
         */
        url?: string;
        /**
         * Target of the relationship Resource reference.
         *
         * Target of the relationship Resource reference
         */
        resource?: Reference;
        /**
         * Target of the relationship Display.
         *
         * Target of the relationship Display
         */
        display?: string;
        /**
         * Target of the relationship Identifier.
         *
         * Target of the relationship Identifier
         */
        identifier?: Identifier;
        static revive(json: any): EvidenceReportRelatesToTargetComponent;
        toJSON(): any;
    }
    class EvidenceReportRelatesToComponent extends BackboneElement {
        /**
         * The target composition/document of this relationship.
         *
         * Target of the relationship
         */
        target: EvidenceReport.EvidenceReportRelatesToTargetComponent;
        /**
         * The type of relationship that this composition has with anther composition or document.
         *
         * replaces | amends | appends | transforms | replacedWith | amendedWith | appendedWith | transformedWith
         */
        code: string;
        static revive(json: any): EvidenceReportRelatesToComponent;
        toJSON(): any;
    }
    class EvidenceReportSubjectCharacteristicComponent extends BackboneElement {
        /**
         * Characteristic code.
         *
         * Characteristic code
         */
        code: CodeableConcept;
        /**
         * Timeframe for the characteristic.
         *
         * Timeframe for the characteristic
         */
        period?: Period;
        /**
         * Characteristic value.
         *
         * Characteristic value
         */
        value: Reference | CodeableConcept | boolean | Quantity | Range;
        /**
         * Is used to express not the characteristic.
         *
         * Is used to express not the characteristic
         */
        exclude?: boolean;
        static revive(json: any): EvidenceReportSubjectCharacteristicComponent;
        toJSON(): any;
    }
    class EvidenceReportSubjectComponent extends BackboneElement {
        /**
         * Used for general notes and annotations not coded elsewhere.
         *
         * Footnotes and/or explanatory notes
         */
        note?: Annotation[];
        /**
         * Characteristic.
         *
         * Characteristic
         */
        characteristic?: EvidenceReport.EvidenceReportSubjectCharacteristicComponent[];
        static revive(json: any): EvidenceReportSubjectComponent;
        toJSON(): any;
    }
}
