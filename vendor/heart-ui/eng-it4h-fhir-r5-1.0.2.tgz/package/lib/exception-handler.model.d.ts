import { ObservableInput } from 'rxjs';
export declare type ExceptionHandler = (operation: string, result?: any) => (error: any) => ObservableInput<any>;
