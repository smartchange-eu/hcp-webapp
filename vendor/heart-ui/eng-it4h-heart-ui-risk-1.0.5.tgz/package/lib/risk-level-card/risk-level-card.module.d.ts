import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as i0 from "@angular/core";
import * as i1 from "./risk-level-card.component";
import * as i2 from "@angular/common";
import * as i3 from "@eng-it4h/heart-ui-utils";
import * as i4 from "@ngx-translate/core";
import * as i5 from "@angular/material/icon";
import * as i6 from "@angular/material/progress-spinner";
import * as i7 from "@angular/material/button";
import * as i8 from "@angular/material/divider";
import * as i9 from "@angular/material/badge";
import * as i10 from "@swimlane/ngx-charts";
import * as i11 from "@angular/material/tooltip";
export declare function HttpLoaderFactoryRiskLevelCard(http: HttpClient): TranslateHttpLoader;
export declare class RiskLevelCardModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RiskLevelCardModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RiskLevelCardModule, [typeof i1.RiskLevelCardComponent], [typeof i2.CommonModule, typeof i3.SubTranslateModule, typeof i4.TranslateModule, typeof i5.MatIconModule, typeof i6.MatProgressSpinnerModule, typeof i7.MatButtonModule, typeof i8.MatDividerModule, typeof i9.MatBadgeModule, typeof i10.GaugeModule, typeof i11.MatTooltipModule], [typeof i1.RiskLevelCardComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RiskLevelCardModule>;
}
