import { OnInit } from '@angular/core';
import { Risk } from '@eng-it4h/heart-ui-model';
import * as i0 from "@angular/core";
export declare class RiskLevelCardComponent implements OnInit {
    risk: Risk.Prediction;
    customColors: any;
    data: any[];
    ngOnInit(): void;
    get percent(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<RiskLevelCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RiskLevelCardComponent, "heart-risk-level-card", never, { "risk": "risk"; }, {}, never, never, false, never>;
}
