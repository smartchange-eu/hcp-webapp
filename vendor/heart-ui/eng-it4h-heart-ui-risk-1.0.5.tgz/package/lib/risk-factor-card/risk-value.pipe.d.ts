import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class RiskValuePipe implements PipeTransform {
    constructor();
    transform(value: number): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<RiskValuePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<RiskValuePipe, "riskPercent", false>;
}
