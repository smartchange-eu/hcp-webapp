import { OnInit } from '@angular/core';
import { PatientCard } from '@eng-it4h/heart-ui-cdss';
import * as i0 from "@angular/core";
export declare class RiskFactorCardComponent implements OnInit {
    base?: PatientCard;
    card: PatientCard;
    label?: string;
    showRisk: boolean;
    riskPlaceholder: boolean;
    colorMap: Map<string, string>;
    maxDecimals: number;
    useArrows: boolean;
    showTooltip: boolean;
    baseValues: Map<string, any>;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RiskFactorCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RiskFactorCardComponent, "heart-risk-factor-card", never, { "base": "base"; "card": "card"; "label": "label"; "showRisk": "showRisk"; "riskPlaceholder": "riskPlaceholder"; "colorMap": "colorMap"; "maxDecimals": "maxDecimals"; "useArrows": "useArrows"; "showTooltip": "showTooltip"; }, {}, never, never, false, never>;
}
