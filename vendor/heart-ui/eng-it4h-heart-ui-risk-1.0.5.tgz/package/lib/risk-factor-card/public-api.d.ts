export * from './risk-factor-card.module';
export * from './risk-factor-card.component';
