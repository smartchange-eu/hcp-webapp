import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as i0 from "@angular/core";
import * as i1 from "./risk-gauge/risk-gauge.component";
import * as i2 from "./risk-factor-card.component";
import * as i3 from "./risk-value.pipe";
import * as i4 from "@angular/common";
import * as i5 from "@eng-it4h/heart-ui-utils";
import * as i6 from "@ngx-translate/core";
import * as i7 from "@angular/material/icon";
import * as i8 from "@angular/material/progress-spinner";
import * as i9 from "@angular/material/progress-bar";
import * as i10 from "@angular/material/button";
import * as i11 from "@angular/material/divider";
import * as i12 from "@angular/material/badge";
import * as i13 from "@angular/material/slider";
import * as i14 from "@angular/material/card";
import * as i15 from "@angular/material/tooltip";
import * as i16 from "@swimlane/ngx-charts";
export declare function HttpLoaderFactoryRiskFactorCard(http: HttpClient): TranslateHttpLoader;
export declare class RiskFactorCardModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RiskFactorCardModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RiskFactorCardModule, [typeof i1.RiskGaugeComponent, typeof i2.RiskFactorCardComponent, typeof i3.RiskValuePipe], [typeof i4.CommonModule, typeof i5.SubTranslateModule, typeof i6.TranslateModule, typeof i7.MatIconModule, typeof i8.MatProgressSpinnerModule, typeof i9.MatProgressBarModule, typeof i10.MatButtonModule, typeof i11.MatDividerModule, typeof i12.MatBadgeModule, typeof i13.MatSliderModule, typeof i14.MatCardModule, typeof i15.MatTooltipModule, typeof i16.GaugeModule, typeof i16.NgxChartsModule], [typeof i2.RiskFactorCardComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RiskFactorCardModule>;
}
