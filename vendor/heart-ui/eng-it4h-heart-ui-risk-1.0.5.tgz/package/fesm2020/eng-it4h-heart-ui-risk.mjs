import * as i0 from '@angular/core';
import { Component, Input, NgModule, ViewEncapsulation, ChangeDetectionStrategy, ViewChild, Pipe } from '@angular/core';
import * as i1$1 from '@angular/common';
import { CommonModule, isPlatformServer, isPlatformBrowser } from '@angular/common';
import { RiskLevel } from '@eng-it4h/heart-ui-model';
import * as i3 from '@swimlane/ngx-charts';
import { GaugeModule, BaseChartComponent, BarOrientation, calculateViewDimensions, ColorHelper, ScaleType, NgxChartsModule } from '@swimlane/ngx-charts';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { SubTranslateModule } from '@eng-it4h/heart-ui-utils';
import * as i1 from '@ngx-translate/core';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { MatDividerModule } from '@angular/material/divider';
import { MatBadgeModule } from '@angular/material/badge';
import * as i2 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { scaleLinear } from 'd3-scale';
import * as i2$1 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSliderModule } from '@angular/material/slider';

class RiskLevelCardComponent {
    constructor() {
        this.data = [];
    }
    ngOnInit() {
        this.data.push({ name: 'Risk', value: this.risk.probability * 100 });
        let color = '#FF5A33';
        if (this.risk.level === RiskLevel.LOW) {
            color = '#44803F';
        }
        else if (this.risk.level === RiskLevel.MODERATE) {
            color = '#FFEC5C';
        }
        this.customColors = [
            {
                name: 'Risk',
                value: color,
            },
        ];
    }
    get percent() {
        return Math.round(this.risk.probability * 1000) / 10;
    }
}
RiskLevelCardComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RiskLevelCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
RiskLevelCardComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: RiskLevelCardComponent, selector: "heart-risk-level-card", inputs: { risk: "risk" }, ngImport: i0, template: "<div class=\"risk-content\">\n  <ngx-charts-gauge [customColors]=\"customColors\" [results]=\"data\" [showAxis]=\"false\" [showText]=\"false\">\n  </ngx-charts-gauge>\n\n  <div class=\"risk-percentage\">\n    <h1>{{ percent }}%</h1>\n  </div>\n</div>", styles: [".risk-content{position:relative;display:flex;justify-content:center;align-items:center}.risk-percentage{position:absolute;font-size:2rem}\n"], dependencies: [{ kind: "component", type: i3.GaugeComponent, selector: "ngx-charts-gauge", inputs: ["legend", "legendTitle", "legendPosition", "min", "max", "textValue", "units", "bigSegments", "smallSegments", "results", "showAxis", "startAngle", "angleSpan", "activeEntries", "axisTickFormatting", "tooltipDisabled", "valueFormatting", "showText", "margin"], outputs: ["activate", "deactivate"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RiskLevelCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-risk-level-card', template: "<div class=\"risk-content\">\n  <ngx-charts-gauge [customColors]=\"customColors\" [results]=\"data\" [showAxis]=\"false\" [showText]=\"false\">\n  </ngx-charts-gauge>\n\n  <div class=\"risk-percentage\">\n    <h1>{{ percent }}%</h1>\n  </div>\n</div>", styles: [".risk-content{position:relative;display:flex;justify-content:center;align-items:center}.risk-percentage{position:absolute;font-size:2rem}\n"] }]
        }], propDecorators: { risk: [{
                type: Input
            }] } });

// AoT requires an exported function for factories
function HttpLoaderFactoryRiskLevelCard(http) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class RiskLevelCardModule {
}
RiskLevelCardModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RiskLevelCardModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
RiskLevelCardModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: RiskLevelCardModule, declarations: [RiskLevelCardComponent], imports: [CommonModule,
        SubTranslateModule, i1.TranslateModule, MatIconModule,
        MatProgressSpinnerModule,
        MatButtonModule,
        MatDividerModule,
        MatBadgeModule,
        GaugeModule,
        MatTooltipModule], exports: [RiskLevelCardComponent] });
RiskLevelCardModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RiskLevelCardModule, imports: [CommonModule,
        SubTranslateModule,
        TranslateModule.forChild({
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactoryRiskLevelCard,
                deps: [HttpClient],
            },
            isolate: true,
        }),
        MatIconModule,
        MatProgressSpinnerModule,
        MatButtonModule,
        MatDividerModule,
        MatBadgeModule,
        GaugeModule,
        MatTooltipModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RiskLevelCardModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [RiskLevelCardComponent],
                    imports: [
                        CommonModule,
                        SubTranslateModule,
                        TranslateModule.forChild({
                            loader: {
                                provide: TranslateLoader,
                                useFactory: HttpLoaderFactoryRiskLevelCard,
                                deps: [HttpClient],
                            },
                            isolate: true,
                        }),
                        MatIconModule,
                        MatProgressSpinnerModule,
                        MatButtonModule,
                        MatDividerModule,
                        MatBadgeModule,
                        GaugeModule,
                        MatTooltipModule,
                    ],
                    exports: [RiskLevelCardComponent],
                }]
        }] });

const VERDANA_FONT_WIDTHS_16_PX = {
    '0': 10,
    '1': 10,
    '2': 10,
    '3': 10,
    '4': 10,
    '5': 10,
    '6': 10,
    '7': 10,
    '8': 10,
    '9': 10,
    A: 11,
    B: 11,
    C: 11,
    D: 12,
    E: 10,
    F: 9,
    G: 12,
    H: 12,
    I: 7,
    J: 7,
    K: 11,
    L: 9,
    M: 13,
    N: 12,
    O: 13,
    P: 10,
    Q: 13,
    R: 11,
    S: 11,
    T: 10,
    U: 12,
    V: 11,
    W: 16,
    X: 11,
    Y: 10,
    Z: 11,
    a: 10,
    b: 10,
    c: 8,
    d: 10,
    e: 10,
    f: 6,
    g: 10,
    h: 10,
    i: 4,
    j: 6,
    k: 9,
    l: 4,
    m: 16,
    n: 10,
    o: 10,
    p: 10,
    q: 10,
    r: 7,
    s: 8,
    t: 6,
    u: 10,
    v: 9,
    w: 13,
    x: 9,
    y: 9,
    z: 8,
    '!': 6,
    '@': 16,
    '#': 13,
    $: 10,
    '%': 17,
    '^': 13,
    '&': 12,
    '*': 10,
    '(': 7,
    ')': 7,
    _: 10,
    '-': 7,
    '+': 13,
    '=': 13,
    ',': 6,
    '.': 6,
    '/': 7,
    "'": 4,
    ':': 7,
    '|': 7,
    '?': 9,
    ';': 7,
    '<': 13,
    '>': 13,
};

var ElementType;
(function (ElementType) {
    ElementType["Value"] = "value";
    ElementType["Units"] = "units";
})(ElementType || (ElementType = {}));
class RiskGaugeComponent extends BaseChartComponent {
    constructor() {
        super(...arguments);
        this.maxDecimals = 3;
        this.useArrows = false;
        this.hideTooltip = false;
        this.value = 0;
        this.units = '';
        this.label = '';
        this.previousValue = 0;
        this.min = 0;
        this.max = 100;
        this.margin = [10, 20, 10, 20];
        this.valueResizeScale = 1;
        this.unitsResizeScale = 1;
        this.valueTextTransform = '';
        this.valueTranslate = '';
        this.unitsTextTransform = '';
        this.unitsTranslate = '';
        // specific to counterfactual.
        // TODO: need some cleaning when it works properly
        this.hasProjectedValue = false;
        this.projXoffest = 0;
        this.transformBar = '';
        this.barOrientation = BarOrientation;
        this.barValue = 0;
        this.customColors = (statName) => {
            return this.color ?? '#1A0C42';
        };
    }
    ngOnInit() {
        if (this.feature && this.feature?.valueType === 'number') {
            this.value = this.feature.value ?? this.value;
            this.units = this.feature.unit ?? this.units;
            this.label = this.getInLabel(this.feature.key) ?? this.label;
        }
        if (this.baseValue) {
            this.hasProjectedValue = true;
            this.previousValue = this.baseValue;
        }
        this.value = this.defaultValue || this.value;
        this.label = this.defaultLabel || this.label;
        this.units = this.defaultUnits || this.units;
        this.barValue = this.hasProjectedValue ? Math.abs(this.value - this.previousValue) : 0;
    }
    getInLabel(codedV) {
        return codedV?.system?.length > 0 ? codedV?.uniqueLabelKey : codedV?.code;
    }
    ngAfterViewInit() {
        super.ngAfterViewInit();
        setTimeout(() => {
            this.scaleText(ElementType.Value);
            this.scaleText(ElementType.Units);
        });
    }
    updateMin() {
        if (this.value === undefined || this.value - this.previousValue === 0)
            return 0;
        const m = this.previousValue - Math.abs((this.previousValue - this.value) * 3);
        return m > 0 ? m : 0;
    }
    updateMax() {
        return this.previousValue + Math.abs(this.previousValue - this.min);
    }
    update() {
        super.update();
        this.min = this.updateMin();
        this.max = this.updateMax();
        this.dims = calculateViewDimensions({
            width: this.width,
            height: this.height,
            margins: this.margin,
        });
        this.valueDomain = this.getValueDomain();
        this.valueScale = this.getValueScale();
        this.displayValue = this.getDisplayValue();
        this.setColors();
        const xOffset = this.margin[3] + this.dims.width / 2;
        const yOffset = this.margin[0] + this.dims.height / 2;
        this.transform = `translate(${xOffset}, ${yOffset})`;
        this.transformLine = `translate(${this.margin[3] + this.valueScale(this.previousValue)}, ${yOffset})`;
        this.projXoffest = this.getBarXOffset();
        this.transformBar = this.hasProjectedValue ? `translate(${this.valueScale(this.projXoffest)}, 0)` : '';
        this.valueTranslate = `translate(0, -15)`;
        this.unitsTranslate = `translate(0, 15)`;
        if (isPlatformServer(this.platformId)) {
            this.scaleTextSSR('value');
            this.scaleTextSSR('units');
        }
        else {
            setTimeout(() => this.scaleText(ElementType.Value), 50);
            setTimeout(() => this.scaleText(ElementType.Units), 50);
        }
    }
    getValueDomain() {
        return [this.min, this.max];
    }
    getValueScale() {
        return scaleLinear().range([0, this.dims.width]).domain(this.valueDomain);
    }
    getDisplayValue() {
        return this.formatLabel();
    }
    formatLabel() {
        if (this.useArrows)
            return this.hasProjectedValue ? `${this.roundDecimals(this.previousValue)} → ${this.roundDecimals(this.value)}` : `${this.roundDecimals(this.value)}`;
        else
            return this.hasProjectedValue ? `${this.roundDecimals(this.value)} (${this.roundDecimals(this.previousValue)})` : `${this.roundDecimals(this.value)}`;
    }
    getTooltipKey(codedV) {
        const label = codedV?.system?.length > 0 ? codedV?.uniqueLabelKey : codedV?.code;
        return 'tooltip.risk-factor.' + label;
    }
    roundDecimals(v) {
        const factor = Math.pow(10, this.maxDecimals);
        return Math.round(v * factor) / factor;
    }
    getBarXOffset() {
        return this.value < this.previousValue ? this.value : this.previousValue;
    }
    scaleText(element, repeat = true) {
        let el;
        let resizeScale;
        if (element === ElementType.Value) {
            el = this.valueTextEl;
            resizeScale = this.valueResizeScale;
        }
        else {
            el = this.unitsTextEl;
            resizeScale = this.unitsResizeScale;
        }
        const { width, height } = el.nativeElement.getBoundingClientRect();
        if (width === 0 || height === 0)
            return;
        const oldScale = resizeScale;
        const availableWidth = this.dims.width;
        const availableHeight = Math.max(this.dims.height / 2 - 15, 0);
        const resizeScaleWidth = Math.floor((availableWidth / (width / resizeScale)) * 100) / 100;
        const resizeScaleHeight = Math.floor((availableHeight / (height / resizeScale)) * 100) / 100;
        resizeScale = Math.min(resizeScaleHeight, resizeScaleWidth);
        if (resizeScale !== oldScale) {
            if (element === ElementType.Value) {
                this.valueResizeScale = resizeScale;
                this.valueTextTransform = `scale(${resizeScale}, ${resizeScale})`;
            }
            else {
                this.unitsResizeScale = resizeScale;
                this.unitsTextTransform = `scale(${resizeScale}, ${resizeScale})`;
            }
            this.cd.markForCheck();
            if (repeat && isPlatformBrowser(this.platformId)) {
                setTimeout(() => {
                    this.scaleText(element, false);
                }, 50);
            }
        }
    }
    calculateTextWidth(fontFamilyKey, text, defaultWidth = 8) {
        return text.split('').reduce((acc, curr) => {
            const width = fontFamilyKey[curr] || defaultWidth;
            return acc + width;
        }, 0);
    }
    scaleTextSSR(element) {
        let resizeScale = 1;
        const value = element === 'value' ? this.displayValue : this.units;
        const width = this.calculateTextWidth(VERDANA_FONT_WIDTHS_16_PX, value, 10);
        const height = 25;
        const availableWidth = this.dims.width;
        const availableHeight = Math.max(this.dims.height / 2 - 15, 0);
        const resizeScaleWidth = Math.floor((availableWidth / (width / resizeScale)) * 100) / 100;
        const resizeScaleHeight = Math.floor((availableHeight / (height / resizeScale)) * 100) / 100;
        resizeScale = Math.min(resizeScaleHeight, resizeScaleWidth);
        if (element === 'value') {
            this.valueResizeScale = resizeScale;
            this.valueTextTransform = `scale(${resizeScale}, ${resizeScale})`;
        }
        else {
            this.unitsResizeScale = resizeScale;
            this.unitsTextTransform = `scale(${resizeScale}, ${resizeScale})`;
        }
        this.cd.markForCheck();
    }
    onClick() {
        this.select.emit({
            name: 'Value',
            value: this.value,
        });
    }
    setColors() {
        this.colors = new ColorHelper(this.scheme, ScaleType.Ordinal, [this.value], this.customColors);
    }
}
RiskGaugeComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RiskGaugeComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
RiskGaugeComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: RiskGaugeComponent, selector: "heart-risk-gauge", inputs: { feature: "feature", baseValue: "baseValue", defaultValue: "defaultValue", defaultUnits: "defaultUnits", defaultLabel: "defaultLabel", defaultMin: "defaultMin", defaultMax: "defaultMax", maxDecimals: "maxDecimals", useArrows: "useArrows", hideTooltip: "hideTooltip", color: "color" }, viewQueries: [{ propertyName: "valueTextEl", first: true, predicate: ["valueTextEl"], descendants: true }, { propertyName: "unitsTextEl", first: true, predicate: ["unitsTextEl"], descendants: true }], usesInheritance: true, ngImport: i0, template: "<ngx-charts-chart [view]=\"[width, height]\" [showLegend]=\"false\" [animations]=\"animations\">\n  <svg:g class=\"linear-gauge chart\">\n    <svg:g ngx-charts-bar class=\"background-bar\" [width]=\"dims.width\" [height]=\"3\" [x]=\"margin[3]\"\n      [y]=\"dims.height / 2 + margin[0] - 2\" [data]=\"{ value: undefined, name: undefined }\"\n      [orientation]=\"barOrientation.Horizontal\" [roundEdges]=\"true\" [animations]=\"animations\">\n    </svg:g>\n    <svg:g *ngIf=\"hasProjectedValue\" ngx-charts-bar [width]=\"valueScale(min+ barValue)\" [height]=\"3\"\n      [x]=\"margin[3]\" [attr.transform]=\"transformBar\" [y]=\"dims.height / 2 + margin[0] - 2\"\n      [fill]=\"colors.getColor(units)\" [data]=\"{ value: undefined, name: undefined }\"\n      [orientation]=\"barOrientation.Horizontal\" [roundEdges]=\"true\" [animations]=\"animations\">\n    </svg:g>\n\n    <svg:line [attr.transform]=\"transformLine\" x1=\"0\" y1=\"5\" x2=\"0\" y2=\"15\"\n      [attr.stroke]=\"colors.getColor(units)\" />\n\n    <svg:line [attr.transform]=\"transformLine\" x1=\"0\" y1=\"-5\" x2=\"0\" y2=\"-15\"\n      [attr.stroke]=\"colors.getColor(units)\" />\n\n    <svg:g [attr.transform]=\"transform\">\n      <svg:g [attr.transform]=\"valueTranslate\">\n        <svg:text #valueTextEl class=\"value\" [style.textAnchor]=\"'middle'\"\n          [attr.transform]=\"valueTextTransform\" alignment-baseline=\"after-edge\">\n          {{ displayValue + ' ' + (units | translate) }}\n        </svg:text>\n      </svg:g>\n\n      <svg:g [attr.transform]=\"unitsTranslate\">\n        <svg:text #unitsTextEl class=\"units\" [style.textAnchor]=\"'middle'\"\n          [matTooltip]=\"('tooltip.'+label) | translate\" matTooltipShowDelay=\"500\" [matTooltipDisabled]=\"hideTooltip\"\n          [attr.transform]=\"unitsTextTransform\" alignment-baseline=\"before-edge\">\n          {{ label | translate }}\n        </svg:text>\n      </svg:g>\n    </svg:g>\n  </svg:g>\n</ngx-charts-chart>", styles: [".ngx-charts-outer{animation:chartFadeIn linear .6s}@keyframes chartFadeIn{0%{opacity:0}20%{opacity:0}to{opacity:1}}.ngx-charts{float:left;overflow:visible}.ngx-charts .circle,.ngx-charts .cell,.ngx-charts .bar,.ngx-charts .node,.ngx-charts .link,.ngx-charts .arc{cursor:pointer}.ngx-charts .bar.active,.ngx-charts .bar:hover,.ngx-charts .cell.active,.ngx-charts .cell:hover,.ngx-charts .arc.active,.ngx-charts .arc:hover,.ngx-charts .node.active,.ngx-charts .node:hover,.ngx-charts .link.active,.ngx-charts .link:hover,.ngx-charts .card.active,.ngx-charts .card:hover{opacity:.8;transition:opacity .1s ease-in-out}.ngx-charts .bar:focus,.ngx-charts .cell:focus,.ngx-charts .arc:focus,.ngx-charts .node:focus,.ngx-charts .link:focus,.ngx-charts .card:focus{outline:none}.ngx-charts .bar.hidden,.ngx-charts .cell.hidden,.ngx-charts .arc.hidden,.ngx-charts .node.hidden,.ngx-charts .link.hidden,.ngx-charts .card.hidden{display:none}.ngx-charts g:focus{outline:none}.ngx-charts .line-series.inactive,.ngx-charts .line-series-range.inactive,.ngx-charts .polar-series-path.inactive,.ngx-charts .polar-series-area.inactive,.ngx-charts .area-series.inactive{transition:opacity .1s ease-in-out;opacity:.2}.ngx-charts .line-highlight{display:none}.ngx-charts .line-highlight.active{display:block}.ngx-charts .area{opacity:.6}.ngx-charts .circle:hover{cursor:pointer}.ngx-charts .label{font-size:12px;font-weight:400}.ngx-charts .tooltip-anchor{fill:#000}.ngx-charts .gridline-path{stroke:#ddd;stroke-width:1;fill:none}.ngx-charts .refline-path{stroke:#a8b2c7;stroke-width:1;stroke-dasharray:5;stroke-dashoffset:5}.ngx-charts .refline-label{font-size:9px}.ngx-charts .reference-area{fill-opacity:.05;fill:#000}.ngx-charts .gridline-path-dotted{stroke:#ddd;stroke-width:1;fill:none;stroke-dasharray:1,20;stroke-dashoffset:3}.ngx-charts .grid-panel rect{fill:none}.ngx-charts .grid-panel.odd rect{fill:#0000000d}\n", ".linear-gauge{cursor:pointer}.linear-gauge .background-bar path{fill:#0000000d}.linear-gauge .units{fill:#666}\n"], dependencies: [{ kind: "directive", type: i1$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.MatTooltip, selector: "[matTooltip]", exportAs: ["matTooltip"] }, { kind: "component", type: i3.ChartComponent, selector: "ngx-charts-chart", inputs: ["view", "showLegend", "legendOptions", "legendType", "activeEntries", "animations"], outputs: ["legendLabelClick", "legendLabelActivate", "legendLabelDeactivate"] }, { kind: "component", type: i3.BarComponent, selector: "g[ngx-charts-bar]", inputs: ["fill", "data", "width", "height", "x", "y", "orientation", "roundEdges", "gradient", "offset", "isActive", "stops", "animations", "ariaLabel", "noBarWhenZero"], outputs: ["select", "activate", "deactivate"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RiskGaugeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-risk-gauge', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ngx-charts-chart [view]=\"[width, height]\" [showLegend]=\"false\" [animations]=\"animations\">\n  <svg:g class=\"linear-gauge chart\">\n    <svg:g ngx-charts-bar class=\"background-bar\" [width]=\"dims.width\" [height]=\"3\" [x]=\"margin[3]\"\n      [y]=\"dims.height / 2 + margin[0] - 2\" [data]=\"{ value: undefined, name: undefined }\"\n      [orientation]=\"barOrientation.Horizontal\" [roundEdges]=\"true\" [animations]=\"animations\">\n    </svg:g>\n    <svg:g *ngIf=\"hasProjectedValue\" ngx-charts-bar [width]=\"valueScale(min+ barValue)\" [height]=\"3\"\n      [x]=\"margin[3]\" [attr.transform]=\"transformBar\" [y]=\"dims.height / 2 + margin[0] - 2\"\n      [fill]=\"colors.getColor(units)\" [data]=\"{ value: undefined, name: undefined }\"\n      [orientation]=\"barOrientation.Horizontal\" [roundEdges]=\"true\" [animations]=\"animations\">\n    </svg:g>\n\n    <svg:line [attr.transform]=\"transformLine\" x1=\"0\" y1=\"5\" x2=\"0\" y2=\"15\"\n      [attr.stroke]=\"colors.getColor(units)\" />\n\n    <svg:line [attr.transform]=\"transformLine\" x1=\"0\" y1=\"-5\" x2=\"0\" y2=\"-15\"\n      [attr.stroke]=\"colors.getColor(units)\" />\n\n    <svg:g [attr.transform]=\"transform\">\n      <svg:g [attr.transform]=\"valueTranslate\">\n        <svg:text #valueTextEl class=\"value\" [style.textAnchor]=\"'middle'\"\n          [attr.transform]=\"valueTextTransform\" alignment-baseline=\"after-edge\">\n          {{ displayValue + ' ' + (units | translate) }}\n        </svg:text>\n      </svg:g>\n\n      <svg:g [attr.transform]=\"unitsTranslate\">\n        <svg:text #unitsTextEl class=\"units\" [style.textAnchor]=\"'middle'\"\n          [matTooltip]=\"('tooltip.'+label) | translate\" matTooltipShowDelay=\"500\" [matTooltipDisabled]=\"hideTooltip\"\n          [attr.transform]=\"unitsTextTransform\" alignment-baseline=\"before-edge\">\n          {{ label | translate }}\n        </svg:text>\n      </svg:g>\n    </svg:g>\n  </svg:g>\n</ngx-charts-chart>", styles: [".ngx-charts-outer{animation:chartFadeIn linear .6s}@keyframes chartFadeIn{0%{opacity:0}20%{opacity:0}to{opacity:1}}.ngx-charts{float:left;overflow:visible}.ngx-charts .circle,.ngx-charts .cell,.ngx-charts .bar,.ngx-charts .node,.ngx-charts .link,.ngx-charts .arc{cursor:pointer}.ngx-charts .bar.active,.ngx-charts .bar:hover,.ngx-charts .cell.active,.ngx-charts .cell:hover,.ngx-charts .arc.active,.ngx-charts .arc:hover,.ngx-charts .node.active,.ngx-charts .node:hover,.ngx-charts .link.active,.ngx-charts .link:hover,.ngx-charts .card.active,.ngx-charts .card:hover{opacity:.8;transition:opacity .1s ease-in-out}.ngx-charts .bar:focus,.ngx-charts .cell:focus,.ngx-charts .arc:focus,.ngx-charts .node:focus,.ngx-charts .link:focus,.ngx-charts .card:focus{outline:none}.ngx-charts .bar.hidden,.ngx-charts .cell.hidden,.ngx-charts .arc.hidden,.ngx-charts .node.hidden,.ngx-charts .link.hidden,.ngx-charts .card.hidden{display:none}.ngx-charts g:focus{outline:none}.ngx-charts .line-series.inactive,.ngx-charts .line-series-range.inactive,.ngx-charts .polar-series-path.inactive,.ngx-charts .polar-series-area.inactive,.ngx-charts .area-series.inactive{transition:opacity .1s ease-in-out;opacity:.2}.ngx-charts .line-highlight{display:none}.ngx-charts .line-highlight.active{display:block}.ngx-charts .area{opacity:.6}.ngx-charts .circle:hover{cursor:pointer}.ngx-charts .label{font-size:12px;font-weight:400}.ngx-charts .tooltip-anchor{fill:#000}.ngx-charts .gridline-path{stroke:#ddd;stroke-width:1;fill:none}.ngx-charts .refline-path{stroke:#a8b2c7;stroke-width:1;stroke-dasharray:5;stroke-dashoffset:5}.ngx-charts .refline-label{font-size:9px}.ngx-charts .reference-area{fill-opacity:.05;fill:#000}.ngx-charts .gridline-path-dotted{stroke:#ddd;stroke-width:1;fill:none;stroke-dasharray:1,20;stroke-dashoffset:3}.ngx-charts .grid-panel rect{fill:none}.ngx-charts .grid-panel.odd rect{fill:#0000000d}\n", ".linear-gauge{cursor:pointer}.linear-gauge .background-bar path{fill:#0000000d}.linear-gauge .units{fill:#666}\n"] }]
        }], propDecorators: { feature: [{
                type: Input
            }], baseValue: [{
                type: Input
            }], defaultValue: [{
                type: Input
            }], defaultUnits: [{
                type: Input
            }], defaultLabel: [{
                type: Input
            }], defaultMin: [{
                type: Input
            }], defaultMax: [{
                type: Input
            }], maxDecimals: [{
                type: Input
            }], useArrows: [{
                type: Input
            }], hideTooltip: [{
                type: Input
            }], valueTextEl: [{
                type: ViewChild,
                args: ['valueTextEl']
            }], unitsTextEl: [{
                type: ViewChild,
                args: ['unitsTextEl']
            }], color: [{
                type: Input
            }] } });

class RiskValuePipe {
    constructor() { }
    transform(value) {
        return Math.round(value * 10000) / 100;
    }
}
RiskValuePipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RiskValuePipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
RiskValuePipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: RiskValuePipe, name: "riskPercent" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RiskValuePipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'riskPercent',
                }]
        }], ctorParameters: function () { return []; } });

class RiskFactorCardComponent {
    constructor() {
        this.showRisk = false;
        this.riskPlaceholder = false;
        this.colorMap = new Map();
        this.maxDecimals = 3;
        this.useArrows = false;
        this.showTooltip = true;
        this.baseValues = new Map();
    }
    ngOnInit() {
        if (this.base?.features) {
            this.base.features.forEach((f) => {
                if (typeof f.value == 'number') {
                    this.baseValues.set(f.key.uniqueLabelKey, Math.round(f.value * 100) / 100);
                }
                else
                    this.baseValues.set(f.key.uniqueLabelKey, f.value);
            });
        }
    }
}
RiskFactorCardComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RiskFactorCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
RiskFactorCardComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: RiskFactorCardComponent, selector: "heart-risk-factor-card", inputs: { base: "base", card: "card", label: "label", showRisk: "showRisk", riskPlaceholder: "riskPlaceholder", colorMap: "colorMap", maxDecimals: "maxDecimals", useArrows: "useArrows", showTooltip: "showTooltip" }, ngImport: i0, template: "<mat-card class=\"example-card\">\n  <mat-card-header *ngIf=\"label\">\n    <mat-card-title>{{label}}</mat-card-title>\n  </mat-card-header>\n  <mat-card-content>\n    <div class=\"counterfactual-card\">\n      <div *ngIf=\"!riskPlaceholder && showRisk && card.risk\"\n        [ngClass]=\"{'risk-low': card.level  == 'low', 'risk-moderate': card.level  == 'moderate', 'risk-high': card.level  == 'high'}\"\n        class=\"feature-line\">\n        <heart-risk-gauge [defaultValue]=\"card.risk | riskPercent\" defaultLabel=\"Risk\"\n          defaultUnits=\"%\" [defaultMin]=\"0\" [defaultMax]=\"100\" [maxDecimals]=\"maxDecimals\"\n          [useArrows]=\"useArrows\"\n          [baseValue]=\"(base?.risk ? (base.risk | riskPercent) : undefined)\" [hideTooltip]=\"true\"></heart-risk-gauge>\n      </div>\n      <div *ngIf=\"riskPlaceholder\" class=\"feature-line risk-empty\">\n        <span></span>\n      </div>\n      <div *ngFor=\"let feat of card.features\" class=\"feature-line\">\n        <heart-risk-gauge [feature]=\"feat\" [baseValue]=\"baseValues.get(feat?.key?.uniqueLabelKey)\"\n          [maxDecimals]=\"maxDecimals\" [useArrows]=\"useArrows\"\n          [color]=\"colorMap.get(feat?.key?.uniqueLabelKey)\" [hideTooltip]=\"!showTooltip\"></heart-risk-gauge>\n      </div>\n    </div>\n  </mat-card-content>\n</mat-card>", styles: [".counterfactual-card{border:1px solid #e0e0e0;box-shadow:0 2px 5px #0000001a;margin:10px;display:flex;flex-direction:column;align-items:center}.feature-line{height:90px;width:100%;display:grid}.risk-empty{background-color:#f0f0f0}.risk-low{background-color:#c4e8c8}.risk-moderate{background-color:#fff4c8}.risk-high{background-color:#ffb0ae}\n"], dependencies: [{ kind: "directive", type: i1$1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1$1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i2$1.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "directive", type: i2$1.MatCardContent, selector: "mat-card-content" }, { kind: "component", type: i2$1.MatCardHeader, selector: "mat-card-header" }, { kind: "directive", type: i2$1.MatCardTitle, selector: "mat-card-title, [mat-card-title], [matCardTitle]" }, { kind: "component", type: RiskGaugeComponent, selector: "heart-risk-gauge", inputs: ["feature", "baseValue", "defaultValue", "defaultUnits", "defaultLabel", "defaultMin", "defaultMax", "maxDecimals", "useArrows", "hideTooltip", "color"] }, { kind: "pipe", type: RiskValuePipe, name: "riskPercent" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RiskFactorCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-risk-factor-card', template: "<mat-card class=\"example-card\">\n  <mat-card-header *ngIf=\"label\">\n    <mat-card-title>{{label}}</mat-card-title>\n  </mat-card-header>\n  <mat-card-content>\n    <div class=\"counterfactual-card\">\n      <div *ngIf=\"!riskPlaceholder && showRisk && card.risk\"\n        [ngClass]=\"{'risk-low': card.level  == 'low', 'risk-moderate': card.level  == 'moderate', 'risk-high': card.level  == 'high'}\"\n        class=\"feature-line\">\n        <heart-risk-gauge [defaultValue]=\"card.risk | riskPercent\" defaultLabel=\"Risk\"\n          defaultUnits=\"%\" [defaultMin]=\"0\" [defaultMax]=\"100\" [maxDecimals]=\"maxDecimals\"\n          [useArrows]=\"useArrows\"\n          [baseValue]=\"(base?.risk ? (base.risk | riskPercent) : undefined)\" [hideTooltip]=\"true\"></heart-risk-gauge>\n      </div>\n      <div *ngIf=\"riskPlaceholder\" class=\"feature-line risk-empty\">\n        <span></span>\n      </div>\n      <div *ngFor=\"let feat of card.features\" class=\"feature-line\">\n        <heart-risk-gauge [feature]=\"feat\" [baseValue]=\"baseValues.get(feat?.key?.uniqueLabelKey)\"\n          [maxDecimals]=\"maxDecimals\" [useArrows]=\"useArrows\"\n          [color]=\"colorMap.get(feat?.key?.uniqueLabelKey)\" [hideTooltip]=\"!showTooltip\"></heart-risk-gauge>\n      </div>\n    </div>\n  </mat-card-content>\n</mat-card>", styles: [".counterfactual-card{border:1px solid #e0e0e0;box-shadow:0 2px 5px #0000001a;margin:10px;display:flex;flex-direction:column;align-items:center}.feature-line{height:90px;width:100%;display:grid}.risk-empty{background-color:#f0f0f0}.risk-low{background-color:#c4e8c8}.risk-moderate{background-color:#fff4c8}.risk-high{background-color:#ffb0ae}\n"] }]
        }], ctorParameters: function () { return []; }, propDecorators: { base: [{
                type: Input
            }], card: [{
                type: Input
            }], label: [{
                type: Input
            }], showRisk: [{
                type: Input
            }], riskPlaceholder: [{
                type: Input
            }], colorMap: [{
                type: Input
            }], maxDecimals: [{
                type: Input
            }], useArrows: [{
                type: Input
            }], showTooltip: [{
                type: Input
            }] } });

// AoT requires an exported function for factories
function HttpLoaderFactoryRiskFactorCard(http) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class RiskFactorCardModule {
}
RiskFactorCardModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RiskFactorCardModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
RiskFactorCardModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: RiskFactorCardModule, declarations: [RiskGaugeComponent, RiskFactorCardComponent, RiskValuePipe], imports: [CommonModule,
        SubTranslateModule, i1.TranslateModule, MatIconModule,
        MatProgressSpinnerModule,
        MatProgressBarModule,
        MatButtonModule,
        MatDividerModule,
        MatBadgeModule,
        MatSliderModule,
        MatCardModule,
        MatTooltipModule,
        GaugeModule,
        NgxChartsModule], exports: [RiskFactorCardComponent] });
RiskFactorCardModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RiskFactorCardModule, imports: [CommonModule,
        SubTranslateModule,
        TranslateModule.forChild({
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactoryRiskFactorCard,
                deps: [HttpClient],
            },
            isolate: true,
        }),
        MatIconModule,
        MatProgressSpinnerModule,
        MatProgressBarModule,
        MatButtonModule,
        MatDividerModule,
        MatBadgeModule,
        MatSliderModule,
        MatCardModule,
        MatTooltipModule,
        GaugeModule,
        NgxChartsModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: RiskFactorCardModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [RiskGaugeComponent, RiskFactorCardComponent, RiskValuePipe],
                    imports: [
                        CommonModule,
                        SubTranslateModule,
                        TranslateModule.forChild({
                            loader: {
                                provide: TranslateLoader,
                                useFactory: HttpLoaderFactoryRiskFactorCard,
                                deps: [HttpClient],
                            },
                            isolate: true,
                        }),
                        MatIconModule,
                        MatProgressSpinnerModule,
                        MatProgressBarModule,
                        MatButtonModule,
                        MatDividerModule,
                        MatBadgeModule,
                        MatSliderModule,
                        MatCardModule,
                        MatTooltipModule,
                        GaugeModule,
                        NgxChartsModule,
                    ],
                    exports: [RiskFactorCardComponent],
                }]
        }] });

/*
 * Public API Surface of heart-ui-risk
 */

/**
 * Generated bundle index. Do not edit.
 */

export { HttpLoaderFactoryRiskFactorCard, HttpLoaderFactoryRiskLevelCard, RiskFactorCardComponent, RiskFactorCardModule, RiskLevelCardComponent, RiskLevelCardModule };
//# sourceMappingURL=eng-it4h-heart-ui-risk.mjs.map
