import * as i0 from "@angular/core";
export declare class TranslationService {
    allowed: string[];
    store: Map<string, any>;
    defaultLanguage: string;
    constructor();
    getTranslation(key: string, language: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslationService>;
}
