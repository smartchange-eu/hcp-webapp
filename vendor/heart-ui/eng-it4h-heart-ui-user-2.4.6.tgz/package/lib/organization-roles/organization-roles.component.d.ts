import { EventEmitter, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CodedValue, Organization, PersonRole } from '@eng-it4h/heart-ui-model';
import { TranslationService } from './translation.service';
import * as i0 from "@angular/core";
export declare class OrganizationRolesComponent implements OnInit {
    private _translationService;
    orgsValues: Organization[];
    toRemove: Organization[];
    rolesValues: CodedValue[];
    mandOrg: boolean;
    mandRole: boolean;
    lang: string;
    appearance: 'fill' | 'outline';
    onlyOneOrg: boolean;
    onlyOneRole: boolean;
    storeIt: EventEmitter<PersonRole[]>;
    form: FormGroup;
    constructor(_translationService: TranslationService);
    ngOnInit(): void;
    render(): void;
    onChange(arg: any): void;
    getErrorMessage(formControlName: string): string;
    private checkInputs;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrganizationRolesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrganizationRolesComponent, "heart-organization-roles", never, { "orgsValues": "orgsValues"; "toRemove": "toRemove"; "rolesValues": "rolesValues"; "mandOrg": "mandOrg"; "mandRole": "mandRole"; "lang": "lang"; "appearance": "appearance"; "onlyOneOrg": "onlyOneOrg"; "onlyOneRole": "onlyOneRole"; }, { "storeIt": "storeIt"; }, never, never, false, never>;
}
