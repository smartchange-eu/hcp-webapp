import { PipeTransform } from '@angular/core';
import { TranslationService } from './translation.service';
import * as i0 from "@angular/core";
export declare class TranslationPipe implements PipeTransform {
    private translationService;
    constructor(translationService: TranslationService);
    transform(value: string, lang?: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslationPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<TranslationPipe, "subtranslate", false>;
}
