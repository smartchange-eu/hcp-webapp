import * as i0 from "@angular/core";
import * as i1 from "./organization-roles.component";
import * as i2 from "./translation.pipe";
import * as i3 from "@angular/common";
import * as i4 from "@angular/forms";
import * as i5 from "@angular/material/input";
import * as i6 from "@angular/material/form-field";
import * as i7 from "@angular/material/select";
import * as i8 from "@angular/material/button";
import * as i9 from "@angular/material/icon";
import * as i10 from "@angular/material/expansion";
import * as i11 from "@angular/common/http";
import * as i12 from "@ngx-translate/core";
export declare class OrganizationRolesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrganizationRolesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrganizationRolesModule, [typeof i1.OrganizationRolesComponent, typeof i2.TranslationPipe], [typeof i3.CommonModule, typeof i4.FormsModule, typeof i4.ReactiveFormsModule, typeof i5.MatInputModule, typeof i6.MatFormFieldModule, typeof i7.MatSelectModule, typeof i8.MatButtonModule, typeof i9.MatIconModule, typeof i10.MatExpansionModule, typeof i11.HttpClientModule, typeof i12.TranslateModule], [typeof i1.OrganizationRolesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrganizationRolesModule>;
}
