export declare const en: {
    "user.new-hcp.org-roles.required.error": string;
    "user.new-hcp.org-roles.covered.label": string;
    "user.new-hcp.org-roles.organization.label": string;
    "user.new-hcp.org-roles.role.label": string;
    "user.new-hcp.org-roles.organization.deselect.label": string;
};
