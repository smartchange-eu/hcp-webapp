export declare const ro: {
    'user.list.filter.placeholder': string;
    'user.list.filter.label': string;
    'user.list.username.label': string;
    'user.list.name.label': string;
    'user.list.family.label': string;
    'user.list.roles.label': string;
    'user.list.enable.label': string;
    'user.list.delete.label': string;
    'user.list.table.no-data': string;
    'user.list.table.paginator.label': string;
};
