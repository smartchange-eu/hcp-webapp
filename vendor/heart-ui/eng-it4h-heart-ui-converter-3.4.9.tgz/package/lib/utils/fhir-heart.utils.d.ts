import { Extension } from '@eng-it4h/fhir-r5';
import { HeartExtension } from '../heart-extension';
export declare class FhirHeartUtils {
    /**
     * Find the extension declared by a HeartExtension object in a FHIR item
     * @param extensions - a FHIR Extension array
     * @param extension - the extension definition
     * @returns null if the extension is not found
     */
    static findExtension(extensions: Extension[], extension: HeartExtension): Extension;
}
