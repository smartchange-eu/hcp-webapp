import { Kinship, Patient } from "@eng-it4h/heart-ui-model";
import { RelatedPerson, Person as FhirPerson, Person } from '@eng-it4h/fhir-r5';
export declare class KinshipConverterUtils {
    static createFhirResourcesToPersist(enrichedPatient: Patient, subsetOfRelativeToCreate?: Kinship[], alreadyPersistedPerson?: Person): FhirKinship;
    static addRelatedPersonLink(fhirKinship: FhirKinship, frp: RelatedPerson): FhirKinship;
}
export declare class FhirKinship {
    relatedPersons: RelatedPerson[];
    person: FhirPerson;
    constructor(relatedPersons: RelatedPerson[], person: FhirPerson);
}
