import { CarePlan as FhirCarePlan, CodeableConcept as FhirCodeableConcept, Coding as FhirCoding, Goal as FhirGoal, PlanDefinition as FhirPlanDefinition } from '@eng-it4h/fhir-r5';
import { GoalTypeName, Goal as LocalGoal, Plan as LocalPlan, Measure, PlanDefinition, QuantitativeMeasureType, RiskLevel } from '@eng-it4h/heart-ui-model';
import { HeartValueSet } from '../heart-extension';
export declare class FhirCodesMapperUtils {
    static PlanStatusToFHIR(planStatus: LocalPlan.PlanStatus): FhirCarePlan.RequestStatus;
    static PlanStatusFromFHIR(fhirCarePlanStatus: FhirCarePlan.RequestStatus | string): LocalPlan.PlanStatus;
    static PlanDefinitionStatusFromFHIR(fhirPlanDefinitionStatus: FhirPlanDefinition.PublicationStatus | string): PlanDefinition.PlanStatus;
    static GoalStatusToFHIR(goalStatus: LocalGoal.GoalStatus): FhirGoal.GoalLifecycleStatus | string;
    static GoalStatusFromFHIR(fhirGoalLifecycleStatus: FhirGoal.GoalLifecycleStatus | string): LocalGoal.GoalStatus;
    static fromDataModelGoalType(goalType: GoalTypeName): FhirCodeableConcept;
    static toDataModelGoalType(fGoalCoding: FhirCoding, fGoalTargetMeasureCode?: HeartValueSet.Common.Measurement): GoalTypeName;
    static getTargetVariableClass(variableName: string): any;
    static getTargetVariableClassName(_class: any): string;
    static toDataModelTargetVariable(fhirCc: FhirCodeableConcept): any;
    /**
     * Questo metodo: risolve il mapping verso FHIR dei vari tipo di misurazioni usabile come goal target
     */
    static fromDataModelTargetVariable(type: QuantitativeMeasureType): FhirCodeableConcept;
    /**
     * Questo metodo: risolve il mapping verso FHIR dei vari tipo di misurazioni usabile come goal target
     */
    static fromDataModelMeasureToValueset(measure: Measure): HeartValueSet.Common.Measurement;
    static getMeasureClassName(measure: Measure): string;
    static RiskProbabilityToFHIR(level: RiskLevel): FhirCodeableConcept;
    static RiskProbabilityFromFHIR(fLevel: FhirCodeableConcept): RiskLevel;
}
