import { CodeableConcept, Identifier as FhirIdentifier, Reference as FhirReference, CodeableReference } from '@eng-it4h/fhir-r5';
import { CodedValue, Identifier, Shareable } from '@eng-it4h/heart-ui-model';
export declare class ModelToFHIRUtils {
    static getReference(e: Shareable): FhirReference;
    static stubFromRef(ref: FhirReference, forceResourceType?: string): Shareable;
    static getFhirResourceType(model: Shareable): string;
    static toCodedValueModel(c: CodeableConcept): CodedValue;
    static fromCodedValueModel(c: CodedValue, text?: string): CodeableConcept;
    static fromTextModel(text: string): CodeableConcept;
    static toIdentifierModel(i: FhirIdentifier): Identifier;
    static fromIdentifierModel(i: Identifier): FhirIdentifier;
    static fromPseudonymIdentifierModel(pseudonym: string): FhirIdentifier;
    static getCodeableReference(cv?: CodedValue, sharable?: Shareable): CodeableReference;
    static encodeToBase64(inputText: string): string;
    static decodeFromBase64(base64: string): string;
}
