import { Address, Annotation, Bundle, CodeableConcept, DataType, DomainResource, Extension, HumanName, Identifier, Period, Quantity, Reference, Timing } from '@eng-it4h/fhir-r5';
import { EncounterQuestionnaire, EncounterType } from '@eng-it4h/heart-ui-model';
export declare class FhirUtils {
    static createCodeableConcept(system: string, code: string, display: string, text?: string): CodeableConcept;
    static createCodeableConceptWithOnlyText(text: string): CodeableConcept;
    static createExtension(url: string, value: DataType): Extension;
    static createExtensionCodeableConcept(url: string, value: CodeableConcept): Extension;
    static createExtensionResource(url: string, value: DomainResource): Extension;
    static createExtensionString(url: string, value: string): Extension;
    static createExtensionBoolean(url: string, value: boolean): Extension;
    static createExtensionNumber(url: string, value: number): Extension;
    static createExtensionDate(url: string, value: Date): Extension;
    static createExtensionQuantity(url: string, value: Quantity): Extension;
    static createExtensionAddress(url: string, value: Address): Extension;
    static createExtensionReference(url: string, value: Reference): Extension;
    static createAnnotation(note: string, hcp?: Reference): Annotation;
    static createTimingMax(duration: number, unit: string): Timing;
    static createPeriodStartEnd(start: Date, end?: Date): Period;
    static createIdentifier(system: string, value: string): Identifier;
    static filterIdentifierBySystem(identifiers: Identifier[], system: string): Identifier;
    static filterIdentifierByTypeSystem(identifiers: Identifier[], typeSystem: string): Identifier;
    static createQuantity(value?: number, system?: string, code?: string, unit?: string): Quantity;
    /**
     * Use in this way:
     * <code> DemoData.createRandomSeries(0, 70, 30).join(' ');</code>
     *
     * @param min - included
     * @param max - included
     * @param samples - amount of samples in the series
     */
    static createRandomSeries(min?: number, max?: number, samples?: number): string[];
    /**
     * Create RelatedPerson
     *
     * @param patient - Patient who the RelatedPerson is related to
     * @param relationship - The type of the relationShip
     * @param name - Name of the related person
     *
     */
    static createRelationshipCode(relationship: {
        display: string;
        code: string;
    }): CodeableConcept;
    static createCommunicationLocale(locale: Locale): CodeableConcept;
    static createHumanName(firstName?: string, lastName?: string): HumanName[];
    /**
     * Create a bundle of type collection for all the specified FHIR resources
     * @param fhirResources
     * @returns
     */
    static createBundleCollection(fhirResources: (DomainResource | Reference)[]): Bundle;
    static fromDataModelEncounterType(type: EncounterType): CodeableConcept;
    static toDataModelEncounterType(type: CodeableConcept): EncounterType;
    static fromDataModelEncounterQuestionnaire(type: EncounterQuestionnaire): string;
    static toDataModelEncounterQuestionnaire(type: string): EncounterQuestionnaire;
}
