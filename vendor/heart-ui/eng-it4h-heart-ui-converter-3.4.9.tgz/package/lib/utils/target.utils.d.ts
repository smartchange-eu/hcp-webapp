import { Bundle, Goal, PlanDefinition } from '@eng-it4h/fhir-r5';
import { Target } from '@eng-it4h/heart-ui-model';
export declare class TargetUtils {
    static fromDataModelTarget(target: Target): Goal.GoalTargetComponent;
    static fromDataModelTargetDefinition(target: Target): PlanDefinition.PlanDefinitionGoalTargetComponent;
    private static fromDataModelQuantitativeTarget;
    private static fromDataModelCategoryTarget;
    private static fromDataModelRangeTarget;
    private static fromDataModelQuantitativeTargetDef;
    private static fromDataModelRangeTargetDef;
    private static fromDataModelCategoryTargetDef;
    private static fromDataModelRange;
    private static fromDataModelQuantity;
    private static fromDataModelCategory;
    static toDataModelTarget(fTarget: Goal.GoalTargetComponent | PlanDefinition.PlanDefinitionGoalTargetComponent, context?: Bundle): Target;
    private static toDataModelQuantitativeTarget;
    private static toDataModelRangeTarget;
    private static toDataModelCategoryTarget;
}
