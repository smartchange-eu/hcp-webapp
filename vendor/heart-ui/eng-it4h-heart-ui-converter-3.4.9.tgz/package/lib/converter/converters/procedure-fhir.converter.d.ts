import { Bundle as FhirBundle, Procedure as FhirProcedure } from '@eng-it4h/fhir-r5';
import { Procedure } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class ProcedureFhirConverter extends AbstractFhirConverter<Procedure, FhirProcedure> {
    fromDataModel(model: Procedure): FhirProcedure;
    toDataModel(resource: FhirProcedure, context: FhirBundle): Procedure;
    private toDataModelWorkout;
    private fromDataModelWorkout;
}
