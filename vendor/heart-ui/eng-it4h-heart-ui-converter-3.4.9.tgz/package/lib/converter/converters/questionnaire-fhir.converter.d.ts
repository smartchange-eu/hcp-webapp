import { Bundle as FhirBundle, Questionnaire as FHIRQuestionnaire } from '@eng-it4h/fhir-r5';
import { Questionnaire } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class QuestionnaireFhirConverter extends AbstractFhirConverter<Questionnaire, FHIRQuestionnaire> {
    private static readonly PREFIX;
    private static readonly SEPARATOR;
    private static readonly SUFFIX;
    private valueSetResolver?;
    toDataModel(resource: FHIRQuestionnaire, context?: FhirBundle): Questionnaire;
    fromDataModel(model: Questionnaire): FHIRQuestionnaire;
    private toDataModelQuestionnaire;
    private toDataModelQuestion;
    private toDataModelQuestionOrGroup;
    private toDataModelGroup;
    /**
     * Convert the well known ValueSet option in a Choice array
     * @param answerValueSet
     */
    private toDataModelQuestionChoiceValueSet;
    private toDataModelQuestionChoice;
    private toDataModelQuestionEnableWhen;
    private fromDataModelQuestionnaire;
}
