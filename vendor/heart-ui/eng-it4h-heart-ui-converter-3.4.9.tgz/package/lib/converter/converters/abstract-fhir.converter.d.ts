import { Bundle as FhirBundle, DomainResource as FhirDomainResource, Duration as FhirDuration, Patient as FhirPatient, Quantity as FhirQuantity, Reference as FhirReference } from '@eng-it4h/fhir-r5';
import { Patient, Shareable } from '@eng-it4h/heart-ui-model';
import { FhirConverterService } from './fhir-converter.service';
export declare abstract class AbstractFhirConverter<Y extends Shareable, Z extends FhirDomainResource> {
    protected service: FhirConverterService;
    constructor(c: FhirConverterService);
    abstract toDataModel(resource: Z | FhirReference, context?: FhirBundle): Y;
    abstract fromDataModel(model: Y): Z;
    /**
     * Prova a risolvere il riferimento sia nella risorsa container che nel bundle, se presente, MA non prova a risolvere in remoto.
     *
     */
    protected resolveReference(reference: FhirReference, parentResource: FhirDomainResource, bundle?: FhirBundle): FhirDomainResource;
    protected resolveSubject(ref: FhirPatient | FhirReference, parent: FhirDomainResource, context: FhirBundle): Patient;
    protected getDuration(duration: FhirDuration): number;
    /**
     * Given a FHIR resource retrieves the ID with its 'resource type' (if available)
     */
    protected toFhirID(resource: FhirDomainResource): string;
    protected toFhirIDPart(resource: FhirDomainResource): number;
    protected toFhirVersion(resource: FhirDomainResource): string;
    protected createQuantity(v: number, unit: string): FhirQuantity;
}
