import { Bundle as FhirBundle, ServiceRequest } from '@eng-it4h/fhir-r5';
import { Prescription } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class PrescriptionFhirConverter extends AbstractFhirConverter<Prescription, ServiceRequest> {
    private priorityList;
    /**
     * fromDataModel check if Prescription is instanceof CounsellingPrescription or ExamPrescription
     * and adapt conversion to ServiceRequest
     */
    fromDataModel(model: Prescription): ServiceRequest;
    private participantFromDataModel;
    toDataModel(fhir: ServiceRequest, context: FhirBundle): Prescription;
    private participantToDataModel;
}
