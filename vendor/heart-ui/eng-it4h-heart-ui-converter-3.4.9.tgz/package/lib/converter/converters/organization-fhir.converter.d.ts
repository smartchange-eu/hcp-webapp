import { Bundle as FhirBundle, Organization as FHIROrganization } from '@eng-it4h/fhir-r5';
import { Organization } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class OrganizationFhirConverter extends AbstractFhirConverter<Organization, FHIROrganization> {
    toDataModel(resource: FHIROrganization, context?: FhirBundle): Organization;
    fromDataModel(model: Organization): FHIROrganization;
    private toDataModelQuestionnaire;
    private fromDataModelQuestionnaire;
}
