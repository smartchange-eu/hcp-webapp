import { Bundle as FhirBundle, ResearchSubject as FhirResearchSubject } from '@eng-it4h/fhir-r5';
import { TrialSubject } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class TrialSubjectFhirConverter extends AbstractFhirConverter<TrialSubject, FhirResearchSubject> {
    toDataModel(resource: FhirResearchSubject, context?: FhirBundle): TrialSubject;
    fromDataModel(model: TrialSubject): FhirResearchSubject;
    private static fromFHIR;
    static toFHIR(model: TrialSubject): FhirResearchSubject;
}
