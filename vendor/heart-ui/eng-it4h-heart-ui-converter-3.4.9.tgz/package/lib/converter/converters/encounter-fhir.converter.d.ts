import { Bundle as FhirBundle, Encounter as FhirEncounter, EpisodeOfCare as FhirEpisodeOfCare } from '@eng-it4h/fhir-r5';
import { ClinicalNote, Encounter, ExamPrescription, GenericQuantitativeMeasure, Patient } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class EncounterFhirConverter extends AbstractFhirConverter<Encounter, FhirEncounter> {
    toDataModel(resource: FhirEncounter, context?: FhirBundle): Encounter;
    fromDataModel(model: Encounter): FhirEncounter;
    fromDataModelEncounter(model: Encounter, episodeOfCare?: FhirEpisodeOfCare, patient?: Patient): FhirEncounter;
    private toDataModelEncounter;
    private setAnamnesisAttribute;
    private setDiagnosisAttribute;
    setMeasuresToEncounter(enc: Encounter, phyExams: GenericQuantitativeMeasure[]): Encounter;
    setExamPrescr(enc: Encounter, examPrescrs: ExamPrescription[]): Encounter;
    setNotes(enc: Encounter, notes: ClinicalNote[]): Encounter;
}
