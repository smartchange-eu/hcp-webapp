import { Appointment as FhirAppointment, Bundle as FhirBundle } from '@eng-it4h/fhir-r5';
import { Appointment } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class AppointmentFhirConverter extends AbstractFhirConverter<Appointment, FhirAppointment> {
    toDataModel(resource: FhirAppointment, context?: FhirBundle): Appointment;
    fromDataModel(model: Appointment): FhirAppointment;
    fromDataModelAppointment(model: Appointment): FhirAppointment;
    private toDataModelAppointment;
}
