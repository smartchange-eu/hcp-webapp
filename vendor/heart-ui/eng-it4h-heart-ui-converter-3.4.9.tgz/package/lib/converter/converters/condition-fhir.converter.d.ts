import { Bundle as FhirBundle, Condition as FhirCondition } from '@eng-it4h/fhir-r5';
import { Condition } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class ConditionFhirConverter extends AbstractFhirConverter<Condition, FhirCondition> {
    fromDataModel(model: Condition): FhirCondition;
    private participantFromDataModel;
    toDataModel(fhir: FhirCondition, context: FhirBundle): Condition;
    private participantToDataModel;
}
