import { Bundle as FhirBundle, RelatedPerson } from '@eng-it4h/fhir-r5';
import { CareGiver } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class CareGiverFhirConverter extends AbstractFhirConverter<CareGiver, RelatedPerson> {
    toDataModel(resource: RelatedPerson, context?: FhirBundle): CareGiver;
    fromDataModel(model: CareGiver): RelatedPerson;
    private fromDataModelGender;
    private toDataModelGender;
}
