import { Bundle as FhirBundle, NutritionIntake } from '@eng-it4h/fhir-r5';
import { Nutrition } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class NutritionFhirConverter extends AbstractFhirConverter<Nutrition, NutritionIntake> {
    toDataModel(fhir: NutritionIntake, context: FhirBundle): Nutrition;
    fromDataModel(model: Nutrition): NutritionIntake;
}
