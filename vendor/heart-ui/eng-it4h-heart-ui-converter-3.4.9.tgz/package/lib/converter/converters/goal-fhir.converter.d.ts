import { Bundle as FhirBundle, Goal as FhirGoal } from '@eng-it4h/fhir-r5';
import { Goal } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class GoalFhirConverter extends AbstractFhirConverter<Goal, FhirGoal> {
    toDataModel(fGoal: FhirGoal, context: FhirBundle): Goal;
    private toDataModelGoalExtractMilestones;
    private toDataModelGoalExtractReplacement;
    private toDataModelGoalExtractActuator;
    fromDataModel(goal: Goal): FhirGoal;
    private _fromDataModelDuration;
    private _fromDataModelDate;
    private _createMilestoneRelationshipExtension;
    private _createReplacementRelationshipExtension;
}
