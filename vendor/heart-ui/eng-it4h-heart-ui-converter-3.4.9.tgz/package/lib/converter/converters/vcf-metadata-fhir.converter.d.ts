import { Bundle as FhirBundle, GenomicStudy } from '@eng-it4h/fhir-r5';
import { Study } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class VcfMetadataFhirConverter extends AbstractFhirConverter<Study, GenomicStudy> {
    private SUPPORTED_VCF;
    private SUPPORTED_CRAM;
    fromDataModel(model: Study): GenomicStudy;
    toDataModel(resource: GenomicStudy, context: FhirBundle): Study;
    private getSpecimenCV;
}
