import { Bundle as FhirBundle, CarePlan as FhirCarePlan } from '@eng-it4h/fhir-r5';
import { Plan } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class PlanFhirConverter extends AbstractFhirConverter<Plan, FhirCarePlan> {
    fromDataModel(plan: Plan): FhirCarePlan;
    private fromDataModelActivity;
    private toDataModelSMBGActivity;
    private toDataModelActivity;
    toDataModel(fhir: FhirCarePlan, context: FhirBundle): Plan;
}
