import { Bundle as FhirBundle, CareTeam as FhirCareTeam } from '@eng-it4h/fhir-r5';
import { CareTeam } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class CareTeamFhirConverter extends AbstractFhirConverter<CareTeam, FhirCareTeam> {
    toDataModel(resource: FhirCareTeam, context?: FhirBundle): CareTeam;
    fromDataModel(model: CareTeam): FhirCareTeam;
    private static fromFHIR;
    static toFHIR(ct: CareTeam): FhirCareTeam;
}
