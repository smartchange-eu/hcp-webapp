import { Bundle as FhirBundle, PlanDefinition as FhirPlanDefinition } from '@eng-it4h/fhir-r5';
import { PlanDefinition } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class PlanDefinitionFhirConverter extends AbstractFhirConverter<PlanDefinition, FhirPlanDefinition> {
    fromDataModel(model: PlanDefinition): FhirPlanDefinition;
    private fromDataModelTopic;
    private fromDataModelGoalDef;
    toDataModel(fhirRes: FhirPlanDefinition, context: FhirBundle): PlanDefinition;
    private toDataModelGoalDef;
    private toDataModelTopic;
    private fromDataModelActivityDef;
    toDataModelActivityDef(fhirActivity: FhirPlanDefinition.PlanDefinitionActionComponent, context: FhirBundle): any;
}
