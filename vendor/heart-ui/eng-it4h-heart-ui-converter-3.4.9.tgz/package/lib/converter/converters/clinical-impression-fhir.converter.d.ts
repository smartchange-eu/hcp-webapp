import { Bundle as FhirBundle, ClinicalImpression as FhirClinicalImpression } from '@eng-it4h/fhir-r5';
import { ObservePatient } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class ClinicalImpressionFhirConverter extends AbstractFhirConverter<ObservePatient, FhirClinicalImpression> {
    fromDataModel(model: ObservePatient): FhirClinicalImpression;
    toDataModel(resource: FhirClinicalImpression, context: FhirBundle): ObservePatient;
    private toDataModelObservePatient;
    private fromDataModelObservePatient;
}
