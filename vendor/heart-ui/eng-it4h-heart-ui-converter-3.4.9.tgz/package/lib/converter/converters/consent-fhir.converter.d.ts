import { Bundle as FhirBundle, Consent as FHIRConsent } from '@eng-it4h/fhir-r5';
import { PatientConsent } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class PatientConsentFhirConverter extends AbstractFhirConverter<PatientConsent, FHIRConsent> {
    toDataModel(resource: FHIRConsent, context?: FhirBundle): PatientConsent;
    fromDataModel(model: PatientConsent): FHIRConsent;
    static fromFHIR(fhir: FHIRConsent): PatientConsent;
    static toFHIR(model: PatientConsent): FHIRConsent;
    private static convertFromFhirConsentPermission;
    private static convertToValueSet;
}
