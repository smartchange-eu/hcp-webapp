import { Bundle as FhirBundle, RiskAssessment } from '@eng-it4h/fhir-r5';
import { Risk } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class RiskFhirConverter extends AbstractFhirConverter<Risk, RiskAssessment> {
    toDataModel(fhir: RiskAssessment, context: FhirBundle): Risk;
    fromDataModel(model: Risk): RiskAssessment;
    private createAgeQuantity;
    private createProbQuantity;
}
