import { Bundle as FhirBundle, EpisodeOfCare as FhirEpisodeOfCare } from '@eng-it4h/fhir-r5';
import { AbstractFhirConverter } from './abstract-fhir.converter';
import { Episode } from '@eng-it4h/heart-ui-model';
export declare class EpisodeFhirConverter extends AbstractFhirConverter<Episode, FhirEpisodeOfCare> {
    toDataModel(resource: FhirEpisodeOfCare, context?: FhirBundle): Episode;
    fromDataModel(model: Episode): FhirEpisodeOfCare;
    private toDataModelEpisode;
    private fromDataModelEpisode;
    private fromDataModelHealthService;
    private toDataModelHealthService;
}
