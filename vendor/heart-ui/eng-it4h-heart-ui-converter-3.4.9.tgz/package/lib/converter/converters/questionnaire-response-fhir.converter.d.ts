import { Bundle as FHIRBundle, QuestionnaireResponse as FHIRQuestionnaireResponse } from '@eng-it4h/fhir-r5';
import { QuestionnaireResponse } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class QuestionnaireResponseFhirConverter extends AbstractFhirConverter<QuestionnaireResponse, FHIRQuestionnaireResponse> {
    toDataModel(resource: FHIRQuestionnaireResponse, context?: FHIRBundle): QuestionnaireResponse;
    fromDataModel(model: QuestionnaireResponse): FHIRQuestionnaireResponse;
    private toDataModelQuestionnaireResponse;
    private toDataModelAnswers;
    private toDataModelAnswers2;
    private extractFHIRQuestionAnswer;
    private fromDataModelQuestionnaireResponse;
    private manageFromDataModelAnswers;
    private toAnswer;
    private toAnswerGroup;
    private convertIntoCoding;
    private fromDataModelToAnswerValue;
}
