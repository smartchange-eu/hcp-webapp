import { Bundle as FhirBundle, Patient as FhirPatient, Practitioner as FhirPractitioner, PractitionerRole as FhirPractitionerRole, Organization as FhirOrganization } from '@eng-it4h/fhir-r5';
import { HealthCareProfessional, Patient, Person } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class PersonFhirConverter extends AbstractFhirConverter<Person, FhirPatient | FhirPractitioner> {
    toDataModel(resource: FhirPatient | FhirPractitioner, context?: FhirBundle): Person;
    fromDataModel(model: Person): FhirPatient | FhirPractitioner;
    /**
     * Convert a FHIR Practitioner resource in the 'easy' HealthcareProfessional
     *
     * As FHIR has some information in the PractitionerRole and Organization resources the converter needs those too
     * @param fhir
     * @param fhirPractitionerRole
     * @param fhirOrganizations
     * @returns
     */
    toDataModelHealthCareProfessional(fhir: FhirPractitioner, fhirPractitionerRole?: FhirPractitionerRole[], fhirOrganizations?: FhirOrganization[]): HealthCareProfessional;
    /**
     * Convert a FHIR Patient resource in the 'easy' Patient
     *
     * @param fhir
     * @returns
     */
    toDataModelPatient(fhir: FhirPatient): Patient;
    /**
     * Convert the 'easy' Patient in the FHIR Patient resource
     *
     * @param patient
     * @returns
     */
    private fromDataModelPatient;
    /**
     * Convert the 'easy' HealthcareProfessional in the FHIR Practitioner resource
     *
     * @param hcp
     * @returns
     */
    private fromDataModelHealthCareProfessional;
    private toDataModelGender;
    /**
     * A previous version of this converter only converted the Gender into a string under the assumption that the enum values are the same.
     *
     * The current method, while more complex, is more flexibile.
     *
     * @param gender
     * @returns
     */
    private fromDataModelGender;
    private fromDataModelPatientAddress;
}
