import { Bundle as FhirBundle, DocumentReference as FhirDocumentReference } from '@eng-it4h/fhir-r5';
import { AbstractFhirConverter } from './abstract-fhir.converter';
import { ClinicalNote } from '@eng-it4h/heart-ui-model';
export declare class ClinicalNoteFhirConverter extends AbstractFhirConverter<ClinicalNote, FhirDocumentReference> {
    toDataModel(fDocument: FhirDocumentReference, context: FhirBundle): ClinicalNote;
    fromDataModel(cn: ClinicalNote): FhirDocumentReference;
}
