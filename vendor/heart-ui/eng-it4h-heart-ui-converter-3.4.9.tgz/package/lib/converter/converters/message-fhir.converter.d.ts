import { Bundle as FhirBundle, Communication as FhirCommunication } from '@eng-it4h/fhir-r5';
import { Message } from '@eng-it4h/heart-ui-model';
import { AbstractFhirConverter } from './abstract-fhir.converter';
export declare class MessageFhirConverter extends AbstractFhirConverter<Message, FhirCommunication> {
    toDataModel(resource: FhirCommunication, context: FhirBundle): Message;
    fromDataModel(message: Message): FhirCommunication;
}
