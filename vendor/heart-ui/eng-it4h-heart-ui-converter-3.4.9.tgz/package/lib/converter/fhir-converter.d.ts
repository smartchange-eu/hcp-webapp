import { Bundle as FhirBundle, DomainResource as FhirDomainResource, Reference as FhirReference } from '@eng-it4h/fhir-r5';
import { Shareable } from '@eng-it4h/heart-ui-model';
import { FhirConverterService } from './converters';
import { DataConverter } from './data-converter';
export declare class FhirConverter implements DataConverter {
    private service;
    constructor();
    toDataModel(resource: FhirDomainResource | FhirReference, context?: FhirBundle): Shareable;
    fromDataModel(model: Shareable): FhirDomainResource;
    get converterService(): FhirConverterService;
    getFHIRReference(model: Shareable): FhirReference;
}
