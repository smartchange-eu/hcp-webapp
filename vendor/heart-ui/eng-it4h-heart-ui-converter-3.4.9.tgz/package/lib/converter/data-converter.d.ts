export interface DataConverter {
    toDataModel(otherModel: any): any;
    fromDataModel(model: any): any;
}
