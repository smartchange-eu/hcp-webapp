export declare class Dictionary {
    /****************************
     * STANDARD SYSTEMS
     ****************************/
    static readonly SNOMED: string;
    static readonly LOINC: string;
    static readonly ACME: string;
    static readonly UNIT_OF_MEASURE: string;
    static readonly ICD10: string;
    static readonly ICD9Proc: string;
    private static readonly FHIR_NAMESPACE;
    static readonly HL7_TERMINLOGY_NAMESPACE = "http://terminology.hl7.org/CodeSystem/";
    /****************************
     * FHIR Officials
     ****************************/
    static readonly FHIR_VALUE_SET_URI: string;
    static readonly FHIR_EXTENSION_NAMESPACE: string;
    static readonly FHIR_OBSERVATION_CATEGORY: string;
    static readonly GOAL_RELATIONSHIP_TYPE_URL: string;
    /****************************
     * HL7 Code systems
    ****************************/
    static readonly HL7_RISK_PROBABILITY: string;
    static readonly HL7_V3_ACT_CODE: string;
    static readonly HL7_CONSENT_SCOPE: string;
    static readonly FHIR_CONDITION_CATEGORY: string;
    static readonly USAGE_CONTEXT_TYPE: string;
    /****************************
     * UHM
     ****************************/
    private static readonly UHM_BASE_DOMAIN;
    static readonly BASE_NAMESPACE: string;
    static readonly UHM_VALUE_SET_URI: string;
    static readonly UHM_IDENTIFIER_URI: string;
    static readonly UHM_STRUCTURE_DEFINITION_URI: string;
    static readonly UHM_CODE_SYSTEM_URI: string;
    static readonly UHM_TRIAL_GROUP_SYSTEM: string;
    static readonly UHM_SECURITY_SYSTEM: string;
    static UHM_PSEUDONYM_SYSTEM: string;
    static readonly PATIENT_TAX_CODE_SYSTEM = "http://hl7.it/sid/codiceFiscale";
}
