import { HeartValueSet } from './heart-valueset';
import { Duration } from 'date-fns';
import { Quantity, CodeableConcept, Reference, Extension, DataType, DomainResource, Coding } from '@eng-it4h/fhir-r5';
declare type ExtensionType = number | Date | string | boolean | Reference | Quantity | Duration;
export declare class HeartExtension {
    protected readonly entity: string;
    protected readonly attributeName: string;
    protected readonly resource: string;
    readonly url: string;
    protected readonly dataType: string;
    constructor(entity: string, attributeName: string, resource: string, url: string, dataType: string);
    /**
     * Find the extension declared by a HeartExtension object in a FHIR item
     * @param extensions - a FHIR Extension array
     * @returns null if the extension is not found
     */
    findAmongExtensions(extensions: Extension[]): Extension;
    extractValueSetFromExtensions(extensions: Extension[]): HeartValueSet;
    extractValueSetsFromExtensions(extensions: Extension[]): HeartValueSet[];
    extractCodingFromExtensions(extensions: Extension[]): Coding[];
    extractReferencesFromExtensions(extensions: Extension[]): Reference[];
    extractValueFromExtensions(extensions: Extension[]): ExtensionType;
    toExtension(value: DataType): Extension;
    toStructuredExtension(innerExtensions: Extension[]): Extension;
    toExtensionCodeableConcept(value: CodeableConcept | HeartValueSet): Extension;
    toExtensionCoding(value: Coding): Extension;
    toExtensionResource(value: DomainResource): Extension;
    toExtensionString(value: string): Extension;
    toExtensionBoolean(value: boolean): Extension;
    toExtensionNumber(value: number): Extension;
    toExtensionDate(value: Date): Extension;
    toExtensionQuantity(value: Quantity): Extension;
    toExtensionReference(value: Reference | DomainResource): Extension;
}
export declare namespace HeartExtension {
    abstract class Common {
        static readonly AttachmentExternalizedBinaryId: HeartExtension;
    }
    abstract class CMP3VDA {
        static readonly CMP3VDA_EXTENSION_NAMESPACE = "https://www.cmp3vda-project.it/fhir/StructureDefinition/";
        static readonly Condition_assertedDate: HeartExtension;
        static readonly Condition_followupDate: HeartExtension;
        static readonly Condition_isPrimary: HeartExtension;
        static readonly Condition_isSyndromic: HeartExtension;
        static readonly Condition_isCatatonic: HeartExtension;
    }
    abstract class Patient {
        static readonly homeType: HeartExtension;
        static readonly birthPlace: HeartExtension;
    }
    abstract class Condition {
        static readonly diagnosisType: HeartExtension;
        static readonly remissionType: HeartExtension;
    }
    abstract class Questionnaire {
        static readonly minValue: HeartExtension;
        static readonly maxValue: HeartExtension;
    }
    abstract class Goal {
        private static readonly ExtensionGoalUri;
        static relationshipType: HeartExtension;
        static relationship: HeartExtension;
        static actuator: HeartExtension;
        static proposedReplaced: HeartExtension;
        static createdOn: HeartExtension;
        static cancelledBy: HeartExtension;
        static validatedOn: HeartExtension;
        static proposedOn: HeartExtension;
        static acceptanceDuration: HeartExtension;
        static acceptedOn: HeartExtension;
        static endedOn: HeartExtension;
        static cancelledOn: HeartExtension;
        static startedOn: HeartExtension;
    }
    abstract class Workout {
        private static readonly ExtensionProcedureUri;
        static healthSource: HeartExtension;
        static healthId: HeartExtension;
        static isAutomatic: HeartExtension;
        static Workoput_type: HeartExtension;
        static intensity: HeartExtension;
        static energyExpenditure: HeartExtension;
        static stepCounter: HeartExtension;
        static distance: HeartExtension;
    }
    abstract class Meal {
        private static readonly ExtensionObservationUri;
        static type: HeartExtension;
        static portionSize: HeartExtension;
        static carbohydrates: HeartExtension;
        static fibers: HeartExtension;
        static sodium: HeartExtension;
        static fats: HeartExtension;
        static proteins: HeartExtension;
        static foodWeight: HeartExtension;
    }
    abstract class BloodGlucose {
        private static readonly ExtensionObservationUri;
        static measurePoint: HeartExtension;
        static drugStatement: HeartExtension;
        static fastingOrAfterMealBloodSugar: HeartExtension;
    }
    abstract class Message {
        private static readonly ExtensionCommunicationUri;
        static read: HeartExtension;
    }
}
export {};
