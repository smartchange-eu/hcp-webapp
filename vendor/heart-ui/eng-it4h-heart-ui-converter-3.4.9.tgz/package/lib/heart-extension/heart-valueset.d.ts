import { CodeableConcept } from '@eng-it4h/fhir-r5';
export declare class HeartValueSet {
    readonly system: string;
    readonly code: string;
    readonly display: string;
    constructor(system: string, code: string, display: string);
    /**
     * ATTENZIONE: usare con cura questo metodo.
     * Considera soprattutto che non si può invocare '==' su due istanze di ValueSet perchè NON sono ENUM
     */
    static fromCodeableConcept(cc: CodeableConcept): HeartValueSet;
    toCodeableConcept(): CodeableConcept;
    equals(code: CodeableConcept | CodeableConcept[] | HeartValueSet | string): boolean;
}
export declare namespace HeartValueSet {
    namespace Common {
        class MeasurementCategory extends HeartValueSet {
            static readonly VITAL_SIGNS: MeasurementCategory;
            static readonly SURVEY: MeasurementCategory;
            static readonly NUTRITION_CATEGORY: MeasurementCategory;
            private constructor();
            static byCode(code: string): MeasurementCategory;
        }
        class ClinicalImpression extends HeartValueSet {
            static readonly OBSERVE_PATIENT: ClinicalImpression;
            private constructor();
            static byCode(code: string): ClinicalImpression;
        }
        class Measurement extends HeartValueSet {
            static readonly MEAL_CODINGS: Measurement;
            static readonly PHYSICAL_ACTIVITY_CODINGS: Measurement;
            static readonly BMI_CODINGS: Measurement;
            static readonly WEIGHT_CODINGS: Measurement;
            static readonly HEIGHT_CODINGS: Measurement;
            static readonly HEART_RATE_RESTING_CODING: Measurement;
            static readonly WAIST_CODINGS: Measurement;
            static readonly MODERATE_PHYSICAL_ACTIVITY_DURATION_WEEKLY_CODINGS: Measurement;
            static readonly VIGOROUS_PHYSICAL_ACTIVITY_DURATION_WEEKLY_CODINGS: Measurement;
            static readonly STRENGTH_PHYSICAL_ACTIVITY_SESSION_WEEKLY_CODINGS: Measurement;
            static readonly CALORIC_DAILY_INTAKE_CODINGS: Measurement;
            static readonly CARBOHYDRATES_DAILY_INTAKE_CODINGS: Measurement;
            static readonly PROTEINS_DAILY_INTAKE_CODINGS: Measurement;
            static readonly FATS_DAILY_INTAKE_CODINGS: Measurement;
            static readonly FIBERS_DAILY_INTAKE_CODINGS: Measurement;
            static readonly SODIUM_DAILY_INTAKE_CODINGS: Measurement;
            static readonly SUGARY_BEVERAGE_DAILY_INTAKE_CODINGS: Measurement;
            static readonly ALCOHOL_DAILY_INTAKE_CODINGS: Measurement;
            static readonly FRUIT_PORTIONS_DAILY_INTAKE_CODINGS: Measurement;
            static readonly VEGETABLES_PORTIONS_DAILY_INTAKE_CODINGS: Measurement;
            static readonly CIGARETTES_DAILY_AMOUNT_CODINGS: Measurement;
            static readonly BLOOD_PRESSURE_CODINGS: Measurement;
            static readonly SYSTOLIC_BLOOD_PRESSURE_CODINGS: Measurement;
            static readonly DIASTOLIC_BLOOD_PRESSURE_CODINGS: Measurement;
            static readonly BLOOD_GLUCOSE_MOLES_CODINGS: Measurement;
            static readonly BLOOD_GLUCOSE_MASS_CODINGS: Measurement;
            static readonly BLOOD_GLUCOSE_MASS_INSULIN_CODINGS: Measurement;
            static readonly HBA1C_CODINGS: Measurement;
            static readonly SPO2_CODINGS: Measurement;
            static readonly CHOLESTEROL_CODINGS: Measurement;
            static readonly CHOLESTEROL_HDL_CODINGS: Measurement;
            static readonly CHOLESTEROL_LDL_CODINGS: Measurement;
            static readonly TRIGLYCERIDE_CODINGS: Measurement;
            static readonly PHYSICAL_INABILITY_CODINGS: Measurement;
            static readonly SMOKER_CODINGS: Measurement;
            static readonly SUPERVISOR_REQUIRED_CODINGS: Measurement;
            static readonly TTM_CODINGS: Measurement;
            static readonly PATIENT_HEALTH_STATUS_CODING: Measurement;
            static readonly LIFESTYLE_CODING: Measurement;
            static readonly GENERAL_HEALTH_POOR_CODING: Measurement;
            static readonly GENERAL_HEALTH_GOOD_CODING: Measurement;
            static readonly GENERAL_HEALTH_FAIR_CODING: Measurement;
            static readonly BODY_TEMPERATURE_CODINGS: Measurement;
            static readonly CHEST_PAIN_CODINGS: Measurement;
            static readonly CHEST_PAIN_QUESTIONNAIRE: Measurement;
            static readonly STEPS_CODINGS: Measurement;
            static readonly COVID_SURVEY: Measurement;
            static readonly FEVER: Measurement;
            static readonly COUGH: Measurement;
            static readonly DRY_COUGH: Measurement;
            static readonly WET_COUGH: Measurement;
            static readonly LOSS_OF_TASTE_SMELL: Measurement;
            static readonly NASAL_CONGESTION: Measurement;
            static readonly SORE_THROAT: Measurement;
            static readonly FATIGUE: Measurement;
            static readonly CONJUNCTIVITIS: Measurement;
            static readonly GENOMIC_VARIANT_CODE: Measurement;
            static readonly DIAGNOSTIC_IMPLICATION_CODE: Measurement;
            static readonly THERAPEUTIC_IMPLICATION_CODE: Measurement;
            static readonly MOLECULAR_CONSEQUENCE_CODE: Measurement;
            static readonly GENOTYPE_CODE: Measurement;
            static readonly HAPLOTYPE_CODE: Measurement;
            static readonly REGION_STUDIED_CODE: Measurement;
            private constructor();
            static byCode(code: string): Measurement;
        }
        class Goal extends HeartValueSet {
            static readonly FAT_LOSS_FINDING: Goal;
            static readonly WEIGHT_FINDING: Goal;
            static readonly WAIST_FINDING: Goal;
            static readonly PHYSICAL_ACTIVITY_FINDING: Goal;
            static readonly MODERATE_PHYSICAL_ACTIVITY_FINDING: Goal;
            static readonly VIGOROUS_PHYSICAL_ACTIVITY_FINDING: Goal;
            static readonly STRENGTH_PHYSICAL_ACTIVITY_FINDING: Goal;
            static readonly STEPS_ACTIVITY_COUNT_FINDING: Goal;
            static readonly ADOPT_HEALTHY_NUTRITION_FINDING: Goal;
            static readonly CALORIC_INTAKE_FINDING: Goal;
            static readonly CARBOHYDRATES_INTAKE_FINDING: Goal;
            static readonly PROTEINS_INTAKE_FINDING: Goal;
            static readonly FATS_INTAKE_FINDING: Goal;
            static readonly FIBERS_INTAKE_FINDING: Goal;
            static readonly SODIUM_INTAKE_FINDING: Goal;
            static readonly FRUIT_PORTIONS_INTAKE_FINDING: Goal;
            static readonly VEGETABLES_PORTIONS_INTAKE_FINDING: Goal;
            static readonly SUGARY_BEVERAGE_INTAKE_REDUCTION_FINDING: Goal;
            static readonly ALCOHOL_INTAKE_REDUCTION_FINDING: Goal;
            static readonly ADOPT_HEALTHY_HABITS_FINDING: Goal;
            static readonly STOP_SMOKING_FINDING: Goal;
            static readonly HEALTHY_PHYSIOLOGICAL_PARAMETERS_MAINTENANCE_FINDING: Goal;
            static readonly BLOOD_GLUCOSE_MAINTENANCE_FINDING: Goal;
            static readonly BLOOD_PRESSURE_MAINTENANCE_FINDING: Goal;
            static readonly HBA1C_MAINTENANCE_FINDING: Goal;
            static readonly CHOLESTEROL_MAINTENANCE_FINDING: Goal;
            static readonly CHOLESTEROL_HDL_MAINTENANCE_FINDING: Goal;
            static readonly CHOLESTEROL_LDL_MAINTENANCE_FINDING: Goal;
            static readonly TRIGLYCERIDE_MAINTENANCE_FINDING: Goal;
            private constructor();
            static byCode(code: string): Goal;
        }
        class GoalRelationship extends HeartValueSet {
            static readonly REPLACEMENT: GoalRelationship;
            static readonly MILESTONE: GoalRelationship;
            private constructor();
            static byCode(code: string): GoalRelationship;
        }
        class Communication extends HeartValueSet {
            static readonly COMMUNICATION_GOAL: Communication;
            static readonly COMMUNICATION_INFORMATIVE: Communication;
            static readonly COMMUNICATION_DOC: Communication;
            static readonly COMMUNICATION_MOTIVATIONAL: Communication;
            static readonly COMMUNICATION_CHAT: Communication;
            private constructor();
            static byCode(code: string): Communication;
        }
        class LifeStyle extends HeartValueSet {
            static readonly SEDENTARY: LifeStyle;
            static readonly POORLY_ACTIVE: LifeStyle;
            static readonly ACTIVE: LifeStyle;
            static readonly VERY_ACTIVE: LifeStyle;
            static readonly ATHLETIC: LifeStyle;
            private constructor();
            static byCode(code: string): Food;
        }
        class Food extends HeartValueSet {
            static readonly PASTA_RICE: Food;
            static readonly WHOLEMEAL_PASTA_RICE: Food;
            static readonly DRIED_LEGUMES: Food;
            static readonly MEAT: Food;
            static readonly SWEETS: Food;
            static readonly VEGETABLES: Food;
            static readonly EGG: Food;
            static readonly FISH: Food;
            static readonly SAVORY_SNACK: Food;
            static readonly FRUIT: Food;
            static readonly POTATOES: Food;
            static readonly FRESH_DAIRY_PRODUCTS: Food;
            static readonly DRIED_FRUITS: Food;
            static readonly FAST_FOOD: Food;
            static readonly ALCOHOL: Food;
            static readonly SUGARY_DRINKS: Food;
            static readonly OIL: Food;
            static readonly COLD_CUTS: Food;
            static readonly SEASONED_DAIRY_PRODUCTS: Food;
            static readonly MILK_YOGURT: Food;
            static readonly BREAD: Food;
            static readonly SALAD: Food;
            static readonly SUGAR: Food;
            static readonly COOKIE: Food;
            static readonly CROISSANT: Food;
            static readonly MARMALADE: Food;
            static readonly PIZZA: Food;
            static readonly FRESH_LEGUMES: Food;
            static readonly CAKES: Food;
            static readonly ICE_CREAM: Food;
            static readonly BANANA: Food;
            static readonly SALT: Food;
            private constructor();
            static byCode(code: string): Food;
        }
        class Condition extends HeartValueSet {
            static readonly REMISSION_IN_THERAPHY: Condition;
            static readonly REMISSION_OFF_THERAPHY: Condition;
            static readonly VERIFICATION_STATUS_PROVISIONAL: Condition;
            static readonly VERIFICATION_STATUS_CONFIRMED: Condition;
            static readonly VERIFICATION_STATUS_REFUTED: Condition;
            static readonly CLINICAL_STATUS_ACTIVE: Condition;
            static readonly CLINICAL_STATUS_RESOLVED: Condition;
            static readonly CLINICAL_STATUS_REMISSION: Condition;
            static readonly CLINICAL_STATUS_UNKNOWN: Condition;
            private constructor();
            static byCode(code: string): Condition;
        }
    }
    namespace GDPR {
        class ConsentPermission extends HeartValueSet {
            static readonly INFAO: ConsentPermission;
            static readonly INFA: ConsentPermission;
            static readonly INFASO: ConsentPermission;
            static readonly PATIENT_CONSENT: ConsentPermission;
            private constructor();
            static byCode(code: string): ConsentPermission;
        }
        class Consent extends HeartValueSet {
            static readonly SCOPE: Consent;
            private constructor();
            static byCode(code: string): Consent;
        }
    }
    namespace Pathology {
        class ManagedPathology extends HeartValueSet {
            static readonly DIABETES_MELLITUS_TYPE_2: ManagedPathology;
            static readonly DMT2: ManagedPathology;
            static readonly CANCER: ManagedPathology;
            static readonly CARDIOVASCULAR_DISEASE: ManagedPathology;
            static readonly CVD: ManagedPathology;
            static readonly CHRONIC_OBSTRUCTIVE_PULMONARY_DISEASE: ManagedPathology;
            static readonly COPD: ManagedPathology;
            static readonly ASTHMA: ManagedPathology;
            static readonly ALLERGY: ManagedPathology;
            static readonly HYPERTENSION: ManagedPathology;
            static readonly OTHER_DISORDER: ManagedPathology;
            private constructor();
            static byCode(code: string): ManagedPathology;
        }
        class Diabetes extends HeartValueSet {
            static readonly CUSTOM_TWO_POINT_GLUCOSE: Diabetes;
            static readonly CUSTOM_THREE_POINT_GLUCOSE: Diabetes;
            static readonly SEVEN_POINT_GLUCOSE: Diabetes;
            static readonly FIVE_POINT_GLUCOSE: Diabetes;
            static readonly FOUR_POINT_GLUCOSE: Diabetes;
            static readonly STAGGERED_GLUCOSE: Diabetes;
            private constructor();
            static byCode(code: string): Diabetes;
        }
        class DocumentReference extends HeartValueSet {
            static readonly CLINICAL_NOTE: DocumentReference;
            private constructor();
            static byCode(code: string): Diabetes;
        }
    }
    class Risk extends HeartValueSet {
        static readonly NEGLIGIBLE: Risk;
        static readonly LOW: Risk;
        static readonly MODERATE: Risk;
        static readonly HIGH: Risk;
        static readonly CERTAIN: Risk;
        private constructor();
        static byCode(code: string): Risk;
    }
    class Prescription extends HeartValueSet {
        static readonly COUNSELLING: Prescription;
        static readonly EXAM: Prescription;
        static readonly RISK_EVALUATION: Prescription;
        private constructor();
        static byCode(code: string): Risk;
    }
}
