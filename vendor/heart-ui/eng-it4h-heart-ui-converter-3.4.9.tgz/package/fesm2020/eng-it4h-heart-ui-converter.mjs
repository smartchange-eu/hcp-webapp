import { FhirUtils as FhirUtils$1, CodeableConcept, Reference, DomainResource, Patient, Quantity, Identifier as Identifier$1, CodeableReference, ClinicalImpression, DocumentReference, AbstractApi, Attachment, CarePlan, PlanDefinition as PlanDefinition$1, Goal as Goal$1, Coding, Extension, Annotation, Timing, Period, HumanName, Bundle, Range, SimpleQuantity, Person, RelatedPerson, Appointment as Appointment$1, ContactPoint, CareTeam as CareTeam$1, Condition, Consent, Encounter as Encounter$1, EpisodeOfCare, Duration, Observation, Communication, Organization as Organization$1, Practitioner, Address, ServiceRequest, Procedure as Procedure$1, Questionnaire, QuestionnaireResponse, UsageContext, RiskAssessment, ResearchSubject, NutritionIntake, GenomicStudy } from '@eng-it4h/fhir-r5';
import { formatDuration, differenceInCalendarDays } from 'date-fns';
import { Patient as Patient$1, HealthCareProfessional, CareGiver, CareTeam, Organization, Goal, Encounter, Diagnosis, Risk, Nutrition, Trial, TrialSubject, Measure, Plan, PlanDefinition, Procedure, Message, ObservePatient, ClinicalNote, Episode, CodedValue, Identifier, GoalTypeName, Smoker, PatientHealthStatus, LifeStyle, Triglyceride, CholesterolLdl, CholesterolHdl, Cholesterol, SpO2, Hba1c, BloodGlucose, DiastolicBloodPressure, SystolicBloodPressure, BloodPressure, SmokingFrequency, SugaryBeverageDrinkingFrequency, AlcoholDrinkingFrequency, VegetablesPortionsDailyIntake, FruitPortionsDailyIntake, SodiumDailyIntake, FibersDailyIntake, FatsDailyIntake, ProteinsDailyIntake, CarbohydratesDailyIntake, CaloricDailyIntake, Meal, SupervisorRequired, PhysicalInability, StepCount, WorkoutSessionInWeek, VigorousWorkoutDurationInWeek, ModerateWorkoutDurationInWeek, Waist, Height, Weight, BMI, GenericQuantitativeMeasure, HeartRate, ChestPainLevel, ChestPainQuestionnaire, BodyTemperature, TTM, COVIDSymptoms, RiskLevel, EncounterType, EncounterQuestionnaire, CategoryTarget, QuantitativeTarget, RangeTarget, TargetQuantity, Appointment, AppointmentStatus, Gender, CareTeamStatus, ConditionClinicalStatus, ConditionVerificationStatus, DiagnosisType, PatientConsent, ConsentPermission, HealthService, CoughType, WeightUnit, LengthUnit, MealType, Food, TemperatureUnit, ConcentrationUnit, PercentageUnit, FeedbackInAppTypeName, QuantitativeMeasure, CategoryMeasure, TherapeuticImplication, DiagnosticImplication, Significance, MolecularConsequence, GenomicVariant, ChromosomePosition, Quality, Genotype, RegionStudied, Haplotype, InformativeMessage, MotivationalMessage, ChatMessage, DocMessage, DocMessageType, Role, PersonRole, Place, PersonAddress, SMBGActivity, CounsellingPrescription, ExamPrescription, Workout, WorkoutType, WorkoutIntensity, EnergyExpenditure, Distance, Questionnaire as Questionnaire$1, Question, QuestionType, QuestionGroup, Choice, QuestionEnableWhen, QuestionEnableWhenCondition, QuestionEnableWhenOperator, QuestionnaireResponse as QuestionnaireResponse$1, ResponseStatus, AnswerGroup, Answer, Study, VcfMetadata, NutritionItem, Person as Person$1, Condition as Condition$1, Prescription } from '@eng-it4h/heart-ui-model';

// tslint:disable:member-ordering
// prettier-ignore
class Dictionary {
}
/****************************
 * STANDARD SYSTEMS
 ****************************/
Dictionary.SNOMED = 'http://snomed.info/sct';
Dictionary.LOINC = 'http://loinc.org';
Dictionary.ACME = 'http://acme.org/devices/clinical-codes';
Dictionary.UNIT_OF_MEASURE = 'http://unitsofmeasure.org';
Dictionary.ICD10 = 'http://terminology.hl7.org/NamingSystem/icd10';
Dictionary.ICD9Proc = 'http://hl7.org/fhir/sid/icd-9-cm';
Dictionary.FHIR_NAMESPACE = 'http://hl7.org/fhir';
Dictionary.HL7_TERMINLOGY_NAMESPACE = 'http://terminology.hl7.org/CodeSystem/';
/****************************
 * FHIR Officials
 ****************************/
Dictionary.FHIR_VALUE_SET_URI = Dictionary.FHIR_NAMESPACE + '/ValueSet/';
Dictionary.FHIR_EXTENSION_NAMESPACE = Dictionary.FHIR_NAMESPACE + '/StructureDefinition/';
Dictionary.FHIR_OBSERVATION_CATEGORY = Dictionary.HL7_TERMINLOGY_NAMESPACE + '/observation-category';
Dictionary.GOAL_RELATIONSHIP_TYPE_URL = Dictionary.FHIR_NAMESPACE + '/goal-relationship-type';
/****************************
 * HL7 Code systems
****************************/
Dictionary.HL7_RISK_PROBABILITY = Dictionary.HL7_TERMINLOGY_NAMESPACE + 'risk-probability';
Dictionary.HL7_V3_ACT_CODE = Dictionary.HL7_TERMINLOGY_NAMESPACE + 'v3-ActCode';
Dictionary.HL7_CONSENT_SCOPE = Dictionary.HL7_TERMINLOGY_NAMESPACE + 'consentscope';
Dictionary.FHIR_CONDITION_CATEGORY = Dictionary.HL7_TERMINLOGY_NAMESPACE + 'condition-category';
Dictionary.USAGE_CONTEXT_TYPE = Dictionary.HL7_TERMINLOGY_NAMESPACE + 'usage-context-type';
/****************************
 * UHM
 ****************************/
Dictionary.UHM_BASE_DOMAIN = 'http://it4h.eng.it';
Dictionary.BASE_NAMESPACE = Dictionary.UHM_BASE_DOMAIN + '/uhm';
Dictionary.UHM_VALUE_SET_URI = Dictionary.BASE_NAMESPACE + '/ValueSet/';
Dictionary.UHM_IDENTIFIER_URI = Dictionary.BASE_NAMESPACE + '/identifiers/';
Dictionary.UHM_STRUCTURE_DEFINITION_URI = Dictionary.BASE_NAMESPACE + '/StructureDefinition/';
Dictionary.UHM_CODE_SYSTEM_URI = Dictionary.BASE_NAMESPACE + '/CodeSystem/';
Dictionary.UHM_TRIAL_GROUP_SYSTEM = Dictionary.BASE_NAMESPACE + '/trial-group';
Dictionary.UHM_SECURITY_SYSTEM = Dictionary.BASE_NAMESPACE + '/security/uuid';
// The system can be configured by each project. The following value is only the default one
// For this reason the entry is not marked as 'readonly'
Dictionary.UHM_PSEUDONYM_SYSTEM = Dictionary.BASE_NAMESPACE + '/security/pseudonym';
Dictionary.PATIENT_TAX_CODE_SYSTEM = 'http://hl7.it/sid/codiceFiscale';

// tslint:disable: max-classes-per-file no-namespace
// FIXME: MODEL non dovrà più dipendere da FHIR
class HeartValueSet {
    constructor(system, code, display) {
        this.system = system;
        this.code = code;
        this.display = display;
    }
    /**
     * ATTENZIONE: usare con cura questo metodo.
     * Considera soprattutto che non si può invocare '==' su due istanze di ValueSet perchè NON sono ENUM
     */
    static fromCodeableConcept(cc) {
        return new HeartValueSet(cc.coding[0].system, cc.coding[0].code, cc.coding[0].display);
    }
    toCodeableConcept() {
        return FhirUtils$1.createCodeableConcept(this.system, this.code, this.display);
    }
    equals(code) {
        // tslint:disable-next-line: triple-equals
        if (code == undefined) {
            return false;
        }
        if (!(code instanceof Array)) {
            if (code instanceof CodeableConcept || !!code.coding) {
                return code?.coding?.some((c) => /*c.system === this.system && */ c.code === this.code) || false;
            }
            else if (code instanceof HeartValueSet) {
                return code.system === this.system && code.code === this.code;
            }
            else {
                return code === this.code;
            }
        }
        else {
            // recursive invocation in case of array of CodeableConcepts
            return code.some((cc) => this.equals(cc));
        }
    }
}
// prettier-ignore
(function (HeartValueSet) {
    function byCode(code, _class) {
        if (!code) {
            return undefined;
        }
        return Object.keys(_class)
            .filter((key) => _class[key] instanceof HeartValueSet && _class[key].code === code)
            .map((key) => _class[key])
            .pop();
    }
    let Common;
    (function (Common) {
        class MeasurementCategory extends HeartValueSet {
            constructor(system, code, display) {
                super(system, code, display);
            }
            static byCode(code) {
                return byCode(code, MeasurementCategory);
            }
        }
        MeasurementCategory.VITAL_SIGNS = new MeasurementCategory(Dictionary.FHIR_OBSERVATION_CATEGORY, 'vital-signs', 'Vital Signs');
        MeasurementCategory.SURVEY = new MeasurementCategory(Dictionary.FHIR_OBSERVATION_CATEGORY, 'survey', 'Survey');
        MeasurementCategory.NUTRITION_CATEGORY = new MeasurementCategory(Dictionary.BASE_NAMESPACE, 'nutrition', 'Nutrition');
        Common.MeasurementCategory = MeasurementCategory;
        class ClinicalImpression extends HeartValueSet {
            constructor(system, code, display) {
                super(system, code, display);
            }
            static byCode(code) {
                return byCode(code, ClinicalImpression);
            }
        }
        ClinicalImpression.OBSERVE_PATIENT = new ClinicalImpression(Dictionary.BASE_NAMESPACE, 'observe-patient', 'Observe patient');
        Common.ClinicalImpression = ClinicalImpression;
        class Measurement extends HeartValueSet {
            constructor(system, code, display) {
                super(system, code, display);
            }
            static byCode(code) {
                return byCode(code, Measurement);
            }
        }
        Measurement.MEAL_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'meal', 'Meal');
        // new Measurement(Dictionary.SNOMED, '68130003', 'Physical Activity')
        Measurement.PHYSICAL_ACTIVITY_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'workout', 'Workout');
        // target of sub-goal BMI
        Measurement.BMI_CODINGS = new Measurement(Dictionary.LOINC, '39156-5', 'Body mass index (BMI) [Ratio]');
        // target of sub-goal WEIGHT
        Measurement.WEIGHT_CODINGS = new Measurement(Dictionary.SNOMED, '27113001', 'Body weight');
        // new Goal( Dictionary.LOINC, '3141-9', 'Body weight Measured' );
        // new Measurement(Dictionary.LOINC, '8302-2', 'Body height' );
        Measurement.HEIGHT_CODINGS = new Measurement(Dictionary.SNOMED, '50373000', 'Body height measure (observable entity)');
        Measurement.HEART_RATE_RESTING_CODING = new Measurement(Dictionary.LOINC, '40443-4', 'Heart rate --resting');
        // public static readonly SMOKING_FREQ_CODINGS = new Measurement(Dictionary.SNOMED, '230056004', 'Cigarette consumption (observable entity)');
        // public static readonly DRINKING_FREQ_CODINGS = new Measurement(Dictionary.SNOMED, '364657008', 'Frequency of drinking (observable entity)');
        // target of sub-goal WAIST
        Measurement.WAIST_CODINGS = new Measurement(Dictionary.SNOMED, '276361009', 'Waist circumference (observable entity)');
        // new Measurement(  Dictionary.LOINC, '8280-0', 'Waist circumference' );
        // target of sub-goal MODERATE_PHYSICAL_ACTIVITY_FINDING
        Measurement.MODERATE_PHYSICAL_ACTIVITY_DURATION_WEEKLY_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'moderate-physical-activity-weekly-duration', 'Moderate physical activity weekly duration');
        // target of sub-goal VIGOROUS_PHYSICAL_ACTIVITY_FINDING
        Measurement.VIGOROUS_PHYSICAL_ACTIVITY_DURATION_WEEKLY_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'vigorous-physical-activity-weekly-duration', 'Vigorous physical activity weekly duration');
        // target of sub-goal STRENGTH_ACTIVITY_FINDING
        Measurement.STRENGTH_PHYSICAL_ACTIVITY_SESSION_WEEKLY_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'strength-physical-activity-weekly-sessions', 'Strength physical activity weekly sessions');
        Measurement.CALORIC_DAILY_INTAKE_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'caloric-daily-intake', 'Caloric Daily Intake');
        Measurement.CARBOHYDRATES_DAILY_INTAKE_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'carbohydrates-daily-intake', 'Carbohydrates Daily Intake');
        Measurement.PROTEINS_DAILY_INTAKE_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'proteins-daily-intake', 'Proteins Daily Intake');
        Measurement.FATS_DAILY_INTAKE_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'fats-daily-intake', 'Fats Daily Intake');
        Measurement.FIBERS_DAILY_INTAKE_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'fibers-daily-intake', 'Fibers Daily Intake');
        Measurement.SODIUM_DAILY_INTAKE_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'sodium-daily-intake', 'Sodium Daily Intake');
        Measurement.SUGARY_BEVERAGE_DAILY_INTAKE_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'sugary-beverage-daily-intake', 'Sugary Beverage Daily Intake');
        Measurement.ALCOHOL_DAILY_INTAKE_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'alcohol-daily-intake', 'Alcohol Daily Intake');
        Measurement.FRUIT_PORTIONS_DAILY_INTAKE_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'fruit-daily-intake', 'Fruit Portions Daily Intake');
        Measurement.VEGETABLES_PORTIONS_DAILY_INTAKE_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'vegetables-daily-intake', 'Vegetable Portions Daily Intake');
        Measurement.CIGARETTES_DAILY_AMOUNT_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'cigarettes-daily-amount', 'Cigarettes Daily Amount');
        Measurement.BLOOD_PRESSURE_CODINGS = new Measurement(Dictionary.LOINC, '55284-4', 'Blood Pressure'); // '85354-9',
        Measurement.SYSTOLIC_BLOOD_PRESSURE_CODINGS = new Measurement(Dictionary.LOINC, '8480-6', 'Systolic Blood Pressure');
        Measurement.DIASTOLIC_BLOOD_PRESSURE_CODINGS = new Measurement(Dictionary.LOINC, '8462-4', 'Diastolic Blood Pressure');
        Measurement.BLOOD_GLUCOSE_MOLES_CODINGS = new Measurement(Dictionary.LOINC, '15074-8', 'Glucose [Moles/volume] In Blood');
        Measurement.BLOOD_GLUCOSE_MASS_CODINGS = new Measurement(Dictionary.LOINC, '2339-0', 'Glucose [Mass/volume] In Blood');
        Measurement.BLOOD_GLUCOSE_MASS_INSULIN_CODINGS = new Measurement(Dictionary.LOINC, '54265-4', 'Glucose [Moles/volume] in Serum or Plasma --1 hour post dose insulin IV');
        Measurement.HBA1C_CODINGS = new Measurement(Dictionary.LOINC, '55454-3', 'Hemoglobin A1c in Blood');
        Measurement.SPO2_CODINGS = new Measurement(Dictionary.LOINC, '20564-1', 'Oxygen saturation in Blood');
        Measurement.CHOLESTEROL_CODINGS = new Measurement(Dictionary.LOINC, '14647-2', 'Cholesterol [Moles/volume] in Serum or Plasma');
        Measurement.CHOLESTEROL_HDL_CODINGS = new Measurement(Dictionary.LOINC, '2085-9', 'Cholesterol in HDL [Moles/volume] in Serum or Plasma');
        Measurement.CHOLESTEROL_LDL_CODINGS = new Measurement(Dictionary.LOINC, '39469-2', 'Cholesterol in LDL [Moles/volume] in Serum or Plasma by calculation');
        Measurement.TRIGLYCERIDE_CODINGS = new Measurement(Dictionary.LOINC, '14927-8', 'Triglyceride [Moles/volume] in Serum or Plasma');
        Measurement.PHYSICAL_INABILITY_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'physical-inability', 'Physical inability');
        Measurement.SMOKER_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'smoker', 'Smoker');
        Measurement.SUPERVISOR_REQUIRED_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'supervisor-required', 'Supervisor required');
        Measurement.TTM_CODINGS = new Measurement(Dictionary.BASE_NAMESPACE, 'transtheoretical-model-stage', 'Transtheoretical model stage');
        Measurement.PATIENT_HEALTH_STATUS_CODING = new Measurement(Dictionary.SNOMED, '278305009', 'Severity score');
        Measurement.LIFESTYLE_CODING = new Measurement(Dictionary.SNOMED, '134436002', 'Lifestyle');
        Measurement.GENERAL_HEALTH_POOR_CODING = new Measurement(Dictionary.SNOMED, '135818000', 'General Health Poor');
        Measurement.GENERAL_HEALTH_GOOD_CODING = new Measurement(Dictionary.SNOMED, '135815002', 'General Health Good');
        Measurement.GENERAL_HEALTH_FAIR_CODING = new Measurement(Dictionary.SNOMED, '135817005', 'General Health Fair');
        Measurement.BODY_TEMPERATURE_CODINGS = new Measurement(Dictionary.LOINC, '8310-5', 'Body Temperature');
        Measurement.CHEST_PAIN_CODINGS = new Measurement(Dictionary.SNOMED, '29857009', 'Chest pain (finding)');
        Measurement.CHEST_PAIN_QUESTIONNAIRE = new Measurement(Dictionary.BASE_NAMESPACE, 'chest-pain-survey', 'Chest pain survey');
        Measurement.STEPS_CODINGS = new Measurement(Dictionary.LOINC, '41950-7', 'Number of steps in 24 hour Measured');
        // COVID
        Measurement.COVID_SURVEY = new Measurement(Dictionary.BASE_NAMESPACE, 'covid-survey', 'COVID survey');
        Measurement.FEVER = new Measurement(Dictionary.SNOMED, '386661006', 'Fever');
        Measurement.COUGH = new Measurement(Dictionary.SNOMED, '49727002', 'Cough');
        Measurement.DRY_COUGH = new Measurement(Dictionary.SNOMED, '11833005', 'Dry Cough');
        Measurement.WET_COUGH = new Measurement(Dictionary.SNOMED, '28743005', 'Productive Cough');
        Measurement.LOSS_OF_TASTE_SMELL = new Measurement(Dictionary.SNOMED, '44169009', 'Loss of Smell');
        Measurement.NASAL_CONGESTION = new Measurement(Dictionary.SNOMED, '68235000', 'Nasal Congestion');
        Measurement.SORE_THROAT = new Measurement(Dictionary.SNOMED, '267102003', 'Sore Throat');
        Measurement.FATIGUE = new Measurement(Dictionary.SNOMED, '84229001', 'Feeling Tired or Weak');
        Measurement.CONJUNCTIVITIS = new Measurement(Dictionary.LOINC, '45682-2', 'Conjunctivitis [Minimum Data Set]');
        Measurement.GENOMIC_VARIANT_CODE = new Measurement(Dictionary.LOINC, '69548-6', 'Genetic variant assessment');
        Measurement.DIAGNOSTIC_IMPLICATION_CODE = new Measurement("http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs", 'diagnostic-implication', 'Diagnostic Implication');
        Measurement.THERAPEUTIC_IMPLICATION_CODE = new Measurement("http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs", 'therapeutic-implication', 'Therapeutic Implication');
        Measurement.MOLECULAR_CONSEQUENCE_CODE = new Measurement("http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs", 'molecular-consequence', 'Molecular consequence');
        Measurement.GENOTYPE_CODE = new Measurement(Dictionary.LOINC, '84413-4', 'Genotype');
        Measurement.HAPLOTYPE_CODE = new Measurement(Dictionary.LOINC, '84414-2', 'Haplotype');
        Measurement.REGION_STUDIED_CODE = new Measurement(Dictionary.LOINC, '53041-0', 'DNA region of interest');
        Common.Measurement = Measurement;
        class Goal extends HeartValueSet {
            // public static readonly WORKOUT = new Goal( Dictionary.BASE_NAMESPACE, 'workout', 'Workout');
            constructor(system, code, display) {
                super(system, code, display);
            }
            static byCode(code) {
                return byCode(code, Goal);
            }
        }
        // macro-goal fat_loss_goal
        Goal.FAT_LOSS_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'fat-loss', 'Fat Loss');
        // sub-goal WEIGHT and BMI
        Goal.WEIGHT_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'weight-reduction', 'Weight Reduction');
        // sub-goal WAIST
        Goal.WAIST_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'waist-reduction', 'Waist Reduction');
        // macro-goal PHYSICAL_ACTIVITY
        Goal.PHYSICAL_ACTIVITY_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'perform-physical-activity', 'Perform physical activity');
        // sub-goal MODERATE_PHYSICAL_ACTIVITY
        Goal.MODERATE_PHYSICAL_ACTIVITY_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'perform-moderate-physical-activity', 'Perform moderate physical activity');
        // sub-goal VIGOROUS_PHYSICAL_ACTIVITY
        Goal.VIGOROUS_PHYSICAL_ACTIVITY_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'perform-vigorous-physical-activity', 'Perform vigorous physical activity');
        // sub-goal STRENGTH_PHYSICAL_ACTIVITY
        Goal.STRENGTH_PHYSICAL_ACTIVITY_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'perform-strength-physical-activity', 'Perform strength physical activity');
        Goal.STEPS_ACTIVITY_COUNT_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'step-activity-count', 'Count daily steps activity');
        Goal.ADOPT_HEALTHY_NUTRITION_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'adopt-healthy-nutrition', 'Adopt Healthy Nutrition');
        Goal.CALORIC_INTAKE_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'caloric-intake', 'Caloric Intake');
        Goal.CARBOHYDRATES_INTAKE_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'carbohydrates-intake', 'Carbohydrates Intake');
        Goal.PROTEINS_INTAKE_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'proteins-intake', 'Proteins Intake');
        Goal.FATS_INTAKE_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'fats-intake', 'Fats Intake');
        Goal.FIBERS_INTAKE_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'fibers-intake', 'Fibers Intake');
        Goal.SODIUM_INTAKE_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'sodium-intake', 'Sodium Intake');
        Goal.FRUIT_PORTIONS_INTAKE_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'fruit-portions-intake', 'Fruit Portions Intake');
        Goal.VEGETABLES_PORTIONS_INTAKE_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'vegetables-portions-intake', 'Vegetables Portions Intake');
        Goal.SUGARY_BEVERAGE_INTAKE_REDUCTION_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'sugary-beverage-intake-reduction', 'Sugary Beverage Intake Reduction');
        Goal.ALCOHOL_INTAKE_REDUCTION_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'alcohol-intake-reduction', 'Alcohol Intake Reduction');
        Goal.ADOPT_HEALTHY_HABITS_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'adopt-healthy-habits', 'Adopt Healthy Habits');
        Goal.STOP_SMOKING_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'stop-smoking', 'Stop Smoking');
        Goal.HEALTHY_PHYSIOLOGICAL_PARAMETERS_MAINTENANCE_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'healthy-physiological-parameters-maintenance', 'Healthy Physiological Parameters Maintenance');
        Goal.BLOOD_GLUCOSE_MAINTENANCE_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'blood-glucose-maintenance', 'Glucose In Blood Maintenance');
        Goal.BLOOD_PRESSURE_MAINTENANCE_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'blood-pressure-maintenance', 'Blood Pressure Maintenance');
        Goal.HBA1C_MAINTENANCE_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'hbA1c-maintenance', 'Hemoglobin A1c in Blood Maintenance');
        Goal.CHOLESTEROL_MAINTENANCE_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'cholesterol-maintenance', 'Cholesterol Maintenance');
        Goal.CHOLESTEROL_HDL_MAINTENANCE_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'cholesterol-hdl-maintenance', 'Cholesterol in HDL Maintenance');
        Goal.CHOLESTEROL_LDL_MAINTENANCE_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'cholesterol-ldl-maintenance', 'Cholesterol in LDL Maintenance');
        Goal.TRIGLYCERIDE_MAINTENANCE_FINDING = new Goal(Dictionary.BASE_NAMESPACE, 'triglyceride-maintenance', 'Triglyceride Maintenance');
        Common.Goal = Goal;
        class GoalRelationship extends HeartValueSet {
            constructor(system, code, display) {
                super(system, code, display);
            }
            static byCode(code) {
                return byCode(code, GoalRelationship);
            }
        }
        GoalRelationship.REPLACEMENT = new GoalRelationship(Dictionary.GOAL_RELATIONSHIP_TYPE_URL, 'replacement', 'Replacement');
        GoalRelationship.MILESTONE = new GoalRelationship(Dictionary.GOAL_RELATIONSHIP_TYPE_URL, 'milestone', 'Milestone');
        Common.GoalRelationship = GoalRelationship;
        class Communication extends HeartValueSet {
            constructor(system, code, display) {
                super(system, code, display);
            }
            static byCode(code) {
                return byCode(code, Communication);
            }
        }
        Communication.COMMUNICATION_GOAL = new Communication(Dictionary.BASE_NAMESPACE, 'goal-message', 'new goal message');
        Communication.COMMUNICATION_INFORMATIVE = new Communication(Dictionary.BASE_NAMESPACE, 'informative-message', 'informative message');
        Communication.COMMUNICATION_DOC = new Communication(Dictionary.BASE_NAMESPACE, 'doc-message', 'doc message');
        Communication.COMMUNICATION_MOTIVATIONAL = new Communication(Dictionary.BASE_NAMESPACE, 'motivational-message', 'motivational message');
        Communication.COMMUNICATION_CHAT = new Communication(Dictionary.BASE_NAMESPACE, 'chat-message', 'chat message');
        Common.Communication = Communication;
        class LifeStyle extends HeartValueSet {
            constructor(system, code, display) {
                super(system, code, display);
            }
            static byCode(code) {
                return byCode(code, LifeStyle);
            }
        }
        LifeStyle.SEDENTARY = new LifeStyle(Dictionary.BASE_NAMESPACE, 'sedentary', 'Sedentary');
        LifeStyle.POORLY_ACTIVE = new LifeStyle(Dictionary.BASE_NAMESPACE, 'poorly_active', 'Poorly active');
        LifeStyle.ACTIVE = new LifeStyle(Dictionary.BASE_NAMESPACE, 'active', 'Active');
        LifeStyle.VERY_ACTIVE = new LifeStyle(Dictionary.BASE_NAMESPACE, 'very_active', 'Very active');
        LifeStyle.ATHLETIC = new LifeStyle(Dictionary.BASE_NAMESPACE, 'athletic', 'Athletic');
        Common.LifeStyle = LifeStyle;
        class Food extends HeartValueSet {
            constructor(system, code, display) {
                super(system, code, display);
            }
            static byCode(code) {
                return byCode(code, Food);
            }
        }
        Food.PASTA_RICE = new Food(Dictionary.BASE_NAMESPACE, 'pasta-rice', 'Pasta and rice');
        Food.WHOLEMEAL_PASTA_RICE = new Food(Dictionary.BASE_NAMESPACE, 'wholemeal-pasta-rice', 'Wholemeal pasta and rice');
        Food.DRIED_LEGUMES = new Food(Dictionary.BASE_NAMESPACE, 'dried-legume', 'Dried legume');
        Food.MEAT = new Food(Dictionary.BASE_NAMESPACE, 'meat', 'Meat');
        Food.SWEETS = new Food(Dictionary.BASE_NAMESPACE, 'sweets', 'Sweets');
        Food.VEGETABLES = new Food(Dictionary.BASE_NAMESPACE, 'vegetables', 'Vegetables');
        Food.EGG = new Food(Dictionary.BASE_NAMESPACE, 'egg', 'Egg');
        Food.FISH = new Food(Dictionary.BASE_NAMESPACE, 'fish', 'Fish');
        Food.SAVORY_SNACK = new Food(Dictionary.BASE_NAMESPACE, 'savory-snack', 'Savory snack');
        Food.FRUIT = new Food(Dictionary.BASE_NAMESPACE, 'fruit', 'Fruit');
        Food.POTATOES = new Food(Dictionary.BASE_NAMESPACE, 'potatoes', 'potatoes');
        Food.FRESH_DAIRY_PRODUCTS = new Food(Dictionary.BASE_NAMESPACE, 'fresh-dairy-products', 'Fresh dairy products');
        Food.DRIED_FRUITS = new Food(Dictionary.BASE_NAMESPACE, 'dried-fruit', 'Dried fruit');
        Food.FAST_FOOD = new Food(Dictionary.BASE_NAMESPACE, 'fast-food', 'Dast food');
        Food.ALCOHOL = new Food(Dictionary.BASE_NAMESPACE, 'alcohol', 'Alcohol');
        Food.SUGARY_DRINKS = new Food(Dictionary.BASE_NAMESPACE, 'sugary-drinks', 'Sugary drinks');
        Food.OIL = new Food(Dictionary.BASE_NAMESPACE, 'oil', 'Oil');
        Food.COLD_CUTS = new Food(Dictionary.BASE_NAMESPACE, 'cold-cuts', 'Cold cuts');
        Food.SEASONED_DAIRY_PRODUCTS = new Food(Dictionary.BASE_NAMESPACE, 'seasoned-dairy-products', 'Seasoned dairy products');
        Food.MILK_YOGURT = new Food(Dictionary.BASE_NAMESPACE, 'milk-yogurt', 'Milk and yogurt');
        Food.BREAD = new Food(Dictionary.BASE_NAMESPACE, 'bread', 'Bread');
        Food.SALAD = new Food(Dictionary.BASE_NAMESPACE, 'salad', 'Salad');
        Food.SUGAR = new Food(Dictionary.BASE_NAMESPACE, 'sugar', 'Sugar');
        Food.COOKIE = new Food(Dictionary.BASE_NAMESPACE, 'cookie', 'Cookie');
        Food.CROISSANT = new Food(Dictionary.BASE_NAMESPACE, 'croissant', 'Croissant');
        Food.MARMALADE = new Food(Dictionary.BASE_NAMESPACE, 'marmalade', 'Marmalade');
        Food.PIZZA = new Food(Dictionary.BASE_NAMESPACE, 'pizza', 'Pizza');
        // NEW IN HEART
        Food.FRESH_LEGUMES = new Food(Dictionary.BASE_NAMESPACE, 'fresh_legumes', 'Fresh Legumes');
        Food.CAKES = new Food(Dictionary.BASE_NAMESPACE, 'cakes', 'Traditional Cakes');
        Food.ICE_CREAM = new Food(Dictionary.BASE_NAMESPACE, 'ice-cream', 'Ice-Cream');
        Food.BANANA = new Food(Dictionary.BASE_NAMESPACE, 'banana', 'Banana');
        Food.SALT = new Food(Dictionary.BASE_NAMESPACE, 'salt', 'Salt');
        Common.Food = Food;
        class Condition extends HeartValueSet {
            constructor(system, code, display) {
                super(system, code, display);
            }
            static byCode(code) {
                return byCode(code, Condition);
            }
        }
        Condition.REMISSION_IN_THERAPHY = new Condition(Dictionary.UHM_CODE_SYSTEM_URI + 'condition-clinical-status-remission', 'in-therapy', 'In remission (in-therapy)');
        Condition.REMISSION_OFF_THERAPHY = new Condition(Dictionary.UHM_CODE_SYSTEM_URI + 'condition-clinical-status-remission', 'off-therapy', 'In remission (off-therapy)');
        Condition.VERIFICATION_STATUS_PROVISIONAL = new Condition(Dictionary.HL7_TERMINLOGY_NAMESPACE + 'condition-ver-status', 'provisional', 'Provisional');
        Condition.VERIFICATION_STATUS_CONFIRMED = new Condition(Dictionary.HL7_TERMINLOGY_NAMESPACE + 'condition-ver-status', 'confirmed', 'Confirmed');
        Condition.VERIFICATION_STATUS_REFUTED = new Condition(Dictionary.HL7_TERMINLOGY_NAMESPACE + 'condition-ver-status', 'refuted', 'Refuted');
        Condition.CLINICAL_STATUS_ACTIVE = new Condition(Dictionary.HL7_TERMINLOGY_NAMESPACE + 'condition-clinical', 'active', 'Active');
        Condition.CLINICAL_STATUS_RESOLVED = new Condition(Dictionary.HL7_TERMINLOGY_NAMESPACE + 'condition-clinical', 'resolved', 'Resolved');
        Condition.CLINICAL_STATUS_REMISSION = new Condition(Dictionary.HL7_TERMINLOGY_NAMESPACE + 'condition-clinical', 'remission', 'Remission');
        Condition.CLINICAL_STATUS_UNKNOWN = new Condition(Dictionary.HL7_TERMINLOGY_NAMESPACE + 'condition-clinical', 'unknown', 'Unknown');
        Common.Condition = Condition;
    })(Common = HeartValueSet.Common || (HeartValueSet.Common = {}));
    let GDPR;
    (function (GDPR) {
        class ConsentPermission extends HeartValueSet {
            constructor(system, code, display) {
                super(system, code, display);
            }
            static byCode(code) {
                return byCode(code, ConsentPermission);
            }
        }
        ConsentPermission.INFAO = new ConsentPermission(Dictionary.HL7_V3_ACT_CODE, 'INFAO', 'access only');
        ConsentPermission.INFA = new ConsentPermission(Dictionary.HL7_V3_ACT_CODE, 'INFA', 'information access');
        ConsentPermission.INFASO = new ConsentPermission(Dictionary.HL7_V3_ACT_CODE, 'INFASO', 'access and save only');
        ConsentPermission.PATIENT_CONSENT = new ConsentPermission(Dictionary.LOINC, '59284-0', 'Patient Consent');
        GDPR.ConsentPermission = ConsentPermission;
        class Consent extends HeartValueSet {
            constructor(system, code, display) {
                super(system, code, display);
            }
            static byCode(code) {
                return byCode(code, Consent);
            }
        }
        Consent.SCOPE = new Consent(Dictionary.HL7_CONSENT_SCOPE, 'patient-privacy', 'Privacy Consent');
        GDPR.Consent = Consent;
    })(GDPR = HeartValueSet.GDPR || (HeartValueSet.GDPR = {}));
    let Pathology;
    (function (Pathology) {
        class ManagedPathology extends HeartValueSet {
            constructor(system, code, display) {
                super(system, code, display);
            }
            static byCode(code) {
                return byCode(code, ManagedPathology);
            }
        }
        ManagedPathology.DIABETES_MELLITUS_TYPE_2 = new ManagedPathology(Dictionary.SNOMED, '44054006', 'Diabetes mellitus type 2 (disorder)');
        ManagedPathology.DMT2 = ManagedPathology.DIABETES_MELLITUS_TYPE_2;
        ManagedPathology.CANCER = new ManagedPathology(Dictionary.SNOMED, '363346000', 'Cancer');
        ManagedPathology.CARDIOVASCULAR_DISEASE = new ManagedPathology(Dictionary.SNOMED, '49601007', 'Disorder of cardiovascular system (disorder)');
        ManagedPathology.CVD = ManagedPathology.CARDIOVASCULAR_DISEASE;
        ManagedPathology.CHRONIC_OBSTRUCTIVE_PULMONARY_DISEASE = new ManagedPathology(Dictionary.SNOMED, '313296004', 'Mild chronic obstructive pulmonary disease (disorder)');
        ManagedPathology.COPD = ManagedPathology.CHRONIC_OBSTRUCTIVE_PULMONARY_DISEASE;
        ManagedPathology.ASTHMA = new ManagedPathology(Dictionary.SNOMED, '195967001', 'Asthma (disorder)');
        ManagedPathology.ALLERGY = new ManagedPathology(Dictionary.SNOMED, '300910009', 'Allergy to pollen (finding)');
        ManagedPathology.HYPERTENSION = new ManagedPathology(Dictionary.SNOMED, '38341003', 'Hypertensive disorder, systemic arterial (disorder)');
        ManagedPathology.OTHER_DISORDER = new ManagedPathology(Dictionary.SNOMED, '64572001', 'Disease (disorder)');
        Pathology.ManagedPathology = ManagedPathology;
        class Diabetes extends HeartValueSet {
            constructor(system, code, display) {
                super(system, code, display);
            }
            static byCode(code) {
                return byCode(code, Diabetes);
            }
        }
        Diabetes.CUSTOM_TWO_POINT_GLUCOSE = new Diabetes(Dictionary.BASE_NAMESPACE, 'custom-2-points-blood-glucose-measurement', 'Custom 2 points blood glucose measurement');
        Diabetes.CUSTOM_THREE_POINT_GLUCOSE = new Diabetes(Dictionary.BASE_NAMESPACE, 'custom-3-points-blood-glucose-measurement', 'Custom 3 points blood glucose measurement');
        Diabetes.SEVEN_POINT_GLUCOSE = new Diabetes(Dictionary.BASE_NAMESPACE, '7-points-blood-glucose-measurement', '7 points blood glucose measurement');
        Diabetes.FIVE_POINT_GLUCOSE = new Diabetes(Dictionary.BASE_NAMESPACE, '5-points-blood-glucose-measurement', '5 points blood glucose measurement');
        Diabetes.FOUR_POINT_GLUCOSE = new Diabetes(Dictionary.BASE_NAMESPACE, '4-points-blood-glucose-measurement', '4 points blood glucose measurement');
        Diabetes.STAGGERED_GLUCOSE = new Diabetes(Dictionary.BASE_NAMESPACE, 'staggered-blood-glucose-measurement', 'staggered blood glucose measurement');
        Pathology.Diabetes = Diabetes;
        class DocumentReference extends HeartValueSet {
            constructor(system, code, display) {
                super(system, code, display);
            }
            static byCode(code) {
                return byCode(code, Diabetes);
            }
        }
        DocumentReference.CLINICAL_NOTE = new DocumentReference(Dictionary.LOINC, '11488-4', 'Consult Note');
        Pathology.DocumentReference = DocumentReference;
    })(Pathology = HeartValueSet.Pathology || (HeartValueSet.Pathology = {}));
    class Risk extends HeartValueSet {
        constructor(system, code, display) {
            super(system, code, display);
        }
        static byCode(code) {
            return byCode(code, Risk);
        }
    }
    Risk.NEGLIGIBLE = new Risk(Dictionary.HL7_RISK_PROBABILITY, 'negligible', 'Negligible likelihood');
    Risk.LOW = new Risk(Dictionary.HL7_RISK_PROBABILITY, 'low', 'Low likelihood');
    Risk.MODERATE = new Risk(Dictionary.HL7_RISK_PROBABILITY, 'moderate', 'Moderate likelihood');
    Risk.HIGH = new Risk(Dictionary.HL7_RISK_PROBABILITY, 'high', 'High likelihood');
    Risk.CERTAIN = new Risk(Dictionary.HL7_RISK_PROBABILITY, 'certain', 'Certain');
    HeartValueSet.Risk = Risk;
    class Prescription extends HeartValueSet {
        constructor(system, code, display) {
            super(system, code, display);
        }
        static byCode(code) {
            return byCode(code, Risk);
        }
    }
    Prescription.COUNSELLING = new Prescription(Dictionary.SNOMED, '409063005', 'Counselling');
    Prescription.EXAM = new Prescription(Dictionary.FHIR_CONDITION_CATEGORY, 'encounter-diagnosis', 'Encounter Diagnosis');
    Prescription.RISK_EVALUATION = new Prescription(Dictionary.SNOMED, '6061000124109', 'Risk evaluation and mitigation strategy consultation (procedure)');
    HeartValueSet.Prescription = Prescription;
})(HeartValueSet || (HeartValueSet = {}));

// tslint:disable: max-classes-per-file no-namespace
// prettier-ignore
class HeartExtension {
    constructor(entity, attributeName, resource, url, dataType) {
        this.entity = entity;
        this.attributeName = attributeName;
        this.resource = resource;
        this.url = url;
        this.dataType = dataType;
        //
    }
    /**
     * Find the extension declared by a HeartExtension object in a FHIR item
     * @param extensions - a FHIR Extension array
     * @returns null if the extension is not found
     */
    findAmongExtensions(extensions) {
        return extensions?.find((item) => {
            return item.url === this.url;
        });
    }
    extractValueSetFromExtensions(extensions) {
        const ext = this.findAmongExtensions(extensions);
        if (ext) {
            return HeartValueSet.fromCodeableConcept(ext.value);
        }
        return undefined;
    }
    extractValueSetsFromExtensions(extensions) {
        return (extensions
            // tslint:disable-next-line:triple-equals
            ?.filter((item) => item.url === this.url && item.value != undefined)
            .map((e) => HeartValueSet.fromCodeableConcept(e.value)));
    }
    extractCodingFromExtensions(extensions) {
        return (extensions
            // tslint:disable-next-line:triple-equals
            ?.filter((item) => item.url === this.url && item.value != undefined)
            .map((e) => e.value));
    }
    extractReferencesFromExtensions(extensions) {
        return (extensions
            // tslint:disable-next-line:triple-equals
            ?.filter((item) => item.url === this.url && item.value != undefined)
            .map((e) => e.value));
    }
    extractValueFromExtensions(extensions) {
        const ext = this.findAmongExtensions(extensions);
        let value;
        if (ext) {
            const v = ext.value;
            if (!!v && (v instanceof Reference || v.reference)) {
                if (!(v instanceof Reference)) {
                    value = Reference.revive(v);
                }
                else {
                    value = v;
                }
            }
            else {
                value = ext.value;
            }
        }
        return value;
    }
    toExtension(value) {
        return FhirUtils$1.createExtension(this.url, value);
    }
    toStructuredExtension(innerExtensions) {
        const ext = FhirUtils$1.createExtension(this.url, undefined);
        ext.extension = innerExtensions;
        return ext;
    }
    toExtensionCodeableConcept(value) {
        if (value instanceof HeartValueSet) {
            return FhirUtils$1.createExtensionCodeableConcept(this.url, value.toCodeableConcept());
        }
        else {
            return FhirUtils$1.createExtensionCodeableConcept(this.url, value);
        }
    }
    toExtensionCoding(value) {
        return FhirUtils$1.createExtensionCoding(this.url, value);
    }
    toExtensionResource(value) {
        return FhirUtils$1.createExtensionResource(this.url, value);
    }
    toExtensionString(value) {
        return FhirUtils$1.createExtensionString(this.url, value);
    }
    toExtensionBoolean(value) {
        return FhirUtils$1.createExtensionBoolean(this.url, value);
    }
    toExtensionNumber(value) {
        return FhirUtils$1.createExtensionNumber(this.url, value);
    }
    toExtensionDate(value) {
        return FhirUtils$1.createExtensionDate(this.url, value);
    }
    toExtensionQuantity(value) {
        return FhirUtils$1.createExtensionQuantity(this.url, value);
    }
    toExtensionReference(value) {
        if (value instanceof DomainResource) {
            return FhirUtils$1.createExtensionReference(this.url, value.getReference());
        }
        return FhirUtils$1.createExtensionReference(this.url, value);
    }
}
(function (HeartExtension) {
    class Common {
    }
    Common.AttachmentExternalizedBinaryId = new HeartExtension('Attachment', '_data', 'Attachment', Dictionary.FHIR_EXTENSION_NAMESPACE + 'externalized-binary-id', 'string');
    HeartExtension.Common = Common;
    // FIXME: REMOVE PROJECT DEPENDANT EXTENSIONS
    class CMP3VDA {
    }
    CMP3VDA.CMP3VDA_EXTENSION_NAMESPACE = 'https://www.cmp3vda-project.it/fhir/StructureDefinition/';
    CMP3VDA.Condition_assertedDate = new HeartExtension('Condition', 'assertedDate', 'Condition', Dictionary.FHIR_EXTENSION_NAMESPACE + 'condition-assertedDate', 'date');
    CMP3VDA.Condition_followupDate = new HeartExtension('Condition', 'followupDate', 'Condition', CMP3VDA.CMP3VDA_EXTENSION_NAMESPACE + 'FollowUpDate', 'date');
    CMP3VDA.Condition_isPrimary = new HeartExtension('Condition', 'isPrimary', 'Condition', Dictionary.UHM_STRUCTURE_DEFINITION_URI + 'is-primary-extension', 'boolean');
    CMP3VDA.Condition_isSyndromic = new HeartExtension('Condition', 'isSyndromic', 'Condition', Dictionary.UHM_STRUCTURE_DEFINITION_URI + 'is-syndromic-extension', 'boolean');
    CMP3VDA.Condition_isCatatonic = new HeartExtension('Condition', 'isCatatonic', 'Condition', Dictionary.UHM_STRUCTURE_DEFINITION_URI + 'is-catatonic-extension', 'boolean');
    HeartExtension.CMP3VDA = CMP3VDA;
    class Patient {
    }
    Patient.homeType = new HeartExtension('Patient', 'homeType', 'Patient', Dictionary.UHM_STRUCTURE_DEFINITION_URI + 'address-home-type', 'Coding');
    Patient.birthPlace = new HeartExtension('Patient', 'birthPlace', 'Patient', Dictionary.FHIR_EXTENSION_NAMESPACE + 'patient-birthPlace', 'Address');
    HeartExtension.Patient = Patient;
    class Condition {
    }
    Condition.diagnosisType = new HeartExtension('Condition', 'diagnosisType', 'Diagnosis', Dictionary.UHM_STRUCTURE_DEFINITION_URI + 'diagnosis-type', 'Coding');
    Condition.remissionType = new HeartExtension('Condition', 'remissionType', 'Diagnosis', Dictionary.UHM_STRUCTURE_DEFINITION_URI + 'condition-clinical-status-remission-qualifier', 'Coding');
    HeartExtension.Condition = Condition;
    class Questionnaire {
    }
    Questionnaire.minValue = new HeartExtension('Questionnaire', 'minValue', 'Questionnaire', Dictionary.FHIR_EXTENSION_NAMESPACE + 'minValue', 'integer | decimal | date | time | dateTime | Quantity');
    Questionnaire.maxValue = new HeartExtension('Questionnaire', 'maxValue', 'Questionnaire', Dictionary.FHIR_EXTENSION_NAMESPACE + 'maxValue', 'integer | decimal | date | time | dateTime | Quantity');
    HeartExtension.Questionnaire = Questionnaire;
    class Goal {
    }
    Goal.ExtensionGoalUri = Dictionary.FHIR_EXTENSION_NAMESPACE + 'Goal/';
    Goal.relationshipType = new HeartExtension('Goal', 'goalRelationship', 'Goal', Dictionary.GOAL_RELATIONSHIP_TYPE_URL, 'Reference(Goal)');
    Goal.relationship = new HeartExtension('Goal', 'goal-relationship', 'Goal', Goal.ExtensionGoalUri + 'goal-relationship', '');
    Goal.actuator = new HeartExtension('Goal', 'actuator', 'Goal', Goal.ExtensionGoalUri + 'goal-actuator', '');
    Goal.proposedReplaced = new HeartExtension('Goal', '', 'Goal', Goal.ExtensionGoalUri + 'goal-proposed-replaced', '');
    Goal.createdOn = new HeartExtension('Goal', '', 'Goal', Goal.ExtensionGoalUri + 'created-on', 'datetime');
    Goal.cancelledBy = new HeartExtension('Goal', '', 'Goal', Goal.ExtensionGoalUri + 'cancelled-by', 'datetime');
    Goal.validatedOn = new HeartExtension('Goal', '', 'Goal', Goal.ExtensionGoalUri + 'validated-on', 'datetime');
    Goal.proposedOn = new HeartExtension('Goal', '', 'Goal', Goal.ExtensionGoalUri + 'proposed-on', 'datetime');
    Goal.acceptanceDuration = new HeartExtension('Goal', '', 'Goal', Goal.ExtensionGoalUri + 'acceptance-duration', 'duration');
    Goal.acceptedOn = new HeartExtension('Goal', '', 'Goal', Goal.ExtensionGoalUri + 'accepted-on', 'datetime');
    Goal.endedOn = new HeartExtension('Goal', '', 'Goal', Goal.ExtensionGoalUri + 'ended-on', 'datetime');
    Goal.cancelledOn = new HeartExtension('Goal', '', 'Goal', Goal.ExtensionGoalUri + 'cancelled-on', 'datetime');
    Goal.startedOn = new HeartExtension('Goal', '', 'Goal', Goal.ExtensionGoalUri + 'started-on', 'datetime');
    HeartExtension.Goal = Goal;
    class Workout {
    }
    Workout.ExtensionProcedureUri = Dictionary.FHIR_EXTENSION_NAMESPACE + 'Procedure/';
    Workout.healthSource = new HeartExtension('Workout', 'healthSource', 'Procedure', Workout.ExtensionProcedureUri + 'health-source', 'string');
    Workout.healthId = new HeartExtension('Workout', 'healthId', 'Procedure', Workout.ExtensionProcedureUri + 'health-id', 'string');
    Workout.isAutomatic = new HeartExtension('Workout', '', 'Procedure', Workout.ExtensionProcedureUri + 'is-automatic', '');
    Workout.Workoput_type = new HeartExtension('Workout', '', 'Procedure', Workout.ExtensionProcedureUri + 'type', '');
    Workout.intensity = new HeartExtension('Workout', '', 'Procedure', Workout.ExtensionProcedureUri + 'intensity', '');
    Workout.energyExpenditure = new HeartExtension('Workout', '', 'Procedure', Workout.ExtensionProcedureUri + 'energy-expenditure', '');
    Workout.stepCounter = new HeartExtension('Workout', '', 'Procedure', Workout.ExtensionProcedureUri + 'step-counter', '');
    Workout.distance = new HeartExtension('Workout', '', 'Procedure', Workout.ExtensionProcedureUri + 'distance', '');
    HeartExtension.Workout = Workout;
    class Meal {
    }
    Meal.ExtensionObservationUri = Dictionary.FHIR_EXTENSION_NAMESPACE + 'Observation/';
    Meal.type = new HeartExtension('Meal', '', 'Observation', Meal.ExtensionObservationUri + 'meal-type', 'code');
    Meal.portionSize = new HeartExtension('Meal', '', 'Observation', Meal.ExtensionObservationUri + 'portion-size', 'code');
    Meal.carbohydrates = new HeartExtension('Meal', 'carbsInKcal', 'Observation', Meal.ExtensionObservationUri + 'carbohydrates', 'decimal');
    Meal.fibers = new HeartExtension('Meal', 'fibersInGrams', 'Observation', Meal.ExtensionObservationUri + 'fibers', 'decimal');
    Meal.sodium = new HeartExtension('Meal', 'sodiumInMilliGrams', 'Observation', Meal.ExtensionObservationUri + 'sodium', 'decimal');
    Meal.fats = new HeartExtension('Meal', 'fatsInKcal', 'Observation', Meal.ExtensionObservationUri + 'fats', 'decimal');
    Meal.proteins = new HeartExtension('Meal', 'proteinsInKcal', 'Observation', Meal.ExtensionObservationUri + 'proteins', 'decimal');
    Meal.foodWeight = new HeartExtension('Meal', 'weightInGrams', 'Observation', Meal.ExtensionObservationUri + 'food-weight', 'decimal');
    HeartExtension.Meal = Meal;
    class BloodGlucose {
    }
    BloodGlucose.ExtensionObservationUri = Dictionary.FHIR_EXTENSION_NAMESPACE + 'Observation/';
    BloodGlucose.measurePoint = new HeartExtension('BloodGlucose', '', 'Observation', BloodGlucose.ExtensionObservationUri + 'blood-glucose-measure-point', 'code');
    BloodGlucose.drugStatement = new HeartExtension('BloodGlucose', '', 'Observation', BloodGlucose.ExtensionObservationUri + 'blood-glucose-drug-measurement', 'code');
    BloodGlucose.fastingOrAfterMealBloodSugar = new HeartExtension('BloodGlucose', '', 'Observation', BloodGlucose.ExtensionObservationUri + 'blood-glucose-fasting-or-aftermeal', 'string');
    HeartExtension.BloodGlucose = BloodGlucose;
    class Message {
    }
    Message.ExtensionCommunicationUri = Dictionary.FHIR_EXTENSION_NAMESPACE + 'Communication/';
    Message.read = new HeartExtension('Message', 'read', 'Communication', Message.ExtensionCommunicationUri + 'read', 'date');
    HeartExtension.Message = Message;
})(HeartExtension || (HeartExtension = {}));

class AbstractFhirConverter {
    constructor(c) {
        this.service = c;
    }
    /**
     * Prova a risolvere il riferimento sia nella risorsa container che nel bundle, se presente, MA non prova a risolvere in remoto.
     *
     */
    resolveReference(reference, parentResource, bundle) {
        if (reference.isContainedResource()) {
            // is contained ref
            return parentResource.findContainedResource(reference);
        }
        else {
            // looks inside the bundle
            const fhir = bundle ? bundle.findResourceInBundle(reference) : undefined;
            if (fhir) {
                return fhir;
            }
            else if (reference.reference?.includes('urn:') && bundle) {
                // replaces substitued IDs. This is a non-normative approach
                const newFhir = bundle.entry.find((e) => e.response._id === reference.reference)?.resource;
                reference.reference = newFhir.resourceType + '/' + newFhir.id;
                return newFhir;
            }
            else {
                // error
                throw new Error(`[ERROR] Unresolvable reference ${reference.reference} while converting element.`);
            }
        }
    }
    resolveSubject(ref, parent, context) {
        let p;
        if (ref instanceof Patient) {
            p = ref;
        }
        else if (ref instanceof Reference) {
            try {
                p = this.resolveReference(ref, parent, context);
            }
            catch (e) {
                console.log(`Error resolving reference ${e}`);
            }
        }
        if (p) {
            return this.service.person.toDataModel(p);
        }
        else {
            return undefined;
        }
    }
    // prettier-ignore
    getDuration(duration) {
        switch (duration.unit) {
            default:
            case 'd': {
                if (duration.value > 30 && duration.value < 365) {
                    const _duration = formatDuration({ days: duration.value }, { format: ['months'] });
                    return +_duration.split(' ')[0];
                }
                else if (duration.value > 365) {
                    const _duration = formatDuration({ days: duration.value }, { format: ['years'] });
                    return +_duration.split(' ')[0];
                }
                else {
                    return duration.value;
                }
            }
            case 'w': {
                const days = duration.value * 7;
                if (days > 30 && days < 365) {
                    const _duration = formatDuration({ days: days }, { format: ['months'] });
                    return +_duration.split(' ')[0];
                }
                else if (days > 365) {
                    const _duration = formatDuration({ days: days }, { format: ['years'] });
                    return +_duration.split(' ')[0];
                }
                else {
                    return days;
                }
            }
            case 'm': {
                if (duration.value > 12) {
                    const _duration = formatDuration({ months: duration.value }, { format: ['years'] });
                    return +_duration.split(' ')[0];
                }
                else {
                    return duration.value;
                }
            }
            case 'y': return duration.value;
        }
    }
    /**
     * Given a FHIR resource retrieves the ID with its 'resource type' (if available)
     */
    toFhirID(resource) {
        const resType = resource.resourceType;
        let id = resource.id;
        const index = id?.indexOf('/_history');
        if (index > 0) {
            id = id.substring(0, index);
        }
        return resType ? `${resType}/${id}` : id;
    }
    toFhirIDPart(resource) {
        let id = resource.id;
        const index = id?.indexOf('/_history');
        if (index > 0) {
            id = id.substring(0, index);
        }
        const numericPartIndex = id?.indexOf('/');
        if (numericPartIndex > 0) {
            id = id.substring(numericPartIndex + 1);
        }
        return id != undefined ? +id : undefined;
    }
    toFhirVersion(resource) {
        const id = resource.id;
        let version = '1';
        const index = id?.indexOf('/_history/');
        if (index > 0) {
            version = id.substring(index + '/_history/'.length);
        }
        else if (resource.meta) {
            version = resource.meta.versionId;
        }
        return version;
    }
    createQuantity(v, unit) {
        const value = new Quantity();
        value.system = Dictionary.UNIT_OF_MEASURE;
        value.unit = unit;
        value.value = v;
        return value;
    }
}

class ModelToFHIRUtils {
    static getReference(e) {
        if (!!e) {
            const resType = ModelToFHIRUtils.getFhirResourceType(e);
            if (!e.id || !resType) {
                return undefined;
            }
            const reference = new Reference();
            // se non è definito il default è l'id
            // reference.reference = `${resType}/${e.fhirId}`;
            reference.reference = `${resType}/${e.id}`;
            return reference;
        }
        else {
            return undefined;
        }
    }
    static stubFromRef(ref, forceResourceType) {
        if (!ref || !ref.reference) {
            return undefined;
        }
        const refFixed = Reference.fromReference(ref.reference, forceResourceType);
        const fhirResourceType = refFixed.type;
        let id = refFixed.getReferenceIdPart();
        if (Number.isNaN(id)) {
            id = ref.getReferenceIdPart();
        }
        if (fhirResourceType == 'Patient') {
            return new Patient$1(id);
        }
        else if (fhirResourceType == 'Practitioner') {
            return new HealthCareProfessional(id);
        }
        else if (fhirResourceType == 'RelatedPerson') {
            return new CareGiver(id);
        }
        else if (fhirResourceType == 'CareTeam') {
            return new CareTeam(id);
        }
        else if (fhirResourceType == 'Organization') {
            return new Organization(id);
        }
        else if (fhirResourceType == 'Goal') {
            const g = new Goal();
            g.id = id;
            return g;
        }
        else if (fhirResourceType == 'Encounter') {
            const e = new Encounter();
            e.id = id;
            return e;
        }
        else if (fhirResourceType == 'Condition') {
            const d = new Diagnosis();
            d.id = id;
            return d;
        }
        else if (fhirResourceType == 'RiskAssessment') {
            const d = new Risk();
            d.id = id;
            return d;
        }
        else if (fhirResourceType == 'NutritionIntake') {
            const d = new Nutrition();
            d.id = id;
            return d;
        }
        if (fhirResourceType == 'ResearchStudy') {
            const d = new Trial();
            d.id = id;
            return d;
        }
        if (fhirResourceType == 'ResearchSubject') {
            const d = new TrialSubject();
            d.id = id;
            return d;
        }
        else {
            throw new TypeError(`Unsupported domain resource type ${[ref.reference]}. Error converting to datamodel from FHIR.`);
        }
    }
    static getFhirResourceType(model) {
        if (model instanceof Measure) {
            return 'Observation';
        }
        else if (model instanceof Goal) {
            return 'Goal';
        }
        else if (model instanceof Patient$1) {
            return 'Patient';
        }
        else if (model instanceof HealthCareProfessional) {
            return 'Practitioner';
        }
        else if (model instanceof Plan) {
            return 'CarePlan';
        }
        else if (model instanceof PlanDefinition) {
            return 'PlanDefinition';
        }
        else if (model instanceof Procedure) {
            return 'Procedure';
        }
        else if (model instanceof Message) {
            return 'Communication';
        }
        else if (model instanceof ObservePatient) {
            return 'ClinicalImpression';
        }
        else if (model instanceof ClinicalNote) {
            return 'DocumentReference';
        }
        else if (model instanceof CareGiver) {
            return 'RelatedPerson';
        }
        else if (model instanceof CareTeam) {
            return 'CareTeam';
        }
        else if (model instanceof Organization) {
            return 'Organization';
        }
        else if (model instanceof Episode) {
            return 'EpisodeOfCare';
        }
        else if (model instanceof Encounter) {
            return 'Encounter';
        }
        else if (model instanceof Risk) {
            return 'RiskAssessment';
        }
        else if (model instanceof Trial) {
            return 'ResearchStudy';
        }
        else if (model instanceof TrialSubject) {
            return 'ResearchSubject';
        }
        else if (model instanceof Nutrition) {
            return 'NutritionIntake';
        }
        else {
            return model.resourceType;
        }
    }
    static toCodedValueModel(c) {
        const code = c.coding[0];
        if (code) {
            return new CodedValue(code.system, code.code, code.display);
        }
        return undefined;
    }
    static fromCodedValueModel(c, text) {
        return FhirUtils$1.createCodeableConcept(c.system, c.code, c.display, text);
    }
    static fromTextModel(text) {
        return FhirUtils$1.createCodeableConceptWithOnlyText(text);
    }
    static toIdentifierModel(i) {
        if (i) {
            const ret = new Identifier();
            ret.value = i.value;
            ret.system = i.system;
            ret.use = i.use;
            return ret;
        }
        else
            return undefined;
    }
    static fromIdentifierModel(i) {
        const ret = new Identifier$1();
        ret.value = i.value;
        ret.system = i.system;
        ret.use = i.use;
        // consider to put this info in the Identifier class as to avoid staticcally defined values
        // ret.type = FhirUtils.createCodeableConcept( Dictionary.UHM_SECURITY_SYSTEM, 'uuid', 'Universal Identifier (UUID)' );
        return ret;
    }
    static fromPseudonymIdentifierModel(pseudonym) {
        const ret = new Identifier$1();
        ret.value = pseudonym;
        ret.system = Dictionary.UHM_PSEUDONYM_SYSTEM;
        ret.use = Identifier$1.IdentifierUse.SECONDARY.toString();
        // consider to put this info in the Identifier class as to avoid statically defined values
        // ret.type = FhirUtils.createCodeableConcept(Dictionary.PSEUDONYM_SYSTEM, 'pseudonym', 'Patient pseudonym');
        return ret;
    }
    static getCodeableReference(cv, sharable) {
        const cr = new CodeableReference();
        if (cv) {
            cr.concept = ModelToFHIRUtils.fromCodedValueModel(cv);
        }
        if (sharable) {
            cr.reference = ModelToFHIRUtils.getReference(sharable);
        }
        return cr;
    }
    static encodeToBase64(inputText) {
        if (inputText) {
            const utf8Encoded = new TextEncoder().encode(inputText);
            return btoa(String.fromCharCode(...utf8Encoded));
        }
        else {
            return undefined;
        }
    }
    static decodeFromBase64(base64) {
        if (!base64) {
            return undefined;
        }
        try {
            const binaryString = atob(base64);
            const binaryData = Uint8Array.from(binaryString, (char) => char.charCodeAt(0));
            return new TextDecoder().decode(binaryData);
        }
        catch (error) {
            throw new Error('Invalid Base64 string.');
        }
    }
}

class ClinicalImpressionFhirConverter extends AbstractFhirConverter {
    fromDataModel(model) {
        if (model instanceof ObservePatient) {
            return this.fromDataModelObservePatient(model);
            // } else {
            //     throw new TypeError(
            //         'Unsupported model type. Error converting from datamodel to FHIR.'
            //     );
        }
        else {
            return undefined;
        }
    }
    toDataModel(resource, context) {
        let model;
        // const code: CodeableConcept = resource.code; //FIXME in r5 the code was deleted
        // list all conversion criteria. It mainly consists of a set of codes to be mapped n the local model
        //FIXME in r5 the code was deleted
        // try matching all the codes (it stops at the first match)
        // if (HeartValueSet.Common.ClinicalImpression.OBSERVE_PATIENT.equals(code)) {
        //   model = this.toDataModelObservePatient(resource, context);
        // } else {
        //   throw new TypeError(
        //     `Unsupported measure type. Error converting to datamodel from FHIR: ${
        //       code?.coding?.length > 0
        //         ? code?.coding[0].code + ' - ' + code?.coding[0].display
        //         : ''
        //     }`
        //   );
        // }
        return model;
    }
    toDataModelObservePatient(resource, context) {
        const model = new ObservePatient();
        // fhir ID
        model.id = this.toFhirIDPart(resource);
        const status = resource.status;
        switch (status) {
            case ClinicalImpression.EventStatus.INPROGRESS.toString():
                model.status = true;
                break;
            case ClinicalImpression.EventStatus.COMPLETED.toString():
            default:
                model.status = false;
                break;
        }
        model.patient = ModelToFHIRUtils.stubFromRef(resource.subject);
        model.practitioner = ModelToFHIRUtils.stubFromRef(resource.performer);
        return model;
    }
    fromDataModelObservePatient(model) {
        const fhir = new ClinicalImpression();
        fhir.id = model.id + '';
        fhir.subject = ModelToFHIRUtils.getReference(model.patient);
        fhir.performer = ModelToFHIRUtils.getReference(model.practitioner);
        //FIXME in r5 the code was deleted
        // fhir.code =
        //   HeartValueSet.Common.ClinicalImpression.OBSERVE_PATIENT.toCodeableConcept();
        if (model.status) {
            fhir.status =
                ClinicalImpression.EventStatus.INPROGRESS.toString();
        }
        else {
            fhir.status =
                ClinicalImpression.EventStatus.COMPLETED.toString();
        }
        return fhir;
    }
}

class ClinicalNoteFhirConverter extends AbstractFhirConverter {
    toDataModel(fDocument, context) {
        const cn = new ClinicalNote();
        cn.id = this.toFhirIDPart(fDocument);
        let author = fDocument.author?.pop();
        if (author) {
            cn.author = ModelToFHIRUtils.stubFromRef(author);
        }
        let sub = fDocument.subject;
        if (sub) {
            cn.patient = ModelToFHIRUtils.stubFromRef(sub);
        }
        // type
        if (fDocument.content?.length > 0) {
            const attachment = fDocument.content[0].attachment;
            cn.title = attachment.title;
            try {
                if (attachment.contentType == 'text/plain') {
                    const base64Data = attachment.data;
                    if (base64Data) {
                        cn.body = ModelToFHIRUtils.decodeFromBase64(base64Data);
                    }
                    else
                        throw new Error('unsupported media type');
                }
            }
            catch (err) {
                console.log('unsupported content type');
                return undefined;
            }
        }
        cn.refers = fDocument.relatesTo
            ?.map((relatesTo) => {
            const ref = relatesTo.target;
            let relatedNote;
            try {
                if (ref && ref instanceof Reference) {
                    relatedNote = this.resolveReference(ref, fDocument, context);
                }
            }
            catch (e) {
                console.log(`Error resolving reference ${e}`);
            }
            return relatedNote;
        })
            .pop();
        cn.createdAt = fDocument.date;
        return cn;
    }
    fromDataModel(cn) {
        const doc = new DocumentReference();
        doc.id = cn.slug || AbstractApi.generateRandomIDDt();
        doc.subject = ModelToFHIRUtils.getReference(cn.patient);
        if (cn.author) {
            doc.author = [ModelToFHIRUtils.getReference(cn.author)];
        }
        doc.status = 'current';
        if (cn.refers) {
            // refers to the previous note
            const relatesTo = new DocumentReference.DocumentReferenceRelatesToComponent();
            relatesTo.target = ModelToFHIRUtils.getReference(cn.refers);
            doc.relatesTo = [relatesTo];
        }
        doc.date = cn.createdAt;
        const attachment = new Attachment();
        attachment.title = cn.title;
        attachment.contentType = 'text/plain';
        attachment.data = ModelToFHIRUtils.encodeToBase64(cn.body);
        const content = new DocumentReference.DocumentReferenceContentComponent();
        content.attachment = attachment;
        doc.content = [content];
        return doc;
    }
}

// prettier-ignore
class FhirCodesMapperUtils {
    static PlanStatusToFHIR(planStatus) {
        switch (planStatus) {
            default:
            case Plan.PlanStatus.DRAFT:
                return CarePlan.RequestStatus.DRAFT;
            case Plan.PlanStatus.ACTIVE:
                return CarePlan.RequestStatus.ACTIVE;
            case Plan.PlanStatus.COMPLETED:
                return CarePlan.RequestStatus.COMPLETED;
            case Plan.PlanStatus.ENTERED_IN_ERROR:
                return CarePlan.RequestStatus.ENTEREDINERROR;
            case Plan.PlanStatus.ON_HOLD:
                return CarePlan.RequestStatus.ONHOLD;
            case Plan.PlanStatus.REVOKED:
                return CarePlan.RequestStatus.REVOKED;
            case Plan.PlanStatus.UNKNOWN:
                return CarePlan.RequestStatus.UNKNOWN;
        }
    }
    static PlanStatusFromFHIR(fhirCarePlanStatus) {
        switch (fhirCarePlanStatus?.toString()) {
            case CarePlan.RequestStatus.ACTIVE.toString():
                return Plan.PlanStatus.ACTIVE;
            case CarePlan.RequestStatus.COMPLETED.toString():
                return Plan.PlanStatus.COMPLETED;
            case CarePlan.RequestStatus.DRAFT.toString():
                return Plan.PlanStatus.DRAFT;
            case CarePlan.RequestStatus.ENTEREDINERROR.toString():
                return Plan.PlanStatus.ENTERED_IN_ERROR;
            case CarePlan.RequestStatus.ONHOLD.toString():
                return Plan.PlanStatus.ON_HOLD;
            case CarePlan.RequestStatus.REVOKED.toString():
                return Plan.PlanStatus.REVOKED;
            case CarePlan.RequestStatus.UNKNOWN.toString():
                return Plan.PlanStatus.UNKNOWN;
            default:
            case CarePlan.RequestStatus.NULL.toString():
                return Plan.PlanStatus.UNKNOWN;
        }
    }
    static PlanDefinitionStatusFromFHIR(fhirPlanDefinitionStatus) {
        switch (fhirPlanDefinitionStatus?.toString()) {
            case PlanDefinition$1.PublicationStatus.ACTIVE.toString():
                return PlanDefinition.PlanStatus.ACTIVE;
            case PlanDefinition$1.PublicationStatus.DRAFT.toString():
                return PlanDefinition.PlanStatus.DRAFT;
            case PlanDefinition$1.PublicationStatus.RETIRED.toString():
                return PlanDefinition.PlanStatus.RETIRED;
            case PlanDefinition$1.PublicationStatus.UNKNOWN.toString():
                return PlanDefinition.PlanStatus.UNKNOWN;
            default:
            case CarePlan.RequestStatus.NULL.toString():
                return PlanDefinition.PlanStatus.UNKNOWN;
        }
    }
    static GoalStatusToFHIR(goalStatus) {
        switch (goalStatus) {
            default:
            case Goal.GoalStatus.PROPOSED:
                return Goal$1.GoalLifecycleStatus.PROPOSED;
            case Goal.GoalStatus.ACHIEVED:
                return 'achieved' /*FhirGoal.GoalLifecycleStatus.ACHIEVED*/;
            case Goal.GoalStatus.CANCELLED:
                return Goal$1.GoalLifecycleStatus.CANCELLED;
            case Goal.GoalStatus.FAILED:
                return 'failed' /*FhirGoal.GoalLifecycleStatus.FAILED*/;
            case Goal.GoalStatus.NOT_ACCEPTED:
                return 'not_accepted' /*FhirGoal.GoalLifecycleStatus.NOT_ACCEPTED*/;
            case Goal.GoalStatus.ACTIVE:
                return 'active' /*FhirGoal.GoalLifecycleStatus.INPROGRESS*/;
            case Goal.GoalStatus.CANDIDATE_FOR_PROPOSAL:
                return 'candidate_for_proposal' /*FhirGoal.GoalLifecycleStatus.CANDIDATE_FOR_PROPOSAL*/;
            case Goal.GoalStatus.NOT_APPROVED:
                return 'not_approved' /*FhirGoal.GoalLifecycleStatus.NOT_APPROVED*/;
            case Goal.GoalStatus.REJECTED:
                return Goal$1.GoalLifecycleStatus.REJECTED;
            case Goal.GoalStatus.PLANNED:
                return Goal$1.GoalLifecycleStatus.PLANNED;
            // case LocalGoal.GoalStatus.UNKNOWN : return FhirGoal.GoalLifecycleStatus.NULL;
        }
    }
    static GoalStatusFromFHIR(fhirGoalLifecycleStatus) {
        switch (fhirGoalLifecycleStatus?.toString()) {
            case Goal$1.GoalLifecycleStatus.PROPOSED.toString():
                return Goal.GoalStatus.PROPOSED;
            case 'achieved' /*FhirGoal.GoalLifecycleStatus.ACHIEVED.toString()*/:
                return Goal.GoalStatus.ACHIEVED;
            case Goal$1.GoalLifecycleStatus.CANCELLED.toString():
                return Goal.GoalStatus.CANCELLED;
            case 'failed' /*FhirGoal.GoalLifecycleStatus.FAILED.toString()*/:
                return Goal.GoalStatus.FAILED;
            case 'not_accepted' /*FhirGoal.GoalLifecycleStatus.NOT_ACCEPTED.toString()*/:
                return Goal.GoalStatus.NOT_ACCEPTED;
            case Goal$1.GoalLifecycleStatus.ACTIVE.toString():
                return Goal.GoalStatus.ACTIVE;
            case 'candidate_for_proposal' /*FhirGoal.GoalLifecycleStatus.CANDIDATE_FOR_PROPOSAL.toString()*/:
                return Goal.GoalStatus.CANDIDATE_FOR_PROPOSAL;
            case 'not_approved' /*FhirGoal.GoalLifecycleStatus.NOT_APPROVED.toString()*/:
                return Goal.GoalStatus.NOT_APPROVED;
            case Goal$1.GoalLifecycleStatus.REJECTED.toString():
                return Goal.GoalStatus.REJECTED;
            case Goal$1.GoalLifecycleStatus.PLANNED.toString():
                return Goal.GoalStatus.PLANNED;
            default:
            case Goal$1.GoalLifecycleStatus.NULL.toString():
                return Goal.GoalStatus.UNKNOWN;
        }
    }
    static fromDataModelGoalType(goalType) {
        switch (goalType) {
            case GoalTypeName.FAT_LOSS:
                return HeartValueSet.Common.Goal.FAT_LOSS_FINDING.toCodeableConcept();
            case GoalTypeName.WAIST_REDUCTION:
                return HeartValueSet.Common.Goal.WAIST_FINDING.toCodeableConcept();
            case GoalTypeName.BMI: // BMI is managed via its WEIGHT LOSS goal
            case GoalTypeName.WEIGHT:
                return HeartValueSet.Common.Goal.WEIGHT_FINDING.toCodeableConcept();
            case GoalTypeName.PHYSICAL_ACTIVITY:
                return HeartValueSet.Common.Goal.PHYSICAL_ACTIVITY_FINDING.toCodeableConcept();
            case GoalTypeName.MODERATE_PHYSICAL_ACTIVITY:
                return HeartValueSet.Common.Goal.MODERATE_PHYSICAL_ACTIVITY_FINDING.toCodeableConcept();
            case GoalTypeName.VIGOROUS_PHYSICAL_ACTIVITY:
                return HeartValueSet.Common.Goal.VIGOROUS_PHYSICAL_ACTIVITY_FINDING.toCodeableConcept();
            case GoalTypeName.STRENGTH_PHYSICAL_ACTIVITY:
                return HeartValueSet.Common.Goal.STRENGTH_PHYSICAL_ACTIVITY_FINDING.toCodeableConcept();
            case GoalTypeName.STEPS:
                return HeartValueSet.Common.Goal.STEPS_ACTIVITY_COUNT_FINDING.toCodeableConcept();
            case GoalTypeName.ADOPT_HEALTHY_NUTRITION:
                return HeartValueSet.Common.Goal.ADOPT_HEALTHY_NUTRITION_FINDING.toCodeableConcept();
            case GoalTypeName.CALORIC_INTAKE:
                return HeartValueSet.Common.Goal.CALORIC_INTAKE_FINDING.toCodeableConcept();
            case GoalTypeName.CARBOHYDRATES_INTAKE:
                return HeartValueSet.Common.Goal.CARBOHYDRATES_INTAKE_FINDING.toCodeableConcept();
            case GoalTypeName.PROTEINS_INTAKE:
                return HeartValueSet.Common.Goal.PROTEINS_INTAKE_FINDING.toCodeableConcept();
            case GoalTypeName.FATS_INTAKE:
                return HeartValueSet.Common.Goal.FATS_INTAKE_FINDING.toCodeableConcept();
            case GoalTypeName.FIBERS_INTAKE:
                return HeartValueSet.Common.Goal.FIBERS_INTAKE_FINDING.toCodeableConcept();
            case GoalTypeName.SODIUM_INTAKE:
                return HeartValueSet.Common.Goal.SODIUM_INTAKE_FINDING.toCodeableConcept();
            case GoalTypeName.FRUIT_PORTIONS_DAILY_INTAKE:
                return HeartValueSet.Common.Goal.FRUIT_PORTIONS_INTAKE_FINDING.toCodeableConcept();
            case GoalTypeName.VEGETABLES_PORTIONS_DAILY_INTAKE:
                return HeartValueSet.Common.Goal.VEGETABLES_PORTIONS_INTAKE_FINDING.toCodeableConcept();
            case GoalTypeName.SUGARY_BEVERAGE_INTAKE:
                return HeartValueSet.Common.Goal.SUGARY_BEVERAGE_INTAKE_REDUCTION_FINDING.toCodeableConcept();
            case GoalTypeName.ALCOHOL_INTAKE:
                return HeartValueSet.Common.Goal.ALCOHOL_INTAKE_REDUCTION_FINDING.toCodeableConcept();
            case GoalTypeName.ADOPT_HEALTHY_HABITS:
                return HeartValueSet.Common.Goal.ADOPT_HEALTHY_HABITS_FINDING.toCodeableConcept();
            case GoalTypeName.STOP_SMOKING:
                return HeartValueSet.Common.Goal.STOP_SMOKING_FINDING.toCodeableConcept();
            case GoalTypeName.HEALTHY_PHYSIOLOGICAL_MAINTAINANCE:
                return HeartValueSet.Common.Goal.HEALTHY_PHYSIOLOGICAL_PARAMETERS_MAINTENANCE_FINDING.toCodeableConcept();
            // case GoalTypeName.systolic_blood_pressure_maintenance':
            // return HeartValueSet.Common.Goal.BLOOD_PRESSURE_MAINTENANCE_FINDING.toCodeableConcept();
            // case GoalTypeName.diastolic_blood_pressure_maintenance':
            // return HeartValueSet.Common.Goal.BLOOD_PRESSURE_MAINTENANCE_FINDING.toCodeableConcept();
            case GoalTypeName.BLOOD_PRESSURE_MAINTAINANCE:
                return HeartValueSet.Common.Goal.BLOOD_PRESSURE_MAINTENANCE_FINDING.toCodeableConcept();
            case GoalTypeName.BLOOD_GLUCOSE_MAINTAINANCE:
                return HeartValueSet.Common.Goal.BLOOD_GLUCOSE_MAINTENANCE_FINDING.toCodeableConcept();
            case GoalTypeName.HBA1C_MAINTAINANCE:
                return HeartValueSet.Common.Goal.HBA1C_MAINTENANCE_FINDING.toCodeableConcept();
            case GoalTypeName.CHOLESTEROL_MAINTAINANCE:
                return HeartValueSet.Common.Goal.CHOLESTEROL_MAINTENANCE_FINDING.toCodeableConcept();
            case GoalTypeName.CHOLESTEROL_HDL_MAINTAINANCE:
                return HeartValueSet.Common.Goal.CHOLESTEROL_HDL_MAINTENANCE_FINDING.toCodeableConcept();
            case GoalTypeName.CHOLESTEROL_LDL_MAINTAINANCE:
                return HeartValueSet.Common.Goal.CHOLESTEROL_LDL_MAINTENANCE_FINDING.toCodeableConcept();
            case GoalTypeName.TRYGLICERIDE_MAINTAINANCE:
                return HeartValueSet.Common.Goal.TRIGLYCERIDE_MAINTENANCE_FINDING.toCodeableConcept();
            default:
                throw new TypeError(`Unsupported quantitative target type '${goalType}' in '#fromDataModelGoalType'. Error converting from datamodel to FHIR.`);
        }
    }
    static toDataModelGoalType(fGoalCoding, fGoalTargetMeasureCode) {
        let type;
        switch (fGoalCoding?.code) {
            case HeartValueSet.Common.Goal.FAT_LOSS_FINDING.code:
                type = GoalTypeName.FAT_LOSS;
                break;
            case HeartValueSet.Common.Goal.WAIST_FINDING.code:
                type = GoalTypeName.WAIST_REDUCTION;
                break;
            case HeartValueSet.Common.Goal.WEIGHT_FINDING.code:
                if (HeartValueSet.Common.Measurement.BMI_CODINGS.equals(fGoalTargetMeasureCode)) {
                    type = GoalTypeName.BMI;
                }
                else {
                    type = GoalTypeName.WEIGHT;
                }
                break;
            case HeartValueSet.Common.Goal.PHYSICAL_ACTIVITY_FINDING.code:
                type = GoalTypeName.PHYSICAL_ACTIVITY;
                break;
            case HeartValueSet.Common.Goal.MODERATE_PHYSICAL_ACTIVITY_FINDING.code:
                type = GoalTypeName.MODERATE_PHYSICAL_ACTIVITY;
                break;
            case HeartValueSet.Common.Goal.VIGOROUS_PHYSICAL_ACTIVITY_FINDING.code:
                type = GoalTypeName.VIGOROUS_PHYSICAL_ACTIVITY;
                break;
            case HeartValueSet.Common.Goal.STRENGTH_PHYSICAL_ACTIVITY_FINDING.code:
                type = GoalTypeName.STRENGTH_PHYSICAL_ACTIVITY;
                break;
            case HeartValueSet.Common.Goal.STEPS_ACTIVITY_COUNT_FINDING.code:
                type = GoalTypeName.STEPS;
                break;
            case HeartValueSet.Common.Goal.ADOPT_HEALTHY_NUTRITION_FINDING.code:
                type = GoalTypeName.ADOPT_HEALTHY_NUTRITION;
                break;
            case HeartValueSet.Common.Goal.CALORIC_INTAKE_FINDING.code:
                type = GoalTypeName.CALORIC_INTAKE;
                break;
            case HeartValueSet.Common.Goal.CARBOHYDRATES_INTAKE_FINDING.code:
                type = GoalTypeName.CARBOHYDRATES_INTAKE;
                break;
            case HeartValueSet.Common.Goal.PROTEINS_INTAKE_FINDING.code:
                type = GoalTypeName.PROTEINS_INTAKE;
                break;
            case HeartValueSet.Common.Goal.FATS_INTAKE_FINDING.code:
                type = GoalTypeName.FATS_INTAKE;
                break;
            case HeartValueSet.Common.Goal.FIBERS_INTAKE_FINDING.code:
                type = GoalTypeName.FIBERS_INTAKE;
                break;
            case HeartValueSet.Common.Goal.SODIUM_INTAKE_FINDING.code:
                type = GoalTypeName.SODIUM_INTAKE;
                break;
            case HeartValueSet.Common.Goal.VEGETABLES_PORTIONS_INTAKE_FINDING.code:
                type = GoalTypeName.VEGETABLES_PORTIONS_DAILY_INTAKE;
                break;
            case HeartValueSet.Common.Goal.FRUIT_PORTIONS_INTAKE_FINDING.code:
                type = GoalTypeName.FRUIT_PORTIONS_DAILY_INTAKE;
                break;
            case HeartValueSet.Common.Goal.SUGARY_BEVERAGE_INTAKE_REDUCTION_FINDING
                .code:
                type = GoalTypeName.SUGARY_BEVERAGE_INTAKE;
                break;
            case HeartValueSet.Common.Goal.ALCOHOL_INTAKE_REDUCTION_FINDING.code:
                type = GoalTypeName.ALCOHOL_INTAKE;
                break;
            case HeartValueSet.Common.Goal.ADOPT_HEALTHY_HABITS_FINDING.code:
                type = GoalTypeName.ADOPT_HEALTHY_HABITS;
                break;
            case HeartValueSet.Common.Goal.STOP_SMOKING_FINDING.code:
                type = GoalTypeName.STOP_SMOKING;
                break;
            case HeartValueSet.Common.Goal
                .HEALTHY_PHYSIOLOGICAL_PARAMETERS_MAINTENANCE_FINDING.code:
                type = GoalTypeName.HEALTHY_PHYSIOLOGICAL_MAINTAINANCE;
                break;
            case HeartValueSet.Common.Goal.BLOOD_PRESSURE_MAINTENANCE_FINDING.code:
                type = GoalTypeName.BLOOD_PRESSURE_MAINTAINANCE;
                break;
            case HeartValueSet.Common.Goal.BLOOD_GLUCOSE_MAINTENANCE_FINDING.code:
                type = GoalTypeName.BLOOD_GLUCOSE_MAINTAINANCE;
                break;
            case HeartValueSet.Common.Goal.HBA1C_MAINTENANCE_FINDING.code:
                type = GoalTypeName.HBA1C_MAINTAINANCE;
                break;
            case HeartValueSet.Common.Goal.CHOLESTEROL_MAINTENANCE_FINDING.code:
                type = GoalTypeName.CHOLESTEROL_MAINTAINANCE;
                break;
            case HeartValueSet.Common.Goal.CHOLESTEROL_HDL_MAINTENANCE_FINDING.code:
                type = GoalTypeName.CHOLESTEROL_HDL_MAINTAINANCE;
                break;
            case HeartValueSet.Common.Goal.CHOLESTEROL_LDL_MAINTENANCE_FINDING.code:
                type = GoalTypeName.CHOLESTEROL_LDL_MAINTAINANCE;
                break;
            case HeartValueSet.Common.Goal.TRIGLYCERIDE_MAINTENANCE_FINDING.code:
                type = GoalTypeName.TRYGLICERIDE_MAINTAINANCE;
                break;
            default:
                type = GoalTypeName.TRYGLICERIDE_MAINTAINANCE;
            // throw new TypeError(
            //   `[WARN] Unsupported FHIR Goal type with coding ${JSON.stringify(
            //     fGoalCoding?.code
            //   )}. Error converting to datamodel from FHIR.`
            // );
        }
        return type;
    }
    static getTargetVariableClass(variableName) {
        switch (variableName) {
            case 'BMI':
                return BMI;
            case 'Weight':
                return Weight;
            case 'Height':
                return Height;
            case 'Waist':
                return Waist;
            case 'ModerateWorkoutDurationInWeek':
                return ModerateWorkoutDurationInWeek;
            case 'VigorousWorkoutDurationInWeek':
                return VigorousWorkoutDurationInWeek;
            case 'WorkoutSessionInWeek':
                return WorkoutSessionInWeek;
            case 'StepCount':
                return StepCount;
            case 'PhysicalInability':
                return PhysicalInability;
            case 'SupervisorRequired':
                return SupervisorRequired;
            case 'Meal':
                return Meal;
            case 'CaloricDailyIntake':
                return CaloricDailyIntake;
            case 'CarbohydratesDailyIntake':
                return CarbohydratesDailyIntake;
            case 'ProteinsDailyIntake':
                return ProteinsDailyIntake;
            case 'FatsDailyIntake':
                return FatsDailyIntake;
            case 'FibersDailyIntake':
                return FibersDailyIntake;
            case 'SodiumDailyIntake':
                return SodiumDailyIntake;
            case 'FruitPortionsDailyIntake':
                return FruitPortionsDailyIntake;
            case 'VegetablesPortionsDailyIntake':
                return VegetablesPortionsDailyIntake;
            case 'AlcoholDrinkingFrequency':
                return AlcoholDrinkingFrequency;
            case 'SugaryBeverageDrinkingFrequency':
                return SugaryBeverageDrinkingFrequency;
            case 'SmokingFrequency':
                return SmokingFrequency;
            case 'BloodPressure':
                return BloodPressure;
            case 'SystolicBloodPressure':
                return SystolicBloodPressure;
            case 'DiastolicBloodPressure':
                return DiastolicBloodPressure;
            case 'BloodGlucose':
                return BloodGlucose;
            case 'Hba1c':
                return Hba1c;
            case 'SpO2':
                return SpO2;
            case 'Cholesterol':
                return Cholesterol;
            case 'CholesterolHdl':
                return CholesterolHdl;
            case 'CholesterolLdl':
                return CholesterolLdl;
            case 'Triglyceride':
                return Triglyceride;
            case 'LifeStyle':
                return LifeStyle;
            case 'PatientHealthStatus':
                return PatientHealthStatus;
            case 'Smoker':
                return Smoker;
            default:
                throw new TypeError(`Unsupported quantitative target type '${variableName}' in 'toDataModelTargetVariable'. Error converting to datamodel from FHIR.`);
        }
    }
    static getTargetVariableClassName(_class) {
        switch (_class.name) {
            case BMI.name:
                return 'BMI';
            case Weight.name:
                return 'Weight';
            case Height.name:
                return 'Height';
            case Waist.name:
                return 'Waist';
            case ModerateWorkoutDurationInWeek.name:
                return 'ModerateWorkoutDurationInWeek';
            case VigorousWorkoutDurationInWeek.name:
                return 'VigorousWorkoutDurationInWeek';
            case WorkoutSessionInWeek.name:
                return 'WorkoutSessionInWeek';
            case StepCount.name:
                return 'StepCount';
            case PhysicalInability.name:
                return 'PhysicalInability';
            case SupervisorRequired.name:
                return 'SupervisorRequired';
            case Meal.name:
                return 'Meal';
            case CaloricDailyIntake.name:
                return 'CaloricDailyIntake';
            case CarbohydratesDailyIntake.name:
                return 'CarbohydratesDailyIntake';
            case ProteinsDailyIntake.name:
                return 'ProteinsDailyIntake';
            case FatsDailyIntake.name:
                return 'FatsDailyIntake';
            case FibersDailyIntake.name:
                return 'FibersDailyIntake';
            case SodiumDailyIntake.name:
                return 'SodiumDailyIntake';
            case VegetablesPortionsDailyIntake.name:
                return 'VegetablesPortionsDailyIntake';
            case FruitPortionsDailyIntake.name:
                return 'FruitPortionsDailyIntake';
            case AlcoholDrinkingFrequency.name:
                return 'AlcoholDrinkingFrequency';
            case SugaryBeverageDrinkingFrequency.name:
                return 'SugaryBeverageDrinkingFrequency';
            case SmokingFrequency.name:
                return 'SmokingFrequency';
            case BloodPressure.name:
                return 'BloodPressure';
            case SystolicBloodPressure.name:
                return 'SystolicBloodPressure';
            case DiastolicBloodPressure.name:
                return 'DiastolicBloodPressure';
            case BloodGlucose.name:
                return 'BloodGlucose';
            case Hba1c.name:
                return 'Hba1c';
            case SpO2.name:
                return 'SpO2';
            case Cholesterol.name:
                return 'Cholesterol';
            case CholesterolHdl.name:
                return 'CholesterolHdl';
            case CholesterolLdl.name:
                return 'CholesterolLdl';
            case Triglyceride.name:
                return 'Triglyceride';
            case LifeStyle.name:
                return 'LifeStyle';
            case PatientHealthStatus.name:
                return 'PatientHealthStatus';
            case Smoker.name:
                return 'Smoker';
            default:
                throw new TypeError(`Unsupported quantitative target type '${_class}' in 'getTargetVariableClassName'. Error converting to datamodel from Class to ClassName.`);
        }
    }
    static toDataModelTargetVariable(fhirCc) {
        if (HeartValueSet.Common.Measurement.BMI_CODINGS.equals(fhirCc)) {
            return BMI;
        }
        else if (HeartValueSet.Common.Measurement.WEIGHT_CODINGS.equals(fhirCc)) {
            return Weight;
        }
        else if (HeartValueSet.Common.Measurement.HEIGHT_CODINGS.equals(fhirCc)) {
            return Height;
        }
        else if (HeartValueSet.Common.Measurement.WAIST_CODINGS.equals(fhirCc)) {
            return Waist;
        }
        else if (HeartValueSet.Common.Measurement.MODERATE_PHYSICAL_ACTIVITY_DURATION_WEEKLY_CODINGS.equals(fhirCc)) {
            return ModerateWorkoutDurationInWeek;
        }
        else if (HeartValueSet.Common.Measurement.VIGOROUS_PHYSICAL_ACTIVITY_DURATION_WEEKLY_CODINGS.equals(fhirCc)) {
            return VigorousWorkoutDurationInWeek;
        }
        else if (HeartValueSet.Common.Measurement.STRENGTH_PHYSICAL_ACTIVITY_SESSION_WEEKLY_CODINGS.equals(fhirCc)) {
            return WorkoutSessionInWeek;
        }
        else if (HeartValueSet.Common.Measurement.STEPS_CODINGS.equals(fhirCc)) {
            return StepCount;
        }
        else if (HeartValueSet.Common.Measurement.PHYSICAL_INABILITY_CODINGS.equals(fhirCc)) {
            return PhysicalInability;
        }
        else if (HeartValueSet.Common.Measurement.SUPERVISOR_REQUIRED_CODINGS.equals(fhirCc)) {
            return SupervisorRequired;
        }
        else if (HeartValueSet.Common.Measurement.MEAL_CODINGS.equals(fhirCc)) {
            return Meal;
        }
        else if (HeartValueSet.Common.Measurement.CALORIC_DAILY_INTAKE_CODINGS.equals(fhirCc)) {
            return CaloricDailyIntake;
        }
        else if (HeartValueSet.Common.Measurement.CARBOHYDRATES_DAILY_INTAKE_CODINGS.equals(fhirCc)) {
            return CarbohydratesDailyIntake;
        }
        else if (HeartValueSet.Common.Measurement.PROTEINS_DAILY_INTAKE_CODINGS.equals(fhirCc)) {
            return ProteinsDailyIntake;
        }
        else if (HeartValueSet.Common.Measurement.FATS_DAILY_INTAKE_CODINGS.equals(fhirCc)) {
            return FatsDailyIntake;
        }
        else if (HeartValueSet.Common.Measurement.FIBERS_DAILY_INTAKE_CODINGS.equals(fhirCc)) {
            return FibersDailyIntake;
        }
        else if (HeartValueSet.Common.Measurement.SODIUM_DAILY_INTAKE_CODINGS.equals(fhirCc)) {
            return SodiumDailyIntake;
        }
        else if (HeartValueSet.Common.Measurement.VEGETABLES_PORTIONS_DAILY_INTAKE_CODINGS.equals(fhirCc)) {
            return VegetablesPortionsDailyIntake;
        }
        else if (HeartValueSet.Common.Measurement.FRUIT_PORTIONS_DAILY_INTAKE_CODINGS.equals(fhirCc)) {
            return FruitPortionsDailyIntake;
        }
        else if (HeartValueSet.Common.Measurement.ALCOHOL_DAILY_INTAKE_CODINGS.equals(fhirCc)) {
            return AlcoholDrinkingFrequency;
        }
        else if (HeartValueSet.Common.Measurement.SUGARY_BEVERAGE_DAILY_INTAKE_CODINGS.equals(fhirCc)) {
            return SugaryBeverageDrinkingFrequency;
        }
        else if (HeartValueSet.Common.Measurement.CIGARETTES_DAILY_AMOUNT_CODINGS.equals(fhirCc)) {
            return SmokingFrequency;
        }
        else if (HeartValueSet.Common.Measurement.BLOOD_PRESSURE_CODINGS.equals(fhirCc)) {
            return undefined;
        }
        else if (HeartValueSet.Common.Measurement.SYSTOLIC_BLOOD_PRESSURE_CODINGS.equals(fhirCc)) {
            return SystolicBloodPressure;
        }
        else if (HeartValueSet.Common.Measurement.DIASTOLIC_BLOOD_PRESSURE_CODINGS.equals(fhirCc)) {
            return DiastolicBloodPressure;
        }
        else if (HeartValueSet.Common.Measurement.BLOOD_GLUCOSE_MOLES_CODINGS.equals(fhirCc)) {
            return BloodGlucose;
        }
        else if (HeartValueSet.Common.Measurement.BLOOD_GLUCOSE_MASS_CODINGS.equals(fhirCc)) {
            return BloodGlucose;
        }
        else if (HeartValueSet.Common.Measurement.HBA1C_CODINGS.equals(fhirCc)) {
            return Hba1c;
        }
        else if (HeartValueSet.Common.Measurement.SPO2_CODINGS.equals(fhirCc)) {
            return SpO2;
        }
        else if (HeartValueSet.Common.Measurement.CHOLESTEROL_CODINGS.equals(fhirCc)) {
            return Cholesterol;
        }
        else if (HeartValueSet.Common.Measurement.CHOLESTEROL_HDL_CODINGS.equals(fhirCc)) {
            return CholesterolHdl;
        }
        else if (HeartValueSet.Common.Measurement.CHOLESTEROL_LDL_CODINGS.equals(fhirCc)) {
            return CholesterolLdl;
        }
        else if (HeartValueSet.Common.Measurement.TRIGLYCERIDE_CODINGS.equals(fhirCc)) {
            return Triglyceride;
        }
        else if (HeartValueSet.Common.Measurement.LIFESTYLE_CODING.equals(fhirCc)) {
            return LifeStyle;
        }
        else if (HeartValueSet.Common.Measurement.PATIENT_HEALTH_STATUS_CODING.equals(fhirCc)) {
            return PatientHealthStatus;
        }
        else if (HeartValueSet.Common.Measurement.SMOKER_CODINGS.equals(fhirCc)) {
            return Smoker;
            // } else if ( HeartValueSet.Common.Goal.PHYSICAL_ACTIVITY_CODINGS.equals(fhirCc) ) {
        }
        else {
            return GenericQuantitativeMeasure;
        }
    }
    /**
     * Questo metodo: risolve il mapping verso FHIR dei vari tipo di misurazioni usabile come goal target
     */
    static fromDataModelTargetVariable(type) {
        switch (type) {
            case BMI:
                return HeartValueSet.Common.Measurement.BMI_CODINGS.toCodeableConcept();
            case Weight:
                return HeartValueSet.Common.Measurement.WEIGHT_CODINGS.toCodeableConcept();
            case Height:
                return HeartValueSet.Common.Measurement.HEIGHT_CODINGS.toCodeableConcept();
            case Waist:
                return HeartValueSet.Common.Measurement.WAIST_CODINGS.toCodeableConcept();
            case ModerateWorkoutDurationInWeek:
                return HeartValueSet.Common.Measurement.MODERATE_PHYSICAL_ACTIVITY_DURATION_WEEKLY_CODINGS.toCodeableConcept();
            case VigorousWorkoutDurationInWeek:
                return HeartValueSet.Common.Measurement.VIGOROUS_PHYSICAL_ACTIVITY_DURATION_WEEKLY_CODINGS.toCodeableConcept();
            case WorkoutSessionInWeek:
                return HeartValueSet.Common.Measurement.STRENGTH_PHYSICAL_ACTIVITY_SESSION_WEEKLY_CODINGS.toCodeableConcept();
            case StepCount:
                return HeartValueSet.Common.Measurement.STEPS_CODINGS.toCodeableConcept();
            case PhysicalInability:
                return HeartValueSet.Common.Measurement.PHYSICAL_INABILITY_CODINGS.toCodeableConcept();
            case SupervisorRequired:
                return HeartValueSet.Common.Measurement.SUPERVISOR_REQUIRED_CODINGS.toCodeableConcept();
            case CaloricDailyIntake:
                return HeartValueSet.Common.Measurement.CALORIC_DAILY_INTAKE_CODINGS.toCodeableConcept();
            case CarbohydratesDailyIntake:
                return HeartValueSet.Common.Measurement.CARBOHYDRATES_DAILY_INTAKE_CODINGS.toCodeableConcept();
            case ProteinsDailyIntake:
                return HeartValueSet.Common.Measurement.PROTEINS_DAILY_INTAKE_CODINGS.toCodeableConcept();
            case FatsDailyIntake:
                return HeartValueSet.Common.Measurement.FATS_DAILY_INTAKE_CODINGS.toCodeableConcept();
            case FibersDailyIntake:
                return HeartValueSet.Common.Measurement.FIBERS_DAILY_INTAKE_CODINGS.toCodeableConcept();
            case SodiumDailyIntake:
                return HeartValueSet.Common.Measurement.SODIUM_DAILY_INTAKE_CODINGS.toCodeableConcept();
            case VegetablesPortionsDailyIntake:
                return HeartValueSet.Common.Measurement.VEGETABLES_PORTIONS_DAILY_INTAKE_CODINGS.toCodeableConcept();
            case FruitPortionsDailyIntake:
                return HeartValueSet.Common.Measurement.FRUIT_PORTIONS_DAILY_INTAKE_CODINGS.toCodeableConcept();
            // TODO
            case SugaryBeverageDrinkingFrequency:
                return HeartValueSet.Common.Measurement.SUGARY_BEVERAGE_DAILY_INTAKE_CODINGS.toCodeableConcept();
            case AlcoholDrinkingFrequency:
                return HeartValueSet.Common.Measurement.ALCOHOL_DAILY_INTAKE_CODINGS.toCodeableConcept();
            case SmokingFrequency:
                return HeartValueSet.Common.Measurement.CIGARETTES_DAILY_AMOUNT_CODINGS.toCodeableConcept();
            // case  : return HeartValueSet.Common.Measurement.BLOOD_PRESSURE_CODINGS.toCodeableConcept();
            case SystolicBloodPressure:
                return HeartValueSet.Common.Measurement.SYSTOLIC_BLOOD_PRESSURE_CODINGS.toCodeableConcept();
            case DiastolicBloodPressure:
                return HeartValueSet.Common.Measurement.DIASTOLIC_BLOOD_PRESSURE_CODINGS.toCodeableConcept();
            case BloodGlucose:
                // const t : typeof BloodGlucose = type;
                // if (measurements.BloodGlucoseUnit.mmol === t.unit) {
                return HeartValueSet.Common.Measurement.BLOOD_GLUCOSE_MOLES_CODINGS.toCodeableConcept();
            // } else {
            //     return HeartValueSet.Common.Measurement.BLOOD_GLUCOSE_MASS_CODINGS.toCodeableConcept();
            // }
            case Hba1c:
                return HeartValueSet.Common.Measurement.HBA1C_CODINGS.toCodeableConcept();
            case SpO2:
                return HeartValueSet.Common.Measurement.SPO2_CODINGS.toCodeableConcept();
            case Cholesterol:
                return HeartValueSet.Common.Measurement.CHOLESTEROL_CODINGS.toCodeableConcept();
            case CholesterolHdl:
                return HeartValueSet.Common.Measurement.CHOLESTEROL_HDL_CODINGS.toCodeableConcept();
            case CholesterolLdl:
                return HeartValueSet.Common.Measurement.CHOLESTEROL_LDL_CODINGS.toCodeableConcept();
            case Triglyceride:
                return HeartValueSet.Common.Measurement.TRIGLYCERIDE_CODINGS.toCodeableConcept();
            case LifeStyle:
                return HeartValueSet.Common.Measurement.LIFESTYLE_CODING.toCodeableConcept();
            case PatientHealthStatus:
                return HeartValueSet.Common.Measurement.PATIENT_HEALTH_STATUS_CODING.toCodeableConcept();
            case Smoker:
                return HeartValueSet.Common.Measurement.SMOKER_CODINGS.toCodeableConcept();
            default:
                throw new TypeError(`Unsupported quantitative target type '${type}' in '#fromDataModelTargetVariable'. Error converting from datamodel to FHIR.`);
        }
    }
    /**
     * Questo metodo: risolve il mapping verso FHIR dei vari tipo di misurazioni usabile come goal target
     */
    static fromDataModelMeasureToValueset(measure) {
        if (measure instanceof BMI) {
            return HeartValueSet.Common.Measurement.BMI_CODINGS;
        }
        else if (measure instanceof Weight) {
            return HeartValueSet.Common.Measurement.WEIGHT_CODINGS;
        }
        else if (measure instanceof Height) {
            return HeartValueSet.Common.Measurement.HEIGHT_CODINGS;
        }
        else if (measure instanceof Waist) {
            return HeartValueSet.Common.Measurement.WAIST_CODINGS;
        }
        else if (measure instanceof ModerateWorkoutDurationInWeek) {
            return HeartValueSet.Common.Measurement
                .MODERATE_PHYSICAL_ACTIVITY_DURATION_WEEKLY_CODINGS;
        }
        else if (measure instanceof VigorousWorkoutDurationInWeek) {
            return HeartValueSet.Common.Measurement
                .VIGOROUS_PHYSICAL_ACTIVITY_DURATION_WEEKLY_CODINGS;
        }
        else if (measure instanceof WorkoutSessionInWeek) {
            return HeartValueSet.Common.Measurement
                .STRENGTH_PHYSICAL_ACTIVITY_SESSION_WEEKLY_CODINGS;
        }
        else if (measure instanceof HeartRate) {
            return HeartValueSet.Common.Measurement.HEART_RATE_RESTING_CODING;
        }
        else if (measure instanceof StepCount) {
            return HeartValueSet.Common.Measurement.STEPS_CODINGS;
        }
        else if (measure instanceof PhysicalInability) {
            return HeartValueSet.Common.Measurement.PHYSICAL_INABILITY_CODINGS;
        }
        else if (measure instanceof SupervisorRequired) {
            return HeartValueSet.Common.Measurement.SUPERVISOR_REQUIRED_CODINGS;
        }
        else if (measure instanceof Meal) {
            return HeartValueSet.Common.Measurement.MEAL_CODINGS;
        }
        else if (measure instanceof CaloricDailyIntake) {
            return HeartValueSet.Common.Measurement.CALORIC_DAILY_INTAKE_CODINGS;
        }
        else if (measure instanceof CarbohydratesDailyIntake) {
            return HeartValueSet.Common.Measurement
                .CARBOHYDRATES_DAILY_INTAKE_CODINGS;
        }
        else if (measure instanceof ProteinsDailyIntake) {
            return HeartValueSet.Common.Measurement.PROTEINS_DAILY_INTAKE_CODINGS;
        }
        else if (measure instanceof FatsDailyIntake) {
            return HeartValueSet.Common.Measurement.FATS_DAILY_INTAKE_CODINGS;
        }
        else if (measure instanceof FibersDailyIntake) {
            return HeartValueSet.Common.Measurement.FIBERS_DAILY_INTAKE_CODINGS;
        }
        else if (measure instanceof SodiumDailyIntake) {
            return HeartValueSet.Common.Measurement.SODIUM_DAILY_INTAKE_CODINGS;
        }
        else if (measure instanceof VegetablesPortionsDailyIntake) {
            return HeartValueSet.Common.Measurement
                .VEGETABLES_PORTIONS_DAILY_INTAKE_CODINGS;
        }
        else if (measure instanceof FruitPortionsDailyIntake) {
            return HeartValueSet.Common.Measurement
                .FRUIT_PORTIONS_DAILY_INTAKE_CODINGS;
            // TODO
        }
        else if (measure instanceof SugaryBeverageDrinkingFrequency) {
            return HeartValueSet.Common.Measurement
                .SUGARY_BEVERAGE_DAILY_INTAKE_CODINGS;
        }
        else if (measure instanceof AlcoholDrinkingFrequency) {
            return HeartValueSet.Common.Measurement.ALCOHOL_DAILY_INTAKE_CODINGS;
        }
        else if (measure instanceof SmokingFrequency) {
            return HeartValueSet.Common.Measurement.CIGARETTES_DAILY_AMOUNT_CODINGS;
            // } else if( obj instanceof   ) { return HeartValueSet.Common.Measurement.BLOOD_PRESSURE_CODINGS;
        }
        else if (measure instanceof SystolicBloodPressure) {
            return HeartValueSet.Common.Measurement.SYSTOLIC_BLOOD_PRESSURE_CODINGS;
        }
        else if (measure instanceof DiastolicBloodPressure) {
            return HeartValueSet.Common.Measurement.DIASTOLIC_BLOOD_PRESSURE_CODINGS;
        }
        else if (measure instanceof BloodPressure) {
            return HeartValueSet.Common.Measurement.BLOOD_PRESSURE_CODINGS;
        }
        else if (measure instanceof BloodGlucose) {
            // const t  ) { typeof BloodGlucose = type;
            // if (measurements.BloodGlucoseUnit.mmol === t.unit) {
            return HeartValueSet.Common.Measurement.BLOOD_GLUCOSE_MOLES_CODINGS;
            // } else {
            //     return HeartValueSet.Common.Measurement.BLOOD_GLUCOSE_MASS_CODINGS;
            // }
        }
        else if (measure instanceof Hba1c) {
            return HeartValueSet.Common.Measurement.HBA1C_CODINGS;
        }
        else if (measure instanceof Cholesterol) {
            return HeartValueSet.Common.Measurement.CHOLESTEROL_CODINGS;
        }
        else if (measure instanceof CholesterolHdl) {
            return HeartValueSet.Common.Measurement.CHOLESTEROL_HDL_CODINGS;
        }
        else if (measure instanceof CholesterolLdl) {
            return HeartValueSet.Common.Measurement.CHOLESTEROL_LDL_CODINGS;
        }
        else if (measure instanceof Triglyceride) {
            return HeartValueSet.Common.Measurement.TRIGLYCERIDE_CODINGS;
        }
        else if (measure instanceof LifeStyle) {
            return HeartValueSet.Common.Measurement.LIFESTYLE_CODING;
        }
        else if (measure instanceof PatientHealthStatus) {
            return HeartValueSet.Common.Measurement.PATIENT_HEALTH_STATUS_CODING;
        }
        else if (measure instanceof Smoker) {
            return HeartValueSet.Common.Measurement.SMOKER_CODINGS;
        }
        else if (measure instanceof ChestPainLevel) {
            return HeartValueSet.Common.Measurement.CHEST_PAIN_CODINGS;
        }
        else if (measure instanceof ChestPainQuestionnaire) {
            return HeartValueSet.Common.Measurement.CHEST_PAIN_QUESTIONNAIRE;
        }
        else {
            throw new TypeError(`Unsupported type '${measure}' in '#fromDataModelMeasureToValueset'. Error converting from datamodel to Valueset.`);
        }
    }
    static getMeasureClassName(measure) {
        if (measure instanceof Weight) {
            return 'Weight';
        }
        else if (measure instanceof Height) {
            return 'Height';
        }
        else if (measure instanceof Waist) {
            return 'Waist';
        }
        else if (measure instanceof BMI) {
            return 'BMI';
        }
        else if (measure instanceof SupervisorRequired) {
            return 'SupervisorRequired';
        }
        else if (measure instanceof PhysicalInability) {
            return 'PhysicalInability';
        }
        else if (measure instanceof StepCount) {
            return 'StepCount';
        }
        else if (measure instanceof Smoker) {
            return 'Smoker';
        }
        else if (measure instanceof LifeStyle) {
            return 'LifeStyle';
        }
        else if (measure instanceof Hba1c) {
            return 'Hba1c';
        }
        else if (measure instanceof SpO2) {
            return 'SpO2';
        }
        else if (measure instanceof Cholesterol) {
            return 'Cholesterol';
        }
        else if (measure instanceof CholesterolLdl) {
            return 'CholesterolLdl';
        }
        else if (measure instanceof CholesterolHdl) {
            return 'CholesterolHdl';
        }
        else if (measure instanceof Triglyceride) {
            return 'Triglyceride';
        }
        else if (measure instanceof BloodPressure) {
            return 'BloodPressure';
        }
        else if (measure instanceof BloodGlucose) {
            return 'BloodGlucose';
        }
        else if (measure instanceof DiastolicBloodPressure) {
            return 'DiastolicBloodPressure';
        }
        else if (measure instanceof SystolicBloodPressure) {
            return 'SystolicBloodPressure';
        }
        else if (measure instanceof HeartRate) {
            return 'HeartRate';
        }
        else if (measure instanceof FatsDailyIntake) {
            return 'FatsDailyIntake';
        }
        else if (measure instanceof FibersDailyIntake) {
            return 'FibersDailyIntake';
        }
        else if (measure instanceof SodiumDailyIntake) {
            return 'SodiumDailyIntake';
        }
        else if (measure instanceof ProteinsDailyIntake) {
            return 'ProteinsDailyIntake';
        }
        else if (measure instanceof CarbohydratesDailyIntake) {
            return 'CarbohydratesDailyIntake';
        }
        else if (measure instanceof CaloricDailyIntake) {
            return 'CaloricDailyIntake';
        }
        else if (measure instanceof BodyTemperature) {
            return 'BodyTemperature';
        }
        else if (measure instanceof ChestPainLevel) {
            return 'ChestPainLevel';
        }
        else if (measure instanceof ChestPainQuestionnaire) {
            return 'ChestPainQuestionnaire';
        }
        else if (measure instanceof SmokingFrequency) {
            return 'SmokingFrequency';
        }
        else if (measure instanceof TTM) {
            return 'TTM';
        }
        else if (measure instanceof PatientHealthStatus) {
            return 'PatientHealthStatus';
        }
        else if (measure instanceof COVIDSymptoms) {
            return 'COVIDSymptoms';
        }
        else {
            throw new Error('FhirCodesMapperUtils#getMeasureClassName: Error unsupported class type');
        }
    }
    static RiskProbabilityToFHIR(level) {
        switch (level) {
            case RiskLevel.NEGLIGIBLE:
                return HeartValueSet.Risk.NEGLIGIBLE.toCodeableConcept();
            case RiskLevel.LOW:
                return HeartValueSet.Risk.LOW.toCodeableConcept();
            case RiskLevel.MODERATE:
                return HeartValueSet.Risk.MODERATE.toCodeableConcept();
            case RiskLevel.HIGH:
                return HeartValueSet.Risk.HIGH.toCodeableConcept();
            case RiskLevel.CERTAIN:
                return HeartValueSet.Risk.CERTAIN.toCodeableConcept();
        }
    }
    static RiskProbabilityFromFHIR(fLevel) {
        if (HeartValueSet.Risk.NEGLIGIBLE.equals(fLevel))
            return RiskLevel.NEGLIGIBLE;
        if (HeartValueSet.Risk.LOW.equals(fLevel))
            return RiskLevel.LOW;
        if (HeartValueSet.Risk.MODERATE.equals(fLevel))
            return RiskLevel.MODERATE;
        if (HeartValueSet.Risk.HIGH.equals(fLevel))
            return RiskLevel.HIGH;
        if (HeartValueSet.Risk.CERTAIN.equals(fLevel))
            return RiskLevel.CERTAIN;
        return undefined;
    }
}

class FhirHeartUtils {
    /**
     * Find the extension declared by a HeartExtension object in a FHIR item
     * @param extensions - a FHIR Extension array
     * @param extension - the extension definition
     * @returns null if the extension is not found
     */
    static findExtension(extensions, extension) {
        return extensions?.find((item) => {
            return item.url === extension.url;
        });
    }
}

class FhirUtils {
    static createCodeableConcept(system, code, display, text) {
        const codeableConcept = new CodeableConcept();
        const coding = new Coding();
        coding.system = system;
        coding.code = code;
        coding.display = display;
        codeableConcept.coding = [coding];
        codeableConcept.text = text;
        return codeableConcept;
    }
    static createCodeableConceptWithOnlyText(text) {
        const codeableConcept = new CodeableConcept();
        codeableConcept.text = text;
        return codeableConcept;
    }
    static createExtension(url, value) {
        const extension = new Extension();
        extension.url = url;
        extension.value = value;
        return extension;
    }
    static createExtensionCodeableConcept(url, value) {
        const extension = new Extension();
        extension.url = url;
        extension.value = value;
        return extension;
    }
    static createExtensionResource(url, value) {
        const extension = new Extension();
        extension.url = url;
        extension.value = value.getReference();
        return extension;
    }
    static createExtensionString(url, value) {
        const extension = new Extension();
        extension.url = url;
        extension.value = value;
        return extension;
    }
    static createExtensionBoolean(url, value) {
        const extension = new Extension();
        extension.url = url;
        extension.value = value;
        return extension;
    }
    static createExtensionNumber(url, value) {
        const extension = new Extension();
        extension.url = url;
        extension.value = value;
        return extension;
    }
    static createExtensionDate(url, value) {
        const extension = new Extension();
        extension.url = url;
        extension.value = value;
        return extension;
    }
    static createExtensionQuantity(url, value) {
        const extension = new Extension();
        extension.url = url;
        extension.value = value;
        return extension;
    }
    static createExtensionAddress(url, value) {
        const extension = new Extension();
        extension.url = url;
        extension.value = value;
        return extension;
    }
    static createExtensionReference(url, value) {
        const extension = new Extension();
        extension.url = url;
        extension.value = value;
        return extension;
    }
    static createAnnotation(note, hcp) {
        const annotation = new Annotation();
        annotation.text = note;
        annotation.author = hcp;
        return annotation;
    }
    // public static createRelatedAction(
    //   actionId: string
    // ): RequestGroup.RequestGroupActionRelatedActionComponent {
    //   const relatedAction =
    //     new RequestGroup.RequestGroupActionRelatedActionComponent();
    //   relatedAction.actionId = actionId;
    //   relatedAction.relationship = 'after-end';
    //   return relatedAction;
    // }
    static createTimingMax(duration, unit) {
        const timing = new Timing();
        const repeat = new Timing.TimingRepeatComponent();
        repeat.duration = 0;
        repeat.durationMax = duration;
        repeat.durationUnit = unit;
        timing.repeat = repeat;
        return timing;
    }
    static createPeriodStartEnd(start, end) {
        const period = new Period();
        period.start = start;
        period.end = end;
        return period;
    }
    static createIdentifier(system, value) {
        const identifier = new Identifier$1();
        identifier.system = system;
        identifier.value = value;
        return identifier;
    }
    static filterIdentifierBySystem(identifiers, system) {
        return identifiers?.filter((i) => i.system === system).pop();
    }
    static filterIdentifierByTypeSystem(identifiers, typeSystem) {
        return identifiers
            ?.filter((i) => i.type)
            .filter((i) => i.type.coding.some((c) => c.system === typeSystem))
            .pop();
    }
    static createQuantity(value, system, code, unit) {
        const quantity = new Quantity();
        quantity.value = value;
        quantity.system = system;
        quantity.code = code;
        quantity.unit = unit;
        return quantity;
    }
    /**
     * Use in this way:
     * <code> DemoData.createRandomSeries(0, 70, 30).join(' ');</code>
     *
     * @param min - included
     * @param max - included
     * @param samples - amount of samples in the series
     */
    static createRandomSeries(min = 0, max = 100, samples = 50) {
        const series = [];
        let random;
        for (let i = 0; i < samples; i++) {
            random = Math.floor(Math.random() * (max - min + 1) + min);
            series.push(random + '');
        }
        return series;
    }
    /**
     * Create RelatedPerson
     *
     * @param patient - Patient who the RelatedPerson is related to
     * @param relationship - The type of the relationShip
     * @param name - Name of the related person
     *
     */
    static createRelationshipCode(relationship) {
        return FhirUtils.createCodeableConcept(Dictionary.FHIR_VALUE_SET_URI + 'relatedperson-relationshiptype', relationship.code, relationship.display);
    }
    static createCommunicationLocale(locale) {
        return FhirUtils.createCodeableConcept('http://hl7.org/fhir/ValueSet/languages', locale.toString(), locale.toString());
    }
    static createHumanName(firstName, lastName) {
        // name and family
        if ((!!firstName && firstName != '') || (!!lastName && lastName != '')) {
            const humanName = new HumanName();
            if (firstName) {
                humanName.given = [firstName];
            }
            humanName.family = lastName;
            return [humanName];
        }
        return undefined;
    }
    /**
     * Create a bundle of type collection for all the specified FHIR resources
     * @param fhirResources
     * @returns
     */
    static createBundleCollection(fhirResources) {
        const bundle = new Bundle();
        bundle.type = 'collection';
        bundle.entry = fhirResources?.map((fr) => {
            const bec = new Bundle.BundleEntryComponent();
            bec.resource = fr;
            return bec;
        });
        return bundle;
    }
    static fromDataModelEncounterType(type) {
        switch (type) {
            case EncounterType.ANNUAL_SCREENING:
                return FhirUtils.createCodeableConcept(Dictionary.UHM_CODE_SYSTEM_URI + 'encounter-type', 'AS', 'annual screening');
            case EncounterType.SCHOOL_CHECK:
                return FhirUtils.createCodeableConcept(Dictionary.UHM_CODE_SYSTEM_URI + 'encounter-type', 'SS', 'school check');
            case EncounterType.PREVENTION_CAMPAIGN:
                return FhirUtils.createCodeableConcept(Dictionary.UHM_CODE_SYSTEM_URI + 'encounter-type', 'PC', 'prevention campaign');
            case EncounterType.FIRST_ENCOUNTER:
                return FhirUtils.createCodeableConcept(Dictionary.UHM_CODE_SYSTEM_URI + 'encounter-type', 'FE', 'first encounter');
            case EncounterType.OTHER:
                return FhirUtils.createCodeableConcept(Dictionary.UHM_CODE_SYSTEM_URI + 'encounter-type', 'OTH', 'other');
            default:
                return undefined;
        }
    }
    static toDataModelEncounterType(type) {
        const tc = type?.coding[0];
        if (tc?.code == 'AS') {
            return EncounterType.ANNUAL_SCREENING;
        }
        else if (tc?.code == 'SS') {
            return EncounterType.SCHOOL_CHECK;
        }
        else if (tc?.code == 'PC') {
            return EncounterType.PREVENTION_CAMPAIGN;
        }
        else if (tc?.code == 'FE') {
            return EncounterType.FIRST_ENCOUNTER;
        }
        else {
            return EncounterType.OTHER;
        }
    }
    static fromDataModelEncounterQuestionnaire(type) {
        switch (type) {
            case EncounterQuestionnaire.FAMILY_ANAMNESIS:
                return Dictionary.BASE_NAMESPACE + '/Questionnaire/rare-disease-family-history';
            case EncounterQuestionnaire.PATIENT_PHYSIOLOGICAL_HISTORY:
                return Dictionary.BASE_NAMESPACE + '/Questionnaire/rare-disease-patient-physiological-history';
            case EncounterQuestionnaire.PATIENT_SHORT_TERM_HISTORY:
                return Dictionary.BASE_NAMESPACE + '/Questionnaire/rare-disease-patient-short-term-pathological-history';
            case EncounterQuestionnaire.REMOTE_ANAMNESIS:
                return Dictionary.BASE_NAMESPACE + '/Questionnaire/rare-disease-patient-long-term-pathological-history';
            case EncounterQuestionnaire.HEALTH_HISTORY:
                return Dictionary.BASE_NAMESPACE + '/Questionnaire/prevention-patient-health-history';
            case EncounterQuestionnaire.LIFESTYLE:
                return Dictionary.BASE_NAMESPACE + '/Questionnaire/prevention-patient-lifestyle';
            default:
                return undefined;
        }
    }
    static toDataModelEncounterQuestionnaire(type) {
        if (type.endsWith('/Questionnaire/rare-disease-family-history'))
            return EncounterQuestionnaire.FAMILY_ANAMNESIS;
        if (type.endsWith('/Questionnaire/rare-disease-patient-physiological-history'))
            return EncounterQuestionnaire.PATIENT_PHYSIOLOGICAL_HISTORY;
        if (type.endsWith('/Questionnaire/rare-disease-patient-short-term-pathological-history'))
            return EncounterQuestionnaire.PATIENT_SHORT_TERM_HISTORY;
        if (type.endsWith('/Questionnaire/rare-disease-patient-long-term-pathological-history'))
            return EncounterQuestionnaire.REMOTE_ANAMNESIS;
        if (type.endsWith('/Questionnaire/prevention-patient-health-history'))
            return EncounterQuestionnaire.HEALTH_HISTORY;
        if (type.endsWith('/Questionnaire/prevention-patient-lifestyle'))
            return EncounterQuestionnaire.LIFESTYLE;
        return EncounterQuestionnaire.OTHER;
    }
}

class TargetUtils {
    static fromDataModelTarget(target) {
        if (target instanceof CategoryTarget) {
            return this.fromDataModelCategoryTarget(target);
        }
        else if (target instanceof QuantitativeTarget) {
            return this.fromDataModelQuantitativeTarget(target);
        }
        else if (target instanceof RangeTarget) {
            return this.fromDataModelRangeTarget(target);
        }
        else {
            throw new TypeError(`Unsupported target type '${target.constructor.name}'. Error converting from datamodel to FHIR.`);
        }
    }
    static fromDataModelTargetDefinition(target) {
        if (target instanceof CategoryTarget) {
            return this.fromDataModelCategoryTargetDef(target);
        }
        else if (target instanceof QuantitativeTarget) {
            return this.fromDataModelQuantitativeTargetDef(target);
        }
        else if (target instanceof RangeTarget) {
            return this.fromDataModelRangeTargetDef(target);
        }
        else {
            throw new TypeError(`Unsupported target type '${target.constructor.name}'. Error converting from datamodel to FHIR.`);
        }
    }
    static fromDataModelQuantitativeTarget(target) {
        const fhirTarget = new Goal$1.GoalTargetComponent();
        // Convert the target type
        if (target.targetCode) {
            fhirTarget.measure = ModelToFHIRUtils.fromCodedValueModel(target.targetCode);
        }
        else if (target.targetVariable) {
            fhirTarget.measure = FhirCodesMapperUtils.fromDataModelTargetVariable(target.targetVariable);
        }
        else {
            console.log(`[WARN] FhirConverter#fromDataModelQuantitativeTarget: no target variable for target ${target}`);
        }
        // Convert the target quantity
        const quantity = this.fromDataModelQuantity(target);
        fhirTarget.detail = quantity;
        return fhirTarget;
    }
    static fromDataModelCategoryTarget(target) {
        const fhirTarget = new Goal$1.GoalTargetComponent();
        // Convert the target type
        if (target.targetCode) {
            fhirTarget.measure = ModelToFHIRUtils.fromCodedValueModel(target.targetCode);
        }
        else if (target.targetVariable) {
            fhirTarget.measure = TargetUtils.fromDataModelCategory(target);
        }
        else {
            console.log(`[WARN] FhirConverter#fromDataModelQuantitativeTarget: no target variable for target ${target}`);
        }
        if (target.thresholdValue) {
            fhirTarget.detail = FhirUtils.createCodeableConcept(Dictionary.BASE_NAMESPACE, target.thresholdValue?.toString(), target.thresholdValue?.toString());
        }
        return fhirTarget;
    }
    static fromDataModelRangeTarget(target) {
        const fhirTarget = new Goal$1.GoalTargetComponent();
        // Convert the target type
        if (target.targetCode) {
            fhirTarget.measure = ModelToFHIRUtils.fromCodedValueModel(target.targetCode);
        }
        else if (target.targetVariable) {
            fhirTarget.measure = FhirCodesMapperUtils.fromDataModelTargetVariable(target.targetVariable);
        }
        else {
            console.log(`[WARN] FhirConverter#fromDataModelQuantitativeTarget: no target variable for target ${target}`);
        }
        // Convert the target quantity
        const range = TargetUtils.fromDataModelRange(target);
        fhirTarget.detail = range;
        return fhirTarget;
    }
    static fromDataModelQuantitativeTargetDef(target) {
        const fhirTarget = new PlanDefinition$1.PlanDefinitionGoalTargetComponent();
        // Convert the target type
        // Convert the target type
        if (target.targetCode) {
            fhirTarget.measure = ModelToFHIRUtils.fromCodedValueModel(target.targetCode);
        }
        else if (target.targetVariable) {
            fhirTarget.measure = FhirCodesMapperUtils.fromDataModelTargetVariable(target.targetVariable);
        }
        else {
            console.log(`[WARN] FhirConverter#fromDataModelQuantitativeTarget: no target variable for target ${target}`);
        }
        // Convert the target quantity
        const quantity = this.fromDataModelQuantity(target);
        fhirTarget.detail = quantity;
        return fhirTarget;
    }
    static fromDataModelRangeTargetDef(target) {
        const fhirTarget = new PlanDefinition$1.PlanDefinitionGoalTargetComponent();
        // Convert the target type
        if (target.targetCode) {
            fhirTarget.measure = ModelToFHIRUtils.fromCodedValueModel(target.targetCode);
        }
        else if (target.targetVariable) {
            fhirTarget.measure = FhirCodesMapperUtils.fromDataModelTargetVariable(target.targetVariable);
        }
        else {
            console.log(`[WARN] FhirConverter#fromDataModelQuantitativeTarget: no target variable for target ${target}`);
        }
        // Convert the target quantity
        const range = TargetUtils.fromDataModelRange(target);
        fhirTarget.detail = range;
        return fhirTarget;
    }
    static fromDataModelCategoryTargetDef(target) {
        const fhirTarget = new PlanDefinition$1.PlanDefinitionGoalTargetComponent();
        // Convert the target type
        if (target.targetCode) {
            fhirTarget.measure = ModelToFHIRUtils.fromCodedValueModel(target.targetCode);
        }
        else if (target.targetVariable) {
            fhirTarget.measure = TargetUtils.fromDataModelCategory(target);
        }
        else {
            console.log(`[WARN] FhirConverter#fromDataModelQuantitativeTarget: no target variable for target ${target}`);
        }
        if (target.thresholdValue) {
            fhirTarget.detail = FhirUtils.createCodeableConcept(Dictionary.BASE_NAMESPACE, target.thresholdValue?.toString(), target.thresholdValue?.toString());
        }
        else {
            throw new TypeError(`Unsupported target type 'CategoryTarget' ${target.targetVariable}. Error converting from datamodel to FHIR.`);
        }
        return fhirTarget;
    }
    static fromDataModelRange(target) {
        // Convert the target quantity
        const range = new Range();
        // both minValue and maxValue must be valorized
        range.high = new SimpleQuantity();
        range.high.system = target.maxThresholdValue.system;
        range.high.unit = target.maxThresholdValue.unit;
        range.high.value = target.maxThresholdValue.magnitude;
        range.low = new SimpleQuantity();
        range.low.system = target.minThresholdValue.system;
        range.low.unit = target.minThresholdValue.unit;
        range.low.value = target.minThresholdValue.magnitude;
        return range;
    }
    static fromDataModelQuantity(target) {
        const quantity = new Quantity();
        quantity.system = target.thresholdValue.system;
        quantity.unit = target.thresholdValue.unit;
        quantity.value = target.thresholdValue.magnitude;
        switch (target.operator) {
            case QuantitativeTarget.RelationalOperator.GE:
                quantity.comparator = Quantity.QuantityComparator.GREATER_OR_EQUAL.toString();
                break;
            case QuantitativeTarget.RelationalOperator.GT:
                quantity.comparator = Quantity.QuantityComparator.GREATER_THAN.toString();
                break;
            case QuantitativeTarget.RelationalOperator.LE:
                quantity.comparator = Quantity.QuantityComparator.LESS_OR_EQUAL.toString();
                break;
            case QuantitativeTarget.RelationalOperator.LT:
                quantity.comparator = Quantity.QuantityComparator.LESS_THAN.toString();
                break;
            default:
            case QuantitativeTarget.RelationalOperator.EQ:
                /* quantity.comparator = FhirQuantity.QuantityComparator.NULL; */ break;
        }
        return quantity;
    }
    static fromDataModelCategory(target) {
        let fhirCc;
        // Convert the target type
        const type = target.targetVariable;
        switch (type) {
            // case measurements.LifeStyle : fhirCc = HeartValueSet.Common.Goal.; break;
            case SmokingFrequency:
                fhirCc = HeartValueSet.Common.Measurement.CIGARETTES_DAILY_AMOUNT_CODINGS.toCodeableConcept();
                break;
            case AlcoholDrinkingFrequency:
                fhirCc = HeartValueSet.Common.Measurement.ALCOHOL_DAILY_INTAKE_CODINGS.toCodeableConcept();
                break;
            case SugaryBeverageDrinkingFrequency:
                fhirCc = HeartValueSet.Common.Measurement.SUGARY_BEVERAGE_DAILY_INTAKE_CODINGS.toCodeableConcept();
                break;
            default:
                throw new TypeError(`Unsupported category target type '${type}'. Error converting from datamodel to FHIR.`);
        }
        return fhirCc;
    }
    static toDataModelTarget(fTarget, context) {
        // Analyze the target quantity
        const detail = fTarget.detail;
        let target;
        // il codice seguente dovrebbe capire il tipo di target sulla base del 'codice' usato per la misura
        if (detail instanceof Quantity || typeof detail == 'number') {
            target = this.toDataModelQuantitativeTarget(fTarget, context);
        }
        else if (detail instanceof Range) {
            target = this.toDataModelRangeTarget(fTarget, context);
        }
        else if (detail instanceof CodeableConcept) {
            target = this.toDataModelCategoryTarget(fTarget, context);
        }
        if (!target) {
            console.log(`Unsupported target type ${fTarget} with detail '${JSON.stringify(detail)}'. Error converting to datamodel from FHIR.`);
        }
        else {
            target.targetCode = ModelToFHIRUtils.toCodedValueModel(fTarget.measure);
        }
        return target;
    }
    static toDataModelQuantitativeTarget(fTarget, context) {
        // Analyze the target quantity
        const qt = new QuantitativeTarget();
        const detail = fTarget.detail;
        // convert threshold
        qt.thresholdValue = new TargetQuantity(detail.value, detail.unit, detail.system);
        // operator
        switch (detail.comparator) {
            case Quantity.QuantityComparator.GREATER_OR_EQUAL.toString():
                qt.operator = QuantitativeTarget.RelationalOperator.GE;
                break;
            case Quantity.QuantityComparator.GREATER_THAN.toString():
                qt.operator = QuantitativeTarget.RelationalOperator.GT;
                break;
            case Quantity.QuantityComparator.LESS_OR_EQUAL.toString():
                qt.operator = QuantitativeTarget.RelationalOperator.LE;
                break;
            case Quantity.QuantityComparator.LESS_THAN.toString():
                qt.operator = QuantitativeTarget.RelationalOperator.LT;
                break;
            default:
            case Quantity.QuantityComparator.NULL.toString():
                qt.operator = QuantitativeTarget.RelationalOperator.EQ;
                break;
        }
        // Convert the target type
        qt.targetVariable = FhirCodesMapperUtils.toDataModelTargetVariable(fTarget.measure);
        if (!qt.targetVariable) {
            return undefined;
        }
        return qt;
    }
    static toDataModelRangeTarget(fTarget, context) {
        // Analyze the target quantity
        const detail = fTarget.detail;
        const qt = new RangeTarget();
        // Convert the target type
        qt.targetVariable = FhirCodesMapperUtils.toDataModelTargetVariable(fTarget.measure);
        if (!qt.targetVariable) {
            return undefined;
        }
        qt.maxThresholdValue = new TargetQuantity(detail.high.value, detail.high.unit, detail.high.system);
        qt.minThresholdValue = new TargetQuantity(detail.low.value, detail.low.unit, detail.low.system);
        return qt;
    }
    static toDataModelCategoryTarget(fTarget, context) {
        // Analyze the target quantity
        const detail = fTarget.detail;
        const ct = new CategoryTarget();
        // Convert the target type
        ct.targetVariable = FhirCodesMapperUtils.toDataModelTargetVariable(fTarget.measure);
        if (!ct.targetVariable) {
            return undefined;
        }
        // convert threshold
        // set the value of the enum
        ct.thresholdValue = detail ? detail.coding[0].code : undefined;
        return ct;
    }
}

class KinshipConverterUtils {
    static createFhirResourcesToPersist(enrichedPatient, subsetOfRelativeToCreate, alreadyPersistedPerson) {
        // 0 - create the "Person" (for the patient)
        // 1 - create the link array and set
        //      [0] the reference to the patient
        // for each relative present in the patient object
        // a - create the RelatedPerson
        //  set the relative relationship code
        //  set the relative's  identifier as Patient
        //  and persist it
        // b - retrieve the fhirId OR anyway get the Reference of the RelatedPerson
        // c - add the link to the just created RelatedPerson in the patient with the value or the RelatedPerson Reference
        // finally - persist the Person
        if (enrichedPatient && enrichedPatient.relatives?.length > 0) {
            const fPerson = alreadyPersistedPerson ?? new Person();
            const relatedPersons = [];
            // fPerson.link = []
            const patientLinkComp = new Person.PersonLinkComponent();
            patientLinkComp.target = ModelToFHIRUtils.getReference(enrichedPatient);
            if (fPerson.link?.[0].target?.reference != patientLinkComp?.target?.reference) {
                if (!fPerson.link) {
                    fPerson.link = [];
                }
                fPerson.link.push(patientLinkComp);
            }
            // let kinshipsToConvert = (subsetOfRelativeToCreate.length > 0) ? subsetOfRelativeToCreate : enrichedPatient.relatives;
            let kinshipsToConvert = enrichedPatient.relatives;
            // enrichedPatient.relatives.forEach((k : Kinship) => {
            kinshipsToConvert.forEach((k) => {
                const rp = new RelatedPerson();
                rp.patient = ModelToFHIRUtils.getReference(k.relative);
                // rp.identifier = //TODO do we have an identifier to set here specific for the project?
                rp.relationship = [FhirUtils.createCodeableConcept(k.relationship.system, k.relationship.code, k.relationship.display)];
                relatedPersons.push(rp);
            });
            return new FhirKinship(relatedPersons, fPerson);
        }
        return undefined;
    }
    static addRelatedPersonLink(fhirKinship, frp) {
        if (fhirKinship?.person?.link?.length > 0) { // the first should be always the patient
            const relativeLink = new Person.PersonLinkComponent();
            relativeLink.target = frp.getReference();
            fhirKinship?.person?.link.push(relativeLink);
        }
        return fhirKinship;
    }
}
class FhirKinship {
    constructor(relatedPersons, person) {
        this.relatedPersons = relatedPersons;
        this.person = person;
    }
}

// tslint:disable: max-line-length no-inferrable-types no-redundant-jsdoc
class AppointmentFhirConverter extends AbstractFhirConverter {
    toDataModel(resource, context) {
        return this.toDataModelAppointment(resource, context);
    }
    fromDataModel(model) {
        if (model instanceof Appointment) {
            return this.fromDataModelAppointment(model);
        }
        else {
            throw new TypeError('Unsupported model type. Error converting from datamodel to FHIR.');
        }
    }
    // Patient ed EpisodeOfCare sono necessari per la memorizzazione dell'appointment - ad oggi
    // TODO: verificare l'allineamento con UHM - vedi SHE #1137 #1171
    fromDataModelAppointment(model) {
        const fhir = new Appointment$1();
        fhir.id = !!model.id ? model.id + '' : undefined;
        if (model.patient) {
            fhir.subject = ModelToFHIRUtils.getReference(model.patient);
        }
        if (model.type) {
            fhir.appointmentType = FhirUtils.fromDataModelEncounterType(model.type);
        }
        if (model.status) {
            fhir.status = model.status.toString();
        }
        if (model.participant) {
            fhir.participant = [];
            let participantItem = new Appointment$1.AppointmentParticipantComponent();
            participantItem.actor = ModelToFHIRUtils.getReference(model.participant);
            participantItem.status = 'accepted';
            fhir.participant.push(participantItem);
        }
        if (model.note) {
            fhir.note = [FhirUtils.createAnnotation(model.note)];
        }
        fhir.start = model.start;
        fhir.end = model.end;
        return fhir;
    }
    toDataModelAppointment(fhir, context) {
        // in questo bundle ci saranno anche i questionnaireresponse (di tutti gli appointment, non solo di questo che stiamo convertendo) e tutti gli altri (che ora non sappiamo)
        const model = new Appointment();
        model.id = +fhir.id;
        if (fhir.subject) {
            model.patient = ModelToFHIRUtils.stubFromRef(fhir.subject, 'Patient');
        }
        if (fhir.participant?.length > 0) {
            model.participant = fhir.participant[0].actor ? ModelToFHIRUtils.stubFromRef(fhir.participant[0].actor, 'Practitioner') : undefined;
        }
        model.start = fhir.start;
        model.end = fhir.end;
        model.type = FhirUtils.toDataModelEncounterType(fhir.appointmentType);
        model.status = AppointmentStatus.convertFromString(fhir.status);
        if (fhir.note?.length > 0) {
            model.note = fhir.note[0].text;
        }
        return model;
    }
}

// tslint:disable: max-line-length no-inferrable-types no-redundant-jsdoc
class CareGiverFhirConverter extends AbstractFhirConverter {
    toDataModel(resource, context) {
        const model = new CareGiver(+resource.id);
        model.patient = ModelToFHIRUtils.stubFromRef(resource.patient, 'Patient');
        // name and family
        if (resource.name?.length > 0) {
            model.firstName = resource.name[0]?.given[0];
            model.lastName = resource.name[0]?.family;
        }
        model.relationship = resource.relationship?.length > 0 ? ModelToFHIRUtils.toCodedValueModel(resource.relationship[0]) : undefined;
        const modelReference = ModelToFHIRUtils.getReference(model);
        // converti i questionnaire responses di interesse tramite il loro convertitore ed aggangialo all'encounter
        const alias = context?.entry
            ?.filter((i) => i.resource.resourceType == 'Patient')
            .filter((i) => (i.resource.link?.length > 0 && i.resource.link[0].other)?.reference == modelReference?.reference)
            .map((entry) => this.service.person.toDataModel(entry.resource, context));
        // codice del questionnaire response da recuperare dall'URL quello usato dalla UI per recuperare il questionario dal server.
        if (alias && alias.length > 0) {
            model.alias = alias[0];
        }
        if (resource.birthDate) {
            model.birthDate = resource.birthDate;
        }
        if (resource.gender) {
            model.gender = this.toDataModelGender(resource.gender);
        }
        // Email address contact
        if (resource.telecom?.length > 0) {
            const emailContact = resource.telecom.find((t) => t.system === ContactPoint.ContactPointSystem.EMAIL.toString());
            model.email = emailContact?.value?.trim();
        }
        return model;
    }
    fromDataModel(model) {
        const fhir = new RelatedPerson();
        fhir.id = !!model.id ? model.id + '' : undefined;
        fhir.name = FhirUtils.createHumanName(model.firstName, model.lastName);
        fhir.relationship = [ModelToFHIRUtils.fromCodedValueModel(model.relationship)];
        fhir.patient = ModelToFHIRUtils.getReference(model.patient);
        fhir.birthDate = model.birthDate;
        fhir.gender = this.fromDataModelGender(model.gender);
        if (!!model.email && model.email != '') {
            const contact = new ContactPoint();
            contact.system = ContactPoint.ContactPointSystem.EMAIL.toString();
            contact.value = model.email;
            (fhir.telecom = fhir.telecom || []).push(contact);
        }
        return fhir;
    }
    fromDataModelGender(gender) {
        if (!gender) {
            return undefined;
        }
        let fhirGender = undefined;
        if (gender == Gender.female) {
            fhirGender = 'female';
        }
        else if (gender == Gender.male) {
            fhirGender = 'male';
        }
        else if (gender == Gender.other) {
            fhirGender = 'other';
        }
        else if (gender == Gender.unknown) {
            fhirGender = 'unknown';
        }
        return fhirGender;
    }
    toDataModelGender(fhirGender) {
        if (!fhirGender) {
            return undefined;
        }
        const strFhirGender = fhirGender.toString();
        let gender = undefined;
        if (strFhirGender == 'female' || strFhirGender == RelatedPerson.AdministrativeGender.FEMALE.toString()) {
            gender = Gender.female;
        }
        else if (strFhirGender == 'male' || strFhirGender == RelatedPerson.AdministrativeGender.MALE.toString()) {
            gender = Gender.male;
        }
        else if (strFhirGender == 'other' || strFhirGender == RelatedPerson.AdministrativeGender.OTHER.toString()) {
            gender = Gender.other;
        }
        else if (strFhirGender == 'unknown' || strFhirGender == RelatedPerson.AdministrativeGender.UNKNOWN.toString()) {
            gender = Gender.unknown;
        }
        return gender;
    }
}

// tslint:disable: max-line-length no-inferrable-types no-redundant-jsdoc
class CareTeamFhirConverter extends AbstractFhirConverter {
    toDataModel(resource, context) {
        return CareTeamFhirConverter.fromFHIR(resource);
    }
    fromDataModel(model) {
        if (model instanceof CareTeam) {
            return CareTeamFhirConverter.toFHIR(model);
        }
        else {
            throw new TypeError('Unsupported model type. Error converting from datamodel to FHIR.');
        }
    }
    static fromFHIR(fhir) {
        const ct = new CareTeam(+fhir.id);
        ct.patient = ModelToFHIRUtils.stubFromRef(fhir.subject, 'Patient');
        ct.organization = fhir.managingOrganization?.length > 0 ? ModelToFHIRUtils.stubFromRef(fhir.managingOrganization[0]) : undefined;
        ct.status = CareTeamStatus.convertFromString(fhir.status);
        const caregiverRef = fhir.participant
            .filter((p) => p.role.coding[0].code === 'caregiver')
            .map((p) => p.member)
            .pop();
        if (caregiverRef) {
            ct.caregiver = new CareGiver(caregiverRef.getReferenceIdPart()); // placeholder
        }
        if (fhir.participant.filter((p) => p.role.coding[0].code === 'organization').length > 0) {
            ct.healthcareProfessionals = undefined;
        }
        else {
            ct.healthcareProfessionals = fhir.participant
                .filter((p) => p.role.coding[0].code === 'practitioner')
                .map((p) => ModelToFHIRUtils.stubFromRef(p.member));
        }
        return ct;
    }
    static toFHIR(ct) {
        const fhir = new CareTeam$1();
        fhir.id = !!ct.id ? ct.id + '' : undefined;
        fhir.subject = ModelToFHIRUtils.getReference(ct.patient);
        fhir.status = ct.status ?? 'active';
        fhir.participant = [];
        if (ct.organization) {
            fhir.managingOrganization = [ModelToFHIRUtils.getReference(ct.organization)];
            if (ct.isWholeOrganizationEnabled()) {
                const partecipant = new CareTeam$1.CareTeamParticipantComponent();
                partecipant.member = ModelToFHIRUtils.getReference(ct.organization);
                partecipant.role = FhirUtils$1.createCodeableConcept(Dictionary.UHM_VALUE_SET_URI + 'participant-role', 'organization', 'Organization');
                fhir.participant.push(partecipant);
            }
        }
        if (ct.healthcareProfessionals?.length > 0) {
            fhir.participant.push(...ct.healthcareProfessionals.map((p) => {
                const partecipant = new CareTeam$1.CareTeamParticipantComponent();
                partecipant.member = ModelToFHIRUtils.getReference(p);
                partecipant.role = FhirUtils$1.createCodeableConcept(Dictionary.UHM_VALUE_SET_URI + 'participant-role', 'practitioner', 'Practitioner');
                return partecipant;
            }));
        }
        if (ct.caregiver) {
            const partecipant = new CareTeam$1.CareTeamParticipantComponent();
            partecipant.role = FhirUtils$1.createCodeableConcept(Dictionary.UHM_VALUE_SET_URI + 'participant-role', 'caregiver', 'Caregiver');
            partecipant.member = ModelToFHIRUtils.getReference(ct.caregiver);
            fhir.participant.push(partecipant);
        }
        return fhir;
    }
}

class ConditionFhirConverter extends AbstractFhirConverter {
    fromDataModel(model) {
        const fhir = new Condition();
        fhir.id = !!model.id ? model.id + '' : undefined;
        if (model instanceof Diagnosis) {
            const conditionCategory = new HeartValueSet(Dictionary.FHIR_CONDITION_CATEGORY, 'encounter-diagnosis', 'Encounter Diagnosis').toCodeableConcept();
            fhir.category = [conditionCategory];
        }
        else {
        }
        fhir.subject = ModelToFHIRUtils.getReference(model.patient);
        if (model.author) {
            // extend the fhir data model???
            fhir.participant = [this.participantFromDataModel(model.author)];
        }
        fhir.onset = model.onsetDate;
        fhir.abatement = model.abatementDate;
        if (model.encounter) {
            fhir.encounter = ModelToFHIRUtils.getReference(model.encounter);
        }
        // patology/diagnosis
        fhir.code = ModelToFHIRUtils.fromCodedValueModel(model.code);
        const verification = model.verificationStatus?.toString();
        if (verification) {
            const cvs = HeartValueSet.Common.Condition.byCode(verification).toCodeableConcept();
            fhir.verificationStatus = cvs;
        }
        // serialize the clincial status while creating the related remission type extension for
        // in-therapy and off-therapy remission values
        let cStatus = model.clinicalStatus?.toString();
        if (cStatus) {
            let cRemissionType = undefined;
            if (cStatus == ConditionClinicalStatus.REMISSION_IN_THERAPY) {
                cRemissionType = HeartValueSet.Common.Condition.REMISSION_IN_THERAPHY;
                cStatus = 'remission'; // FHIR Code for clinicalStatus == 'remission'
            }
            else if (cStatus == ConditionClinicalStatus.REMISSION_OFF_THERAPY) {
                cRemissionType = HeartValueSet.Common.Condition.REMISSION_OFF_THERAPHY;
                cStatus = 'remission'; // FHIR Code for clinicalStatus == 'remission'
            }
            fhir.clinicalStatus = HeartValueSet.Common.Condition.byCode(cStatus).toCodeableConcept();
            if (cRemissionType) {
                if (!fhir.extension) {
                    fhir.extension = [];
                }
                const remissionTypeCc = cRemissionType.toCodeableConcept().coding[0];
                const remissionTypeExt = HeartExtension.Condition.remissionType.toExtensionCoding(remissionTypeCc);
                fhir.extension.push(remissionTypeExt);
            }
        }
        if (model.note) {
            const annotation = new Annotation();
            annotation.text = model.note;
            fhir.note = [annotation];
        }
        if (model instanceof Diagnosis) {
            const diagnosisTypes = model.types;
            if (diagnosisTypes) {
                const catExt = diagnosisTypes.map((c) => {
                    const dtCoding = new Coding();
                    dtCoding.system = Dictionary.UHM_CODE_SYSTEM_URI + 'diagnosis-type';
                    dtCoding.code = c;
                    return HeartExtension.Condition.diagnosisType.toExtensionCoding(dtCoding);
                });
                if (!fhir.extension) {
                    fhir.extension = [];
                }
                fhir.extension.push(...catExt);
            }
        }
        return fhir;
    }
    participantFromDataModel(author) {
        const participant = new Condition.ConditionParticipantComponent();
        participant.function = new HeartValueSet('http://terminology.hl7.org/CodeSystem/provenance-participant-type', 'author', 'Author').toCodeableConcept();
        participant.actor = ModelToFHIRUtils.getReference(author);
        return participant;
    }
    toDataModel(fhir, context) {
        let c;
        const category = fhir.category[0]?.coding[0]?.code;
        if (category == 'encounter-diagnosis') {
            c = new Diagnosis();
        }
        else {
            throw new Error(`Condition category ${category} not supported`);
        }
        // fhir ID
        const fhirId = this.toFhirIDPart(fhir);
        c.id = fhirId;
        c.patient = ModelToFHIRUtils.stubFromRef(fhir.subject, 'Patient');
        const participant = fhir.participant;
        if (participant?.length > 0) {
            c.author = this.participantToDataModel(participant[0]);
        }
        c.onsetDate = fhir.onset;
        c.abatementDate = fhir.abatement;
        if (fhir.encounter) {
            c.encounter = ModelToFHIRUtils.stubFromRef(fhir.encounter, 'Encounter');
        }
        c.code = ModelToFHIRUtils.toCodedValueModel(fhir.code);
        if (fhir.verificationStatus) {
            const vStatus = fhir.verificationStatus.coding[0].code;
            c.verificationStatus = ConditionVerificationStatus.valueOf(vStatus);
        }
        if (fhir.clinicalStatus) {
            let cStatus = fhir.clinicalStatus.coding[0].code;
            if (cStatus == 'remission') {
                const remissionTypeExt = HeartExtension.Condition.remissionType.extractValueFromExtensions(fhir.extension);
                if (remissionTypeExt) {
                    const rtCode = remissionTypeExt.code;
                    if (rtCode == HeartValueSet.Common.Condition.REMISSION_IN_THERAPHY.code) {
                        c.clinicalStatus = ConditionClinicalStatus.REMISSION_IN_THERAPY;
                    }
                    else {
                        c.clinicalStatus = ConditionClinicalStatus.REMISSION_OFF_THERAPY;
                    }
                }
                else {
                    console.error(`Missing remission type extension for 'remission' value in the Condition resource with id ${fhir.id}`);
                }
            }
            else {
                c.clinicalStatus = ConditionClinicalStatus.valueOf(cStatus);
            }
        }
        if (fhir.note?.length == 1) {
            c.note = fhir.note[0].text;
        }
        if (fhir.extension) {
            const categoriesCodings = HeartExtension.Condition.diagnosisType.extractCodingFromExtensions(fhir.extension);
            if (categoriesCodings?.length > 0) {
                const d = c;
                d.types = categoriesCodings.map((vs) => DiagnosisType.valueOf(vs.code));
            }
        }
        return c;
    }
    participantToDataModel(fhir) {
        let participant;
        if (fhir && fhir.function.coding[0].code == 'author') {
            participant = ModelToFHIRUtils.stubFromRef(fhir.actor, 'Practitioner');
        }
        return participant;
    }
}

// tslint:disable: max-line-length no-inferrable-types no-redundant-jsdoc
class PatientConsentFhirConverter extends AbstractFhirConverter {
    toDataModel(resource, context) {
        return PatientConsentFhirConverter.fromFHIR(resource);
    }
    fromDataModel(model) {
        if (model instanceof PatientConsent) {
            return PatientConsentFhirConverter.toFHIR(model);
        }
        else {
            throw new TypeError('Unsupported model type. Error converting from datamodel to FHIR.');
        }
    }
    static fromFHIR(fhir) {
        const c = new PatientConsent(+fhir.id);
        const atts = fhir.sourceAttachment;
        if (atts && atts[0]) {
            const att = atts[0];
            c.attachmentTitle = att.title;
            const contentDataId = HeartExtension.Common.AttachmentExternalizedBinaryId.extractValueFromExtensions(att._data?.extension);
            c.contentDataId = contentDataId;
        }
        c.createdAt = fhir.date;
        c.patientRef = ModelToFHIRUtils.stubFromRef(fhir.subject);
        c.performerRef =
            fhir.grantee?.length > 0
                ? ModelToFHIRUtils.stubFromRef(fhir.grantee[0])
                : undefined;
        if (fhir.category?.length > 0) {
            c.permissions = fhir.category
                .map((cat) => PatientConsentFhirConverter.convertFromFhirConsentPermission(HeartValueSet.GDPR.ConsentPermission.byCode(cat.coding[0].code)))
                .filter((cat) => cat);
        }
        return c;
    }
    static toFHIR(model) {
        const fhir = new Consent();
        fhir.id = !!model.id ? model.id + '' : undefined;
        fhir.date = model.createdAt || new Date();
        fhir.status = Consent.ConsentState.ACTIVE.toString();
        // fhir.scope = HeartValueSet.GDPR.Consent.SCOPE.toCodeableConcept(); //FIXME : SCOPE eliminato
        fhir.category = [
            HeartValueSet.GDPR.ConsentPermission.PATIENT_CONSENT.toCodeableConcept(),
        ];
        if (model.permissions?.length > 0) {
            fhir.category.push(...model.permissions.map((p) => PatientConsentFhirConverter.convertToValueSet(p)?.toCodeableConcept()));
        }
        if (model.attachmentTitle) {
            const attachment = new Attachment();
            attachment.title = model.attachmentTitle;
            attachment.contentType = 'application/pdf';
            if (model.contentDataId) {
                attachment._data = {
                    extension: [
                        HeartExtension.Common.AttachmentExternalizedBinaryId.toExtensionString(model.contentDataId),
                    ],
                };
            }
            fhir.sourceAttachment = [attachment];
        }
        fhir.subject = ModelToFHIRUtils.getReference(model.patientRef);
        if (model.performerRef) {
            fhir.grantee = [ModelToFHIRUtils.getReference(model.performerRef)];
        }
        return fhir;
    }
    static convertFromFhirConsentPermission(fhirConsentPermission) {
        if (fhirConsentPermission === HeartValueSet.GDPR.ConsentPermission.INFA) {
            return ConsentPermission.INFA;
        }
        else if (fhirConsentPermission === HeartValueSet.GDPR.ConsentPermission.INFAO) {
            return ConsentPermission.INFAO;
        }
        else if (fhirConsentPermission === HeartValueSet.GDPR.ConsentPermission.INFASO) {
            return ConsentPermission.INFASO;
        }
        else {
            return undefined;
        }
    }
    static convertToValueSet(currentValue) {
        if (currentValue === ConsentPermission.INFA) {
            return HeartValueSet.GDPR.ConsentPermission.INFA;
        }
        else if (currentValue === ConsentPermission.INFAO) {
            return HeartValueSet.GDPR.ConsentPermission.INFAO;
        }
        else if (currentValue === ConsentPermission.INFASO) {
            return HeartValueSet.GDPR.ConsentPermission.INFASO;
        }
        else {
            return undefined;
        }
    }
}

// tslint:disable: max-line-length no-inferrable-types no-redundant-jsdoc
class EncounterFhirConverter extends AbstractFhirConverter {
    toDataModel(resource, context) {
        return this.toDataModelEncounter(resource, context);
    }
    fromDataModel(model) {
        if (model instanceof Encounter) {
            return this.fromDataModelEncounter(model);
        }
        else {
            throw new TypeError('Unsupported model type. Error converting from datamodel to FHIR.');
        }
    }
    // Patient ed EpisodeOfCare sono necessari per la memorizzazione dell'encounter - ad oggi
    // TODO: verificare l'allineamento con UHM - vedi SHE #1137 #1171
    fromDataModelEncounter(model, episodeOfCare, patient) {
        const fhir = new Encounter$1();
        fhir.id = !!model.id ? model.id + '' : undefined;
        // Alignment to UHM FHIR PROFILE
        if (model.patient) {
            fhir.subject = ModelToFHIRUtils.getReference(model.patient);
        }
        else if (patient) {
            fhir.subject = ModelToFHIRUtils.getReference(patient);
        }
        // creates a link between the EpisodeOfCare and the Encounter.
        // the link requires that the EoC ID is already defined
        // TODO: check with SHE people. It was mandatory => NOW, IF NEEDED, IT HAS TO BE ENFORCED BY THE TEMPLATE
        if (episodeOfCare) {
            fhir.episodeOfCare = [new Reference({ reference: 'EpisodeOfCare/' + episodeOfCare.id })];
        }
        if (model.type) {
            fhir.type = [FhirUtils.fromDataModelEncounterType(model.type)];
        }
        fhir.serviceProvider = model.serviceProvider ? ModelToFHIRUtils.getReference(model.serviceProvider) : undefined;
        if (model.participant) {
            fhir.participant = [];
            let participantItem = new Encounter$1.EncounterParticipantComponent();
            participantItem.actor = ModelToFHIRUtils.getReference(model.participant);
            fhir.participant.push(participantItem);
        }
        fhir.status = model.status.toString();
        let period = FhirUtils.createPeriodStartEnd(model.startDate);
        if (model.closingDate) {
            period = FhirUtils.createPeriodStartEnd(model.startDate, model.closingDate);
        }
        fhir.actualPeriod = period;
        return fhir;
    }
    toDataModelEncounter(fhir, context) {
        // in questo bundle ci saranno anche i questionnaireresponse (di tutti gli encounter, non solo di questo che stiamo convertendo) e tutti gli altri (che ora non sappiamo)
        const model = new Encounter();
        model.id = +fhir.id;
        if (fhir.subject) {
            model.patient = ModelToFHIRUtils.stubFromRef(fhir.subject, 'Patient');
        }
        if (fhir.participant?.length > 0) {
            model.participant = fhir.participant[0].actor ? ModelToFHIRUtils.stubFromRef(fhir.participant[0].actor, 'Practitioner') : undefined;
        }
        model.serviceProvider = fhir.serviceProvider ? ModelToFHIRUtils.stubFromRef(fhir.serviceProvider) : undefined;
        // FIXME FHIR R5 uses 'actualPeriod'
        model.startDate = fhir.actualPeriod?.start ? new Date(fhir.actualPeriod?.start) : new Date(fhir['actualPeriod']['start']);
        model.closingDate = fhir.actualPeriod?.end ? new Date(fhir.actualPeriod?.end) : undefined;
        if (fhir.type?.length > 0) {
            model.type = FhirUtils.toDataModelEncounterType(fhir.type[0]);
        }
        const modelReference = ModelToFHIRUtils.getReference(model).reference;
        // converti i questionnaire responses di interesse tramite il loro convertitore ed aggangialo all'encounter
        const qrs = context?.entry
            .filter((i) => i.resource.resourceType == 'QuestionnaireResponse')
            .filter((i) => i.resource.encounter.reference == modelReference)
            .map((entry) => this.service.questionnaireResponse.toDataModel(entry.resource, context));
        // codice del questionnaire response da recuperare dall'URL quello usato dalla UI per recuperare il questionario dal server.
        if (qrs) {
            qrs.forEach((qr) => this.setAnamnesisAttribute(model, qr));
        }
        // converti le diagnosis di interesse tramite il loro convertitore ed aggangialo all'encounter
        const diagnoses = context?.entry
            .filter((i) => i.resource.resourceType == 'Condition')
            .filter((i) => i.resource.encounter.reference == modelReference)
            .map((entry) => this.service.condition.toDataModel(entry.resource, context));
        // codice del questionnaire response da recuperare dall'URL quello usato dalla UI per recuperare il questionario dal server.
        if (diagnoses) {
            diagnoses.forEach((d) => this.setDiagnosisAttribute(model, d));
        }
        // converti le observations e inseriscile nel model in physical_examination
        const measureConv = this.service.measure;
        const phyExams = context?.entry
            .filter((i) => i.resource.resourceType == 'Observation')
            .filter((i) => i.resource.encounter.reference == modelReference)
            .map((entry) => measureConv.toDataModelGenericMeasure(entry.resource, context));
        if (phyExams) {
            this.setMeasuresToEncounter(model, phyExams);
        }
        // converti le examPrescription e inseriscile nel model in exam_prescr
        // TODO: from here
        const examPrescr = context?.entry
            .filter((i) => i.resource.resourceType == 'ServiceRequest')
            .filter((i) => i.resource.encounter.reference == modelReference)
            .map((entry) => this.service.prescription.toDataModel(entry.resource, context));
        if (examPrescr) {
            this.setExamPrescr(model, examPrescr);
        }
        const notes = context?.entry
            .filter((i) => i.resource.resourceType == 'DocumentReference')
            .filter((i) => i.resource.context.some((ref) => ref.reference == modelReference))
            .filter((i) => HeartValueSet.Common.ClinicalImpression.OBSERVE_PATIENT.equals(i.resource.type))
            .map((entry) => this.service.clinicalNote.toDataModel(entry.resource, context));
        if (notes) {
            this.setNotes(model, notes);
        }
        return model;
    }
    setAnamnesisAttribute(enc, qr) {
        const url = qr.questionnaire?.questionnaireId ?? qr.questionnaireUrl;
        const type = FhirUtils.toDataModelEncounterQuestionnaire(url);
        enc.setQuestionnaire(type, qr);
        return enc;
    }
    setDiagnosisAttribute(enc, diagnosis) {
        if (!enc.diagnosis) {
            enc.diagnosis = [];
        }
        enc.diagnosis.push(diagnosis);
        return enc;
    }
    setMeasuresToEncounter(enc, phyExams) {
        if (!enc.physical_examination) {
            enc.physical_examination = [];
        }
        enc.physical_examination.push(...phyExams);
        return enc;
    }
    setExamPrescr(enc, examPrescrs) {
        if (!enc.exam_prescr) {
            enc.exam_prescr = [];
        }
        enc.exam_prescr.push(...examPrescrs);
        return enc;
    }
    setNotes(enc, notes) {
        if (!enc.notes) {
            enc.notes = [];
        }
        enc.notes.push(...notes);
        return enc;
    }
}

// tslint:disable: max-line-length no-inferrable-types no-redundant-jsdoc
class EpisodeFhirConverter extends AbstractFhirConverter {
    toDataModel(resource, context) {
        return this.toDataModelEpisode(resource, context);
    }
    fromDataModel(model) {
        if (model instanceof Episode) {
            return this.fromDataModelEpisode(model);
        }
        else {
            throw new TypeError('Unsupported model type. Error converting from datamodel to FHIR.');
        }
    }
    toDataModelEpisode(fhir, context) {
        const model = new Episode(+fhir.id);
        model.patient = ModelToFHIRUtils.stubFromRef(fhir.patient, 'Patient');
        model.careManager = ModelToFHIRUtils.stubFromRef(fhir.careManager, 'Practitioner');
        model.type = this.toDataModelHealthService(fhir.type);
        if (fhir.managingOrganization) {
            model.managingOrganization = ModelToFHIRUtils.stubFromRef(fhir.managingOrganization);
        }
        if (fhir.statusHistory?.length > 0) {
            model.openingDate = fhir.statusHistory[0].period?.start;
        }
        if (fhir.statusHistory?.length > 1) {
            model.closingDate = fhir.statusHistory[1].period?.start;
        }
        const fhirEncounters = context?.entry
            // filter only the encounters
            ?.filter((entry) => entry.resource.resourceType == 'Encounter')
            ?.map((entry) => entry.resource)
            // ... of this episodeOfCare
            ?.filter((fhirEncounter) => fhirEncounter.episodeOfCare[0].getReferenceIdPart() == +fhir.id);
        model.encounter = fhirEncounters?.map((fhirEncounter) => this.service.encounter.toDataModel(fhirEncounter));
        return model;
    }
    fromDataModelEpisode(model) {
        const fhir = new EpisodeOfCare();
        fhir.id = !!model.id ? model.id + '' : AbstractApi.generateRandomIDDt();
        // TODO: verificare l'allineamento con UHM - vedi SHE #1137 #1171
        fhir.patient = model.patient ? ModelToFHIRUtils.getReference(model.patient) : undefined;
        fhir.careManager = model.careManager ? ModelToFHIRUtils.getReference(model.careManager) : undefined;
        fhir.type = this.fromDataModelHealthService(model.type);
        fhir.managingOrganization = model.managingOrganization ? ModelToFHIRUtils.getReference(model.managingOrganization) : undefined;
        const statusHistoryArray = [];
        // set the default status
        fhir.status = EpisodeOfCare.EpisodeOfCareStatus.ACTIVE.toString();
        if (model.openingDate) {
            let statusHistoryItem = new EpisodeOfCare.EpisodeOfCareStatusHistoryComponent();
            statusHistoryItem.period = FhirUtils.createPeriodStartEnd(model.openingDate);
            statusHistoryItem.status = EpisodeOfCare.EpisodeOfCareStatus.ACTIVE.toString();
            statusHistoryArray.push(statusHistoryItem);
        }
        if (model.closingDate) {
            let statusHistoryItem = new EpisodeOfCare.EpisodeOfCareStatusHistoryComponent();
            statusHistoryItem.period = FhirUtils.createPeriodStartEnd(model.closingDate);
            statusHistoryItem.status = EpisodeOfCare.EpisodeOfCareStatus.FINISHED.toString();
            statusHistoryArray.push(statusHistoryItem);
            fhir.status = EpisodeOfCare.EpisodeOfCareStatus.FINISHED.toString();
        }
        fhir.statusHistory = statusHistoryArray;
        if (model.encounter?.length > 0) {
            // const fhirEncounters = model.encounter.map(encounter => this.fromDataModelEncounter(encounter, model.patient, fhir));
            // TODO: verificare l'allineamento con UHM - vedi SHE #1137 #1171
            const fhirEncounters = model.encounter.map((encounter) => this.service.encounter.fromDataModelEncounter(encounter, fhir, model.patient));
            // Encounter SENZA Subject
            // const fhirEncounters = model.encounter.map(encounter => (this.service.encounter as EncounterFhirConverter).fromDataModelEncounter(encounter, fhir));
            // add fhirEcnounters as contained resources;
            fhir.contained = fhirEncounters;
        }
        return fhir;
    }
    fromDataModelHealthService(type) {
        if (type == HealthService.DAY_HOSPITAL) {
            return [FhirUtils.createCodeableConcept(Dictionary.UHM_CODE_SYSTEM_URI + 'episode-of-care-type', 'DH', 'day hospital')];
        }
        else if (type == HealthService.HOSPITALIZATION) {
            return [FhirUtils.createCodeableConcept(Dictionary.UHM_CODE_SYSTEM_URI + 'episode-of-care-type', 'HO', 'hospitalisation')];
        }
        else if (type == HealthService.OUTPATIENT) {
            return [FhirUtils.createCodeableConcept(Dictionary.UHM_CODE_SYSTEM_URI + 'episode-of-care-type', 'OV', 'outpatient visit')];
        }
        return undefined;
    }
    toDataModelHealthService(type) {
        if (type?.length > 0) {
            const tc = type[0]?.coding[0];
            if (tc.code == 'DH') {
                return HealthService.DAY_HOSPITAL;
            }
            else if (tc.code == 'HO') {
                return HealthService.HOSPITALIZATION;
            }
            else if (tc.code == 'OV') {
                return HealthService.OUTPATIENT;
            }
        }
        return undefined;
    }
}

class GoalFhirConverter extends AbstractFhirConverter {
    toDataModel(fGoal, context) {
        const lGoal = new Goal();
        lGoal.id = this.toFhirIDPart(fGoal);
        lGoal.version = this.toFhirVersion(fGoal);
        /** target singolo
        if (fGoal.target?.length > 0) {
          lGoal.target = TargetUtils.toDataModelTarget(fGoal.target[0], context);
        }*/
        if (fGoal.target?.length > 0) {
            lGoal.targets = fGoal.target.map((t) => TargetUtils.toDataModelTarget(t, context));
        }
        if (fGoal.subject) {
            lGoal.subject = ModelToFHIRUtils.stubFromRef(fGoal.subject, 'Patient');
        }
        if (fGoal.extension) {
            // traduzione delle date
            const duration = HeartExtension.Goal.acceptanceDuration.extractValueFromExtensions(fGoal.extension);
            lGoal.acceptanceDurationInDays = duration?.value;
            lGoal.createdOn = HeartExtension.Goal.createdOn.extractValueFromExtensions(fGoal.extension);
            lGoal.validatedOn = HeartExtension.Goal.validatedOn.extractValueFromExtensions(fGoal.extension);
            lGoal.proposedOn = HeartExtension.Goal.proposedOn.extractValueFromExtensions(fGoal.extension);
            lGoal.acceptedOn = HeartExtension.Goal.acceptedOn.extractValueFromExtensions(fGoal.extension);
            lGoal.cancelledOn = HeartExtension.Goal.cancelledOn.extractValueFromExtensions(fGoal.extension);
            lGoal.endedOn = HeartExtension.Goal.endedOn.extractValueFromExtensions(fGoal.extension);
            // actuator
            const ref = HeartExtension.Goal.actuator.extractValueFromExtensions(fGoal.extension);
            if (ref) {
                this.toDataModelGoalExtractActuator(ref, fGoal, context, lGoal);
            }
            // replacement (goal che mi sta sostituendo)
            this.toDataModelGoalExtractReplacement(fGoal, context, lGoal);
            // TODO
            // console.log('ERROR in FHIR Converter: Extension non supporta più nested resources!!! rivedere serializzatore e deserializzatore di Goal_relationship');
            // milestones
            this.toDataModelGoalExtractMilestones(fGoal, lGoal, context);
        }
        if (fGoal.start instanceof Date) {
            lGoal.startedOn = fGoal.start;
        }
        else if (typeof fGoal.start === 'string') {
            lGoal.startedOn = new Date(fGoal.start);
        }
        // target singolo
        if (fGoal.target?.length > 0) {
            if (fGoal.target[0].due) {
                if (fGoal.target[0].due instanceof Duration) {
                    lGoal.durationInDays = this.getDuration(fGoal.target[0].due);
                }
                else if (fGoal.target[0].due instanceof Date) {
                    lGoal.durationInDays = differenceInCalendarDays(fGoal.target[0].due, lGoal.startedOn);
                    // throw new TypeError(`Unsupported target 'end' date type '${fGoal.target.due}' in FHIR Goal`);
                }
                else {
                    throw new TypeError(`Unsupported 'end' type '${fGoal.target[0].due}' in FHIR Goal`);
                }
            }
        }
        lGoal.status = FhirCodesMapperUtils.GoalStatusFromFHIR(fGoal.lifecycleStatus);
        // descrizione del goal fornita dal medico
        lGoal.note = fGoal.note ? fGoal.note[0].text : undefined;
        // _goal.??? = fGoal.category // TODO
        // _goal.causedBy // TODO
        if (fGoal.source) {
            let fExpressedBy;
            if (fGoal.source instanceof Reference) {
                try {
                    fExpressedBy = this.resolveReference(fGoal.source, fGoal, context);
                }
                catch (err) {
                    lGoal.recommender = this.service.person.toDataModel(fGoal.source);
                }
            }
            else {
                fExpressedBy = fExpressedBy;
            }
            if (fExpressedBy) {
                lGoal.recommender = this.service.person.toDataModel(fExpressedBy); // TODO
            }
        }
        // type
        if (fGoal.description) {
            if (fGoal.description.coding && fGoal.description.coding.length > 0) {
                lGoal.type = ModelToFHIRUtils.toCodedValueModel(fGoal.description);
            }
            if (fGoal.description.text) {
                lGoal.description = fGoal.description.text;
            }
        }
        return lGoal;
    }
    toDataModelGoalExtractMilestones(fGoal, lGoal, context) {
        const fMilestoneExts = fGoal.extension
            .filter((e) => e.url === HeartExtension.Goal.relationship.url)
            .filter((mExt) => !!mExt.extension
            ?.filter((innerExt) => innerExt.value && innerExt.value instanceof CodeableConcept)
            .find((innerExt) => innerExt.value.coding[0].code === 'milestone'));
        if (fMilestoneExts) {
            lGoal.milestones = [];
            fMilestoneExts.forEach((fMilestoneExt) => {
                // const ref = fMilestoneExt.value as FhirReference;
                const targetRef = fMilestoneExt.extension.find((innerExt) => innerExt.url === 'target').value;
                const refFhirId = targetRef.reference;
                // controlla che non sia già riferita questa milestone dal macrogoal (es: in caso di replacement)
                if (lGoal.milestones.every((m) => m.fhirId !== refFhirId)) {
                    let fMilestone;
                    // prova a cercare la risorsa nel contesto
                    fMilestone = this.resolveReference(targetRef, fGoal, context);
                    let _milestone = this.toDataModel(fMilestone, context);
                    if (!_milestone) {
                        console.log(`[WARN] Il riferimento al sottogoal ${JSON.stringify(_milestone)} ha prodotto un Goal undefined`);
                    }
                    else {
                        while (_milestone) {
                            lGoal.milestones.push(_milestone);
                            _milestone = _milestone.replacement;
                        }
                    }
                }
            });
            // Ensure the correct linkage among the goal (see relationship replacement/proposedReplacementOf)
        }
    }
    toDataModelGoalExtractReplacement(fGoal, context, lGoal) {
        const fReplacementExt = fGoal.extension
            .filter((e) => e.url === HeartExtension.Goal.relationship.url)
            .filter((mExt) => !!mExt.extension
            ?.filter((innerExt) => innerExt.value && innerExt.value instanceof CodeableConcept)
            .find((innerExt) => innerExt.value.coding[0].code === 'replacement'));
        if (fReplacementExt && fReplacementExt.length > 0) {
            const replaceRef = fReplacementExt[0].extension.find((innerExt) => innerExt.url === 'target').value;
            let fReplacement;
            // prova a cercare la risorsa nel contesto
            fReplacement = this.resolveReference(replaceRef, fGoal, context);
            const _rep = this.toDataModel(fReplacement, context);
            if (!_rep) {
                console.log(`[WARN] Ignorato il riferimento al replacement ${JSON.stringify(_rep)}. TODO`);
            }
            else {
                lGoal.replacement = _rep;
            }
        }
    }
    toDataModelGoalExtractActuator(ref, fGoal, context, lGoal) {
        let fActuator;
        // prova a cercare la risorsa nel contesto
        try {
            fActuator = this.resolveReference(ref, fGoal, context);
            lGoal.recommender = this.service.person.toDataModel(fActuator);
        }
        catch (err) {
            lGoal.recommender = this.service.person.toDataModel(ref);
        }
        if (!lGoal.recommender) {
            console.log(`[WARN] Ignorato il riferimento all'attuatore ${JSON.stringify(ref)}. TODO`);
        }
    }
    fromDataModel(goal) {
        const fGoal = new Goal$1();
        const patient = goal.subject;
        if (patient === undefined) {
            throw Error('Patient not found while converting the goal.');
        }
        // save local id for future referencing
        fGoal._id = goal.id;
        if (goal.fhirId) {
            fGoal.id = goal.fhirId.startsWith('Goal') ? goal.fhirId.substring('Goal/'.length) : goal.fhirId;
        }
        else {
            fGoal.id = AbstractApi.generateRandomIDDt();
        }
        // fGoal.category // TODO
        if (goal.note) {
            const ann = new Annotation();
            ann.text = goal.note;
            fGoal.note = [ann];
        }
        const extension = [];
        if (goal.actuator) {
            extension.push(HeartExtension.Goal.actuator.toExtensionReference(ModelToFHIRUtils.getReference(patient)));
        }
        if (goal.recommender) {
            fGoal.source = ModelToFHIRUtils.getReference(goal.recommender);
        }
        if (goal.proposedReplacementOf) {
            extension.push(HeartExtension.Goal.proposedReplaced.toExtensionReference(ModelToFHIRUtils.getReference(goal.proposedReplacementOf)));
        }
        if (goal.replacement) {
            const replacement = this._createReplacementRelationshipExtension(ModelToFHIRUtils.getReference(goal.replacement));
            extension.push(replacement);
        }
        fGoal.subject = ModelToFHIRUtils.getReference(patient);
        // addresses
        if (goal.causedBy) {
            fGoal.addresses = [];
            // TODO: Convertire le misurazioni di origine
            // goal.causedBy.forEach((origin) => fGoal.addresses.push(origin.reference));
        }
        /** target singolo
        if (goal.target) {
          fGoal.target = [TargetUtils.fromDataModelTarget(goal.target)];
        } */
        // if goal.targets exist and has at least 1 element
        if (goal.targets?.length > 0) {
            fGoal.target = goal.targets.map((t) => TargetUtils.fromDataModelTarget(t));
        }
        /** target singolo
        if (goal.durationInDays) {
          if (!(fGoal.target?.length > 0)) {
            fGoal.target = [new FhirGoal.GoalTargetComponent()];
          }
    
          const duration = new FhirDuration();
          duration.unit = 'd';
          duration.system = Dictionary.UNIT_OF_MEASURE;
          duration.value = goal.durationInDays;
          fGoal.target[0].due = duration;
        }*/
        if (goal.durationInDays) {
            // FIXME: does it make sense to add an empty target?
            if (!(fGoal.target?.length > 0)) {
                fGoal.target = [new Goal$1.GoalTargetComponent()];
            }
            const duration = this._fromDataModelDuration(goal.durationInDays);
            // Itera su ogni target di fGoal.target e assegna la durata
            fGoal.target.forEach((target) => {
                target.due = duration;
            });
        }
        // traduzione delle date
        const createdOn = this._fromDataModelDate(goal.createdOn);
        if (createdOn) {
            extension.push(HeartExtension.Goal.createdOn.toExtensionDate(createdOn));
        }
        const validatedOn = this._fromDataModelDate(goal.validatedOn);
        if (validatedOn) {
            extension.push(HeartExtension.Goal.validatedOn.toExtensionDate(validatedOn));
        }
        const proposedOn = this._fromDataModelDate(goal.proposedOn);
        if (proposedOn) {
            extension.push(HeartExtension.Goal.proposedOn.toExtensionDate(proposedOn));
        }
        if (goal.acceptanceDurationInDays) {
            const acceptanceDuration = this._fromDataModelDuration(goal.acceptanceDurationInDays);
            extension.push(HeartExtension.Goal.acceptanceDuration.toExtension(acceptanceDuration));
        }
        const acceptedOn = this._fromDataModelDate(goal.acceptedOn);
        if (acceptedOn) {
            extension.push(HeartExtension.Goal.acceptedOn.toExtensionDate(acceptedOn));
        }
        const cancelledOn = this._fromDataModelDate(goal.cancelledOn);
        if (cancelledOn) {
            extension.push(HeartExtension.Goal.cancelledOn.toExtensionDate(cancelledOn));
        }
        fGoal.lifecycleStatus = FhirCodesMapperUtils.GoalStatusToFHIR(goal.status)?.toString();
        // category
        if (goal.type) {
            fGoal.description = ModelToFHIRUtils.fromCodedValueModel(goal.type, goal.description);
        }
        else if (goal.description) {
            fGoal.description = ModelToFHIRUtils.fromTextModel(goal.description);
        }
        fGoal.start = this._fromDataModelDate(goal.startedOn);
        const endedOn = this._fromDataModelDate(goal.endedOn);
        if (endedOn) {
            extension.push(HeartExtension.Goal.endedOn.toExtensionDate(endedOn));
        }
        if (goal.milestones && goal.milestones.length > 0) {
            goal.milestones.forEach((m) => {
                const fMilestone = this.fromDataModel(m);
                const fMilestoneExt = this._createMilestoneRelationshipExtension(fMilestone);
                extension.push(fMilestoneExt);
            });
        }
        if (extension.length > 0) {
            fGoal.extension = extension;
        }
        return fGoal;
    }
    _fromDataModelDuration(days) {
        const duration = new Duration();
        duration.system = Dictionary.UNIT_OF_MEASURE;
        if (days == 7) {
            duration.unit = 'w';
            duration.value = 1;
        }
        else if (days == 30) {
            duration.unit = 'm';
            duration.value = 1;
        }
        else {
            duration.unit = 'd';
            duration.value = days;
        }
        return duration;
    }
    _fromDataModelDate(localDate) {
        if (localDate instanceof Date) {
            return localDate;
        }
        else if (typeof localDate === 'string') {
            return new Date(localDate);
        }
        return undefined;
    }
    _createMilestoneRelationshipExtension(fMilestoneGoal) {
        const fMilestoneExtValueExt = new Extension();
        const fMilestoneExtTypeExt = new Extension();
        // crea la struttura esterna
        const fMilestoneExt = HeartExtension.Goal.relationship.toStructuredExtension([fMilestoneExtTypeExt, fMilestoneExtValueExt]);
        // crea l'estensione per tracciare il tipo
        fMilestoneExtTypeExt.value = HeartValueSet.Common.GoalRelationship.MILESTONE.toCodeableConcept();
        fMilestoneExtTypeExt.url = 'type';
        // crea l'estensione per tracciare il valore
        // console.log( 'TODO in Goal-FHIR-Converter: Extension non supporta più nested resources!!! rivedere serializzatore e deserializzatore di Goal_relationship' );
        // ATTENTION: while the data model only accepts references the serializer needs the instance of the goal!!!
        fMilestoneExtValueExt.value = fMilestoneGoal;
        fMilestoneExtValueExt.url = 'target';
        return fMilestoneExt;
    }
    _createReplacementRelationshipExtension(fReplacement) {
        const fReplacementExtValueExt = new Extension();
        const fReplacementExtTypeExt = new Extension();
        // crea la struttura esterna
        const fReplacementExt = HeartExtension.Goal.relationship.toExtension([fReplacementExtTypeExt, fReplacementExtValueExt]);
        // crea l'estensione per tracciare il tipo
        fReplacementExtTypeExt.value = HeartValueSet.Common.GoalRelationship.REPLACEMENT.toCodeableConcept();
        fReplacementExtTypeExt.url = 'type';
        // crea l'estensione per tracciare il valore
        fReplacementExtValueExt.value = fReplacement;
        fReplacementExtValueExt.url = 'target';
        return fReplacementExt;
    }
}

class MeasureFhirConverter extends AbstractFhirConverter {
    fromDataModel(model) {
        if (model instanceof Measure && !(model instanceof Meal)) {
            return this.fromDataModelMeasure(model);
        }
        else if (model instanceof Meal) {
            return this.fromDataModelMeal(model);
        }
        else {
            throw new TypeError('Unsupported model type. Error converting from datamodel to FHIR.');
        }
    }
    toDataModel(resource, context) {
        let measure;
        const code = resource.code;
        // list all conversion criteria. It mainly consists of a set of codes to be mapped n the local model
        // try matching all the codes (it stops at the first match)
        if (HeartValueSet.Common.Measurement.BMI_CODINGS.equals(code)) {
            measure = this.toDataModelBmi(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.WEIGHT_CODINGS.equals(code)) {
            measure = this.toDataModelWeight(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.HEIGHT_CODINGS.equals(code)) {
            measure = this.toDataModelHeight(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.WAIST_CODINGS.equals(code)) {
            measure = this.toDataModelWaist(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.HEART_RATE_RESTING_CODING.equals(code)) {
            measure = this.toDataModelHeartRate(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.STEPS_CODINGS.equals(code)) {
            measure = this.toDataModelStepCount(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.PHYSICAL_INABILITY_CODINGS.equals(code)) {
            measure = this.toDataModelPhysicalInability(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.LIFESTYLE_CODING.equals(code)) {
            measure = this.toDataModelLifeStyle(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.SMOKER_CODINGS.equals(code)) {
            measure = this.toDataModelSmoker(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.SUPERVISOR_REQUIRED_CODINGS.equals(code)) {
            measure = this.toDataModelSupervisorRequired(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.MEAL_CODINGS.equals(code)) {
            measure = this.toDataModelMeal(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.TTM_CODINGS.equals(code)) {
            measure = this.toDataModelTTM(resource, context);
        }
        else if (
        // HeartValueSet.Common.Measurement.SMOKING_FREQ_CODINGS.equals(code) ||
        HeartValueSet.Common.Measurement.CIGARETTES_DAILY_AMOUNT_CODINGS.equals(code)) {
            measure = this.toDataModelSmokingFrequency(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.BLOOD_PRESSURE_CODINGS.equals(code)) {
            measure = this.toDataModelBloodPressure(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.BLOOD_GLUCOSE_MOLES_CODINGS.equals(code) || HeartValueSet.Common.Measurement.BLOOD_GLUCOSE_MASS_CODINGS.equals(code)) {
            measure = this.toDataModelBloodGlucose(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.CHOLESTEROL_HDL_CODINGS.equals(code)) {
            measure = this.toDataModelCholHdl(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.CHOLESTEROL_LDL_CODINGS.equals(code)) {
            measure = this.toDataModelCholLdl(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.CHOLESTEROL_CODINGS.equals(code)) {
            measure = this.toDataModelChol(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.TRIGLYCERIDE_CODINGS.equals(code)) {
            measure = this.toDataModelTriglyceride(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.SPO2_CODINGS.equals(code)) {
            measure = this.toDataModelSpO2(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.HBA1C_CODINGS.equals(code)) {
            measure = this.toDataModelHba1c(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.BODY_TEMPERATURE_CODINGS.equals(code)) {
            measure = this.toDataModelBodyTemperature(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.COVID_SURVEY.equals(code)) {
            measure = this.toDataModelCovidSymptoms(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.PATIENT_HEALTH_STATUS_CODING.equals(code)) {
            measure = this.toDataModelHealthStatus(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.CHEST_PAIN_CODINGS.equals(code) || HeartValueSet.Common.Measurement.CHEST_PAIN_QUESTIONNAIRE.equals(code)) {
            measure = this.toDataModelChestPain(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.GENOMIC_VARIANT_CODE.equals(code)) {
            measure = this.toDataModelGenomicVariant(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.DIAGNOSTIC_IMPLICATION_CODE.equals(code)) {
            measure = this.toDataModelDiagnosticImplication(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.THERAPEUTIC_IMPLICATION_CODE.equals(code)) {
            measure = this.toDataModelTherapeuticImplication(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.MOLECULAR_CONSEQUENCE_CODE.equals(code)) {
            measure = this.toDataModelMolecularConsequence(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.GENOTYPE_CODE.equals(code)) {
            measure = this.toDataModelGenotype(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.HAPLOTYPE_CODE.equals(code)) {
            measure = this.toDataModelHaplotype(resource, context);
        }
        else if (HeartValueSet.Common.Measurement.REGION_STUDIED_CODE.equals(code)) {
            measure = this.toDataModelRegionStudied(resource, context);
        }
        else if (code.coding) {
            // cosa succede se arriva una risorsa che non supportiamo - tipo nelle card di suggerimenti?
            measure = this.toDataModelGenericMeasure(resource, context);
        }
        else {
            const _code = code?.coding?.length > 0 ? code.coding[0].code + ' - ' + code.coding[0].display : '';
            throw new TypeError(`Unsupported measure type. Error converting to datamodel from FHIR: ${_code}`);
        }
        // id
        measure.id = +resource.id;
        // status
        measure.status = resource.status;
        if (resource.method) {
            measure.method = ModelToFHIRUtils.toCodedValueModel(resource.method);
        }
        // fhir ID
        const fhirVersion = this.toFhirVersion(resource);
        // FhirVersionable is an interface so we can't do 'instanceof'
        if (measure.supportFhirVersion && !!measure.supportFhirVersion()) {
            measure.version = fhirVersion;
        }
        // measure.fhirId = this.toFhirID(resource);
        if (resource.subject) {
            measure.patient = ModelToFHIRUtils.stubFromRef(resource.subject); /* this.resolveSubject( resource.subject as FhirReference, resource, context );*/
        }
        if (resource.effective && resource.effective instanceof Date) {
            measure.assertedWhen = resource.effective;
        }
        // check the optional comments
        if (resource.note?.length > 0 && resource.note[0].text !== '') {
            measure.notes = resource.note?.map((note) => note?.text).pop();
            // let text : string = resource.text.div;
            // // removes the optional XML tags
            // if ( text.startsWith('<div>') && text.endsWith('</div>') ) {
            //     text = text.substring('<div>'.length, text.length - '</div>'.length);
            // }
            // measure.notes = resource.text.div;
        }
        // procedure source
        if (resource.extension) {
            measure.healthId = HeartExtension.Workout.healthId.extractValueFromExtensions(resource.extension);
            measure.healthSource = HeartExtension.Workout.healthSource.extractValueFromExtensions(resource.extension);
        }
        return measure;
    }
    toDataModelHealthStatus(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.PATIENT_HEALTH_STATUS_CODING.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelHealthStatus'`);
        }
        const sl = new PatientHealthStatus();
        // fhir version
        //sl.fhirId = this.toFhirVersion(resource);
        // prettier-ignore
        if (resource.value instanceof CodeableConcept) {
            const v = resource.value;
            if (HeartValueSet.Common.Measurement.GENERAL_HEALTH_POOR_CODING.equals(v)) {
                sl.value = PatientHealthStatus.PatientHealthStatusCategory.POOR;
            }
            else if (HeartValueSet.Common.Measurement.GENERAL_HEALTH_FAIR_CODING.equals(v)) {
                sl.value = PatientHealthStatus.PatientHealthStatusCategory.FAIR;
            }
            else if (HeartValueSet.Common.Measurement.GENERAL_HEALTH_GOOD_CODING.equals(v)) {
                sl.value = PatientHealthStatus.PatientHealthStatusCategory.GOOD;
            }
            else {
                throw new TypeError('Unsupported value type for PatientHealthStatus element. Error converting to datamodel from FHIR.');
            }
        }
        else {
            throw new TypeError('Unsupported value type for PatientHealthStatus element. Error converting to datamodel from FHIR.');
        }
        return sl;
    }
    toDataModelCovidSymptoms(resource, context) {
        if (!HeartValueSet.Common.Measurement.COVID_SURVEY.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelCovidSymptoms'`);
        }
        const resp = new COVIDSymptoms();
        const components = resource.component;
        if (components) {
            let temp;
            temp = components.find((c) => HeartValueSet.Common.Measurement.NASAL_CONGESTION.equals(c.code));
            resp.nasalCongestion = temp ? temp.value : false;
            temp = resource.component.find((obsComp) => HeartValueSet.Common.Measurement.SORE_THROAT.equals(obsComp.code));
            resp.soreThroat = temp ? temp.value : false;
            temp = resource.component.find((obsComp) => HeartValueSet.Common.Measurement.FEVER.equals(obsComp.code));
            resp.fever = temp ? temp.value : false;
            temp = resource.component.find((obsComp) => HeartValueSet.Common.Measurement.FATIGUE.equals(obsComp.code));
            resp.fatigue = temp ? temp.value : false;
            temp = resource.component.find((obsComp) => HeartValueSet.Common.Measurement.DRY_COUGH.equals(obsComp.code));
            if (temp) {
                resp.cough = temp.value;
                if (resp.cough) {
                    resp.coughType = CoughType.CoughTypeCategory.dry_cough;
                }
            }
            temp = resource.component.find((obsComp) => HeartValueSet.Common.Measurement.WET_COUGH.equals(obsComp.code));
            if (temp) {
                resp.cough = temp.value;
                if (resp.cough) {
                    resp.coughType = CoughType.CoughTypeCategory.wet_cough;
                }
            }
            temp = resource.component.find((obsComp) => HeartValueSet.Common.Measurement.LOSS_OF_TASTE_SMELL.equals(obsComp.code));
            resp.lossOfTasteAndSmell = temp ? temp.value : false;
            temp = resource.component.find((obsComp) => HeartValueSet.Common.Measurement.CONJUNCTIVITIS.equals(obsComp.code));
            resp.conjunctivitis = temp ? temp.value : false;
        }
        return resp;
    }
    toDataModelWeight(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.WEIGHT_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelWeight'`);
        }
        const weight = new Weight();
        if (resource.value instanceof Quantity) {
            weight.unit = WeightUnit[resource.value.unit];
            weight.value = resource.value.value;
        }
        else {
            throw new TypeError(`Unsupported value type for Weight element. Error converting to datamodel from FHIR. Found: ${resource.value}`);
        }
        return weight;
    }
    toDataModelHeight(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.HEIGHT_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelWeight'`);
        }
        const height = new Height();
        if (resource.value instanceof Quantity) {
            height.unit = LengthUnit[resource.value.unit];
            height.value = resource.value.value;
        }
        else {
            throw new TypeError('Unsupported value type for Height element. Error converting to datamodel from FHIR.');
        }
        return height;
    }
    toDataModelPhysicalInability(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.PHYSICAL_INABILITY_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelPhysicalInability'`);
        }
        const pi = new PhysicalInability();
        pi.valueAsBoolean = resource.value;
        return pi;
    }
    toDataModelLifeStyle(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.LIFESTYLE_CODING.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelLifeStyle'`);
        }
        const lf = new LifeStyle();
        // prettier-ignore
        if (resource.value instanceof CodeableConcept) {
            const v = resource.value;
            if (HeartValueSet.Common.LifeStyle.ACTIVE.equals(v)) {
                lf.value = LifeStyle.LifeStyleCategory.ACTIVE;
            }
            else if (HeartValueSet.Common.LifeStyle.ATHLETIC.equals(v)) {
                lf.value = LifeStyle.LifeStyleCategory.ATHLETIC;
            }
            else if (HeartValueSet.Common.LifeStyle.POORLY_ACTIVE.equals(v)) {
                lf.value = LifeStyle.LifeStyleCategory.POORLY_ACTIVE;
            }
            else if (HeartValueSet.Common.LifeStyle.SEDENTARY.equals(v)) {
                lf.value = LifeStyle.LifeStyleCategory.SEDENTARY;
            }
            else if (HeartValueSet.Common.LifeStyle.VERY_ACTIVE.equals(v)) {
                lf.value = LifeStyle.LifeStyleCategory.VERY_ACTIVE;
            }
            else {
                throw new TypeError('Unsupported value type for LifeStyle element. Error converting to datamodel from FHIR.');
            }
        }
        else {
            throw new TypeError('Unsupported value type for LifeStyle element. Error converting to datamodel from FHIR.');
        }
        return lf;
    }
    toDataModelSmoker(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.SMOKER_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelSmoker'`);
        }
        const smoker = new Smoker();
        smoker.valueAsBoolean = resource.value;
        return smoker;
    }
    toDataModelSupervisorRequired(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.SUPERVISOR_REQUIRED_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelSupervisorRequired'`);
        }
        const sr = new SupervisorRequired();
        sr.valueAsBoolean = resource.value;
        return sr;
    }
    toDataModelGenericMeasure(resource, context) {
        let measure = new GenericQuantitativeMeasure();
        measure.cvType = ModelToFHIRUtils.toCodedValueModel(resource.code);
        resource.effective;
        if (resource.value == undefined && resource.component?.length > 0) {
            // gestire i components
            if (!measure.components) {
                measure.components = [];
            }
            resource.component.forEach((c) => {
                measure.components.push(this.getValue(c));
            });
        }
        else {
            measure = this.getValue(resource);
        }
        // FIXME: it is done twice if the method is called internally from the global toDataModel
        // id
        measure.id = +resource.id;
        // status
        measure.status = resource.status;
        if (resource.method) {
            measure.method = ModelToFHIRUtils.toCodedValueModel(resource.method);
        }
        // fhir ID
        const fhirVersion = this.toFhirVersion(resource);
        // FhirVersionable is an interface so we can't do 'instanceof'
        if (measure.supportFhirVersion && !!measure.supportFhirVersion()) {
            measure.version = fhirVersion;
        }
        // measure.fhirId = this.toFhirID(resource);
        if (resource.subject) {
            measure.patient = ModelToFHIRUtils.stubFromRef(resource.subject); /* this.resolveSubject( resource.subject as FhirReference, resource, context );*/
        }
        if (resource.effective && resource.effective instanceof Date) {
            measure.assertedWhen = resource.effective;
        }
        // check the optional comments
        if (resource.note?.length > 0 && resource.note[0].text !== '') {
            measure.notes = resource.note?.map((note) => note?.text).pop();
            // let text : string = resource.text.div;
            // // removes the optional XML tags
            // if ( text.startsWith('<div>') && text.endsWith('</div>') ) {
            //     text = text.substring('<div>'.length, text.length - '</div>'.length);
            // }
            // measure.notes = resource.text.div;
        }
        return measure;
    }
    getValue(resource) {
        const toRet = new GenericQuantitativeMeasure();
        toRet.cvType = ModelToFHIRUtils.toCodedValueModel(resource.code);
        if (resource.value instanceof Quantity) {
            if (resource.value.code) {
                toRet.unit = new CodedValue(resource.value.system ?? Dictionary.UNIT_OF_MEASURE, resource.value.code);
            }
            toRet.unitLabel = resource.value.unit;
            toRet.value = resource.value.value;
        }
        else if (resource.value instanceof CodeableConcept) {
            toRet.cv = ModelToFHIRUtils.toCodedValueModel(resource.value);
        }
        else {
            throw new TypeError(`Unsupported value type for GenericQuantitativeMeasure element. Error converting to datamodel from FHIR. Found: ${resource.value}`);
        }
        return toRet;
    }
    toDataModelMeal(resource, context) {
        const meal = new Meal();
        meal.id = this.toFhirIDPart(resource);
        meal.version = this.toFhirVersion(resource);
        meal.assertedWhen = resource.effective;
        const extensions = resource.extension;
        if (extensions) {
            const mealType = HeartExtension.Meal.type.extractValueFromExtensions(extensions);
            meal.type = MealType[mealType.toUpperCase()];
            // if (!meal.type && mealType === 'BREAK') {
            //     meal.type = MealType.SNACK;
            // }
        }
        meal.foods = [];
        const foodComps = resource.component;
        if (foodComps) {
            foodComps.forEach((fc) => {
                const foodCode = fc.code;
                const food = new Food();
                meal.foods.push(food);
                // convert the 'foodCode' into a macrocategory
                if (foodCode) {
                    if (HeartValueSet.Common.Food.PASTA_RICE.equals(foodCode)) {
                        food.setType(Food.FoodType.PASTA_RICE);
                    }
                    else if (HeartValueSet.Common.Food.WHOLEMEAL_PASTA_RICE.equals(foodCode)) {
                        food.setType(Food.FoodType.WHOLEMEAL_PASTA_RICE);
                    }
                    else if (HeartValueSet.Common.Food.DRIED_LEGUMES.equals(foodCode)) {
                        food.setType(Food.FoodType.DRIED_LEGUMES);
                    }
                    else if (HeartValueSet.Common.Food.MEAT.equals(foodCode)) {
                        food.setType(Food.FoodType.MEAT);
                    }
                    else if (HeartValueSet.Common.Food.SWEETS.equals(foodCode)) {
                        food.setType(Food.FoodType.SWEETS);
                    }
                    else if (HeartValueSet.Common.Food.VEGETABLES.equals(foodCode)) {
                        food.setType(Food.FoodType.VEGETABLES);
                    }
                    else if (HeartValueSet.Common.Food.EGG.equals(foodCode)) {
                        food.setType(Food.FoodType.EGG);
                    }
                    else if (HeartValueSet.Common.Food.FISH.equals(foodCode)) {
                        food.setType(Food.FoodType.FISH);
                    }
                    else if (HeartValueSet.Common.Food.SAVORY_SNACK.equals(foodCode)) {
                        food.setType(Food.FoodType.SAVORY_SNACK);
                    }
                    else if (HeartValueSet.Common.Food.FRUIT.equals(foodCode)) {
                        food.setType(Food.FoodType.FRUIT);
                    }
                    else if (HeartValueSet.Common.Food.POTATOES.equals(foodCode)) {
                        food.setType(Food.FoodType.POTATOES);
                    }
                    else if (HeartValueSet.Common.Food.FRESH_DAIRY_PRODUCTS.equals(foodCode)) {
                        food.setType(Food.FoodType.FRESH_DAIRY_PRODUCTS);
                    }
                    else if (HeartValueSet.Common.Food.DRIED_FRUITS.equals(foodCode)) {
                        food.setType(Food.FoodType.DRIED_FRUITS);
                    }
                    else if (HeartValueSet.Common.Food.FAST_FOOD.equals(foodCode)) {
                        food.setType(Food.FoodType.FAST_FOOD);
                    }
                    else if (HeartValueSet.Common.Food.ALCOHOL.equals(foodCode)) {
                        food.setType(Food.FoodType.ALCOHOL);
                    }
                    else if (HeartValueSet.Common.Food.SUGARY_DRINKS.equals(foodCode)) {
                        food.setType(Food.FoodType.SUGARY_DRINKS);
                    }
                    else if (HeartValueSet.Common.Food.OIL.equals(foodCode)) {
                        food.setType(Food.FoodType.OIL);
                    }
                    else if (HeartValueSet.Common.Food.COLD_CUTS.equals(foodCode)) {
                        food.setType(Food.FoodType.COLD_CUTS);
                    }
                    else if (HeartValueSet.Common.Food.SEASONED_DAIRY_PRODUCTS.equals(foodCode)) {
                        food.setType(Food.FoodType.SEASONED_DAIRY_PRODUCTS);
                    }
                    else if (HeartValueSet.Common.Food.MILK_YOGURT.equals(foodCode)) {
                        food.setType(Food.FoodType.MILK_YOGURT);
                    }
                    else if (HeartValueSet.Common.Food.BREAD.equals(foodCode)) {
                        food.setType(Food.FoodType.BREAD);
                    }
                    else if (HeartValueSet.Common.Food.SALAD.equals(foodCode)) {
                        food.setType(Food.FoodType.SALAD);
                    }
                    else if (HeartValueSet.Common.Food.SUGAR.equals(foodCode)) {
                        food.setType(Food.FoodType.SUGAR);
                    }
                    else if (HeartValueSet.Common.Food.COOKIE.equals(foodCode)) {
                        food.setType(Food.FoodType.COOKIE);
                    }
                    else if (HeartValueSet.Common.Food.CROISSANT.equals(foodCode)) {
                        food.setType(Food.FoodType.CROISSANT);
                    }
                    else if (HeartValueSet.Common.Food.MARMALADE.equals(foodCode)) {
                        food.setType(Food.FoodType.MARMALADE);
                    }
                    else if (HeartValueSet.Common.Food.PIZZA.equals(foodCode)) {
                        food.setType(Food.FoodType.PIZZA);
                    }
                    // NEW in Heart
                    else if (HeartValueSet.Common.Food.FRESH_LEGUMES.equals(foodCode)) {
                        food.setType(Food.FoodType.FRESH_LEGUMES);
                    }
                    else if (HeartValueSet.Common.Food.CAKES.equals(foodCode)) {
                        food.setType(Food.FoodType.CAKES);
                    }
                    else if (HeartValueSet.Common.Food.ICE_CREAM.equals(foodCode)) {
                        food.setType(Food.FoodType.ICE_CREAM);
                    }
                    else if (HeartValueSet.Common.Food.BANANA.equals(foodCode)) {
                        food.setType(Food.FoodType.BANANA);
                    }
                    else if (HeartValueSet.Common.Food.SALT.equals(foodCode)) {
                        food.setType(Food.FoodType.SALT);
                    }
                }
                food.details = {
                    caloricIntake: fc.value.value,
                };
                if (fc.extension) {
                    fc.extension.forEach((fcExt) => {
                        const fcType = fcExt.url;
                        if (fcExt.value instanceof Quantity) {
                            const fcValue = fcExt.value.value;
                            // TODO Check the unit of measure used in the FHIR Quantity to avoid possibile inconsistencies
                            if (fcType === HeartExtension.Meal.foodWeight.url) {
                                food.details.weightInGrams = fcValue;
                            }
                            else if (fcType === HeartExtension.Meal.carbohydrates.url) {
                                food.details.carbsInKcal = fcValue;
                            }
                            else if (fcType === HeartExtension.Meal.proteins.url) {
                                food.details.proteinsInKcal = fcValue;
                            }
                            else if (fcType === HeartExtension.Meal.fats.url) {
                                food.details.fatsInKcal = fcValue;
                            }
                            else if (fcType === HeartExtension.Meal.fibers.url) {
                                food.details.fibersInGrams = fcValue;
                            }
                            else if (fcType === HeartExtension.Meal.sodium.url) {
                                food.details.sodiumInMilliGrams = fcValue;
                            }
                        }
                        else if (typeof fcExt.value === 'string') {
                            const fcValue = fcExt.value;
                            if (fcType === HeartExtension.Meal.portionSize.url) {
                                switch (fcValue) {
                                    case 'large':
                                        food.portionSize = Food.PortionSize.LARGE;
                                        break;
                                    case 'medium':
                                        food.portionSize = Food.PortionSize.MEDIUM;
                                        break;
                                    default:
                                    case 'small':
                                        food.portionSize = Food.PortionSize.SMALL;
                                        break;
                                }
                            }
                        }
                    });
                }
            });
        }
        return meal;
    }
    toDataModelBmi(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.BMI_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelBmi'`);
        }
        const bmi = new BMI();
        if (resource.value instanceof Quantity) {
            bmi.value = resource.value.value;
        }
        else {
            throw new TypeError('Unsupported value type for BMI element. Error converting to datamodel from FHIR.');
        }
        return bmi;
    }
    toDataModelWaist(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.WAIST_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelWaist'`);
        }
        const waist = new Waist();
        if (resource.value instanceof Quantity) {
            waist.unit = LengthUnit[resource.value.unit];
            waist.value = resource.value.value;
        }
        else {
            throw new TypeError('Unsupported value type for Waist element. Error converting to datamodel from FHIR.');
        }
        return waist;
    }
    toDataModelHeartRate(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.HEART_RATE_RESTING_CODING.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelHeartRate'`);
        }
        const hr = new HeartRate();
        if (resource.value instanceof Quantity) {
            hr.value = resource.value.value;
        }
        else {
            throw new TypeError('Unsupported value type for HeartRate element. Error converting to datamodel from FHIR.');
        }
        return hr;
    }
    toDataModelStepCount(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.STEPS_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelStepCount'`);
        }
        const sc = new StepCount();
        if (!!resource.value) {
            sc.value = resource.value;
        }
        else {
            throw new TypeError('Unsupported value type for StepCount element. Error converting to datamodel from FHIR.');
        }
        return sc;
    }
    toDataModelBodyTemperature(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.BODY_TEMPERATURE_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelBodyTemperature'`);
        }
        const bt = new BodyTemperature();
        if (resource.value instanceof Quantity) {
            bt.unit = TemperatureUnit[resource.value.unit];
            bt.value = resource.value.value;
        }
        else {
            throw new TypeError('Unsupported value type for BT element. Error converting to datamodel from FHIR.');
        }
        return bt;
    }
    toDataModelCholHdl(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.CHOLESTEROL_HDL_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelCholHdl'`);
        }
        const chol = new CholesterolHdl();
        if (resource.value instanceof Quantity) {
            chol.unit = ConcentrationUnit[resource.value.unit];
            chol.value = resource.value.value;
        }
        else {
            throw new TypeError('Unsupported value type for Cholesterol HDL element. Error converting to datamodel from FHIR.');
        }
        return chol;
    }
    toDataModelCholLdl(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.CHOLESTEROL_LDL_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelCholLdl'`);
        }
        const chol = new CholesterolLdl();
        if (resource.value instanceof Quantity) {
            chol.unit = ConcentrationUnit[resource.value.unit];
            chol.value = resource.value.value;
        }
        else {
            throw new TypeError('Unsupported value type for Cholesterol LDL element. Error converting to datamodel from FHIR.');
        }
        return chol;
    }
    toDataModelChol(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.CHOLESTEROL_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelChol'`);
        }
        const chol = new Cholesterol();
        if (resource.value instanceof Quantity) {
            chol.unit = ConcentrationUnit[resource.value.unit];
            chol.value = resource.value.value;
        }
        else {
            throw new TypeError('Unsupported value type for Cholesterol element. Error converting to datamodel from FHIR.');
        }
        return chol;
    }
    toDataModelTriglyceride(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.TRIGLYCERIDE_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelTriglyceride'`);
        }
        const tri = new Triglyceride();
        if (resource.value instanceof Quantity) {
            tri.unit = ConcentrationUnit[resource.value.unit];
            tri.value = resource.value.value;
        }
        else {
            throw new TypeError('Unsupported value type for Triglyceride element. Error converting to datamodel from FHIR.');
        }
        return tri;
    }
    toDataModelSpO2(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.SPO2_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelSpO2'`);
        }
        const meas = new SpO2();
        if (resource.value instanceof Quantity) {
            meas.unit = PercentageUnit[resource.value.unit];
            meas.value = resource.value.value;
        }
        else {
            throw new TypeError('Unsupported value type for SpO2 element. Error converting to datamodel from FHIR.');
        }
        return meas;
    }
    toDataModelHba1c(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.HBA1C_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelHba1c'`);
        }
        const meas = new Hba1c();
        if (resource.value instanceof Quantity) {
            meas.unit = PercentageUnit[resource.value.unit];
            meas.value = resource.value.value;
        }
        else {
            throw new TypeError('Unsupported value type for Hba1c element. Error converting to datamodel from FHIR.');
        }
        return meas;
    }
    toDataModelChestPain(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        let cp;
        if (HeartValueSet.Common.Measurement.CHEST_PAIN_CODINGS.equals(resource.code)) {
            cp = new ChestPainLevel();
        }
        else if (HeartValueSet.Common.Measurement.CHEST_PAIN_QUESTIONNAIRE.equals(resource.code)) {
            cp = new ChestPainQuestionnaire();
        }
        else {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelChestPain'`);
        }
        cp.value = resource.value;
        return cp;
    }
    toDataModelBloodGlucose(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.BLOOD_GLUCOSE_MOLES_CODINGS.equals(resource.code) && !HeartValueSet.Common.Measurement.BLOOD_GLUCOSE_MASS_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelBloodGlucose'`);
        }
        const bg = new BloodGlucose();
        if (resource.effective instanceof Date) {
            const hours = resource.effective.getHours();
            let isFasting = false;
            let isAfterMeal = false;
            if (resource.extension) {
                const measPoint = HeartExtension.BloodGlucose.measurePoint.extractValueFromExtensions(resource.extension);
                if (measPoint) {
                    switch (measPoint) {
                        case 'fasting':
                            bg.measPoint = FeedbackInAppTypeName.BG_P1;
                            break;
                        case 'after-breakfast':
                            bg.measPoint = FeedbackInAppTypeName.BG_P2;
                            break;
                        case 'before-lunch':
                            bg.measPoint = FeedbackInAppTypeName.BG_P3;
                            break;
                        case 'after-lunch':
                            bg.measPoint = FeedbackInAppTypeName.BG_P4;
                            break;
                        case 'before-dinner':
                            bg.measPoint = FeedbackInAppTypeName.BG_P5;
                            break;
                        case 'after-dinner':
                            bg.measPoint = FeedbackInAppTypeName.BG_P6;
                            break;
                        case 'before-sleeping':
                            bg.measPoint = FeedbackInAppTypeName.BG_P7;
                            break;
                    }
                }
                else {
                    // MAMMA MIA CHE PORCATA QUESTO MAPPING!!!
                    const fastingOrAfterMeal = HeartExtension.BloodGlucose.fastingOrAfterMealBloodSugar.extractValueFromExtensions(resource.extension);
                    if (fastingOrAfterMeal) {
                        isFasting = fastingOrAfterMeal === 'fasting-blood-sugar';
                        isAfterMeal = fastingOrAfterMeal === 'blood-sugar-at-two-hours-from-the-meal';
                        if (hours < 8 || isFasting) {
                            bg.measPoint = FeedbackInAppTypeName.BG_P1;
                        }
                        else if (hours < 10 && isAfterMeal) {
                            bg.measPoint = FeedbackInAppTypeName.BG_P2;
                        }
                        else if (hours < 14 && !isAfterMeal) {
                            bg.measPoint = FeedbackInAppTypeName.BG_P3;
                        }
                        else if (hours < 17 && isAfterMeal) {
                            bg.measPoint = FeedbackInAppTypeName.BG_P4;
                        }
                        else if (hours < 20 && !isAfterMeal) {
                            bg.measPoint = FeedbackInAppTypeName.BG_P5;
                        }
                        else if (hours < 23 && isAfterMeal) {
                            bg.measPoint = FeedbackInAppTypeName.BG_P6;
                        }
                        else {
                            bg.measPoint = FeedbackInAppTypeName.BG_P7;
                        }
                    }
                }
            }
        }
        // INSULIN extension
        const insulinCode = HeartExtension.BloodGlucose.drugStatement.extractValueFromExtensions(resource?.extension)?.toString()?.toUpperCase();
        bg.insulin = BloodGlucose.DrugStatement[insulinCode?.toUpperCase()];
        if (resource.value instanceof Quantity) {
            bg.unit = ConcentrationUnit[resource.value.unit];
            bg.value = resource.value.value;
        }
        else {
            throw new TypeError('Unsupported value type for BloodGlucose element. Error converting to datamodel from FHIR.');
        }
        return bg;
    }
    toDataModelBloodPressure(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.BLOOD_PRESSURE_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelBloodPressure'`);
        }
        const bp = new BloodPressure();
        if (resource.component) {
            const diasComp = resource.component.find((obsComp) => HeartValueSet.Common.Measurement.DIASTOLIC_BLOOD_PRESSURE_CODINGS.equals(obsComp.code));
            if (diasComp) {
                const v = diasComp.value;
                const diasObs = new DiastolicBloodPressure(v.value);
                bp.diastolic = diasObs;
            }
            const sysComp = resource.component.find((obsComp) => HeartValueSet.Common.Measurement.SYSTOLIC_BLOOD_PRESSURE_CODINGS.equals(obsComp.code));
            if (sysComp) {
                const v = sysComp.value;
                const sysObs = new DiastolicBloodPressure(v.value);
                bp.systolic = sysObs;
            }
        }
        return bp;
    }
    toDataModelTTM(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.TTM_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelTTM'`);
        }
        const sf = new TTM();
        if (resource.value instanceof CodeableConcept) {
            const code = resource.value.coding[0].code.toUpperCase();
            sf.value = TTM.TTMCategory[code].toString();
        }
        else {
            throw new TypeError('Unsupported value type for TTM element. Error converting to datamodel from FHIR.');
        }
        return sf;
    }
    toDataModelSmokingFrequency(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        // && !HeartValueSet.Common.Measurement.SMOKING_FREQ_CODINGS.equals( resource.code )
        if (!HeartValueSet.Common.Measurement.CIGARETTES_DAILY_AMOUNT_CODINGS.equals(resource.code)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelSmokingFrequency'`);
        }
        const sf = new SmokingFrequency();
        // fhir version
        sf.version = this.toFhirVersion(resource);
        // sf.fhirId = this.toFhirID(resource);
        if (resource.value instanceof Quantity) {
            const v = resource.value.value;
            if (v === 0) {
                sf.value = SmokingFrequency.SmokingFrequencyCategory.exactly_0_cigarettes_per_day;
            }
            else if (v <= 5) {
                sf.value = SmokingFrequency.SmokingFrequencyCategory.lt_eq_5_cigarettes_per_day;
            }
            else if (v <= 10) {
                sf.value = SmokingFrequency.SmokingFrequencyCategory.lt_eq_10_cigarettes_per_day;
            }
            else if (v <= 15) {
                sf.value = SmokingFrequency.SmokingFrequencyCategory.lt_eq_15_cigarettes_per_day;
            }
            else if (v <= 20) {
                sf.value = SmokingFrequency.SmokingFrequencyCategory.lt_eq_20_cigarettes_per_day;
            }
            else {
                sf.value = SmokingFrequency.SmokingFrequencyCategory.more_than_20_cigarettes_per_day;
            }
        }
        else if (resource.value instanceof Range) {
            const lValue = resource.value.low ? resource.value.low.value : undefined;
            const hValue = resource.value.high ? resource.value.high.value : undefined;
            if (lValue >= 1 && hValue <= 5) {
                sf.value = SmokingFrequency.SmokingFrequencyCategory.lt_eq_5_cigarettes_per_day;
            }
            else if (lValue >= 6 && hValue <= 10) {
                sf.value = SmokingFrequency.SmokingFrequencyCategory.lt_eq_10_cigarettes_per_day;
            }
            else if (lValue >= 11 && hValue <= 15) {
                sf.value = SmokingFrequency.SmokingFrequencyCategory.lt_eq_15_cigarettes_per_day;
            }
            else if (lValue >= 16 && hValue <= 20) {
                sf.value = SmokingFrequency.SmokingFrequencyCategory.lt_eq_20_cigarettes_per_day;
            }
            else if (lValue >= 21) {
                sf.value = SmokingFrequency.SmokingFrequencyCategory.more_than_20_cigarettes_per_day;
            }
            else {
                sf.value = SmokingFrequency.SmokingFrequencyCategory.exactly_0_cigarettes_per_day;
            }
        }
        else if (resource.value instanceof CodeableConcept) {
            const code = resource.value.coding[0].code;
            sf.value = SmokingFrequency.SmokingFrequencyCategory[code].toString();
        }
        else {
            throw new TypeError('Unsupported value type for SmokingFrequency element. Error converting to datamodel from FHIR.');
        }
        return sf;
    }
    fromDataModelMeal(meal) {
        const obs = new Observation();
        // save local id for future referencing
        obs._id = meal.id;
        if (meal.fhirId) {
            obs.id = meal.fhirId.startsWith('Observation') ? meal.fhirId.substring('Observation/'.length) : meal.fhirId;
        }
        else {
            obs.id = AbstractApi.generateRandomIDDt();
        }
        obs.extension = [];
        obs.category = [HeartValueSet.Common.MeasurementCategory.NUTRITION_CATEGORY.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.MEAL_CODINGS.toCodeableConcept();
        // paziente/soggetto
        if (meal.patient === undefined) {
            throw Error('Patient not found while converting the meal.');
        }
        obs.subject = ModelToFHIRUtils.getReference(meal.patient);
        obs.performer = [ModelToFHIRUtils.getReference(meal.patient)];
        obs.effective = new Date(meal.assertedWhen);
        obs.component = [];
        if (meal.foods) {
            meal.foods.forEach((food) => {
                const component = new Observation.ObservationComponentComponent();
                component.extension = [];
                obs.component.push(component);
                // component.code = new FhirCodeableConcept();
                // const cCoding = new FhirCoding();
                // component.code.coding = [ cCoding ];
                // cCoding.system = Dictionary.BASE_NAMESPACE;
                // cCoding.display = '';
                switch (food.type) {
                    case Food.FoodType.PASTA_RICE:
                        component.code = HeartValueSet.Common.Food.PASTA_RICE.toCodeableConcept();
                        break;
                    case Food.FoodType.WHOLEMEAL_PASTA_RICE:
                        component.code = HeartValueSet.Common.Food.WHOLEMEAL_PASTA_RICE.toCodeableConcept();
                        break;
                    case Food.FoodType.DRIED_LEGUMES:
                        component.code = HeartValueSet.Common.Food.DRIED_LEGUMES.toCodeableConcept();
                        break;
                    case Food.FoodType.MEAT:
                        component.code = HeartValueSet.Common.Food.MEAT.toCodeableConcept();
                        break;
                    case Food.FoodType.SWEETS:
                        component.code = HeartValueSet.Common.Food.SWEETS.toCodeableConcept();
                        break;
                    case Food.FoodType.VEGETABLES:
                        component.code = HeartValueSet.Common.Food.VEGETABLES.toCodeableConcept();
                        break;
                    case Food.FoodType.EGG:
                        component.code = HeartValueSet.Common.Food.EGG.toCodeableConcept();
                        break;
                    case Food.FoodType.FISH:
                        component.code = HeartValueSet.Common.Food.FISH.toCodeableConcept();
                        break;
                    case Food.FoodType.SAVORY_SNACK:
                        component.code = HeartValueSet.Common.Food.SAVORY_SNACK.toCodeableConcept();
                        break;
                    case Food.FoodType.FRUIT:
                        component.code = HeartValueSet.Common.Food.FRUIT.toCodeableConcept();
                        break;
                    case Food.FoodType.POTATOES:
                        component.code = HeartValueSet.Common.Food.POTATOES.toCodeableConcept();
                        break;
                    case Food.FoodType.FRESH_DAIRY_PRODUCTS:
                        component.code = HeartValueSet.Common.Food.FRESH_DAIRY_PRODUCTS.toCodeableConcept();
                        break;
                    case Food.FoodType.DRIED_FRUITS:
                        component.code = HeartValueSet.Common.Food.DRIED_FRUITS.toCodeableConcept();
                        break;
                    case Food.FoodType.FAST_FOOD:
                        component.code = HeartValueSet.Common.Food.FAST_FOOD.toCodeableConcept();
                        break;
                    case Food.FoodType.ALCOHOL:
                        component.code = HeartValueSet.Common.Food.ALCOHOL.toCodeableConcept();
                        break;
                    case Food.FoodType.SUGARY_DRINKS:
                        component.code = HeartValueSet.Common.Food.SUGARY_DRINKS.toCodeableConcept();
                        break;
                    case Food.FoodType.OIL:
                        component.code = HeartValueSet.Common.Food.OIL.toCodeableConcept();
                        break;
                    case Food.FoodType.COLD_CUTS:
                        component.code = HeartValueSet.Common.Food.COLD_CUTS.toCodeableConcept();
                        break;
                    case Food.FoodType.SEASONED_DAIRY_PRODUCTS:
                        component.code = HeartValueSet.Common.Food.SEASONED_DAIRY_PRODUCTS.toCodeableConcept();
                        break;
                    case Food.FoodType.MILK_YOGURT:
                        component.code = HeartValueSet.Common.Food.MILK_YOGURT.toCodeableConcept();
                        break;
                    case Food.FoodType.BREAD:
                        component.code = HeartValueSet.Common.Food.BREAD.toCodeableConcept();
                        break;
                    case Food.FoodType.SALAD:
                        component.code = HeartValueSet.Common.Food.SALAD.toCodeableConcept();
                        break;
                    case Food.FoodType.SUGAR:
                        component.code = HeartValueSet.Common.Food.SUGAR.toCodeableConcept();
                        break;
                    case Food.FoodType.COOKIE:
                        component.code = HeartValueSet.Common.Food.COOKIE.toCodeableConcept();
                        break;
                    case Food.FoodType.CROISSANT:
                        component.code = HeartValueSet.Common.Food.CROISSANT.toCodeableConcept();
                        break;
                    case Food.FoodType.MARMALADE:
                        component.code = HeartValueSet.Common.Food.MARMALADE.toCodeableConcept();
                        break;
                    case Food.FoodType.PIZZA:
                        component.code = HeartValueSet.Common.Food.PIZZA.toCodeableConcept();
                        break;
                    // NEW IN HEART
                    case Food.FoodType.FRESH_LEGUMES:
                        component.code = HeartValueSet.Common.Food.FRESH_LEGUMES.toCodeableConcept();
                        break;
                    case Food.FoodType.CAKES:
                        component.code = HeartValueSet.Common.Food.CAKES.toCodeableConcept();
                        break;
                    case Food.FoodType.ICE_CREAM:
                        component.code = HeartValueSet.Common.Food.ICE_CREAM.toCodeableConcept();
                        break;
                    case Food.FoodType.BANANA:
                        component.code = HeartValueSet.Common.Food.BANANA.toCodeableConcept();
                        break;
                    case Food.FoodType.SALT:
                        component.code = HeartValueSet.Common.Food.SALT.toCodeableConcept();
                        break;
                }
                const det = food.details;
                // caloric intake in kcal
                component.value = this.createQuantity(det.caloricIntake, 'kcal');
                const carbsExt = this.createQuantity(det.carbsInKcal, 'kcal');
                component.extension.push(HeartExtension.Meal.carbohydrates.toExtensionQuantity(carbsExt));
                const fatsExt = this.createQuantity(det.fatsInKcal, 'kcal');
                component.extension.push(HeartExtension.Meal.fats.toExtensionQuantity(fatsExt));
                const fibersExt = this.createQuantity(det.fibersInGrams, 'g');
                component.extension.push(HeartExtension.Meal.fibers.toExtensionQuantity(fibersExt));
                const sodiumExt = this.createQuantity(det.sodiumInMilliGrams, 'mg');
                component.extension.push(HeartExtension.Meal.sodium.toExtensionQuantity(sodiumExt));
                const proteinsExt = this.createQuantity(det.proteinsInKcal, 'kcal');
                component.extension.push(HeartExtension.Meal.proteins.toExtensionQuantity(proteinsExt));
                const unit = food.type === Food.FoodType.ALCOHOL || food.type === Food.FoodType.SUGARY_DRINKS ? 'ml' : 'g';
                const weightExt = this.createQuantity(det.weightInGrams, unit);
                component.extension.push(HeartExtension.Meal.foodWeight.toExtensionQuantity(weightExt));
                let portionSizeExt;
                switch (food.portionSize) {
                    case (food.portionSize = Food.PortionSize.LARGE):
                        portionSizeExt = 'large';
                        break;
                    case (food.portionSize = Food.PortionSize.MEDIUM):
                        portionSizeExt = 'medium';
                        break;
                    default:
                    case (food.portionSize = Food.PortionSize.SMALL):
                        portionSizeExt = 'small';
                        break;
                }
                component.extension.push(HeartExtension.Meal.portionSize.toExtensionString(portionSizeExt));
            });
        }
        if (meal.type) {
            let valueTypeCode;
            switch (meal.type) {
                default:
                case MealType.SNACK:
                    valueTypeCode = 'SNACK';
                    break;
                case MealType.BREAKFAST:
                    valueTypeCode = 'BREAKFAST';
                    break;
                case MealType.LUNCH:
                    valueTypeCode = 'LUNCH';
                    break;
                case MealType.DINNER:
                    valueTypeCode = 'DINNER';
                    break;
            }
            obs.extension.push(HeartExtension.Meal.type.toExtensionString(valueTypeCode));
        }
        return obs;
    }
    fromDataModelMeasure(measure) {
        // choose the best converter (note: I'm avoiding the use of polymorphism)
        let obs;
        if (measure instanceof QuantitativeMeasure) {
            if (measure instanceof Weight) {
                obs = this.fromDataModelWeight(measure);
            }
            else if (measure instanceof Height) {
                obs = this.fromDataModelHeight(measure);
            }
            else if (measure instanceof Waist) {
                obs = this.fromDataModelWaist(measure);
            }
            else if (measure instanceof BMI) {
                obs = this.fromDataModelBmi(measure);
            }
            else if (measure instanceof SupervisorRequired) {
                obs = this.fromDataModelSupervisorRequired(measure);
            }
            else if (measure instanceof PhysicalInability) {
                obs = this.fromDataModelPhysicalInability(measure);
            }
            else if (measure instanceof StepCount) {
                obs = this.fromDataModelStepCount(measure);
            }
            else if (measure instanceof Smoker) {
                obs = this.fromDataModelSmoker(measure);
            }
            else if (measure instanceof LifeStyle) {
                obs = this.fromDataModelLifeStyle(measure);
            }
            else if (measure instanceof Hba1c) {
                obs = this.fromDataModelHbA1c(measure);
            }
            else if (measure instanceof SpO2) {
                obs = this.fromDataModelSpO2(measure);
            }
            else if (measure instanceof Cholesterol) {
                obs = this.fromDataModelCholesterol(measure);
            }
            else if (measure instanceof CholesterolLdl) {
                obs = this.fromDataModelCholesterolLdl(measure);
            }
            else if (measure instanceof CholesterolHdl) {
                obs = this.fromDataModelCholesterolHdl(measure);
            }
            else if (measure instanceof Triglyceride) {
                obs = this.fromDataModelTriglyceride(measure);
            }
            else if (measure instanceof BloodPressure) {
                obs = this.fromDataModelBloodPressure(measure);
            }
            else if (measure instanceof BloodGlucose) {
                obs = this.fromDataModelBloodGlucose(measure);
            }
            else if (measure instanceof DiastolicBloodPressure) {
                throw new TypeError('Bad conversion format for DiastolicBloodPressure');
                // obs = this.fromDataModelDiastolicBloodPressure(measure);
            }
            else if (measure instanceof SystolicBloodPressure) {
                throw new TypeError('Bad conversion format for SystolicBloodPressure');
                // obs = this.fromDataModelSystolicBloodPressure(measure);
            }
            else if (measure instanceof HeartRate) {
                obs = this.fromDataModelHeartRate(measure);
                // } else if (measure instanceof FatsDailyIntake) {
                //     obs = this.fromDataModelFatsDailyIntake(measure);
                // } else if (measure instanceof FibersDailyIntake) {
                //     obs = this.fromDataModelFibersDailyIntake(measure);
                // } else if (measure instanceof SodiumDailyIntake) {
                //     obs = this.fromDataModelSodiumDailyIntake(measure);
                // } else if (measure instanceof ProteinsDailyIntake) {
                //     obs = this.fromDataModelProteinsDailyIntake(measure);
                // } else if (measure instanceof CarbohydratesDailyIntake) {
                //     obs = this.fromDataModelCarbohydratesDailyIntake(measure);
                // } else if (measure instanceof CaloricDailyIntake) {
                //     obs = this.fromDataModelCaloricDailyIntake(measure);
            }
            else if (measure instanceof BodyTemperature) {
                obs = this.fromDataModelBodyTemperature(measure);
            }
            else if (measure instanceof ChestPainLevel || measure instanceof ChestPainQuestionnaire) {
                obs = this.fromDataModelChestPain(measure);
            }
            else if (measure instanceof GenericQuantitativeMeasure) {
                obs = this.fromDataModelGenericQuantitativeMeasure(measure);
            }
        }
        else if (measure instanceof CategoryMeasure) {
            if (measure instanceof SmokingFrequency) {
                obs = this.fromDataModelSmokingFrequency(measure);
            }
            else if (measure instanceof TTM) {
                obs = this.fromDataModelTTM(measure);
            }
            else if (measure instanceof PatientHealthStatus) {
                obs = this.fromDataModelHealthStatus(measure);
            }
        }
        else if (measure instanceof COVIDSymptoms) {
            // COVIDSymptoms is neither Category, nor Quantitative... it should be Qualitative
            obs = this.fromDataModelCovidSymptoms(measure);
        }
        if (!obs) {
            throw new TypeError(`Unsupported measure type ${measure.constructor.name}. Error converting from datamodel to FHIR.`);
        }
        const patient = measure.patient;
        if (patient === undefined) {
            throw Error('Patient not found while converting the measure.');
        }
        // fhir ID
        if (measure.fhirId) {
            obs.id = measure.fhirId.startsWith('Observation') ? measure.fhirId.substring('Observation/'.length) : measure.fhirId;
        }
        else {
            obs.id = AbstractApi.generateRandomIDDt();
        }
        // measure datetime
        obs.effective = measure.assertedWhen;
        // the patient (system's user is the implicit subject)
        obs.subject = ModelToFHIRUtils.getReference(patient);
        obs.status = measure.status ?? Observation.ObservationStatus.FINAL.toString();
        if (measure.method) {
            obs.method = ModelToFHIRUtils.fromCodedValueModel(measure.method);
        }
        // measure comments
        if (measure.notes) {
            const ann = new Annotation();
            ann.text = measure.notes;
            obs.note = [ann];
        }
        // measure source
        if (measure.healthId) {
            if (!obs.extension) {
                obs.extension = [];
            }
            obs.extension.push(HeartExtension.Workout.healthId.toExtensionString(measure.healthId));
            if (measure.healthSource) {
                obs.extension.push(HeartExtension.Workout.healthSource.toExtensionString(measure.healthSource));
            }
        }
        return obs;
    }
    fromDataModelHealthStatus(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.SURVEY.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.PATIENT_HEALTH_STATUS_CODING.toCodeableConcept();
        switch (measure.value) {
            default:
            case PatientHealthStatus.PatientHealthStatusCategory.POOR:
                obs.value = HeartValueSet.Common.Measurement.GENERAL_HEALTH_POOR_CODING.toCodeableConcept();
                break;
            case PatientHealthStatus.PatientHealthStatusCategory.FAIR:
                obs.value = HeartValueSet.Common.Measurement.GENERAL_HEALTH_FAIR_CODING.toCodeableConcept();
                break;
            case PatientHealthStatus.PatientHealthStatusCategory.GOOD:
                obs.value = HeartValueSet.Common.Measurement.GENERAL_HEALTH_GOOD_CODING.toCodeableConcept();
                break;
        }
        return obs;
    }
    fromDataModelCovidSymptoms(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.code = HeartValueSet.Common.Measurement.COVID_SURVEY.toCodeableConcept();
        obs.category = [HeartValueSet.Common.MeasurementCategory.SURVEY.toCodeableConcept()];
        obs.component = [];
        if (measure.nasalCongestion) {
            const c = new Observation.ObservationComponentComponent();
            c.code = HeartValueSet.Common.Measurement.NASAL_CONGESTION.toCodeableConcept();
            c.value = true;
            obs.component.push(c);
        }
        if (measure.soreThroat) {
            const c = new Observation.ObservationComponentComponent();
            c.code = HeartValueSet.Common.Measurement.SORE_THROAT.toCodeableConcept();
            c.value = true;
            obs.component.push(c);
        }
        if (measure.fever) {
            const c = new Observation.ObservationComponentComponent();
            c.code = HeartValueSet.Common.Measurement.FEVER.toCodeableConcept();
            c.value = true;
            obs.component.push(c);
        }
        if (measure.fatigue) {
            const c = new Observation.ObservationComponentComponent();
            c.code = HeartValueSet.Common.Measurement.FATIGUE.toCodeableConcept();
            c.value = true;
            obs.component.push(c);
        }
        if (measure.lossOfTasteAndSmell) {
            const c = new Observation.ObservationComponentComponent();
            c.code = HeartValueSet.Common.Measurement.LOSS_OF_TASTE_SMELL.toCodeableConcept();
            c.value = true;
            obs.component.push(c);
        }
        if (measure.conjunctivitis) {
            const c = new Observation.ObservationComponentComponent();
            c.code = HeartValueSet.Common.Measurement.CONJUNCTIVITIS.toCodeableConcept();
            c.value = true;
            obs.component.push(c);
        }
        if (measure.cough) {
            const c = new Observation.ObservationComponentComponent();
            if (measure.coughType.toString() === CoughType.CoughTypeCategory[CoughType.CoughTypeCategory.dry_cough]) {
                c.code = HeartValueSet.Common.Measurement.DRY_COUGH.toCodeableConcept();
            }
            else {
                c.code = HeartValueSet.Common.Measurement.WET_COUGH.toCodeableConcept();
            }
            c.value = true;
            obs.component.push(c);
        }
        return obs;
    }
    fromDataModelWeight(weight) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.WEIGHT_CODINGS.toCodeableConcept();
        const v = new Quantity();
        // convertire il valore locale in Kg
        v.unit = WeightUnit[WeightUnit.kg];
        v.code = WeightUnit[WeightUnit.kg];
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.value = this.roundValue(weight.valueIn(WeightUnit.kg), 2);
        obs.value = v;
        return obs;
    }
    fromDataModelWaist(waist) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.WAIST_CODINGS.toCodeableConcept();
        const v = new Quantity();
        // convertire il valore locale in cm
        v.unit = LengthUnit[LengthUnit.cm];
        v.code = LengthUnit[LengthUnit.cm];
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.value = this.roundValue(waist.valueIn(LengthUnit.cm), 2);
        obs.value = v;
        return obs;
    }
    fromDataModelHeight(height) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.HEIGHT_CODINGS.toCodeableConcept();
        const v = new Quantity();
        // convertire il valore locale in m
        v.unit = LengthUnit[LengthUnit.m];
        v.code = LengthUnit[LengthUnit.m];
        v.system = Dictionary.UNIT_OF_MEASURE;
        // ISSUE: v.value è un number quindi non posso aggiustare la precision che richiede il tipo string
        v.value = this.roundValue(height.valueIn(LengthUnit.m), 2);
        obs.value = v;
        return obs;
    }
    fromDataModelBmi(bmi) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.BMI_CODINGS.toCodeableConcept();
        const v = new Quantity();
        v.code = 'kg/m2';
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.unit = bmi.unit;
        v.value = this.roundValue(bmi.valueIn(), 2);
        obs.value = v;
        return obs;
    }
    fromDataModelSupervisorRequired(sr) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.SUPERVISOR_REQUIRED_CODINGS.toCodeableConcept();
        obs.value = sr.valueAsBoolean;
        return obs;
    }
    fromDataModelPhysicalInability(sr) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.PHYSICAL_INABILITY_CODINGS.toCodeableConcept();
        obs.value = sr.valueAsBoolean;
        return obs;
    }
    fromDataModelSmoker(sr) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.SMOKER_CODINGS.toCodeableConcept();
        obs.value = sr.valueAsBoolean;
        return obs;
    }
    fromDataModelLifeStyle(lf) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.LIFESTYLE_CODING.toCodeableConcept();
        switch (lf.value) {
            default:
            case LifeStyle.LifeStyleCategory.SEDENTARY:
                obs.value = HeartValueSet.Common.LifeStyle.SEDENTARY.toCodeableConcept();
                break;
            case LifeStyle.LifeStyleCategory.ACTIVE:
                obs.value = HeartValueSet.Common.LifeStyle.ACTIVE.toCodeableConcept();
                break;
            case LifeStyle.LifeStyleCategory.ATHLETIC:
                obs.value = HeartValueSet.Common.LifeStyle.ATHLETIC.toCodeableConcept();
                break;
            case LifeStyle.LifeStyleCategory.POORLY_ACTIVE:
                obs.value = HeartValueSet.Common.LifeStyle.POORLY_ACTIVE.toCodeableConcept();
                break;
            case LifeStyle.LifeStyleCategory.VERY_ACTIVE:
                obs.value = HeartValueSet.Common.LifeStyle.VERY_ACTIVE.toCodeableConcept();
                break;
        }
        return obs;
    }
    fromDataModelHbA1c(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.HBA1C_CODINGS.toCodeableConcept();
        const v = new Quantity();
        v.code = '%';
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.unit = '%';
        v.value = this.roundValue(measure.valueIn(), 2);
        obs.value = v;
        return obs;
    }
    fromDataModelSpO2(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.SPO2_CODINGS.toCodeableConcept();
        const v = new Quantity();
        v.code = '%';
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.unit = '%';
        v.value = this.roundValue(measure.valueIn(), 2);
        obs.value = v;
        return obs;
    }
    fromDataModelCholesterol(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.CHOLESTEROL_CODINGS.toCodeableConcept();
        const v = new Quantity();
        v.code = measure.unit.toString();
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.unit = measure.unit.toString();
        v.value = this.roundValue(measure.value, 0);
        obs.value = v;
        return obs;
    }
    fromDataModelCholesterolLdl(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.CHOLESTEROL_LDL_CODINGS.toCodeableConcept();
        const v = new Quantity();
        v.code = measure.unit.toString();
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.unit = measure.unit.toString();
        v.value = this.roundValue(measure.value);
        obs.value = v;
        return obs;
    }
    fromDataModelCholesterolHdl(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.CHOLESTEROL_HDL_CODINGS.toCodeableConcept();
        const v = new Quantity();
        v.code = measure.unit.toString();
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.unit = measure.unit.toString();
        v.value = this.roundValue(measure.value);
        obs.value = v;
        return obs;
    }
    fromDataModelTriglyceride(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.TRIGLYCERIDE_CODINGS.toCodeableConcept();
        const v = new Quantity();
        v.code = measure.unit.toString();
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.unit = measure.unit.toString();
        v.value = this.roundValue(measure.value);
        obs.value = v;
        return obs;
    }
    fromDataModelBloodGlucose(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        if (measure.unit === ConcentrationUnit.mgdL) {
            obs.code = HeartValueSet.Common.Measurement.BLOOD_GLUCOSE_MASS_CODINGS.toCodeableConcept();
        }
        else {
            obs.code = HeartValueSet.Common.Measurement.BLOOD_GLUCOSE_MOLES_CODINGS.toCodeableConcept();
        }
        obs.extension = [];
        let isAfterMeal = false;
        let isFasting = false;
        let measPointCode;
        switch (measure.measPoint) {
            case FeedbackInAppTypeName.BG_P1:
                measPointCode = 'fasting';
                isFasting = true;
                break;
            case FeedbackInAppTypeName.BG_P2:
                measPointCode = 'after-breakfast';
                isAfterMeal = true;
                break;
            case FeedbackInAppTypeName.BG_P3:
                measPointCode = 'before-lunch';
                break;
            case FeedbackInAppTypeName.BG_P4:
                measPointCode = 'after-lunch';
                isAfterMeal = true;
                break;
            case FeedbackInAppTypeName.BG_P5:
                measPointCode = 'before-dinner';
                break;
            case FeedbackInAppTypeName.BG_P6:
                measPointCode = 'after-dinner';
                isAfterMeal = true;
                break;
            case FeedbackInAppTypeName.BG_P7:
                measPointCode = 'before-sleeping';
                break;
        }
        obs.extension.push(HeartExtension.BloodGlucose.measurePoint.toExtensionString(measPointCode));
        if (isFasting) {
            obs.extension.push(HeartExtension.BloodGlucose.fastingOrAfterMealBloodSugar.toExtensionString('fasting-blood-sugar'));
        }
        if (isAfterMeal) {
            obs.extension.push(HeartExtension.BloodGlucose.fastingOrAfterMealBloodSugar.toExtensionString('blood-sugar-at-two-hours-from-the-meal'));
        }
        // INSULIN extension
        if (measure.insulin) {
            obs.extension.push(HeartExtension.BloodGlucose.drugStatement.toExtensionString(measure.insulin.toString().toLowerCase()));
        }
        const v = new Quantity();
        v.code = measure.unit.toString();
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.unit = measure.unit ? measure.unit.toString() : undefined;
        v.value = this.roundValue(measure.value);
        obs.value = v;
        return obs;
    }
    fromDataModelBloodPressure(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.BLOOD_PRESSURE_CODINGS.toCodeableConcept();
        obs.component = [];
        if (measure.diastolic) {
            const diaObsComponent = new Observation.ObservationComponentComponent();
            diaObsComponent.code = HeartValueSet.Common.Measurement.DIASTOLIC_BLOOD_PRESSURE_CODINGS.toCodeableConcept();
            const v = new Quantity();
            v.code = measure.diastolic.unit;
            v.system = Dictionary.UNIT_OF_MEASURE;
            v.unit = measure.diastolic.unit;
            v.value = this.roundValue(measure.diastolic.value);
            diaObsComponent.value = v;
            obs.component.push(diaObsComponent);
        }
        if (measure.systolic) {
            const sysObsComponent = new Observation.ObservationComponentComponent();
            sysObsComponent.code = HeartValueSet.Common.Measurement.SYSTOLIC_BLOOD_PRESSURE_CODINGS.toCodeableConcept();
            const v = new Quantity();
            v.code = measure.systolic.unit;
            v.system = Dictionary.UNIT_OF_MEASURE;
            v.unit = measure.systolic.unit;
            v.value = this.roundValue(measure.systolic.value);
            sysObsComponent.value = v;
            obs.component.push(sysObsComponent);
        }
        return obs;
    }
    fromDataModelGenericQuantitativeMeasure(measure) {
        const obs = new Observation();
        obs.id = !!measure.id ? measure.id + '' : AbstractApi.generateRandomIDDt();
        obs.code = FhirUtils.createCodeableConcept(measure.cvType.system, measure.cvType.code, measure.cvType.uniqueLabelKey);
        if (measure.components) {
            obs.component = [];
            measure.components.forEach((c) => {
                const comp = new Observation.ObservationComponentComponent();
                comp.code = FhirUtils.createCodeableConcept(c.cvType.system, c.cvType.code, c.cvType.uniqueLabelKey);
                this.setQuantityToObservation(c, comp);
                obs.component.push(comp);
            });
        }
        else {
            this.setQuantityToObservation(measure, obs);
        }
        obs.effective = measure.assertedWhen;
        if (measure.notes) {
            const ann = new Annotation();
            ann.text = measure.notes;
            obs.note = [ann];
        }
        return obs;
    }
    setQuantityToObservation(measure, obs) {
        if (measure?.cv) {
            // codedValue selected from dropdown
            const s = FhirUtils.createCodeableConcept(measure.cv.system, measure.cv.code, measure.cv.display);
            obs.value = s;
        }
        else if (measure?.value) {
            // numeric value
            const v = new Quantity();
            v.code = measure.unit?.code;
            v.system = measure.unit?.system;
            v.unit = measure.unit?.display;
            v.value = measure.value;
            obs.value = v;
        }
        return obs;
    }
    fromDataModelHeartRate(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.HEART_RATE_RESTING_CODING.toCodeableConcept();
        const v = new Quantity();
        v.code = '/min';
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.unit = 'beats/minute';
        v.value = this.roundValue(measure.value);
        obs.value = v;
        return obs;
    }
    fromDataModelFatsDailyIntake(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.FATS_DAILY_INTAKE_CODINGS.toCodeableConcept();
        const v = new Quantity();
        v.code = '%';
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.unit = '%';
        v.value = this.roundValue(measure.value);
        obs.value = v;
        return obs;
    }
    fromDataModelFibersDailyIntake(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.FIBERS_DAILY_INTAKE_CODINGS.toCodeableConcept();
        const v = new Quantity();
        v.code = '%';
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.unit = '%';
        v.value = this.roundValue(measure.value);
        obs.value = v;
        return obs;
    }
    fromDataModelSodiumDailyIntake(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.SODIUM_DAILY_INTAKE_CODINGS.toCodeableConcept();
        const v = new Quantity();
        v.code = '%';
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.unit = '%';
        v.value = this.roundValue(measure.value);
        obs.value = v;
        return obs;
    }
    fromDataModelProteinsDailyIntake(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.PROTEINS_DAILY_INTAKE_CODINGS.toCodeableConcept();
        obs.code.text = 'Proteins Daily Intake';
        const v = new Quantity();
        v.code = '%';
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.unit = '%';
        v.value = this.roundValue(measure.value);
        obs.value = v;
        return obs;
    }
    fromDataModelCarbohydratesDailyIntake(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.CARBOHYDRATES_DAILY_INTAKE_CODINGS.toCodeableConcept();
        const v = new Quantity();
        v.code = '%';
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.unit = '%';
        v.value = this.roundValue(measure.value);
        obs.value = v;
        return obs;
    }
    fromDataModelCaloricDailyIntake(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.CALORIC_DAILY_INTAKE_CODINGS.toCodeableConcept();
        const v = new Quantity();
        v.code = 'cal';
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.unit = measure.unit;
        v.value = this.roundValue(measure.value);
        obs.value = v;
        return obs;
    }
    fromDataModelStepCount(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        // obs.category = [ HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept() ];
        obs.code = HeartValueSet.Common.Measurement.STEPS_CODINGS.toCodeableConcept();
        obs.value = measure.value;
        return obs;
    }
    fromDataModelSmokingFrequency(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.CIGARETTES_DAILY_AMOUNT_CODINGS.toCodeableConcept();
        const v = new Range();
        obs.value = v;
        const low = new Quantity();
        const high = new Quantity();
        v.low = low;
        v.high = high;
        switch (measure.value) {
            default:
            case SmokingFrequency.SmokingFrequencyCategory.exactly_0_cigarettes_per_day:
                low.value = 0;
                high.value = 0;
                break;
            case SmokingFrequency.SmokingFrequencyCategory.lt_eq_5_cigarettes_per_day:
                low.value = 1;
                high.value = 5;
                break;
            case SmokingFrequency.SmokingFrequencyCategory.lt_eq_10_cigarettes_per_day:
                low.value = 6;
                high.value = 10;
                break;
            case SmokingFrequency.SmokingFrequencyCategory.lt_eq_15_cigarettes_per_day:
                low.value = 11;
                high.value = 15;
                break;
            case SmokingFrequency.SmokingFrequencyCategory.lt_eq_20_cigarettes_per_day:
                low.value = 16;
                high.value = 20;
                break;
            case SmokingFrequency.SmokingFrequencyCategory.more_than_20_cigarettes_per_day:
                low.value = 21;
                high.value = undefined;
                break;
        }
        return obs;
    }
    fromDataModelBodyTemperature(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.BODY_TEMPERATURE_CODINGS.toCodeableConcept();
        const v = new Quantity();
        v.code = 'Cel';
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.unit = TemperatureUnit[TemperatureUnit.CELSIUS];
        v.value = measure.valueIn(TemperatureUnit.CELSIUS);
        obs.value = v;
        return obs;
    }
    fromDataModelChestPain(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.SURVEY.toCodeableConcept()];
        if (measure instanceof ChestPainLevel) {
            obs.code = HeartValueSet.Common.Measurement.CHEST_PAIN_CODINGS.toCodeableConcept();
        }
        else if (measure instanceof ChestPainQuestionnaire) {
            obs.code = HeartValueSet.Common.Measurement.CHEST_PAIN_QUESTIONNAIRE.toCodeableConcept();
        }
        obs.value = measure.value;
        return obs;
    }
    fromDataModelTTM(measure) {
        const obs = new Observation();
        obs.id = AbstractApi.generateRandomIDDt();
        obs.category = [HeartValueSet.Common.MeasurementCategory.VITAL_SIGNS.toCodeableConcept()];
        obs.code = HeartValueSet.Common.Measurement.TTM_CODINGS.toCodeableConcept();
        const v = new CodeableConcept();
        obs.value = v;
        switch (measure.value) {
            default:
            case TTM.TTMCategory.TTM1:
                // ('TTM2', 'Transtheoretical model 2', Dictionary.BASE_NAMESPACE);
                v.coding = [
                    new Coding({
                        code: 'TTM1',
                        display: 'Transtheoretical model 2',
                        system: Dictionary.BASE_NAMESPACE,
                    }),
                ];
                break;
            case TTM.TTMCategory.TTM2:
                v.coding = [
                    new Coding({
                        code: 'TTM2',
                        display: 'Transtheoretical model 2',
                        system: Dictionary.BASE_NAMESPACE,
                    }),
                ];
                break;
        }
        return obs;
    }
    // TODO CMP3
    toDataModelTherapeuticImplication(resource, context) {
        const tImplication = new TherapeuticImplication(parseInt(resource.id));
        // recupera l'id della Observation cui questa TherapeuticImplication è legata
        if (resource.derivedFrom) {
            tImplication.relatedGenomicVariantId = Number.isNaN(resource.derivedFrom[0].getReferenceIdPart())
                ? resource.derivedFrom[0].reference
                : resource.derivedFrom[0].getReferenceIdPart();
        }
        resource.component?.forEach((comp) => {
            switch (comp.code?.coding[0]?.code) {
                // case "associated-therapy":
                // tImplication.actionable = comp.value as string;
                case '51963-7':
                    //DONE tImplication.actionable.push(CODEDVALUE)
                    let coding = comp.value?.coding[0];
                    tImplication.actionable.push(new CodedValue(coding.system, coding.code, coding.display));
                    break;
                case '93044-6':
                    coding = comp.value?.coding[0];
                    tImplication.evidenceLevel = new CodedValue(coding.system, coding.code, coding.display);
                    break;
            }
        });
        return tImplication;
    }
    toDataModelDiagnosticImplication(resource, context) {
        const dImplication = new DiagnosticImplication(parseInt(resource.id));
        let coding;
        let clinVar = new Significance();
        let acmg = new Significance();
        // recupera l'id della Observation cui questa DiagnosticImplication è legata
        if (resource.derivedFrom) {
            dImplication.relatedGenomicVariantId = Number.isNaN(resource.derivedFrom[0].getReferenceIdPart())
                ? resource.derivedFrom[0].reference
                : resource.derivedFrom[0].getReferenceIdPart();
        }
        resource.component?.forEach((comp) => {
            switch (comp.code?.coding[0]?.code) {
                case 'CLINSIG':
                case '53037-8':
                    // discriminante sul system del value -> vedi modello DiagnosticImplication
                    coding = comp.value?.coding[0];
                    const cv = new CodedValue(coding.system, coding.code, coding.display);
                    if (cv.system == 'http://www.ncbi.nlm.nih.gov/clinvar') {
                        clinVar.significance = cv;
                    }
                    else if (cv.system == 'http://loinc.org') {
                        acmg.significance = cv;
                    }
                    else {
                        console.error(`${cv.system} not managed by toDataModelDiagnosticImplication`);
                    }
                    break;
                case 'functional-effect':
                    coding = comp.value?.coding[0];
                    dImplication.functionalEffect = new CodedValue(coding?.system, coding?.code, coding?.display);
                    //clinVar.evidenceLevel = new CodedValue(coding?.system, coding?.code, coding?.display);
                    break;
                case '93044-6': //EvidenceLevel
                    coding = comp.value?.coding[0];
                    clinVar.evidenceLevel = new CodedValue(coding?.system, coding?.code, coding?.display);
                    break;
                case '81259-4':
                    coding = comp.value?.coding[0];
                    dImplication.predictedPhenotype.push(new CodedValue(coding?.system, coding?.code, coding?.display)); // ora è un array
                    break;
                case 'CADD':
                    dImplication.CADD = comp.value?.value;
                    break;
            }
        });
        dImplication.clinVar = clinVar;
        dImplication.acmg = acmg;
        return dImplication;
    }
    toDataModelMolecularConsequence(resource, context) {
        const mCons = new MolecularConsequence(parseInt(resource.id));
        let coding;
        // recupera l'id della Observation cui questa DiagnosticImplication è legata
        if (resource.derivedFrom) {
            mCons.relatedGenomicVariantId = Number.isNaN(resource.derivedFrom[0].getReferenceIdPart())
                ? resource.derivedFrom[0].reference
                : resource.derivedFrom[0].getReferenceIdPart();
        }
        resource.component?.forEach((comp) => {
            switch (comp.code?.coding[0]?.code) {
                case '48004-6':
                    coding = comp.value?.coding[0];
                    let cvCC = new CodedValue(coding.system, coding.code, coding.display);
                    mCons.codingChange = cvCC;
                    break;
                case '48005-3':
                    coding = comp.value?.coding[0];
                    let cvPC = new CodedValue(coding.system, coding.code, coding.display);
                    mCons.proteinChange = cvPC;
                    break;
                case '51958-7': //EvidenceLevel
                    coding = comp.value?.coding[0];
                    let cvRS = new CodedValue(coding.system, coding.code, coding.display);
                    mCons.transcriptRefSeq = cvRS;
                    break;
                case 'feature-consequence':
                    coding = comp.value?.coding[0];
                    let cvCons = new CodedValue(coding.system, coding.code, coding.display);
                    mCons.featureConsequences.push(cvCons);
                    break;
            }
        });
        return mCons;
    }
    toDataModelGenomicVariant(resource, context) {
        const gVariant = new GenomicVariant(parseInt(resource.id), undefined);
        if (Number.isNaN(gVariant.id)) {
            // il vcf2fhir genera id in formato stringa
            gVariant.linkedId = resource.id;
        }
        let allelicDepth = undefined;
        let allelicTotalDepth = undefined;
        let sampleAllelicFrequency = undefined;
        let coding;
        let cPosition = new ChromosomePosition();
        cPosition.start = [];
        cPosition.end = [];
        // esegue un ciclo su tutti i component della observation
        resource.component?.forEach((comp) => {
            console.log(`Converting: ${comp.code?.coding[0]?.code}`);
            switch (comp.code?.coding[0]?.code) {
                case '81252-9': // Discrete genetic variant
                    coding = comp.value?.coding[0];
                    gVariant.variantId = new CodedValue(coding.system, coding.code, coding.display);
                    break;
                case '81254-5': // Exact Position
                    if (comp.value?.low)
                        cPosition.start.push(comp.value.low.value);
                    if (comp.value?.high)
                        cPosition.end.push(comp.value.high.value);
                    break;
                case '81302-2': // Inner Position
                    if (comp.value?.low)
                        cPosition.start.push(comp.value.low.value);
                    if (comp.value?.high)
                        cPosition.start.push(comp.value.high.value);
                    break;
                case '81301-4': // Outer Position
                    if (comp.value?.low)
                        cPosition.end.push(comp.value.low.value);
                    if (comp.value?.high)
                        cPosition.end.push(comp.value.high.value);
                    break;
                case '47999-8': // EXON
                    cPosition.exon = comp.value?.trim();
                    break;
                case '48000-4': // Chromosome
                    coding = comp.value?.coding[0];
                    if (coding)
                        gVariant.chromo = new CodedValue(coding.system, coding.code, coding.display);
                    break;
                case '48013-7': // Chromosome - using "Genomic reference sequence ID"
                    coding = comp.value?.coding[0];
                    if (coding)
                        gVariant.chromo = new CodedValue(coding.system, coding.code, coding.display);
                    break;
                case '69547-8': // Reference Allele
                    gVariant.reference = comp.value?.trim();
                    break;
                case '69551-0': // Alternate Allele
                    gVariant.alteration = comp.value?.trim();
                    break;
                case '82121-5': // Coverage Allele
                    allelicDepth = comp.value?.value;
                    break;
                case '81258-6': // Frequency Allele
                    sampleAllelicFrequency = comp.value?.value;
                    break;
                case '92821-8': // Population Frequency
                    gVariant.populationFreq = comp.value?.value;
                    break;
                case 'RD':
                case 'total-read-depth': // TOTAL READ DEPTH - changed
                    allelicTotalDepth = comp.value?.value;
                    break;
                case '48018-6': // Gene
                    coding = comp.value?.coding[0];
                    gVariant.geneName = new CodedValue(coding.system, coding.code, coding.display);
                    break;
                case '48004-6': // DNA Code change
                    coding = comp.value?.coding[0];
                    gVariant.codingChange = new CodedValue(coding.system, coding.code, coding.display ?? coding.code);
                    break;
                case '48005-3': // Amino Acid change
                    coding = comp.value?.coding[0];
                    gVariant.proteinChange = new CodedValue(coding.system, coding.code, coding.display);
                    break;
                // case "molecular-consequence": // Molecular Consequence
                //   coding = (comp.value as FhirCodeableConcept)?.coding[0];
                //   gVariant.molecularConsequence = new CodedValue(coding.system, coding.code, coding.display);
                //   break;
                case '48019-4': // Coding Change Type
                    coding = comp.value?.coding[0];
                    gVariant.type = new CodedValue(coding.system, coding.code, coding.display);
                    break;
                case '48002-0': // Genomic Source
                    coding = comp.value?.coding[0];
                    gVariant._genomicSource = new CodedValue(coding.system, coding.code, coding.display);
                    break;
                // case '51958-7': // Transcript refseq // moved in MolecularConsequences
                //   coding = (comp.value as FhirCodeableConcept)?.coding[0];
                //   gVariant.transcript = new CodedValue(coding.system, coding.code, coding.display);
                //   gVariant.transcriptVersion = coding.version;
                //   break;
                case 'GP': // Genotype
                    gVariant.genotype = comp.value?.trim();
                    break;
                case '53034-5':
                    // console.log(`to manage ${JSON.stringify(comp)}`);
                    coding = comp.value?.coding[0];
                    gVariant.allelicState = new CodedValue(coding.system, coding.code, coding.display);
                    break;
                default:
                    console.log(`code: ${comp.code?.coding[0]?.code} NOT FOUND`);
                    break;
            }
        });
        // costruisce la quality sulla base dei valori allelic letti
        gVariant.quality = new Quality(allelicDepth, allelicTotalDepth, sampleAllelicFrequency);
        // estrae l'incidentalFinding dalla extension
        let ifExt = resource.extension?.find((e) => e.url === 'http://hl7.org/fhir/StructureDefinition/observation-secondaryFinding');
        if (ifExt) {
            gVariant.incidental = true;
        }
        else {
            gVariant.incidental = false;
        }
        gVariant.position = cPosition;
        return gVariant;
    }
    toDataModelGenotype(resource, hlaBundle) {
        // console.log("[CONVERTER]: conversione Genotype: " + resource.id);
        const genotype = new Genotype(parseInt(resource.id));
        // copia il valore
        genotype.value = resource?.value?.coding[0]?.display;
        // Cerca il component con il gene
        const gene = resource?.component?.find((c) => c?.code?.coding?.find((coding) => coding?.code === '48018-6'));
        if (gene) {
            const geneCode = gene?.value?.coding[0];
            if (geneCode)
                genotype.gene = new CodedValue(geneCode.system, geneCode.code, geneCode.display);
        }
        // Gestisce i derivedFrom
        resource?.derivedFrom?.forEach((df) => {
            if (df instanceof Reference) {
                const dfRef = df;
                // console.log("[CONVERTER]: derivedFrom Obs: " + JSON.stringify(dfRef));
                // Cerca nel bundle l'Observation correlata e la converte in un Haplotype
                let relatedEntry = hlaBundle.entry.find((entry) => {
                    const resource = entry.resource;
                    return resource?.getReference()?.reference === dfRef.reference;
                });
                if (relatedEntry) {
                    genotype.haplotypes.push(this.toDataModelHaplotype(relatedEntry.resource, hlaBundle));
                }
            }
        });
        console.log('[CONVERTER]: Genotype: ' + JSON.stringify(genotype));
        return genotype;
    }
    toDataModelRegionStudied(resource, context) {
        // console.log("[CONVERTER]: converto Haplotype: " + resource.id);
        const regionStudied = new RegionStudied(parseInt(resource.id));
        // Cerca il component con il value
        const valueComponent = resource?.component?.find((c) => c?.code?.coding?.find((coding) => coding?.code === '81293-3'));
        if (valueComponent) {
            regionStudied.value = valueComponent.value;
        }
        // Cerca il component con il gene
        const gene = resource?.component?.find((c) => c?.code?.coding?.find((coding) => coding?.code === '48018-6'));
        if (gene) {
            const geneCode = gene?.value?.coding[0];
            if (geneCode)
                regionStudied.gene = new CodedValue(geneCode.system, geneCode.code, geneCode.display);
        }
        // console.log("[CONVERTER]: Haplotype: " + JSON.stringify(haplotype));
        return regionStudied;
    }
    toDataModelHaplotype(resource, context) {
        // console.log("[CONVERTER]: converto Haplotype: " + resource.id);
        const haplotype = new Haplotype(parseInt(resource.id));
        // copia il valore
        haplotype.value = resource?.value?.coding[0]?.display;
        // Cerca il component con il gene
        const gene = resource?.component?.find((c) => c?.code?.coding?.find((coding) => coding?.code === '48018-6'));
        if (gene) {
            const geneCode = gene?.value?.coding[0];
            if (geneCode)
                haplotype.gene = new CodedValue(geneCode.system, geneCode.code, geneCode.display);
        }
        // console.log("[CONVERTER]: Haplotype: " + JSON.stringify(haplotype));
        return haplotype;
    }
    roundValue(input, digits = 0) {
        try {
            return Number.parseFloat(input.toFixed(digits));
        }
        catch (err) {
            return input;
        }
    }
}

class MessageFhirConverter extends AbstractFhirConverter {
    toDataModel(resource, context) {
        let message;
        const categories = resource?.category || [];
        if (HeartValueSet.Common.Communication.COMMUNICATION_INFORMATIVE.equals(categories)) {
            message = new InformativeMessage();
            // fhir ID
            message.id = this.toFhirIDPart(resource);
            message.received = resource.received;
            if (resource.payload && resource.payload[0].content) {
                message.textLabel = resource.payload[0].content.text;
            }
        }
        else if (HeartValueSet.Common.Communication.COMMUNICATION_MOTIVATIONAL.equals(categories)) {
            message = new MotivationalMessage();
            // fhir ID
            message.id = this.toFhirIDPart(resource);
            message.received = resource.received;
            if (resource.payload && resource.payload[0].content) {
                message.textLabel = resource.payload[0].content.text;
            }
        }
        else if (HeartValueSet.Common.Communication.COMMUNICATION_CHAT.equals(categories)) {
            message = new ChatMessage();
            // fhir ID
            message.id = this.toFhirIDPart(resource);
            // fhir version
            message.version = this.toFhirVersion(resource);
            message.received = resource.received;
            message.sent = resource.sent;
            // TODO: add read Date. extension to be made in FHIR
            message.read = HeartExtension.Message.read.extractValueFromExtensions(resource.extension);
            if (resource.sender && resource.sender) {
                message.sender = ModelToFHIRUtils.stubFromRef(resource.sender);
            }
            if (resource.recipient?.length > 0 && resource.recipient[0]) {
                message.recipient = ModelToFHIRUtils.stubFromRef(resource.recipient[0]);
            }
            if (resource.payload && resource.payload[0].content) {
                message.text = resource.payload[0].content.text;
            }
        }
        else if (HeartValueSet.Common.Communication.COMMUNICATION_DOC.equals(categories)) {
            message = new DocMessage();
            // fhir ID
            message.id = this.toFhirIDPart(resource);
            // fhir version
            // message.fhirVersion = this.toFhirVersion(resource);
            if (resource.reason?.length > 0) {
                message.type = DocMessageType.valueOf(resource.reason[0].concept.text);
            }
            message.sent = resource.sent;
            message.received = resource.received;
            if (resource.sender && resource.sender) {
                try {
                    const practitionerRef = this.resolveReference(resource.sender, resource, context);
                    if (practitionerRef) {
                        const practitioner = this.service.person.toDataModel(practitionerRef, context);
                        message.senderName = practitioner.getFullName();
                    }
                }
                catch (err) {
                    message.senderName = '';
                }
            }
            if (resource.subject) {
                message.recipient = ModelToFHIRUtils.stubFromRef(resource.subject);
            }
            if (resource.payload && resource.payload[0].content) {
                message.text = resource.payload[0].content.text;
                message.customMsg = resource.payload[0].content.text;
            }
            message.read = HeartExtension.Message.read.extractValueFromExtensions(resource.extension);
        }
        else {
            throw new Error(`Method 'toDataModelMessage' not yet implemented for this message type`);
        }
        return message;
    }
    fromDataModel(message) {
        const fhir = new Communication();
        // usare il FHIR ID invece dell'id del DB
        fhir.id = message.fhirId ? message.fhirId + '' : '';
        // fhir.version = !!message.fhirVersion ? message.fhirVersion + '' : undefined;
        if (message instanceof ChatMessage) {
            fhir.category = [HeartValueSet.Common.Communication.COMMUNICATION_CHAT.toCodeableConcept()];
            fhir.sender = ModelToFHIRUtils.getReference(message.sender);
            fhir.recipient = [ModelToFHIRUtils.getReference(message.recipient)];
            // finds the patient reference between 'sender' and 'recipient' attributes
            if (message.sender?.resourceType == 'Patient') {
                fhir.subject = ModelToFHIRUtils.getReference(message.sender);
            }
            else if (message.recipient?.resourceType == 'Patient') {
                fhir.subject = ModelToFHIRUtils.getReference(message.recipient);
            }
            fhir.received = message.received;
            fhir.sent = message.sent;
            const pl = new Communication.CommunicationPayloadComponent();
            // FIXME - system and code?
            pl.content = FhirUtils$1.createCodeableConcept(undefined, undefined, message.text);
            fhir.payload = [pl];
            if (message.isRead()) {
                fhir.extension = [HeartExtension.Message.read.toExtensionDate(message.read)];
            }
        }
        else if (message instanceof DocMessage) {
            fhir.category = [HeartValueSet.Common.Communication.COMMUNICATION_DOC.toCodeableConcept()];
            const reason = new CodeableConcept();
            reason.text = message.type.toString();
            fhir.reason = [reason];
            fhir.sender = ModelToFHIRUtils.getReference(message.sender);
            fhir.recipient = [ModelToFHIRUtils.getReference(message.recipient)];
            fhir.subject = ModelToFHIRUtils.getReference(message.recipient);
            fhir.received = message.received;
            fhir.sent = message.sent;
            // fhir.status = Communication.CommunicationStatus.COMPLETED;
            // TODOs
            // message.title;
            // message.text;
            const pl = new Communication.CommunicationPayloadComponent();
            // FIXME - system and code?
            pl.content = FhirUtils$1.createCodeableConcept(undefined, undefined, message.text);
            fhir.payload = [pl];
            if (message.isRead()) {
                fhir.extension = [HeartExtension.Message.read.toExtensionDate(message.read)];
            }
        }
        else {
            throw new Error(`Method 'fromDataModelMessage' not yet implemented for this message type`);
        }
        return fhir;
    }
}

// tslint:disable: max-line-length no-inferrable-types no-redundant-jsdoc
class OrganizationFhirConverter extends AbstractFhirConverter {
    toDataModel(resource, context) {
        return this.toDataModelQuestionnaire(resource);
    }
    fromDataModel(model) {
        if (model instanceof Organization) {
            return this.fromDataModelQuestionnaire(model);
        }
        else {
            throw new TypeError('Unsupported model type. Error converting from datamodel to FHIR.');
        }
    }
    toDataModelQuestionnaire(fhir) {
        const o = new Organization(+fhir.id);
        o.name = fhir.name;
        return o;
    }
    fromDataModelQuestionnaire(model) {
        const fhir = new Organization$1();
        fhir.id = !!model.id ? model.id + '' : undefined;
        fhir.name = model.name;
        return fhir;
    }
}

// tslint:disable: max-line-length no-inferrable-types no-redundant-jsdoc
// prettier-ignore
class PersonFhirConverter extends AbstractFhirConverter {
    toDataModel(resource, context) {
        if (resource instanceof Patient) {
            return this.toDataModelPatient(resource);
        }
        else if (resource instanceof Practitioner) {
            return this.toDataModelHealthCareProfessional(resource);
        }
        else {
            return undefined;
        }
    }
    fromDataModel(model) {
        if (model instanceof Patient$1) {
            return this.fromDataModelPatient(model);
        }
        else if (model instanceof HealthCareProfessional) {
            return this.fromDataModelHealthCareProfessional(model);
        }
        else {
            throw new TypeError('Unsupported model type. Error converting from datamodel to FHIR.');
        }
    }
    /**
     * Convert a FHIR Practitioner resource in the 'easy' HealthcareProfessional
     *
     * As FHIR has some information in the PractitionerRole and Organization resources the converter needs those too
     * @param fhir
     * @param fhirPractitionerRole
     * @param fhirOrganizations
     * @returns
     */
    toDataModelHealthCareProfessional(fhir, fhirPractitionerRole, fhirOrganizations) {
        const id = +fhir.id;
        const hcp = new HealthCareProfessional(id);
        const name = ((fhir.name || [])[0]?.given || [])[0];
        const family = (fhir.name || [])[0]?.family;
        hcp.firstName = name;
        hcp.lastName = family;
        // extract Gender enum with dedicated converter
        hcp.gender = this.toDataModelGender(fhir.gender);
        if (fhirPractitionerRole) {
            hcp.personRoles = fhirPractitionerRole.map((pr) => {
                // FIXME: evolvere il mapping tra codice ruolo e Role
                let org = undefined;
                if (pr.organization) {
                    const orgRef = pr.organization;
                    const fOrg = fhirOrganizations ? fhirOrganizations.find((o) => (o.id === orgRef.id || o.id === orgRef.getReferenceIdPart().toString())) : undefined;
                    org = fOrg ? fOrg : ModelToFHIRUtils.stubFromRef(orgRef, 'Organization');
                }
                let role = undefined;
                if (pr.code) {
                    role = Role.convertFromString(pr.code[0].coding[0].code);
                }
                return new PersonRole(org, role);
            });
        }
        if (fhir.telecom?.length > 0) {
            const emailContact = fhir.telecom.find((t) => t.system === ContactPoint.ContactPointSystem.EMAIL.toString());
            hcp.email = emailContact?.value?.trim();
        }
        const uuidIdentifier = FhirUtils$1.filterIdentifierBySystem(fhir.identifier, Dictionary.UHM_SECURITY_SYSTEM);
        hcp.uuid = ModelToFHIRUtils.toIdentifierModel(uuidIdentifier);
        const otherIdentifiers = fhir.identifier?.filter(i => i.system != Dictionary.UHM_SECURITY_SYSTEM)?.map(i => ModelToFHIRUtils.toIdentifierModel(i)) ?? [];
        hcp.additionalIdentifiers = otherIdentifiers;
        hcp.birthDate = fhir.birthDate;
        return hcp;
    }
    /**
     * Convert a FHIR Patient resource in the 'easy' Patient
     *
     * @param fhir
     * @returns
     */
    toDataModelPatient(fhir) {
        const id = +fhir.id;
        const patient = new Patient$1(id);
        /******************************************
         * Security attributes (from Person)
         ******************************************/
        const uuidIdentifier = FhirUtils$1.filterIdentifierBySystem(fhir.identifier, Dictionary.UHM_SECURITY_SYSTEM);
        patient.uuid = ModelToFHIRUtils.toIdentifierModel(uuidIdentifier);
        if (fhir.managingOrganization) {
            const orgReference = fhir.managingOrganization;
            patient.managingOrganization = new Organization(orgReference.getReferenceIdPart());
        }
        /******************************************
         * Security - END
         ******************************************/
        // ***** ALERT! USED BY THE PATIENT SPACE MICORSERVICE *****
        patient.patientIdentifier = FhirUtils$1.filterIdentifierBySystem(fhir.identifier, Dictionary.UHM_PSEUDONYM_SYSTEM)?.value;
        patient.patientIdentifierSystem = Dictionary.UHM_PSEUDONYM_SYSTEM;
        const otherIdentifiers = fhir.identifier?.filter(i => i.system != Dictionary.UHM_PSEUDONYM_SYSTEM && i.system != Dictionary.UHM_SECURITY_SYSTEM)?.map(i => ModelToFHIRUtils.toIdentifierModel(i)) ?? [];
        patient.additionalIdentifiers = otherIdentifiers;
        // Pseudonym
        // FIXME: should this be removed as it is redundant wrt patientIdentifier?
        // const pseudonymIdentifier = FhirUtils.filterIdentifierByTypeSystem( fhir.identifier, Dictionary.PseudonymSystem );
        // if ( pseudonymIdentifier ) {
        //   patient.pseudonym = pseudonymIdentifier.value;
        // }
        // name and family
        if (fhir.name?.length > 0) {
            patient.firstName = fhir.name[0]?.given[0];
            patient.lastName = fhir.name[0]?.family;
        }
        // Email address contact
        if (fhir.telecom?.length > 0) {
            const emailContact = fhir.telecom.find((t) => t.system === ContactPoint.ContactPointSystem.EMAIL.toString());
            patient.email = emailContact?.value?.trim();
        }
        // extract Gender enum with dedicated converter
        patient.gender = this.toDataModelGender(fhir.gender);
        // birthDate
        patient.birthDate = fhir.birthDate;
        patient.taxCode = FhirUtils$1.filterIdentifierBySystem(fhir.identifier, Dictionary.PATIENT_TAX_CODE_SYSTEM)?.value;
        // FIXME
        /**
         * Creare una classe enum o mappa dove metto i regional code
         * Fare in modo di aver modo di convertire sia da chiave a valore che da valore a chiave
         * Nel caso dovessimo alla fine avere molti regional code
         */
        // birthPlace
        const fhirBirthPlace = HeartExtension.Patient.birthPlace.extractValueFromExtensions(fhir.extension);
        if (fhirBirthPlace) {
            const birthPlace = new Place();
            birthPlace.city = fhirBirthPlace.city;
            birthPlace.country = fhirBirthPlace.country;
            birthPlace.state = fhirBirthPlace.state;
            birthPlace.district = fhirBirthPlace.district;
            patient.birthPlace = birthPlace;
        }
        /******************************************
         * Addresses
         ******************************************/
        fhir.address
            ?.filter(address => (address?.extension || [])[0]?.url == HeartExtension.Patient.homeType.url)
            .forEach(address => {
            const extension = address.extension[0];
            const personAddress = new PersonAddress();
            personAddress.city = address.city;
            personAddress.country = address.country;
            personAddress.district = address.district;
            personAddress.state = address.state;
            personAddress.postalCode = address.postalCode;
            if (address.line && address.line.length > 0)
                personAddress.line = (address.line || [])[0] ?? undefined;
            if (extension?.value == "RESIDENCE") {
                patient.residence = personAddress;
            }
            else if (extension?.value == "DOMICILE") {
                patient.domicile = personAddress;
            }
            else {
                patient.residence = personAddress;
            }
        });
        // Phone number contact
        if (fhir.telecom?.length > 0) {
            const phoneContact = fhir.telecom.find((t) => t.system === ContactPoint.ContactPointSystem.PHONE.toString());
            patient.phoneNumber = phoneContact?.value?.trim();
        }
        return patient;
    }
    /**
     * Convert the 'easy' Patient in the FHIR Patient resource
     *
     * @param patient
     * @returns
     */
    fromDataModelPatient(patient) {
        const fhir = new Patient();
        fhir.id = !!patient.id ? patient.id + '' : undefined;
        /******************************************
         * Security attributes (from Person)
         ******************************************/
        if (patient?.personRoles[0]?.organization) {
            // const orgRef = 'Organization/' + patient?.personRoles[0]?.organization?.id;
            fhir.managingOrganization = ModelToFHIRUtils.getReference(patient.personRoles[0]?.organization);
        }
        else if (patient.managingOrganization) {
            fhir.managingOrganization = ModelToFHIRUtils.getReference(patient.managingOrganization);
        }
        if (patient.uuid) {
            const uuidIdentifier = ModelToFHIRUtils.fromIdentifierModel(patient.uuid);
            (fhir.identifier = fhir.identifier || []).push(uuidIdentifier);
        }
        /******************************************
         * Security - END
         ******************************************/
        if (patient.patientIdentifier) {
            // FIXME, ci dovranno dare una url corretta
            const patientIdentifier = ModelToFHIRUtils.fromPseudonymIdentifierModel(patient.patientIdentifier);
            (fhir.identifier = fhir.identifier || []).push(patientIdentifier);
        }
        patient.additionalIdentifiers?.forEach(id => (fhir.identifier = fhir.identifier || []).push(ModelToFHIRUtils.fromIdentifierModel(id)));
        // Pseudonym
        // FIXME: should this be removed as it is redundant wrt patientIdentifier?
        // if 'yes' we have to check server-side behavior
        // if ( patient.pseudonym ) {
        //   const pseudonymIdentifier = ModelToFHIRUtils.fromPseudonymIdentifierModel(patient.pseudonym);
        //   (fhir.identifier = fhir.identifier || []).push(pseudonymIdentifier);
        // }
        // name and family
        if ((!!patient.firstName && patient.firstName != '') || (!!patient.lastName && patient.lastName != '')) {
            const humanName = new HumanName();
            if (patient.firstName) {
                humanName.given = [patient.firstName];
            }
            humanName.family = patient.lastName;
            fhir.name = [humanName];
        }
        // Email address contact
        if (!!patient.email && patient.email != '') {
            const contact = new ContactPoint();
            contact.system = ContactPoint.ContactPointSystem.EMAIL.toString();
            contact.value = patient.email;
            (fhir.telecom = fhir.telecom || []).push(contact);
        }
        // extract AdministrativeGender enum with dedicated converter
        fhir.gender = this.fromDataModelGender(patient.gender)?.toString();
        // birthDate
        fhir.birthDate = patient.birthDate;
        if (!!patient.taxCode && patient.taxCode != '') {
            const taxCodeIdentifier = new Identifier$1();
            taxCodeIdentifier.system = Dictionary.PATIENT_TAX_CODE_SYSTEM;
            taxCodeIdentifier.value = patient.taxCode;
            (fhir.identifier = fhir.identifier || []).push(taxCodeIdentifier);
        }
        // birthPlace
        const birthPlace = patient.birthPlace;
        if (birthPlace) {
            const fhirBirthPlace = new Address();
            fhirBirthPlace.city = birthPlace.city;
            fhirBirthPlace.country = birthPlace.country;
            fhirBirthPlace.state = birthPlace.state;
            fhirBirthPlace.district = birthPlace.district;
            // set 'fhirBirthPlace' as an extension
            (fhir.extension = fhir.extension || []).push(HeartExtension.Patient.birthPlace.toExtension(fhirBirthPlace));
        }
        /******************************************
         * Addresses
         ******************************************/
        const residence = patient.residence;
        // Residence address
        if (residence) {
            const residenceAddress = this.fromDataModelPatientAddress(residence, true);
            (fhir.address = fhir.address || []).push(residenceAddress);
        }
        // Domicile address
        const domicile = patient.domicile;
        if (domicile) {
            const domicileAddress = this.fromDataModelPatientAddress(domicile, false);
            (fhir.address = fhir.address || []).push(domicileAddress);
        }
        // Phone number contact
        if (!!patient.phoneNumber && patient.phoneNumber != '') {
            const contact = new ContactPoint();
            contact.system = ContactPoint.ContactPointSystem.PHONE.toString();
            contact.value = patient.phoneNumber;
            (fhir.telecom = fhir.telecom || []).push(contact);
        }
        return fhir;
    }
    /**
     * Convert the 'easy' HealthcareProfessional in the FHIR Practitioner resource
     *
     * @param hcp
     * @returns
     */
    fromDataModelHealthCareProfessional(hcp) {
        const fhir = new Practitioner();
        fhir.id = !!hcp.id ? hcp.id + '' : undefined;
        if (hcp.uuid) {
            (fhir.identifier = fhir.identifier || []).push(ModelToFHIRUtils.fromIdentifierModel(hcp.uuid));
        }
        hcp.additionalIdentifiers?.forEach(id => (fhir.identifier = fhir.identifier || []).push(ModelToFHIRUtils.fromIdentifierModel(id)));
        if (!!hcp.email && hcp.email != '') {
            const contact = new ContactPoint();
            contact.system = ContactPoint.ContactPointSystem.EMAIL.toString();
            contact.value = hcp.email;
            (fhir.telecom = fhir.telecom || []).push(contact);
        }
        // extract AdministrativeGender enum with dedicated converter
        fhir.gender = this.fromDataModelGender(hcp.gender)?.toString();
        // birth date
        fhir.birthDate = hcp.birthDate;
        // name and family
        if ((!!hcp.firstName && hcp.firstName != '') || (!!hcp.lastName && hcp.lastName != '')) {
            const humanName = new HumanName();
            if (hcp.firstName) {
                humanName.given = [hcp.firstName];
            }
            humanName.family = hcp.lastName;
            fhir.name = [humanName];
        }
        return fhir;
    }
    toDataModelGender(fhirGender) {
        if (!fhirGender) {
            return undefined;
        }
        const strFhirGender = fhirGender.toString();
        let gender = undefined;
        if (strFhirGender == "female" ||
            strFhirGender == Patient.AdministrativeGender.FEMALE.toString() ||
            strFhirGender == Practitioner.AdministrativeGender.FEMALE.toString()) {
            gender = Gender.female;
        }
        else if (strFhirGender == "male" ||
            strFhirGender == Patient.AdministrativeGender.MALE.toString() ||
            strFhirGender == Practitioner.AdministrativeGender.MALE.toString()) {
            gender = Gender.male;
        }
        else if (strFhirGender == "other" ||
            strFhirGender == Patient.AdministrativeGender.OTHER.toString() ||
            strFhirGender == Practitioner.AdministrativeGender.OTHER.toString()) {
            gender = Gender.other;
        }
        else if (strFhirGender == "unknown" ||
            strFhirGender == Patient.AdministrativeGender.UNKNOWN.toString() ||
            strFhirGender == Practitioner.AdministrativeGender.UNKNOWN.toString()) {
            gender = Gender.unknown;
        }
        return gender;
    }
    /**
     * A previous version of this converter only converted the Gender into a string under the assumption that the enum values are the same.
     *
     * The current method, while more complex, is more flexibile.
     *
     * @param gender
     * @returns
     */
    fromDataModelGender(gender) {
        if (!gender) {
            return undefined;
        }
        let fhirGender = undefined;
        if (gender == Gender.female) {
            fhirGender = "female"; // | FhirPatient.AdministrativeGender.FEMALE | FhirPractitioner.AdministrativeGender.FEMALE;
        }
        else if (gender == Gender.male) {
            fhirGender = "male"; // FhirPatient.AdministrativeGender.MALE | FhirPractitioner.AdministrativeGender.MALE;
        }
        else if (gender == Gender.other) {
            fhirGender = "other"; // FhirPatient.AdministrativeGender.OTHER | FhirPractitioner.AdministrativeGender.OTHER;
        }
        else if (gender == Gender.unknown) {
            fhirGender = "unknown"; // FhirPatient.AdministrativeGender.UNKNOWN | FhirPractitioner.AdministrativeGender.UNKNOWN;
        }
        return fhirGender;
    }
    fromDataModelPatientAddress(residence, isOfficial) {
        const fhirAddress = new Address();
        fhirAddress.city = residence.city;
        fhirAddress.country = residence.country;
        fhirAddress.district = residence.district;
        fhirAddress.postalCode = residence.postalCode;
        if (residence.line) {
            fhirAddress.line = [residence.line];
        }
        const coding = new Coding();
        coding.code = isOfficial ? "DOMICILE" : "RESIDENCE";
        coding.system = Dictionary.UHM_CODE_SYSTEM_URI + "home-type-code-system";
        fhirAddress.extension = [HeartExtension.Patient.homeType.toExtensionCoding(coding)];
        // force the 'use' value to 'home'
        fhirAddress.use = Address.AddressUse.HOME.toString();
        // force the 'type' value to 'both'
        fhirAddress.type = Address.AddressType.BOTH.toString();
        return fhirAddress;
    }
}

class PlanFhirConverter extends AbstractFhirConverter {
    fromDataModel(plan) {
        const cp = new CarePlan();
        if (plan.fhirId) {
            cp.id = plan.fhirId.startsWith('CarePlan') ? plan.fhirId.substring('CarePlan/'.length) : plan.fhirId;
        }
        else {
            cp.id = AbstractApi.generateRandomIDDt();
        }
        cp.intent = CarePlan.CarePlanIntent.PLAN.toString();
        cp.status = plan.status ? FhirCodesMapperUtils.PlanStatusToFHIR(plan.status).toString() : CarePlan.RequestStatus.ACTIVE.toString();
        if (plan.start || plan.due) {
            cp.period = new Period();
            cp.period.start = plan.start ?? undefined;
            cp.period.end = plan.due ?? undefined;
        }
        cp.created = new Date();
        // patient
        const patient = plan.patient;
        if (patient === undefined) {
            throw Error('Patient not found while converting the plan.');
        }
        cp.subject = ModelToFHIRUtils.getReference(patient);
        // practitioner
        const author = plan.author;
        if (author) {
            cp.custodian = ModelToFHIRUtils.getReference(author); // [ author.reference, patient.reference ];
        }
        // Clinical Condition motivating the plan itself
        cp.addresses = plan.motivation?.map((m) => this.service.condition.fromDataModel(m).code);
        // care plan category
        const fhirPlanCategory = ModelToFHIRUtils.fromCodedValueModel(plan.category);
        cp.category = [fhirPlanCategory];
        const fhirGoals = [];
        // set a goals included in the plan
        // TODO: put the goals also into the Activities
        if (plan.goals) {
            plan.goals.forEach((goal) => {
                fhirGoals.push(this.service.goal.fromDataModel(goal));
            });
        }
        cp.goal = fhirGoals;
        // set a goals included in the plan
        // TODO: put the goals also into the Activities
        if (plan.activities) {
            const fhirActivities = [];
            plan.activities.forEach((activity) => {
                fhirActivities.push(this.fromDataModelActivity(activity));
            });
            cp.activity = fhirActivities;
        }
        return cp;
    }
    fromDataModelActivity(activity) {
        throw new TypeError(`fromDataModelActivity not implemented`);
    }
    toDataModelSMBGActivity(fActivity, context) {
        const smbgActivity = new SMBGActivity();
        // const detail = fActivity.detail;
        // Schedulare N comunicazioni se si gestisce l'SMBG (1 per punto di misurazione)
        const comTypes = [];
        smbgActivity.comTypes = comTypes;
        return smbgActivity;
    }
    toDataModelActivity(fActivity, context) {
        let activity;
        return activity;
    }
    toDataModel(fhir, context) {
        const model = new Plan();
        // fhir ID
        model.id = this.toFhirIDPart(fhir);
        // check that the condition is supported
        if (fhir.addresses) {
            const conditions = fhir.addresses;
            // the converter is assuming that reference have been already solved into resources
            if (!(conditions?.length > 0)) {
                throw new TypeError('Unsupported care plan instance. Error converting to datamodel from FHIR as there is no condition specified.');
            }
            model.motivation = [...conditions].map((c) => {
                if (c instanceof CodeableReference && c.reference) {
                    c = this.resolveReference(c.reference, undefined, context);
                }
                return this.service.condition.toDataModel(c, context);
            });
        }
        if (fhir.status) {
            model.status = FhirCodesMapperUtils.PlanStatusFromFHIR(fhir.status);
        }
        if (fhir.period) {
            model.start = fhir.period.start;
            model.due = fhir.period.end;
        }
        if (fhir.category && fhir.category.length > 0) {
            model.category = ModelToFHIRUtils.toCodedValueModel(fhir.category[0]);
        }
        // ignore subject, category
        const fhirGoals = fhir.goal;
        // the converter is assuming that references have been already solved into resources
        if (fhirGoals?.length > 0) {
            const goals = fhirGoals
                .map((g) => {
                if (g instanceof Reference) {
                    return this.resolveReference(g, fhir, context);
                }
                else {
                    return g;
                }
            })
                .map((fhirGoal) => {
                return this.service.goal.toDataModel(fhirGoal, context);
            });
            model.goals = goals;
        }
        const fhirActivities = fhir.activity;
        if (fhirActivities && fhirActivities.length > 0) {
            const activities = [];
            fhirActivities.forEach((fhirActivity) => {
                const act = this.toDataModelActivity(fhirActivity, context);
                if (act) {
                    activities.push(act);
                }
            });
            model.activities = activities;
        }
        const carePlanAuthor = fhir.custodian;
        if (carePlanAuthor) {
            let _fhirAuthor;
            _fhirAuthor = carePlanAuthor;
            if (!(_fhirAuthor instanceof Practitioner)) {
                if (_fhirAuthor.reference.indexOf('Practitioner') >= 0) {
                    try {
                        _fhirAuthor = this.resolveReference(_fhirAuthor, fhir, context);
                    }
                    catch (err) {
                        // practitioner reference unresoveable
                    }
                }
            }
            if (_fhirAuthor) {
                model.author = this.service.person.toDataModel(_fhirAuthor, context);
            }
        }
        if (fhir.subject) {
            model.patient = ModelToFHIRUtils.stubFromRef(fhir.subject, 'Patient'); // this.resolveSubject(careplan.subject, careplan, context);
        }
        return model;
    }
}

class PrescriptionFhirConverter extends AbstractFhirConverter {
    constructor() {
        // in a future possible to change form ExamPrescription to the more generic Prescription
        super(...arguments);
        this.priorityList = [
            new CodedValue('http://hl7.org/fhir/request-priority', 'stat'),
            new CodedValue('http://hl7.org/fhir/request-priority', 'asap'),
            new CodedValue('http://hl7.org/fhir/request-priority', 'urgent'),
            new CodedValue('http://hl7.org/fhir/request-priority', 'routine'),
        ];
    }
    /**
     * fromDataModel check if Prescription is instanceof CounsellingPrescription or ExamPrescription
     * and adapt conversion to ServiceRequest
     */
    fromDataModel(model) {
        const fhir = new ServiceRequest();
        if (model instanceof CounsellingPrescription) {
            fhir.id = !!model.id ? model.id + '' : undefined;
            // status: active | revoked 1..1
            if (model.status) {
                fhir.status = FhirCodesMapperUtils.PlanStatusToFHIR(model.status).toString();
            }
            // intent: proposal 1..1
            fhir.intent = 'proposal';
            // category: http://snomed.info/sct|409063005 (Counselling) 0..*
            fhir.category = [HeartValueSet.Prescription.COUNSELLING.toCodeableConcept()];
            // priority: routine | urgent 0..1
            if (model.priority) {
                fhir.priority = model.priority?.code;
            }
            // code: http://snomed.info/sct|6061000124109 (Risk evaluation and mitigation strategy consultation (procedure)) 0..1
            fhir.code = ModelToFHIRUtils.getCodeableReference(new CodedValue(Dictionary.SNOMED, '6061000124109', 'Risk evaluation and mitigation strategy consultation (procedure)'));
            // subject: Patient ref 1..1
            if (model.subject) {
                fhir.subject = ModelToFHIRUtils.getReference(model.subject);
            }
            // authoredOn: date 0..1
            if (model.dateTime) {
                fhir.authoredOn = model.dateTime;
            }
            // supportingInfo: Risk Assessment reference (from suggestion card) 0..*
            if (model.supportingInfo) {
                /**
                 * iteration over each 'item' in the 'model.supportingInfo' array - Shareable [].
                 * For each one, it creates a 'CodeableReference' object as for the FHIR R5 ServiceRequest.supportingInfo.
                 * */
                fhir.supportingInfo = model.supportingInfo.map((item) => {
                    const fhirReference = ModelToFHIRUtils.getReference(item);
                    const codeableRef = new CodeableReference();
                    codeableRef.reference = fhirReference;
                    return codeableRef;
                });
            }
        }
        else if (model instanceof ExamPrescription) {
            // throw new Error("Method not implemented");
            fhir.id = !!model.id ? model.id + '' : undefined;
            // fhir.meta = new Meta();
            // if ( model instanceof ExamPrescription ) {
            //   const conditionCategory = new HeartValueSet(
            //     Dictionary.FHIR_CONDITION_CATEGORY,
            //     'encounter-diagnosis',
            //     'Encounter Diagnosis'
            //   ).toCodeableConcept();
            //   fhir.category = [ conditionCategory ];
            //   fhir.meta.profile = [ Dictionary.UHM_STRUCTURE_DEFINITION_URI + 'Diagnosis' ];
            // } else {
            //   fhir.meta.profile = [ Dictionary.UHM_STRUCTURE_DEFINITION_URI + 'Condition' ];
            // }
            // STATIC
            fhir.status = 'active';
            fhir.intent = 'directive';
            fhir.priority = model.priority?.code; // FIXME routine | urgent | asap | stat
            fhir.subject = ModelToFHIRUtils.getReference(model.subject);
            if (model.author) {
                fhir.requester = ModelToFHIRUtils.getReference(model.author);
            }
            fhir.occurrence = model.dateTime;
            if (model.encounter) {
                fhir.encounter = ModelToFHIRUtils.getReference(model.encounter);
            }
            if (model.diagnosis && model.diagnosis.length > 0) {
                //JUST ONE DIAGNOSIS AT THIS MOMENT
                if (!fhir.supportingInfo) {
                    fhir.supportingInfo = [];
                }
                fhir.supportingInfo.push(ModelToFHIRUtils.getCodeableReference(undefined, model.diagnosis[0]));
            }
            fhir.code = ModelToFHIRUtils.getCodeableReference(model.examCode);
            if (model.specimenType) {
                if (!fhir.supportingInfo) {
                    fhir.supportingInfo = [];
                }
                fhir.supportingInfo.push(ModelToFHIRUtils.getCodeableReference(model.specimenType));
            }
            if (model.note) {
                const annotation = new Annotation();
                annotation.text = model.note;
                fhir.note = [annotation];
            }
        }
        return fhir;
    }
    participantFromDataModel(author) {
        const participant = new Condition.ConditionParticipantComponent();
        participant.function = new HeartValueSet('http://terminology.hl7.org/CodeSystem/provenance-participant-type', 'author', 'Author').toCodeableConcept();
        participant.actor = ModelToFHIRUtils.getReference(author);
        return participant;
    }
    toDataModel(fhir, context) {
        // throw new Error("Method not implemented");
        if (fhir.category && fhir.category.length > 0 && fhir.category[0].coding[0].code == HeartValueSet.Prescription.COUNSELLING.code) {
            let cp = new CounsellingPrescription();
            // fhir ID
            const fhirId = this.toFhirIDPart(fhir);
            cp.id = fhirId;
            //model.status: active | revoked 1..1
            cp.status = FhirCodesMapperUtils.PlanStatusFromFHIR(fhir.status);
            // model.priority: routine | urgent 0..1 check the code from the list above r.20
            if (fhir.priority) {
                cp.priority = this.priorityList.find((p) => p.code == fhir.priority);
            }
            // model.subject 1..1
            cp.subject = ModelToFHIRUtils.stubFromRef(fhir.subject, 'Patient');
            // model.dateTime 0..1
            if (fhir.authoredOn) {
                cp.dateTime = new Date(fhir.authoredOn);
            }
            // 1. model.supportingInfo: holds Shareable 0..*
            if (fhir.supportingInfo) {
                cp.supportingInfo = [];
                fhir.supportingInfo.forEach((item) => {
                    if (item.reference) {
                        const shareableStub = ModelToFHIRUtils.stubFromRef(item.reference);
                        if (shareableStub) {
                            cp.supportingInfo.push(shareableStub);
                        }
                    }
                });
            }
            // 2. model.supportingInfo: holds RiskAssessment 0..*
            // if (item.reference && item.reference.reference.includes('RiskAssessment')) {
            // const riskAssessmentStub = ModelToFHIRUtils.stubFromRef(item.reference as FhirReference) as RiskAssessment;
            // if (riskAssessmentStub) {
            // cp.supportingInfo.push(riskAssessmentStub);
            //  }
            // }
            return cp;
        }
        else {
            let ep = new ExamPrescription();
            // if (!fhir.meta?.profile?.includes(Dictionary.UHM_STRUCTURE_DEFINITION_URI + 'Diagnosis')) {
            //   // UHM
            //   throw new Error('Missing UHM profile');
            // }
            // const category = fhir.category[0]?.coding[0]?.code;
            // if ( category == 'encounter-diagnosis') {
            //   c = new Diagnosis();
            // } else {
            //   throw new Error(`Condition category ${category} not supported`);
            // }
            // // fhir ID
            const fhirId = this.toFhirIDPart(fhir);
            ep.id = fhirId;
            ep.subject = ModelToFHIRUtils.stubFromRef(fhir.subject, 'Patient');
            ep.author = this.participantToDataModel(fhir.author);
            ep.dateTime = fhir.occurrence;
            if (fhir.encounter) {
                ep.encounter = ModelToFHIRUtils.stubFromRef(fhir.encounter, 'Encounter');
            }
            ep.examCode = ModelToFHIRUtils.toCodedValueModel(fhir.code.concept);
            if (fhir.note?.length == 1) {
                ep.note = fhir.note[0].text;
            }
            if (fhir.supportingInfo) {
                ep.diagnosis = [];
                fhir.supportingInfo.forEach((item) => {
                    if (item.reference && item.reference.reference.includes('Condition')) {
                        ep.diagnosis.push(ModelToFHIRUtils.stubFromRef(item.reference, 'Condition'));
                    }
                    else if (item.concept) {
                        ep.specimenType = ModelToFHIRUtils.toCodedValueModel(item.concept);
                    }
                });
            }
            if (fhir.priority) {
                ep.priority = this.priorityList.find((p) => p.code == fhir.priority);
            }
            return ep;
        }
    }
    participantToDataModel(fhir) {
        let participant;
        if (fhir && fhir.function.coding[0].code == 'author') {
            participant = ModelToFHIRUtils.stubFromRef(fhir.actor, 'Practitioner');
        }
        return participant;
    }
}

class ProcedureFhirConverter extends AbstractFhirConverter {
    fromDataModel(model) {
        if (model instanceof Workout) {
            return this.fromDataModelWorkout(model);
        }
        else {
            throw new TypeError('Unsupported model type. Error converting from datamodel to FHIR.');
        }
    }
    toDataModel(resource, context) {
        let procedure;
        const codings = resource.category[0]?.coding;
        // list all conversion criteria. It mainly consists of a set of codes to be mapped n the local model
        // try matching all the codes (it stops at the first match)
        codings.some((coding) => {
            const code = coding.code;
            if (HeartValueSet.Common.Measurement.PHYSICAL_ACTIVITY_CODINGS.equals(code)) {
                procedure = this.toDataModelWorkout(resource, context);
                return true;
            }
            return false;
        });
        if (!procedure) {
            throw new TypeError('Unsupported procedure type. Error converting to datamodel from FHIR.');
        }
        // fhir ID
        procedure.id = this.toFhirIDPart(resource);
        if (resource.subject) {
            // procedure.patient = this.resolveSubject(
            //   resource.subject,
            //   resource,
            //   context
            // );
            procedure.patient = ModelToFHIRUtils.stubFromRef(resource.subject, 'Patient');
        }
        // procedure source
        if (resource.extension) {
            procedure.healthId = HeartExtension.Workout.healthId.extractValueFromExtensions(resource.extension);
            procedure.healthSource = HeartExtension.Workout.healthSource.extractValueFromExtensions(resource.extension);
        }
        return procedure;
    }
    toDataModelWorkout(resource, context) {
        // looks in the local coding definitions if there is one of the codes contained in 'resource'
        if (!HeartValueSet.Common.Measurement.PHYSICAL_ACTIVITY_CODINGS.equals(resource.category)) {
            throw new Error(`[ERROR] Wrong observation type in 'toDataModelWorkout'`);
        }
        const wk = new Workout();
        if (resource.performer && resource.performer.length > 0) {
            // WARNING - ONLY THE FIRST
            const performed = resource.performer[0];
            if (performed && performed instanceof Period) {
                wk.performedSince = performed.start;
                wk.performedTo = performed.end;
                wk.assertedWhen = performed.start;
            }
        }
        wk.automatic = HeartExtension.Workout.isAutomatic.extractValueFromExtensions(resource.extension);
        if (resource.code) {
            const code = resource.code.coding[0].code.toUpperCase();
            wk.workoutType = WorkoutType[code];
        }
        const wkIntensity = HeartExtension.Workout.intensity.extractValueFromExtensions(resource.extension);
        wk.intensity = WorkoutIntensity[wkIntensity?.toUpperCase()];
        const energyExpenditureQuantity = HeartExtension.Workout.energyExpenditure.extractValueFromExtensions(resource.extension);
        if (energyExpenditureQuantity) {
            const energyExpenditure = new EnergyExpenditure();
            energyExpenditure.value = energyExpenditureQuantity.value;
            wk.energyExpenditure = energyExpenditure;
        }
        const stepCounterQuantity = HeartExtension.Workout.stepCounter.extractValueFromExtensions(resource.extension);
        if (stepCounterQuantity) {
            const stepCounter = new StepCount();
            stepCounter.value = stepCounterQuantity.value;
            wk.stepCount = stepCounter;
        }
        const distanceQuantity = HeartExtension.Workout.distance.extractValueFromExtensions(resource.extension);
        if (distanceQuantity) {
            const distance = new Distance();
            distance.value = distanceQuantity.value;
            wk.distance = distance;
        }
        return wk;
    }
    fromDataModelWorkout(wk) {
        const proc = new Procedure$1();
        proc.category = [HeartValueSet.Common.Measurement.PHYSICAL_ACTIVITY_CODINGS.toCodeableConcept()];
        // paziente/soggetto
        if (wk.patient === undefined) {
            throw Error('Patient not found while converting the workout.');
        }
        proc.subject = ModelToFHIRUtils.getReference(wk.patient);
        if (wk.performedSince || wk.performedTo) {
            const performed = new Period();
            performed.start = wk.performedSince;
            performed.end = wk.performedTo;
            const performer = new Procedure$1.ProcedurePerformerComponent();
            performer.period = performed;
            proc.performer = [performer];
        }
        proc.extension = [];
        proc.extension.push(HeartExtension.Workout.isAutomatic.toExtensionBoolean(wk.automatic));
        if (wk.workoutType) {
            proc.code = new CodeableConcept();
            proc.code.coding = [
                new Coding({
                    code: WorkoutType[wk.workoutType].toString().toLowerCase(),
                    system: Dictionary.BASE_NAMESPACE,
                }),
            ];
        }
        if (wk.intensity) {
            // TODO: definire il mapping/codici?
            proc.extension.push(HeartExtension.Workout.intensity.toExtensionString(WorkoutIntensity[wk.intensity].toString().toUpperCase()));
        }
        if (wk.energyExpenditure) {
            const energyExpenditure = new Quantity();
            energyExpenditure.value = wk.energyExpenditure.value;
            energyExpenditure.unit = wk.energyExpenditure.unit;
            proc.extension.push(HeartExtension.Workout.energyExpenditure.toExtensionQuantity(energyExpenditure));
        }
        if (wk.stepCount) {
            const stepCount = new Quantity();
            stepCount.value = wk.stepCount.value;
            stepCount.unit = wk.stepCount.unit;
            proc.extension.push(HeartExtension.Workout.stepCounter.toExtensionQuantity(stepCount));
        }
        if (wk.distance) {
            const distance = new Quantity();
            distance.value = wk.distance.value;
            distance.unit = wk.distance.unit.toString();
            proc.extension.push(HeartExtension.Workout.distance.toExtensionQuantity(distance));
        }
        // procedure source
        if (wk.healthId) {
            if (!proc.extension) {
                proc.extension = [];
            }
            proc.extension.push(HeartExtension.Workout.healthId.toExtensionString(wk.healthId));
            if (wk.healthSource) {
                proc.extension.push(HeartExtension.Workout.healthSource.toExtensionString(wk.healthSource));
            }
        }
        return proc;
    }
}

// tslint:disable: max-line-length no-inferrable-types no-redundant-jsdoc
class QuestionnaireFhirConverter extends AbstractFhirConverter {
    toDataModel(resource, context) {
        if (resource instanceof Questionnaire) {
            return this.toDataModelQuestionnaire(resource);
        }
        else {
            return undefined;
        }
    }
    fromDataModel(model) {
        if (model instanceof Questionnaire$1) {
            return this.fromDataModelQuestionnaire(model);
        }
        else {
            throw new TypeError('Unsupported model type. Error converting from datamodel to FHIR.');
        }
    }
    toDataModelQuestionnaire(fhir) {
        const q = new Questionnaire$1('', []);
        q.id = fhir.id ? +fhir.id : undefined;
        q.title = fhir.title;
        q.name = QuestionnaireFhirConverter.PREFIX + fhir.name + QuestionnaireFhirConverter.SUFFIX;
        q.questionnaireId = fhir.url;
        q.items = fhir.item?.map(item => this.toDataModelQuestionOrGroup(item)) || [];
        return q;
    }
    toDataModelQuestion(fhir) {
        if (fhir.type == Questionnaire.QuestionnaireItemType.GROUP.toString()) {
            throw new Error(`Invalid QuestionnaireItemComponent for 'group' in toDataModelQuestion method (invoke 'toDataModelQuestionOrGroup')`);
        }
        const q = new Question();
        q.questionId = fhir.linkId;
        q.prefix = fhir.prefix;
        if (fhir.code?.length > 0) {
            const code = fhir.code[0];
            q.code = new CodedValue(code.system, code.code, code.display);
            q.text = QuestionnaireFhirConverter.PREFIX + q.code.system + QuestionnaireFhirConverter.SEPARATOR + q.code.code + QuestionnaireFhirConverter.SUFFIX;
        }
        else {
            q.text = fhir.text;
        }
        q.multiChoice = fhir.repeats;
        q.readOnly = fhir.readOnly;
        q.required = fhir.required;
        if (fhir.type) {
            switch (fhir.type) {
                case Questionnaire.QuestionnaireItemType.BOOLEAN.toString():
                    q.type = QuestionType.boolean;
                    break;
                // FIXME
                // case FHIRQuestionnaire.QuestionnaireItemType.BOOLEAN.toString(): q.type = QuestionType.CodedValue; break;
                case Questionnaire.QuestionnaireItemType.DATE.toString():
                    q.type = QuestionType.date;
                    break;
                // case FHIRQuestionnaire.QuestionnaireItemType.DATETIME.toString(): q.type = QuestionType.dateTime; break;
                case Questionnaire.QuestionnaireItemType.DISPLAY.toString():
                    q.type = QuestionType.display;
                    break;
                case Questionnaire.QuestionnaireItemType.DECIMAL.toString():
                    q.type = QuestionType.decimal;
                    // FIXME: where are min and max?
                    // Min and Max are used only for numeric datatype
                    // Extension: http://hl7.org/fhir/StructureDefinition/minValue
                    q.min = HeartExtension.Questionnaire.minValue.extractValueFromExtensions(fhir.extension);
                    // Extension: http://hl7.org/fhir/StructureDefinition/maxValue
                    q.max = HeartExtension.Questionnaire.maxValue.extractValueFromExtensions(fhir.extension);
                    break;
                case Questionnaire.QuestionnaireItemType.INTEGER.toString():
                    q.type = QuestionType.integer;
                    // FIXME: where are min and max?
                    // Min and Max are used only for numeric datatype
                    // Extension: http://hl7.org/fhir/StructureDefinition/minValue
                    q.min = HeartExtension.Questionnaire.minValue.extractValueFromExtensions(fhir.extension);
                    // Extension: http://hl7.org/fhir/StructureDefinition/maxValue
                    q.max = HeartExtension.Questionnaire.maxValue.extractValueFromExtensions(fhir.extension);
                    break;
                case Questionnaire.QuestionnaireItemType.TEXT.toString():
                    q.type = QuestionType.text;
                    // Max length is used only for textual datatype
                    q.maxLength = fhir.maxLength;
                    break;
                case Questionnaire.QuestionnaireItemType.STRING.toString():
                    q.type = QuestionType.string;
                    // Max length is used only for textual datatype
                    q.maxLength = fhir.maxLength;
                    break;
                case Questionnaire.QuestionnaireItemType.CODING.toString():
                case 'coding': // 'coding' replaces 'choice' since FHIR R5
                    q.type = QuestionType.CodedValue;
                    break;
            }
        }
        else if (!(fhir.answerOption?.length > 0) || !(fhir.answerValueSet)) {
            throw new Error(`Questionnaire not valid as it is missing both 'type' and 'answerOption/answerValueSet'.`);
        }
        if (fhir.answerOption) {
            // FIXME
            const permittedAnswers = fhir.answerOption?.map(ao => this.toDataModelQuestionChoice(ao));
            q.permittedAnswers = permittedAnswers;
        }
        else if (fhir.answerValueSet) {
            q.permittedAnswers = this.toDataModelQuestionChoiceValueSet(fhir.answerValueSet);
        }
        if (q.multiChoice && !(q.permittedAnswers?.length > 0)) {
            console.error(`The questionnaire attribute 'repeats == true' is not supported for question without a predefined set of choices`);
        }
        if (fhir.enableWhen) {
            q.enableWhen = this.toDataModelQuestionEnableWhen(fhir.enableWhen, fhir.enableBehavior);
        }
        // q.items = fhir.item?.map(item => this.toDataModelQuestionOrGroup(item));
        // UHM supports only nested Question (not 'group')
        q.items = fhir.item?.map(item => this.toDataModelQuestion(item));
        return q;
    }
    toDataModelQuestionOrGroup(fhir) {
        if (fhir.type == Questionnaire.QuestionnaireItemType.GROUP.toString()) {
            return this.toDataModelGroup(fhir);
        }
        else {
            return this.toDataModelQuestion(fhir);
        }
    }
    toDataModelGroup(fhir) {
        if (fhir.type != Questionnaire.QuestionnaireItemType.GROUP.toString()) {
            throw new Error(`Invalid QuestionnaireItemComponent for '${fhir.type}' in toDataModelQuestion method (invoke 'toDataModelQuestion')`);
        }
        const group = new QuestionGroup();
        group.groupId = fhir.linkId;
        group.required = fhir.required;
        group.prefix = fhir.prefix;
        if (fhir.code?.length > 0) {
            const code = fhir.code[0];
            group.code = new CodedValue(code.system, code.code, code.display);
            group.text = QuestionnaireFhirConverter.PREFIX + group.code.system + QuestionnaireFhirConverter.SEPARATOR + group.code.code + QuestionnaireFhirConverter.SUFFIX;
        }
        else {
            group.text = fhir.text;
        }
        group.repeated = fhir.repeats;
        group.items = fhir.item?.map(item => this.toDataModelQuestionOrGroup(item));
        // verifica che nelle domande del suo gruppo non ci sia nulla di obbligatorio, altrimenti visualizza un asterisco nel titolo della sezione
        // if any subquestion is mandatory, set an attribute used only the gui, to render a *. THIS DOES NOT IMPACT THE VALIDATOR - ONLY UX MATTER
        if (group.items && group.items[0] instanceof Question) {
            group.showSubStar = group.items.some(i => i.required);
        }
        return group;
    }
    /**
     * Convert the well known ValueSet option in a Choice array
     * @param answerValueSet
     */
    toDataModelQuestionChoiceValueSet(answerValueSet) {
        if (!answerValueSet) {
            return undefined;
        }
        if (this.valueSetResolver != undefined) {
            return this.valueSetResolver(answerValueSet);
        }
        let choices = undefined;
        // FIXME: how can we support a custom ValueSet? -> SPOSTATO NEL CONNECTOR
        // if ( answerValueSet == 'http://hl7.org/fhir/ValueSet/yesnodontknow' ) {
        //   choices = [
        //     new Choice(new CodedValue("http://terminology.hl7.org/CodeSystem/v2-0532", "Y", "Yes"), QuestionnaireFhirConverter.PREFIX + "valueset.yesnodontknow.yes"),
        //     new Choice(new CodedValue("http://terminology.hl7.org/CodeSystem/v2-0532", "N", "No"), QuestionnaireFhirConverter.PREFIX + "valueset.yesnodontknow.no"),
        //     new Choice(new CodedValue("http://terminology.hl7.org/CodeSystem/data-absent-reason", "asked-unknown", "Don't know"), QuestionnaireFhirConverter.PREFIX + "valueset.yesnodontknow.unknown"),
        //   ];
        // } else if ( answerValueSet == 'http://it4h.eng.it/uhm/ValueSet/patient-history-status' ) {
        //   choices = [
        //     new Choice(new CodedValue("http://terminology.hl7.org/CodeSystem/condition-clinical", "active", "Active"), QuestionnaireFhirConverter.PREFIX + "valueset.patient-history-status.active"),
        //     new Choice(new CodedValue("http://terminology.hl7.org/CodeSystem/condition-clinical", "inactive", "Inactive"), QuestionnaireFhirConverter.PREFIX + "valueset.patient-history-status.inactive"),
        //     new Choice(new CodedValue("http://terminology.hl7.org/CodeSystem/condition-clinical", "unknown", "Unknown"), QuestionnaireFhirConverter.PREFIX + "valueset.patient-history-status.unknown"),
        //   ];
        // } else if ( answerValueSet == 'http://it4h.eng.it/uhm/ValueSet/biological-family-member' ) {
        //   choices = [
        //     new Choice(new CodedValue("http://terminology.hl7.org/CodeSystem/v3-RoleCode", "DAU", "Natural daughter"), QuestionnaireFhirConverter.PREFIX + "valueset.biological-family-member.natural-daughter"),
        //     new Choice(new CodedValue("http://terminology.hl7.org/CodeSystem/v3-RoleCode", "SON", "Natural son"), QuestionnaireFhirConverter.PREFIX + "valueset.biological-family-member.natural-son"),
        //     new Choice(new CodedValue("http://terminology.hl7.org/CodeSystem/v3-RoleCode", "NMTH", "Natural mother"), QuestionnaireFhirConverter.PREFIX + "valueset.biological-family-member.natural-mother"),
        //     new Choice(new CodedValue("http://terminology.hl7.org/CodeSystem/v3-RoleCode", "NFTH", "Natural father"), QuestionnaireFhirConverter.PREFIX + "valueset.biological-family-member.natural-father"),
        //   ];
        // } else {
        //   // throw new Error(`Unknown valueset ${answerValueSet}. The data model Choice set can't be created.`);
        choices = answerValueSet;
        // }
        return choices;
    }
    toDataModelQuestionChoice(fhir) {
        let value = undefined;
        if (fhir.value instanceof Coding) {
            const code = fhir.value;
            value = new CodedValue(code.system, code.code, code.display);
        }
        else if (fhir.value instanceof Reference) {
            throw new Error(`FHIR Reference value type not supported in 'toDataModelQuestionChoice'`);
        }
        else {
            value = fhir.value;
        }
        const choice = new Choice(value);
        return choice;
    }
    toDataModelQuestionEnableWhen(fhirEnableWhen, enableBehavior) {
        if (!(fhirEnableWhen?.length > 0)) {
            return undefined;
        }
        const ew = new QuestionEnableWhen();
        if (enableBehavior) {
            ew.behaviour = enableBehavior == 'all' ? 'all' : 'any';
        }
        ew.conditions = fhirEnableWhen.map(few => {
            const condition = new QuestionEnableWhenCondition();
            condition.question = few.question;
            switch (few.operator) {
                case 'exists':
                    condition.operator = QuestionEnableWhenOperator.EXISTS;
                    break;
                case '=':
                    condition.operator = QuestionEnableWhenOperator.EQ;
                    break;
                case '!=':
                    condition.operator = QuestionEnableWhenOperator.NE;
                    break;
                case '>':
                    condition.operator = QuestionEnableWhenOperator.GT;
                    break;
                case '<':
                    condition.operator = QuestionEnableWhenOperator.LT;
                    break;
                case '>=':
                    condition.operator = QuestionEnableWhenOperator.GE;
                    break;
                case '<=':
                    condition.operator = QuestionEnableWhenOperator.LE;
                    break;
            }
            // boolean | number | number | Date | Date | Date | string | Coding | Quantity | Reference;
            const fhirAnswer = few.answer;
            if (fhirAnswer instanceof Date) {
                condition.answer = fhirAnswer;
            }
            else if (fhirAnswer instanceof Coding) {
                condition.answer = new CodedValue(fhirAnswer.system, fhirAnswer.code, fhirAnswer.display);
            }
            else if (fhirAnswer instanceof Quantity) {
                throw new Error(`Unsupported FhirQuantity value in 'enableWhen'`);
            }
            else if (fhirAnswer instanceof Reference) {
                throw new Error(`Unsupported FhirReference value in 'enableWhen'`);
            }
            else {
                condition.answer = fhirAnswer;
            }
            return condition;
        });
        return ew;
    }
    fromDataModelQuestionnaire(model) {
        //Implementazione da continuare
        /*     const fhir = new FHIRQuestionnaire();
            fhir.id = !!model.id ? model.id + '' : undefined;
        
            fhir.url = model.questionnaireId;
        
            fhir.name = model.name;
        
            fhir.title = model.title;
        
            fhir.item = model.items?.map(item => this. (item)) || [];
        
            return fhir; */
        throw new Error(`fromDataModelQuestionnaireResponse not implemented`);
    }
}
QuestionnaireFhirConverter.PREFIX = "questionnaire.";
QuestionnaireFhirConverter.SEPARATOR = "|";
QuestionnaireFhirConverter.SUFFIX = ".label";

// tslint:disable: max-line-length no-inferrable-types no-redundant-jsdoc
class QuestionnaireResponseFhirConverter extends AbstractFhirConverter {
    toDataModel(resource, context) {
        if (resource instanceof QuestionnaireResponse) {
            return this.toDataModelQuestionnaireResponse(resource, context);
        }
        else {
            return undefined;
        }
    }
    fromDataModel(model) {
        if (model instanceof QuestionnaireResponse$1) {
            return this.fromDataModelQuestionnaireResponse(model);
        }
        else {
            throw new TypeError('Unsupported model type. Error converting from datamodel to FHIR.');
        }
    }
    toDataModelQuestionnaireResponse(fhir, context) {
        if (!fhir) {
            throw new Error('Missing FHIR questionnaire response');
        }
        let questionnaire;
        if (fhir.questionnaire) {
            questionnaire = new Questionnaire$1(fhir.questionnaire);
        }
        const response = new QuestionnaireResponse$1(questionnaire);
        response.id = fhir.id ? +fhir.id : undefined;
        if (fhir.status == 'completed' || fhir.status == 'in-progress') {
            if (fhir.status == 'completed') {
                response.status = ResponseStatus.completed;
            }
            else if (fhir.status == 'in-progress') {
                response.status = ResponseStatus.inprogress;
            }
        }
        if (fhir.authored != undefined) {
            response.date = fhir.authored;
        }
        response.subject = ModelToFHIRUtils.stubFromRef(fhir.subject, 'Patient');
        response.author = ModelToFHIRUtils.stubFromRef(fhir.author, 'Practitioner');
        /*
         * FIXME: workaround to identify RepeatedAnswerGroup as the discriminator is only available in the Questionnaire resource.
         * An alternative it to remove the RepeatedAnswerGroup type in the datamodel
         */
        // const repeatableAnswerGroupIDs: string[] = [];
        // if ( context ) {
        //   const ns = context.entry?.find(e => e.resource instanceof NamingSystem)?.resource as NamingSystem;
        //   if ( ns ) {
        //     repeatableAnswerGroupIDs.push(...(ns.uniqueId?.map(uId => uId.value) || []));
        //   }
        // }
        if (fhir.item) {
            response.answers = this.toDataModelAnswers(fhir.item);
        }
        if (fhir.questionnaire) {
            response.questionnaireUrl = fhir.questionnaire;
        }
        return response;
    }
    toDataModelAnswers(fhirItems) {
        // sorted array of answers
        const answers = fhirItems?.map((item) => this.toDataModelAnswers2(item)).filter(a => !!a) || [];
        // const groupOfAnswers: Answer[] = answers.filter(a => a instanceof Answer) as Answer[];
        // const groupOfAnswerGroups: AnswerGroup[] = answers.filter(a => a instanceof AnswerGroup) as AnswerGroup[];
        // // this code is a tentative approach to identify a 'RepeatedAnswerGroup'.
        // // It starts with creating a map by groupId and, in case of recurring items it assumes that it is facing a RepeatedAnswerGroup
        // const groupedAnswerGroups: { [key: string]: AnswerGroup[] } = this.groupBy(groupOfAnswerGroups) as { [key: string]: AnswerGroup[] };
        // const answerGroups: (AnswerGroup | RepeatedAnswerGroup)[] = Object.entries(groupedAnswerGroups).map(entry => {
        //   if (entry[1].length > 1 || repeatableAnswerGroupIDs.includes(entry[0])) { // FIXME: se è stato inserito un solo gruppo non entra - funziona solo con 2 elementi "repeatable"
        //     const repeatedGroup = new RepeatedAnswerGroup();
        //     repeatedGroup.groupId = entry[0] as string;
        //     repeatedGroup.answers = entry[1] as AnswerGroup[];
        //     return repeatedGroup;
        //   } else {
        //     return entry[1][0];
        //   }
        // });
        // unsorted array of answers
        // let result = [...groupOfAnswers, ...answerGroups];
        // restore the original answer order
        // result = this.sortAnswers(answers, result);
        return answers;
    }
    // private groupBy(answers: AnswerGroup[]): { [key: string]: AnswerGroup[] } {
    //   const results: { [key: string]: AnswerGroup[] } = {};
    //   answers.forEach(a => {
    //     const aKey = a.groupId;
    //     let value = results[aKey];
    //     if ( !value ) {
    //       value = [];
    //       results[aKey] = value;
    //     }
    //     value.push(a);
    //   })
    //   return results;
    // }
    toDataModelAnswers2(fhir) {
        // If there are no answers and there are innested items
        if (fhir.item?.length > 0 && !(fhir.answer?.length > 0)) {
            // if the component has nested items it is an AnswerGroup
            const answer = new AnswerGroup();
            answer.groupId = fhir.linkId;
            answer.answers = this.toDataModelAnswers(fhir.item);
            return answer;
            // If there are answers
        }
        else if (fhir.answer?.length > 0) {
            // if it has some answers it is a simple Answer
            const answer = new Answer();
            answer.questionId = fhir.linkId;
            answer.value = this.extractFHIRQuestionAnswer(fhir.answer);
            // only in case that there is only one answer checks if it has nested answers
            if (fhir.answer.length == 1 && fhir.answer[0].item?.length > 0) {
                answer.answers = fhir.answer[0].item.map(ni => this.toDataModelAnswers2(ni));
            }
            return answer;
        }
        return undefined;
    }
    extractFHIRQuestionAnswer(answers) {
        const results = answers?.map(a => {
            if (a.value instanceof Coding) {
                return new CodedValue(a.value.system, a.value.code, a.value.display);
            }
            else {
                return a.value ?? (a['valueBoolean']);
            }
        });
        if (results.length > 1) {
            return results;
        }
        else {
            return results[0];
        }
    }
    fromDataModelQuestionnaireResponse(model) {
        const fhir = new QuestionnaireResponse();
        fhir.id = !!model.id ? model.id + '' : undefined;
        if (model.author) {
            fhir.author = ModelToFHIRUtils.getReference(model.author);
        }
        fhir.questionnaire = model.questionnaire?.questionnaireId;
        fhir.status = model.status?.toString();
        fhir.authored = model.date;
        if (model.subject) {
            fhir.subject = ModelToFHIRUtils.getReference(model.subject);
        }
        if (model.source) {
            fhir.source = ModelToFHIRUtils.getReference(model.source);
        }
        if (model.answers?.length > 0) {
            const answers = this.manageFromDataModelAnswers(model.answers);
            fhir.item = answers?.length > 0 ? answers : undefined;
        }
        return fhir;
    }
    manageFromDataModelAnswers(modelAnswers) {
        let responseItemComponents;
        responseItemComponents = modelAnswers?.flatMap((answer) => {
            if (answer) {
                if (answer instanceof Answer) {
                    return this.toAnswer(answer);
                }
                else if (answer instanceof AnswerGroup && answer?.answers?.length > 0) {
                    return this.toAnswerGroup(answer);
                }
            }
            return undefined;
        });
        // remove empty answers and any answer without items
        responseItemComponents = responseItemComponents?.filter(answer => answer != undefined && (answer.item?.length > 0 || answer?.answer?.length > 0));
        return responseItemComponents;
    }
    toAnswer(answer) {
        const itemComponent = new QuestionnaireResponse.QuestionnaireResponseItemComponent();
        itemComponent.linkId = answer.questionId;
        const answerValue = this.fromDataModelToAnswerValue(answer.value);
        const answerValueArray = Array.isArray(answerValue) ? answerValue : [answerValue];
        itemComponent.answer = answerValueArray?.map((av) => {
            const answerItemComponent = new QuestionnaireResponse.QuestionnaireResponseItemAnswerComponent();
            answerItemComponent.value = av;
            return answerItemComponent;
        });
        // serialize the nested question answers that are nested in a 'simple' question
        const nestedAnswers = answer.answers?.filter(a => a != undefined);
        if (nestedAnswers?.length > 0) {
            const items = nestedAnswers?.flatMap(answer => {
                if (answer) {
                    if (answer instanceof AnswerGroup) {
                        return this.toAnswerGroup(answer);
                    }
                    else {
                        return this.toAnswer(answer);
                    }
                }
                return undefined;
            })
                .filter(item => item != undefined);
            if (items.length > 0) {
                if (itemComponent.answer.length == 1) {
                    itemComponent.answer[0].item = items;
                }
                else if (!(itemComponent.answer?.length > 0)) {
                    itemComponent.item = items;
                }
                else {
                    console.log("Ignore nested answers as there are several answers at first level. Nested are supported for single first level answers.");
                }
            }
        }
        return itemComponent;
    }
    toAnswerGroup(answerGroup) {
        let itemComponent = new QuestionnaireResponse.QuestionnaireResponseItemComponent();
        itemComponent.linkId = answerGroup.groupId;
        const items = answerGroup.answers
            ?.flatMap(answer => {
            if (answer) {
                if (answer instanceof AnswerGroup) {
                    return this.toAnswerGroup(answer);
                }
                else {
                    return this.toAnswer(answer);
                }
            }
            return undefined;
        })
            .filter(item => item != undefined);
        if (items.length > 0) {
            itemComponent.item = items;
            return itemComponent;
        }
        else {
            return undefined;
        }
    }
    convertIntoCoding(codedValue) {
        let codingValue = new Coding();
        codingValue.system = codedValue.system;
        codingValue.code = codedValue.code;
        codingValue.display = codedValue.originalDisplay ?? (codedValue.display?.includes('.label') ? undefined : codedValue.display); // FIXME Evita il 422
        return codingValue;
    }
    fromDataModelToAnswerValue(answerValue) {
        if (answerValue instanceof CodedValue) {
            return this.convertIntoCoding(answerValue);
        }
        else if (Array.isArray(answerValue) && answerValue?.length > 0 && answerValue[0] instanceof CodedValue) {
            return answerValue?.map(av => this.convertIntoCoding(av));
        }
        else if (typeof answerValue == 'boolean' || answerValue instanceof Boolean) {
            return answerValue;
        }
        else if (typeof answerValue == 'number' || answerValue instanceof Number) {
            return answerValue;
        }
        else if (typeof answerValue == 'string' || answerValue instanceof String) {
            return answerValue;
        }
        else if (answerValue instanceof Date) {
            return answerValue;
        }
        return undefined;
    }
}

class VcfMetadataFhirConverter extends AbstractFhirConverter {
    constructor() {
        super(...arguments);
        this.SUPPORTED_VCF = 'filtered-vcf';
        this.SUPPORTED_CRAM = 'cram';
    }
    // private SUPPORTED_VCF = 'vcf'
    fromDataModel(model) {
        throw new TypeError('Unsupported model type. Error converting from datamodel to FHIR.');
    }
    // TODO: to check with actual response from the server
    toDataModel(resource, context) {
        const toRet = new Study();
        toRet.vcfsMeta = [];
        const curr = new VcfMetadata();
        resource.analysis?.forEach(a => {
            // we only use the filtered-vcf > output[x].type.coding[x].code
            const supportedVCF = a.output.find(o => { return o.type.coding[0].code == this.SUPPORTED_VCF; });
            if (supportedVCF) {
                curr.date = a.date;
                // const ref = (a.output[0]?.file as Reference)?.reference
                const ref = supportedVCF?.file?.reference;
                curr.diagnosticReportReferenceId = ref ? ref.split("/")[1] : undefined; // FIXME array in fhir, single attribute in easy model
                curr.sequencing = ModelToFHIRUtils.toCodedValueModel(a.methodType[0]);
                if (a.specimen) {
                    // a.specimen.forEach(r => {}) // FIXME array in fhir, single attribute in easy model
                    const id = a.specimen[0].getReferenceIdPart();
                    curr.specimen = this.getSpecimenCV(id, context);
                }
                toRet.vcfsMeta.push(curr); // push only if filtered VCF is presetn
            }
            const supportedCram = a.output.find(o => { return o.type.coding[0].code == this.SUPPORTED_CRAM; });
            if (supportedCram) {
                // CRAM if VCF exists
                const ref = supportedCram?.file?.reference;
                curr.cramReportReferenceId = ref ? ref.split("/")[1] : undefined; // FIXME array in fhir, single attribute in easy model
            }
        });
        return toRet;
    }
    getSpecimenCV(id, context) {
        let toRet;
        if (id && context) {
            let res = context.entry.find(e => e.resource.id == id);
            if (res) {
                toRet = ModelToFHIRUtils.toCodedValueModel(res.resource.type);
            }
        }
        return toRet;
    }
}

class PlanDefinitionFhirConverter extends AbstractFhirConverter {
    fromDataModel(model) {
        const planD = new PlanDefinition$1();
        planD.id = !!model.id ? model.id + '' : undefined;
        planD.status = PlanDefinition$1.PublicationStatus.ACTIVE.toString();
        if (model.focus) {
            let useContext = new UsageContext();
            useContext.code = new Coding({
                code: 'focus',
                display: 'Clinical focus',
                system: Dictionary.USAGE_CONTEXT_TYPE,
            });
            useContext.value = ModelToFHIRUtils.fromCodedValueModel(model.focus);
            planD.useContext = [useContext];
        }
        planD.topic = this.fromDataModelTopic(model.topic);
        const fhirGoals = [];
        // set a goals included in the plan
        // TODO: put the goals also into the Activities
        if (model.goals) {
            model.goals.forEach((goal) => {
                fhirGoals.push(this.fromDataModelGoalDef(goal));
            });
        }
        planD.goal = fhirGoals;
        const fhirActions = [];
        // set a goals included in the plan
        // TODO: put the goals also into the Activities
        if (model.activities) {
            model.activities.forEach((activity) => {
                fhirActions.push(this.fromDataModelActivityDef(activity));
            });
        }
        planD.action = fhirActions;
        return planD;
    }
    fromDataModelTopic(type) {
        if (type == PlanDefinition.PlanTopic.EDUCATION) {
            return [FhirUtils.createCodeableConcept(Dictionary.HL7_TERMINLOGY_NAMESPACE + 'definition-topic', 'education', 'Treatment')];
        }
        else if (type == PlanDefinition.PlanTopic.ASSESSMENT) {
            return [FhirUtils.createCodeableConcept(Dictionary.HL7_TERMINLOGY_NAMESPACE + 'definition-topic', 'assessment', 'Treatment')];
        }
        else if (type == PlanDefinition.PlanTopic.TREATMENT) {
            return [FhirUtils.createCodeableConcept(Dictionary.HL7_TERMINLOGY_NAMESPACE + 'definition-topic', 'treatment', 'Treatment')];
        }
        return undefined;
    }
    fromDataModelGoalDef(goal) {
        const toRet = new PlanDefinition$1.PlanDefinitionGoalComponent();
        const targets = [];
        let duration = undefined;
        if (goal.durationInDays) {
            duration = new Duration();
            duration.unit = 'd';
            duration.system = Dictionary.UNIT_OF_MEASURE;
            duration.value = goal.durationInDays;
        }
        goal.targets.forEach((lTarget) => {
            const target = TargetUtils.fromDataModelTargetDefinition(lTarget);
            target.due = duration;
            targets.push(target);
        });
        toRet.target = targets;
        if (goal.type) {
            toRet.description = ModelToFHIRUtils.fromCodedValueModel(goal.type);
            toRet.description.text = goal.description;
        }
        return toRet;
    }
    toDataModel(fhirRes, context) {
        const model = new PlanDefinition();
        // fhir ID
        const fhirId = this.toFhirIDPart(fhirRes);
        model.id = fhirId;
        if (fhirRes.status) {
            model.status = FhirCodesMapperUtils.PlanDefinitionStatusFromFHIR(fhirRes.status);
        }
        if (fhirRes.useContext?.length > 0) {
            const focus = fhirRes.useContext?.find((uc) => {
                return uc.code?.code == 'focus' && uc.value instanceof CodeableConcept;
            });
            if (focus) {
                model.focus = ModelToFHIRUtils.toCodedValueModel(focus.value);
            }
            const age = fhirRes.useContext?.find((uc) => {
                return uc.code?.code == 'age' && uc.value instanceof Range;
            });
            if (age) {
                const range = age.value;
                model.ageRange = { min: range?.low?.value, max: range?.high?.value };
            }
        }
        if (fhirRes.topic?.length > 0) {
            model.topic = this.toDataModelTopic(fhirRes.topic[0]);
        }
        const fhirGoals = fhirRes.goal;
        // the converter is assuming that references have been already solved into resources
        if (fhirGoals?.length > 0) {
            const goals = fhirGoals.map((g) => {
                return this.toDataModelGoalDef(g);
            });
            model.goals = goals;
        }
        const fhirActivities = fhirRes.action;
        if (fhirActivities && fhirActivities.length > 0) {
            const activities = [];
            fhirActivities.forEach((fhirActivity) => {
                const act = this.toDataModelActivityDef(fhirActivity, context);
                if (act) {
                    activities.push(act);
                }
            });
            model.activities = activities;
        }
        return model;
    }
    toDataModelGoalDef(fGoal) {
        const lGoal = new Goal();
        if (fGoal.description) {
            if (fGoal.description.coding) {
                lGoal.type = ModelToFHIRUtils.toCodedValueModel(fGoal.description);
            }
            lGoal.description = fGoal.description.text;
        }
        if (fGoal.target?.length > 0) {
            const lTargets = [];
            fGoal.target.forEach((fTarget) => {
                const target = TargetUtils.toDataModelTarget(fTarget);
                lGoal.durationInDays = this.getDuration(fTarget.due);
                lTargets.push(target);
            });
            lGoal.targets = lTargets;
        }
        return lGoal;
    }
    toDataModelTopic(type) {
        const tc = type?.coding[0];
        if (tc?.code == 'education') {
            return PlanDefinition.PlanTopic.EDUCATION; //[FhirUtils.createCodeableConcept(Dictionary.HL7_TERMINLOGY_NAMESPACE + 'definition-topic', 'education', 'Treatment')];
        }
        else if (tc?.code == 'assessment') {
            return PlanDefinition.PlanTopic.ASSESSMENT; //[FhirUtils.createCodeableConcept(Dictionary.HL7_TERMINLOGY_NAMESPACE + 'definition-topic', 'assessment', 'Treatment')];
        }
        else if (tc?.code == 'treatment') {
            return PlanDefinition.PlanTopic.TREATMENT; //[FhirUtils.createCodeableConcept(Dictionary.HL7_TERMINLOGY_NAMESPACE + 'definition-topic', 'treatment', 'Treatment')];
        }
        return undefined;
    }
    fromDataModelActivityDef(activity) {
        console.error('Method not implemented.');
        return undefined;
    }
    toDataModelActivityDef(fhirActivity, context) {
        console.error('Method not implemented.');
        return undefined;
    }
}

class RiskFhirConverter extends AbstractFhirConverter {
    toDataModel(fhir, context) {
        let model = new Risk(+fhir.id);
        model.patient = ModelToFHIRUtils.stubFromRef(fhir.subject, 'Patient');
        if (fhir.occurrence instanceof Date)
            model.date = fhir.occurrence;
        fhir.prediction?.forEach((fPrediction) => {
            const mPrediction = new Risk.Prediction();
            if (fPrediction.outcome) {
                mPrediction.code = ModelToFHIRUtils.toCodedValueModel(fPrediction.outcome);
            }
            if (fPrediction.probability) {
                if (typeof fPrediction.probability == 'number') {
                    mPrediction.probability = fPrediction.probability;
                }
                else {
                    mPrediction.range = { min: fPrediction.probability.low?.value, max: fPrediction.probability.high?.value };
                }
            }
            if (fPrediction.qualitativeRisk) {
                mPrediction.level = FhirCodesMapperUtils.RiskProbabilityFromFHIR(fPrediction.qualitativeRisk);
            }
            if (fPrediction.when && fPrediction.when instanceof Range) {
                const r = fPrediction.when;
                mPrediction.maxAge = r.high?.value;
                mPrediction.minAge = r.low?.value;
            }
            model.predictions.push(mPrediction);
        });
        if (fhir.mitigation)
            model.mitigation = fhir.mitigation;
        return model;
    }
    fromDataModel(model) {
        const fhir = new RiskAssessment();
        fhir.id = !!model.id ? model.id + '' : undefined;
        fhir.subject = ModelToFHIRUtils.getReference(model.subject);
        fhir.status = 'final';
        fhir.occurrence = model.date;
        if (model.predictions.length > 0)
            fhir.prediction = [];
        model.predictions.forEach((mPrediction) => {
            const prediction = new RiskAssessment.RiskAssessmentPredictionComponent();
            if (mPrediction.range) {
                if (mPrediction.range.min == mPrediction.range.max) {
                    prediction.probability = Math.round(mPrediction.probability * 100000) / 100000;
                }
                else if (mPrediction.range.max || mPrediction.range.min) {
                    const prob = new Range();
                    if (mPrediction.range.max) {
                        prob.high = this.createProbQuantity(mPrediction.range.max);
                    }
                    if (mPrediction.range.min) {
                        prob.low = this.createProbQuantity(mPrediction.range.min);
                    }
                    prediction.probability = prob;
                }
            }
            prediction.outcome = ModelToFHIRUtils.fromCodedValueModel(mPrediction.code);
            prediction.qualitativeRisk = FhirCodesMapperUtils.RiskProbabilityToFHIR(mPrediction.level);
            if (mPrediction.maxAge || mPrediction.minAge) {
                const when = new Range();
                if (mPrediction.maxAge) {
                    when.high = this.createAgeQuantity(mPrediction.maxAge);
                }
                if (mPrediction.minAge) {
                    when.low = this.createAgeQuantity(mPrediction.minAge);
                }
                prediction.when = when;
            }
            fhir.prediction.push(prediction);
        });
        if (model.mitigation)
            fhir.mitigation = model.mitigation;
        return fhir;
    }
    createAgeQuantity(age) {
        const v = new Quantity();
        v.code = 'a';
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.unit = 'years';
        v.value = age;
        return v;
    }
    createProbQuantity(prob) {
        const v = new Quantity();
        v.code = '%';
        v.system = Dictionary.UNIT_OF_MEASURE;
        v.unit = '%';
        v.value = prob;
        return v;
    }
}

// tslint:disable: max-line-length no-inferrable-types no-redundant-jsdoc
class TrialSubjectFhirConverter extends AbstractFhirConverter {
    toDataModel(resource, context) {
        return TrialSubjectFhirConverter.fromFHIR(resource);
    }
    fromDataModel(model) {
        if (model instanceof TrialSubject) {
            return TrialSubjectFhirConverter.toFHIR(model);
        }
        else {
            throw new TypeError('Unsupported model type. Error converting from datamodel to FHIR.');
        }
    }
    static fromFHIR(fhir) {
        const model = new TrialSubject(+fhir.id);
        model.patient = ModelToFHIRUtils.stubFromRef(fhir.subject, 'Patient');
        model.study = ModelToFHIRUtils.stubFromRef(fhir.study);
        model.group = new CodedValue(Dictionary.UHM_TRIAL_GROUP_SYSTEM, fhir.assignedComparisonGroup);
        return model;
    }
    static toFHIR(model) {
        const fhir = new ResearchSubject();
        fhir.id = !!model.id ? model.id + '' : undefined;
        fhir.subject = ModelToFHIRUtils.getReference(model.patient);
        fhir.study = ModelToFHIRUtils.getReference(model.study);
        fhir.status = 'active';
        fhir.assignedComparisonGroup = model.group.code;
        return fhir;
    }
}

class NutritionFhirConverter extends AbstractFhirConverter {
    toDataModel(fhir, context) {
        const model = new Nutrition(+fhir.id);
        // Estrai il paziente dal subject reference
        model.patient = ModelToFHIRUtils.stubFromRef(fhir.subject, 'Patient');
        // Imposta la data (se presente). Verifica comunque se è tipo Date o period, anche se dovremmo avere solo date
        if (fhir.occurrence) {
            if (fhir.occurrence instanceof Date) {
                model.date = fhir.occurrence;
            }
            else if (fhir.occurrence instanceof Period && fhir.occurrence.start) {
                model.date = new Date(fhir.occurrence.start);
            }
        }
        model.items = [];
        // Itera sui consumedItem e mappa nutritionProduct e amount
        fhir.consumedItem?.forEach((fConsumedItem) => {
            if (fConsumedItem.nutritionProduct?.concept?.coding?.length > 0) {
                const nutritionItem = new NutritionItem();
                //per ogni consumedItem abbiamo 1..1 nutritionProduct che si mapperà sul nutritionItem
                nutritionItem.product = ModelToFHIRUtils.toCodedValueModel(fConsumedItem.nutritionProduct.concept);
                nutritionItem.type = ModelToFHIRUtils.toCodedValueModel(fConsumedItem.type);
                nutritionItem.unit = new CodedValue(fConsumedItem.amount.system, fConsumedItem.amount.code, fConsumedItem.amount.unit);
                nutritionItem.quantity = fConsumedItem.amount.value;
                model.items.push(nutritionItem);
            }
        });
        return model;
    }
    fromDataModel(model) {
        const fhir = new NutritionIntake();
        fhir.id = !!model.id ? model.id + '' : undefined;
        fhir.subject = ModelToFHIRUtils.getReference(model.patient);
        fhir.status = 'completed';
        fhir.occurrence = model.date ?? new Date();
        fhir.consumedItem = [];
        model.items.forEach((item) => {
            const component = new NutritionIntake.NutritionIntakeConsumedItemComponent();
            component.nutritionProduct = new CodeableReference();
            component.nutritionProduct.concept = ModelToFHIRUtils.fromCodedValueModel(item.product);
            component.type = ModelToFHIRUtils.fromCodedValueModel(item.type);
            component.amount = new Quantity();
            component.amount.value = item.quantity;
            component.amount.system = item.unit.system;
            component.amount.code = item.unit.code;
            component.amount.unit = item.unit.originalDisplay;
            fhir.consumedItem.push(component);
        });
        return fhir;
    }
}

class FhirConverterService {
    constructor() {
        this.personConverter = new PersonFhirConverter(this);
        this.measureConverter = new MeasureFhirConverter(this);
        this.procedureConverter = new ProcedureFhirConverter(this);
        this.goalConverter = new GoalFhirConverter(this);
        this.planConverter = new PlanFhirConverter(this);
        this.messageConverter = new MessageFhirConverter(this);
        this.clinicalImpressionConverter = new ClinicalImpressionFhirConverter(this);
        this.clinicalNoteConverter = new ClinicalNoteFhirConverter(this);
        this.conditionConverter = new ConditionFhirConverter(this);
        this.caregiverConverter = new CareGiverFhirConverter(this);
        this.careTeamConverter = new CareTeamFhirConverter(this);
        this.consentConverter = new PatientConsentFhirConverter(this);
        this.organizationConverter = new OrganizationFhirConverter(this);
        this.questionnaireConverter = new QuestionnaireFhirConverter(this);
        this.questionnaireResponseConverter = new QuestionnaireResponseFhirConverter(this);
        this.episodeConverter = new EpisodeFhirConverter(this);
        this.encounterConverter = new EncounterFhirConverter(this);
        this.appointmentConverter = new AppointmentFhirConverter(this);
        this.vcfMetadataConverter = new VcfMetadataFhirConverter(this);
        this.planDefinitionConverter = new PlanDefinitionFhirConverter(this);
        this.prescriptionConverter = new PrescriptionFhirConverter(this);
        this.riskConverter = new RiskFhirConverter(this);
        this.trialSubjectConverter = new TrialSubjectFhirConverter(this);
        this.nutritionConverter = new NutritionFhirConverter(this);
    }
    get measure() {
        return this.measureConverter;
    }
    get person() {
        return this.personConverter;
    }
    get procedure() {
        return this.procedureConverter;
    }
    get goal() {
        return this.goalConverter;
    }
    get plan() {
        return this.planConverter;
    }
    get planDefinition() {
        return this.planDefinitionConverter;
    }
    get message() {
        return this.messageConverter;
    }
    get clinicalImpression() {
        return this.clinicalImpressionConverter;
    }
    get clinicalNote() {
        return this.clinicalNoteConverter;
    }
    get careGiver() {
        return this.caregiverConverter;
    }
    get careTeam() {
        return this.careTeamConverter;
    }
    get condition() {
        return this.conditionConverter;
    }
    get consent() {
        return this.consentConverter;
    }
    get organization() {
        return this.organizationConverter;
    }
    get questionnaire() {
        return this.questionnaireConverter;
    }
    get questionnaireResponse() {
        return this.questionnaireResponseConverter;
    }
    get episode() {
        return this.episodeConverter;
    }
    get encounter() {
        return this.encounterConverter;
    }
    get appointment() {
        return this.appointmentConverter;
    }
    get vcfMetadata() {
        return this.vcfMetadataConverter;
    }
    get prescription() {
        return this.prescriptionConverter;
    }
    get risk() {
        return this.riskConverter;
    }
    get trialSubject() {
        return this.trialSubjectConverter;
    }
    get nutrition() {
        return this.nutritionConverter;
    }
}

// tslint:disable: max-line-length no-inferrable-types no-redundant-jsdoc
class FhirConverter {
    constructor() {
        this.service = new FhirConverterService();
    }
    toDataModel(resource, context) {
        if (!resource) {
            return undefined;
        }
        if (resource instanceof Reference) {
            return ModelToFHIRUtils.stubFromRef(resource);
        }
        else if (resource instanceof Observation) {
            return this.service.measure.toDataModel(resource, context);
        }
        else if (resource instanceof Goal$1) {
            return this.service.goal.toDataModel(resource, context);
        }
        else if (resource instanceof CarePlan) {
            return this.service.plan.toDataModel(resource, context);
        }
        else if (resource instanceof Patient || resource instanceof Practitioner) {
            return this.service.person.toDataModel(resource, context);
        }
        else if (resource instanceof Procedure$1) {
            return this.service.procedure.toDataModel(resource, context);
        }
        else if (resource instanceof Communication) {
            return this.service.message.toDataModel(resource, context);
        }
        else if (resource instanceof ClinicalImpression) {
            return this.service.clinicalImpression.toDataModel(resource, context);
        }
        else if (resource instanceof DocumentReference) {
            return this.service.clinicalNote.toDataModel(resource, context);
        }
        else if (resource instanceof RelatedPerson) {
            return this.service.careGiver.toDataModel(resource, context);
        }
        else if (resource instanceof CareTeam$1) {
            return this.service.careTeam.toDataModel(resource, context);
        }
        else if (resource instanceof Organization$1) {
            return this.service.organization.toDataModel(resource, context);
        }
        else if (resource instanceof Questionnaire) {
            return this.service.questionnaire.toDataModel(resource, context);
        }
        else if (resource instanceof QuestionnaireResponse) {
            return this.service.questionnaireResponse.toDataModel(resource, context);
        }
        else if (resource instanceof EpisodeOfCare) {
            return this.service.episode.toDataModel(resource, context);
        }
        else if (resource instanceof Encounter$1) {
            return this.service.encounter.toDataModel(resource, context);
        }
        else if (resource instanceof Appointment$1) {
            return this.service.appointment.toDataModel(resource, context);
        }
        else if (resource instanceof Condition) {
            return this.service.condition.toDataModel(resource, context);
        }
        else if (resource instanceof GenomicStudy) {
            return this.service.vcfMetadata.toDataModel(resource, context);
        }
        else if (resource instanceof ServiceRequest) {
            return this.service.prescription.toDataModel(resource, context);
        }
        else if (resource instanceof PlanDefinition$1) {
            return this.service.planDefinition.toDataModel(resource, context);
        }
        else if (resource instanceof RiskAssessment) {
            return this.service.risk.toDataModel(resource, context);
        }
        else if (resource instanceof ResearchSubject) {
            return this.service.trialSubject.toDataModel(resource, context);
        }
        else if (resource instanceof NutritionIntake) {
            return this.service.nutrition.toDataModel(resource, context);
        }
        else {
            throw new TypeError(`Unsupported domain resource type ${resource.constructor.name}. Error converting to datamodel from FHIR.`);
        }
    }
    fromDataModel(model) {
        if (!model) {
            return undefined;
        }
        if (model instanceof Measure) {
            return this.service.measure.fromDataModel(model);
        }
        else if (model instanceof Goal) {
            return this.service.goal.fromDataModel(model);
        }
        else if (model instanceof Person$1) {
            return this.service.person.fromDataModel(model);
        }
        else if (model instanceof Plan) {
            return this.service.plan.fromDataModel(model);
        }
        else if (model instanceof Procedure) {
            return this.service.procedure.fromDataModel(model);
        }
        else if (model instanceof Message) {
            return this.service.message.fromDataModel(model);
        }
        else if (model instanceof ObservePatient) {
            return this.service.clinicalImpression.fromDataModel(model);
        }
        else if (model instanceof ClinicalNote) {
            return this.service.clinicalNote.fromDataModel(model);
        }
        else if (model instanceof CareGiver) {
            return this.service.careGiver.fromDataModel(model);
        }
        else if (model instanceof CareTeam) {
            return this.service.careTeam.fromDataModel(model);
        }
        else if (model instanceof Organization) {
            return this.service.organization.fromDataModel(model);
        }
        else if (model instanceof Questionnaire$1) {
            return this.service.questionnaire.fromDataModel(model);
        }
        else if (model instanceof QuestionnaireResponse$1) {
            return this.service.questionnaireResponse.fromDataModel(model);
        }
        else if (model instanceof Episode) {
            return this.service.episode.fromDataModel(model);
        }
        else if (model instanceof Encounter) {
            return this.service.encounter.fromDataModel(model);
        }
        else if (model instanceof Appointment) {
            return this.service.appointment.fromDataModel(model);
        }
        else if (model instanceof Condition$1) {
            return this.service.condition.fromDataModel(model);
        }
        else if (model instanceof Prescription) {
            return this.service.prescription.fromDataModel(model);
        }
        else if (model instanceof PlanDefinition) {
            return this.service.planDefinition.fromDataModel(model);
        }
        else if (model instanceof Risk) {
            return this.service.risk.fromDataModel(model);
        }
        else if (model instanceof TrialSubject) {
            return this.service.trialSubject.fromDataModel(model);
        }
        else if (model instanceof Nutrition) {
            return this.service.nutrition.fromDataModel(model);
        }
        else {
            throw new TypeError(`Unsupported model type '${model.resourceType}'. Error converting from datamodel to FHIR.`);
        }
    }
    get converterService() {
        return this.service;
    }
    getFHIRReference(model) {
        return ModelToFHIRUtils.getReference(model);
    }
}

/*
 * Public API Surface of converter
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AbstractFhirConverter, AppointmentFhirConverter, ClinicalImpressionFhirConverter, ClinicalNoteFhirConverter, Dictionary, EncounterFhirConverter, FhirCodesMapperUtils, FhirConverter, FhirConverterService, FhirHeartUtils, FhirKinship, FhirUtils, GoalFhirConverter, HeartExtension, HeartValueSet, KinshipConverterUtils, MeasureFhirConverter, MessageFhirConverter, ModelToFHIRUtils, PersonFhirConverter, PlanDefinitionFhirConverter, PlanFhirConverter, PrescriptionFhirConverter, ProcedureFhirConverter, RiskFhirConverter, TargetUtils, TrialSubjectFhirConverter, VcfMetadataFhirConverter };
//# sourceMappingURL=eng-it4h-heart-ui-converter.mjs.map
