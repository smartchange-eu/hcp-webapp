import * as i0 from '@angular/core';
import { Injectable, Pipe, NgModule, Component, Inject, EventEmitter, Directive, Input, Output, HostListener } from '@angular/core';
import * as i3 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i1$1 from '@angular/material/dialog';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { Locale } from '@eng-it4h/heart-ui-model';
import * as i1 from '@ngx-translate/core';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { enGB, it as it$2 } from 'date-fns/locale';
import * as i4 from '@angular/forms';
import { FormsModule, FormGroup, FormControl, ReactiveFormsModule } from '@angular/forms';
import * as i3$1 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i1$2 from '@angular/material/core';
import { MatOptionModule, MAT_DATE_FORMATS, DateAdapter, MAT_DATE_LOCALE } from '@angular/material/core';
import * as i5 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import * as i3$2 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i9 from '@angular/material/select';
import { MatSelectModule } from '@angular/material/select';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient } from '@angular/common/http';
import * as i1$3 from '@angular/material/snack-bar';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { Subject, of } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import * as i1$4 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i4$1 from 'ngx-markdown';
import { MarkdownModule } from 'ngx-markdown';
import * as i4$2 from '@angular/material/tabs';
import { MatTabsModule } from '@angular/material/tabs';
import * as i2 from '@angular/material/datepicker';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { DateFnsAdapter } from '@angular/material-date-fns-adapter';

const en$1 = {};

const it$1 = {
    "utils.confirmation-dialog.reason.label": "Ragione del rifiuto",
    "utils.confirmation-dialog.reason.dropdown.label": "Seleziona una motivazione al rifiuto",
    "utils.confirmation-dialog.reason.notes.label": "Note aggiuntive",
};

const en = {
    "button.store.label": "Save",
    "required.error": "Mandatory field",
    "email.error": "The format of the e-mail address is not valid",
    "max.error": "Please check the number provided, it seems exceeding the maximum",
    "min.error": "Please check the number provided, it seems too low",
    "username.label": "Username",
    "pwd.label": "Password",
};

const it = {
    "button.store.label": "Salva",
    "required.error": "Campo obbligatorio",
    "email.error": "Formato dell'indirizzo e-mail non valido",
    "max.error": "Si prega di controllare il numero inserito, sembra e massimo consentito",
    "min.error": "Si prega di controllare il numero inserito, sembra a del minimo consentito",
    "username.label": "Nome utente",
    "pwd.label": "Password",
};

class SubTranslateConfig {
    constructor() {
        this.defaultLanguage = Locale.EN;
        this.overwriteInitial = true;
        this.useTranslateServiceFirst = false;
        this.locales = new Map();
    }
}
class SubTranslateService {
    constructor(_translate, _config) {
        this._translate = _translate;
        this._config = _config;
        this._store = new Map();
        //initialize
        this._allowed = Array.from(this._config.locales.keys());
        this._allowed.forEach((key) => {
            this._store.set(key, this._config.locales.get(key).subtranslateDicionary);
        });
    }
    setLanguages(dictionary) {
        if (dictionary) {
            const keys = dictionary.keys();
            for (const key of keys) {
                if (this.isAllowed(key)) {
                    const value = dictionary.get(key);
                    const merged = this.mergeLanguage(key, value);
                    this._store.set(key, merged);
                }
            }
        }
    }
    getFnsLocale(key) {
        return this._config.locales?.get(Locale.convertFromString(key)).fnsAdapterLocale;
    }
    getLocaleCode(key) {
        return this._config.locales?.get(Locale.convertFromString(key)).nativeAdapterLocale;
    }
    mergeLanguage(key, value) {
        const current = this._store.get(key);
        if (this._config.overwriteInitial) {
            const newD = { ...current, ...value };
            return newD;
        }
        else {
            const newD = { ...value, ...current };
            return newD;
        }
    }
    getTranslation(key, language) {
        if (this._config.useTranslateServiceFirst && this.hasTranslation(key, language)) {
            return this._translate.instant(key);
        }
        let toRet;
        if (this.isAllowed(language)) {
            toRet = this._store.get(language)?.[key];
        }
        else {
            toRet = this._store.get(this.defaultLanguage)?.[key];
        }
        return toRet ?? `${key}@${language}`;
    }
    isAllowed(language) {
        return language && this._allowed.includes(Locale.convertFromString(language));
    }
    get defaultLanguage() {
        return this._config.defaultLanguage;
    }
    hasTranslation(translationKey, language) {
        //FIXME: currently supports only flat keys
        const translation = this._translate.translations[language];
        return translation && translationKey in translation;
    }
}
SubTranslateService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: SubTranslateService, deps: [{ token: i1.TranslateService }, { token: SubTranslateConfig }], target: i0.ɵɵFactoryTarget.Injectable });
SubTranslateService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: SubTranslateService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: SubTranslateService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: function () { return [{ type: i1.TranslateService }, { type: SubTranslateConfig }]; } });

/*
 * Transalte the value
 * Takes an argument that defines the language.
 * Usage:
 *   value | subtranslate:lang
 * Example:
 *   {{ 'logout.label.to-translate' | subtranslate:'en' }}
 *   formats to: Logout
*/
class SubTranslatePipe {
    constructor(_subTranslateService) {
        this._subTranslateService = _subTranslateService;
    }
    transform(value, lang) {
        return this._subTranslateService.getTranslation(value, lang);
    }
}
SubTranslatePipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: SubTranslatePipe, deps: [{ token: SubTranslateService }], target: i0.ɵɵFactoryTarget.Pipe });
SubTranslatePipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: SubTranslatePipe, name: "subtranslate" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: SubTranslatePipe, decorators: [{
            type: Pipe,
            args: [{ name: 'subtranslate' }]
        }], ctorParameters: function () { return [{ type: SubTranslateService }]; } });

const DEFAULT_CONFIG = {
    defaultLanguage: Locale.EN,
    overwriteInitial: true,
    useTranslateServiceFirst: false,
    locales: new Map([
        [Locale.EN, { display: 'English', fnsAdapterLocale: enGB, nativeAdapterLocale: 'en-GB', locale: Locale.EN, subtranslateDicionary: en }],
        [Locale.IT, { display: 'Italian - italiano', fnsAdapterLocale: it$2, nativeAdapterLocale: 'it', locale: Locale.IT, subtranslateDicionary: it }],
        // [Locale.RO, { display: 'Romanian - română', fnsAdapterLocale: fnsRo, nativeAdapterLocale: 'ro', locale: Locale.RO, subtranslateDicionary: ro }],
    ]),
};
class SubTranslateModule {
    static forRoot(config) {
        return {
            ngModule: SubTranslateModule,
            providers: [{ provide: SubTranslateConfig, useValue: config ?? DEFAULT_CONFIG }],
        };
    }
}
SubTranslateModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: SubTranslateModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
SubTranslateModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: SubTranslateModule, declarations: [SubTranslatePipe], imports: [CommonModule, i1.TranslateModule], exports: [SubTranslatePipe] });
SubTranslateModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: SubTranslateModule, imports: [CommonModule, TranslateModule.forChild()] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: SubTranslateModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [SubTranslatePipe],
                    imports: [CommonModule, TranslateModule.forChild()],
                    exports: [SubTranslatePipe],
                }]
        }] });

class ConfirmationDialogComponent {
    constructor(_subTranslateService, dialogRef, data) {
        this._subTranslateService = _subTranslateService;
        this.dialogRef = dialogRef;
        this.data = data;
        this.title = data.title;
        this.msg = data.msg;
        this.closeLabel = data.closeLabel ?? undefined;
        this.okLabel = data.okLabel ?? undefined;
        this.reasons = data.reasons;
        this.lang = data.lang ?? 'en';
        this.showOverriddenNotes = data.showOverriddenNotes ?? false;
        this.createDictionary();
    }
    // approccio per unificare il servizio di traduzione
    createDictionary() {
        const dictionary = new Map();
        dictionary.set('en', en$1);
        dictionary.set('it', it$1);
        this._subTranslateService.setLanguages(dictionary);
    }
    ngOnInit() { }
    save() {
        if (this.reasons || this.notes) {
            this.dialogRef.close({ selectedReason: this.selectedReason, notes: this.notes });
        }
        else {
            this.dialogRef.close(true);
        }
    }
    close() {
        this.dialogRef.close();
    }
}
ConfirmationDialogComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ConfirmationDialogComponent, deps: [{ token: SubTranslateService }, { token: i1$1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
ConfirmationDialogComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: ConfirmationDialogComponent, selector: "heart-confirmation-dialog", ngImport: i0, template: "<h2 mat-dialog-title>\n  {{ title | translate }}</h2>\n\n<!-- [formGroup]=\"form\" -->\n<mat-dialog-content>\n\n  <div class=\"d-flex flex-column flex-gap-2\">\n    <div class=\"mb-2\" *ngIf=\"msg\">\n      <span>{{ msg | translate}}</span>\n    </div>\n    <div *ngIf=\"reasons\" class=\"mt-1\">\n      <mat-form-field style=\"width: 100%;\" appearance=\"outline\">\n        <mat-label [ngClass]=\"{'required' : true}\">{{ 'utils.confirmation-dialog.reason.label' |\n          subtranslate:lang}}</mat-label>\n        <mat-select [(value)]=\"selectedReason\">\n          <mat-option disabled [value]=\"undefined\">\n            {{'utils.confirmation-dialog.reason.dropdown.label' | subtranslate:lang}}\n          </mat-option>\n          <mat-option *ngFor=\"let r of reasons\" [value]=\"r\">\n            {{r.display | translate}}\n          </mat-option>\n        </mat-select>\n      </mat-form-field>\n    </div>\n    <div *ngIf=\"showOverriddenNotes\">\n      <mat-form-field appearance=\"outline\">\n        <mat-label>{{'utils.confirmation-dialog.reason.notes.label' |\n          subtranslate:lang}}</mat-label>\n        <textarea matInput type=\"text\" [(ngModel)]=\"notes\"></textarea>\n      </mat-form-field>\n    </div>\n  </div>\n\n</mat-dialog-content>\n\n<mat-dialog-actions align=\"end\">\n  <button mat-raised-button *ngIf=\"closeLabel\" (click)=\"close()\">{{closeLabel | translate}}</button>\n  <button mat-raised-button color=\"primary\" *ngIf=\"okLabel\" (click)=\"save()\"\n    [disabled]=\"reasons && !selectedReason\">{{okLabel |\n    translate}}</button>\n</mat-dialog-actions>", styles: ["mat-form-field{width:100%!important;height:auto!important}.required:before{content:\"*\";font-weight:400;size:16px}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i4.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i4.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "component", type: i3$1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: i1$2.MatOption, selector: "mat-option", exportAs: ["matOption"] }, { kind: "directive", type: i5.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i3$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i3$2.MatLabel, selector: "mat-label" }, { kind: "component", type: i9.MatSelect, selector: "mat-select", inputs: ["disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator"], exportAs: ["matSelect"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }, { kind: "pipe", type: SubTranslatePipe, name: "subtranslate" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ConfirmationDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-confirmation-dialog', template: "<h2 mat-dialog-title>\n  {{ title | translate }}</h2>\n\n<!-- [formGroup]=\"form\" -->\n<mat-dialog-content>\n\n  <div class=\"d-flex flex-column flex-gap-2\">\n    <div class=\"mb-2\" *ngIf=\"msg\">\n      <span>{{ msg | translate}}</span>\n    </div>\n    <div *ngIf=\"reasons\" class=\"mt-1\">\n      <mat-form-field style=\"width: 100%;\" appearance=\"outline\">\n        <mat-label [ngClass]=\"{'required' : true}\">{{ 'utils.confirmation-dialog.reason.label' |\n          subtranslate:lang}}</mat-label>\n        <mat-select [(value)]=\"selectedReason\">\n          <mat-option disabled [value]=\"undefined\">\n            {{'utils.confirmation-dialog.reason.dropdown.label' | subtranslate:lang}}\n          </mat-option>\n          <mat-option *ngFor=\"let r of reasons\" [value]=\"r\">\n            {{r.display | translate}}\n          </mat-option>\n        </mat-select>\n      </mat-form-field>\n    </div>\n    <div *ngIf=\"showOverriddenNotes\">\n      <mat-form-field appearance=\"outline\">\n        <mat-label>{{'utils.confirmation-dialog.reason.notes.label' |\n          subtranslate:lang}}</mat-label>\n        <textarea matInput type=\"text\" [(ngModel)]=\"notes\"></textarea>\n      </mat-form-field>\n    </div>\n  </div>\n\n</mat-dialog-content>\n\n<mat-dialog-actions align=\"end\">\n  <button mat-raised-button *ngIf=\"closeLabel\" (click)=\"close()\">{{closeLabel | translate}}</button>\n  <button mat-raised-button color=\"primary\" *ngIf=\"okLabel\" (click)=\"save()\"\n    [disabled]=\"reasons && !selectedReason\">{{okLabel |\n    translate}}</button>\n</mat-dialog-actions>", styles: ["mat-form-field{width:100%!important;height:auto!important}.required:before{content:\"*\";font-weight:400;size:16px}\n"] }]
        }], ctorParameters: function () { return [{ type: SubTranslateService }, { type: i1$1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }]; } });

// AoT requires an exported function for factories
function HttpLoaderFactoryConfirmation(http) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class ConfirmationDialogModule {
}
ConfirmationDialogModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ConfirmationDialogModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
ConfirmationDialogModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: ConfirmationDialogModule, declarations: [ConfirmationDialogComponent], imports: [CommonModule,
        FormsModule,
        MatDialogModule,
        MatButtonModule,
        MatOptionModule,
        MatInputModule,
        MatSelectModule, i1.TranslateModule, SubTranslateModule], exports: [ConfirmationDialogComponent] });
ConfirmationDialogModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ConfirmationDialogModule, imports: [CommonModule,
        FormsModule,
        MatDialogModule,
        MatButtonModule,
        MatOptionModule,
        MatInputModule,
        MatSelectModule,
        TranslateModule.forChild({
            defaultLanguage: 'en',
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactoryConfirmation,
                deps: [HttpClient],
            },
            isolate: false
        }),
        SubTranslateModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ConfirmationDialogModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        ConfirmationDialogComponent
                    ],
                    imports: [
                        CommonModule,
                        FormsModule,
                        MatDialogModule,
                        MatButtonModule,
                        MatOptionModule,
                        MatInputModule,
                        MatSelectModule,
                        TranslateModule.forChild({
                            defaultLanguage: 'en',
                            loader: {
                                provide: TranslateLoader,
                                useFactory: HttpLoaderFactoryConfirmation,
                                deps: [HttpClient],
                            },
                            isolate: false
                        }),
                        SubTranslateModule
                    ],
                    exports: [ConfirmationDialogComponent],
                }]
        }] });

class SnackBarService {
    //create an instance of MatSnackBar
    constructor(snackBar, ts) {
        this.snackBar = snackBar;
        this.ts = ts;
    }
    /**
     *
     * @param message the message
     * @param action
     * @param duration
     * @param hPos
     * @param vPos
     */
    openSnackBar(message, action = 'OK', duration = 4000, panelClass, hPos = 'center', vPos = 'bottom') {
        this.ts.get(message).subscribe((res) => {
            this.snackBar.open(res, action, {
                duration: duration,
                horizontalPosition: hPos,
                verticalPosition: vPos,
                panelClass: panelClass,
            });
        });
    }
}
SnackBarService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: SnackBarService, deps: [{ token: i1$3.MatSnackBar }, { token: i1.TranslateService }], target: i0.ɵɵFactoryTarget.Injectable });
SnackBarService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: SnackBarService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: SnackBarService, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: i1$3.MatSnackBar }, { type: i1.TranslateService }]; } });

// AoT requires an exported function for factories
function HttpLoaderFactorySnackbar(http) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class SnackbarModule {
}
SnackbarModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: SnackbarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
SnackbarModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: SnackbarModule, imports: [CommonModule,
        MatSnackBarModule, i1.TranslateModule] });
SnackbarModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: SnackbarModule, providers: [SnackBarService], imports: [CommonModule,
        MatSnackBarModule,
        TranslateModule.forChild({
            defaultLanguage: 'en',
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactorySnackbar,
                deps: [HttpClient],
            },
            isolate: false,
        })] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: SnackbarModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [
                        CommonModule,
                        MatSnackBarModule,
                        TranslateModule.forChild({
                            defaultLanguage: 'en',
                            loader: {
                                provide: TranslateLoader,
                                useFactory: HttpLoaderFactorySnackbar,
                                deps: [HttpClient],
                            },
                            isolate: false,
                        }),
                    ],
                    exports: [],
                    providers: [SnackBarService],
                }]
        }] });

class DebouncedButtonDirective {
    constructor() {
        this.debounceClickTime = 500; //The standard range of milliseconds in which the clicks will be managed as one;
        this.debounceClick = new EventEmitter(); // the event to be catched by the caller
        this.clicks = new Subject();
    }
    ngOnInit() {
        this.subscription = this.clicks
            .pipe(debounceTime(this.debounceClickTime))
            .subscribe((e) => this.debounceClick.emit(e));
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    clickEvent(event) {
        event.preventDefault();
        event.stopPropagation();
        this.clicks.next(event);
    }
}
DebouncedButtonDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DebouncedButtonDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
DebouncedButtonDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "15.2.10", type: DebouncedButtonDirective, selector: "[heartDebouncedButton]", inputs: { debounceClickTime: "debounceClickTime" }, outputs: { debounceClick: "debounceClick" }, host: { listeners: { "click": "clickEvent($event)" } }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: DebouncedButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[heartDebouncedButton]',
                }]
        }], ctorParameters: function () { return []; }, propDecorators: { debounceClickTime: [{
                type: Input
            }], debounceClick: [{
                type: Output
            }], clickEvent: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

class PreventDoubleClickModule {
}
PreventDoubleClickModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: PreventDoubleClickModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
PreventDoubleClickModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: PreventDoubleClickModule, declarations: [DebouncedButtonDirective], imports: [CommonModule], exports: [DebouncedButtonDirective] });
PreventDoubleClickModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: PreventDoubleClickModule, imports: [CommonModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: PreventDoubleClickModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DebouncedButtonDirective
                    ],
                    imports: [
                        CommonModule,
                    ],
                    exports: [DebouncedButtonDirective],
                }]
        }] });

class MessageBoxComponent {
    constructor() {
        this.type = 'info';
    }
    ngOnInit() {
    }
}
MessageBoxComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: MessageBoxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
MessageBoxComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: MessageBoxComponent, selector: "heart-message-box", inputs: { msg: "msg", type: "type", icon: "icon" }, ngImport: i0, template: "<div class=\"box-{{type}}\">\n<!-- <div [className]=\"'box-' + type\"> -->\n  <mat-icon>{{icon}}</mat-icon>\n  <span>\n    {{msg | translate}}\n  </span>\n</div>", styles: [".mat-icon{vertical-align:middle}.box,.box-warning,.box-accent,.box-info{width:100%;padding:8px;text-align:center;border-radius:5px;background-color:var(--light-background, whitesmoke);margin:0 4px}.box-info{border-style:solid;border-width:1px;font-weight:300;border-color:var(--primary-color, royalblue);color:var(--primary-color, royalblue)}.box-accent{border-style:dashed;border-width:2px;font-weight:600;border-color:var(--accent-color, cyan);color:var(--accent-color, cyan)}.box-warning{border-style:solid;border-width:2px;font-weight:600;border-color:var(--warning-color, lightcoral);color:var(--warning-color, lightcoral)}\n"], dependencies: [{ kind: "component", type: i1$4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: MessageBoxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-message-box', template: "<div class=\"box-{{type}}\">\n<!-- <div [className]=\"'box-' + type\"> -->\n  <mat-icon>{{icon}}</mat-icon>\n  <span>\n    {{msg | translate}}\n  </span>\n</div>", styles: [".mat-icon{vertical-align:middle}.box,.box-warning,.box-accent,.box-info{width:100%;padding:8px;text-align:center;border-radius:5px;background-color:var(--light-background, whitesmoke);margin:0 4px}.box-info{border-style:solid;border-width:1px;font-weight:300;border-color:var(--primary-color, royalblue);color:var(--primary-color, royalblue)}.box-accent{border-style:dashed;border-width:2px;font-weight:600;border-color:var(--accent-color, cyan);color:var(--accent-color, cyan)}.box-warning{border-style:solid;border-width:2px;font-weight:600;border-color:var(--warning-color, lightcoral);color:var(--warning-color, lightcoral)}\n"] }]
        }], ctorParameters: function () { return []; }, propDecorators: { msg: [{
                type: Input
            }], type: [{
                type: Input
            }], icon: [{
                type: Input
            }] } });

// AoT requires an exported function for factories
function HttpLoaderFactoryMessageBox(http) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class MessageBoxModule {
}
MessageBoxModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: MessageBoxModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
MessageBoxModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: MessageBoxModule, declarations: [MessageBoxComponent], imports: [CommonModule, i1.TranslateModule, MatIconModule], exports: [MessageBoxComponent] });
MessageBoxModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: MessageBoxModule, imports: [CommonModule,
        TranslateModule.forChild({
            defaultLanguage: 'en',
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactoryMessageBox,
                deps: [HttpClient],
            },
            isolate: false,
        }),
        MatIconModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: MessageBoxModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        MessageBoxComponent
                    ],
                    imports: [
                        CommonModule,
                        TranslateModule.forChild({
                            defaultLanguage: 'en',
                            loader: {
                                provide: TranslateLoader,
                                useFactory: HttpLoaderFactoryMessageBox,
                                deps: [HttpClient],
                            },
                            isolate: false,
                        }),
                        MatIconModule
                    ],
                    exports: [
                        MessageBoxComponent
                    ]
                }]
        }] });

class InformationMdDialogComponent {
    constructor(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.title = data.title;
        this.msg = data.msg;
        this.closeLabel = data.closeLabel;
        this.okLabel = data.okLabel;
    }
    ngOnInit() { }
    close() {
        this.dialogRef.close();
    }
}
InformationMdDialogComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: InformationMdDialogComponent, deps: [{ token: i1$1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
InformationMdDialogComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: InformationMdDialogComponent, selector: "heart-information-md-dialog", ngImport: i0, template: "<h2 mat-dialog-title>{{ title | translate }}</h2>\n\n<!-- [formGroup]=\"form\" -->\n<mat-dialog-content>\n\n  <div class=\"d-flex flex-column flex-gap-2 markdown-offset-fix markdown-body\">\n    <div class=\"mb-2\" *ngIf=\"msg\" [innerHTML]=\"msg | markdown\">\n    </div>\n  </div>\n\n</mat-dialog-content>\n\n<mat-dialog-actions align=\"end\">\n  <button mat-flat-button (click)=\"close()\">{{okLabel | translate}}</button>\n</mat-dialog-actions>", styles: [".markdown-body{font-family:unset!important}.markdown-offset-fix{margin-left:1em!important;padding-right:1em!important}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "component", type: i3$1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "pipe", type: i4$1.MarkdownPipe, name: "markdown" }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: InformationMdDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-information-md-dialog', template: "<h2 mat-dialog-title>{{ title | translate }}</h2>\n\n<!-- [formGroup]=\"form\" -->\n<mat-dialog-content>\n\n  <div class=\"d-flex flex-column flex-gap-2 markdown-offset-fix markdown-body\">\n    <div class=\"mb-2\" *ngIf=\"msg\" [innerHTML]=\"msg | markdown\">\n    </div>\n  </div>\n\n</mat-dialog-content>\n\n<mat-dialog-actions align=\"end\">\n  <button mat-flat-button (click)=\"close()\">{{okLabel | translate}}</button>\n</mat-dialog-actions>", styles: [".markdown-body{font-family:unset!important}.markdown-offset-fix{margin-left:1em!important;padding-right:1em!important}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }]; } });

// AoT requires an exported function for factories
function HttpLoaderFactoryMd(http) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class InformationMdDialogModule {
}
InformationMdDialogModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: InformationMdDialogModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
InformationMdDialogModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: InformationMdDialogModule, declarations: [InformationMdDialogComponent], imports: [CommonModule,
        FormsModule,
        MatDialogModule,
        MatButtonModule,
        MatOptionModule,
        MatInputModule,
        MatSelectModule,
        MarkdownModule, i1.TranslateModule] });
InformationMdDialogModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: InformationMdDialogModule, imports: [CommonModule,
        FormsModule,
        MatDialogModule,
        MatButtonModule,
        MatOptionModule,
        MatInputModule,
        MatSelectModule,
        MarkdownModule,
        TranslateModule.forChild({
            defaultLanguage: 'en',
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactoryMd,
                deps: [HttpClient],
            },
            isolate: false
        })] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: InformationMdDialogModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        InformationMdDialogComponent
                    ],
                    imports: [
                        CommonModule,
                        FormsModule,
                        MatDialogModule,
                        MatButtonModule,
                        MatOptionModule,
                        MatInputModule,
                        MatSelectModule,
                        MarkdownModule,
                        TranslateModule.forChild({
                            defaultLanguage: 'en',
                            loader: {
                                provide: TranslateLoader,
                                useFactory: HttpLoaderFactoryMd,
                                deps: [HttpClient],
                            },
                            isolate: false
                        })
                    ]
                }]
        }] });

class InformationMdTabDialogComponent {
    constructor(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.keys = [];
        this.titlesContents = data.titlesContents;
        this.okLabel = data.okLabel;
    }
    ngOnInit() {
        this.keys = Array.from(this.titlesContents.keys());
    }
    close() {
        this.dialogRef.close();
    }
}
InformationMdTabDialogComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: InformationMdTabDialogComponent, deps: [{ token: i1$1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
InformationMdTabDialogComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: InformationMdTabDialogComponent, selector: "heart-information-md-tab-dialog", ngImport: i0, template: "\n<mat-dialog-content>\n\n  <mat-tab-group backgroundColor=\"primary\">\n    <ng-container *ngFor=\"let key of keys\">\n      <mat-tab label=\"{{key | translate}}\"> \n        <div class=\"d-flex flex-column flex-gap-2 markdown-offset-fix markdown-body\">\n          <div class=\"mb-2\" [innerHTML]=\" titlesContents.get(key) | markdown\">\n          </div>\n        </div> \n       \n      </mat-tab>\n    </ng-container>\n  </mat-tab-group>\n\n  <!-- <div class=\"d-flex flex-column flex-gap-2 markdown-offset-fix markdown-body\">\n    <div class=\"mb-2\" *ngIf=\"msg\" [innerHTML]=\"msg | markdown\">\n    </div>\n  </div> -->\n\n</mat-dialog-content>\n\n<mat-dialog-actions align=\"end\">\n  <button mat-flat-button (click)=\"close()\">{{okLabel | translate}}</button>\n</mat-dialog-actions>", styles: [".markdown-body{font-family:unset!important}.markdown-offset-fix{margin-left:1em!important;padding-right:1em!important}\n"], dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "component", type: i3$1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: i4$2.MatTab, selector: "mat-tab", inputs: ["disabled"], exportAs: ["matTab"] }, { kind: "component", type: i4$2.MatTabGroup, selector: "mat-tab-group", inputs: ["color", "disableRipple", "fitInkBarToContent", "mat-stretch-tabs"], exportAs: ["matTabGroup"] }, { kind: "pipe", type: i4$1.MarkdownPipe, name: "markdown" }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: InformationMdTabDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-information-md-tab-dialog', template: "\n<mat-dialog-content>\n\n  <mat-tab-group backgroundColor=\"primary\">\n    <ng-container *ngFor=\"let key of keys\">\n      <mat-tab label=\"{{key | translate}}\"> \n        <div class=\"d-flex flex-column flex-gap-2 markdown-offset-fix markdown-body\">\n          <div class=\"mb-2\" [innerHTML]=\" titlesContents.get(key) | markdown\">\n          </div>\n        </div> \n       \n      </mat-tab>\n    </ng-container>\n  </mat-tab-group>\n\n  <!-- <div class=\"d-flex flex-column flex-gap-2 markdown-offset-fix markdown-body\">\n    <div class=\"mb-2\" *ngIf=\"msg\" [innerHTML]=\"msg | markdown\">\n    </div>\n  </div> -->\n\n</mat-dialog-content>\n\n<mat-dialog-actions align=\"end\">\n  <button mat-flat-button (click)=\"close()\">{{okLabel | translate}}</button>\n</mat-dialog-actions>", styles: [".markdown-body{font-family:unset!important}.markdown-offset-fix{margin-left:1em!important;padding-right:1em!important}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }]; } });

// AoT requires an exported function for factories
function HttpLoaderFactoryMdTab(http) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class InformationMdTabDialogModule {
}
InformationMdTabDialogModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: InformationMdTabDialogModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
InformationMdTabDialogModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: InformationMdTabDialogModule, declarations: [InformationMdTabDialogComponent], imports: [CommonModule,
        FormsModule,
        MatDialogModule,
        MatButtonModule,
        MatOptionModule,
        MatInputModule,
        MatSelectModule,
        MarkdownModule,
        MatTabsModule, i1.TranslateModule] });
InformationMdTabDialogModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: InformationMdTabDialogModule, imports: [CommonModule,
        FormsModule,
        MatDialogModule,
        MatButtonModule,
        MatOptionModule,
        MatInputModule,
        MatSelectModule,
        MarkdownModule,
        MatTabsModule,
        TranslateModule.forChild({
            defaultLanguage: 'en',
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactoryMdTab,
                deps: [HttpClient],
            },
            isolate: false
        })] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: InformationMdTabDialogModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        InformationMdTabDialogComponent
                    ],
                    imports: [
                        CommonModule,
                        FormsModule,
                        MatDialogModule,
                        MatButtonModule,
                        MatOptionModule,
                        MatInputModule,
                        MatSelectModule,
                        MarkdownModule,
                        MatTabsModule,
                        TranslateModule.forChild({
                            defaultLanguage: 'en',
                            loader: {
                                provide: TranslateLoader,
                                useFactory: HttpLoaderFactoryMdTab,
                                deps: [HttpClient],
                            },
                            isolate: false
                        }),
                    ]
                }]
        }] });

class OrderTranslatePipe {
    constructor(translate) {
        this.translate = translate;
    }
    transform(array) {
        let sortedArray = array.slice().sort((a, b) => {
            if (this.translate.instant(a.uniqueLabelKey) < this.translate.instant(b.uniqueLabelKey))
                return -1;
            else if (this.translate.instant(a.uniqueLabelKey) > this.translate.instant(b.uniqueLabelKey))
                return 1;
            else
                return 0;
        });
        return sortedArray;
    }
}
OrderTranslatePipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: OrderTranslatePipe, deps: [{ token: i1.TranslateService }], target: i0.ɵɵFactoryTarget.Pipe });
OrderTranslatePipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: OrderTranslatePipe, name: "orderTranslate" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: OrderTranslatePipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'orderTranslate'
                }]
        }], ctorParameters: function () { return [{ type: i1.TranslateService }]; } });

class UsefulPipesModule {
}
UsefulPipesModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: UsefulPipesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
UsefulPipesModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: UsefulPipesModule, declarations: [OrderTranslatePipe], imports: [CommonModule], exports: [OrderTranslatePipe] });
UsefulPipesModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: UsefulPipesModule, imports: [CommonModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: UsefulPipesModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        OrderTranslatePipe
                    ],
                    imports: [
                        CommonModule
                    ],
                    exports: [OrderTranslatePipe]
                }]
        }] });

class PasswordGeneratorUtils {
    static generateRandomPwd(pwdValidationPattern) {
        let toRet;
        const regex = new RegExp(pwdValidationPattern);
        // console.log(regex)
        let validChars = this.getValidChars(pwdValidationPattern);
        let min = 0;
        let max = validChars.length - 1;
        let tot = this.extractLength(pwdValidationPattern)[0] ?? 8;
        while (true) {
            toRet = '';
            for (let n = 0; n < tot; n++) {
                const k = Math.floor(Math.random() * (max - min + 1) + min);
                toRet += validChars[k];
                // console.log(`${k} ==> ${validChars[k]}`)
            }
            // console.log(toRet)
            if (regex.exec(toRet)?.length > 0) {
                return toRet;
            }
        }
    }
    static generatePasswordFromRegexAdvanced(regexStr) {
        // Extract positive lookaheads (?=.*[...])
        const lookaheadPattern = /\(\?=.*?\[([^\]]+)\]\)/g;
        const lookaheadMatches = [...regexStr.matchAll(lookaheadPattern)];
        const requiredSets = lookaheadMatches.map((match) => match[1]);
        // Extract length constraints {min,max}
        const lengthMatch = regexStr.match(/\{(\d+),(\d+)\}/);
        const minLength = lengthMatch ? parseInt(lengthMatch[1], 10) : 8;
        const maxLength = lengthMatch ? parseInt(lengthMatch[2], 10) : 20;
        const totalLength = Math.floor(Math.random() * (maxLength - minLength + 1)) + minLength;
        // Start with one char from each required set
        const passwordChars = requiredSets.map((set) => set[Math.floor(Math.random() * set.length)]);
        // Extract optional character classes [abc]? and treat them probabilistically
        const optionalPattern = /\[([^\]]+)\]\?/g;
        const optionalMatches = [...regexStr.matchAll(optionalPattern)];
        const optionalChars = optionalMatches
            .map((match) => {
            return Math.random() < 0.5 ? match[1][Math.floor(Math.random() * match[1].length)] : '';
        })
            .filter(Boolean);
        passwordChars.push(...optionalChars);
        // Combine all required sets for remaining characters
        const allChars = requiredSets.join('') + optionalMatches.map((m) => m[1]).join('');
        while (passwordChars.length < totalLength) {
            passwordChars.push(allChars[Math.floor(Math.random() * allChars.length)]);
        }
        // Shuffle to avoid predictable order
        for (let i = passwordChars.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [passwordChars[i], passwordChars[j]] = [passwordChars[j], passwordChars[i]];
        }
        return passwordChars.join('');
    }
    static extractLength(pwdValidationPattern) {
        let toRet = [];
        const regexToExtractPatternMin = '{([0-9])';
        const regexToExtractPatternMax = '([0-9]{1,2})}';
        const regexMin = new RegExp(regexToExtractPatternMin);
        const regexMax = new RegExp(regexToExtractPatternMax);
        const min = regexMin.exec(pwdValidationPattern);
        const max = regexMax.exec(pwdValidationPattern);
        if (min) {
            toRet.push(parseInt(min[1]));
        }
        if (max) {
            toRet.push(parseInt(max[1]));
        }
        return toRet;
    }
    static getValidChars(pwdValidationPattern) {
        let index = pwdValidationPattern.indexOf('.{');
        let pattern = pwdValidationPattern.slice(0, index);
        let validChars = [];
        for (let i = 33; i < 48; i++) {
            // sepcials 1
            let char = String.fromCharCode(i);
            if (pattern.includes(char)) {
                validChars.push(char);
            }
        }
        for (let i = 48; i <= 57; i++) {
            //digits
            let char = String.fromCharCode(i);
            if (pattern.includes('0-9')) {
                validChars.push(char);
            }
        }
        for (let i = 58; i < 64; i++) {
            // sepcials 2
            let char = String.fromCharCode(i);
            if (pattern.includes(char)) {
                validChars.push(char);
            }
        }
        for (let i = 65; i <= 90; i++) {
            //upper case
            let char = String.fromCharCode(i);
            if (pattern.includes('A-Z')) {
                validChars.push(char);
            }
        }
        for (let i = 91; i < 96; i++) {
            // sepcials 3
            let char = String.fromCharCode(i);
            if (pattern.includes(char)) {
                validChars.push(char);
            }
        }
        for (let i = 97; i <= 122; i++) {
            //lower case
            let char = String.fromCharCode(i);
            if (pattern.includes('a-z')) {
                validChars.push(char);
            }
        }
        for (let i = 123; i < 127; i++) {
            // sepcials 4
            let char = String.fromCharCode(i);
            if (pattern.includes(char)) {
                validChars.push(char);
            }
        }
        if (!validChars.length) {
            throw new Error('Could not find characters that match the ' + 'password pattern ' + pwdValidationPattern + '. Patterns must match individual ' + 'characters, not the password as a whole.');
        }
        return validChars;
    }
}

function validateUsernameAvailability() {
    return (control) => {
        return of(control.value == "sda@sd.it" ? { userExists: true } : null);
        // return user.findUserByEmail(control.value)
        //     .pipe(
        //         map(user => username == "sdaradante" ? {userExists:true} : null)
        //     );
    };
}

const COMPLETE = {
    parse: {
        dateInput: 'dd/MM/yyyy',
    },
    display: {
        dateInput: 'dd/MM/yyyy',
        monthYearLabel: 'MMMM yyyy',
        dateA11yLabel: 'LL',
        monthYearA11yLabel: 'MMMM yyyy',
    },
};
const MONTH_YEAR = {
    parse: {
        dateInput: 'MM/yyyy',
    },
    display: {
        dateInput: 'MMMM yyyy',
        monthYearLabel: 'MMMM yyyy',
        dateA11yLabel: 'MM/yyyy',
        monthYearA11yLabel: 'MMMM yyyy',
    },
};
const ONLY_YEAR = {
    parse: {
        dateInput: 'yyyy',
    },
    display: {
        dateInput: 'yyyy',
        monthYearLabel: 'yyyy',
        dateA11yLabel: 'yyyy',
        monthYearA11yLabel: 'yyyy',
    },
};

class OnlyYearComponent {
    constructor(_dateAdapter) {
        this._dateAdapter = _dateAdapter;
        this.appearance = 'outline';
        this.selected = new EventEmitter();
    }
    ngOnInit() {
        this.dateHint = ONLY_YEAR.parse.dateInput;
        if (this.locale)
            this._dateAdapter.setLocale(this.locale);
        this.form = new FormGroup({});
        this.form.addControl('date', new FormControl(this.dateToEdit));
    }
    ngOnChanges(changes) {
        const _lang = changes['locale'];
        if (_lang) {
            if (_lang.currentValue != _lang.previousValue) {
                this._dateAdapter.setLocale(this.locale);
            }
        }
    }
    setYear(normalizedMonthAndYear, datepicker) {
        datepicker.close();
        this.selected.emit(normalizedMonthAndYear);
        this.form.get('date').setValue(normalizedMonthAndYear);
    }
}
OnlyYearComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: OnlyYearComponent, deps: [{ token: i1$2.DateAdapter }], target: i0.ɵɵFactoryTarget.Component });
OnlyYearComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: OnlyYearComponent, selector: "heart-only-year", inputs: { appearance: "appearance", locale: "locale", dateToEdit: "dateToEdit" }, outputs: { selected: "selected" }, providers: [{ provide: MAT_DATE_FORMATS, useValue: ONLY_YEAR }], usesOnChanges: true, ngImport: i0, template: "<p>only-year works!</p>\n<form [formGroup]=\"form\">\n\n  <mat-form-field [appearance]=\"appearance\">\n    <mat-label>{{ dateHint }}</mat-label>\n    <input matInput readonly [matDatepicker]=\"picker\" formControlName=\"date\" />\n    <mat-hint>{{ dateHint }}</mat-hint>\n    <mat-datepicker-toggle matIconSuffix [for]=\"picker\"></mat-datepicker-toggle>\n    <mat-datepicker startView=\"multi-year\" (yearSelected)=\"setYear($event, picker)\" #picker></mat-datepicker>\n  </mat-form-field>\n</form>", dependencies: [{ kind: "component", type: i2.MatDatepicker, selector: "mat-datepicker", exportAs: ["matDatepicker"] }, { kind: "directive", type: i2.MatDatepickerInput, selector: "input[matDatepicker]", inputs: ["matDatepicker", "min", "max", "matDatepickerFilter"], exportAs: ["matDatepickerInput"] }, { kind: "component", type: i2.MatDatepickerToggle, selector: "mat-datepicker-toggle", inputs: ["for", "tabIndex", "aria-label", "disabled", "disableRipple"], exportAs: ["matDatepickerToggle"] }, { kind: "component", type: i3$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i3$2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i3$2.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i3$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "directive", type: i4.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i4.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i4.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i4.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i4.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: i5.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: OnlyYearComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-only-year', providers: [{ provide: MAT_DATE_FORMATS, useValue: ONLY_YEAR }], template: "<p>only-year works!</p>\n<form [formGroup]=\"form\">\n\n  <mat-form-field [appearance]=\"appearance\">\n    <mat-label>{{ dateHint }}</mat-label>\n    <input matInput readonly [matDatepicker]=\"picker\" formControlName=\"date\" />\n    <mat-hint>{{ dateHint }}</mat-hint>\n    <mat-datepicker-toggle matIconSuffix [for]=\"picker\"></mat-datepicker-toggle>\n    <mat-datepicker startView=\"multi-year\" (yearSelected)=\"setYear($event, picker)\" #picker></mat-datepicker>\n  </mat-form-field>\n</form>" }]
        }], ctorParameters: function () { return [{ type: i1$2.DateAdapter }]; }, propDecorators: { appearance: [{
                type: Input
            }], locale: [{
                type: Input
            }], dateToEdit: [{
                type: Input
            }], selected: [{
                type: Output
            }] } });

class MonthYearComponent {
    constructor(_dateAdapter) {
        this._dateAdapter = _dateAdapter;
        this.appearance = 'outline';
        this.selected = new EventEmitter();
    }
    ngOnInit() {
        this.dateHint = MONTH_YEAR.parse.dateInput;
        if (this.locale)
            this._dateAdapter.setLocale(this.locale);
        this.form = new FormGroup({});
        this.form.addControl('date', new FormControl(this.dateToEdit));
    }
    ngOnChanges(changes) {
        const _lang = changes['locale'];
        if (_lang) {
            if (_lang.currentValue != _lang.previousValue) {
                this._dateAdapter.setLocale(this.locale);
            }
        }
    }
    setMonthAndYear(normalizedMonthAndYear, datepicker) {
        datepicker.close();
        this.selected.emit(normalizedMonthAndYear);
        this.form.get('date').setValue(normalizedMonthAndYear);
    }
}
MonthYearComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: MonthYearComponent, deps: [{ token: i1$2.DateAdapter }], target: i0.ɵɵFactoryTarget.Component });
MonthYearComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: MonthYearComponent, selector: "heart-month-year", inputs: { appearance: "appearance", locale: "locale", dateToEdit: "dateToEdit" }, outputs: { selected: "selected" }, providers: [{ provide: MAT_DATE_FORMATS, useValue: MONTH_YEAR }], usesOnChanges: true, ngImport: i0, template: "<form [formGroup]=\"form\">\n\n  <mat-form-field [appearance]=\"appearance\">\n    <mat-label>{{ dateHint }}</mat-label>\n    <input matInput readonly [matDatepicker]=\"picker\" formControlName=\"date\" />\n    <mat-hint>{{ dateHint }}</mat-hint>\n    <mat-datepicker-toggle matIconSuffix [for]=\"picker\"></mat-datepicker-toggle>\n    <mat-datepicker startView=\"multi-year\" (monthSelected)=\"setMonthAndYear($event, picker)\" #picker></mat-datepicker>\n  </mat-form-field>\n</form>", dependencies: [{ kind: "component", type: i2.MatDatepicker, selector: "mat-datepicker", exportAs: ["matDatepicker"] }, { kind: "directive", type: i2.MatDatepickerInput, selector: "input[matDatepicker]", inputs: ["matDatepicker", "min", "max", "matDatepickerFilter"], exportAs: ["matDatepickerInput"] }, { kind: "component", type: i2.MatDatepickerToggle, selector: "mat-datepicker-toggle", inputs: ["for", "tabIndex", "aria-label", "disabled", "disableRipple"], exportAs: ["matDatepickerToggle"] }, { kind: "component", type: i3$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i3$2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i3$2.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i3$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "directive", type: i4.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i4.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i4.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i4.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i4.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: i5.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: MonthYearComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-month-year', providers: [{ provide: MAT_DATE_FORMATS, useValue: MONTH_YEAR }], template: "<form [formGroup]=\"form\">\n\n  <mat-form-field [appearance]=\"appearance\">\n    <mat-label>{{ dateHint }}</mat-label>\n    <input matInput readonly [matDatepicker]=\"picker\" formControlName=\"date\" />\n    <mat-hint>{{ dateHint }}</mat-hint>\n    <mat-datepicker-toggle matIconSuffix [for]=\"picker\"></mat-datepicker-toggle>\n    <mat-datepicker startView=\"multi-year\" (monthSelected)=\"setMonthAndYear($event, picker)\" #picker></mat-datepicker>\n  </mat-form-field>\n</form>" }]
        }], ctorParameters: function () { return [{ type: i1$2.DateAdapter }]; }, propDecorators: { appearance: [{
                type: Input
            }], locale: [{
                type: Input
            }], dateToEdit: [{
                type: Input
            }], selected: [{
                type: Output
            }] } });

class CompleteDateComponent {
    constructor(_dateAdapter) {
        this._dateAdapter = _dateAdapter;
    }
    ngOnInit() {
        this.dateHint = COMPLETE.parse.dateInput;
        if (this.locale)
            this._dateAdapter.setLocale(this.locale);
    }
    ngOnChanges(changes) {
        const _lang = changes['locale'];
        if (_lang) {
            if (_lang.currentValue != _lang.previousValue) {
                this._dateAdapter.setLocale(this.locale);
            }
        }
    }
}
CompleteDateComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CompleteDateComponent, deps: [{ token: i1$2.DateAdapter }], target: i0.ɵɵFactoryTarget.Component });
CompleteDateComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: CompleteDateComponent, selector: "heart-complete-date", inputs: { locale: "locale" }, providers: [{ provide: MAT_DATE_FORMATS, useValue: COMPLETE }], usesOnChanges: true, ngImport: i0, template: "<mat-form-field appearance=\"fill\">\n  <mat-label>Different locale</mat-label>\n  <input matInput readonly [matDatepicker]=\"dp\">\n  <mat-hint>{{dateHint}}</mat-hint>\n  <mat-datepicker-toggle matIconSuffix [for]=\"dp\"></mat-datepicker-toggle>\n  <mat-datepicker #dp></mat-datepicker>\n</mat-form-field>", dependencies: [{ kind: "component", type: i2.MatDatepicker, selector: "mat-datepicker", exportAs: ["matDatepicker"] }, { kind: "directive", type: i2.MatDatepickerInput, selector: "input[matDatepicker]", inputs: ["matDatepicker", "min", "max", "matDatepickerFilter"], exportAs: ["matDatepickerInput"] }, { kind: "component", type: i2.MatDatepickerToggle, selector: "mat-datepicker-toggle", inputs: ["for", "tabIndex", "aria-label", "disabled", "disableRipple"], exportAs: ["matDatepickerToggle"] }, { kind: "component", type: i3$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i3$2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i3$2.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i3$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "directive", type: i5.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: CompleteDateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'heart-complete-date', providers: [{ provide: MAT_DATE_FORMATS, useValue: COMPLETE }], template: "<mat-form-field appearance=\"fill\">\n  <mat-label>Different locale</mat-label>\n  <input matInput readonly [matDatepicker]=\"dp\">\n  <mat-hint>{{dateHint}}</mat-hint>\n  <mat-datepicker-toggle matIconSuffix [for]=\"dp\"></mat-datepicker-toggle>\n  <mat-datepicker #dp></mat-datepicker>\n</mat-form-field>" }]
        }], ctorParameters: function () { return [{ type: i1$2.DateAdapter }]; }, propDecorators: { locale: [{
                type: Input
            }] } });

class FormUtilsModule {
}
FormUtilsModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: FormUtilsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
FormUtilsModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: FormUtilsModule, declarations: [MonthYearComponent, CompleteDateComponent, OnlyYearComponent], imports: [CommonModule, MatDatepickerModule, MatFormFieldModule, ReactiveFormsModule, MatInputModule], exports: [MonthYearComponent, CompleteDateComponent, OnlyYearComponent] });
FormUtilsModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: FormUtilsModule, providers: [
        { provide: MAT_DATE_FORMATS, useValue: MONTH_YEAR },
        { provide: DateAdapter, useClass: DateFnsAdapter, deps: [MAT_DATE_LOCALE] },
        { provide: MAT_DATE_LOCALE, useValue: enGB },
    ], imports: [CommonModule, MatDatepickerModule, MatFormFieldModule, ReactiveFormsModule, MatInputModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: FormUtilsModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [MonthYearComponent, CompleteDateComponent, OnlyYearComponent],
                    exports: [MonthYearComponent, CompleteDateComponent, OnlyYearComponent],
                    imports: [CommonModule, MatDatepickerModule, MatFormFieldModule, ReactiveFormsModule, MatInputModule],
                    providers: [
                        { provide: MAT_DATE_FORMATS, useValue: MONTH_YEAR },
                        { provide: DateAdapter, useClass: DateFnsAdapter, deps: [MAT_DATE_LOCALE] },
                        { provide: MAT_DATE_LOCALE, useValue: enGB },
                    ],
                }]
        }] });

class ValidationConfig {
}
ValidationConfig.pwdValidationPattern = '^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[*.!@$%^&()[\\]{}:;<>,.?~_+\\-=|]).{8,20}$';
ValidationConfig.pwdValidationPatternTextArray = [
    'form-utils.pwd.panel.text.8-20',
    'form-utils.pwd.panel.text.digits',
    'form-utils.pwd.panel.text.lowercase',
    'form-utils.pwd.panel.text.uppercase',
    'form-utils.pwd.panel.text.special',
];
ValidationConfig.taxCodeValidatorPattern = '^[A-Za-z]{6}[0-9]{2}[A-Za-z]{1}[0-9]{2}[A-Za-z]{1}[0-9]{3}[A-Za-z]{1}$';
ValidationConfig.emailValidationPattern = '^[a-zA-Z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$';
ValidationConfig.phoneValidatorPattern = '^\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d+)[-. )]*(\\d+)[-. ]*(\\d+)(?: *x(\\d+))?\\s*$';

/*
 * Public API Surface of model
 */

/*
 * Public API Surface of heart-ui-utils
 */

/**
 * Generated bundle index. Do not edit.
 */

export { COMPLETE, CompleteDateComponent, ConfirmationDialogComponent, ConfirmationDialogModule, DEFAULT_CONFIG, DebouncedButtonDirective, FormUtilsModule, HttpLoaderFactoryConfirmation, HttpLoaderFactoryMd, HttpLoaderFactoryMdTab, HttpLoaderFactoryMessageBox, HttpLoaderFactorySnackbar, InformationMdDialogComponent, InformationMdDialogModule, InformationMdTabDialogComponent, InformationMdTabDialogModule, MONTH_YEAR, MessageBoxComponent, MessageBoxModule, MonthYearComponent, ONLY_YEAR, OnlyYearComponent, OrderTranslatePipe, PasswordGeneratorUtils, PreventDoubleClickModule, SnackBarService, SnackbarModule, SubTranslateConfig, SubTranslateModule, SubTranslatePipe, SubTranslateService, UsefulPipesModule, ValidationConfig, validateUsernameAvailability };
//# sourceMappingURL=eng-it4h-heart-ui-utils.mjs.map
