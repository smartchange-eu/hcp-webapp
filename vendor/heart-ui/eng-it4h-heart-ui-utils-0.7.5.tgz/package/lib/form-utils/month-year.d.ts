import { EventEmitter, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { DateAdapter } from '@angular/material/core';
import { MatDatepicker } from '@angular/material/datepicker';
import { Locale } from 'date-fns';
import * as i0 from "@angular/core";
export declare class MonthYearComponent implements OnInit, OnChanges {
    private _dateAdapter;
    appearance: 'fill' | 'outline';
    locale?: Locale;
    dateToEdit?: Date;
    dateHint: string;
    selected: EventEmitter<Date>;
    form: FormGroup;
    constructor(_dateAdapter: DateAdapter<Date>);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setMonthAndYear(normalizedMonthAndYear: any, datepicker: MatDatepicker<any>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MonthYearComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MonthYearComponent, "heart-month-year", never, { "appearance": "appearance"; "locale": "locale"; "dateToEdit": "dateToEdit"; }, { "selected": "selected"; }, never, never, false, never>;
}
