export declare class ValidationConfig {
    static pwdValidationPattern: string;
    static pwdValidationPatternTextArray: string[];
    static taxCodeValidatorPattern: string;
    static emailValidationPattern: string;
    static phoneValidatorPattern: string;
}
