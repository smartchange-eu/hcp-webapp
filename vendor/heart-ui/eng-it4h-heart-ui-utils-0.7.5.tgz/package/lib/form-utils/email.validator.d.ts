import { AsyncValidatorFn } from '@angular/forms';
export declare function validateUsernameAvailability(): AsyncValidatorFn;
