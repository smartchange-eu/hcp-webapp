import * as i0 from "@angular/core";
import * as i1 from "./month-year";
import * as i2 from "./complete-date";
import * as i3 from "./only-year";
import * as i4 from "@angular/common";
import * as i5 from "@angular/material/datepicker";
import * as i6 from "@angular/material/form-field";
import * as i7 from "@angular/forms";
import * as i8 from "@angular/material/input";
export declare class FormUtilsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FormUtilsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FormUtilsModule, [typeof i1.MonthYearComponent, typeof i2.CompleteDateComponent, typeof i3.OnlyYearComponent], [typeof i4.CommonModule, typeof i5.MatDatepickerModule, typeof i6.MatFormFieldModule, typeof i7.ReactiveFormsModule, typeof i8.MatInputModule], [typeof i1.MonthYearComponent, typeof i2.CompleteDateComponent, typeof i3.OnlyYearComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FormUtilsModule>;
}
