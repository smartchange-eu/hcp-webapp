export declare class PasswordGeneratorUtils {
    static generateRandomPwd(pwdValidationPattern: string): string;
    static generatePasswordFromRegexAdvanced(regexStr: string): string;
    private static extractLength;
    private static getValidChars;
}
