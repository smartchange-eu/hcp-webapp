import { OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { DateAdapter } from '@angular/material/core';
import * as i0 from "@angular/core";
export declare class CompleteDateComponent implements OnInit, OnChanges {
    private _dateAdapter;
    dateHint: string;
    locale?: Locale;
    constructor(_dateAdapter: DateAdapter<Date>);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CompleteDateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CompleteDateComponent, "heart-complete-date", never, { "locale": "locale"; }, {}, never, never, false, never>;
}
