import { OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { ConfirmationDialogComponent } from '../confirmation-dialog';
import * as i0 from "@angular/core";
export declare class InformationMdDialogComponent implements OnInit {
    dialogRef: MatDialogRef<ConfirmationDialogComponent>;
    data: any;
    title: string;
    msg: string;
    closeLabel: string;
    okLabel: string;
    constructor(dialogRef: MatDialogRef<ConfirmationDialogComponent>, data: any);
    ngOnInit(): void;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InformationMdDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InformationMdDialogComponent, "heart-information-md-dialog", never, {}, {}, never, never, false, never>;
}
