import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as i0 from "@angular/core";
import * as i1 from "./information-md-dialog.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "@angular/material/dialog";
import * as i5 from "@angular/material/button";
import * as i6 from "@angular/material/core";
import * as i7 from "@angular/material/input";
import * as i8 from "@angular/material/select";
import * as i9 from "ngx-markdown";
import * as i10 from "@ngx-translate/core";
export declare function HttpLoaderFactoryMd(http: HttpClient): TranslateHttpLoader;
export declare class InformationMdDialogModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<InformationMdDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<InformationMdDialogModule, [typeof i1.InformationMdDialogComponent], [typeof i2.CommonModule, typeof i3.FormsModule, typeof i4.MatDialogModule, typeof i5.MatButtonModule, typeof i6.MatOptionModule, typeof i7.MatInputModule, typeof i8.MatSelectModule, typeof i9.MarkdownModule, typeof i10.TranslateModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<InformationMdDialogModule>;
}
