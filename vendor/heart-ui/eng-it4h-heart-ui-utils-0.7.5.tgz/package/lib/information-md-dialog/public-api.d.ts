export * from './information-md-dialog.module';
export * from './information-md-dialog.component';
