import { PipeTransform } from '@angular/core';
import { CodedValue } from '@eng-it4h/heart-ui-model';
import { TranslateService } from '@ngx-translate/core';
import * as i0 from "@angular/core";
export declare class OrderTranslatePipe implements PipeTransform {
    private translate;
    constructor(translate: TranslateService);
    transform(array: Array<CodedValue>): Array<CodedValue>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderTranslatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<OrderTranslatePipe, "orderTranslate", false>;
}
