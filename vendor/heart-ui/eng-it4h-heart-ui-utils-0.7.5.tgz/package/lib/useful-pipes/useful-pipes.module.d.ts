import * as i0 from "@angular/core";
import * as i1 from "./order-translate.pipe";
import * as i2 from "@angular/common";
export declare class UsefulPipesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UsefulPipesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UsefulPipesModule, [typeof i1.OrderTranslatePipe], [typeof i2.CommonModule], [typeof i1.OrderTranslatePipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UsefulPipesModule>;
}
