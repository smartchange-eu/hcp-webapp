export * from './information-md-tab-dialog.module';
export * from './information-md-tab-dialog.component';
