import { OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import * as i0 from "@angular/core";
export declare class InformationMdTabDialogComponent implements OnInit {
    dialogRef: MatDialogRef<InformationMdTabDialogComponent>;
    data: any;
    titlesContents: Map<string, string>;
    okLabel: string;
    protected keys: string[];
    constructor(dialogRef: MatDialogRef<InformationMdTabDialogComponent>, data: any);
    ngOnInit(): void;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InformationMdTabDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InformationMdTabDialogComponent, "heart-information-md-tab-dialog", never, {}, {}, never, never, false, never>;
}
