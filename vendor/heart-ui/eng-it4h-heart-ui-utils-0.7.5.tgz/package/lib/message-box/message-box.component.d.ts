import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare type MessgeType = 'info' | 'accent' | 'warning';
export declare class MessageBoxComponent implements OnInit {
    msg: string;
    type: MessgeType;
    icon?: string;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MessageBoxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MessageBoxComponent, "heart-message-box", never, { "msg": "msg"; "type": "type"; "icon": "icon"; }, {}, never, never, false, never>;
}
