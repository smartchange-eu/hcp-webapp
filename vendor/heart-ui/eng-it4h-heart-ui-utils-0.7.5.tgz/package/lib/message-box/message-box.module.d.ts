import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient } from '@angular/common/http';
import * as i0 from "@angular/core";
import * as i1 from "./message-box.component";
import * as i2 from "@angular/common";
import * as i3 from "@ngx-translate/core";
import * as i4 from "@angular/material/icon";
export declare function HttpLoaderFactoryMessageBox(http: HttpClient): TranslateHttpLoader;
export declare class MessageBoxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MessageBoxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MessageBoxModule, [typeof i1.MessageBoxComponent], [typeof i2.CommonModule, typeof i3.TranslateModule, typeof i4.MatIconModule], [typeof i1.MessageBoxComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MessageBoxModule>;
}
