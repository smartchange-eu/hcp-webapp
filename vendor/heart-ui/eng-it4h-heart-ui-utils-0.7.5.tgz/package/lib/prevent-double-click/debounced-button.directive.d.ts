import { EventEmitter, OnDestroy, OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class DebouncedButtonDirective implements OnInit, OnDestroy {
    debounceClickTime: number;
    debounceClick: EventEmitter<any>;
    private clicks;
    private subscription?;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    clickEvent(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DebouncedButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DebouncedButtonDirective, "[heartDebouncedButton]", never, { "debounceClickTime": "debounceClickTime"; }, { "debounceClick": "debounceClick"; }, never, never, false, never>;
}
