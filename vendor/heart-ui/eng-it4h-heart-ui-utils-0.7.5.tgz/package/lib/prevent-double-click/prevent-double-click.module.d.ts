import * as i0 from "@angular/core";
import * as i1 from "./debounced-button.directive";
import * as i2 from "@angular/common";
export declare class PreventDoubleClickModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PreventDoubleClickModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PreventDoubleClickModule, [typeof i1.DebouncedButtonDirective], [typeof i2.CommonModule], [typeof i1.DebouncedButtonDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PreventDoubleClickModule>;
}
