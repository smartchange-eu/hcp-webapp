import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient } from '@angular/common/http';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@angular/material/snack-bar";
import * as i3 from "@ngx-translate/core";
export declare function HttpLoaderFactorySnackbar(http: HttpClient): TranslateHttpLoader;
export declare class SnackbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SnackbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SnackbarModule, never, [typeof i1.CommonModule, typeof i2.MatSnackBarModule, typeof i3.TranslateModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SnackbarModule>;
}
