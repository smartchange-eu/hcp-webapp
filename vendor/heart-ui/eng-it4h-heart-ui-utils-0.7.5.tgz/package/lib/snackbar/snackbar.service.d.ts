import { MatSnackBar } from '@angular/material/snack-bar';
import { TranslateService } from '@ngx-translate/core';
import * as i0 from "@angular/core";
export declare class SnackBarService {
    private snackBar;
    private ts;
    constructor(snackBar: MatSnackBar, ts: TranslateService);
    /**
     *
     * @param message the message
     * @param action
     * @param duration
     * @param hPos
     * @param vPos
     */
    openSnackBar(message: string, action?: string, duration?: number, panelClass?: string | string[], hPos?: 'start' | 'center' | 'end' | 'left' | 'right', vPos?: 'top' | 'bottom'): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SnackBarService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SnackBarService>;
}
