export declare const it: {
    "utils.confirmation-dialog.reason.label": string;
    "utils.confirmation-dialog.reason.dropdown.label": string;
    "utils.confirmation-dialog.reason.notes.label": string;
};
