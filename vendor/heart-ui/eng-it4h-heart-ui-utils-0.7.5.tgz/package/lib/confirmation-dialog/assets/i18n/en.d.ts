export declare const en: {};
