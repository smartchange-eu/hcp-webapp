import { OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { CodedValue } from '@eng-it4h/heart-ui-model';
import { SubTranslateService } from '../sub-translate';
import * as i0 from "@angular/core";
export declare class ConfirmationDialogComponent implements OnInit {
    private _subTranslateService;
    dialogRef: MatDialogRef<ConfirmationDialogComponent>;
    data: any;
    title: string;
    msg: string;
    closeLabel?: string;
    okLabel?: string;
    reasons?: CodedValue[];
    notes?: string;
    lang: string;
    showOverriddenNotes: boolean;
    selectedReason?: CodedValue;
    constructor(_subTranslateService: SubTranslateService, dialogRef: MatDialogRef<ConfirmationDialogComponent>, data: any);
    createDictionary(): void;
    ngOnInit(): void;
    save(): void;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmationDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfirmationDialogComponent, "heart-confirmation-dialog", never, {}, {}, never, never, false, never>;
}
