export declare const it: {
    "button.store.label": string;
    "required.error": string;
    "email.error": string;
    "max.error": string;
    "min.error": string;
    "username.label": string;
    "pwd.label": string;
};
