import { PipeTransform } from '@angular/core';
import { SubTranslateService } from './sub-translate.service';
import * as i0 from "@angular/core";
export declare class SubTranslatePipe implements PipeTransform {
    private _subTranslateService;
    constructor(_subTranslateService: SubTranslateService);
    transform(value: string, lang?: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubTranslatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SubTranslatePipe, "subtranslate", false>;
}
