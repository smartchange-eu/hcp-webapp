import { ModuleWithProviders } from '@angular/core';
import { SubTranslateConfig } from './sub-translate.service';
import * as i0 from "@angular/core";
import * as i1 from "./sub-translate.pipe";
import * as i2 from "@angular/common";
import * as i3 from "@ngx-translate/core";
export declare const DEFAULT_CONFIG: SubTranslateConfig;
export declare class SubTranslateModule {
    static forRoot(config: SubTranslateConfig): ModuleWithProviders<SubTranslateModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubTranslateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SubTranslateModule, [typeof i1.SubTranslatePipe], [typeof i2.CommonModule, typeof i3.TranslateModule], [typeof i1.SubTranslatePipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SubTranslateModule>;
}
