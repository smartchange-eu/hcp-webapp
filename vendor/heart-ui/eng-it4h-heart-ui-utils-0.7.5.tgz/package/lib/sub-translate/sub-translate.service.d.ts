import { Locale, TranslationLanguage } from '@eng-it4h/heart-ui-model';
import { TranslateService } from '@ngx-translate/core';
import { Locale as FnsLocale } from 'date-fns';
import * as i0 from "@angular/core";
export declare class SubTranslateConfig {
    defaultLanguage: Locale;
    overwriteInitial?: boolean;
    useTranslateServiceFirst?: boolean;
    locales: Map<Locale, TranslationLanguage>;
}
export declare class SubTranslateService {
    private _translate;
    private _config;
    private _allowed;
    private _store;
    constructor(_translate: TranslateService, _config: SubTranslateConfig);
    setLanguages(dictionary: Map<string, any>): void;
    getFnsLocale(key: string): FnsLocale | undefined;
    getLocaleCode(key: string): string;
    private mergeLanguage;
    getTranslation(key: string, language: string): string;
    private isAllowed;
    get defaultLanguage(): string;
    private hasTranslation;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubTranslateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubTranslateService>;
}
