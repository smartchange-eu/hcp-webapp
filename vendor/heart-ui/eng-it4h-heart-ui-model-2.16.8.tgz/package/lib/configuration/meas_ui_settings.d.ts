export declare class MeasUiSettings {
    static BMI: {
        img: string;
        label: string;
    };
    static WAIST: {
        img: string;
        label: string;
        max: number;
        min: number;
    };
    static CIGARETTES: {
        img: string;
        label: string;
    };
    static SMOKER: {
        img: string;
        label: string;
    };
    static WEIGHT: {
        img: string;
        label: string;
        max: number;
        min: number;
    };
    static HEIGHT: {
        img: string;
        label: string;
        max: number;
        min: number;
    };
    static PHYSICAL_ACTIVITY: {
        img: string;
        label: string;
    };
    static HEART_RATE: {
        img: string;
        label: string;
    };
    static STEP_COUNT: {
        img: string;
        label: string;
    };
    static SUPERVISOR_REQUIRED: {
        img: string;
        label: string;
    };
    static PHYSICAL_INABILITY: {
        img: string;
        label: string;
    };
    static BLOOD_GLUCOSE: {
        img: string;
        label: string;
        max: number;
        min: number;
    };
    static HBA1C: {
        img: string;
        label: string;
        max: number;
        min: number;
    };
    static SPO2: {
        img: string;
        label: string;
        max: number;
        min: number;
    };
    static HDL: {
        img: string;
        label: string;
        max: number;
        min: number;
    };
    static LDL: {
        img: string;
        label: string;
        max: number;
        min: number;
    };
    static CHOLESTEROL: {
        img: string;
        label: string;
        max: number;
        min: number;
    };
    static TRIGLYCERIDE: {
        img: string;
        label: string;
        max: number;
        min: number;
    };
    static MEAL_ACTIVITY: {
        img: string;
        label: string;
    };
    static CALORIC_DAILY_INTAKE: {
        img: string;
        label: string;
    };
    static FIBERS_DAILY_INTAKE: {
        img: string;
        label: string;
    };
    static CARBOHYDRATES_DAILY_INTAKE: {
        img: string;
        label: string;
    };
    static PROTEINS_DAILY_INTAKE: {
        img: string;
        label: string;
    };
    static FATS_DAILY_INTAKE: {
        img: string;
        label: string;
    };
    static SODIUM_DAILY_INTAKE: {
        img: string;
        label: string;
    };
    static VEGETABLES_PORTIONS_DAILY_INTAKE: {
        img: string;
        label: string;
    };
    static FRUIT_PORTIONS_DAILY_INTAKE: {
        img: string;
        label: string;
    };
    static ARTERIAL_PRESSURE: {
        img: string;
        label: string;
    };
    static SYS_PRESSURE: {
        img: string;
        label: string;
        max: number;
        min: number;
    };
    static DIA_PRESSURE: {
        img: string;
        label: string;
        max: number;
        min: number;
    };
    static HR: {
        img: string;
        label: string;
        max: number;
        min: number;
    };
    static TEMP: {
        img: string;
        label: string;
        max: number;
        min: number;
    };
    static COVID: {
        img: string;
        label: string;
    };
    static CHEST_PAIN_Q: {
        img: string;
        label: string;
    };
    static CHEST_PAIN_LEVEL: {
        img: string;
        label: string;
    };
}
