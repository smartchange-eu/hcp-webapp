import { FeedbackInAppType } from '../model/feedback';
/**
 * configurazioni della frequenza (opzionale) e del periodo di eviction (opzionale) per ciascuna tipologia di comunicazione
 *
 * ATTENZIONE: Assicurarsi che il nome delle variabili statiche corrisponda con il rispettivo FeedbackInAppTypeName
 * altirmenti ci saranno problemi con il recupero dal DB
 */
export declare class FeedbackTypeSettings {
    static TTM: FeedbackInAppType;
    static S_UX_QUESTIONNAIRE: FeedbackInAppType;
    static BG_P1: FeedbackInAppType;
    static BG_P2: FeedbackInAppType;
    static BG_P3: FeedbackInAppType;
    static BG_P4: FeedbackInAppType;
    static BG_P5: FeedbackInAppType;
    static BG_P6: FeedbackInAppType;
    static BG_P7: FeedbackInAppType;
    static MEAL_BREAKFAST: FeedbackInAppType;
    static MEAL_LUNCH: FeedbackInAppType;
    static MEAL_DINNER: FeedbackInAppType;
    static PHYSICAL_ACTIVITY: FeedbackInAppType;
    static HABITS_SMOKING: FeedbackInAppType;
    static WEIGHT: FeedbackInAppType;
    /**
     * From here onward the FeedbackInAppType have a 'global' scope and they are used only in the Jobs
     */
    static REMINDER: FeedbackInAppType;
    static MOTIVATIONAL: FeedbackInAppType;
    static INFORMATIVE: FeedbackInAppType;
}
