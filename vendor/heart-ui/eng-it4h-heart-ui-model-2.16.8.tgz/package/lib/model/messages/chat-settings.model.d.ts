import { HealthCareProfessional, Patient } from '../actor';
export declare class ChatSettings {
    private static resourceType;
    patient: Patient;
    practitioner: HealthCareProfessional;
    option: ChatSettings.ChatSettingsType;
    toJSON(): any;
    static revive(json: any | ChatSettings): ChatSettings;
}
export declare namespace ChatSettings {
    enum ChatSettingsType {
        NO_MESSAGING,
        CHAT_ONLY,
        CHAT_AND_VIDEO
    }
    namespace ChatSettingsType {
        function valueOf(type: string): ChatSettingsType;
    }
}
