import { Shareable } from './../shareable.model';
export declare abstract class Message extends Shareable {
    readonly resourceType: string;
    title: string;
    received: Date;
    sent?: Date;
    read?: Date;
    isSent(): boolean;
    isReceived(): boolean;
    isRead(): boolean;
    /**
     * this is needed in case the message contains values that have to be used when translating the message content
     */
    valuesAsObject(): any;
    toLog(): string;
}
