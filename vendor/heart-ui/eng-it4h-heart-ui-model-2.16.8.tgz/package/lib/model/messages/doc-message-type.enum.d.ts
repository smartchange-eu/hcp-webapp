export declare enum DocMessageType {
    COMMUNICATION,
    CONGRATULATION,
    MOTIVATIONAL,
    DATA_REQUEST
}
export declare namespace DocMessageType {
    function valueOf(type: string): DocMessageType;
}
