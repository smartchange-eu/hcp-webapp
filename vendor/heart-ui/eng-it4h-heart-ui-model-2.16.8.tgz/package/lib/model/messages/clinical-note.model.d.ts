import { Patient } from '../actor';
import { HealthCareProfessional } from '../actor/healthcare-professional.model';
import { Shareable } from '../shareable.model';
/**
 * A clinical note is a means for care team to discuss about a patient.
 *
 * Clinical notes can be 'referred to' (i.e. reply mechanism)
 */
export declare class ClinicalNote extends Shareable {
    readonly resourceType: string;
    get slug(): string;
    set slug(slug: string);
    title: string;
    description: string;
    body: string;
    createdAt: Date;
    tagList: string[];
    patient: Patient;
    author: HealthCareProfessional;
    refers?: ClinicalNote;
}
