import { Message } from './message.model';
export declare class InformativeMessage extends Message {
    textLabel: string;
    commId: number;
    goToModule: string;
    goToPage: string;
    constructor(commId?: number, text?: string, title?: string, received?: Date);
    toString(): string;
    toLog(): string;
}
