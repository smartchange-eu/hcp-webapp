import { Message } from './message.model';
import { Versionable } from '../versionable.model';
import { Person } from '../actor';
export declare class ChatMessage extends Message implements Versionable {
    version: string;
    text: string;
    sender: Person;
    recipient: Person;
    constructor(text?: string, title?: string, received?: Date, sent?: Date, read?: Date, sender?: Person, recipient?: Person);
    toString(): string;
    supportVersion(): boolean;
}
