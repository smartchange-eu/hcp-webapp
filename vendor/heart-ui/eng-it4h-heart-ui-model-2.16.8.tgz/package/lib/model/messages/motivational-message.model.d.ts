import { Message } from './message.model';
import { MotivationalMessageType } from './motivational-message-type.model';
export declare class MotivationalMessage extends Message {
    cluster: string;
    textLabel: string;
    /**
     * Identificativo dell'albero decisionale corrispondente ad un macro-goal
     */
    goalType: string;
    elapseBeforeRepetitionInDays: number;
    messageType: MotivationalMessageType;
    values: Map<string, any>;
    constructor(cluster?: string, textLabel?: string, messageType?: MotivationalMessageType, title?: string, received?: Date, elapseBeforeRepetitionInDays?: number);
    valuesAsObject(): any;
    toString(): string;
    getPriority(): number;
}
