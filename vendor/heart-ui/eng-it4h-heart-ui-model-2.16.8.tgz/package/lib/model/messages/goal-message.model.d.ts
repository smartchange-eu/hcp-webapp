import { Message } from './message.model';
export declare class GoalMessage extends Message {
    goalFhirId: string;
    text: string;
    sender: string;
    constructor(text?: string, title?: string, received?: Date, goalFhirId?: string, sender?: string);
}
