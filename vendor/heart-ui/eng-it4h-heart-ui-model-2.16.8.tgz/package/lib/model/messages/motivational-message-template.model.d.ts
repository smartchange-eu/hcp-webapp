import { MotivationalMessageType } from './motivational-message-type.model';
export interface MotivationalMessageTemplate {
    cluster: string;
    elapseInDays: number;
    goalType: string;
    label: string;
    messageType: MotivationalMessageType;
}
