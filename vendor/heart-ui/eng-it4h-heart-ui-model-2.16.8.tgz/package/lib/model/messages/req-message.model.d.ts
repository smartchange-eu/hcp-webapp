import { FeedbackInAppTypeName } from './../feedback';
import { Message } from './message.model';
/**
 * I req message sono usati per definire su quale pagina deve finire la comunicazione
 */
export declare class ReqMessage extends Message {
    readonly resourceType: string;
    textLabel: string;
    commId: number;
    reqType: FeedbackInAppTypeName;
    goToModule: string;
    goToPage: string;
    constructor(goToModule?: string, goToPage?: string, text?: string, title?: string, received?: Date, reqType?: FeedbackInAppTypeName);
    toString(): string;
    toLog(): string;
}
