export declare enum MotivationalMessageType {
    ADVICE,
    APPLAUDE,
    ARRANGE,
    BOOSTER,
    KEEP_ON_TRACK,
    DO_NOTHING,
    NEEDED_INFO
}
