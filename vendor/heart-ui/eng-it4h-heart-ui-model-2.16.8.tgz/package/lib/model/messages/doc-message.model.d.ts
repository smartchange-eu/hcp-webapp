import { Message } from './message.model';
import { DocMessageType } from './doc-message-type.enum';
import { Person } from '../actor';
export declare class DocMessage extends Message {
    goalFhirId: string;
    type: DocMessageType;
    text: string;
    customMsg: string;
    senderName: string;
    sender: Person;
    recipient: Person;
    constructor(text?: string, title?: string, received?: Date, customMsg?: string, senderName?: string, sender?: Person, recipient?: Person);
    getCompleteMsg(): string;
    toString(): string;
}
