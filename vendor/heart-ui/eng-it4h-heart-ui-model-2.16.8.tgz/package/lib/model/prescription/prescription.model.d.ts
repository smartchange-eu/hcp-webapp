import { Patient } from '../actor';
import { CodedValue } from '../coded-value.model';
import { Shareable } from '../shareable.model';
export declare abstract class Prescription extends Shareable {
    subject?: Patient;
    priority?: CodedValue;
    dateTime?: Date;
    readonly resourceType: string;
    constructor(subject?: Patient, priority?: CodedValue, dateTime?: Date);
}
