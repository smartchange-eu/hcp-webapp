import { HealthCareProfessional, Patient } from '../actor';
import { CodedValue } from '../coded-value.model';
import { Diagnosis } from '../conditions';
import { Encounter } from '../episodes';
import { Prescription } from './prescription.model';
export declare class ExamPrescription extends Prescription {
    subject?: Patient;
    examCode?: CodedValue;
    specimenType?: CodedValue;
    priority?: CodedValue;
    author?: HealthCareProfessional;
    dateTime?: Date;
    note?: string;
    diagnosis?: Diagnosis[];
    encounter?: Encounter;
    constructor(subject?: Patient, examCode?: CodedValue, specimenType?: CodedValue, priority?: CodedValue, author?: HealthCareProfessional, dateTime?: Date);
}
