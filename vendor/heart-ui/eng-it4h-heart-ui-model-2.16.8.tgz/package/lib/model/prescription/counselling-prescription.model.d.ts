import { Patient } from '../actor';
import { CodedValue } from '../coded-value.model';
import { Plan } from '../goal';
import { Shareable } from '../shareable.model';
import { Prescription } from './prescription.model';
export declare class CounsellingPrescription extends Prescription {
    subject?: Patient;
    priority?: CodedValue;
    dateTime?: Date;
    status?: Plan.PlanStatus;
    supportingInfo?: Shareable[];
    constructor(subject?: Patient, priority?: CodedValue, dateTime?: Date, status?: Plan.PlanStatus);
}
