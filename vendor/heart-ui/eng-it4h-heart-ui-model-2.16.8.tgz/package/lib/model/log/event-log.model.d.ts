/**
 * EventLog class to monitor events in the mobile app
 */
export declare class EventLog {
    timestamp: Date;
    patientId: string;
    view: string;
    operation: string;
    element: string;
    constructor(timestamp: Date, patientId: string, view: string, operation: string, // = LogConf.NOOPERATION,
    element: string);
}
