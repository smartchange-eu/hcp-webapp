export declare class CodedValue {
    readonly system: string;
    readonly code: string;
    readonly display?: string;
    readonly originalDisplay?: string;
    private readonly SEPARATOR;
    constructor(system: string, code: string, display?: string, // i18n string
    originalDisplay?: string);
    get uniqueLabelKey(): string;
}
