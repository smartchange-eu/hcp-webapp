import { LengthUnit } from './units';
import { QuantitativeMeasure } from './quantitative-measure.model';
export declare class Height extends QuantitativeMeasure {
    static TYPE: string;
    value: number;
    unit: LengthUnit;
    constructor(value?: number, unit?: LengthUnit);
    valueIn(asUnit?: LengthUnit): number;
}
