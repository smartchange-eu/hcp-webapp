import { Measure } from './measure.model';
export declare class COVIDSymptoms extends Measure {
    nasalCongestion: boolean;
    soreThroat: boolean;
    fever: boolean;
    fatigue: boolean;
    cough: boolean;
    coughType: CoughType.CoughTypeCategory;
    lossOfTasteAndSmell: boolean;
    conjunctivitis: boolean;
    constructor(value?: number);
}
export declare namespace CoughType {
    enum CoughTypeCategory {
        dry_cough,
        wet_cough
    }
}
