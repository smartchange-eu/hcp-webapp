import { QuantitativeMeasure } from './quantitative-measure.model';
export declare class Smoker extends QuantitativeMeasure {
    static TYPE: string;
    value: number;
    constructor(value?: number);
    get valueAsBoolean(): boolean;
    set valueAsBoolean(value: boolean);
}
