export declare enum TemperatureUnit {
    CELSIUS,
    FAHRENHEIT
}
export declare namespace TemperatureUnit {
    function convert(value: number, from: TemperatureUnit, to: TemperatureUnit): TemperatureUnit;
}
