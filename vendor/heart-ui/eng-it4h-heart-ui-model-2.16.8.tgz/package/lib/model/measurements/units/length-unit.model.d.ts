export declare enum LengthUnit {
    km,
    m,
    cm
}
export declare namespace LengthUnit {
    function convert(value: number, from: LengthUnit, to: LengthUnit): LengthUnit;
}
