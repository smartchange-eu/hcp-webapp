export declare enum WeightUnit {
    kg,
    g,
    mg
}
export declare namespace WeightUnit {
    function convert(value: number, from: WeightUnit, to: WeightUnit): WeightUnit;
}
