export declare enum ConcentrationUnit {
    mmol,
    mgdL
}
export declare namespace ConcentrationUnit {
    function convert(value: number, from: ConcentrationUnit, to: ConcentrationUnit): ConcentrationUnit;
}
