export declare enum PercentageUnit {
    perc
}
export declare namespace PercentageUnit {
    function convert(value: number, from: PercentageUnit, to: PercentageUnit): PercentageUnit;
}
