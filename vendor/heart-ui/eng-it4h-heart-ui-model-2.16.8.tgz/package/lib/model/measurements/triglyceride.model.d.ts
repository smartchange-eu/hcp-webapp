import { ConcentrationUnit } from './units/concentration-unit.model';
import { QuantitativeMeasure } from './quantitative-measure.model';
export declare class Triglyceride extends QuantitativeMeasure {
    static TYPE: string;
    value: number;
    unit: ConcentrationUnit;
    constructor(value?: number, unit?: ConcentrationUnit);
    valueIn(asUnit?: ConcentrationUnit): number;
}
