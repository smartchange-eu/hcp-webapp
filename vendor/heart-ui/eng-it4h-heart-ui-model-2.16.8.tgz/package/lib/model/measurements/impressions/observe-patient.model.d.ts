import { HealthCareProfessional, Patient } from '../../actor';
import { Shareable } from '../../shareable.model';
export declare class ObservePatient extends Shareable {
    readonly resourceType = "ObservePatient";
    patient: Patient;
    practitioner: HealthCareProfessional;
    assertedWhen: Date;
    status: boolean;
    toString(): string;
    toJSON(): any;
    static revive(json: any | ObservePatient): ObservePatient;
}
