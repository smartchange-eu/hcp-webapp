export * from './observe-patient.model';
