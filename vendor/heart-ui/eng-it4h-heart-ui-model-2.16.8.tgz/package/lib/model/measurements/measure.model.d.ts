import { CodedValue } from '../coded-value.model';
import { Event } from './event.model';
export declare abstract class Measure extends Event {
    readonly resourceType: string;
    status: string;
    method?: CodedValue;
    protected _image: string;
    protected _label: string;
    private _healthId;
    get healthId(): string;
    set healthId(value: string);
    healthSource: string;
    get image(): string;
    get label(): string;
    getName(): string;
}
