import { CategoryMeasure } from './category-measure.model';
export declare class AlcoholDrinkingFrequency extends CategoryMeasure {
    value: AlcoholDrinkingFrequency.AlcoholDrinkingFrequencyCategory;
    constructor(value?: AlcoholDrinkingFrequency.AlcoholDrinkingFrequencyCategory);
}
export declare namespace AlcoholDrinkingFrequency {
    enum AlcoholDrinkingFrequencyCategory {
        no_drink_per_day,
        less_than_2_drink_per_day,
        less_than_3_drink_per_day,
        less_than_4_drink_per_day,
        more_than_equal_4_drink_per_day
    }
}
