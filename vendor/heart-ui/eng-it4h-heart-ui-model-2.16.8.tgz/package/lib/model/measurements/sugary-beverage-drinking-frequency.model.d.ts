import { CategoryMeasure } from './category-measure.model';
export declare class SugaryBeverageDrinkingFrequency extends CategoryMeasure {
    value: SugaryBeverageDrinkingFrequency.SugaryBeverageDrinkingFrequencyCategory;
    constructor(value?: SugaryBeverageDrinkingFrequency.SugaryBeverageDrinkingFrequencyCategory);
}
export declare namespace SugaryBeverageDrinkingFrequency {
    enum SugaryBeverageDrinkingFrequencyCategory {
        no_drink_per_day,
        less_than_2_drink_per_day,
        less_than_3_drink_per_day,
        less_than_4_drink_per_day,
        more_than_equal_4_drink_per_day
    }
}
