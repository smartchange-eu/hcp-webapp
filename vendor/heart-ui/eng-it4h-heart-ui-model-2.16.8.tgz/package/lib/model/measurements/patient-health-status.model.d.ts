import { CategoryMeasure } from './category-measure.model';
export declare class PatientHealthStatus extends CategoryMeasure {
    value: PatientHealthStatus.PatientHealthStatusCategory;
    constructor(value?: PatientHealthStatus.PatientHealthStatusCategory);
}
export declare namespace PatientHealthStatus {
    enum PatientHealthStatusCategory {
        POOR,
        FAIR,
        GOOD
    }
    namespace PatientHealthStatusCategory {
        function valueOf(type: string): PatientHealthStatusCategory;
    }
}
