import { QuantitativeMeasure } from './quantitative-measure.model';
import { WeightUnit } from './units/weight-unit.model';
export declare class Weight extends QuantitativeMeasure {
    static TYPE: string;
    value: number;
    unit: WeightUnit;
    constructor(value?: number, unit?: WeightUnit);
    valueIn(asUnit?: WeightUnit): number;
}
