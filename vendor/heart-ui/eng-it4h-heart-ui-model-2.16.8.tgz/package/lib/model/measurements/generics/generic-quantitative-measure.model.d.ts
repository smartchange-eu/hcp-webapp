import { CodedValue } from '../../coded-value.model';
import { Choice } from '../../questionnaires';
import { QuantitativeMeasure } from '../quantitative-measure.model';
export declare class GenericQuantitativeMeasure extends QuantitativeMeasure {
    private readonly SEPARATOR;
    value: number;
    cv: CodedValue;
    cvType: CodedValue;
    components: GenericQuantitativeMeasure[];
    constructor(value?: number | Choice, code?: CodedValue, unit?: CodedValue, components?: GenericQuantitativeMeasure[]);
    fromQuantitativeMeasure(measure: QuantitativeMeasure): void;
    toString(): string;
}
