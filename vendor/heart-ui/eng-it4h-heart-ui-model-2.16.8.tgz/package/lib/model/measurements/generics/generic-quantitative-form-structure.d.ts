import { QuantitativeSectionFormStructure } from "./quantitative-section-form-structure";
export declare class GenericQuantitativeFormStructure {
    sections: QuantitativeSectionFormStructure[];
}
