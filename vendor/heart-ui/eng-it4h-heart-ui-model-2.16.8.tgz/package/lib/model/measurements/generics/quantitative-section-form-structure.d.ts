import { CodedValue } from '../../coded-value.model';
import { CodedValueQuestion } from './coded-value-question.model';
export declare class QuantitativeSectionFormStructure {
    order?: number;
    label: CodedValue;
    valuesToCollect: CodedValueQuestion[];
}
