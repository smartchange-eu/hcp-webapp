import { CodedValue } from '../../coded-value.model';
import { Choice, Question } from '../../questionnaires';
export declare class CodedValueQuestion extends Question {
    readonly resourceType: string;
    order?: number;
    cvToCollect: CodedValue;
    permittedAnswers?: Choice[] | string;
    multiChoice: boolean;
    icon?: string;
    unit?: CodedValue | CodedValue[];
    tooltipKey?: string;
    readonly?: boolean;
    components: CodedValueQuestion[];
    hasClosedAnswer(): boolean;
}
