import { CategoryMeasure } from '../measurements/category-measure.model';
export declare class TTM extends CategoryMeasure {
    value: TTM.TTMCategory;
    constructor(value?: TTM.TTMCategory);
}
export declare namespace TTM {
    enum TTMCategory {
        TTM1,
        TTM2
    }
}
