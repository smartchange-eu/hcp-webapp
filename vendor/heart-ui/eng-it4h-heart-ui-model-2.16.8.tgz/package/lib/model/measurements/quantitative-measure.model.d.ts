import { Measure } from './measure.model';
export declare abstract class QuantitativeMeasure extends Measure {
    value?: number;
    unit?: any;
    unitLabel?: any;
    toString(): string;
}
