import { QuantitativeMeasure } from './quantitative-measure.model';
export declare class SodiumDailyIntake extends QuantitativeMeasure {
    static TYPE: string;
    value: number;
    readonly unit: string;
    constructor(value?: number);
    valueIn(): number;
    toString(): string;
}
