import { QuantitativeMeasure } from './quantitative-measure.model';
export declare class ChestPainLevel extends QuantitativeMeasure {
    static TYPE: string;
    value: number;
    constructor(value?: number);
}
