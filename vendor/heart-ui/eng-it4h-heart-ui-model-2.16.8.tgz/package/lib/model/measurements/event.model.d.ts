import { Patient } from '../actor';
import { Shareable } from '../shareable.model';
export declare abstract class Event extends Shareable {
    assertedWhen: Date;
    notes: string;
    automatic: boolean;
    patient: Patient;
    constructor(assertedWhen?: Date);
    toString(): string;
}
