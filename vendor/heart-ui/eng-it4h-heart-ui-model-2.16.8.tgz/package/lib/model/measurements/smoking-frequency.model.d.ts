import { CategoryMeasure } from './category-measure.model';
import { Versionable } from '../versionable.model';
export declare class SmokingFrequency extends CategoryMeasure implements Versionable {
    static TYPE: string;
    value: SmokingFrequency.SmokingFrequencyCategory;
    version: string;
    constructor(value?: SmokingFrequency.SmokingFrequencyCategory);
    supportVersion(): boolean;
    toString(): string;
}
export declare namespace SmokingFrequency {
    enum SmokingFrequencyCategory {
        exactly_0_cigarettes_per_day,
        lt_eq_5_cigarettes_per_day,
        lt_eq_10_cigarettes_per_day,
        lt_eq_15_cigarettes_per_day,
        lt_eq_20_cigarettes_per_day,
        more_than_20_cigarettes_per_day
    }
}
