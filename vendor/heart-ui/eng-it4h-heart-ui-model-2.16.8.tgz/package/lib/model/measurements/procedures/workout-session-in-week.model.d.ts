import { QuantitativeMeasure } from '../quantitative-measure.model';
export declare class WorkoutSessionInWeek extends QuantitativeMeasure {
    static TYPE: string;
    value: number;
    readonly unit = "session/week";
    constructor();
}
