import { Food } from './food.model';
import { Versionable } from '../../versionable.model';
import { Measure } from '../measure.model';
export declare class Meal extends Measure implements Versionable {
    resourceType: string;
    static TYPE: string;
    version: string;
    healthSource: string;
    foods: Food[];
    type: MealType;
    constructor();
    supportVersion(): boolean;
    calculateKcal(): number;
    calculateCarbsInKcal(): number;
    toString(): string;
}
export declare enum MealType {
    SNACK,
    BREAKFAST,
    LUNCH,
    DINNER
}
