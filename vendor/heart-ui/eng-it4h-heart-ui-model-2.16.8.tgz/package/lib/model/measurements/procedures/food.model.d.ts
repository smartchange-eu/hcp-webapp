import { MealType } from './meal.model';
export declare class Food {
    private readonly imagePrefix;
    private readonly labelPrefix;
    private readonly portionLabelPrefix;
    private readonly portionLabelSuffix;
    private readonly customLabel;
    id: number;
    image: string;
    label: string;
    type: Food.FoodType;
    details: Food.FoodDetails;
    portionSize: Food.PortionSize;
    private small;
    private medium;
    private large;
    bestAt: MealType[];
    setType(t: Food.FoodType): void;
    /**
     * This mehtod can be invoked only if the object has all the data about the portions.
     * Otherwise you have to directly set the attribute 'details'
     *
     * @param portionSize
     */
    recalculatePortionNutrients(portionSize: Food.PortionSize): Food.FoodDetails;
    toString(): string;
    getSmallGrams(): string;
    getMediumGrams(): string;
    getLargeGrams(): string;
    getUnit(): string;
    getSmallLabel(): string;
    getMediumLabel(): string;
    getLargeLabel(): string;
    getPortionSizeLabel(): string;
    setCustomNutrients(customGrams: number): void;
    reCalculatePortionSize(completeFood: Food): Food.PortionSize;
    static revive(json: any): Food;
}
export declare namespace Food {
    enum PortionSize {
        SMALL = 1,
        MEDIUM = 2,
        LARGE = 3,
        CUSTOM = 4
    }
    interface FoodDetails {
        caloricIntake?: number;
        carbsInKcal?: number;
        fatsInKcal?: number;
        proteinsInKcal?: number;
        fibersInGrams?: number;
        sodiumInMilliGrams?: number;
        weightInGrams?: number;
        label?: string;
    }
    enum FoodType {
        PASTA_RICE = 1,
        WHOLEMEAL_PASTA_RICE = 2,
        DRIED_LEGUMES = 3,
        MEAT = 4,
        SWEETS = 5,
        VEGETABLES = 6,
        EGG = 7,
        FISH = 8,
        SAVORY_SNACK = 9,
        FRUIT = 10,
        POTATOES = 11,
        FRESH_DAIRY_PRODUCTS = 12,
        DRIED_FRUITS = 13,
        FAST_FOOD = 14,
        ALCOHOL = 15,
        SUGARY_DRINKS = 16,
        OIL = 17,
        COLD_CUTS = 18,
        SEASONED_DAIRY_PRODUCTS = 19,
        MILK_YOGURT = 20,
        BREAD = 21,
        SALAD = 22,
        SUGAR = 23,
        COOKIE = 24,
        CROISSANT = 25,
        MARMALADE = 26,
        PIZZA = 27,
        FRESH_LEGUMES = 28,
        CAKES = 29,
        ICE_CREAM = 30,
        BANANA = 31,
        SALT = 32
    }
}
