export declare class Intensity {
    label: string;
    description: string;
    image: string;
    constructor(label: string, description: string, image: string);
}
