import { QuantitativeMeasure } from '../quantitative-measure.model';
export declare class ModerateWorkoutDurationInWeek extends QuantitativeMeasure {
    static TYPE: string;
    constructor();
}
