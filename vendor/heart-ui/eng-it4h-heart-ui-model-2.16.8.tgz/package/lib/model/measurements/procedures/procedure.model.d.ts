import { Event } from '../event.model';
export declare abstract class Procedure extends Event {
    protected _image: string;
    protected _label: string;
    private _fhirId;
    get fhirId(): string;
    set fhirId(value: string);
    private _healthId;
    get healthId(): string;
    set healthId(value: string);
    performedSince: Date;
    performedTo: Date;
    get image(): string;
    get label(): string;
    getDurationInMinutes(): number;
}
