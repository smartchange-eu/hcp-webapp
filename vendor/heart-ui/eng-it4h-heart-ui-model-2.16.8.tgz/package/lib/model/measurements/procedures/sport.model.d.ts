export declare class Sport {
    img: string;
    label: string;
    selectable: boolean;
    selected: boolean;
    minIntensity: number;
    maxIntensity: number;
    mix: boolean;
    constructor(img: string, label: string, selectable: boolean, selected: boolean, min: number, max: number);
    toString(): string;
}
export declare namespace Sport {
    enum SportIntensity {
        LIGHT = 0,
        MODERATE = 1,
        VIGOROUS = 2,
        EXTREME = 3
    }
}
