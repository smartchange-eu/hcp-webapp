import { Procedure } from './procedure.model';
import { Distance } from '../distance.model';
import { EnergyExpenditure } from '../energy-expenditure.model';
import { StepCount } from '../step-count.model';
export declare class Workout extends Procedure {
    readonly resourceType: string;
    static TYPE: string;
    distance: Distance;
    energyExpenditure: EnergyExpenditure;
    stepCount: StepCount;
    workoutType: WorkoutType;
    intensity: WorkoutIntensity;
    healthSource: string;
    bpm: number;
    constructor();
    toString(): string;
}
export declare enum WorkoutIntensity {
    LIGHT,
    MODERATE,
    VIGOROUS
}
export declare enum WorkoutType {
    WALKING = 0,
    JOGGING = 1,
    CYCLING = 2,
    FITNESS = 3,
    BODY_BUILDING = 4,
    SOCCER = 5,
    TENNIS = 6,
    VOLLEY = 7,
    BASKET = 8,
    GENERIC_SPORT = 9,
    GENERIC_AEROBIC_ACTIVITY = 10,
    GENERIC_ANAEROBIC_ACTIVITY = 11,
    GENERIC_STRENGTH_ACTIVITY = 12,
    SWIMMING = 13,
    YOGA = 14
}
