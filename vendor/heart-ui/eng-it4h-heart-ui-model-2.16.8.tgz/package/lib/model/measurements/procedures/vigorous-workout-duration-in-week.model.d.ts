import { QuantitativeMeasure } from '../quantitative-measure.model';
export declare class VigorousWorkoutDurationInWeek extends QuantitativeMeasure {
    static TYPE: string;
    value: number;
    unit: string;
    constructor();
    setDuration(start: Date, end: Date): void;
}
