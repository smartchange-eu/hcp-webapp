import { Measure } from './measure.model';
export declare abstract class CategoryMeasure extends Measure {
}
