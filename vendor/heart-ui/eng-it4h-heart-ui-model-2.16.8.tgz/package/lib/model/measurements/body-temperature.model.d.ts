import { TemperatureUnit } from './units';
import { QuantitativeMeasure } from './quantitative-measure.model';
export declare class BodyTemperature extends QuantitativeMeasure {
    static TYPE: string;
    value: number;
    unit: TemperatureUnit;
    constructor(value?: number, unit?: TemperatureUnit);
    valueIn(asUnit?: TemperatureUnit): number;
}
