import { Versionable } from '../versionable.model';
import { QuantitativeMeasure } from './quantitative-measure.model';
export declare class StepCount extends QuantitativeMeasure implements Versionable {
    static TYPE: string;
    value: number;
    readonly unit = "";
    version: string;
    constructor(value?: number);
    supportVersion(): boolean;
}
