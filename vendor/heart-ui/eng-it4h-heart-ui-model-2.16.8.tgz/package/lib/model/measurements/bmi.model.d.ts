import { Height } from './height.model';
import { QuantitativeMeasure } from './quantitative-measure.model';
import { Weight } from './weight.model';
export declare class BMI extends QuantitativeMeasure {
    static TYPE: string;
    value: number;
    readonly unit: string;
    constructor(value?: number);
    valueIn(): number;
    toString(): string;
    static calculate(weight: Weight, height: Height): BMI;
}
