import { CategoryMeasure } from './category-measure.model';
export declare class LifeStyle extends CategoryMeasure {
    value: LifeStyle.LifeStyleCategory;
    constructor(value?: LifeStyle.LifeStyleCategory);
}
export declare namespace LifeStyle {
    enum LifeStyleCategory {
        SEDENTARY = "sedentary",
        POORLY_ACTIVE = "poorly_active",
        ACTIVE = "active",
        VERY_ACTIVE = "very_active",
        ATHLETIC = "athletic"
    }
    namespace LifeStyleCategory {
        function valueOf(type: string): LifeStyleCategory;
    }
}
