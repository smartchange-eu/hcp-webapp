export declare class EnergyExpenditure {
    value: number;
    readonly unit = "kcal";
    constructor(value?: number);
}
