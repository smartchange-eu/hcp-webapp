import { QuantitativeMeasure } from './quantitative-measure.model';
export declare class ChestPainQuestionnaire extends QuantitativeMeasure {
    static TYPE: string;
    value: number;
    constructor(value?: number);
}
