import { PercentageUnit } from './units';
import { QuantitativeMeasure } from './quantitative-measure.model';
export declare class SpO2 extends QuantitativeMeasure {
    static TYPE: string;
    value: number;
    unit: PercentageUnit;
    constructor(value?: number, unit?: PercentageUnit);
    valueIn(asUnit?: PercentageUnit): number;
}
