import { QuantitativeMeasure } from './quantitative-measure.model';
import { DiastolicBloodPressure, SystolicBloodPressure } from './';
export declare class BloodPressure extends QuantitativeMeasure {
    systolic?: SystolicBloodPressure;
    diastolic?: DiastolicBloodPressure;
    static TYPE: string;
    value: number;
    readonly unit: string;
    constructor(systolic?: SystolicBloodPressure, diastolic?: DiastolicBloodPressure);
    toString(): string;
}
