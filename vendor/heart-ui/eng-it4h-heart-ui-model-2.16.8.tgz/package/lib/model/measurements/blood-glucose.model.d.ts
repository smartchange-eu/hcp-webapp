import { ConcentrationUnit } from './units/concentration-unit.model';
import { QuantitativeMeasure } from './quantitative-measure.model';
import { FeedbackInAppTypeName } from '../feedback';
export declare class BloodGlucose extends QuantitativeMeasure {
    static TYPE: string;
    value: number;
    /**
     * Traccia se è stata anche assunta insulina o altro
     */
    insulin: BloodGlucose.DrugStatement;
    unit: ConcentrationUnit;
    measPoint: FeedbackInAppTypeName;
    max_BG_P1: number;
    max_BG_P2: number;
    max_BG_P3: number;
    max_BG_P4: number;
    max_BG_P5: number;
    max_BG_P6: number;
    max_BG_P7: number;
    constructor(value?: number, unit?: ConcentrationUnit, measPoint?: FeedbackInAppTypeName, insulin?: BloodGlucose.DrugStatement);
    valueIn(asUnit?: ConcentrationUnit): number;
    estimateMeasPoint(): void;
}
export declare namespace BloodGlucose {
    enum DrugStatement {
        TAKEN,
        NOT_TAKEN
    }
}
