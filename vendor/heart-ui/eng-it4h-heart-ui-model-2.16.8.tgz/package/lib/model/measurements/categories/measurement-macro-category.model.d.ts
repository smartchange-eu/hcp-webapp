import { MeasurementCategory } from './measurement-category.model';
export interface MeasurementMacroCategory {
    id: string;
    image: string;
    type: string;
    categories: MeasurementCategory[];
}
