import { MeasurementTypeDescription } from './measurement-type-description.model';
export interface MeasurementCategory {
    id: string;
    label: string;
    types: MeasurementTypeDescription[];
    image: string;
    multiUnit: string;
}
