export interface MeasurementTypeDescription {
    unit: string;
    labelCode: string;
    class: any;
    mandatory: boolean;
    multiUnit: string;
}
