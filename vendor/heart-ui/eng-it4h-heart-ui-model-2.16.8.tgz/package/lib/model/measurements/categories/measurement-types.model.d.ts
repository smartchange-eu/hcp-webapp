import { MeasurementMacroCategory } from './measurement-macro-category.model';
export interface MeasurementTypes {
    disease: string;
    macrocategories: MeasurementMacroCategory[];
}
