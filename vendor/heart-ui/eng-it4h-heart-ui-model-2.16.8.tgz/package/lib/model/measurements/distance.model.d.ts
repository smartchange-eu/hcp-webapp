import { LengthUnit } from './units';
export declare class Distance {
    value: number;
    unit: LengthUnit;
    constructor(value?: number, unit?: LengthUnit);
    valueIn(asUnit?: LengthUnit): number;
}
