import { QuantitativeMeasure } from './quantitative-measure.model';
export declare class HeartRate extends QuantitativeMeasure {
    static TYPE: string;
    value: number;
    readonly unit = "bpm";
    constructor(value?: number);
}
