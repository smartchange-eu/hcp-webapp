export declare class ChromosomePosition {
    start?: number[];
    end?: number[];
    exon?: string;
}
