import { CodedValue } from "../../coded-value.model";
import { Measure } from "../measure.model";
export declare class Haplotype extends Measure {
    resourceType: string;
    gene: CodedValue;
    value: string;
    constructor(id: number);
}
