import { CodedValue } from "../../coded-value.model";
import { Measure } from "../measure.model";
export declare class TherapeuticImplication extends Measure {
    resourceType: string;
    relatedGenomicVariantId: number | string;
    actionable: CodedValue[];
    evidenceLevel?: CodedValue;
    constructor(id: number);
}
