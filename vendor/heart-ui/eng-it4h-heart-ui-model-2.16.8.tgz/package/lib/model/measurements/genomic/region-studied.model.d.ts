import { CodedValue } from "../../coded-value.model";
import { Measure } from "../measure.model";
export declare class RegionStudied extends Measure {
    private static PREFIX;
    resourceType: string;
    gene: CodedValue;
    value: string;
    constructor(id: number);
    simplifiedRegionStudied(): string;
}
