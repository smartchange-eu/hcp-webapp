import { CodedValue } from "../../coded-value.model";
import { Measure } from "../measure.model";
import { Haplotype } from "./haplotype.model";
import { RegionStudied } from "./region-studied.model";
export declare class Genotype extends Measure {
    resourceType: string;
    gene: CodedValue;
    value: string;
    region: RegionStudied;
    haplotypes: Haplotype[];
    constructor(id: number);
}
