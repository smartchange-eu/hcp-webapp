import { Shareable } from "../../shareable.model";
import { VcfMetadata } from "./vcf-metadata.model";
export declare class Study extends Shareable {
    resourceType: string;
    vcfsMeta: VcfMetadata[];
}
