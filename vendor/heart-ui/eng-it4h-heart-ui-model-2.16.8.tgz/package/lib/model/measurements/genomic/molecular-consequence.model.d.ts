import { CodedValue } from "../../coded-value.model";
import { Measure } from "../measure.model";
export declare class MolecularConsequence extends Measure {
    resourceType: string;
    relatedGenomicVariantId: number | string;
    codingChange?: CodedValue;
    proteinChange?: CodedValue;
    transcriptRefSeq?: CodedValue;
    featureConsequences: CodedValue[];
    constructor(id: number);
}
