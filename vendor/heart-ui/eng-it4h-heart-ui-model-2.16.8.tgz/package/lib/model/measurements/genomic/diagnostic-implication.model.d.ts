import { CodedValue } from "../../coded-value.model";
import { Measure } from "../measure.model";
import { Significance } from "./significance.model";
export declare class DiagnosticImplication extends Measure {
    resourceType: string;
    relatedGenomicVariantId: number | string;
    clinVar: Significance;
    acmg: Significance;
    CADD: number;
    predictedPhenotype: CodedValue[];
    functionalEffect: CodedValue;
    constructor(id: number);
}
