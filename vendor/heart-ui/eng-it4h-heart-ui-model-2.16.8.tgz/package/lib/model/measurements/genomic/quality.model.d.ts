export declare class Quality {
    allelicReadDepth: number;
    totalReadDepth: number;
    sampleAllelicFrequency: number;
    allelicBalance: number;
    refAllelicReadDepth: number;
    constructor(allelicReadDepth: number, totalReadDepth?: number, sampleAllelicFrequency?: number);
}
