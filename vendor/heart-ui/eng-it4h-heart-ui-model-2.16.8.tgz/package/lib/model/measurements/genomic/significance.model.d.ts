import { CodedValue } from "../../coded-value.model";
export declare class Significance {
    significance?: CodedValue;
    evidenceLevel?: CodedValue;
}
