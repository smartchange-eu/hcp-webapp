import { Shareable } from "../../shareable.model";
import { GenomicVariant } from "./genomic-variant.model";
export declare class Vcf extends Shareable {
    resourceType: string;
    variants: GenomicVariant[];
}
