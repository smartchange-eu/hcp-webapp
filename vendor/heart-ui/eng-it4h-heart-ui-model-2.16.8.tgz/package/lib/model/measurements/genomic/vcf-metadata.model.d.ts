import { CodedValue } from "../../coded-value.model";
import { Shareable } from "../../shareable.model";
export declare class VcfMetadata extends Shareable {
    resourceType: string;
    id: number;
    specimen: CodedValue;
    sequencing: CodedValue;
    date: Date;
    diagnosticReportReferenceId: string;
    cramReportReferenceId: string;
}
