import { CodedValue } from '../coded-value.model';
export declare class NutritionItem {
    /**
     * Represents the NutritionIntake.consumedItem.
     * The following parameters from this backbone element are visualized in the web app:
     * 1. nutritionProduct
     * 2. amount.value
     * 3. amount.unit, which can be either: {number per day, number per week}
     */
    product: CodedValue;
    quantity: number;
    unit: CodedValue;
    type: CodedValue;
}
