import { Patient } from '../actor';
import { Shareable } from '../shareable.model';
import { NutritionItem } from './nutrition-item.model';
export declare class Nutrition extends Shareable {
    readonly resourceType: string;
    items: NutritionItem[];
    date: Date;
    patient: Patient;
}
