import { QuantitativeMeasure } from '../measurements/quantitative-measure.model';
import { QuantitativeTarget } from '../goal/quantitative-target.model';
import { Target } from '../goal/target.model';
export declare class Stats {
    last: QuantitativeMeasure;
    worst: QuantitativeMeasure;
    target: Target;
    image?: string;
    judg?: number;
    reached: boolean;
    min: number;
    max: number;
    lastValue: number;
    operator: QuantitativeTarget.RelationalOperator;
    constructor(last: QuantitativeMeasure, target: Target, worst?: QuantitativeMeasure);
    toString(): string;
    judge(): void;
}
