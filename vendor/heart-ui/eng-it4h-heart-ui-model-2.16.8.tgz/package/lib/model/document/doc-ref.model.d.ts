import { CodedValue } from "../coded-value.model";
export declare class DocRef {
    readonly resourceType: string;
    subjectId: number;
    type: CodedValue;
    date: Date;
    constructor(subjectId: number, type: CodedValue, date: Date);
}
