export interface Versionable {
    version: string;
    supportVersion(): boolean;
}
