import { HealthCareProfessional, Organization, Patient } from '../actor';
import { Diagnosis } from '../conditions';
import { EncounterStatus, EncounterQuestionnaire, EncounterType } from '../enumeration';
import { Measure } from '../measurements';
import { ClinicalNote } from '../messages';
import { ExamPrescription } from '../prescription/exam-prescription.model';
import { QuestionnaireResponse } from '../questionnaires';
import { Shareable } from '../shareable.model';
export declare class Encounter extends Shareable {
    readonly resourceType: string;
    startDate: Date;
    closingDate?: Date;
    patient?: Patient;
    participant?: HealthCareProfessional;
    serviceProvider?: Organization;
    type?: EncounterType;
    private questionnaires;
    private otherQuestionnaires;
    diagnosis?: Diagnosis[];
    physical_examination?: Measure[];
    therapy_prescr?: any;
    exam_prescr?: ExamPrescription[];
    notes?: ClinicalNote[];
    diagn_report?: any;
    administration?: any;
    procedures?: any;
    get status(): EncounterStatus;
    setQuestionnaire(type: EncounterQuestionnaire, qr: QuestionnaireResponse): void;
    /**
     * gets the questionnaire response associated to the Encounter
     * @param type get a predefined qestionnaire by type
     * @param url of a non-standard questionnaire (EncounterQuestionnaire must be OTHER)
     * @returns a QuestionnaireResponse, if available
     */
    getQuestionnaire(type: EncounterQuestionnaire, url?: string): QuestionnaireResponse | undefined;
    get anamn_prox(): QuestionnaireResponse;
    get anamn_rem(): QuestionnaireResponse;
    get anamn_fisio(): QuestionnaireResponse;
    get anamn_fam(): QuestionnaireResponse;
    set anamn_prox(qr: QuestionnaireResponse);
    set anamn_rem(qr: QuestionnaireResponse);
    set anamn_fisio(qr: QuestionnaireResponse);
    set anamn_fam(qr: QuestionnaireResponse);
}
