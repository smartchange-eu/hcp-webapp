import { HealthCareProfessional, Organization, Patient } from "../actor";
import { HealthService, EpisodeStatus } from "../enumeration";
import { Shareable } from "../shareable.model";
import { Encounter } from "./encounter.model";
export declare class Episode extends Shareable {
    readonly resourceType: string;
    patient: Patient;
    careManager: HealthCareProfessional;
    type: HealthService;
    managingOrganization?: Organization;
    openingDate: Date;
    closingDate?: Date;
    encounter: Encounter[];
    get status(): EpisodeStatus;
}
