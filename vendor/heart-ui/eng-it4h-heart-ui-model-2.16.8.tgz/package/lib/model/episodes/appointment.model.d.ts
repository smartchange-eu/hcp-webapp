import { HealthCareProfessional, Patient } from '../actor';
import { AppointmentStatus, EncounterType } from '../enumeration';
import { Shareable } from '../shareable.model';
export declare class Appointment extends Shareable {
    resourceType: string;
    patient?: Patient;
    participant?: HealthCareProfessional;
    type: EncounterType;
    status: AppointmentStatus;
    note: string;
    start: Date;
    end: Date;
}
