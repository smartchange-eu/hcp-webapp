import { QuestionEnableWhenCondition } from "./question-enable-when-condition.model";
export declare class QuestionEnableWhen {
    behaviour?: 'all' | 'any';
    conditions: QuestionEnableWhenCondition[];
}
