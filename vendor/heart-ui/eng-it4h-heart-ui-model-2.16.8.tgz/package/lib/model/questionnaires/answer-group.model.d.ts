import { Answer } from "./answer.model";
/**
 * Model a structured group of questionnaire answers (see QuestionnaireResponse Item)
 */
export declare class AnswerGroup {
    readonly resourceType: string;
    groupId: string;
    answers: (Answer | AnswerGroup)[];
    /**
     * Alias of 'groupId'
     */
    get questionId(): string;
    answersByQuestionId(groupId: string): (AnswerGroup | Answer)[];
}
