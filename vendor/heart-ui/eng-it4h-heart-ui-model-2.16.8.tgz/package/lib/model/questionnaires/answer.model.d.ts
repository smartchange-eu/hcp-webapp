import { CodedValue } from "../coded-value.model";
/**
 * The Answer model the basic answer item that can be assigned to a Questionnaire question item
 */
export declare class Answer {
    readonly resourceType: string;
    questionId: string;
    value: CodedValue | CodedValue[] | number | string | boolean | Date;
    answers: Answer[];
    answersByQuestionId(groupId: string): Answer[];
}
