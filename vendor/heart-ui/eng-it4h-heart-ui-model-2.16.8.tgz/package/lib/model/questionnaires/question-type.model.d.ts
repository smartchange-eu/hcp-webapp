export declare enum QuestionType {
    boolean = 0,
    integer = 1,
    decimal = 2,
    text = 3,
    string = 4,
    CodedValue = 5,
    date = 6,
    display = 7
}
