import { AbstractQuestion } from "./abstract-question.model";
import { Question } from "./question.model";
export declare class QuestionGroup extends AbstractQuestion {
    readonly resourceType: string;
    groupId: string;
    /**
     * @deprecated
     */
    set name(name: string);
    /**
     * @deprecated
     */
    get name(): string;
    /**
     * @deprecated
     */
    get questionId(): string;
    /**
     * @deprecated
     */
    set questionId(questionId: string);
    /**
     * Indicate if the current group of questions can be repeated
     */
    repeated?: boolean;
    items: (Question | QuestionGroup)[];
    /**
     * Used to indicate if there is any sub question that is mandatory -> so the star should be rendered also in the father's title
     * THIS DOES NOT IMPACT THE FORM VALIDATOR - it's only for usability purpose
     */
    showSubStar: boolean;
}
