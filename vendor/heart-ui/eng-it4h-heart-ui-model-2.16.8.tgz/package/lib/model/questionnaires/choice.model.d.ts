import { CodedValue } from "../coded-value.model";
export declare class Choice {
    value: CodedValue | number | string | Date;
    label: string;
    constructor(value: CodedValue | number | string | Date, label?: string);
    getLabel(): string;
    private generateLabel;
}
