import { CareGiver, HealthCareProfessional, Patient } from "../actor";
import { Shareable } from "../shareable.model";
import { AnswerGroup } from "./answer-group.model";
import { Answer } from "./answer.model";
import { Questionnaire } from "./questionnaire.model";
export declare class QuestionnaireResponse extends Shareable {
    readonly resourceType: string;
    status: ResponseStatus;
    questionnaire: Questionnaire;
    questionnaireUrl: string;
    subject: Patient;
    author: HealthCareProfessional;
    source: Patient | CareGiver;
    /**
     * Authored date of the questionnaire response. It is the date of the last editing
     */
    date: Date;
    answers: (Answer | AnswerGroup)[];
    constructor(q: Questionnaire);
    answersByQuestionId(groupId: string): AnswerGroup[];
}
export declare enum ResponseStatus {
    inprogress = "in-progress",
    completed = "completed",
    amended = "amended",
    enteredinerror = "entered-in-error",
    stopped = "stopped"
}
export declare namespace ResponseStatus {
    function valueOf(type: string): ResponseStatus;
}
