import { CodedValue } from "../coded-value.model";
import { QuestionEnableWhen } from "./question-enable-when.model";
export declare abstract class AbstractQuestion {
    prefix: string;
    code: CodedValue;
    /**
     * Indicate if this group required
     */
    required: boolean;
    enableWhen?: QuestionEnableWhen;
    readOnly: boolean;
    text: string;
}
