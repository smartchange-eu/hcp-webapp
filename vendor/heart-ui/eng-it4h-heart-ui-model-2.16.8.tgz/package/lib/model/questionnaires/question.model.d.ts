import { AbstractQuestion } from "./abstract-question.model";
import { Choice } from "./choice.model";
import { QuestionType } from "./question-type.model";
export declare class Question extends AbstractQuestion {
    readonly resourceType: string;
    questionId: string;
    type: QuestionType;
    min: number;
    max: number;
    maxLength: number;
    permittedAnswers?: Choice[] | string;
    multiChoice: boolean;
    items?: Question[];
    hasClosedAnswer(): boolean;
}
