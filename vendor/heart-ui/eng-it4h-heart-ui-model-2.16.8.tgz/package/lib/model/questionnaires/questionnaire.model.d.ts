import { Shareable } from "../shareable.model";
import { QuestionGroup } from "./question-group.model";
import { Question } from "./question.model";
export declare class Questionnaire extends Shareable {
    readonly resourceType: string;
    /**
     * In FHIR the Questionnaire ID is the URL used as 'canonical' datatype
     */
    questionnaireId: string;
    /**
     * Name for this questionnaire (human friendly)
     */
    title: string;
    /**
     * Name for this questionnaire (computer friendly)
     */
    name: string;
    /**
     * Questions and sections within the Questionnaire
     */
    items: (Question | QuestionGroup)[];
    constructor(questionnaireId: string, items?: (Question | QuestionGroup)[]);
}
