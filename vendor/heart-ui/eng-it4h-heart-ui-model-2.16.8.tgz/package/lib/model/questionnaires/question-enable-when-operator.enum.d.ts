export declare enum QuestionEnableWhenOperator {
    EXISTS = 0,
    EQ = 1,
    NE = 2,
    GT = 3,
    GE = 4,
    LT = 5,
    LE = 6
}
