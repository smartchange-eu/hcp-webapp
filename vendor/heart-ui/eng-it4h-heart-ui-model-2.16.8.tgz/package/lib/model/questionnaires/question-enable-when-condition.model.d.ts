import { CodedValue } from "../coded-value.model";
import { QuestionEnableWhenOperator } from "./question-enable-when-operator.enum";
export declare class QuestionEnableWhenCondition {
    question: string;
    operator: QuestionEnableWhenOperator;
    answer: string | boolean | number | CodedValue | Date;
}
