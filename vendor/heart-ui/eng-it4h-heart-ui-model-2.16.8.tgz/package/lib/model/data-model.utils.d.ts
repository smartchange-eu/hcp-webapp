export declare class DataModelUtils {
    static loadClassByTypeName(resourceType: string): any;
    static attributeRevive(item: any, reviveCallback: (o: any) => any): any;
}
