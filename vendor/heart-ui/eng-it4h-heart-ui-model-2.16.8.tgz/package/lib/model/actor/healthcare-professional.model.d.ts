import { Person } from './person.model';
export declare class HealthCareProfessional extends Person {
    readonly resourceType: string;
    pseudonym: string;
    static revive(json: any): HealthCareProfessional;
}
