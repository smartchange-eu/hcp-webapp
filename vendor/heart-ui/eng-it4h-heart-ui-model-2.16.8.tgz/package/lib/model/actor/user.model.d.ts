import { Patient } from './patient.model';
import { HealthCareProfessional } from './healthcare-professional.model';
import { Locale, Role } from './../enumeration';
export declare class User {
    readonly resourceType: string;
    id?: number;
    username: string;
    /**
     * (Optional) the password should be used only while creatin the user credentials.
     *
     * IMPORTANT: if the user is deserializing server data the password field will always be empty
     */
    password?: string;
    /**
     * It indicates that the user will be forced to reset the current password as soon as they log-in the system.
     * so the current password is 'temporary'
     *
     * (Optional) the password should be used only while creatin the user credentials. so this attribute should be used only together with the password
     *
     * IMPORTANT: if the user is deserializing server data the password field will always be empty
     */
    temporaryPassword?: boolean;
    /**
     * If 'false' it specifies that the registration email requires a validation process.
     * Otherwise if 'true'.
     *
     * It is used only during the registration of a user.
     *
     * Default value: false
     */
    emailVerified?: boolean;
    /**
     * The 'person' contains the sensitive data and the roles of the current user. It is mandatory
     */
    person: HealthCareProfessional | Patient;
    /**
     * Indicates if the user is currently logged in the system
     */
    logged: boolean;
    /**
     * Indicates if the user is currently enabled or disabled in the system
     *
     * Disabled users must not be able to authenticate themselves
     */
    enabled: boolean;
    /**
     * Locale used by the user for localization purposes.
     *
     * In case the identity provider supports the locale management the same information
     * should also be available in the token
     *
     */
    locale?: Locale;
    /**
     * Date indicating the last time the user has been updated. It should be valorized server-side
     */
    lastUpdate?: Date;
    badges?: Map<string, number>;
    constructor(value?: {
        id?: number;
        username?: string;
        person?: HealthCareProfessional | Patient;
        logged?: boolean;
        enabled?: boolean;
        lastUpdate?: Date;
        badges?: Map<string, number>;
        password?: string;
        temporaryPassword?: boolean;
        emailVerified?: boolean;
    });
    /**
     * Set of roles assigned to the user. The actual role list is in the 'person' attribute so this is a logical list.
     */
    get roles(): Role[];
    static revive(json: any): User;
}
