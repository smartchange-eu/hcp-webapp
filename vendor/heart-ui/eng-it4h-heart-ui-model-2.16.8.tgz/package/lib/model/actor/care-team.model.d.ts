import { CareTeamStatus } from '../enumeration';
import { Shareable } from '../shareable.model';
import { CareGiver } from './care-giver.model';
import { HealthCareProfessional } from './healthcare-professional.model';
import { Organization } from './organization.model';
import { Patient } from './patient.model';
export declare class CareTeam extends Shareable {
    readonly resourceType: string;
    patient: Patient;
    organization?: Organization;
    healthcareProfessionals?: HealthCareProfessional[];
    caregiver?: CareGiver;
    status: CareTeamStatus;
    isWholeOrganizationEnabled(): boolean;
}
