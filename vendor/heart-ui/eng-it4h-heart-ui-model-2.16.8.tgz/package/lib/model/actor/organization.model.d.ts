import { Shareable } from '../shareable.model';
export declare class Organization extends Shareable {
    id?: number;
    name?: string;
    readonly resourceType: string;
    constructor(id?: number, name?: string);
    static revive(json: any): Organization;
}
