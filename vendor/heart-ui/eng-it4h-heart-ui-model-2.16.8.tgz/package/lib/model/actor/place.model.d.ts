export declare class Place {
    readonly resourceType: string;
    /**
     * Name of the city
     */
    city?: string;
    /**
     * Mandatory value to specify the country (e.g. Italy)
     */
    country: string;
    /**
     * Mandatory value to specify the state/(italian) region (e.g. Lazio)
     */
    state: string;
    /**
     * Human readable name of the Italian province.
     */
    district?: string;
    static revive(json: any): Place;
}
