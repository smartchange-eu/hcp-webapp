import { CodedValue } from '../coded-value.model';
import { Kinship } from './kinship.model';
import { Organization } from './organization.model';
import { PersonAddress } from './person-address.model';
import { Person } from './person.model';
import { Place } from './place.model';
export declare class Patient extends Person {
    readonly resourceType: string;
    taxCode?: string;
    birthPlace?: Place;
    /**
     * This is pseudonym added in the registration phase.
     * This will be present if the Patient does not have a system account
     */
    patientIdentifier?: string;
    /**
   * This is the pseudonym system code used by the server to model the pseudonym.
   */
    patientIdentifierSystem?: string;
    /**
     * backwards compatibility of the 'pseudonym' attribute
     *
     * @deprecated: use patientIdentifier instead
     */
    get pseudonym(): string;
    /**
     * @deprecated: use patientIdentifier instead
     */
    set pseudonym(pseudonym: string);
    /**
     * One liner to described the full address of the patient
     */
    domicile?: PersonAddress;
    residence?: PersonAddress;
    phoneNumber?: string;
    /**
     * NOTE if the patient is a User of the system the 'managingOrganization' value is managed by User.PersonRoles
     */
    managingOrganization?: Organization;
    presentAnalyses?: CodedValue[];
    relatives?: Kinship[];
    static revive(json: any | Patient): Patient;
    getCompleteIdentifier(): string;
}
