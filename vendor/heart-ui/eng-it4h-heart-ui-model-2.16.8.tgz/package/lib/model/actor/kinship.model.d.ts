import { CodedValue } from "../coded-value.model";
import { Patient } from "./patient.model";
export declare class Kinship {
    relative: Patient;
    relationship: CodedValue;
    relatedPersonId?: string;
    constructor(relative: Patient, relationship: CodedValue, relatedPersonId?: string);
}
