import { Patient } from './patient.model';
import { Shareable } from '../shareable.model';
import { CodedValue } from '../coded-value.model';
import { Gender } from '../enumeration';
export declare class CareGiver extends Shareable {
    readonly resourceType: string;
    patient: Patient;
    relationship: CodedValue;
    firstName: string;
    lastName: string;
    email?: string;
    gender: Gender;
    birthDate?: Date;
    alias: Patient;
    get name(): string;
    set name(r: string);
    get relationshipType(): string;
    set relationshipType(r: string);
}
