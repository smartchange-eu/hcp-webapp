export declare class Identifier {
    value: string;
    system: string;
    use: string;
    static revive(json: any): Identifier;
}
