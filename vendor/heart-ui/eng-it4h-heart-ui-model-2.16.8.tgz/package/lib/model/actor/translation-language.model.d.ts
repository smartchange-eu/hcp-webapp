import { Locale as FNSLocale } from 'date-fns';
import { Locale } from '../enumeration';
export interface TranslationLanguage {
    locale: Locale;
    display?: string;
    fnsAdapterLocale: FNSLocale;
    nativeAdapterLocale: string;
    subtranslateDicionary?: any;
}
