import { Role } from "../enumeration/role.enum";
import { Organization } from "./organization.model";
/**
 * This is an associtive class to link a Person with an Organization and a Role
 *
 * Noteworthy is that in case the Person is a Patient the only valid role is 'patient'
 */
export declare class PersonRole {
    organization: Organization;
    role: Role;
    constructor(organization: Organization, role: Role);
    static revive(json: any): PersonRole;
}
