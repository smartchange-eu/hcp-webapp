import { Place } from "./place.model";
/**
 * Person address is used to model domicile and residence addresses of a person
 */
export declare class PersonAddress extends Place {
    readonly resourceType: string;
    /**
     * The type is meant to express that a person address can be used as postal address and/or
     * as physical address
     */
    homeType?: PersonAddress.HomeType;
    /**
     * Full address (street and number)
     */
    line?: string;
    postalCode?: string;
    static revive(json: any): PersonAddress;
}
export declare namespace PersonAddress {
    enum HomeType {
        DOMICILE = "domicile",
        RESIDENCE = "residence"
    }
    namespace HomeType {
        function fromString(value: string): HomeType | undefined;
    }
}
