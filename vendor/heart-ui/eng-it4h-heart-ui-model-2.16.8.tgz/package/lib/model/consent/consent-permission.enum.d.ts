export declare enum ConsentPermission {
    INFA,
    INFAO,
    INFASO
}
