import { CareGiver } from './../actor/care-giver.model';
import { Organization, Patient, Person } from '../actor';
import { Shareable } from './../shareable.model';
import { ConsentPermission } from './consent-permission.enum';
export declare class PatientConsent extends Shareable {
    readonly resourceType: string;
    createdAt: Date;
    attachmentTitle: string;
    patientRef: Patient;
    performerRef: Person | CareGiver | Organization;
    readonly attachmentType: string;
    permissions: ConsentPermission[];
    contentDataId: string;
    static revive(json: any): PatientConsent;
}
