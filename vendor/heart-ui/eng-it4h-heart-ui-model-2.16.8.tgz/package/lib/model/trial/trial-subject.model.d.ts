import { Patient } from '../actor';
import { CodedValue } from '../coded-value.model';
import { Shareable } from '../shareable.model';
import { Trial } from './trial.model';
export declare class TrialSubject extends Shareable {
    resourceType: 'TrialSubject';
    study: Trial;
    patient: Patient;
    group: CodedValue;
}
