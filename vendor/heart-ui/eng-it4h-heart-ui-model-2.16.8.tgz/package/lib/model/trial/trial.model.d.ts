import { CodedValue } from '../coded-value.model';
import { Shareable } from '../shareable.model';
export declare class Trial extends Shareable {
    resourceType: 'Trial';
    url: string;
    region: CodedValue;
    groups: CodedValue[];
}
