export declare enum EncounterQuestionnaire {
    FAMILY_ANAMNESIS = "family-history",
    PATIENT_PHYSIOLOGICAL_HISTORY = "patient-physiological-history",
    PATIENT_SHORT_TERM_HISTORY = "short-term-pathological-history",
    REMOTE_ANAMNESIS = "long-term-pathological-history",
    HEALTH_HISTORY = "prevention-health-history",
    LIFESTYLE = "patient-lifestyle-nutrition",
    OTHER = "other"
}
export declare namespace EncounterQuestionnaire {
    function values(): EncounterQuestionnaire[];
    function valueOf(value: string): EncounterQuestionnaire;
}
