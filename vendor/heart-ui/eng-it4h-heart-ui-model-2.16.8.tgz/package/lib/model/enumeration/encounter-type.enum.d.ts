export declare enum EncounterType {
    ANNUAL_SCREENING = "annual-screening",
    FIRST_ENCOUNTER = "first-encounter",
    SCHOOL_CHECK = "school-check",
    PREVENTION_CAMPAIGN = "prevention-campaign",
    OTHER = "other"
}
export declare namespace EncounterType {
    function values(): EncounterType[];
    function convertFromString(string: string): EncounterType;
}
