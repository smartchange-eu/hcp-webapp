export declare enum EncounterStatus {
    INPROGRESS = "in-progress",
    COMPLETED = "completed"
}
export declare namespace EncounterStatus {
    function values(): EncounterStatus[];
    function convertFromString(string: string): EncounterStatus;
}
