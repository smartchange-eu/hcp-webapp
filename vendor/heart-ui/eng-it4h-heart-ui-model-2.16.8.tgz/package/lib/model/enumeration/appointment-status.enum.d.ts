export declare enum AppointmentStatus {
    PROPOSED = "proposed",
    PENDING = "pending",
    BOOKED = "booked",
    CANCELLED = "cancelled",
    FULFILLED = "fulfilled"
}
export declare namespace AppointmentStatus {
    function values(): AppointmentStatus[];
    function convertFromString(string: string): AppointmentStatus;
}
