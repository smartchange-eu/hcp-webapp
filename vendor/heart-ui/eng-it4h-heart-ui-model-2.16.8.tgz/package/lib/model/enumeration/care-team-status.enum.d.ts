export declare enum CareTeamStatus {
    PROPOSED = "proposed",
    ACTIVE = "active",
    SUSPENDED = "suspended",
    INACTIVE = "inactive"
}
export declare namespace CareTeamStatus {
    function values(): CareTeamStatus[];
    function convertFromString(string: string): CareTeamStatus;
}
