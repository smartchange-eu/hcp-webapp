export declare enum Gender {
    male,
    female,
    other,
    unknown
}
export declare namespace Gender {
    function fromString(gender: string): Gender;
}
