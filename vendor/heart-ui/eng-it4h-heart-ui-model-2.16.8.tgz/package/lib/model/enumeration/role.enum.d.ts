export declare class Role {
    static ADMIN: Role;
    static PRACTITIONER: Role;
    static RESEARCHER: Role;
    static PATIENT: Role;
    static GENETICIST: Role;
    static LAB_GENETICIST: Role;
    static RESEARCHER_GENETICIST: Role;
    static BIOINFORMATICIAN: Role;
    static NURSE: Role;
    /**
     * static array of project-scoped roles
     *
     * To add a new role you have to create a new role
     * and add it to the EXTRA array as soon as the app is loaded
     *
     */
    static EXTRA: Role[];
    readonly role: string;
    constructor(role: string);
    toString(): string;
    /**
     * Custom serialization of the enum. As this class is not a real enumeration this is needed to have the 'role' as string instead of an object
     *
     * @returns serialized roles
     */
    toJSON(): unknown;
    toStringUppercase(): string;
    static values(): Role[];
    /**
     *
     * @param roleString
     * @returns
     */
    static convertFromString(roleString: string): Role;
}
