export declare enum RiskLevel {
    NEGLIGIBLE = "negligible",
    LOW = "low",
    MODERATE = "moderate",
    HIGH = "high",
    CERTAIN = "certain"
}
export declare namespace RiskLevel {
    function values(): RiskLevel[];
    function convertFromString(string: string): RiskLevel;
}
