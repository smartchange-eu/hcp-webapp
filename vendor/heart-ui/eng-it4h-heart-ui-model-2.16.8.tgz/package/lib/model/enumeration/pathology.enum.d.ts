export declare enum Pathology {
    DIABETES_MELLITUS_TYPE_2 = "DIABETES_MELLITUS_TYPE_2",
    DMT2 = "DMT2",
    CANCER = "CANCER",
    CARDIOVASCULAR_DISEASE = "CARDIOVASCULAR_DISEASE",
    CVD = "CVD",
    CHRONIC_OBSTRUCTIVE_PULMONARY_DISEASE = "CHRONIC_OBSTRUCTIVE_PULMONARY_DISEASE",
    COPD = "COPD",
    ASTHMA = "ASTHMA",
    ALLERGY = "ALLERGY",
    HYPERTENSION = "HYPERTENSION",
    OTHER_DISORDER = "OTHER_DISORDER"
}
export declare namespace Pathology {
    function convertFromString(pathologyString: string): Pathology;
}
