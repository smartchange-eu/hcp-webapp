export declare enum HealthService {
    OUTPATIENT = "outpatient",
    HOSPITALIZATION = "hospitalization",
    DAY_HOSPITAL = "day_hospital"
}
export declare namespace HealthService {
    function values(): HealthService[];
    function convertFromString(string: string): HealthService;
}
