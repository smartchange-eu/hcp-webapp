export declare enum EpisodeStatus {
    ACTIVE = "active",
    FINISHED = "finished"
}
export declare namespace EpisodeStatus {
    function values(): EpisodeStatus[];
    function convertFromString(string: string): EpisodeStatus;
}
