export declare abstract class Shareable {
    id?: number;
    constructor(id?: number);
    get fhirId(): string;
    get healthId(): string;
    onLocalFramework?: boolean;
    abstract readonly resourceType: string;
}
