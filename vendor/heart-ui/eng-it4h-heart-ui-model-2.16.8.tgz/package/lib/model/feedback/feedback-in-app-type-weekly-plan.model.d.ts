import { FeedbackInAppType } from './feedback-in-app-type.model';
export declare class FeedbackTypeWeeklyPlan {
    day: FeedbackTypeWeekDays;
    points: FeedbackInAppType[];
    constructor(day: FeedbackTypeWeekDays, points?: FeedbackInAppType[]);
}
export declare enum FeedbackTypeWeekDays {
    MONDAY = 1,
    TUESDAY = 2,
    WEDNESDAY = 3,
    THURSDAY = 4,
    FRIDAY = 5,
    SATURDAY = 6,
    SUNDAY = 7
}
