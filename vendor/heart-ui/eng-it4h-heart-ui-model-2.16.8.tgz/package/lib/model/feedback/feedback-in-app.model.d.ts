import { FeedbackInAppType } from './feedback-in-app-type.model';
export declare class FeedbackInApp {
    id: number;
    type: FeedbackInAppType;
    scheduledFor: Date;
    status: FeedbackInAppStatus;
    titleKey: string;
    textKey: string;
    constructor(scheduledFor?: Date, type?: FeedbackInAppType, status?: FeedbackInAppStatus, titleKey?: string, textKey?: string);
    toString(): string;
    isEvicted(): boolean;
}
export declare enum FeedbackInAppTypeName {
    BG_P1,
    BG_P2,
    BG_P3,
    BG_P4,
    BG_P5,
    BG_P6,
    BG_P7,
    TTM,
    S_UX_QUESTIONNAIRE,
    MEAL_BREAKFAST,
    MEAL_LUNCH,
    MEAL_DINNER,
    PHYSICAL_ACTIVITY,
    HABITS_SMOKING,
    WEIGHT,
    REMINDER,
    INFORMATIVE,
    MOTIVATIONAL
}
export declare enum FeedbackInAppStatus {
    PENDING,
    SHOWN,
    DONE,
    DONOTFIRE
}
