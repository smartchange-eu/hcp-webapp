import { FeedbackInAppTypeName } from './../feedback/feedback-in-app.model';
import { FeedbackTypeWeekDays } from './feedback-in-app-type-weekly-plan.model';
declare type PeriodUnit = 'd' | 'h' | 'y';
declare type IntervalPeriodUnit = 'd' | 'h' | 'w';
export declare class FeedbackInAppType {
    name?: FeedbackInAppTypeName;
    intervalPeriodValue?: number;
    intervalPeriodUnit?: IntervalPeriodUnit;
    evictionPeriodValue?: number;
    evictionPeriodUnit?: PeriodUnit;
    notificationDay?: FeedbackTypeWeekDays;
    notificationHour?: number;
    notificationMinutes?: number;
    constructor(config?: FeedbackInAppType);
    toString(): string;
}
export {};
