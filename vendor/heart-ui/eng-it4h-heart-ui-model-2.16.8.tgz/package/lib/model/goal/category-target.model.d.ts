import { Target } from './target.model';
import { CategoryMeasureType } from '../measurements/valid-types';
import { CodedValue } from '../coded-value.model';
export declare class CategoryTarget implements Target {
    constructor(targetVariable?: CategoryMeasureType, thresholdValue?: string);
    targetCode: CodedValue;
    id: number;
    targetVariable: CategoryMeasureType;
    thresholdValue: string;
    classname: string;
    static revive(json: any): CategoryTarget;
    getReadable(): string;
    toString(): string;
}
