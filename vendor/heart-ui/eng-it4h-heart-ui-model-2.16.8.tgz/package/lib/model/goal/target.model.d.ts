import { CodedValue } from '../coded-value.model';
import { MeasureType } from '../measurements/valid-types';
export interface Target {
    id: number;
    targetVariable: MeasureType;
    targetCode: CodedValue;
    getReadable(): string;
}
