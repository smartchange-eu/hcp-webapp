import { Activity } from './activity.model';
import { FeedbackTypeWeeklyPlan } from '../feedback';
export declare class SMBGActivity extends Activity {
    profileName: string;
    comTypes: FeedbackTypeWeeklyPlan[];
}
