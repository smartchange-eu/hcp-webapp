export declare abstract class Activity {
    id: number;
    start: Date;
    end: Date;
}
