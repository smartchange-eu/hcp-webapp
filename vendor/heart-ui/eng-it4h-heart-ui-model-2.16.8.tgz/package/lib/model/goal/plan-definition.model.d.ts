import { Activity } from './activity.model';
import { Goal } from './goal.model';
import { Shareable } from '../shareable.model';
import { CodedValue } from '../coded-value.model';
export declare class PlanDefinition extends Shareable {
    readonly resourceType: string;
    status: PlanDefinition.PlanStatus;
    ageRange?: {
        min?: number;
        max?: number;
    };
    topic: PlanDefinition.PlanTopic;
    focus: CodedValue;
    goals: Goal[];
    activities: Activity[];
    toString(): string;
}
export declare namespace PlanDefinition {
    enum PlanStatus {
        UNKNOWN = 0,
        DRAFT = 1,
        ACTIVE = 2,
        RETIRED = 3
    }
    enum PlanTopic {
        EDUCATION = 0,
        TREATMENT = 1,
        ASSESSMENT = 2
    }
}
