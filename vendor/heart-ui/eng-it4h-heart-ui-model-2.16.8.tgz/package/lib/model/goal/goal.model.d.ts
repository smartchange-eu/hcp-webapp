import { Person, Patient } from '../actor';
import { Versionable } from '../versionable.model';
import { Measure } from '../measurements/measure.model';
import { Shareable } from '../shareable.model';
import { GoalInternalActivity } from './goal-internal-activity.model';
import { Target } from './target.model';
import { CodedValue } from '../coded-value.model';
export declare class Goal extends Shareable implements Versionable {
    readonly resourceType: string;
    createdOn?: Date;
    validatedOn?: Date;
    proposedOn?: Date;
    acceptanceDurationInDays?: number;
    acceptedOn?: Date;
    startedOn?: Date;
    endedOn?: Date;
    cancelledOn?: Date;
    durationInDays?: number;
    description?: string;
    /**
     * if omitted it is the current system
     */
    recommender?: Person;
    actuator?: Person;
    status: Goal.GoalStatus;
    /**set multiple targets. So Target is declared as array
    public target: Target;
    */
    targets: Target[];
    subject: Patient;
    /**
     * The goal that the current one is meant to replace
     *
     * Bi-directional relationship with 'replacement'
     */
    private _proposedReplacementOf?;
    /**
     * The goal that is meant to replace the current one
     *
     * Bi-directional relationship with 'proposedReplacementOf'
     */
    private _replacement?;
    /**
     * Set of measure originating the goal itself
     *
     * The current set is introduced, mainly, if the goal is not manually assigned (e.g. from the assessment manager)
     */
    causedBy?: Measure[];
    /**
     * Al momento stiamo usando font awesome... ma valuterei l'opzione icomoon
     */
    imageSrc: string;
    private _type;
    version: string;
    note: string;
    activities?: GoalInternalActivity[];
    milestones: Goal[];
    /**
     * Aggiunto dopo la riunione su richiesta di Francesco. Aggiunto anche nella kb_goals_definitions
     */
    summary: string;
    /** OLD CONSTRUCTOR - with a single target
     * public constructor(target?: Target, recommender?: Person) {
      super();
      this.target = target;
      this.recommender = recommender;
    }*/
    constructor(targets?: Target[], recommender?: Person);
    /**
     * La data di fine è calcolabile solo se:
     * i) esiste una durata
     * ii) è nota la data di inizio (i.e. il goal è in progress o planned)
     */
    getGoalEndDate(): Date;
    /**
     * La durata è calcolabile solo se:
     * ii) è nota la data di inizio (i.e. il goal è in progress o planned)
     */
    setGoalEndDate(d: Date): void;
    /**
     * La data di 'scadenza' è calcolabile solo se:
     * i) esiste un periodo di validità del goal
     * ii) è nota la data di proposizione (i.e. il goal è in progress o planned)
     */
    getAcceptanceEndDate(): Date;
    /**
     * READ: This goal has been replaced by <OTHER GOAL>
     */
    set proposedReplacementOf(g: Goal);
    get proposedReplacementOf(): Goal;
    /**
     * READ: This goal is a replacement (ie. is replacing) of <OTHER GOAL>
     */
    set replacement(g: Goal);
    get replacement(): Goal;
    get editedByPractitioner(): boolean;
    set type(type: CodedValue);
    get type(): CodedValue;
    /**
     * targets come array
     */
    toString(): string;
    /**
    * target singolo
    public toString(): string {
      return `Goal{[${this.id} - ${this.fhirId}/_history/${this.version}], type=${this._type}, status=${this.status}, target=${this.targets} recommender=${this.recommender}}`;
    }*/
    supportVersion(): boolean;
    findMilestoneByType(type: string, status?: Goal.GoalStatus): Goal;
    findMilestoneById(id: number): Goal;
    findMilestoneByFhirId(fhirId: string): Goal;
    /**
     * restituisce true se data attuale > della data finale getGoalEndedDate
     */
    isGoalEnded(): boolean;
    /**
     *
     * restituisce la percentuale di tempo trascorso tra la data di creazione goal e la acceptance duration max date.
     *
     *  1 - goal non può essere più accettato
     *  <1 - goal ancora accettabile
     *
     * se la getAcceptanceEndDate non c'è restituirà -1
     * se la proposedOn non c'è restituirà -1
     *
     */
    getAcceptanceDurationCompletionPercentage(): number;
    /**
     * revive su target come array
     */
    static revive(json: any, onlyEnabled?: boolean): Goal;
}
export declare namespace Goal {
    enum GoalStatus {
        UNKNOWN = 0,
        ACHIEVED = 1,
        CANCELLED = 2,
        FAILED = 3,
        NOT_ACCEPTED = 4,
        ACTIVE = 5,
        CANDIDATE_FOR_PROPOSAL = 6,
        PROPOSED = 7,
        NOT_APPROVED = 8,
        REJECTED = 9,
        PLANNED = 10
    }
}
