import { Person } from '../actor';
export declare class Note {
    author: Person;
    createdOn: Date;
    value: string;
    constructor(author: Person, note: string);
}
