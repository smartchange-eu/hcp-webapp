import { QuantitativeMeasureType } from '../measurements/valid-types';
import { TargetQuantity } from './target-quantity.model';
import { Target } from './target.model';
import { CodedValue } from '../coded-value.model';
export declare class RangeTarget implements Target {
    constructor(targetVariable?: QuantitativeMeasureType, minThresholdValue?: TargetQuantity, maxThresholdValue?: TargetQuantity);
    targetCode: CodedValue;
    id: number;
    targetVariable: QuantitativeMeasureType;
    minThresholdValue?: TargetQuantity;
    maxThresholdValue?: TargetQuantity;
    classname: 'RangeTarget';
    static revive(json: any): RangeTarget;
    getReadable(): string;
    toString(): string;
}
