import { QuantitativeMeasureType } from '../measurements/valid-types';
import { TargetQuantity } from './target-quantity.model';
import { Target } from './target.model';
import { CodedValue } from '../coded-value.model';
export declare class QuantitativeTarget implements Target {
    constructor(targetVariable?: QuantitativeMeasureType, thresholdValue?: TargetQuantity, operator?: QuantitativeTarget.RelationalOperator);
    targetCode: CodedValue;
    id: number;
    targetVariable: QuantitativeMeasureType;
    thresholdValue: TargetQuantity;
    operator: QuantitativeTarget.RelationalOperator;
    classname: string;
    static revive(json: any): QuantitativeTarget;
    getReadable(): string;
    toString(): string;
}
export declare namespace QuantitativeTarget {
    enum RelationalOperator {
        LT,
        LE,
        GT,
        GE,
        EQ
    }
}
