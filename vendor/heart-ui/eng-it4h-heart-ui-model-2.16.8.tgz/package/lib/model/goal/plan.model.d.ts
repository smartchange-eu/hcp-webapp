import { Activity } from './activity.model';
import { Goal } from './goal.model';
import { HealthCareProfessional } from '../actor/healthcare-professional.model';
import { Shareable } from '../shareable.model';
import { Condition } from '../conditions/condition.model';
import { Note } from './note.model';
import { Patient } from '../actor';
import { CodedValue } from '../coded-value.model';
export declare class Plan extends Shareable {
    readonly resourceType: string;
    status: Plan.PlanStatus;
    patient: Patient;
    category: CodedValue;
    author: HealthCareProfessional;
    goals: Goal[];
    activities: Activity[];
    motivation: Condition[];
    start: Date;
    due: Date;
    therapeuticNotes: Note[];
    toString(): string;
    /**
     * It looks for the goal instance by navigating the hierarchy of goals
     */
    lookupGoalById(id: number): Goal;
    /**
     * It looks for the goal instance by navigating the hierarchy of goals
     */
    lookupGoalByFhirId(fhirId: string): Goal;
    getMilestones(): Goal[];
    getMilestonesInProgress(): Goal[];
}
export declare namespace Plan {
    enum PlanStatus {
        UNKNOWN = 0,
        DRAFT = 1,
        ACTIVE = 2,
        ON_HOLD = 3,
        REVOKED = 4,
        COMPLETED = 5,
        ENTERED_IN_ERROR = 6
    }
}
