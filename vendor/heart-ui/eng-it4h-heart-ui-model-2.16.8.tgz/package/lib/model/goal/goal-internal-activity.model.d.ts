/**
 * This class is used to model the activities required for a specific procedure
 *
 * They are just text (at most there is a number to quantify them)
 */
export declare class GoalInternalActivity {
    id: number;
    label: string;
    /**
     * The value is an optional attibute used for the activities requiring tuning
     *
     * The attribute doesn't have a 'unit'
     */
    value?: number;
    enabled: boolean;
    toString(): string;
    static revive(json: any): GoalInternalActivity;
}
