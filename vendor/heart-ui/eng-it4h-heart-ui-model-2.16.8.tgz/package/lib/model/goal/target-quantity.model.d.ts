export declare class TargetQuantity {
    magnitude: number;
    /**
     * TODO: occore capire come definire li tipo dell'unità di misura.
     * Usare string o le enum o entrambe?
     */
    unit: string;
    system: string;
    constructor(magnitude: number, unit?: string, system?: string);
    toString(): string;
    static revive(json: any): TargetQuantity;
}
