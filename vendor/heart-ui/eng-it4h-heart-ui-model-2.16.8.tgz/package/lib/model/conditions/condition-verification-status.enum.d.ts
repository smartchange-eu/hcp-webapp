export declare enum ConditionVerificationStatus {
    PROVISIONAL = "provisional",
    CONFIRMED = "confirmed",
    REFUSED = "refused"
}
export declare namespace ConditionVerificationStatus {
    function values(): ConditionVerificationStatus[];
    function valueOf(value: string): ConditionVerificationStatus;
}
