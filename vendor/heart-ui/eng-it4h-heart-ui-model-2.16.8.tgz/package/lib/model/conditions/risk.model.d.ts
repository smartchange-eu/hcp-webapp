import { Patient } from '../actor';
import { CodedValue } from '../coded-value.model';
import { RiskLevel } from '../enumeration/risk-level.enum';
import { Shareable } from '../shareable.model';
export declare class Risk extends Shareable {
    readonly resourceType: string;
    patient: Patient;
    /**
     * @alias patient
     */
    set subject(subject: Patient);
    get subject(): Patient;
    /**
     * when the risk was computed
     */
    date: Date;
    mitigation: string;
    predictions: Risk.Prediction[];
}
export declare namespace Risk {
    class Prediction {
        /**
         * Standard value code describing the predicted outcome
         */
        code: CodedValue;
        range: {
            min: number;
            max: number;
        };
        level: RiskLevel;
        minAge: number;
        maxAge: number;
        get age(): number;
        get probability(): number;
        set probability(p: number);
    }
}
