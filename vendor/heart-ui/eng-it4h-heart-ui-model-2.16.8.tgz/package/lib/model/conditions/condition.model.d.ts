import { HealthCareProfessional, Patient } from "../actor";
import { CodedValue } from "../coded-value.model";
import { Encounter } from "../episodes";
import { Shareable } from "../shareable.model";
import { ConditionClinicalStatus } from "./condition-clinical-status.enum";
import { ConditionVerificationStatus } from "./condition-verification-status.enum";
export declare abstract class Condition extends Shareable {
    readonly resourceType: string;
    patient: Patient;
    /**
     * @alias patient
     */
    set subject(subject: Patient);
    get subject(): Patient;
    author: HealthCareProfessional;
    onsetDate: Date;
    abatementDate: Date;
    encounter: Encounter;
    /**
     * Standard value code describing the clinical diagnosis
     */
    code: CodedValue;
    /**
     * specify the status of the diagnosis (i.e. is it provisional or confirmed?)
      */
    verificationStatus: ConditionVerificationStatus;
    /**
     * specify the clinical status of the patient
     */
    clinicalStatus: ConditionClinicalStatus;
    /**
     * Clinical note about the diagnosis
     */
    note: string;
}
