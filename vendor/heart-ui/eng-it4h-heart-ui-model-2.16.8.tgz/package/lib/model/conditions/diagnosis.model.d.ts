import { DiagnosisType } from "./diagnosis-type.enum";
import { Condition } from "./condition.model";
export declare class Diagnosis extends Condition {
    /**
     * specify if the diagnosis has been created in laboratory, clinical, ... context
     *
     * NOTE: This is NOT the FHIR category!!!
     */
    types: DiagnosisType[];
}
