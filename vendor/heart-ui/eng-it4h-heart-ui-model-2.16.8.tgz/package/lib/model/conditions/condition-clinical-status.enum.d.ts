export declare enum ConditionClinicalStatus {
    ACTIVE = "active",
    RESOLVED = "resolved",
    REMISSION_IN_THERAPY = "remission-in-therapy",
    REMISSION_OFF_THERAPY = "remission-off-therapy",
    UNKNOWN = "unknown"
}
export declare namespace ConditionClinicalStatus {
    function values(): ConditionClinicalStatus[];
    function valueOf(value: string): ConditionClinicalStatus;
}
