export declare enum DiagnosisType {
    CLINICAL = "clinical",
    GENETIC = "genetic",
    HISTOLOGICAL = "histological",
    LABOATORY = "laboratory"
}
export declare namespace DiagnosisType {
    function values(): DiagnosisType[];
    function valueOf(value: string): DiagnosisType;
}
