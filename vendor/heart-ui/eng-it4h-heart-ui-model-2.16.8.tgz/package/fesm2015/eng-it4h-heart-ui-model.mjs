import { addYears, addDays, addHours, isBefore, differenceInCalendarYears, subYears, endOfYear, getHours, differenceInMinutes, isSameDay } from 'date-fns';

class LogConf {
}
LogConf.NOT_LOGGED = 'NotLoggedUser';
// OPERAZIONI da loggare
LogConf.OP_VIEW_CREATED = 'ViewCreated'; // evento di creazione nuova vista
LogConf.OP_ELEMENT_TAPPED = 'ElementTapped'; // evento di tap su un elemento grafico (pulsante, ...) ma sono escluse le notifiche di sistema
LogConf.OP_SYSTEM_NOTIFICATION_TAPPED = 'SystemNotificationTapped'; // evento di tap su una notifica di sistema
LogConf.OP_SYSTEM_EVENT = 'SystemEvent'; // caratterizza gli eventi di sistema
LogConf.OP_NO_OPERATION = 'NoOperation'; // valore di 'default' usato nel caso in cui non ci sia un'interazione specifica
LogConf.OP_DONE = 'Done'; // tap sul bottono 'Fatto'
LogConf.OP_LATER = 'Later'; // tap sul bottono 'Lo faccio dopo'
LogConf.OP_MSG_PRODUCED = 'MsgProduced'; // evento di produzione e salvataggio (lato telefono) di un messaggio
LogConf.OP_MSG_COMM_SCHEDULED = 'MsgScheduled'; // evento di schedulazione (lato telefono) di una comunicazione come local notification
LogConf.OP_MSG_COMM_REMOVED = 'MsgRemoved'; // evento di schedulazione (lato telefono) di una comunicazione da local notification
LogConf.OP_DATA_CHECKING = 'DataChecking'; // evento di checking della presenza dei dati (e.g. Measure/Meal) per la schedulazione delle notifiche
LogConf.OP_COMM_CREATED = 'CommCreated'; // evento di creazione di Communication -> Non implica lo scheduling della Local notification
LogConf.OP_TTM_EVALUATION = 'TTMEvaluation'; // evento durante la valutazione del TTM
LogConf.OP_WARNING = 'Warning'; // evento di warning (es: inserimento misure non valide)
LogConf.OP_PROGRESS_EVALUATION = 'ProgressEvaluation'; // evento durante la valutazione dei progressi dell'utente
LogConf.OP_VIEW_CLOSED = 'ViewClosed'; // evento durante la valutazione dei progressi dell'utente
LogConf.OP_START_SURVEY = 'Start Survey'; // tap sull'elemento di conferma per l'inizio delle domande del questionario
// ELEMENT da loggare
LogConf.NO_ELEMENT = 'NoElementLogged'; // valore di 'default' nel caso in cui, nell'evento, non sia stato coinvolto un elemento grafico
// da concatenare con dettagli (es. la categoria toccata)
LogConf.CAT_READ_MORE = 'ReadMore: ';
LogConf.CAT_READ_MSG = 'ReadMsg: ';
LogConf.CAT_GO_TO_DISHES = 'AddDish';
LogConf.CAT_MEAL = 'Meal: ';
LogConf.CAT_STARTUP = 'StartUp';
LogConf.CAT_SUSPEND = 'Suspend';
LogConf.CAT_EXIT = 'Exit';
LogConf.CAT_RESUME = 'Resume';
LogConf.CAT_LOW_MEMORY = 'LowMemory';
LogConf.CAT_TUTORIAL = 'Tutorial';
LogConf.CAT_DISH = 'Dish: ';
LogConf.CAT_PORTION = 'Portion: ';
LogConf.CAT_TAB = 'TAB: ';
LogConf.CAT_LIFT = 'LIFT: ';
LogConf.CAT_LAST_TTM = 'Last TTM: ';
LogConf.CAT_NEW_TTM = 'New TTM: ';
LogConf.CAT_NO_DATA = 'No Data: ';
LogConf.CAT_FAILED = 'Failed ';
LogConf.CAT_SUCCEED = 'Success ';
LogConf.CAT_CLEAN = 'Clean ';
LogConf.CAT_ACTIONBAR_TITLE = 'ActionBarTitle:  ';
LogConf.CAT_COMM_ID = 'cID: ';
LogConf.CAT_MSG_ID = 'mID: ';
LogConf.CAT_BUG_REPORT = 'BUG Report SENT';
LogConf.CAT_GPS_SENT = 'GPS position SENT';
LogConf.CAT_GPS_ERROR = 'GPS position - ERROR Sending';
LogConf.CAT_GPS_BKG = 'GPS position RCVD';
LogConf.CAT_REST_ERR = 'ERROR returned by the server';

class MeasUiSettings {
}
MeasUiSettings.BMI = {
    img: 'fa-male',
    label: 'measure.bmi.label',
};
MeasUiSettings.WAIST = {
    img: 'pas-waist',
    label: 'measure.waist.label',
    max: 150,
    min: 50,
};
MeasUiSettings.CIGARETTES = {
    img: 'mdi-smoking-rooms',
    label: 'measure.cigarettes.label',
};
MeasUiSettings.SMOKER = {
    img: 'mdi-smoking-rooms',
    label: 'measure.smoker.label',
};
MeasUiSettings.WEIGHT = {
    img: 'pas-weight-scale',
    label: 'measure.weight.label',
    max: 250,
    min: 40,
};
MeasUiSettings.HEIGHT = {
    img: 'pas-height',
    label: 'measure.height.label',
    max: 220,
    min: 120,
};
MeasUiSettings.PHYSICAL_ACTIVITY = {
    img: 'mdi-directions-run',
    label: 'measure.physical_activity.label',
};
MeasUiSettings.HEART_RATE = {
    img: 'fa-heartbeat',
    label: 'measure.hr.label',
};
MeasUiSettings.STEP_COUNT = {
    img: 'fa-shoe-prints',
    label: 'measure.step_count.label',
};
// public static ENERGY_EXPENDITURE = {
//     img: '',
//     label: 'measure.energy_expenditure.label',
// };
MeasUiSettings.SUPERVISOR_REQUIRED = {
    img: 'fa-user-md',
    label: 'measure.',
};
MeasUiSettings.PHYSICAL_INABILITY = {
    img: 'fa-universal-access',
    label: 'measure.',
};
MeasUiSettings.BLOOD_GLUCOSE = {
    img: 'fa-tint',
    label: 'measure.blood_glucose.label',
    max: 34,
    min: 2,
};
MeasUiSettings.HBA1C = {
    img: 'fa-tint',
    label: 'measure.hba1c.label',
    max: 16,
    min: 3,
};
MeasUiSettings.SPO2 = {
    img: 'pas-pressure',
    label: 'measure.oximetry.label',
    max: 100,
    min: 85,
};
MeasUiSettings.HDL = {
    img: 'fa-tint',
    label: 'measure.hdl.label',
    max: 50,
    min: 20,
};
MeasUiSettings.LDL = {
    img: 'fa-tint',
    label: 'measure.ldl.label',
    max: 200,
    min: 80,
};
MeasUiSettings.CHOLESTEROL = {
    img: 'fa-tint',
    label: 'measure.cholesterol.label',
    max: 300,
    min: 100,
};
MeasUiSettings.TRIGLYCERIDE = {
    img: 'fa-tint',
    label: 'measure.triglyceride.label',
    max: 600,
    min: 50,
};
MeasUiSettings.MEAL_ACTIVITY = {
    img: '',
    label: 'measure.meal_activity.label',
};
MeasUiSettings.CALORIC_DAILY_INTAKE = {
    img: '',
    label: 'measure.caloric_daily_intake.label',
};
MeasUiSettings.FIBERS_DAILY_INTAKE = {
    img: '',
    label: 'measure.fibers_daily_intake.label',
};
MeasUiSettings.CARBOHYDRATES_DAILY_INTAKE = {
    img: '',
    label: 'measure.carbohydrates_daily_intake.label',
};
MeasUiSettings.PROTEINS_DAILY_INTAKE = {
    img: '',
    label: 'measure.proteins_daily_intake.label',
};
MeasUiSettings.FATS_DAILY_INTAKE = {
    img: '',
    label: 'measure.fats_daily_intake.label',
};
MeasUiSettings.SODIUM_DAILY_INTAKE = {
    img: '',
    label: 'measure.sodium_daily_intake.label',
};
MeasUiSettings.VEGETABLES_PORTIONS_DAILY_INTAKE = {
    img: '',
    label: 'measure.vegetables_portions_daily_intake.label',
};
MeasUiSettings.FRUIT_PORTIONS_DAILY_INTAKE = {
    img: '',
    label: 'measure.fruit_portions_daily_intake.label',
};
MeasUiSettings.ARTERIAL_PRESSURE = {
    img: 'pas-pressure',
    label: 'measure.pressure.blood.label',
};
MeasUiSettings.SYS_PRESSURE = {
    img: 'pas-pressure',
    label: 'measure.pressure.sys.label',
    max: 300,
    min: 60,
};
MeasUiSettings.DIA_PRESSURE = {
    img: 'pas-pressure',
    label: 'measure.pressure.dia.label',
    max: 150,
    min: 30,
};
MeasUiSettings.HR = {
    img: 'pas-pressure',
    label: 'measure.bpm.label',
    max: 250,
    min: 30,
};
MeasUiSettings.TEMP = {
    img: 'pas-pressure',
    label: 'measure.temperature.label',
    max: 43,
    min: 34,
};
MeasUiSettings.COVID = {
    img: 'fa-virus',
    label: 'measure.covid.label',
};
MeasUiSettings.CHEST_PAIN_Q = {
    img: 'fa-',
    label: 'measure.chestpainq.label',
};
MeasUiSettings.CHEST_PAIN_LEVEL = {
    img: 'fa-',
    label: 'measure.chestpainlevel.label',
};

// tslint:disable-next-line:max-classes-per-file
class FeedbackTypeWeeklyPlan {
    constructor(day, points = []) {
        this.day = day;
        this.points = points;
    }
}
var FeedbackTypeWeekDays;
(function (FeedbackTypeWeekDays) {
    FeedbackTypeWeekDays[FeedbackTypeWeekDays["MONDAY"] = 1] = "MONDAY";
    FeedbackTypeWeekDays[FeedbackTypeWeekDays["TUESDAY"] = 2] = "TUESDAY";
    FeedbackTypeWeekDays[FeedbackTypeWeekDays["WEDNESDAY"] = 3] = "WEDNESDAY";
    FeedbackTypeWeekDays[FeedbackTypeWeekDays["THURSDAY"] = 4] = "THURSDAY";
    FeedbackTypeWeekDays[FeedbackTypeWeekDays["FRIDAY"] = 5] = "FRIDAY";
    FeedbackTypeWeekDays[FeedbackTypeWeekDays["SATURDAY"] = 6] = "SATURDAY";
    FeedbackTypeWeekDays[FeedbackTypeWeekDays["SUNDAY"] = 7] = "SUNDAY";
})(FeedbackTypeWeekDays || (FeedbackTypeWeekDays = {}));

class FeedbackInAppType {
    constructor(config) {
        if (config) {
            this.name = config.name;
            this.intervalPeriodValue = config.intervalPeriodValue;
            this.intervalPeriodUnit = config.intervalPeriodUnit;
            this.evictionPeriodValue = config.evictionPeriodValue;
            this.evictionPeriodUnit = config.evictionPeriodUnit;
            this.notificationDay = config.notificationDay;
            this.notificationHour = config.notificationHour;
            this.notificationMinutes = config.notificationMinutes;
        }
    }
    toString() {
        return `${this.constructor.name} ${this.name ? this.name.toString() : ''} IntervalPeriod: ${this.intervalPeriodValue}${this.intervalPeriodUnit}  EvictionPeriod: ${this.evictionPeriodValue}${this.evictionPeriodUnit}`;
    }
}

class FeedbackInApp {
    // public evictionPeriod: number;
    constructor(scheduledFor, type, status = FeedbackInAppStatus.PENDING, titleKey, textKey) {
        this.scheduledFor = scheduledFor;
        this.type = type;
        this.status = status;
        this.titleKey = titleKey
            ? titleKey
            : type
                ? 'comm.title.' + type.name.toString()
                : undefined;
        this.textKey = textKey
            ? textKey
            : type
                ? 'comm.text.' + type.name.toString()
                : undefined;
    }
    toString() {
        return `${this.id} ${this.scheduledFor ? this.scheduledFor.toString() : ''} TITLE:${this.titleKey} BODY:${this.textKey} ${this.type} ${this.status} `;
    }
    isEvicted() {
        var _a, _b;
        if (!this.scheduledFor && this.type.evictionPeriodUnit === undefined) {
            return false;
        }
        let endDate = this.scheduledFor;
        switch ((_a = this.type) === null || _a === void 0 ? void 0 : _a.evictionPeriodUnit) {
            case 'h':
                endDate = addHours(this.scheduledFor, this.type.evictionPeriodValue);
                break;
            case 'd':
                endDate = addDays(this.scheduledFor, this.type.evictionPeriodValue);
                break;
            // case 'w':
            //   endDate = addWeeks(this.scheduledFor, this.type.evictionPeriodValue);
            //   break;
            // case 'm':
            //   endDate = addMonths(this.scheduledFor, this.type.evictionPeriodValue);
            //   break;
            case 'y':
                endDate = addYears(this.scheduledFor, this.type.evictionPeriodValue);
                break;
            default:
                throw new Error(`Unexpected prioed unit ${(_b = this.type) === null || _b === void 0 ? void 0 : _b.evictionPeriodUnit}`);
        }
        return isBefore(endDate, new Date());
    }
}
var FeedbackInAppTypeName;
(function (FeedbackInAppTypeName) {
    FeedbackInAppTypeName[FeedbackInAppTypeName["BG_P1"] = 'BG_P1'] = "BG_P1";
    FeedbackInAppTypeName[FeedbackInAppTypeName["BG_P2"] = 'BG_P2'] = "BG_P2";
    FeedbackInAppTypeName[FeedbackInAppTypeName["BG_P3"] = 'BG_P3'] = "BG_P3";
    FeedbackInAppTypeName[FeedbackInAppTypeName["BG_P4"] = 'BG_P4'] = "BG_P4";
    FeedbackInAppTypeName[FeedbackInAppTypeName["BG_P5"] = 'BG_P5'] = "BG_P5";
    FeedbackInAppTypeName[FeedbackInAppTypeName["BG_P6"] = 'BG_P6'] = "BG_P6";
    FeedbackInAppTypeName[FeedbackInAppTypeName["BG_P7"] = 'BG_P7'] = "BG_P7";
    FeedbackInAppTypeName[FeedbackInAppTypeName["TTM"] = 'TTM'] = "TTM";
    FeedbackInAppTypeName[FeedbackInAppTypeName["S_UX_QUESTIONNAIRE"] = 'S_UX_QUESTIONNAIRE'] = "S_UX_QUESTIONNAIRE";
    FeedbackInAppTypeName[FeedbackInAppTypeName["MEAL_BREAKFAST"] = 'MEAL_BREAKFAST'] = "MEAL_BREAKFAST";
    FeedbackInAppTypeName[FeedbackInAppTypeName["MEAL_LUNCH"] = 'MEAL_LUNCH'] = "MEAL_LUNCH";
    FeedbackInAppTypeName[FeedbackInAppTypeName["MEAL_DINNER"] = 'MEAL_DINNER'] = "MEAL_DINNER";
    FeedbackInAppTypeName[FeedbackInAppTypeName["PHYSICAL_ACTIVITY"] = 'PHYSICAL_ACTIVITY'] = "PHYSICAL_ACTIVITY";
    FeedbackInAppTypeName[FeedbackInAppTypeName["HABITS_SMOKING"] = 'HABITS_SMOKING'] = "HABITS_SMOKING";
    // HABITS_DRINKING = 'HABITS_DRINKING' as any,
    FeedbackInAppTypeName[FeedbackInAppTypeName["WEIGHT"] = 'WEIGHT'] = "WEIGHT";
    FeedbackInAppTypeName[FeedbackInAppTypeName["REMINDER"] = 'REMINDER'] = "REMINDER";
    FeedbackInAppTypeName[FeedbackInAppTypeName["INFORMATIVE"] = 'INFORMATIVE'] = "INFORMATIVE";
    FeedbackInAppTypeName[FeedbackInAppTypeName["MOTIVATIONAL"] = 'MOTIVATIONAL'] = "MOTIVATIONAL";
})(FeedbackInAppTypeName || (FeedbackInAppTypeName = {}));
var FeedbackInAppStatus;
(function (FeedbackInAppStatus) {
    FeedbackInAppStatus[FeedbackInAppStatus["PENDING"] = 'PENDING'] = "PENDING";
    FeedbackInAppStatus[FeedbackInAppStatus["SHOWN"] = 'SHOWN'] = "SHOWN";
    FeedbackInAppStatus[FeedbackInAppStatus["DONE"] = 'DONE'] = "DONE";
    FeedbackInAppStatus[FeedbackInAppStatus["DONOTFIRE"] = 'DONOTFIRE'] = "DONOTFIRE";
})(FeedbackInAppStatus || (FeedbackInAppStatus = {}));

// tslint:disable:object-literal-sort-keys
/**
 * configurazioni della frequenza (opzionale) e del periodo di eviction (opzionale) per ciascuna tipologia di comunicazione
 *
 * ATTENZIONE: Assicurarsi che il nome delle variabili statiche corrisponda con il rispettivo FeedbackInAppTypeName
 * altirmenti ci saranno problemi con il recupero dal DB
 */
class FeedbackTypeSettings {
}
FeedbackTypeSettings.TTM = new FeedbackInAppType({
    name: FeedbackInAppTypeName.TTM,
    evictionPeriodValue: 3,
    evictionPeriodUnit: 'd',
    notificationHour: 11,
    notificationMinutes: 30, // 30
});
FeedbackTypeSettings.S_UX_QUESTIONNAIRE = new FeedbackInAppType({
    name: FeedbackInAppTypeName.S_UX_QUESTIONNAIRE,
    evictionPeriodValue: 1,
    evictionPeriodUnit: 'y',
    intervalPeriodValue: 28,
    intervalPeriodUnit: 'd',
    notificationHour: 11,
    notificationMinutes: 30, // 30
});
// IMPORTANTE: i reminder di BG non sono periodici... vengono schedulati sempre tutti
FeedbackTypeSettings.BG_P1 = new FeedbackInAppType({
    name: FeedbackInAppTypeName.BG_P1,
    evictionPeriodValue: 3,
    evictionPeriodUnit: 'h',
    notificationHour: 7,
    notificationMinutes: 0, // 0
});
FeedbackTypeSettings.BG_P2 = new FeedbackInAppType({
    name: FeedbackInAppTypeName.BG_P2,
    evictionPeriodValue: 3,
    evictionPeriodUnit: 'h',
    notificationHour: 8,
    notificationMinutes: 30, // 30
});
FeedbackTypeSettings.BG_P3 = new FeedbackInAppType({
    name: FeedbackInAppTypeName.BG_P3,
    evictionPeriodValue: 3,
    evictionPeriodUnit: 'h',
    notificationHour: 12,
    notificationMinutes: 0, // 0
});
FeedbackTypeSettings.BG_P4 = new FeedbackInAppType({
    name: FeedbackInAppTypeName.BG_P4,
    evictionPeriodValue: 3,
    evictionPeriodUnit: 'h',
    notificationHour: 14,
    notificationMinutes: 0, // 0
});
FeedbackTypeSettings.BG_P5 = new FeedbackInAppType({
    name: FeedbackInAppTypeName.BG_P5,
    evictionPeriodValue: 3,
    evictionPeriodUnit: 'h',
    notificationHour: 19,
    notificationMinutes: 30, // 30
});
FeedbackTypeSettings.BG_P6 = new FeedbackInAppType({
    name: FeedbackInAppTypeName.BG_P6,
    evictionPeriodValue: 3,
    evictionPeriodUnit: 'h',
    notificationHour: 21,
    notificationMinutes: 30, // 30
});
FeedbackTypeSettings.BG_P7 = new FeedbackInAppType({
    name: FeedbackInAppTypeName.BG_P7,
    evictionPeriodValue: 2,
    evictionPeriodUnit: 'h',
    notificationHour: 22,
    notificationMinutes: 0, // 0
});
FeedbackTypeSettings.MEAL_BREAKFAST = new FeedbackInAppType({
    name: FeedbackInAppTypeName.MEAL_BREAKFAST,
    intervalPeriodValue: 24,
    intervalPeriodUnit: 'h',
    evictionPeriodValue: 15,
    evictionPeriodUnit: 'h',
    notificationHour: 8,
    notificationMinutes: 30, // 30
});
FeedbackTypeSettings.MEAL_LUNCH = new FeedbackInAppType({
    name: FeedbackInAppTypeName.MEAL_LUNCH,
    intervalPeriodValue: 24,
    intervalPeriodUnit: 'h',
    evictionPeriodValue: 10,
    evictionPeriodUnit: 'h',
    notificationHour: 14,
    notificationMinutes: 0, // 0
});
FeedbackTypeSettings.MEAL_DINNER = new FeedbackInAppType({
    name: FeedbackInAppTypeName.MEAL_DINNER,
    intervalPeriodValue: 24,
    intervalPeriodUnit: 'h',
    evictionPeriodValue: 3,
    evictionPeriodUnit: 'h',
    notificationHour: 21,
    notificationMinutes: 0, // 0
});
FeedbackTypeSettings.PHYSICAL_ACTIVITY = new FeedbackInAppType({
    name: FeedbackInAppTypeName.PHYSICAL_ACTIVITY,
    intervalPeriodValue: 7,
    intervalPeriodUnit: 'd',
    evictionPeriodValue: 24,
    evictionPeriodUnit: 'h',
    notificationDay: FeedbackTypeWeekDays.FRIDAY,
    notificationHour: 18,
    notificationMinutes: 30, // 30
});
FeedbackTypeSettings.HABITS_SMOKING = new FeedbackInAppType({
    name: FeedbackInAppTypeName.HABITS_SMOKING,
    intervalPeriodValue: 24,
    intervalPeriodUnit: 'h',
    evictionPeriodValue: 4,
    evictionPeriodUnit: 'h',
    notificationHour: 20,
    notificationMinutes: 0, // 0
});
// obsolete FeedbackInApp type (it is not possible to provide only this information)
// public static HABITS_DRINKING = new FeedbackInAppType({
//     type: FeedbackInAppTypeName.HABITS_DRINKING,
//     intervalPeriodValue: 24,
//     intervalPeriodUnit: 'h',
//     evictionPeriodValue: 20,
//     evictionPeriodUnit: 'h',
// });
FeedbackTypeSettings.WEIGHT = new FeedbackInAppType({
    name: FeedbackInAppTypeName.WEIGHT,
    intervalPeriodValue: 15,
    intervalPeriodUnit: 'd',
    evictionPeriodValue: 3,
    evictionPeriodUnit: 'd',
    notificationDay: FeedbackTypeWeekDays.WEDNESDAY,
    notificationHour: 8,
    notificationMinutes: 0, // 0
});
/**
 * From here onward the FeedbackInAppType have a 'global' scope and they are used only in the Jobs
 */
FeedbackTypeSettings.REMINDER = new FeedbackInAppType({
    name: FeedbackInAppTypeName.REMINDER,
    evictionPeriodValue: 24,
    evictionPeriodUnit: 'h', // h
});
FeedbackTypeSettings.MOTIVATIONAL = new FeedbackInAppType({
    name: FeedbackInAppTypeName.MOTIVATIONAL,
    evictionPeriodValue: 24,
    evictionPeriodUnit: 'h', // h
});
FeedbackTypeSettings.INFORMATIVE = new FeedbackInAppType({
    name: FeedbackInAppTypeName.INFORMATIVE,
    evictionPeriodValue: 23,
    evictionPeriodUnit: 'h',
    intervalPeriodValue: 24,
    intervalPeriodUnit: 'h',
    notificationHour: 10,
    notificationMinutes: 0, // 0
});

var Gender;
(function (Gender) {
    Gender[Gender["male"] = 'male'] = "male";
    Gender[Gender["female"] = 'female'] = "female";
    Gender[Gender["other"] = 'other'] = "other";
    Gender[Gender["unknown"] = 'unknown'] = "unknown";
})(Gender || (Gender = {}));
(function (Gender) {
    function fromString(gender) {
        if (gender === Gender.male.toString()) {
            return Gender.male;
        }
        else if (gender === Gender.female.toString()) {
            return Gender.female;
        }
        else if (gender === Gender.unknown.toString()) {
            return Gender.unknown;
        }
        else if (gender === Gender.other.toString()) {
            return Gender.other;
        }
        else {
            return undefined;
        }
    }
    Gender.fromString = fromString;
})(Gender || (Gender = {}));

class Role {
    constructor(role) {
        // forces lowercasing to role name
        this.role = role.toLowerCase();
    }
    toString() {
        return this.role;
    }
    /**
     * Custom serialization of the enum. As this class is not a real enumeration this is needed to have the 'role' as string instead of an object
     *
     * @returns serialized roles
     */
    toJSON() {
        return this.role;
    }
    toStringUppercase() {
        return this.role.toUpperCase();
    }
    static values() {
        const values = Object.values(Role).filter(v => v instanceof Role);
        if (Role.EXTRA) {
            values.push(...Role.EXTRA);
        }
        return values;
    }
    /**
     *
     * @param roleString
     * @returns
     */
    static convertFromString(roleString) {
        const values = Role.values();
        return values.find(v => v.role.toLowerCase() == roleString.toLowerCase());
    }
}
Role.ADMIN = new Role('admin');
Role.PRACTITIONER = new Role('practitioner');
Role.RESEARCHER = new Role('researcher');
Role.PATIENT = new Role('patient');
Role.GENETICIST = new Role('geneticist');
Role.LAB_GENETICIST = new Role('lab_geneticist');
Role.RESEARCHER_GENETICIST = new Role('researcher_geneticist');
Role.BIOINFORMATICIAN = new Role('bioinformatician');
Role.NURSE = new Role('nurse');
// public static GUEST = new Role('guest');
/**
 * static array of project-scoped roles
 *
 * To add a new role you have to create a new role
 * and add it to the EXTRA array as soon as the app is loaded
 *
 */
Role.EXTRA = [];

var Locale;
(function (Locale) {
    Locale["AF"] = "af";
    Locale["SQ"] = "sq";
    Locale["AM"] = "am";
    Locale["AR"] = "ar";
    Locale["AN"] = "an";
    Locale["HY"] = "hy";
    Locale["AST"] = "ast";
    Locale["AZ"] = "az";
    Locale["EU"] = "eu";
    Locale["BE"] = "be";
    Locale["BN"] = "bn";
    Locale["BS"] = "bs";
    Locale["BR"] = "br";
    Locale["BG"] = "bg";
    Locale["CA"] = "ca";
    Locale["CKB"] = "ckb";
    Locale["ZH"] = "zh";
    Locale["CO"] = "co";
    Locale["HR"] = "hr";
    Locale["CS"] = "cs";
    Locale["DA"] = "da";
    Locale["NL"] = "nl";
    Locale["EN"] = "en";
    Locale["EO"] = "eo";
    Locale["ET"] = "et";
    Locale["FO"] = "fo";
    Locale["FIL"] = "fil";
    Locale["FI"] = "fi";
    Locale["FR"] = "fr";
    Locale["GL"] = "gl";
    Locale["KA"] = "ka";
    Locale["DE"] = "de";
    Locale["EL"] = "el";
    Locale["GN"] = "gn";
    Locale["GU"] = "gu";
    Locale["HA"] = "ha";
    Locale["HAW"] = "haw";
    Locale["HE"] = "he";
    Locale["HI"] = "hi";
    Locale["HU"] = "hu";
    Locale["IS"] = "is";
    Locale["ID"] = "id";
    Locale["IA"] = "ia";
    Locale["GA"] = "ga";
    Locale["IT"] = "it";
    Locale["JA"] = "ja";
    Locale["KN"] = "kn";
    Locale["KK"] = "kk";
    Locale["KM"] = "km";
    Locale["KO"] = "ko";
    Locale["KU"] = "ku";
    Locale["KY"] = "ky";
    Locale["LO"] = "lo";
    Locale["LA"] = "la";
    Locale["LV"] = "lv";
    Locale["LN"] = "ln";
    Locale["LT"] = "lt";
    Locale["MK"] = "mk";
    Locale["MS"] = "ms";
    Locale["ML"] = "ml";
    Locale["MT"] = "mt";
    Locale["MR"] = "mr";
    Locale["MN"] = "mn";
    Locale["NE"] = "ne";
    Locale["NO"] = "no";
    Locale["NB"] = "nb";
    Locale["NN"] = "nn";
    Locale["OC"] = "oc";
    Locale["OR"] = "or";
    Locale["OM"] = "om";
    Locale["PS"] = "ps";
    Locale["FA"] = "fa";
    Locale["PL"] = "pl";
    Locale["PT"] = "pt";
    Locale["PA"] = "pa";
    Locale["QU"] = "qu";
    Locale["RO"] = "ro";
    Locale["MO"] = "mo";
    Locale["RM"] = "rm";
    Locale["RU"] = "ru";
    Locale["GD"] = "gd";
    Locale["SR"] = "sr";
    Locale["SH"] = "sh";
    Locale["SN"] = "sn";
    Locale["SD"] = "sd";
    Locale["SI"] = "si";
    Locale["SK"] = "sk";
    Locale["SL"] = "sl";
    Locale["SO"] = "so";
    Locale["ST"] = "st";
    Locale["ES"] = "es";
    Locale["SU"] = "su";
    Locale["SW"] = "sw";
    Locale["SV"] = "sv";
    Locale["TG"] = "tg";
    Locale["TA"] = "ta";
    Locale["TT"] = "tt";
    Locale["TE"] = "te";
    Locale["TH"] = "th";
    Locale["TI"] = "ti";
    Locale["TO"] = "to";
    Locale["TR"] = "tr";
    Locale["TK"] = "tk";
    Locale["TW"] = "tw";
    Locale["UK"] = "uk";
    Locale["UR"] = "ur";
    Locale["UG"] = "ug";
    Locale["UZ"] = "uz";
    Locale["VI"] = "vi";
    Locale["WA"] = "wa";
    Locale["CY"] = "cy";
    Locale["FY"] = "fy";
    Locale["XH"] = "xh";
    Locale["YI"] = "yi";
    Locale["YO"] = "yo";
    Locale["ZU"] = "zu";
})(Locale || (Locale = {}));
// tslint:disable-next-line:no-namespace
(function (Locale) {
    function values() {
        return Object.values(Locale);
    }
    Locale.values = values;
    function convertFromString(localeString) {
        return this.values().find(v => v == localeString);
    }
    Locale.convertFromString = convertFromString;
})(Locale || (Locale = {}));
// return [Locale.AF ,
//   Locale.SQ ,
//   Locale.AM ,
//   Locale.AR ,
//   Locale.AN ,
//   Locale.HY ,
//   Locale.AST,
//   Locale.AZ ,
//   Locale.EU ,
//   Locale.BE ,
//   Locale.BN ,
//   Locale.BS ,
//   Locale.BR ,
//   Locale.BG ,
//   Locale.CA ,
//   Locale.CKB,
//   Locale.ZH ,
//   Locale.CO ,
//   Locale.HR ,
//   Locale.CS ,
//   Locale.DA ,
//   Locale.NL ,
//   Locale.EN ,
//   Locale.EO ,
//   Locale.ET ,
//   Locale.FO ,
//   Locale.FIL,
//   Locale.FI ,
//   Locale.FR ,
//   Locale.GL ,
//   Locale.KA ,
//   Locale.DE ,
//   Locale.EL ,
//   Locale.GN ,
//   Locale.GU ,
//   Locale.HA ,
//   Locale.HAW,
//   Locale.HE ,
//   Locale.HI ,
//   Locale.HU ,
//   Locale.IS ,
//   Locale.ID ,
//   Locale.IA ,
//   Locale.GA ,
//   Locale.IT ,
//   Locale.JA ,
//   Locale.KN ,
//   Locale.KK ,
//   Locale.KM ,
//   Locale.KO ,
//   Locale.KU ,
//   Locale.KY ,
//   Locale.LO ,
//   Locale.LA ,
//   Locale.LV ,
//   Locale.LN ,
//   Locale.LT ,
//   Locale.MK ,
//   Locale.MS ,
//   Locale.ML ,
//   Locale.MT ,
//   Locale.MR ,
//   Locale.MN ,
//   Locale.NE ,
//   Locale.NO ,
//   Locale.NB ,
//   Locale.NN ,
//   Locale.OC ,
//   Locale.OR ,
//   Locale.OM ,
//   Locale.PS ,
//   Locale.FA ,
//   Locale.PL ,
//   Locale.PT ,
//   Locale.PA ,
//   Locale.QU ,
//   Locale.RO ,
//   Locale.MO ,
//   Locale.RM ,
//   Locale.RU ,
//   Locale.GD ,
//   Locale.SR ,
//   Locale.SH ,
//   Locale.SN ,
//   Locale.SD ,
//   Locale.SI ,
//   Locale.SK ,
//   Locale.SL ,
//   Locale.SO ,
//   Locale.ST ,
//   Locale.ES ,
//   Locale.SU ,
//   Locale.SW ,
//   Locale.SV ,
//   Locale.TG ,
//   Locale.TA ,
//   Locale.TT ,
//   Locale.TE ,
//   Locale.TH ,
//   Locale.TI ,
//   Locale.TO ,
//   Locale.TR ,
//   Locale.TK ,
//   Locale.TW ,
//   Locale.UK ,
//   Locale.UR ,
//   Locale.UG ,
//   Locale.UZ ,
//   Locale.VI ,
//   Locale.WA ,
//   Locale.CY ,
//   Locale.FY ,
//   Locale.XH ,
//   Locale.YI ,
//   Locale.YO ,
//   Locale.ZU];

var Pathology;
(function (Pathology) {
    Pathology["DIABETES_MELLITUS_TYPE_2"] = "DIABETES_MELLITUS_TYPE_2";
    Pathology["DMT2"] = "DMT2";
    Pathology["CANCER"] = "CANCER";
    Pathology["CARDIOVASCULAR_DISEASE"] = "CARDIOVASCULAR_DISEASE";
    Pathology["CVD"] = "CVD";
    Pathology["CHRONIC_OBSTRUCTIVE_PULMONARY_DISEASE"] = "CHRONIC_OBSTRUCTIVE_PULMONARY_DISEASE";
    Pathology["COPD"] = "COPD";
    Pathology["ASTHMA"] = "ASTHMA";
    Pathology["ALLERGY"] = "ALLERGY";
    Pathology["HYPERTENSION"] = "HYPERTENSION";
    Pathology["OTHER_DISORDER"] = "OTHER_DISORDER";
})(Pathology || (Pathology = {}));
(function (Pathology) {
    function convertFromString(pathologyString) {
        if (pathologyString === Pathology.DIABETES_MELLITUS_TYPE_2.toString()) {
            return Pathology.DIABETES_MELLITUS_TYPE_2;
        }
        else if (pathologyString === Pathology.DMT2.toString()) {
            return Pathology.DMT2;
        }
        else if (pathologyString === Pathology.CANCER.toString()) {
            return Pathology.CANCER;
        }
        else if (pathologyString === Pathology.CARDIOVASCULAR_DISEASE.toString()) {
            return Pathology.CARDIOVASCULAR_DISEASE;
        }
        else if (pathologyString === Pathology.CVD.toString()) {
            return Pathology.CVD;
        }
        else if (pathologyString ===
            Pathology.CHRONIC_OBSTRUCTIVE_PULMONARY_DISEASE.toString()) {
            return Pathology.CHRONIC_OBSTRUCTIVE_PULMONARY_DISEASE;
        }
        else if (pathologyString === Pathology.COPD.toString()) {
            return Pathology.COPD;
        }
        else if (pathologyString === Pathology.ASTHMA.toString()) {
            return Pathology.ASTHMA;
        }
        else if (pathologyString === Pathology.ALLERGY.toString()) {
            return Pathology.ALLERGY;
        }
        else if (pathologyString === Pathology.HYPERTENSION.toString()) {
            return Pathology.HYPERTENSION;
        }
        else if (pathologyString === Pathology.OTHER_DISORDER.toString()) {
            return Pathology.OTHER_DISORDER;
        }
        else {
            return undefined;
        }
    }
    Pathology.convertFromString = convertFromString;
})(Pathology || (Pathology = {}));

class Language {
    constructor(name, code) {
        this.name = name;
        this.code = code;
    }
    // comodity per il progetto host
    static getSubset(codes) {
        const toRet = this.allLanguages.filter(lang => codes.includes(lang.code));
        return toRet;
    }
}
Language.allLanguages = [
    { name: "English", code: "en" },
    { name: "Italian - italiano", code: "it" },
    { name: "Afrikaans", code: "af" },
    { name: "Albanian - shqip", code: "sq" },
    { name: "Amharic - አማርኛ", code: "am" },
    { name: "Arabic - العربية", code: "ar" },
    { name: "Aragonese - aragonés", code: "an" },
    { name: "Armenian - հայերեն", code: "hy" },
    { name: "Asturian - asturianu", code: "ast" },
    { name: "Azerbaijani - azərbaycan dili", code: "az" },
    { name: "Basque - euskara", code: "eu" },
    { name: "Belarusian - беларуская", code: "be" },
    { name: "Bengali - বাংলা", code: "bn" },
    { name: "Bosnian - bosanski", code: "bs" },
    { name: "Breton - brezhoneg", code: "br" },
    { name: "Bulgarian - български", code: "bg" },
    { name: "Catalan - català", code: "ca" },
    { name: "Central Kurdish - کوردی (دەستنوسی عەرەبی)", code: "ckb" },
    { name: "Chinese - 中文", code: "zh" },
    // {name: "Chinese (Hong Kong) - 中文（香港）", code: "zh-HK"},
    // {name: "Chinese (Simplified) - 中文（简体）", code: "zh-CN"},
    // {name: "Chinese (Traditional) - 中文（繁體）", code: "zh-TW"},
    { name: "Corsican", code: "co" },
    { name: "Croatian - hrvatski", code: "hr" },
    { name: "Czech - čeština", code: "cs" },
    { name: "Danish - dansk", code: "da" },
    { name: "Dutch - Nederlands", code: "nl" },
    // {name: "English (Australia)", code: "en-AU"},
    // {name: "English (Canada)", code: "en-CA"},
    // {name: "English (India)", code: "en-IN"},
    // {name: "English (New Zealand)", code: "en-NZ"},
    // {name: "English (South Africa)", code: "en-ZA"},
    // {name: "English (United Kingdom)", code: "en-GB"},
    // {name: "English (United States)", code: "en-US"},
    { name: "Esperanto - esperanto", code: "eo" },
    { name: "Estonian - eesti", code: "et" },
    { name: "Faroese - føroyskt", code: "fo" },
    { name: "Filipino", code: "fil" },
    { name: "Finnish - suomi", code: "fi" },
    { name: "French - français", code: "fr" },
    // {name: "French (Canada) - français (Canada)", code: "fr-CA"},
    // {name: "French (France) - français (France)", code: "fr-FR"},
    // {name: "French (Switzerland) - français (Suisse)", code: "fr-CH"},
    { name: "Galician - galego", code: "gl" },
    { name: "Georgian - ქართული", code: "ka" },
    { name: "German - Deutsch", code: "de" },
    // {name: "German (Austria) - Deutsch (Österreich)", code: "de-AT"},
    // {name: "German (Germany) - Deutsch (Deutschland)", code: "de-DE"},
    // {name: "German (Liechtenstein) - Deutsch (Liechtenstein)", code: "de-LI"},
    // {name: "German (Switzerland) - Deutsch (Schweiz)", code: "de-CH"},
    { name: "Greek - Ελληνικά", code: "el" },
    { name: "Guarani", code: "gn" },
    { name: "Gujarati - ગુજરાતી", code: "gu" },
    { name: "Hausa", code: "ha" },
    { name: "Hawaiian - ʻŌlelo Hawaiʻi", code: "haw" },
    { name: "Hebrew - עברית", code: "he" },
    { name: "Hindi - हिन्दी", code: "hi" },
    { name: "Hungarian - magyar", code: "hu" },
    { name: "Icelandic - íslenska", code: "is" },
    { name: "Indonesian - Indonesia", code: "id" },
    { name: "Interlingua", code: "ia" },
    { name: "Irish - Gaeilge", code: "ga" },
    // {name: "Italian (Italy) - italiano (Italia)", code: "it-IT"},
    // {name: "Italian (Switzerland) - italiano (Svizzera)", code: "it-CH"},
    { name: "Japanese - 日本語", code: "ja" },
    { name: "Kannada - ಕನ್ನಡ", code: "kn" },
    { name: "Kazakh - қазақ тілі", code: "kk" },
    { name: "Khmer - ខ្មែរ", code: "km" },
    { name: "Korean - 한국어", code: "ko" },
    { name: "Kurdish - Kurdî", code: "ku" },
    { name: "Kyrgyz - кыргызча", code: "ky" },
    { name: "Lao - ລາວ", code: "lo" },
    { name: "Latin", code: "la" },
    { name: "Latvian - latviešu", code: "lv" },
    { name: "Lingala - lingála", code: "ln" },
    { name: "Lithuanian - lietuvių", code: "lt" },
    { name: "Macedonian - македонски", code: "mk" },
    { name: "Malay - Bahasa Melayu", code: "ms" },
    { name: "Malayalam - മലയാളം", code: "ml" },
    { name: "Maltese - Malti", code: "mt" },
    { name: "Marathi - मराठी", code: "mr" },
    { name: "Mongolian - монгол", code: "mn" },
    { name: "Nepali - नेपाली", code: "ne" },
    { name: "Norwegian - norsk", code: "no" },
    { name: "Norwegian Bokmål - norsk bokmål", code: "nb" },
    { name: "Norwegian Nynorsk - nynorsk", code: "nn" },
    { name: "Occitan", code: "oc" },
    { name: "Oriya - ଓଡ଼ିଆ", code: "or" },
    { name: "Oromo - Oromoo", code: "om" },
    { name: "Pashto - پښتو", code: "ps" },
    { name: "Persian - فارسی", code: "fa" },
    { name: "Polish - polski", code: "pl" },
    { name: "Portuguese - português", code: "pt" },
    // {name: "Portuguese (Brazil) - português (Brasil)", code: "pt-BR"},
    // {name: "Portuguese (Portugal) - português (Portugal)", code: "pt-PT"},
    { name: "Punjabi - ਪੰਜਾਬੀ", code: "pa" },
    { name: "Quechua", code: "qu" },
    { name: "Romanian - română", code: "ro" },
    { name: "Romanian (Moldova) - română (Moldova)", code: "mo" },
    { name: "Romansh - rumantsch", code: "rm" },
    { name: "Russian - русский", code: "ru" },
    { name: "Scottish Gaelic", code: "gd" },
    { name: "Serbian - српски", code: "sr" },
    { name: "Serbo - Croatian", code: "sh" },
    { name: "Shona - chiShona", code: "sn" },
    { name: "Sindhi", code: "sd" },
    { name: "Sinhala - සිංහල", code: "si" },
    { name: "Slovak - slovenčina", code: "sk" },
    { name: "Slovenian - slovenščina", code: "sl" },
    { name: "Somali - Soomaali", code: "so" },
    { name: "Southern Sotho", code: "st" },
    { name: "Spanish - español", code: "es" },
    // {name: "Spanish (Argentina) - español (Argentina)", code: "es-AR"},
    // {name: "Spanish (Latin America) - español (Latinoamérica)", code: "es-419"},
    // {name: "Spanish (Mexico) - español (México)", code: "es-MX"},
    // {name: "Spanish (Spain) - español (España)", code: "es-ES"},
    // {name: "Spanish (United States) - español (Estados Unidos)", code: "es-US"},
    { name: "Sundanese", code: "su" },
    { name: "Swahili - Kiswahili", code: "sw" },
    { name: "Swedish - svenska", code: "sv" },
    { name: "Tajik - тоҷикӣ", code: "tg" },
    { name: "Tamil - தமிழ்", code: "ta" },
    { name: "Tatar", code: "tt" },
    { name: "Telugu - తెలుగు", code: "te" },
    { name: "Thai - ไทย", code: "th" },
    { name: "Tigrinya - ትግርኛ", code: "ti" },
    { name: "Tongan - lea fakatonga", code: "to" },
    { name: "Turkish - Türkçe", code: "tr" },
    { name: "Turkmen", code: "tk" },
    { name: "Twi", code: "tw" },
    { name: "Ukrainian - українська", code: "uk" },
    { name: "Urdu - اردو", code: "ur" },
    { name: "Uyghur", code: "ug" },
    { name: "Uzbek - o‘zbek", code: "uz" },
    { name: "Vietnamese - Tiếng Việt", code: "vi" },
    { name: "Walloon - wa", code: "wa" },
    { name: "Welsh - Cymraeg", code: "cy" },
    { name: "Western Frisian", code: "fy" },
    { name: "Xhosa", code: "xh" },
    { name: "Yiddish", code: "yi" },
    { name: "Yoruba - Èdè Yorùbá", code: "yo" },
    { name: "Zulu - isiZulu", code: "zu" }
];

var HealthService;
(function (HealthService) {
    HealthService["OUTPATIENT"] = "outpatient";
    HealthService["HOSPITALIZATION"] = "hospitalization";
    HealthService["DAY_HOSPITAL"] = "day_hospital";
})(HealthService || (HealthService = {}));
// tslint:disable-next-line:no-namespace
(function (HealthService) {
    function values() {
        return Object.values(HealthService);
    }
    HealthService.values = values;
    function convertFromString(string) {
        return this.values().find(v => v == string);
    }
    HealthService.convertFromString = convertFromString;
})(HealthService || (HealthService = {}));

var EpisodeStatus;
(function (EpisodeStatus) {
    EpisodeStatus["ACTIVE"] = "active";
    EpisodeStatus["FINISHED"] = "finished";
})(EpisodeStatus || (EpisodeStatus = {}));
// tslint:disable-next-line:no-namespace
(function (EpisodeStatus) {
    function values() {
        return Object.values(EpisodeStatus);
    }
    EpisodeStatus.values = values;
    function convertFromString(string) {
        return this.values().find(v => v == string);
    }
    EpisodeStatus.convertFromString = convertFromString;
})(EpisodeStatus || (EpisodeStatus = {}));

var EncounterStatus;
(function (EncounterStatus) {
    EncounterStatus["INPROGRESS"] = "in-progress";
    EncounterStatus["COMPLETED"] = "completed";
})(EncounterStatus || (EncounterStatus = {}));
// tslint:disable-next-line:no-namespace
(function (EncounterStatus) {
    function values() {
        return Object.values(EncounterStatus);
    }
    EncounterStatus.values = values;
    function convertFromString(string) {
        return this.values().find(v => v == string);
    }
    EncounterStatus.convertFromString = convertFromString;
})(EncounterStatus || (EncounterStatus = {}));

var EncounterQuestionnaire;
(function (EncounterQuestionnaire) {
    EncounterQuestionnaire["FAMILY_ANAMNESIS"] = "family-history";
    EncounterQuestionnaire["PATIENT_PHYSIOLOGICAL_HISTORY"] = "patient-physiological-history";
    EncounterQuestionnaire["PATIENT_SHORT_TERM_HISTORY"] = "short-term-pathological-history";
    EncounterQuestionnaire["REMOTE_ANAMNESIS"] = "long-term-pathological-history";
    EncounterQuestionnaire["HEALTH_HISTORY"] = "prevention-health-history";
    EncounterQuestionnaire["LIFESTYLE"] = "patient-lifestyle-nutrition";
    EncounterQuestionnaire["OTHER"] = "other";
})(EncounterQuestionnaire || (EncounterQuestionnaire = {}));
// tslint:disable-next-line:no-namespace
(function (EncounterQuestionnaire) {
    function values() {
        return Object.values(EncounterQuestionnaire);
    }
    EncounterQuestionnaire.values = values;
    function valueOf(value) {
        return this.values().find((v) => v == value);
    }
    EncounterQuestionnaire.valueOf = valueOf;
})(EncounterQuestionnaire || (EncounterQuestionnaire = {}));

var EncounterType;
(function (EncounterType) {
    EncounterType["ANNUAL_SCREENING"] = "annual-screening";
    EncounterType["FIRST_ENCOUNTER"] = "first-encounter";
    EncounterType["SCHOOL_CHECK"] = "school-check";
    EncounterType["PREVENTION_CAMPAIGN"] = "prevention-campaign";
    EncounterType["OTHER"] = "other";
})(EncounterType || (EncounterType = {}));
// tslint:disable-next-line:no-namespace
(function (EncounterType) {
    function values() {
        return Object.values(EncounterType);
    }
    EncounterType.values = values;
    function convertFromString(string) {
        return this.values().find((v) => v == string);
    }
    EncounterType.convertFromString = convertFromString;
})(EncounterType || (EncounterType = {}));

var AppointmentStatus;
(function (AppointmentStatus) {
    AppointmentStatus["PROPOSED"] = "proposed";
    AppointmentStatus["PENDING"] = "pending";
    AppointmentStatus["BOOKED"] = "booked";
    AppointmentStatus["CANCELLED"] = "cancelled";
    AppointmentStatus["FULFILLED"] = "fulfilled";
})(AppointmentStatus || (AppointmentStatus = {}));
// tslint:disable-next-line:no-namespace
(function (AppointmentStatus) {
    function values() {
        return Object.values(AppointmentStatus);
    }
    AppointmentStatus.values = values;
    function convertFromString(string) {
        return this.values().find((v) => v == string);
    }
    AppointmentStatus.convertFromString = convertFromString;
})(AppointmentStatus || (AppointmentStatus = {}));

var RiskLevel;
(function (RiskLevel) {
    RiskLevel["NEGLIGIBLE"] = "negligible";
    RiskLevel["LOW"] = "low";
    RiskLevel["MODERATE"] = "moderate";
    RiskLevel["HIGH"] = "high";
    RiskLevel["CERTAIN"] = "certain";
})(RiskLevel || (RiskLevel = {}));
// tslint:disable-next-line:no-namespace
(function (RiskLevel) {
    function values() {
        return Object.values(RiskLevel);
    }
    RiskLevel.values = values;
    function convertFromString(string) {
        return this.values().find((v) => v == string);
    }
    RiskLevel.convertFromString = convertFromString;
})(RiskLevel || (RiskLevel = {}));

var CareTeamStatus;
(function (CareTeamStatus) {
    CareTeamStatus["PROPOSED"] = "proposed";
    CareTeamStatus["ACTIVE"] = "active";
    CareTeamStatus["SUSPENDED"] = "suspended";
    CareTeamStatus["INACTIVE"] = "inactive";
})(CareTeamStatus || (CareTeamStatus = {}));
// tslint:disable-next-line:no-namespace
(function (CareTeamStatus) {
    function values() {
        return Object.values(CareTeamStatus);
    }
    CareTeamStatus.values = values;
    function convertFromString(string) {
        return this.values().find((v) => v == string);
    }
    CareTeamStatus.convertFromString = convertFromString;
})(CareTeamStatus || (CareTeamStatus = {}));

// tslint:disable-next-line:no-empty-interface
class Shareable {
    constructor(id) {
        this.id = id;
    }
    get fhirId() {
        return this.id ? `${this.id}` : undefined;
    }
    get healthId() {
        return undefined;
    }
}

class Identifier {
    static revive(json) {
        const newObj = Object.create(Identifier.prototype);
        // if ('Identifier' !== json.resourceType) {
        //   throw new TypeError(`Trying to wrongly deserialize as '${newObj.resourceType}' ${JSON.stringify(json)}`);
        // }
        return Object.assign(newObj, json || {});
    }
}

class Organization extends Shareable {
    constructor(id, name) {
        super(id);
        this.id = id;
        this.name = name;
        this.resourceType = 'Organization';
    }
    static revive(json) {
        const newObj = Object.create(Organization.prototype);
        if ('Organization' !== json.resourceType) {
            throw new TypeError(`Trying to wrongly deserialize as '${newObj.resourceType}' ${JSON.stringify(json)}`);
        }
        return Object.assign(newObj, json || {});
    }
}

/**
 * This is an associtive class to link a Person with an Organization and a Role
 *
 * Noteworthy is that in case the Person is a Patient the only valid role is 'patient'
 */
class PersonRole {
    constructor(organization, role) {
        this.organization = organization;
        this.role = role;
    }
    static revive(json) {
        if (!json.organization && !json.role) {
            return undefined;
        }
        const newObj = Object.create(PersonRole.prototype);
        // if ('PersonRole' !== json.resourceType) {
        //   throw new TypeError(`Trying to wrongly deserialize as 'PersonRole' ${json}`);
        // }
        return Object.assign(newObj, json || {}, {
            organization: (() => {
                return json.organization ? Organization.revive(json.organization) : undefined;
            })(),
            role: (() => {
                return json.role ? Role.convertFromString(json.role) : undefined;
            })(),
        });
    }
}

class Person extends Shareable {
    constructor() {
        super(...arguments);
        this.additionalIdentifiers = [];
        /**
         * Array of couples role-organization. it is meant to define the expected role of the user for a given organization.
         * In case the user plays multiple roles for the same organization multiple instance of PersonRole will be created
         *
         * Used only for security purposes
         */
        this.personRoles = [];
        this.gender = Gender.unknown;
    }
    /**
     * backwards compatibility of the 'name' attribute
     *
     * @deprecated: use firstName instead
     */
    get name() {
        return this.firstName;
    }
    /**
     * @deprecated: use firstName instead
     */
    set name(name) {
        this.firstName = name;
    }
    /**
     * Backwards compatibility of the 'family' attribute
     *
     * @deprecated: use lastName instead
     */
    get family() {
        return this.lastName;
    }
    /**
     * @deprecated: use lastName instead
     */
    set family(family) {
        this.lastName = family;
    }
    /**
     * Age of the person at the instant of enrollment in the system.
     *
     * This can be estimated as the expected age of the person at the last day of the year (i.e. 31/12)
     *
     * IMPORTANT: If you set the age the birthdate is automatically changed
     */
    get age() {
        // fetches current Date
        const today = new Date();
        return this.calculateAgeAt(today);
    }
    calculateAgeAt(day) {
        // fetches birthdate
        let birthDate = this.birthDate;
        // if birthDate is undefined returns undefined
        if (birthDate == undefined) {
            return undefined;
        }
        if (isBefore(day, birthDate)) {
            return undefined;
        }
        // add age to birthDate
        let age = 0;
        // calculated the difference in years between birtdate and today (left param is the most recent one)
        age = differenceInCalendarYears(day, birthDate);
        return age;
    }
    /**
     * IMPORTANT: If you set the age the birthdate is automatically changed
     */
    set age(age) {
        // if the paraemter is undefined we can't calculate the birthdate
        if (age == undefined) {
            return;
        }
        // fetches current Date
        const today = new Date();
        // subtract age to current Date
        let birthDate = subYears(today, age);
        // change the calculated Date to end of yeary
        birthDate = endOfYear(birthDate);
        // sets the calculated birthDate usign the new value
        this.birthDate = birthDate;
    }
    getFullName() {
        var _a, _b;
        if (this.name || this.family) {
            return [(_a = this.name) === null || _a === void 0 ? void 0 : _a.trim(), (_b = this.family) === null || _b === void 0 ? void 0 : _b.trim()]
                .filter((str) => str && str !== '')
                .join(' ')
                .trim();
        }
        return undefined;
    }
    static personSource(newPerson, json) {
        return Object.assign(newPerson, {
            id: json.id,
            firstName: json.firstName,
            lastName: json.lastName,
            email: json.email,
            birthDate: json.birthDate ? new Date(json.birthDate) : undefined,
            // age: json.age, // DO NOT fetch the age from json
            createdAt: json.createdAt ? new Date(json.createdAt) : undefined,
            personRoles: (() => {
                const prs = json.personRoles;
                return (prs === null || prs === void 0 ? void 0 : prs.map(pr => PersonRole.revive(pr)).filter(pr => pr != undefined)) || [];
            })(),
            uuid: (() => {
                return Identifier.revive(json.uuid);
            })(),
            gender: (() => {
                return Gender.fromString(json.gender);
            })(),
        });
    }
}

// prettier-ignore
class HealthCareProfessional extends Person {
    constructor() {
        super(...arguments);
        // DO NOT make it static, in case you have to customize the toJSON() method
        this.resourceType = 'HealthCareProfessional';
    }
    static revive(json) {
        const newObj = new HealthCareProfessional(undefined);
        if (newObj.resourceType !== json.resourceType) {
            throw new TypeError(`Trying to wrongly deserialize as '${newObj.resourceType}' ${JSON.stringify(json)}`);
        }
        return Object.assign(newObj, Person.personSource(newObj, json), {
            pseudonym: json.pseudonym,
        });
    }
}

class Place {
    constructor() {
        // DO NOT make it static, in case you have to customize the toJSON() method
        this.resourceType = 'Place';
    }
    static revive(json) {
        if (!json) {
            return undefined;
        }
        const newObj = new Place();
        if (newObj.resourceType !== json.resourceType) {
            throw new TypeError(`Trying to wrongly deserialize as '${newObj.resourceType}' ${json}`);
        }
        return Object.assign(newObj, json, {
            city: json.city,
            country: json.country,
            state: json.state,
            district: json.district
        });
    }
}

/**
 * Person address is used to model domicile and residence addresses of a person
 */
class PersonAddress extends Place {
    constructor() {
        super(...arguments);
        // DO NOT make it static, in case you have to customize the toJSON() method
        this.resourceType = 'PersonAddress';
    }
    static revive(json) {
        if (!json) {
            return undefined;
        }
        const newObj = new PersonAddress();
        if (newObj.resourceType !== json.resourceType) {
            throw new TypeError(`Trying to wrongly deserialize as '${newObj.resourceType}' ${json}`);
        }
        return Object.assign(newObj, Place.revive(json), {
            line: json.line,
            postalCode: json.postalCode,
            // use: json.use ? PersonAddress.AddressUse.fromString(json.use) : undefined,
            // type: json.type ? PersonAddress.AddressType.fromString(json.type) : undefined,
            homeType: json.homeType ? PersonAddress.HomeType.fromString(json.homeType) : undefined,
        });
    }
}
(function (PersonAddress) {
    // export enum AddressType {
    //   BOTH = 'both'
    // }
    // export namespace AddressType {
    //   export function fromString(value: string): AddressType | undefined {
    //     if (value === AddressType.BOTH.toString()) {
    //       return AddressType.BOTH;
    //     }
    //     return undefined
    //   }
    // }
    // export enum AddressUse {
    //   HOME = 'home'
    // }
    // export namespace AddressUse {
    //   export function fromString(value: string): AddressUse | undefined {
    //     if ( value === AddressUse.HOME.toString() ) {
    //       return AddressUse.HOME;
    //     }
    //     return undefined
    //   }
    // }
    let HomeType;
    (function (HomeType) {
        HomeType["DOMICILE"] = "domicile";
        HomeType["RESIDENCE"] = "residence";
    })(HomeType = PersonAddress.HomeType || (PersonAddress.HomeType = {}));
    (function (HomeType) {
        function fromString(value) {
            if (value === HomeType.DOMICILE.toString()) {
                return HomeType.DOMICILE;
            }
            else if (value === HomeType.RESIDENCE.toString()) {
                return HomeType.RESIDENCE;
            }
            return undefined;
        }
        HomeType.fromString = fromString;
    })(HomeType = PersonAddress.HomeType || (PersonAddress.HomeType = {}));
})(PersonAddress || (PersonAddress = {}));

// prettier-ignore
class Patient extends Person {
    constructor() {
        super(...arguments);
        // DO NOT make it static, in case you have to customize the toJSON() method
        this.resourceType = 'Patient';
    }
    /**
     * backwards compatibility of the 'pseudonym' attribute
     *
     * @deprecated: use patientIdentifier instead
     */
    get pseudonym() {
        return this.patientIdentifier;
    }
    /**
     * @deprecated: use patientIdentifier instead
     */
    set pseudonym(pseudonym) {
        this.patientIdentifier = pseudonym;
    }
    static revive(json) {
        const newObj = new Patient();
        if (newObj.resourceType !== json.resourceType) {
            throw new TypeError(`Trying to wrongly deserialize as '${newObj.resourceType}' ${json}`);
        }
        return Object.assign(newObj, Person.personSource(newObj, json), {
            patientIdentifier: json.patientIdentifier,
            birthPlace: json.birthPlace ? Place.revive(json.birthPlace) : undefined,
            taxCode: json.taxCode,
            regionalCode: json.regionalCode,
            // notes: json.notes,
            phoneNumber: json.phoneNumber,
            managingOrganization: json.managingOrganization ? Organization.revive(json.managingOrganization) : undefined,
            domicile: json.domicile ? PersonAddress.revive(json.domicile) : undefined,
            residence: json.residence ? PersonAddress.revive(json.residence) : undefined,
        });
    }
    // returns only identifier if the system is missing, otherwise joint using PIPE
    // if the identifier is missing returns ''
    getCompleteIdentifier() {
        var _a;
        const PIPE = '|';
        let toRet = '';
        toRet += this.patientIdentifierSystem ? this.patientIdentifierSystem + PIPE : '';
        toRet += (_a = this.patientIdentifier) !== null && _a !== void 0 ? _a : '';
        return toRet;
    }
}

class User {
    constructor(value) {
        this.resourceType = 'User';
        /**
         * Indicates if the user is currently logged in the system
         */
        this.logged = false;
        /**
         * Indicates if the user is currently enabled or disabled in the system
         *
         * Disabled users must not be able to authenticate themselves
         */
        this.enabled = true;
        this.badges = new Map();
        if (value) {
            Object.assign(this, value);
        }
    }
    /**
     * Set of roles assigned to the user. The actual role list is in the 'person' attribute so this is a logical list.
     */
    get roles() {
        var _a, _b;
        return ((_b = (_a = this.person) === null || _a === void 0 ? void 0 : _a.personRoles) === null || _b === void 0 ? void 0 : _b.map((pr) => pr.role).filter(role => role != undefined)) || [];
    }
    static revive(json) {
        const newObj = Object.create(User.prototype);
        if ('User' !== json.resourceType) {
            throw new TypeError(`Trying to wrongly deserialize as '${newObj.resourceType}' ${JSON.stringify(json)}`);
        }
        if (json.roles) {
            // reset 'roles' attributes as this is a derived values
            json.roles = undefined;
        }
        return Object.assign(newObj, json, {
            person: (() => {
                var _a, _b;
                if (((_a = json.person) === null || _a === void 0 ? void 0 : _a.resourceType) === 'HealthCareProfessional') {
                    return HealthCareProfessional.revive(json.person);
                }
                else if (((_b = json.person) === null || _b === void 0 ? void 0 : _b.resourceType) === 'Patient') {
                    return Patient.revive(json.person);
                }
                else {
                    return undefined;
                }
            })(),
        });
    }
}

class CodedValue {
    constructor(system, code, display, // i18n string
    originalDisplay //needed for backend validation
    ) {
        this.system = system;
        this.code = code;
        this.display = display;
        this.originalDisplay = originalDisplay;
        this.SEPARATOR = "|";
    }
    get uniqueLabelKey() {
        return this.system + this.SEPARATOR + this.code;
    }
}

class CareGiver extends Shareable {
    constructor() {
        super(...arguments);
        this.resourceType = 'CareGiver';
        this.gender = Gender.unknown;
    }
    get name() {
        return this.firstName;
    }
    set name(r) {
        this.firstName = r;
    }
    get relationshipType() {
        return this.relationship.code;
    }
    set relationshipType(r) {
        this.relationship = new CodedValue('', r);
    }
}

class CareTeam extends Shareable {
    constructor() {
        super(...arguments);
        this.resourceType = 'CareTeam';
        this.status = CareTeamStatus.ACTIVE;
    }
    isWholeOrganizationEnabled() {
        // IMPORTANT: 'healthcareProfessionals' is undefined only if the whole organization is enabled (it is empty/filled array otherwise)
        return /*this._wholeOrganizationEnabled || */ !this.healthcareProfessionals; // && this.healthcareProfessionals.length > 0;
    }
}

class Kinship {
    constructor(relative, relationship, relatedPersonId) {
        this.relative = relative;
        this.relationship = relationship;
        this.relatedPersonId = relatedPersonId;
    }
}

class Event extends Shareable {
    constructor(assertedWhen = new Date()) {
        super();
        this.automatic = false;
        this.assertedWhen = assertedWhen;
    }
    toString() {
        return `${this.id}[on: ${this.assertedWhen ? this.assertedWhen.toISOString() : ''}]`;
    }
}

class Measure extends Event {
    constructor() {
        super(...arguments);
        this.resourceType = 'Measure';
        this.status = 'final';
    }
    get healthId() {
        return this._healthId;
    }
    set healthId(value) {
        this._healthId = value;
    }
    get image() {
        return this._image;
    }
    get label() {
        return this._label;
    }
    getName() {
        return `${this.constructor.name}`;
    }
}

class CategoryMeasure extends Measure {
}

class QuantitativeMeasure extends Measure {
    toString() {
        return `${this.constructor.name}: ${this.value} ${this.unit ? this.unit : ''}`;
    }
}

class AlcoholDrinkingFrequency extends CategoryMeasure {
    constructor(value) {
        super();
        this.value = value;
    }
}
// tslint:disable-next-line:no-namespace
(function (AlcoholDrinkingFrequency) {
    let AlcoholDrinkingFrequencyCategory;
    (function (AlcoholDrinkingFrequencyCategory) {
        AlcoholDrinkingFrequencyCategory[AlcoholDrinkingFrequencyCategory["no_drink_per_day"] = 'no_drink_per_day'] = "no_drink_per_day";
        AlcoholDrinkingFrequencyCategory[AlcoholDrinkingFrequencyCategory["less_than_2_drink_per_day"] = 'less_than_2_drink_per_day'] = "less_than_2_drink_per_day";
        AlcoholDrinkingFrequencyCategory[AlcoholDrinkingFrequencyCategory["less_than_3_drink_per_day"] = 'less_than_3_drink_per_day'] = "less_than_3_drink_per_day";
        AlcoholDrinkingFrequencyCategory[AlcoholDrinkingFrequencyCategory["less_than_4_drink_per_day"] = 'less_than_4_drink_per_day'] = "less_than_4_drink_per_day";
        AlcoholDrinkingFrequencyCategory[AlcoholDrinkingFrequencyCategory["more_than_equal_4_drink_per_day"] = 'more_than_equal_4_drink_per_day'] = "more_than_equal_4_drink_per_day";
    })(AlcoholDrinkingFrequencyCategory = AlcoholDrinkingFrequency.AlcoholDrinkingFrequencyCategory || (AlcoholDrinkingFrequency.AlcoholDrinkingFrequencyCategory = {}));
})(AlcoholDrinkingFrequency || (AlcoholDrinkingFrequency = {}));

class SugaryBeverageDrinkingFrequency extends CategoryMeasure {
    constructor(value) {
        super();
        this.value = value;
    }
}
// tslint:disable-next-line:no-namespace
(function (SugaryBeverageDrinkingFrequency) {
    let SugaryBeverageDrinkingFrequencyCategory;
    (function (SugaryBeverageDrinkingFrequencyCategory) {
        SugaryBeverageDrinkingFrequencyCategory[SugaryBeverageDrinkingFrequencyCategory["no_drink_per_day"] = 'no_drink_per_day'] = "no_drink_per_day";
        SugaryBeverageDrinkingFrequencyCategory[SugaryBeverageDrinkingFrequencyCategory["less_than_2_drink_per_day"] = 'less_than_2_drink_per_day'] = "less_than_2_drink_per_day";
        SugaryBeverageDrinkingFrequencyCategory[SugaryBeverageDrinkingFrequencyCategory["less_than_3_drink_per_day"] = 'less_than_3_drink_per_day'] = "less_than_3_drink_per_day";
        SugaryBeverageDrinkingFrequencyCategory[SugaryBeverageDrinkingFrequencyCategory["less_than_4_drink_per_day"] = 'less_than_4_drink_per_day'] = "less_than_4_drink_per_day";
        SugaryBeverageDrinkingFrequencyCategory[SugaryBeverageDrinkingFrequencyCategory["more_than_equal_4_drink_per_day"] = 'more_than_equal_4_drink_per_day'] = "more_than_equal_4_drink_per_day";
    })(SugaryBeverageDrinkingFrequencyCategory = SugaryBeverageDrinkingFrequency.SugaryBeverageDrinkingFrequencyCategory || (SugaryBeverageDrinkingFrequency.SugaryBeverageDrinkingFrequencyCategory = {}));
})(SugaryBeverageDrinkingFrequency || (SugaryBeverageDrinkingFrequency = {}));

class SmokingFrequency extends CategoryMeasure {
    constructor(value) {
        super();
        this.value = value;
        this._image = MeasUiSettings.CIGARETTES.img;
        this._label = SmokingFrequency.TYPE;
    }
    supportVersion() {
        return true;
    }
    toString() {
        return `Smoking [fhir: ${this.fhirId}/_history/${this.version}] ${this.value}`;
    }
}
SmokingFrequency.TYPE = MeasUiSettings.CIGARETTES.label;
// tslint:disable-next-line:no-namespace
(function (SmokingFrequency) {
    let SmokingFrequencyCategory;
    (function (SmokingFrequencyCategory) {
        SmokingFrequencyCategory[SmokingFrequencyCategory["exactly_0_cigarettes_per_day"] = 'exactly_0_cigarettes_per_day'] = "exactly_0_cigarettes_per_day";
        SmokingFrequencyCategory[SmokingFrequencyCategory["lt_eq_5_cigarettes_per_day"] = 'lt_eq_5_cigarettes_per_day'] = "lt_eq_5_cigarettes_per_day";
        SmokingFrequencyCategory[SmokingFrequencyCategory["lt_eq_10_cigarettes_per_day"] = 'lt_eq_10_cigarettes_per_day'] = "lt_eq_10_cigarettes_per_day";
        SmokingFrequencyCategory[SmokingFrequencyCategory["lt_eq_15_cigarettes_per_day"] = 'lt_eq_15_cigarettes_per_day'] = "lt_eq_15_cigarettes_per_day";
        SmokingFrequencyCategory[SmokingFrequencyCategory["lt_eq_20_cigarettes_per_day"] = 'lt_eq_20_cigarettes_per_day'] = "lt_eq_20_cigarettes_per_day";
        SmokingFrequencyCategory[SmokingFrequencyCategory["more_than_20_cigarettes_per_day"] = 'more_than_20_cigarettes_per_day'] = "more_than_20_cigarettes_per_day";
    })(SmokingFrequencyCategory = SmokingFrequency.SmokingFrequencyCategory || (SmokingFrequency.SmokingFrequencyCategory = {}));
})(SmokingFrequency || (SmokingFrequency = {}));

class LifeStyle extends CategoryMeasure {
    constructor(value) {
        super();
        this.value = value;
    }
}
// tslint:disable-next-line:no-namespace
(function (LifeStyle) {
    let LifeStyleCategory;
    (function (LifeStyleCategory) {
        LifeStyleCategory["SEDENTARY"] = "sedentary";
        LifeStyleCategory["POORLY_ACTIVE"] = "poorly_active";
        LifeStyleCategory["ACTIVE"] = "active";
        LifeStyleCategory["VERY_ACTIVE"] = "very_active";
        LifeStyleCategory["ATHLETIC"] = "athletic";
    })(LifeStyleCategory = LifeStyle.LifeStyleCategory || (LifeStyle.LifeStyleCategory = {}));
    (function (LifeStyleCategory) {
        function valueOf(type) {
            if (type === LifeStyleCategory.SEDENTARY.toString()) {
                return LifeStyleCategory.SEDENTARY;
            }
            else if (type === LifeStyleCategory.POORLY_ACTIVE.toString()) {
                return LifeStyleCategory.POORLY_ACTIVE;
            }
            else if (type === LifeStyleCategory.ACTIVE.toString()) {
                return LifeStyleCategory.ACTIVE;
            }
            else if (type === LifeStyleCategory.VERY_ACTIVE.toString()) {
                return LifeStyleCategory.VERY_ACTIVE;
            }
            else if (type === LifeStyleCategory.ATHLETIC.toString()) {
                return LifeStyleCategory.ATHLETIC;
            }
            else {
                return undefined;
            }
        }
        LifeStyleCategory.valueOf = valueOf;
    })(LifeStyleCategory = LifeStyle.LifeStyleCategory || (LifeStyle.LifeStyleCategory = {}));
})(LifeStyle || (LifeStyle = {}));

class TTM extends CategoryMeasure {
    constructor(value) {
        super();
        this.value = value;
    }
}
// tslint:disable-next-line:no-namespace
(function (TTM) {
    let TTMCategory;
    (function (TTMCategory) {
        TTMCategory[TTMCategory["TTM1"] = 'TTM1'] = "TTM1";
        TTMCategory[TTMCategory["TTM2"] = 'TTM2'] = "TTM2";
    })(TTMCategory = TTM.TTMCategory || (TTM.TTMCategory = {}));
})(TTM || (TTM = {}));

var WeightUnit;
(function (WeightUnit) {
    WeightUnit[WeightUnit["kg"] = 'kg'] = "kg";
    WeightUnit[WeightUnit["g"] = 'g'] = "g";
    WeightUnit[WeightUnit["mg"] = 'mg'] = "mg";
})(WeightUnit || (WeightUnit = {}));
(function (WeightUnit) {
    function convert(value, from, to) {
        let newValue = undefined;
        if (from === to) {
            return value;
        }
        if (to == undefined) {
            return value;
        }
        switch (from) {
            case WeightUnit.kg:
                if (to === WeightUnit.g) {
                    newValue = 1000 * value;
                }
                else if (to === WeightUnit.mg) {
                    newValue = 1000 * 1000 * value;
                }
                break;
            case WeightUnit.g:
                if (to === WeightUnit.kg) {
                    newValue = 0.001 * value;
                }
                else if (to === WeightUnit.mg) {
                    newValue = 1000 * value;
                }
                break;
            case WeightUnit.mg:
                if (to === WeightUnit.kg) {
                    newValue = 0.001 * 0.001 * value;
                }
                else if (to === WeightUnit.g) {
                    newValue = 0.001 * value;
                }
                break;
        }
        if (newValue === undefined) {
            console.log(`ERROR: invalid conversion from ${from} to ${to}`);
        }
        return newValue;
    }
    WeightUnit.convert = convert;
})(WeightUnit || (WeightUnit = {}));

var LengthUnit;
(function (LengthUnit) {
    LengthUnit[LengthUnit["km"] = 'km'] = "km";
    LengthUnit[LengthUnit["m"] = 'm'] = "m";
    LengthUnit[LengthUnit["cm"] = 'cm'] = "cm";
})(LengthUnit || (LengthUnit = {}));
(function (LengthUnit) {
    function convert(value, from, to) {
        let newValue = undefined;
        if (from === to) {
            return value;
        }
        if (to == undefined) {
            return value;
        }
        switch (from) {
            case LengthUnit.km:
                if (to === LengthUnit.m) {
                    newValue = 1000 * value;
                }
                else if (to === LengthUnit.cm) {
                    newValue = 100000 * value;
                }
                break;
            case LengthUnit.m:
                if (to === LengthUnit.km) {
                    newValue = 0.001 * value;
                }
                else if (to === LengthUnit.cm) {
                    newValue = 100 * value;
                }
                break;
            case LengthUnit.cm:
                if (to === LengthUnit.km) {
                    newValue = 0.00001 * value;
                }
                else if (to === LengthUnit.m) {
                    newValue = 0.01 * value;
                }
                break;
        }
        if (newValue === undefined) {
            console.log(`ERROR: invalid conversion from ${from} to ${to}`);
        }
        return newValue;
    }
    LengthUnit.convert = convert;
})(LengthUnit || (LengthUnit = {}));

var TemperatureUnit;
(function (TemperatureUnit) {
    TemperatureUnit[TemperatureUnit["CELSIUS"] = 'C'] = "CELSIUS";
    TemperatureUnit[TemperatureUnit["FAHRENHEIT"] = 'F'] = "FAHRENHEIT";
})(TemperatureUnit || (TemperatureUnit = {}));
(function (TemperatureUnit) {
    function convert(value, from, to) {
        let newValue = undefined;
        if (from === to) {
            return value;
        }
        if (to == undefined) {
            return value;
        }
        switch (from) {
            case TemperatureUnit.CELSIUS:
                if (to === TemperatureUnit.FAHRENHEIT) {
                    newValue = (value * (9 / 5)) + 32;
                }
                break;
            case TemperatureUnit.FAHRENHEIT:
                if (to === TemperatureUnit.CELSIUS) {
                    newValue = (value - 32) * (5 / 9);
                }
                break;
        }
        if (newValue === undefined) {
            console.log(`ERROR: invalid conversion from ${from} to ${to}`);
        }
        return newValue;
    }
    TemperatureUnit.convert = convert;
})(TemperatureUnit || (TemperatureUnit = {}));

var ConcentrationUnit;
(function (ConcentrationUnit) {
    ConcentrationUnit[ConcentrationUnit["mmol"] = 'mmol/L'] = "mmol";
    ConcentrationUnit[ConcentrationUnit["mgdL"] = 'mg/dL'] = "mgdL";
    // mgmL = 'mg/mL' as any,
    // perc = '%' as any,
})(ConcentrationUnit || (ConcentrationUnit = {}));
(function (ConcentrationUnit) {
    function convert(value, from, to) {
        let newValue = undefined;
        if (from === to) {
            return value;
        }
        if (to == undefined) {
            return value;
        }
        switch (from) {
            case ConcentrationUnit.mmol:
                if (to === ConcentrationUnit.mgdL) {
                    newValue = 18.0182 * value;
                }
                break;
            case ConcentrationUnit.mgdL:
                if (to === ConcentrationUnit.mmol) {
                    newValue = 0.0555 * value;
                }
                break;
        }
        if (newValue === undefined) {
            console.log(`ERROR: invalid conversion from ${from} to ${to}`);
        }
        return newValue;
    }
    ConcentrationUnit.convert = convert;
})(ConcentrationUnit || (ConcentrationUnit = {}));

var PercentageUnit;
(function (PercentageUnit) {
    PercentageUnit[PercentageUnit["perc"] = '%'] = "perc";
})(PercentageUnit || (PercentageUnit = {}));
// tslint:disable-next-line:no-namespace
(function (PercentageUnit) {
    function convert(value, from, to) {
        if (from === to) {
            return value;
        }
        if (to === undefined) {
            return value;
        }
        console.log(`ERROR: invalid conversion from ${from} to ${to}`);
        return undefined;
    }
    PercentageUnit.convert = convert;
})(PercentageUnit || (PercentageUnit = {}));

class BMI extends QuantitativeMeasure {
    constructor(value) {
        super();
        this.unit = 'kg/m2';
        this._image = MeasUiSettings.BMI.img;
        this._label = BMI.TYPE;
        this.value = value;
    }
    valueIn() {
        // the BMI can't be converted in other units
        return this.value;
    }
    toString() {
        return `BMI: ${this.value.toFixed(2)} ${this.unit}`;
    }
    static calculate(weight, height) {
        const bmi = new BMI();
        const hInM = height.valueIn(LengthUnit.m);
        const wInKg = weight.valueIn(WeightUnit.kg);
        const value = wInKg / Math.pow(hInM, 2);
        bmi.value = Number.parseFloat(value.toFixed(2));
        return bmi;
    }
}
BMI.TYPE = MeasUiSettings.BMI.label;

// import { evaluate as MathjsEvaluate } from 'mathjs';
class Height extends QuantitativeMeasure {
    constructor(value, unit = LengthUnit.cm) {
        super();
        this.unit = LengthUnit.cm;
        this._image = MeasUiSettings.HEIGHT.img;
        this._label = Height.TYPE;
        this.value = value;
        this.unit = unit;
    }
    valueIn(asUnit) {
        return LengthUnit.convert(this.value, this.unit, asUnit);
        // if (asUnit === undefined) {
        //   return this.value;
        // } else if (LengthUnit[this.unit] !== asUnit.toString()) {
        //   return MathjsEvaluate(
        //     `${this.value} ${LengthUnit[this.unit]} to ${asUnit.toString()}`
        //   ).toNumber();
        // } else {
        //   return this.value;
        // }
    }
}
Height.TYPE = MeasUiSettings.HEIGHT.label;

class Waist extends QuantitativeMeasure {
    constructor(value, unit = LengthUnit.cm) {
        super();
        this._image = MeasUiSettings.WAIST.img;
        this._label = Waist.TYPE;
        this.value = value;
        this.unit = unit;
    }
    valueIn(asUnit) {
        return LengthUnit.convert(this.value, this.unit, asUnit);
    }
}
Waist.TYPE = MeasUiSettings.WAIST.label;

class Weight extends QuantitativeMeasure {
    constructor(value, unit = WeightUnit.kg) {
        super();
        this._image = MeasUiSettings.WEIGHT.img;
        this._label = Weight.TYPE;
        this.value = value;
        this.unit = unit;
    }
    valueIn(asUnit) {
        return WeightUnit.convert(this.value, this.unit, asUnit);
    }
}
Weight.TYPE = MeasUiSettings.WEIGHT.label;

// import { evaluate as MathjsEvaluate } from 'mathjs';
class Distance {
    constructor(value, unit = LengthUnit.m) {
        this.value = value;
        this.unit = unit;
    }
    valueIn(asUnit) {
        return LengthUnit.convert(this.value, this.unit, asUnit);
        // if (asUnit === undefined) {
        //     return this.value;
        // } else if (LengthUnit[this.unit] !== asUnit.toString()) {
        //     return MathjsEvaluate(`${this.value} ${LengthUnit[this.unit]} to ${asUnit.toString()}`).toNumber();
        // } else {
        //     return this.value;
        // }
    }
}

class HeartRate extends QuantitativeMeasure {
    constructor(value) {
        super();
        this.unit = 'bpm';
        this._image = MeasUiSettings.HEART_RATE.img;
        this._label = HeartRate.TYPE;
        this.value = value;
    }
}
HeartRate.TYPE = MeasUiSettings.HEART_RATE.label;

// import { MeasUiSettings } from '@config/meas_ui_settings';
class EnergyExpenditure {
    constructor(value) {
        this.unit = 'kcal';
        // this.image = MeasUiSettings.ENERGY_EXPENDITURE.img;
        // this.label = EnergyExpenditure.TYPE;
        this.value = value;
    }
}

class StepCount extends QuantitativeMeasure {
    constructor(value) {
        super();
        this.unit = '';
        this._image = MeasUiSettings.BLOOD_GLUCOSE.img;
        this._label = StepCount.TYPE;
        this.value = value;
    }
    supportVersion() {
        return true;
    }
}
StepCount.TYPE = MeasUiSettings.STEP_COUNT.label;

class SupervisorRequired extends QuantitativeMeasure {
    constructor(value) {
        super();
        this._image = MeasUiSettings.SUPERVISOR_REQUIRED.img;
        this._label = SupervisorRequired.TYPE;
        this.value = value;
    }
    get valueAsBoolean() {
        return this.value > 0;
    }
    set valueAsBoolean(value) {
        this.value = value ? 1 : 0;
    }
}
SupervisorRequired.TYPE = MeasUiSettings.SUPERVISOR_REQUIRED.label;

class Smoker extends QuantitativeMeasure {
    constructor(value) {
        super();
        this._image = MeasUiSettings.SMOKER.img;
        this._label = Smoker.TYPE;
        this.value = value;
    }
    get valueAsBoolean() {
        return this.value > 0;
    }
    set valueAsBoolean(value) {
        this.value = value ? 1 : 0;
    }
}
Smoker.TYPE = MeasUiSettings.SMOKER.label;

class PhysicalInability extends QuantitativeMeasure {
    constructor(value) {
        super();
        this._image = MeasUiSettings.PHYSICAL_INABILITY.img;
        this._label = PhysicalInability.TYPE;
        this.value = value;
    }
    get valueAsBoolean() {
        return this.value > 0;
    }
    set valueAsBoolean(value) {
        this.value = value ? 1 : 0;
    }
}
PhysicalInability.TYPE = MeasUiSettings.PHYSICAL_INABILITY.label;

class BloodGlucose extends QuantitativeMeasure {
    constructor(value, unit = ConcentrationUnit.mmol, measPoint, insulin) {
        super();
        this.max_BG_P1 = 8;
        this.max_BG_P2 = 10;
        this.max_BG_P3 = 13;
        this.max_BG_P4 = 15;
        this.max_BG_P5 = 19;
        this.max_BG_P6 = 22;
        this.max_BG_P7 = 23;
        // this.image = 'fa-user-circle-o';
        this._image = MeasUiSettings.BLOOD_GLUCOSE.img;
        this._label = BloodGlucose.TYPE;
        this.value = value;
        this.unit = unit;
        this.unitLabel = ConcentrationUnit[unit].toString();
        this.measPoint = measPoint;
        this.insulin = insulin;
    }
    valueIn(asUnit) {
        return ConcentrationUnit.convert(this.value, this.unit, asUnit);
        // if (asUnit === undefined) {
        //   return this.value;
        // } else if (ConcentrationUnit[this.unit] !== asUnit.toString()) {
        //   return MathjsEvaluate(
        //     `${this.value} ${ConcentrationUnit[this.unit]} to ${asUnit.toString()}`
        //   ).toNumber();
        // } else {
        //   return this.value;
        // }
    }
    // FIXME: should take nemes from some other place not from FeedbackInApp
    estimateMeasPoint() {
        if (!this.measPoint && this.assertedWhen) {
            const measurementTime = getHours(this.assertedWhen);
            if (measurementTime <= this.max_BG_P1) {
                this.measPoint = FeedbackInAppTypeName.BG_P1;
            }
            else if (measurementTime <= this.max_BG_P2) {
                this.measPoint = FeedbackInAppTypeName.BG_P2;
            }
            else if (measurementTime <= this.max_BG_P3) {
                this.measPoint = FeedbackInAppTypeName.BG_P3;
            }
            else if (measurementTime <= this.max_BG_P4) {
                this.measPoint = FeedbackInAppTypeName.BG_P4;
            }
            else if (measurementTime <= this.max_BG_P5) {
                this.measPoint = FeedbackInAppTypeName.BG_P5;
            }
            else if (measurementTime <= this.max_BG_P6) {
                this.measPoint = FeedbackInAppTypeName.BG_P6;
            }
            else {
                this.measPoint = FeedbackInAppTypeName.BG_P1;
            }
        }
    }
}
BloodGlucose.TYPE = MeasUiSettings.BLOOD_GLUCOSE.label;
// tslint:disable-next-line:no-namespace
(function (BloodGlucose) {
    let DrugStatement;
    (function (DrugStatement) {
        DrugStatement[DrugStatement["TAKEN"] = 'TAKEN'] = "TAKEN";
        DrugStatement[DrugStatement["NOT_TAKEN"] = 'NOT_TAKEN'] = "NOT_TAKEN";
    })(DrugStatement = BloodGlucose.DrugStatement || (BloodGlucose.DrugStatement = {}));
})(BloodGlucose || (BloodGlucose = {}));

class CaloricDailyIntake extends QuantitativeMeasure {
    constructor(value) {
        super();
        this.unit = 'kcal/d';
        this._image = MeasUiSettings.CALORIC_DAILY_INTAKE.img;
        this._label = CaloricDailyIntake.TYPE;
        this.value = value;
    }
    valueIn() {
        // the CaloricDailyIntake can't be converted in other units
        return this.value;
    }
    toString() {
        return `CaloricDailyIntake: ${this.value.toFixed(2)} ${this.unit}`;
    }
}
CaloricDailyIntake.TYPE = MeasUiSettings.CALORIC_DAILY_INTAKE.label;

class CarbohydratesDailyIntake extends QuantitativeMeasure {
    constructor(value) {
        super();
        this.unit = 'g/d';
        this._image = MeasUiSettings.CARBOHYDRATES_DAILY_INTAKE.img;
        this._label = CarbohydratesDailyIntake.TYPE;
        this.value = value;
    }
    valueIn() {
        // the CarbohydratesDailyIntake can't be converted in other units
        return this.value;
    }
    toString() {
        return `CarbohydratesDailyIntake: ${this.value.toFixed(2)} ${this.unit}`;
    }
}
CarbohydratesDailyIntake.TYPE = MeasUiSettings.CARBOHYDRATES_DAILY_INTAKE.label;

class ProteinsDailyIntake extends QuantitativeMeasure {
    constructor(value) {
        super();
        this.unit = 'g/d';
        this._image = MeasUiSettings.PROTEINS_DAILY_INTAKE.img;
        this._label = ProteinsDailyIntake.TYPE;
        this.value = value;
    }
    valueIn() {
        // the ProteinsDailyIntake can't be converted in other units
        return this.value;
    }
    toString() {
        return `ProteinsDailyIntake: ${this.value.toFixed(2)} ${this.unit}`;
    }
}
ProteinsDailyIntake.TYPE = MeasUiSettings.PROTEINS_DAILY_INTAKE.label;

class FatsDailyIntake extends QuantitativeMeasure {
    constructor(value) {
        super();
        this.unit = 'g/d';
        this._image = MeasUiSettings.FATS_DAILY_INTAKE.img;
        this._label = FatsDailyIntake.TYPE;
        this.value = value;
    }
    valueIn() {
        // the FatsDailyIntake can't be converted in other units
        return this.value;
    }
    toString() {
        return `FatsDailyIntake: ${this.value.toFixed(2)} ${this.unit}`;
    }
}
FatsDailyIntake.TYPE = MeasUiSettings.FATS_DAILY_INTAKE.label;

class FibersDailyIntake extends QuantitativeMeasure {
    constructor(value) {
        super();
        this.unit = 'g/d';
        this._image = MeasUiSettings.FIBERS_DAILY_INTAKE.img;
        this._label = FibersDailyIntake.TYPE;
        this.value = value;
    }
    valueIn() {
        // the FibersDailyIntake can't be converted in other units
        return this.value;
    }
    toString() {
        return `FibersDailyIntake: ${this.value.toFixed(2)} ${this.unit}`;
    }
}
FibersDailyIntake.TYPE = MeasUiSettings.FIBERS_DAILY_INTAKE.label;

class BloodPressure extends QuantitativeMeasure {
    constructor(systolic, diastolic) {
        super();
        this.systolic = systolic;
        this.diastolic = diastolic;
        this.unit = 'mmHg';
        this._image = MeasUiSettings.ARTERIAL_PRESSURE.img;
        this._label = BloodPressure.TYPE;
    }
    toString() {
        return `BloodPressure: ${this.systolic ? this.systolic.toString() : '-'} ${this.diastolic ? this.diastolic.toString() : '-'}`;
    }
}
BloodPressure.TYPE = MeasUiSettings.ARTERIAL_PRESSURE.label;

class SodiumDailyIntake extends QuantitativeMeasure {
    constructor(value) {
        super();
        this.unit = 'g/die';
        this._image = MeasUiSettings.SODIUM_DAILY_INTAKE.img;
        this._label = SodiumDailyIntake.TYPE;
        this.value = value;
    }
    valueIn() {
        // the FatsDailyIntake can't be converted in other units
        return this.value;
    }
    toString() {
        return `SodiumDailyIntake: ${this.value.toFixed(2)} ${this.unit}`;
    }
}
SodiumDailyIntake.TYPE = MeasUiSettings.SODIUM_DAILY_INTAKE.label;

class FruitPortionsDailyIntake extends QuantitativeMeasure {
    constructor(value) {
        super();
        this.unit = 'portions/d';
        this._image = MeasUiSettings.FRUIT_PORTIONS_DAILY_INTAKE.img;
        this._label = FruitPortionsDailyIntake.TYPE;
        this.value = value;
    }
    valueIn() {
        // the FruitPortionsDailyIntake can't be converted in other units
        return this.value;
    }
    toString() {
        return `FruitPortionsDailyIntake: ${this.value.toFixed(2)} ${this.unit}`;
    }
}
FruitPortionsDailyIntake.TYPE = MeasUiSettings.FRUIT_PORTIONS_DAILY_INTAKE.label;

class VegetablesPortionsDailyIntake extends QuantitativeMeasure {
    constructor(value) {
        super();
        this.unit = 'portions/d';
        this._image = MeasUiSettings.VEGETABLES_PORTIONS_DAILY_INTAKE.img;
        this._label = VegetablesPortionsDailyIntake.TYPE;
        this.value = value;
    }
    valueIn() {
        // the VegetablesPortionsDailyIntake can't be converted in other units
        return this.value;
    }
    toString() {
        return `VegetablesPortionsDailyIntake: ${this.value.toFixed(2)} ${this.unit}`;
    }
}
VegetablesPortionsDailyIntake.TYPE = MeasUiSettings.VEGETABLES_PORTIONS_DAILY_INTAKE.label;

class SystolicBloodPressure extends QuantitativeMeasure {
    constructor(value) {
        super();
        this.unit = 'mmHg';
        this._image = MeasUiSettings.SYS_PRESSURE.img;
        this._label = SystolicBloodPressure.TYPE;
        this.value = value;
    }
    valueIn() {
        // the SystolicBloodPressure can't be converted in other units
        return this.value;
    }
    toString() {
        return `SystolicBloodPressure: ${this.value} ${this.unit}`;
    }
}
SystolicBloodPressure.TYPE = MeasUiSettings.SYS_PRESSURE.label;

class DiastolicBloodPressure extends QuantitativeMeasure {
    constructor(value) {
        super();
        this.unit = 'mmHg';
        this._image = MeasUiSettings.DIA_PRESSURE.img;
        this._label = DiastolicBloodPressure.TYPE;
        this.value = value;
    }
    valueIn() {
        // the DiastolicBloodPressure can't be converted in other units
        return this.value;
    }
    toString() {
        return `DiastolicBloodPressure: ${this.value} ${this.unit}`;
    }
}
DiastolicBloodPressure.TYPE = MeasUiSettings.DIA_PRESSURE.label;

class Hba1c extends QuantitativeMeasure {
    constructor(value, unit = PercentageUnit.perc) {
        super();
        // this.image = 'fa-user-circle-o';
        this._image = MeasUiSettings.HBA1C.img;
        this._label = Hba1c.TYPE;
        this.value = value;
        this.unit = unit;
    }
    valueIn(asUnit) {
        return PercentageUnit.convert(this.value, this.unit, asUnit);
    }
}
Hba1c.TYPE = MeasUiSettings.HBA1C.label;

class SpO2 extends QuantitativeMeasure {
    constructor(value, unit = PercentageUnit.perc) {
        super();
        // this.image = 'fa-user-circle-o';
        this._image = MeasUiSettings.SPO2.img;
        this._label = SpO2.TYPE;
        this.value = value;
        this.unit = unit;
    }
    valueIn(asUnit) {
        return PercentageUnit.convert(this.value, this.unit, asUnit);
    }
}
SpO2.TYPE = MeasUiSettings.SPO2.label;

class Cholesterol extends QuantitativeMeasure {
    constructor(value, unit = ConcentrationUnit.mgdL) {
        super();
        // this.image = 'fa-user-circle-o';
        this._image = MeasUiSettings.BLOOD_GLUCOSE.img;
        this._label = Cholesterol.TYPE;
        this.value = value;
        this.unit = unit;
    }
    valueIn(asUnit) {
        return ConcentrationUnit.convert(this.value, this.unit, asUnit);
        // if (asUnit === undefined) {
        //   return this.value;
        // } else if (ConcentrationUnit[this.unit] !== asUnit.toString()) {
        //   return MathjsEvaluate(
        //     `${this.value} ${ConcentrationUnit[this.unit]} to ${asUnit.toString()}`
        //   ).toNumber();
        // } else {
        //   return this.value;
        // }
    }
}
Cholesterol.TYPE = MeasUiSettings.CHOLESTEROL.label;

class CholesterolHdl extends QuantitativeMeasure {
    constructor(value, unit = ConcentrationUnit.mgdL) {
        super();
        // this.image = 'fa-user-circle-o';
        this._image = MeasUiSettings.HDL.img;
        this._label = CholesterolHdl.TYPE;
        this.value = value;
        this.unit = unit;
        this.unitLabel = ConcentrationUnit[unit].toString();
    }
    valueIn(asUnit) {
        return ConcentrationUnit.convert(this.value, this.unit, asUnit);
        // if (asUnit === undefined) {
        //   return this.value;
        // } else if (ConcentrationUnit[this.unit] !== asUnit.toString()) {
        //   return MathjsEvaluate(
        //     `${this.value} ${ConcentrationUnit[this.unit]} to ${asUnit.toString()}`
        //   ).toNumber();
        // } else {
        //   return this.value;
        // }
    }
}
CholesterolHdl.TYPE = MeasUiSettings.HDL.label;

class CholesterolLdl extends QuantitativeMeasure {
    constructor(value, unit = ConcentrationUnit.mgdL) {
        super();
        // this.image = 'fa-user-circle-o';
        this._image = MeasUiSettings.BLOOD_GLUCOSE.img;
        this._label = CholesterolLdl.TYPE;
        this.value = value;
        this.unit = unit;
        this.unitLabel = ConcentrationUnit[unit].toString();
    }
    valueIn(asUnit) {
        return ConcentrationUnit.convert(this.value, this.unit, asUnit);
        // if (asUnit === undefined) {
        //   return this.value;
        // } else if (ConcentrationUnit[this.unit] !== asUnit.toString()) {
        //   return MathjsEvaluate(
        //     `${this.value} ${ConcentrationUnit[this.unit]} to ${asUnit.toString()}`
        //   ).toNumber();
        // } else {
        //   return this.value;
        // }
    }
}
CholesterolLdl.TYPE = MeasUiSettings.LDL.label;

class Triglyceride extends QuantitativeMeasure {
    constructor(value, unit = ConcentrationUnit.mgdL) {
        super();
        // this.image = 'fa-user-circle-o';
        this._image = MeasUiSettings.BLOOD_GLUCOSE.img;
        this._label = Triglyceride.TYPE;
        this.value = value;
        this.unit = unit;
        this.unitLabel = ConcentrationUnit[unit].toString();
    }
    valueIn(asUnit) {
        return ConcentrationUnit.convert(this.value, this.unit, asUnit);
        // if (asUnit === undefined) {
        //   return this.value;
        // } else if (ConcentrationUnit[this.unit] !== asUnit.toString()) {
        //   return MathjsEvaluate(
        //     `${this.value} ${ConcentrationUnit[this.unit]} to ${asUnit.toString()}`
        //   ).toNumber();
        // } else {
        //   return this.value;
        // }
    }
}
Triglyceride.TYPE = MeasUiSettings.TRIGLYCERIDE.label;

// import { evaluate as MathjsEvaluate } from 'mathjs';
class BodyTemperature extends QuantitativeMeasure {
    constructor(value, unit = TemperatureUnit.CELSIUS) {
        super();
        this.unit = TemperatureUnit.CELSIUS;
        this._image = MeasUiSettings.TEMP.img;
        this._label = BodyTemperature.TYPE;
        this.value = value;
        this.unit = unit;
    }
    valueIn(asUnit) {
        return TemperatureUnit.convert(this.value, this.unit, asUnit);
        // if (asUnit === undefined) {
        //   return this.value;
        // } else if (TemperatureUnit[this.unit] !== asUnit.toString()) {
        //   return MathjsEvaluate(
        //     `${this.value} deg${TemperatureUnit[this.unit]} to deg${asUnit.toString()}`
        //   ).toNumber();
        // } else {
        //   return this.value;
        // }
    }
}
BodyTemperature.TYPE = MeasUiSettings.TEMP.label;

class COVIDSymptoms extends Measure {
    constructor(value) {
        super();
        this.nasalCongestion = false;
        this.soreThroat = false;
        this.fever = false;
        this.fatigue = false;
        this.cough = false;
        this.lossOfTasteAndSmell = false;
        this.conjunctivitis = false;
        this._image = MeasUiSettings.COVID.img;
        this._label = MeasUiSettings.COVID.label;
    }
}
// tslint:disable-next-line:no-namespace
var CoughType;
(function (CoughType) {
    let CoughTypeCategory;
    (function (CoughTypeCategory) {
        CoughTypeCategory[CoughTypeCategory["dry_cough"] = 'dry_cough'] = "dry_cough";
        CoughTypeCategory[CoughTypeCategory["wet_cough"] = 'wet_cough'] = "wet_cough";
    })(CoughTypeCategory = CoughType.CoughTypeCategory || (CoughType.CoughTypeCategory = {}));
})(CoughType || (CoughType = {}));

class PatientHealthStatus extends CategoryMeasure {
    constructor(value) {
        super();
        this.value = value;
    }
}
// tslint:disable-next-line:no-namespace
(function (PatientHealthStatus) {
    let PatientHealthStatusCategory;
    (function (PatientHealthStatusCategory) {
        PatientHealthStatusCategory[PatientHealthStatusCategory["POOR"] = 'poor'] = "POOR";
        PatientHealthStatusCategory[PatientHealthStatusCategory["FAIR"] = 'fair'] = "FAIR";
        PatientHealthStatusCategory[PatientHealthStatusCategory["GOOD"] = 'good'] = "GOOD";
    })(PatientHealthStatusCategory = PatientHealthStatus.PatientHealthStatusCategory || (PatientHealthStatus.PatientHealthStatusCategory = {}));
    (function (PatientHealthStatusCategory) {
        function valueOf(type) {
            if (type === PatientHealthStatusCategory.POOR.toString()) {
                return PatientHealthStatusCategory.POOR;
            }
            else if (type === PatientHealthStatusCategory.FAIR.toString()) {
                return PatientHealthStatusCategory.FAIR;
            }
            else if (type === PatientHealthStatusCategory.GOOD.toString()) {
                return PatientHealthStatusCategory.GOOD;
            }
            else {
                return undefined;
            }
        }
        PatientHealthStatusCategory.valueOf = valueOf;
    })(PatientHealthStatusCategory = PatientHealthStatus.PatientHealthStatusCategory || (PatientHealthStatus.PatientHealthStatusCategory = {}));
})(PatientHealthStatus || (PatientHealthStatus = {}));

class ChestPainLevel extends QuantitativeMeasure {
    constructor(value) {
        super();
        this._label = ChestPainLevel.TYPE;
        this.value = value;
    }
}
ChestPainLevel.TYPE = MeasUiSettings.CHEST_PAIN_LEVEL.label;

class ChestPainQuestionnaire extends QuantitativeMeasure {
    constructor(value) {
        super();
        this._label = ChestPainQuestionnaire.TYPE;
        this.value = value;
    }
}
ChestPainQuestionnaire.TYPE = MeasUiSettings.CHEST_PAIN_Q.label;

class ObservePatient extends Shareable {
    constructor() {
        super(...arguments);
        this.resourceType = 'ObservePatient';
    }
    toString() {
        return `ObservePatient[${this.id} - ${this.fhirId}] ${this.status}`;
    }
    toJSON() {
        var _a, _b;
        const o = {
            assertedWhen: this.assertedWhen,
            patientId: (_a = this.patient) === null || _a === void 0 ? void 0 : _a.id,
            practitionerId: (_b = this.practitioner) === null || _b === void 0 ? void 0 : _b.id,
            status: this.status,
            resourceType: this.resourceType,
        };
        return o; // passed to stringify
    }
    static revive(json) {
        const newObj = Object.create(ObservePatient.prototype);
        if (json.resourceType && newObj.resourceType !== json.resourceType) {
            throw new TypeError(`Trying to wrongly deserialize as '${newObj.resourceType}' ${json}`);
        }
        const ps = Object.assign(newObj, json, {});
        if (!!json.patientId) {
            ps.patient = new Patient(json.patientId);
        }
        if (!!json.practitionerId) {
            ps.practitioner = new HealthCareProfessional(json.practitionerId);
        }
        return ps;
    }
}

class Intensity {
    constructor(label, description, image) {
        this.label = label;
        this.description = description;
        this.image = image;
    }
}

class ModerateWorkoutDurationInWeek extends QuantitativeMeasure {
    constructor() {
        super();
        this._image = MeasUiSettings.PHYSICAL_ACTIVITY.img;
        this._label = ModerateWorkoutDurationInWeek.TYPE;
    }
}
ModerateWorkoutDurationInWeek.TYPE = MeasUiSettings.PHYSICAL_ACTIVITY.label;

class VigorousWorkoutDurationInWeek extends QuantitativeMeasure {
    constructor() {
        super();
        // duration in minutes
        this.value = 0;
        this.unit = 'min';
        this._image = MeasUiSettings.PHYSICAL_ACTIVITY.img;
        this._label = VigorousWorkoutDurationInWeek.TYPE;
    }
    setDuration(start, end) {
        this.value = differenceInMinutes(end, start);
    }
}
VigorousWorkoutDurationInWeek.TYPE = MeasUiSettings.PHYSICAL_ACTIVITY.label;

class Procedure extends Event {
    get fhirId() {
        return this._fhirId;
    }
    set fhirId(value) {
        this._fhirId = value;
    }
    get healthId() {
        return this._healthId;
    }
    set healthId(value) {
        this._healthId = value;
    }
    get image() {
        return this._image;
    }
    get label() {
        return this._label;
    }
    getDurationInMinutes() {
        return differenceInMinutes(this.performedTo, this.performedSince);
    }
}

class Workout extends Procedure {
    constructor() {
        super();
        this.resourceType = 'Procedure';
        this._image = MeasUiSettings.PHYSICAL_ACTIVITY.img;
        this._label = Workout.TYPE;
    }
    toString() {
        let toRet = `Workout [Type: ${WorkoutType[this.workoutType]} Intensity:${this.intensity}] Since: ${this.performedSince} To: ${this.performedTo} Asserted: ${this.assertedWhen}`;
        if (this.energyExpenditure) {
            toRet += ` ${this.energyExpenditure}`;
        }
        if (this.stepCount) {
            toRet += ` ${this.stepCount}`;
        }
        // if (this.heartRateMeasures) {
        //   toRet += ` ${this.heartRateMeasures}`;
        // }
        return toRet;
    }
}
Workout.TYPE = MeasUiSettings.PHYSICAL_ACTIVITY.label;
var WorkoutIntensity;
(function (WorkoutIntensity) {
    WorkoutIntensity[WorkoutIntensity["LIGHT"] = 'light'] = "LIGHT";
    WorkoutIntensity[WorkoutIntensity["MODERATE"] = 'moderate'] = "MODERATE";
    WorkoutIntensity[WorkoutIntensity["VIGOROUS"] = 'vigorous'] = "VIGOROUS";
})(WorkoutIntensity || (WorkoutIntensity = {}));
var WorkoutType;
(function (WorkoutType) {
    WorkoutType[WorkoutType["WALKING"] = 0] = "WALKING";
    WorkoutType[WorkoutType["JOGGING"] = 1] = "JOGGING";
    WorkoutType[WorkoutType["CYCLING"] = 2] = "CYCLING";
    WorkoutType[WorkoutType["FITNESS"] = 3] = "FITNESS";
    WorkoutType[WorkoutType["BODY_BUILDING"] = 4] = "BODY_BUILDING";
    WorkoutType[WorkoutType["SOCCER"] = 5] = "SOCCER";
    WorkoutType[WorkoutType["TENNIS"] = 6] = "TENNIS";
    WorkoutType[WorkoutType["VOLLEY"] = 7] = "VOLLEY";
    WorkoutType[WorkoutType["BASKET"] = 8] = "BASKET";
    WorkoutType[WorkoutType["GENERIC_SPORT"] = 9] = "GENERIC_SPORT";
    WorkoutType[WorkoutType["GENERIC_AEROBIC_ACTIVITY"] = 10] = "GENERIC_AEROBIC_ACTIVITY";
    WorkoutType[WorkoutType["GENERIC_ANAEROBIC_ACTIVITY"] = 11] = "GENERIC_ANAEROBIC_ACTIVITY";
    WorkoutType[WorkoutType["GENERIC_STRENGTH_ACTIVITY"] = 12] = "GENERIC_STRENGTH_ACTIVITY";
    WorkoutType[WorkoutType["SWIMMING"] = 13] = "SWIMMING";
    WorkoutType[WorkoutType["YOGA"] = 14] = "YOGA";
})(WorkoutType || (WorkoutType = {}));

class WorkoutSessionInWeek extends QuantitativeMeasure {
    constructor() {
        super();
        this.unit = 'session/week';
        this._image = MeasUiSettings.PHYSICAL_ACTIVITY.img;
        this._label = WorkoutSessionInWeek.TYPE;
    }
}
WorkoutSessionInWeek.TYPE = MeasUiSettings.PHYSICAL_ACTIVITY.label;

class Food {
    constructor() {
        this.imagePrefix = 'res://food_';
        this.labelPrefix = 'nutrition.label.food_';
        this.portionLabelPrefix = 'nutrition.portion.food_'; // da aggiungere il typeid
        this.portionLabelSuffix = '.'; // da aggiungere small/medium/large
        this.customLabel = 'nutrition.portion.custom';
        this.details = {};
    }
    setType(t) {
        // tslint:disable-next-line:triple-equals
        if (t == undefined) {
            console.log('[ERROR] Trying to set an undefined type for the food');
        }
        else {
            this.type = t;
            this.image = this.imagePrefix + t;
            this.label = this.labelPrefix + t;
        }
    }
    /**
     * This mehtod can be invoked only if the object has all the data about the portions.
     * Otherwise you have to directly set the attribute 'details'
     *
     * @param portionSize
     */
    recalculatePortionNutrients(portionSize) {
        this.portionSize = portionSize;
        if (this.small === undefined ||
            this.medium === undefined ||
            this.large === undefined) {
            throw new Error('Invalid status of the Food object. Check its initialization');
        }
        if (this.portionSize === Food.PortionSize.SMALL) {
            return (this.details = this.small);
        }
        else if (this.portionSize === Food.PortionSize.MEDIUM) {
            return (this.details = this.medium);
        }
        else if (this.portionSize === Food.PortionSize.LARGE) {
            return (this.details = this.large);
        }
        else {
            return (this.details = undefined);
        }
    }
    toString() {
        return `[${this.id}] ${this.image} ${this.label}: SMALL[${this.small}] REGULAR[${this.medium}] HUGE[${this.large}]`;
    }
    getSmallGrams() {
        if (this.type !== Food.FoodType.ALCOHOL) {
            return '(' + this.small.weightInGrams + this.getUnit() + ')';
        }
        return '';
    }
    getMediumGrams() {
        if (this.type !== Food.FoodType.ALCOHOL) {
            return '(' + this.medium.weightInGrams + this.getUnit() + ')';
        }
        return '';
    }
    getLargeGrams() {
        if (this.type !== Food.FoodType.ALCOHOL) {
            return '(' + this.large.weightInGrams + this.getUnit() + ')';
        }
        return '';
    }
    getUnit() {
        if (this.type !== Food.FoodType.ALCOHOL &&
            this.type !== Food.FoodType.SUGARY_DRINKS) {
            return 'g';
        }
        else {
            return 'ml';
        }
    }
    // public getCustomGrams() {
    //     if (this.type !== Food.FoodType.ALCOHOL) {
    //         return '(' + this.custom.weightInGrams + 'g)';
    //     }
    //     return '';
    // }
    getSmallLabel() {
        return this.small.label;
    }
    getMediumLabel() {
        return this.medium.label;
    }
    getLargeLabel() {
        return this.large.label;
    }
    // public getCustomLabel(): string {
    //     return this.custom.label;
    // }
    getPortionSizeLabel() {
        let suffix;
        if (this.portionSize) {
            switch (this.portionSize) {
                case Food.PortionSize.SMALL:
                    suffix = 'small';
                    break;
                case Food.PortionSize.MEDIUM:
                    suffix = 'medium';
                    break;
                case Food.PortionSize.LARGE:
                    suffix = 'large';
                    break;
                case Food.PortionSize.CUSTOM:
                    // suffix = 'custom';
                    return this.customLabel;
                default:
                    suffix = 'small';
                    break;
            }
            // switch (this.portionSize.toString()) {
            //     case '0':
            //     case 'SMALL':
            //         suffix = 'small';
            //         break;
            //     case '1':
            //     case 'MEDIUM':
            //         suffix = 'medium';
            //         break;
            //     case '2':
            //     case 'LARGE':
            //         suffix = 'large';
            //         break;
            //     default:
            //         suffix = 'medium';
            //         break;
            // }
            // return this.portionLabelPrefix + this.type + this.portionLabelSuffix + this.portionSize.toString().toLowerCase();
            return (this.portionLabelPrefix + this.type + this.portionLabelSuffix + suffix);
        }
        else {
            return ''; // non dovrebbe mai restituire questo
        }
    }
    setCustomNutrients(customGrams) {
        if (customGrams > 0) {
            this.portionSize = Food.PortionSize.CUSTOM;
            let currentDetail;
            let ratio = 1;
            if (this.medium) {
                // caso in cui il Food è generato dal JSON e non dal DB
                ratio = customGrams / this.medium.weightInGrams;
                currentDetail = this.medium;
            }
            else if (this.details) {
                // caso in cui il Food è lett dal DB, quindi ci sono solo i dettagli della scelta precedente
                ratio = customGrams / this.details.weightInGrams;
                currentDetail = this.details;
            }
            else {
                throw new Error('Invalid status of the Food PORTION. Check its REVIVE or INIT');
            }
            const customDetails = {};
            customDetails.label = 'nutrition.portion.custom';
            customDetails.weightInGrams = customGrams;
            customDetails.caloricIntake = ratio * currentDetail.caloricIntake;
            customDetails.carbsInKcal = ratio * currentDetail.carbsInKcal;
            customDetails.fatsInKcal = ratio * currentDetail.fatsInKcal;
            customDetails.fibersInGrams = ratio * currentDetail.fibersInGrams;
            customDetails.proteinsInKcal = ratio * currentDetail.proteinsInKcal;
            customDetails.sodiumInMilliGrams =
                ratio * currentDetail.sodiumInMilliGrams;
            this.details = customDetails;
        }
        else {
            this.portionSize = Food.PortionSize.MEDIUM;
            this.recalculatePortionNutrients(this.portionSize);
            console.log(`[ERROR] ${this.constructor.name}#setCustomNutrients rcvd customGrams: ${customGrams}. Returned Medium Portion Size statically`);
        }
    }
    reCalculatePortionSize(completeFood) {
        if (this.details.weightInGrams === completeFood.small.weightInGrams) {
            return Food.PortionSize.SMALL;
        }
        else if (this.details.weightInGrams === completeFood.medium.weightInGrams) {
            return Food.PortionSize.MEDIUM;
        }
        else if (this.details.weightInGrams === completeFood.large.weightInGrams) {
            return Food.PortionSize.LARGE;
        }
        else {
            return Food.PortionSize.CUSTOM;
        }
    }
    static revive(json) {
        return Object.assign(new Food(), json, {});
    }
}
// tslint:disable-next-line:no-namespace
(function (Food) {
    let PortionSize;
    (function (PortionSize) {
        PortionSize[PortionSize["SMALL"] = 1] = "SMALL";
        PortionSize[PortionSize["MEDIUM"] = 2] = "MEDIUM";
        PortionSize[PortionSize["LARGE"] = 3] = "LARGE";
        PortionSize[PortionSize["CUSTOM"] = 4] = "CUSTOM";
    })(PortionSize = Food.PortionSize || (Food.PortionSize = {}));
    let FoodType;
    (function (FoodType) {
        FoodType[FoodType["PASTA_RICE"] = 1] = "PASTA_RICE";
        FoodType[FoodType["WHOLEMEAL_PASTA_RICE"] = 2] = "WHOLEMEAL_PASTA_RICE";
        FoodType[FoodType["DRIED_LEGUMES"] = 3] = "DRIED_LEGUMES";
        FoodType[FoodType["MEAT"] = 4] = "MEAT";
        FoodType[FoodType["SWEETS"] = 5] = "SWEETS";
        FoodType[FoodType["VEGETABLES"] = 6] = "VEGETABLES";
        FoodType[FoodType["EGG"] = 7] = "EGG";
        FoodType[FoodType["FISH"] = 8] = "FISH";
        FoodType[FoodType["SAVORY_SNACK"] = 9] = "SAVORY_SNACK";
        FoodType[FoodType["FRUIT"] = 10] = "FRUIT";
        FoodType[FoodType["POTATOES"] = 11] = "POTATOES";
        FoodType[FoodType["FRESH_DAIRY_PRODUCTS"] = 12] = "FRESH_DAIRY_PRODUCTS";
        FoodType[FoodType["DRIED_FRUITS"] = 13] = "DRIED_FRUITS";
        FoodType[FoodType["FAST_FOOD"] = 14] = "FAST_FOOD";
        FoodType[FoodType["ALCOHOL"] = 15] = "ALCOHOL";
        FoodType[FoodType["SUGARY_DRINKS"] = 16] = "SUGARY_DRINKS";
        FoodType[FoodType["OIL"] = 17] = "OIL";
        FoodType[FoodType["COLD_CUTS"] = 18] = "COLD_CUTS";
        FoodType[FoodType["SEASONED_DAIRY_PRODUCTS"] = 19] = "SEASONED_DAIRY_PRODUCTS";
        FoodType[FoodType["MILK_YOGURT"] = 20] = "MILK_YOGURT";
        FoodType[FoodType["BREAD"] = 21] = "BREAD";
        FoodType[FoodType["SALAD"] = 22] = "SALAD";
        FoodType[FoodType["SUGAR"] = 23] = "SUGAR";
        FoodType[FoodType["COOKIE"] = 24] = "COOKIE";
        FoodType[FoodType["CROISSANT"] = 25] = "CROISSANT";
        FoodType[FoodType["MARMALADE"] = 26] = "MARMALADE";
        FoodType[FoodType["PIZZA"] = 27] = "PIZZA";
        FoodType[FoodType["FRESH_LEGUMES"] = 28] = "FRESH_LEGUMES";
        FoodType[FoodType["CAKES"] = 29] = "CAKES";
        FoodType[FoodType["ICE_CREAM"] = 30] = "ICE_CREAM";
        FoodType[FoodType["BANANA"] = 31] = "BANANA";
        FoodType[FoodType["SALT"] = 32] = "SALT";
    })(FoodType = Food.FoodType || (Food.FoodType = {}));
})(Food || (Food = {}));

// FIXME: MODEL non dovrà più dipendere da FHIR
class Meal extends Measure {
    constructor() {
        super();
        this.resourceType = 'Meal';
        this.foods = [];
        this._image = MeasUiSettings.MEAL_ACTIVITY.img;
        this._label = Meal.TYPE;
    }
    supportVersion() {
        return true;
    }
    calculateKcal() {
        let kcal = 0;
        if (this.foods && this.foods.length) {
            for (const f of this.foods) {
                kcal += f.details.caloricIntake;
            }
        }
        return kcal;
    }
    calculateCarbsInKcal() {
        let carbs = 0;
        if (this.foods && this.foods.length) {
            for (const f of this.foods) {
                carbs += f.details.carbsInKcal;
            }
        }
        return carbs;
    }
    toString() {
        return `Meal ${this.type} [fhir: ${this.fhirId}/_history/${this.version}]`;
    }
}
Meal.TYPE = MeasUiSettings.MEAL_ACTIVITY.label;
var MealType;
(function (MealType) {
    MealType[MealType["SNACK"] = 'SNACK'] = "SNACK";
    MealType[MealType["BREAKFAST"] = 'BREAKFAST'] = "BREAKFAST";
    MealType[MealType["LUNCH"] = 'LUNCH'] = "LUNCH";
    MealType[MealType["DINNER"] = 'DINNER'] = "DINNER";
})(MealType || (MealType = {}));

class Sport {
    // mix = true se il tipo di workout dipenda dall'intensità a cui è stato svolto l'esercizio
    constructor(img, label, selectable, selected, min, max) {
        this.img = img;
        this.label = label;
        this.selectable = selectable;
        this.selected = selected;
        // this.toShowForTypes = sportIntensity;
        this.minIntensity = min;
        this.maxIntensity = max;
        this.mix = max > 2 && min <= 2;
    }
    toString() {
        return `SPORT: ${this.img} - ${this.label}`;
    }
}
// tslint:disable-next-line:no-namespace
(function (Sport) {
    let SportIntensity;
    (function (SportIntensity) {
        SportIntensity[SportIntensity["LIGHT"] = 0] = "LIGHT";
        SportIntensity[SportIntensity["MODERATE"] = 1] = "MODERATE";
        SportIntensity[SportIntensity["VIGOROUS"] = 2] = "VIGOROUS";
        SportIntensity[SportIntensity["EXTREME"] = 3] = "EXTREME";
    })(SportIntensity = Sport.SportIntensity || (Sport.SportIntensity = {}));
})(Sport || (Sport = {}));

class ChromosomePosition {
}

class GenomicVariant extends Measure {
    constructor(id, genomicSource) {
        super();
        // id presente in sharable (number)
        this.resourceType = "GenomicVariant";
        this.incidental = false;
        this.id = id;
        this._genomicSource = genomicSource;
    }
}

class Quality {
    constructor(allelicReadDepth, totalReadDepth, sampleAllelicFrequency) {
        this.allelicReadDepth = allelicReadDepth;
        this.totalReadDepth = totalReadDepth;
        this.sampleAllelicFrequency = sampleAllelicFrequency;
        if (!this.allelicReadDepth || !this.totalReadDepth || !this.sampleAllelicFrequency) {
            if (this.allelicReadDepth && this.totalReadDepth) {
                this.sampleAllelicFrequency = (this.allelicReadDepth / this.totalReadDepth);
            }
            else if (this.allelicReadDepth && this.sampleAllelicFrequency) {
                this.totalReadDepth = Math.round(this.allelicReadDepth / this.sampleAllelicFrequency);
            }
            else if (this.totalReadDepth && this.sampleAllelicFrequency) {
                this.allelicReadDepth = Math.round(this.totalReadDepth * this.sampleAllelicFrequency);
            }
        }
        if (sampleAllelicFrequency) {
        }
        else if (this.totalReadDepth && this.allelicReadDepth) {
            this.sampleAllelicFrequency = this.allelicReadDepth / this.totalReadDepth;
        }
        if (allelicReadDepth && totalReadDepth) {
            this.allelicBalance = allelicReadDepth / totalReadDepth;
            this.refAllelicReadDepth = totalReadDepth - allelicReadDepth;
        }
        // 05/06 commentati perché nella nuova versione ci arrivano già calcolati
        // this.allelicDepthCov = this.coverage*(1-this.frequency);
        // this.allelicDepthNotCov = this.coverage*(this.frequency);
        // this.allelicDepth = ""+this.allelicDepthCov+"/"+this.allelicDepthNotCov
    }
}

class Significance {
}

class TherapeuticImplication extends Measure {
    constructor(id) {
        super();
        this.resourceType = "TherapeuticImplication";
        // actionable? : string; // elenco di farmaci - non strutturato
        this.actionable = [];
        this.id = id;
    }
}

class DiagnosticImplication extends Measure {
    constructor(id) {
        super();
        this.resourceType = "DiagnosticImplication";
        // utilizzato per costruire il codice OMIM
        this.predictedPhenotype = []; // FIXME: questo impatta converter e gui - possibile: 1 stringa, tante stringhe molto lunghe (ellipsis con espansione al click)
        this.id = id;
    }
}

class Genotype extends Measure {
    constructor(id) {
        super();
        this.resourceType = "Genotype";
        this.haplotypes = [];
        this.id = id;
    }
}

class Haplotype extends Measure {
    constructor(id) {
        super();
        this.resourceType = "Haplotype";
        this.id = id;
    }
}

class RegionStudied extends Measure {
    constructor(id) {
        super();
        this.resourceType = "RegionStudied";
        this.id = id;
    }
    simplifiedRegionStudied() {
        if (this.value.toLowerCase().startsWith(RegionStudied.PREFIX)) {
            return this.value.substring(RegionStudied.PREFIX.length);
        }
        return this.value;
    }
}
RegionStudied.PREFIX = "coverage on the gene region:";

class Vcf extends Shareable {
    constructor() {
        super(...arguments);
        this.resourceType = "VCF";
    }
}

class VcfMetadata extends Shareable {
    constructor() {
        super(...arguments);
        this.resourceType = 'VcfMetadata';
    }
}

class Study extends Shareable {
    constructor() {
        super(...arguments);
        this.resourceType = "Study";
    }
}

class MolecularConsequence extends Measure {
    constructor(id) {
        super();
        this.resourceType = "MolecularConsequence";
        this.featureConsequences = [];
        this.id = id;
    }
}

/**
 * The Answer model the basic answer item that can be assigned to a Questionnaire question item
 */
class Answer {
    constructor() {
        this.resourceType = 'BackboneElement';
    }
    answersByQuestionId(groupId) {
        var _a;
        return (_a = this.answers) === null || _a === void 0 ? void 0 : _a.filter(a => a.questionId == groupId);
    }
}

/**
 * Model a structured group of questionnaire answers (see QuestionnaireResponse Item)
 */
class AnswerGroup {
    constructor() {
        this.resourceType = 'BackboneElement';
    }
    /**
     * Alias of 'groupId'
     */
    get questionId() {
        return this.groupId;
    }
    answersByQuestionId(groupId) {
        var _a;
        return (_a = this.answers) === null || _a === void 0 ? void 0 : _a.filter(a => a.questionId == groupId);
    }
}

class Choice {
    constructor(value, label) {
        this.value = value;
        this.generateLabel(label);
    }
    getLabel() {
        var _a;
        return (_a = this.label) !== null && _a !== void 0 ? _a : this.generateLabel();
    }
    generateLabel(label) {
        var _a;
        if (label) {
            this.label = label;
        }
        else if (this.value && this.value instanceof CodedValue) {
            this.label = (_a = this.value.display) !== null && _a !== void 0 ? _a : this.value.uniqueLabelKey;
        }
        else {
            this.label = this.value + '';
        }
        return this.label;
    }
}

var QuestionType;
(function (QuestionType) {
    QuestionType[QuestionType["boolean"] = 0] = "boolean";
    QuestionType[QuestionType["integer"] = 1] = "integer";
    QuestionType[QuestionType["decimal"] = 2] = "decimal";
    QuestionType[QuestionType["text"] = 3] = "text";
    QuestionType[QuestionType["string"] = 4] = "string";
    QuestionType[QuestionType["CodedValue"] = 5] = "CodedValue";
    QuestionType[QuestionType["date"] = 6] = "date";
    // WARN: to support dateTime we need a material component with the time and the QuestionnaireReponse serializer must support both 'date' and 'dateTime'
    // dateTime,
    // a 'display' question has no answer
    QuestionType[QuestionType["display"] = 7] = "display";
})(QuestionType || (QuestionType = {}));

class AbstractQuestion {
    constructor() {
        // TODO: da investigare
        this.readOnly = false;
    }
}

class Question extends AbstractQuestion {
    constructor() {
        super(...arguments);
        this.resourceType = 'Questionnaire.Question';
        this.min = 0; // valore minimo della risposta qualora fosse di tipo int
    }
    hasClosedAnswer() {
        var _a;
        if (Array.isArray(this.permittedAnswers) && ((_a = this.permittedAnswers) === null || _a === void 0 ? void 0 : _a.length) > 0) {
            return true;
        }
        return false;
    }
}

class QuestionGroup extends AbstractQuestion {
    constructor() {
        super(...arguments);
        this.resourceType = 'Questionnaire.Group';
        this.items = [];
        /**
         * Used to indicate if there is any sub question that is mandatory -> so the star should be rendered also in the father's title
         * THIS DOES NOT IMPACT THE FORM VALIDATOR - it's only for usability purpose
         */
        this.showSubStar = false;
    }
    /**
     * @deprecated
     */
    set name(name) {
        this.text = name;
    }
    /**
     * @deprecated
     */
    get name() {
        return this.text;
    }
    /**
     * @deprecated
     */
    get questionId() {
        return this.groupId;
    }
    /**
     * @deprecated
     */
    set questionId(questionId) {
        this.groupId = questionId;
    }
}

class QuestionEnableWhenCondition {
}

class QuestionEnableWhen {
}

var QuestionEnableWhenOperator;
(function (QuestionEnableWhenOperator) {
    QuestionEnableWhenOperator[QuestionEnableWhenOperator["EXISTS"] = 0] = "EXISTS";
    QuestionEnableWhenOperator[QuestionEnableWhenOperator["EQ"] = 1] = "EQ";
    QuestionEnableWhenOperator[QuestionEnableWhenOperator["NE"] = 2] = "NE";
    QuestionEnableWhenOperator[QuestionEnableWhenOperator["GT"] = 3] = "GT";
    QuestionEnableWhenOperator[QuestionEnableWhenOperator["GE"] = 4] = "GE";
    QuestionEnableWhenOperator[QuestionEnableWhenOperator["LT"] = 5] = "LT";
    QuestionEnableWhenOperator[QuestionEnableWhenOperator["LE"] = 6] = "LE";
})(QuestionEnableWhenOperator || (QuestionEnableWhenOperator = {}));
;

class QuestionnaireResponse extends Shareable {
    constructor(q) {
        super();
        this.resourceType = 'QuestionnaireResponse';
        this.questionnaire = q;
        this.date = new Date();
    }
    answersByQuestionId(groupId) {
        var _a;
        return (_a = this.answers) === null || _a === void 0 ? void 0 : _a.filter(a => a.questionId == groupId);
    }
}
var ResponseStatus;
(function (ResponseStatus) {
    ResponseStatus["inprogress"] = "in-progress";
    ResponseStatus["completed"] = "completed";
    ResponseStatus["amended"] = "amended";
    ResponseStatus["enteredinerror"] = "entered-in-error";
    ResponseStatus["stopped"] = "stopped";
})(ResponseStatus || (ResponseStatus = {}));
(function (ResponseStatus) {
    function valueOf(type) {
        if (type === ResponseStatus.inprogress.toString()) {
            return ResponseStatus.inprogress;
        }
        else if (type === ResponseStatus.completed.toString()) {
            return ResponseStatus.completed;
        }
        else if (type === ResponseStatus.amended.toString()) {
            return ResponseStatus.amended;
        }
        else if (type === ResponseStatus.enteredinerror.toString()) {
            return ResponseStatus.enteredinerror;
        }
        else if (type === ResponseStatus.stopped.toString()) {
            return ResponseStatus.stopped;
        }
        else {
            return undefined;
        }
    }
    ResponseStatus.valueOf = valueOf;
})(ResponseStatus || (ResponseStatus = {}));

class Questionnaire extends Shareable {
    constructor(questionnaireId, items = []) {
        super();
        this.resourceType = 'Questionnaire';
        this.questionnaireId = questionnaireId;
        this.items = items;
    }
}

class GenericQuantitativeMeasure extends QuantitativeMeasure {
    constructor(value, code, unit, components) {
        var _a, _b;
        super();
        this.SEPARATOR = '|';
        if (Number.isFinite(value)) {
            this.value = value;
        }
        else if (value instanceof Choice && value.value instanceof CodedValue) {
            this.cv = new CodedValue(value.value.system, value.value.code, value.getLabel());
        }
        this.cvType = code;
        this.unit = unit;
        this.unitLabel = unit === null || unit === void 0 ? void 0 : unit.code;
        this.components = components;
        this._label = ((_a = this.cvType) === null || _a === void 0 ? void 0 : _a.system) + this.SEPARATOR + ((_b = this.cvType) === null || _b === void 0 ? void 0 : _b.code);
    }
    fromQuantitativeMeasure(measure) {
        // FIXME does not set the code (cvType) because it is not set in the quantitative measure
        this.value = measure.value;
        this.unit = measure.unit;
        this._label = measure.label;
    }
    toString() {
        return `${this.cvType.uniqueLabelKey} : ${this.value}`;
    }
}

class GenericQuantitativeFormStructure {
}

class QuantitativeSectionFormStructure {
}

class CodedValueQuestion extends Question {
    constructor() {
        super(...arguments);
        this.resourceType = 'CodedValueQuestion';
        // derived value (e.g. BMI)
        this.readonly = false;
    }
    hasClosedAnswer() {
        var _a;
        if (Array.isArray(this.permittedAnswers) && ((_a = this.permittedAnswers) === null || _a === void 0 ? void 0 : _a.length) > 0) {
            return true;
        }
        return false;
    }
}

var measurements = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get AlcoholDrinkingFrequency () { return AlcoholDrinkingFrequency; },
    BMI: BMI,
    get BloodGlucose () { return BloodGlucose; },
    BloodPressure: BloodPressure,
    BodyTemperature: BodyTemperature,
    COVIDSymptoms: COVIDSymptoms,
    CaloricDailyIntake: CaloricDailyIntake,
    CarbohydratesDailyIntake: CarbohydratesDailyIntake,
    CategoryMeasure: CategoryMeasure,
    ChestPainLevel: ChestPainLevel,
    ChestPainQuestionnaire: ChestPainQuestionnaire,
    Cholesterol: Cholesterol,
    CholesterolHdl: CholesterolHdl,
    CholesterolLdl: CholesterolLdl,
    ChromosomePosition: ChromosomePosition,
    CodedValueQuestion: CodedValueQuestion,
    get ConcentrationUnit () { return ConcentrationUnit; },
    get CoughType () { return CoughType; },
    DiagnosticImplication: DiagnosticImplication,
    DiastolicBloodPressure: DiastolicBloodPressure,
    Distance: Distance,
    EnergyExpenditure: EnergyExpenditure,
    Event: Event,
    FatsDailyIntake: FatsDailyIntake,
    FibersDailyIntake: FibersDailyIntake,
    get Food () { return Food; },
    FruitPortionsDailyIntake: FruitPortionsDailyIntake,
    GenericQuantitativeFormStructure: GenericQuantitativeFormStructure,
    GenericQuantitativeMeasure: GenericQuantitativeMeasure,
    GenomicVariant: GenomicVariant,
    Genotype: Genotype,
    Haplotype: Haplotype,
    Hba1c: Hba1c,
    HeartRate: HeartRate,
    Height: Height,
    Intensity: Intensity,
    get LengthUnit () { return LengthUnit; },
    get LifeStyle () { return LifeStyle; },
    Meal: Meal,
    get MealType () { return MealType; },
    Measure: Measure,
    ModerateWorkoutDurationInWeek: ModerateWorkoutDurationInWeek,
    MolecularConsequence: MolecularConsequence,
    ObservePatient: ObservePatient,
    get PatientHealthStatus () { return PatientHealthStatus; },
    get PercentageUnit () { return PercentageUnit; },
    PhysicalInability: PhysicalInability,
    Procedure: Procedure,
    ProteinsDailyIntake: ProteinsDailyIntake,
    Quality: Quality,
    QuantitativeMeasure: QuantitativeMeasure,
    QuantitativeSectionFormStructure: QuantitativeSectionFormStructure,
    RegionStudied: RegionStudied,
    Significance: Significance,
    Smoker: Smoker,
    get SmokingFrequency () { return SmokingFrequency; },
    SodiumDailyIntake: SodiumDailyIntake,
    SpO2: SpO2,
    get Sport () { return Sport; },
    StepCount: StepCount,
    Study: Study,
    get SugaryBeverageDrinkingFrequency () { return SugaryBeverageDrinkingFrequency; },
    SupervisorRequired: SupervisorRequired,
    SystolicBloodPressure: SystolicBloodPressure,
    get TTM () { return TTM; },
    get TemperatureUnit () { return TemperatureUnit; },
    TherapeuticImplication: TherapeuticImplication,
    Triglyceride: Triglyceride,
    Vcf: Vcf,
    VcfMetadata: VcfMetadata,
    VegetablesPortionsDailyIntake: VegetablesPortionsDailyIntake,
    VigorousWorkoutDurationInWeek: VigorousWorkoutDurationInWeek,
    Waist: Waist,
    Weight: Weight,
    get WeightUnit () { return WeightUnit; },
    Workout: Workout,
    get WorkoutIntensity () { return WorkoutIntensity; },
    WorkoutSessionInWeek: WorkoutSessionInWeek,
    get WorkoutType () { return WorkoutType; }
});

class CategoryTarget {
    constructor(targetVariable, thresholdValue) {
        this.classname = 'CategoryTarget';
        this.targetVariable = targetVariable;
        this.thresholdValue = thresholdValue;
    }
    static revive(json) {
        const targetVariable = json.targetVariable_ === 'Weight' ? Weight : measurements[json.targetVariable_];
        const thresholdValue = json.thresholdValue; // TargetQuantity.revive(json.thresholdValue);
        return Object.assign(new CategoryTarget(), json, {
            targetVariable,
            thresholdValue,
        });
    }
    getReadable() {
        return `${this.thresholdValue}`;
    }
    toString() {
        return (this.targetVariable ? this.targetVariable.name : '<no type>') + this.thresholdValue;
    }
}
// tslint:disable-next-line:no-namespace
// export namespace QuantitativeTarget {
//     export enum RelationalOperator {LT = '<' as any, LE = '<=' as any, GT = '>' as any, GE = '>=' as any, EQ = '==' as any }
// }

/**
 * This class is used to model the activities required for a specific procedure
 *
 * They are just text (at most there is a number to quantify them)
 */
class GoalInternalActivity {
    constructor() {
        this.enabled = true;
    }
    toString() {
        return `[${this.id}, ${this.enabled}] ${this.label} [${this.value}]`;
    }
    static revive(json) {
        return Object.assign(new GoalInternalActivity(), json, {});
    }
}

class TargetQuantity {
    constructor(magnitude, unit, system) {
        this.magnitude = magnitude;
        this.unit = unit;
        this.system = system;
    }
    toString() {
        return `${this.magnitude} ${this.unit}`;
    }
    static revive(json) {
        return Object.assign(new TargetQuantity(-1, '', ''), json, {});
    }
}

class QuantitativeTarget {
    constructor(targetVariable, thresholdValue, operator = QuantitativeTarget.RelationalOperator.EQ) {
        this.classname = 'QuantitativeTarget';
        this.targetVariable = targetVariable;
        this.thresholdValue = thresholdValue;
        this.operator = operator;
    }
    static revive(json) {
        // const op = json.operator ? QuantitativeTarget.RelationalOperator[json.operator] : undefined;
        const thresholdValue = TargetQuantity.revive(json.thresholdValue);
        const targetVariable = json.targetVariable_ === 'Weight' ? Weight : measurements[json.targetVariable_];
        if (!targetVariable) {
            console.log(`[ERROR] Unresolved QuantitativeTarget targetVariable as measurements: ${json.targetVariable_}`);
        }
        return Object.assign(new QuantitativeTarget(), json, {
            // operator : op,
            targetVariable,
            thresholdValue,
        });
    }
    getReadable() {
        return `${this.thresholdValue}`;
    }
    toString() {
        return `Target[${this.targetVariable ? this.targetVariable.name : ''}: ${this.operator} ${this.thresholdValue}]`;
    }
}
// tslint:disable-next-line:no-namespace
(function (QuantitativeTarget) {
    let RelationalOperator;
    (function (RelationalOperator) {
        RelationalOperator[RelationalOperator["LT"] = '<'] = "LT";
        RelationalOperator[RelationalOperator["LE"] = '<='] = "LE";
        RelationalOperator[RelationalOperator["GT"] = '>'] = "GT";
        RelationalOperator[RelationalOperator["GE"] = '>='] = "GE";
        RelationalOperator[RelationalOperator["EQ"] = '=='] = "EQ";
    })(RelationalOperator = QuantitativeTarget.RelationalOperator || (QuantitativeTarget.RelationalOperator = {}));
})(QuantitativeTarget || (QuantitativeTarget = {}));

class RangeTarget {
    constructor(targetVariable, minThresholdValue, maxThresholdValue) {
        this.targetVariable = targetVariable;
        this.minThresholdValue = minThresholdValue;
        this.maxThresholdValue = maxThresholdValue;
    }
    static revive(json) {
        const minThresholdValue = TargetQuantity.revive(json.minThresholdValue);
        const maxThresholdValue = TargetQuantity.revive(json.maxThresholdValue);
        const targetVariable = json.targetVariable_ === 'Weight' ? Weight : measurements[json.targetVariable_];
        if (!targetVariable) {
            console.log(`[ERROR] Unresolved RangeTarget targetVariable as measurements: ${json.targetVariable_}`);
        }
        return Object.assign(new RangeTarget(), json, {
            maxThresholdValue,
            minThresholdValue,
            targetVariable,
        });
    }
    getReadable() {
        return `${this.minThresholdValue}-${this.maxThresholdValue}`;
    }
    toString() {
        return `${this.targetVariable.name}: [${this.minThresholdValue}, ${this.maxThresholdValue}]`;
    }
}

class Goal extends Shareable {
    /** OLD CONSTRUCTOR - with a single target
     * public constructor(target?: Target, recommender?: Person) {
      super();
      this.target = target;
      this.recommender = recommender;
    }*/
    constructor(targets, recommender) {
        super();
        this.resourceType = 'Goal';
        this.status = Goal.GoalStatus.UNKNOWN;
        /**set multiple targets. So Target is declared as array
        public target: Target;
        */
        this.targets = [];
        this.targets = targets;
        this.recommender = recommender;
    }
    /**
     * La data di fine è calcolabile solo se:
     * i) esiste una durata
     * ii) è nota la data di inizio (i.e. il goal è in progress o planned)
     */
    getGoalEndDate() {
        if (!this.startedOn || !this.durationInDays) {
            return undefined;
        }
        return addDays(this.startedOn, this.durationInDays);
    }
    /**
     * La durata è calcolabile solo se:
     * ii) è nota la data di inizio (i.e. il goal è in progress o planned)
     */
    setGoalEndDate(d) {
        if (!this.startedOn) {
            return;
        }
        this.durationInDays = Math.round((d.getTime() - this.startedOn.getTime()) / (1000 * 60 * 60 * 24));
    }
    /**
     * La data di 'scadenza' è calcolabile solo se:
     * i) esiste un periodo di validità del goal
     * ii) è nota la data di proposizione (i.e. il goal è in progress o planned)
     */
    getAcceptanceEndDate() {
        if (!this.proposedOn || !this.acceptanceDurationInDays) {
            return undefined;
        }
        return addDays(this.proposedOn, this.acceptanceDurationInDays);
    }
    /**
     * READ: This goal has been replaced by <OTHER GOAL>
     */
    set proposedReplacementOf(g) {
        this._proposedReplacementOf = g;
        if (g && this !== g._replacement) {
            g._replacement = this;
        }
    }
    get proposedReplacementOf() {
        return this._proposedReplacementOf;
    }
    /**
     * READ: This goal is a replacement (ie. is replacing) of <OTHER GOAL>
     */
    set replacement(g) {
        this._replacement = g;
        if (g && this !== g._proposedReplacementOf) {
            g._proposedReplacementOf = this;
        }
    }
    get replacement() {
        return this._replacement;
    }
    get editedByPractitioner() {
        // && (this.recommender instanceof Practitioner); // fa crashare il sitema
        return this.recommender && this.recommender.constructor === HealthCareProfessional;
    }
    set type(type) {
        this._type = type;
        // const gSetting = GoalsUiSettings[type];
        // if (gSetting) {
        //     this._imageSrc = gSetting.img;
        //     this._description = gSetting.desc;
        // }
    }
    get type() {
        return this._type;
    }
    /**
     * targets come array
     */
    toString() {
        return `Goal{[${this.id} - ${this.fhirId}/_history/${this.version}], type=${this._type}, status=${this.status}, target=[${this.targets.map((t) => t.toString()).join(', ')}] recommender=${this.recommender}}`;
    }
    /**
    * target singolo
    public toString(): string {
      return `Goal{[${this.id} - ${this.fhirId}/_history/${this.version}], type=${this._type}, status=${this.status}, target=${this.targets} recommender=${this.recommender}}`;
    }*/
    supportVersion() {
        return true;
    }
    findMilestoneByType(type, status) {
        if (this.milestones) {
            for (const m of this.milestones) {
                if (m.type.toString() === type && (!status || status === m.status)) {
                    return m;
                }
                else {
                    const subMilestone = m.findMilestoneByType(type, status);
                    if (subMilestone) {
                        return subMilestone;
                    }
                }
            }
        }
        return undefined;
    }
    findMilestoneById(id) {
        if (this.id === id) {
            return this;
        }
        if (this.milestones) {
            for (const m of this.milestones) {
                if (m.id === id) {
                    return m;
                }
            }
            for (const m of this.milestones) {
                const subMilestone = m.findMilestoneById(id);
                if (subMilestone) {
                    return subMilestone;
                }
            }
        }
        return undefined;
    }
    findMilestoneByFhirId(fhirId) {
        const prefixedFhirId = 'Goal/' + fhirId;
        if (this.fhirId === fhirId || this.fhirId === prefixedFhirId) {
            return this;
        }
        if (this.milestones) {
            for (const m of this.milestones) {
                if (m.fhirId === fhirId || m.fhirId === prefixedFhirId) {
                    return m;
                }
            }
            for (const m of this.milestones) {
                const subMilestone = m.findMilestoneByFhirId(fhirId);
                if (subMilestone) {
                    return subMilestone;
                }
            }
        }
        return undefined;
    }
    /**
     * restituisce true se data attuale > della data finale getGoalEndedDate
     */
    isGoalEnded() {
        const now = new Date();
        const goalEndDate = this.getGoalEndDate();
        if (goalEndDate) {
            const end = new Date(goalEndDate);
            return isBefore(end, now) || isSameDay(end, now);
        }
        else {
            return false;
        }
    }
    /**
     *
     * restituisce la percentuale di tempo trascorso tra la data di creazione goal e la acceptance duration max date.
     *
     *  1 - goal non può essere più accettato
     *  <1 - goal ancora accettabile
     *
     * se la getAcceptanceEndDate non c'è restituirà -1
     * se la proposedOn non c'è restituirà -1
     *
     */
    getAcceptanceDurationCompletionPercentage() {
        const accEndDate = this.getAcceptanceEndDate();
        if (accEndDate === undefined || this.proposedOn === undefined) {
            return -1;
        }
        const accMax = accEndDate.valueOf();
        const now = new Date().valueOf();
        const accMin = this.proposedOn.valueOf();
        const perc = 1 - (accMax - now) / (accMax - accMin);
        return perc;
    }
    /**
     * revive su target come array
     */
    static revive(json, onlyEnabled = false) {
        // Revive the nested Target array
        let targets = [];
        //it should be an array of targets
        const jsonTargets = json.target;
        //check if jsonTarget is an array
        if (jsonTargets && Array.isArray(jsonTargets)) {
            targets = jsonTargets.map((jsonTarget) => {
                if (jsonTarget.classname === QuantitativeTarget.name) {
                    return QuantitativeTarget.revive(jsonTarget);
                }
                else if (jsonTarget.classname === RangeTarget.name) {
                    return RangeTarget.revive(jsonTarget);
                }
                else {
                    return CategoryTarget.revive(jsonTarget);
                }
            });
        }
        /**
         * revive su target come singolo elemento
        public static revive(json: any, onlyEnabled: boolean = false): Goal {
          // Revive the nested Target
          let target: Target;
          const jsonTarget: any = json.target;
          if (jsonTarget) {
            if (jsonTarget.classname === QuantitativeTarget.name) {
              target = QuantitativeTarget.revive(jsonTarget);
            } else if (jsonTarget.classname === RangeTarget.name) {
              target = RangeTarget.revive(jsonTarget);
            } else {
              target = CategoryTarget.revive(jsonTarget);
            }
          }*/
        // Revive the Status
        let status;
        const jsonStatus = json.status;
        status = jsonStatus === undefined ? Goal.GoalStatus.UNKNOWN : Goal.GoalStatus[Goal.GoalStatus[jsonStatus]];
        // Revive the nested Goals
        let milestones;
        if (json.milestones) {
            milestones = [];
            for (const sgJson of json.milestones) {
                if (!onlyEnabled || sgJson.enabled) {
                    // recursively revive enabled milestones (if specified)
                    milestones.push(Goal.revive(sgJson, onlyEnabled));
                }
            }
        }
        // Revive the nested Activities
        let activites;
        if (json.activites) {
            activites = [];
            for (const actJson of json.activites) {
                activites.push(GoalInternalActivity.revive(actJson));
            }
        }
        return Object.assign(new Goal(), json, {
            // recommender : Patient.revive(json.recommender),
            activites: activites,
            milestones: milestones,
            status: status,
            targets: targets,
        });
    }
}
// tslint:disable-next-line:no-namespace
(function (Goal) {
    let GoalStatus;
    (function (GoalStatus) {
        GoalStatus[GoalStatus["UNKNOWN"] = 0] = "UNKNOWN";
        GoalStatus[GoalStatus["ACHIEVED"] = 1] = "ACHIEVED";
        GoalStatus[GoalStatus["CANCELLED"] = 2] = "CANCELLED";
        GoalStatus[GoalStatus["FAILED"] = 3] = "FAILED";
        GoalStatus[GoalStatus["NOT_ACCEPTED"] = 4] = "NOT_ACCEPTED";
        GoalStatus[GoalStatus["ACTIVE"] = 5] = "ACTIVE";
        GoalStatus[GoalStatus["CANDIDATE_FOR_PROPOSAL"] = 6] = "CANDIDATE_FOR_PROPOSAL";
        GoalStatus[GoalStatus["PROPOSED"] = 7] = "PROPOSED";
        GoalStatus[GoalStatus["NOT_APPROVED"] = 8] = "NOT_APPROVED";
        GoalStatus[GoalStatus["REJECTED"] = 9] = "REJECTED";
        GoalStatus[GoalStatus["PLANNED"] = 10] = "PLANNED";
    })(GoalStatus = Goal.GoalStatus || (Goal.GoalStatus = {}));
})(Goal || (Goal = {}));

var GoalTypeName;
(function (GoalTypeName) {
    GoalTypeName[GoalTypeName["FAT_LOSS"] = 'fat_loss_goal'] = "FAT_LOSS";
    GoalTypeName[GoalTypeName["WAIST_REDUCTION"] = 'waist_goal'] = "WAIST_REDUCTION";
    GoalTypeName[GoalTypeName["BMI"] = 'bmi_goal'] = "BMI";
    GoalTypeName[GoalTypeName["WEIGHT"] = 'weight_goal'] = "WEIGHT";
    GoalTypeName[GoalTypeName["PHYSICAL_ACTIVITY"] = 'physical_activity_goal'] = "PHYSICAL_ACTIVITY";
    GoalTypeName[GoalTypeName["MODERATE_PHYSICAL_ACTIVITY"] = 'moderate_physical_activity_goal'] = "MODERATE_PHYSICAL_ACTIVITY";
    GoalTypeName[GoalTypeName["VIGOROUS_PHYSICAL_ACTIVITY"] = 'vigorous_physical_activity_goal'] = "VIGOROUS_PHYSICAL_ACTIVITY";
    GoalTypeName[GoalTypeName["STRENGTH_PHYSICAL_ACTIVITY"] = 'strength_physical_activity_goal'] = "STRENGTH_PHYSICAL_ACTIVITY";
    GoalTypeName[GoalTypeName["STEPS"] = 'steps'] = "STEPS";
    GoalTypeName[GoalTypeName["ADOPT_HEALTHY_NUTRITION"] = 'adopt_healthy_nutrition_goal'] = "ADOPT_HEALTHY_NUTRITION";
    GoalTypeName[GoalTypeName["CALORIC_INTAKE"] = 'caloric_intake_goal'] = "CALORIC_INTAKE";
    GoalTypeName[GoalTypeName["CARBOHYDRATES_INTAKE"] = 'carbohydrates_intake_goal'] = "CARBOHYDRATES_INTAKE";
    GoalTypeName[GoalTypeName["PROTEINS_INTAKE"] = 'proteins_intake_goal'] = "PROTEINS_INTAKE";
    GoalTypeName[GoalTypeName["FATS_INTAKE"] = 'fats_intake_goal'] = "FATS_INTAKE";
    GoalTypeName[GoalTypeName["FIBERS_INTAKE"] = 'fibers_intake_goal'] = "FIBERS_INTAKE";
    GoalTypeName[GoalTypeName["SUGARY_BEVERAGE_INTAKE"] = 'sugary_beverage_intake_goal'] = "SUGARY_BEVERAGE_INTAKE";
    GoalTypeName[GoalTypeName["ALCOHOL_INTAKE"] = 'alcohol_intake_goal'] = "ALCOHOL_INTAKE";
    GoalTypeName[GoalTypeName["SODIUM_INTAKE"] = 'sodium_intake_goal'] = "SODIUM_INTAKE";
    GoalTypeName[GoalTypeName["FRUIT_PORTIONS_DAILY_INTAKE"] = 'fruit_portions_intake_goal'] = "FRUIT_PORTIONS_DAILY_INTAKE";
    GoalTypeName[GoalTypeName["VEGETABLES_PORTIONS_DAILY_INTAKE"] = 'vegetables_portions_intake_goal'] = "VEGETABLES_PORTIONS_DAILY_INTAKE";
    GoalTypeName[GoalTypeName["ADOPT_HEALTHY_HABITS"] = 'adopt_healthy_habits_goal'] = "ADOPT_HEALTHY_HABITS";
    GoalTypeName[GoalTypeName["STOP_SMOKING"] = 'stop_smoking_goal'] = "STOP_SMOKING";
    GoalTypeName[GoalTypeName["HEALTHY_PHYSIOLOGICAL_MAINTAINANCE"] = 'healthy_physiological_parameters_maintenance_goal'] = "HEALTHY_PHYSIOLOGICAL_MAINTAINANCE";
    GoalTypeName[GoalTypeName["BLOOD_PRESSURE_MAINTAINANCE"] = 'blood_pressure_maintenance_goal'] = "BLOOD_PRESSURE_MAINTAINANCE";
    GoalTypeName[GoalTypeName["BLOOD_GLUCOSE_MAINTAINANCE"] = 'blood_glucose_maintenance_goal'] = "BLOOD_GLUCOSE_MAINTAINANCE";
    GoalTypeName[GoalTypeName["HBA1C_MAINTAINANCE"] = 'hba1c_maintenance_goal'] = "HBA1C_MAINTAINANCE";
    GoalTypeName[GoalTypeName["CHOLESTEROL_MAINTAINANCE"] = 'cholesterol_maintenance_goal'] = "CHOLESTEROL_MAINTAINANCE";
    GoalTypeName[GoalTypeName["CHOLESTEROL_HDL_MAINTAINANCE"] = 'cholesterol_hdl_maintenance_goal'] = "CHOLESTEROL_HDL_MAINTAINANCE";
    GoalTypeName[GoalTypeName["CHOLESTEROL_LDL_MAINTAINANCE"] = 'cholesterol_ldl_maintenance_goal'] = "CHOLESTEROL_LDL_MAINTAINANCE";
    GoalTypeName[GoalTypeName["TRYGLICERIDE_MAINTAINANCE"] = 'triglyceride_maintenance_goal'] = "TRYGLICERIDE_MAINTAINANCE";
    GoalTypeName[GoalTypeName["REST_QUALITY"] = 'rest_quality_goal'] = "REST_QUALITY";
    GoalTypeName[GoalTypeName["GENERIC_GOAL"] = 'generic_goal'] = "GENERIC_GOAL";
})(GoalTypeName || (GoalTypeName = {}));

class Activity {
}

class SMBGActivity extends Activity {
}

class Plan extends Shareable {
    constructor() {
        super(...arguments);
        this.resourceType = 'Plan';
        this.start = new Date();
        this.due = new Date();
    }
    toString() {
        return `Plan[${this.id} - ${this.fhirId}] ${this.goals}`;
    }
    /**
     * It looks for the goal instance by navigating the hierarchy of goals
     */
    lookupGoalById(id) {
        for (const g of this.goals) {
            const m = g.findMilestoneById(id);
            if (m) {
                return m;
            }
        }
        return undefined;
    }
    /**
     * It looks for the goal instance by navigating the hierarchy of goals
     */
    lookupGoalByFhirId(fhirId) {
        for (const g of this.goals) {
            const m = g.findMilestoneByFhirId(fhirId);
            if (m) {
                return m;
            }
        }
        return undefined;
    }
    getMilestones() {
        if (this.goals) {
            const allMilestones = this.goals.filter((mg) => mg.milestones && mg.milestones.length > 0).map((mg) => mg.milestones);
            // make the milestones array flat
            return Array.prototype.concat(...allMilestones);
        }
        return [];
    }
    getMilestonesInProgress() {
        if (this.goals) {
            const activeMilestones = this.goals
                // .filter((mg) => mg.milestones && mg.milestones.length > 0)
                .map((macrogoals) => macrogoals.milestones)
                .map((allMilestones) => allMilestones.filter((mg) => mg.status === Goal.GoalStatus.ACTIVE));
            // make the milestones array flat
            return Array.prototype.concat(...activeMilestones);
        }
        return [];
    }
}
// tslint:disable-next-line:no-namespace
(function (Plan) {
    let PlanStatus;
    (function (PlanStatus) {
        PlanStatus[PlanStatus["UNKNOWN"] = 0] = "UNKNOWN";
        PlanStatus[PlanStatus["DRAFT"] = 1] = "DRAFT";
        PlanStatus[PlanStatus["ACTIVE"] = 2] = "ACTIVE";
        PlanStatus[PlanStatus["ON_HOLD"] = 3] = "ON_HOLD";
        PlanStatus[PlanStatus["REVOKED"] = 4] = "REVOKED";
        PlanStatus[PlanStatus["COMPLETED"] = 5] = "COMPLETED";
        PlanStatus[PlanStatus["ENTERED_IN_ERROR"] = 6] = "ENTERED_IN_ERROR";
    })(PlanStatus = Plan.PlanStatus || (Plan.PlanStatus = {}));
})(Plan || (Plan = {}));

class Note {
    constructor(author, note) {
        this.author = author;
        this.createdOn = new Date();
        this.value = note;
    }
}

class PlanDefinition extends Shareable {
    constructor() {
        super(...arguments);
        this.resourceType = 'PlanDefinition';
    }
    toString() {
        return `PlanDefinition[${this.id} - ${this.fhirId}] ${this.goals}`;
    }
}
// tslint:disable-next-line:no-namespace
(function (PlanDefinition) {
    let PlanStatus;
    (function (PlanStatus) {
        PlanStatus[PlanStatus["UNKNOWN"] = 0] = "UNKNOWN";
        PlanStatus[PlanStatus["DRAFT"] = 1] = "DRAFT";
        PlanStatus[PlanStatus["ACTIVE"] = 2] = "ACTIVE";
        PlanStatus[PlanStatus["RETIRED"] = 3] = "RETIRED";
    })(PlanStatus = PlanDefinition.PlanStatus || (PlanDefinition.PlanStatus = {}));
    let PlanTopic;
    (function (PlanTopic) {
        PlanTopic[PlanTopic["EDUCATION"] = 0] = "EDUCATION";
        PlanTopic[PlanTopic["TREATMENT"] = 1] = "TREATMENT";
        PlanTopic[PlanTopic["ASSESSMENT"] = 2] = "ASSESSMENT";
    })(PlanTopic = PlanDefinition.PlanTopic || (PlanDefinition.PlanTopic = {}));
})(PlanDefinition || (PlanDefinition = {}));

class Message extends Shareable {
    constructor() {
        super(...arguments);
        this.resourceType = 'Message';
    }
    isSent() {
        return !!this.sent;
    }
    isReceived() {
        return !!this.received;
    }
    isRead() {
        return !!this.read;
    }
    /**
     * this is needed in case the message contains values that have to be used when translating the message content
     */
    valuesAsObject() {
        return {};
    }
    toLog() {
        let res = '';
        const msgre = /Message/gi;
        res += this.constructor.name.replace(msgre, ''); // elimina Message dal nome del costruttore
        res += `[${LogConf.CAT_MSG_ID}${this.id}]`;
        // console.log(`From ${this.constructor.name} To ${res}`);
        return res;
    }
}

class DocMessage extends Message {
    constructor(text, title, received, customMsg, senderName, sender, recipient) {
        super();
        this.text = text;
        this.title = title;
        this.received = received;
        this.customMsg = customMsg;
        this.senderName = senderName;
        this.sender = sender;
        this.recipient = recipient;
    }
    getCompleteMsg() {
        let message = '';
        if (this.text) {
            message += `${this.text}\n`;
        }
        if (this.customMsg) {
            message += `${this.customMsg}\n`;
        }
        return message;
    }
    toString() {
        return `${this.constructor.name} - ${this.title}. ${this.text}, ${this.customMsg} [${this.received}] [${this.sender}]`;
    }
}

var DocMessageType;
(function (DocMessageType) {
    DocMessageType[DocMessageType["COMMUNICATION"] = 'communication'] = "COMMUNICATION";
    DocMessageType[DocMessageType["CONGRATULATION"] = 'congratulation'] = "CONGRATULATION";
    DocMessageType[DocMessageType["MOTIVATIONAL"] = 'motivational'] = "MOTIVATIONAL";
    DocMessageType[DocMessageType["DATA_REQUEST"] = 'data_request'] = "DATA_REQUEST";
})(DocMessageType || (DocMessageType = {}));
(function (DocMessageType) {
    function valueOf(type) {
        if (type === DocMessageType.COMMUNICATION.toString()) {
            return DocMessageType.COMMUNICATION;
        }
        else if (type === DocMessageType.CONGRATULATION.toString()) {
            return DocMessageType.CONGRATULATION;
        }
        else if (type === DocMessageType.MOTIVATIONAL.toString()) {
            return DocMessageType.MOTIVATIONAL;
        }
        else if (type === DocMessageType.DATA_REQUEST.toString()) {
            return DocMessageType.DATA_REQUEST;
        }
        else {
            return undefined;
        }
    }
    DocMessageType.valueOf = valueOf;
})(DocMessageType || (DocMessageType = {}));

class GoalMessage extends Message {
    constructor(text, title, received, goalFhirId, sender) {
        super();
        this.text = text;
        this.title = title;
        this.received = received;
        this.goalFhirId = goalFhirId;
        this.sender = sender;
    }
}

var MotivationalMessageType;
(function (MotivationalMessageType) {
    MotivationalMessageType[MotivationalMessageType["ADVICE"] = 'ADVICE'] = "ADVICE";
    MotivationalMessageType[MotivationalMessageType["APPLAUDE"] = 'APPLAUDE'] = "APPLAUDE";
    MotivationalMessageType[MotivationalMessageType["ARRANGE"] = 'ARRANGE'] = "ARRANGE";
    MotivationalMessageType[MotivationalMessageType["BOOSTER"] = 'BOOSTER'] = "BOOSTER";
    MotivationalMessageType[MotivationalMessageType["KEEP_ON_TRACK"] = 'KEEP_ON_TRACK'] = "KEEP_ON_TRACK";
    MotivationalMessageType[MotivationalMessageType["DO_NOTHING"] = 'DO_NOTHING'] = "DO_NOTHING";
    MotivationalMessageType[MotivationalMessageType["NEEDED_INFO"] = 'NEEDED_INFO'] = "NEEDED_INFO";
})(MotivationalMessageType || (MotivationalMessageType = {}));

class MotivationalMessage extends Message {
    constructor(cluster, textLabel, messageType, title, received, elapseBeforeRepetitionInDays = 0) {
        super();
        this.values = new Map();
        this.cluster = cluster;
        this.textLabel = textLabel;
        this.messageType = messageType;
        this.title = title;
        this.received = received;
        this.elapseBeforeRepetitionInDays = elapseBeforeRepetitionInDays;
    }
    valuesAsObject() {
        if (!this.values) {
            return {};
        }
        const object = {};
        this.values.forEach((v, k) => {
            object[k] = v;
        });
        return object;
    }
    toString() {
        return `${this.textLabel} [${this.cluster}]: elapseBeforeRepetitionInDays=${this.elapseBeforeRepetitionInDays} ${this.values ? [...Array.from(this.values.keys())] : 'NO VALUES'}`;
    }
    getPriority() {
        switch (this.messageType) {
            case MotivationalMessageType.ADVICE:
                return 1;
            case MotivationalMessageType.APPLAUDE:
                return 2;
            case MotivationalMessageType.KEEP_ON_TRACK:
                return 3;
            case MotivationalMessageType.NEEDED_INFO:
                return 4;
            case MotivationalMessageType.ARRANGE:
                return 5;
            case MotivationalMessageType.BOOSTER:
                return 6;
            case MotivationalMessageType.DO_NOTHING:
                return 0;
            default:
                return -1;
        }
    }
}

class InformativeMessage extends Message {
    constructor(commId, text, title, received) {
        super();
        this.textLabel = text;
        this.title = title;
        this.received = received;
        this.commId = commId;
    }
    toString() {
        return `${this.constructor.name} - ${this.title}. ${this.textLabel}, related to Communication_Id: ${this.commId} `;
    }
    toLog() {
        let res = '';
        const msgre = /Message/gi;
        res += this.constructor.name.replace(msgre, ''); // elimina Message dal nome del costruttore
        res += `[${LogConf.CAT_MSG_ID}${this.id}]`;
        if (this.commId !== undefined && this.commId >= 0) {
            res += `[${LogConf.CAT_COMM_ID}${this.commId}]`;
        }
        // console.log(`From ${this.constructor.name} To ${res}`);
        return res;
    }
}

class ChatMessage extends Message {
    constructor(text, title, received, sent, read, sender, recipient) {
        super();
        this.text = text;
        this.title = title;
        this.received = received;
        this.sent = sent;
        this.read = read;
        this.sender = sender;
        this.recipient = recipient;
    }
    toString() {
        return `${this.constructor.name} - ${this.title}. ${this.text} [sent ${this.received} - received ${this.received} read ${this.read}] [${this.sender} to ${this.recipient}][fhir: ${this.fhirId}/_history/${this.version}]`;
    }
    supportVersion() {
        return true;
    }
}

/**
 * I req message sono usati per definire su quale pagina deve finire la comunicazione
 */
class ReqMessage extends Message {
    constructor(goToModule, goToPage, text, title, received, reqType) {
        super();
        this.resourceType = 'ReqMessage';
        this.textLabel = text;
        this.title = title;
        this.received = received;
        this.goToModule = goToModule;
        this.goToPage = goToPage;
        this.reqType = reqType;
    }
    toString() {
        return `${this.constructor.name} - ${this.title}. ${this.textLabel}, GoTo: ${this.goToModule}-${this.goToPage}`;
    }
    toLog() {
        let res = '';
        const msgre = /Message/gi;
        res += this.constructor.name.replace(msgre, ''); // elimina Message dal nome del costruttore
        if (this.textLabel.startsWith('comm.text.')) {
            res += ' ' + this.textLabel.substring(10);
        }
        else {
            res += ' ' + this.textLabel;
        }
        res += `[${LogConf.CAT_MSG_ID}${this.id}]`;
        if (this.commId !== undefined && this.commId >= 0) {
            res += `[${LogConf.CAT_COMM_ID}${this.commId}]`;
        }
        return res;
    }
}

class ChatSettings {
    constructor() {
        // public practitionerFullName: string;
        this.option = ChatSettings.ChatSettingsType.NO_MESSAGING;
    }
    toJSON() {
        var _a, _b, _c;
        const o = {
            patientId: (_a = this.patient) === null || _a === void 0 ? void 0 : _a.id,
            practitionerId: (_b = this.practitioner) === null || _b === void 0 ? void 0 : _b.id,
            option: (_c = this.option) === null || _c === void 0 ? void 0 : _c.toString(),
            resourceType: ChatSettings.resourceType,
        };
        // DO not serialize 'practitionerFullName'
        return o; // passed to stringify
    }
    static revive(json) {
        const newObj = Object.create(ChatSettings.prototype);
        if (json.resourceType && ChatSettings.resourceType !== json.resourceType) {
            throw new TypeError(`Trying to wrongly deserialize as '${ChatSettings.resourceType}' ${json}`);
        }
        const ps = Object.assign(newObj, json, {});
        if (!!json.patientId) {
            ps.patient = new Patient(json.patientId);
        }
        if (!!json.practitionerId) {
            ps.practitioner = new HealthCareProfessional(json.practitionerId);
        }
        if (!!json.option) {
            ps.option = ChatSettings.ChatSettingsType.valueOf(json.option);
        }
        return ps;
    }
}
ChatSettings.resourceType = 'ChatSettings';
// tslint:disable-next-line:no-namespace
(function (ChatSettings) {
    let ChatSettingsType;
    (function (ChatSettingsType) {
        ChatSettingsType[ChatSettingsType["NO_MESSAGING"] = 'NO_MESSAGING'] = "NO_MESSAGING";
        ChatSettingsType[ChatSettingsType["CHAT_ONLY"] = 'CHAT_ONLY'] = "CHAT_ONLY";
        ChatSettingsType[ChatSettingsType["CHAT_AND_VIDEO"] = 'CHAT_AND_VIDEO'] = "CHAT_AND_VIDEO";
    })(ChatSettingsType = ChatSettings.ChatSettingsType || (ChatSettings.ChatSettingsType = {}));
    (function (ChatSettingsType) {
        function valueOf(type) {
            if (type === ChatSettingsType.NO_MESSAGING.toString()) {
                return ChatSettingsType.NO_MESSAGING;
            }
            else if (type === ChatSettingsType.CHAT_ONLY.toString()) {
                return ChatSettingsType.CHAT_ONLY;
            }
            else if (type === ChatSettingsType.CHAT_AND_VIDEO.toString()) {
                return ChatSettingsType.CHAT_AND_VIDEO;
            }
            else {
                return undefined;
            }
        }
        ChatSettingsType.valueOf = valueOf;
    })(ChatSettingsType = ChatSettings.ChatSettingsType || (ChatSettings.ChatSettingsType = {}));
})(ChatSettings || (ChatSettings = {}));

/**
 * A clinical note is a means for care team to discuss about a patient.
 *
 * Clinical notes can be 'referred to' (i.e. reply mechanism)
 */
class ClinicalNote extends Shareable {
    constructor() {
        super(...arguments);
        this.resourceType = 'ClinicalNote';
    }
    get slug() {
        return this.id ? this.id + '' : undefined;
    }
    set slug(slug) {
        this.id = Number(slug);
    }
}

class PatientConsent extends Shareable {
    constructor() {
        super(...arguments);
        this.resourceType = 'PatientConsent';
        this.attachmentType = 'PDF';
    }
    // tslint:disable-next-line: member-ordering
    static revive(json) {
        const newObj = Object.create(PatientConsent.prototype);
        if (newObj.resourceType !== json.resourceType) {
            throw new TypeError(`Trying to wrongly deserialize as 'Consent' ${json}`);
        }
        return Object.assign(newObj, json, {});
    }
}

var ConsentPermission;
(function (ConsentPermission) {
    ConsentPermission[ConsentPermission["INFA"] = 'INFA'] = "INFA";
    ConsentPermission[ConsentPermission["INFAO"] = 'INFAO'] = "INFAO";
    ConsentPermission[ConsentPermission["INFASO"] = 'INFASO'] = "INFASO";
})(ConsentPermission || (ConsentPermission = {}));

class Condition extends Shareable {
    constructor() {
        super(...arguments);
        this.resourceType = 'Condition';
        // public evidence: any[];
    }
    /**
     * @alias patient
     */
    set subject(subject) {
        this.patient = subject;
    }
    get subject() {
        return this.patient;
    }
}

class Diagnosis extends Condition {
}

var ConditionClinicalStatus;
(function (ConditionClinicalStatus) {
    ConditionClinicalStatus["ACTIVE"] = "active";
    ConditionClinicalStatus["RESOLVED"] = "resolved";
    // REMISSION = 'remission',
    ConditionClinicalStatus["REMISSION_IN_THERAPY"] = "remission-in-therapy";
    ConditionClinicalStatus["REMISSION_OFF_THERAPY"] = "remission-off-therapy";
    ConditionClinicalStatus["UNKNOWN"] = "unknown";
})(ConditionClinicalStatus || (ConditionClinicalStatus = {}));
// tslint:disable-next-line:no-namespace
(function (ConditionClinicalStatus) {
    function values() {
        return Object.values(ConditionClinicalStatus);
    }
    ConditionClinicalStatus.values = values;
    function valueOf(value) {
        return this.values().find((v) => v == value);
    }
    ConditionClinicalStatus.valueOf = valueOf;
})(ConditionClinicalStatus || (ConditionClinicalStatus = {}));

var ConditionVerificationStatus;
(function (ConditionVerificationStatus) {
    ConditionVerificationStatus["PROVISIONAL"] = "provisional";
    ConditionVerificationStatus["CONFIRMED"] = "confirmed";
    ConditionVerificationStatus["REFUSED"] = "refused";
})(ConditionVerificationStatus || (ConditionVerificationStatus = {}));
// tslint:disable-next-line:no-namespace
(function (ConditionVerificationStatus) {
    function values() {
        return Object.values(ConditionVerificationStatus);
    }
    ConditionVerificationStatus.values = values;
    function valueOf(value) {
        return this.values().find((v) => v == value);
    }
    ConditionVerificationStatus.valueOf = valueOf;
})(ConditionVerificationStatus || (ConditionVerificationStatus = {}));

var DiagnosisType;
(function (DiagnosisType) {
    DiagnosisType["CLINICAL"] = "clinical";
    DiagnosisType["GENETIC"] = "genetic";
    DiagnosisType["HISTOLOGICAL"] = "histological";
    DiagnosisType["LABOATORY"] = "laboratory";
})(DiagnosisType || (DiagnosisType = {}));
// tslint:disable-next-line:no-namespace
(function (DiagnosisType) {
    function values() {
        return Object.values(DiagnosisType);
    }
    DiagnosisType.values = values;
    function valueOf(value) {
        return this.values().find((v) => v == value);
    }
    DiagnosisType.valueOf = valueOf;
})(DiagnosisType || (DiagnosisType = {}));

class Risk extends Shareable {
    constructor() {
        super(...arguments);
        this.resourceType = 'Risk';
        this.predictions = [];
    }
    /**
     * @alias patient
     */
    set subject(subject) {
        this.patient = subject;
    }
    get subject() {
        return this.patient;
    }
}
(function (Risk) {
    class Prediction {
        get age() {
            var _a;
            return (_a = this.maxAge) !== null && _a !== void 0 ? _a : this.minAge;
        }
        get probability() {
            return (this.range.min + this.range.max) / 2;
        }
        set probability(p) {
            this.range = { min: p, max: p };
        }
    }
    Risk.Prediction = Prediction;
})(Risk || (Risk = {}));

class Stats {
    constructor(last, target, worst) {
        this.reached = false;
        this.last = last;
        this.worst = worst; // non serve se non usiamo i box di feedback delle prime versioni
        this.target = target;
        this.lastValue = this.last.value;
        this.judge();
    }
    toString() {
        return `LAST: ${this.last} - WORST: ${this.worst}`;
    }
    judge() {
        // verifica il tipo di target
        if (this.target instanceof QuantitativeTarget) {
            this.min = this.target.thresholdValue.magnitude;
            this.operator = this.target.operator;
        }
        else if (this.target instanceof RangeTarget) {
            this.min = this.target.minThresholdValue.magnitude;
            this.max = this.target.maxThresholdValue.magnitude;
        }
        if (this.max && this.max >= 0) {
            // RANGE TARGET
            this.reached = this.lastValue >= this.min && this.lastValue <= this.max;
        }
        else {
            // Quantitative Target
            switch (this.operator) {
                case QuantitativeTarget.RelationalOperator.LT:
                    this.reached = this.lastValue < this.min;
                    break;
                case QuantitativeTarget.RelationalOperator.LE:
                    this.reached = this.lastValue <= this.min;
                    break;
                case QuantitativeTarget.RelationalOperator.GT:
                    this.reached = this.lastValue > this.min;
                    break;
                case QuantitativeTarget.RelationalOperator.GE:
                    this.reached = this.lastValue >= this.min;
                    break;
                case QuantitativeTarget.RelationalOperator.EQ:
                    this.reached = this.lastValue === this.min;
                    break;
                default:
                    break;
            }
        }
    }
}

/**
 * EventLog class to monitor events in the mobile app
 */
class EventLog {
    constructor(timestamp = new Date(), patientId, view, operation, // = LogConf.NOOPERATION,
    element // = LogConf.NOELEMENT,
    ) {
        this.timestamp = timestamp;
        this.patientId = patientId;
        this.view = view;
        this.operation = operation;
        this.element = element;
    }
}

class Prescription extends Shareable {
    constructor(subject, priority, dateTime) {
        super();
        this.subject = subject;
        this.priority = priority;
        this.dateTime = dateTime;
        this.resourceType = 'ServiceRequest';
    }
}

class ExamPrescription extends Prescription {
    constructor(subject, examCode, specimenType, priority, author, dateTime) {
        super();
        this.subject = subject;
        this.examCode = examCode;
        this.specimenType = specimenType;
        this.priority = priority;
        this.author = author;
        this.dateTime = dateTime;
    }
}

class CounsellingPrescription extends Prescription {
    constructor(subject, priority, dateTime, status) {
        super();
        this.subject = subject;
        this.priority = priority;
        this.dateTime = dateTime;
        this.status = status;
        this.supportingInfo = [];
    }
}

class Episode extends Shareable {
    constructor() {
        super(...arguments);
        // public static readonly fhirResourceType = 'EpisodeOfCare';
        this.resourceType = 'Episode';
    }
    get status() {
        return this.closingDate ? EpisodeStatus.FINISHED : EpisodeStatus.ACTIVE;
    }
}

class Encounter extends Shareable {
    constructor() {
        super(...arguments);
        this.resourceType = 'Encounter';
        this.questionnaires = new Map();
        this.otherQuestionnaires = new Map();
    }
    get status() {
        return this.closingDate ? EncounterStatus.COMPLETED : EncounterStatus.INPROGRESS;
    }
    setQuestionnaire(type, qr) {
        var _a, _b;
        if (type == EncounterQuestionnaire.OTHER) {
            const url = (_b = (_a = qr.questionnaire) === null || _a === void 0 ? void 0 : _a.questionnaireId) !== null && _b !== void 0 ? _b : qr.questionnaireUrl;
            this.otherQuestionnaires.set(url, qr);
        }
        this.questionnaires.set(type, qr);
    }
    /**
     * gets the questionnaire response associated to the Encounter
     * @param type get a predefined qestionnaire by type
     * @param url of a non-standard questionnaire (EncounterQuestionnaire must be OTHER)
     * @returns a QuestionnaireResponse, if available
     */
    getQuestionnaire(type, url) {
        var _a, _b;
        if (type == EncounterQuestionnaire.OTHER) {
            if (url)
                return (_a = this.otherQuestionnaires) === null || _a === void 0 ? void 0 : _a.get(url);
        }
        else
            return (_b = this.questionnaires) === null || _b === void 0 ? void 0 : _b.get(type);
        return undefined;
    }
    // LEFT FOR COMPATIBILITY
    get anamn_prox() {
        var _a;
        return (_a = this.questionnaires) === null || _a === void 0 ? void 0 : _a.get(EncounterQuestionnaire.PATIENT_SHORT_TERM_HISTORY);
    }
    get anamn_rem() {
        var _a;
        return (_a = this.questionnaires) === null || _a === void 0 ? void 0 : _a.get(EncounterQuestionnaire.REMOTE_ANAMNESIS);
    }
    get anamn_fisio() {
        var _a;
        return (_a = this.questionnaires) === null || _a === void 0 ? void 0 : _a.get(EncounterQuestionnaire.PATIENT_PHYSIOLOGICAL_HISTORY);
    }
    get anamn_fam() {
        var _a;
        return (_a = this.questionnaires) === null || _a === void 0 ? void 0 : _a.get(EncounterQuestionnaire.FAMILY_ANAMNESIS);
    }
    set anamn_prox(qr) {
        var _a;
        (_a = this.questionnaires) === null || _a === void 0 ? void 0 : _a.set(EncounterQuestionnaire.PATIENT_SHORT_TERM_HISTORY, qr);
    }
    set anamn_rem(qr) {
        var _a;
        (_a = this.questionnaires) === null || _a === void 0 ? void 0 : _a.set(EncounterQuestionnaire.REMOTE_ANAMNESIS, qr);
    }
    set anamn_fisio(qr) {
        var _a;
        (_a = this.questionnaires) === null || _a === void 0 ? void 0 : _a.set(EncounterQuestionnaire.PATIENT_PHYSIOLOGICAL_HISTORY, qr);
    }
    set anamn_fam(qr) {
        var _a;
        (_a = this.questionnaires) === null || _a === void 0 ? void 0 : _a.set(EncounterQuestionnaire.FAMILY_ANAMNESIS, qr);
    }
}

class Appointment extends Shareable {
    constructor() {
        super(...arguments);
        this.resourceType = 'Appointment';
    }
}

class DocRef {
    constructor(subjectId, type, date) {
        this.resourceType = 'DocumentReference';
        this.subjectId = subjectId;
        this.type = type;
        this.date = date;
    }
}

class Trial extends Shareable {
}

class TrialSubject extends Shareable {
}

class Nutrition extends Shareable {
    constructor() {
        super(...arguments);
        this.resourceType = 'Nutrition'; //check
    }
}

class NutritionItem {
}

class DataModelUtils {
    static loadClassByTypeName(resourceType) {
        if (!resourceType) {
            throw new TypeError(`Deserializer invoked but the resource type is not specified.`);
        }
        let _class;
        const knownSerializableClasses = {
            Practitioner: HealthCareProfessional,
            Patient: Patient,
            User: User,
            // TODO: register all the elements that can be serialized
        };
        _class = knownSerializableClasses[resourceType];
        if (!_class) {
            throw new TypeError(`Unsupported type ${resourceType} to be deserialized`);
        }
        if (_class['revive'] === undefined) {
            throw new TypeError(`The type ${resourceType} doesn't have a 'revive' method to be called`);
        }
        return _class;
    }
    static attributeRevive(item, reviveCallback) {
        if (!item) {
            return undefined;
        }
        if (Array.isArray(item)) {
            const newItem = [];
            item.forEach((i) => {
                // tries to revive array of elements
                const rev = reviveCallback(i);
                newItem.push(rev);
            });
            return newItem;
        }
        else {
            return reviveCallback(item);
        }
    }
}

// FOLDERS

/*
 * Public API Surface of model
 */

/**
 * Generated bundle index. Do not edit.
 */

export { Activity, AlcoholDrinkingFrequency, Answer, AnswerGroup, Appointment, AppointmentStatus, BMI, BloodGlucose, BloodPressure, BodyTemperature, COVIDSymptoms, CaloricDailyIntake, CarbohydratesDailyIntake, CareGiver, CareTeam, CareTeamStatus, CategoryMeasure, CategoryTarget, ChatMessage, ChatSettings, ChestPainLevel, ChestPainQuestionnaire, Choice, Cholesterol, CholesterolHdl, CholesterolLdl, ChromosomePosition, ClinicalNote, CodedValue, CodedValueQuestion, ConcentrationUnit, Condition, ConditionClinicalStatus, ConditionVerificationStatus, ConsentPermission, CoughType, CounsellingPrescription, DataModelUtils, Diagnosis, DiagnosisType, DiagnosticImplication, DiastolicBloodPressure, Distance, DocMessage, DocMessageType, DocRef, Encounter, EncounterQuestionnaire, EncounterStatus, EncounterType, EnergyExpenditure, Episode, EpisodeStatus, Event, EventLog, ExamPrescription, FatsDailyIntake, FeedbackInApp, FeedbackInAppStatus, FeedbackInAppType, FeedbackInAppTypeName, FeedbackTypeSettings, FeedbackTypeWeekDays, FeedbackTypeWeeklyPlan, FibersDailyIntake, Food, FruitPortionsDailyIntake, Gender, GenericQuantitativeFormStructure, GenericQuantitativeMeasure, GenomicVariant, Genotype, Goal, GoalInternalActivity, GoalMessage, GoalTypeName, Haplotype, Hba1c, HealthCareProfessional, HealthService, HeartRate, Height, Identifier, InformativeMessage, Intensity, Kinship, Language, LengthUnit, LifeStyle, Locale, LogConf, Meal, MealType, MeasUiSettings, Measure, Message, ModerateWorkoutDurationInWeek, MolecularConsequence, MotivationalMessage, MotivationalMessageType, Note, Nutrition, NutritionItem, ObservePatient, Organization, Pathology, Patient, PatientConsent, PatientHealthStatus, PercentageUnit, Person, PersonAddress, PersonRole, PhysicalInability, Place, Plan, PlanDefinition, Prescription, Procedure, ProteinsDailyIntake, Quality, QuantitativeMeasure, QuantitativeSectionFormStructure, QuantitativeTarget, Question, QuestionEnableWhen, QuestionEnableWhenCondition, QuestionEnableWhenOperator, QuestionGroup, QuestionType, Questionnaire, QuestionnaireResponse, RangeTarget, RegionStudied, ReqMessage, ResponseStatus, Risk, RiskLevel, Role, SMBGActivity, Shareable, Significance, Smoker, SmokingFrequency, SodiumDailyIntake, SpO2, Sport, Stats, StepCount, Study, SugaryBeverageDrinkingFrequency, SupervisorRequired, SystolicBloodPressure, TTM, TargetQuantity, TemperatureUnit, TherapeuticImplication, Trial, TrialSubject, Triglyceride, User, Vcf, VcfMetadata, VegetablesPortionsDailyIntake, VigorousWorkoutDurationInWeek, Waist, Weight, WeightUnit, Workout, WorkoutIntensity, WorkoutSessionInWeek, WorkoutType };
//# sourceMappingURL=eng-it4h-heart-ui-model.mjs.map
