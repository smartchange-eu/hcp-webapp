/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@eng-it4h/heart-ui-model" />
export * from './public-api';
