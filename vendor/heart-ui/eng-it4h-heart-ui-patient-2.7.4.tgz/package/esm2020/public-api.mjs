/*
 * Public API Surface of patient
 */
export * from './lib/patient-card/';
export * from './lib/patient-list/';
export * from './lib/patient-stats/';
export * from './lib/family-members';
export * from './lib/patient-anagraphic-form/';
export * from './lib/address-form/';
export * from './lib/patient-expandible/';
export * from './lib/patient-mini-card/';
export * from './lib/patient-kinship/';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljLWFwaS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3Byb2plY3RzL2hlYXJ0LXVpLXBhdGllbnQvc3JjL3B1YmxpYy1hcGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7O0dBRUc7QUFFSCxjQUFjLHFCQUFxQixDQUFDO0FBQ3BDLGNBQWMscUJBQXFCLENBQUM7QUFDcEMsY0FBYyxzQkFBc0IsQ0FBQztBQUNyQyxjQUFjLHNCQUFzQixDQUFDO0FBQ3JDLGNBQWMsZ0NBQWdDLENBQUM7QUFDL0MsY0FBYyxxQkFBcUIsQ0FBQztBQUNwQyxjQUFjLDJCQUEyQixDQUFDO0FBQzFDLGNBQWMsMEJBQTBCLENBQUM7QUFDekMsY0FBYyx3QkFBd0IsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBQdWJsaWMgQVBJIFN1cmZhY2Ugb2YgcGF0aWVudFxuICovXG5cbmV4cG9ydCAqIGZyb20gJy4vbGliL3BhdGllbnQtY2FyZC8nO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvcGF0aWVudC1saXN0Lyc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9wYXRpZW50LXN0YXRzLyc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9mYW1pbHktbWVtYmVycyc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9wYXRpZW50LWFuYWdyYXBoaWMtZm9ybS8nO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvYWRkcmVzcy1mb3JtLyc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9wYXRpZW50LWV4cGFuZGlibGUvJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL3BhdGllbnQtbWluaS1jYXJkLyc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9wYXRpZW50LWtpbnNoaXAvJztcbiJdfQ==