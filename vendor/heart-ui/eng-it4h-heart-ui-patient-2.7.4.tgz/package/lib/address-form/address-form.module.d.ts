import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as i0 from "@angular/core";
import * as i1 from "./address-form.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/common/http";
import * as i4 from "@eng-it4h/heart-ui-utils";
import * as i5 from "@ngx-translate/core";
import * as i6 from "@angular/forms";
import * as i7 from "@angular/material/input";
import * as i8 from "@angular/material/form-field";
import * as i9 from "@angular/material/select";
import * as i10 from "@angular/material/button";
import * as i11 from "@angular/material/icon";
export declare function HttpLoaderFactoryAddress(http: HttpClient): TranslateHttpLoader;
export declare class AddressFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AddressFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AddressFormModule, [typeof i1.AddressFormComponent], [typeof i2.CommonModule, typeof i3.HttpClientModule, typeof i4.SubTranslateModule, typeof i5.TranslateModule, typeof i6.FormsModule, typeof i6.ReactiveFormsModule, typeof i7.MatInputModule, typeof i8.MatFormFieldModule, typeof i9.MatSelectModule, typeof i10.MatButtonModule, typeof i11.MatIconModule], [typeof i1.AddressFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AddressFormModule>;
}
