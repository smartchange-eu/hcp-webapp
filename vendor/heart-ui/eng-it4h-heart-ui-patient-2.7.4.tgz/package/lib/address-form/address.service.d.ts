import { City } from './assets/cities/city.model';
import * as i0 from "@angular/core";
export declare type Dataset = 'Italy' | 'UK';
export declare class AddressService {
    private supported;
    private completeStructure;
    private regions;
    private provsPerRegion;
    getSupportedCities(): Dataset[];
    getCompleteStructure(dataset: Dataset): City[];
    getRegions(dataset: Dataset): string[];
    getProvsPerRegion(dataset: Dataset): Map<string, string[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddressService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AddressService>;
}
