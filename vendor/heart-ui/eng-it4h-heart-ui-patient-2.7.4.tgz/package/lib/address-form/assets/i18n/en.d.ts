export declare const en: {
    "patient.address-form.button.store.label": string;
    "patient.address-form.country.label": string;
    "patient.address-form.region.label": string;
    "patient.address-form.prov.label": string;
    "patient.address-form.city.label": string;
    "patient.address-form.street.label": string;
};
