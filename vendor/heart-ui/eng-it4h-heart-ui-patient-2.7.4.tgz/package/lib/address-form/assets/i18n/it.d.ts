export declare const it: {
    "patient.address-form.required.error": string;
    "patient.address-form.country.label": string;
    "patient.address-form.region.label": string;
    "patient.address-form.prov.label": string;
    "patient.address-form.city.label": string;
    "patient.address-form.street.label": string;
    "patient.address-form.select.reset.label": string;
};
