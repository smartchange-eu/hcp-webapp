export declare class City {
    region: string;
    province: string;
    provinceCode: string;
    cityName: string;
    cap: string[];
}
