import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as i0 from "@angular/core";
import * as i1 from "./patient-anagraphic-form.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/common/http";
import * as i4 from "@eng-it4h/heart-ui-utils";
import * as i5 from "@ngx-translate/core";
import * as i6 from "@angular/forms";
import * as i7 from "@angular/material/input";
import * as i8 from "@angular/material/form-field";
import * as i9 from "@angular/material/datepicker";
import * as i10 from "@angular/material/slide-toggle";
import * as i11 from "@angular/material/button";
import * as i12 from "../family-members/family-members.module";
import * as i13 from "@angular/material/icon";
import * as i14 from "@angular/material/radio";
import * as i15 from "@angular/material/expansion";
import * as i16 from "@angular/material/divider";
import * as i17 from "../address-form/address-form.module";
import * as i18 from "@angular/material/select";
export declare function HttpLoaderFactoryPatientAnagraphic(http: HttpClient): TranslateHttpLoader;
export declare class PatientAnagraphicFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PatientAnagraphicFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PatientAnagraphicFormModule, [typeof i1.PatientAnagraphicFormComponent], [typeof i2.CommonModule, typeof i3.HttpClientModule, typeof i4.SubTranslateModule, typeof i5.TranslateModule, typeof i6.FormsModule, typeof i6.ReactiveFormsModule, typeof i7.MatInputModule, typeof i8.MatFormFieldModule, typeof i9.MatDatepickerModule, typeof i10.MatSlideToggleModule, typeof i11.MatButtonModule, typeof i12.FamilyMembersModule, typeof i13.MatIconModule, typeof i4.FormUtilsModule, typeof i14.MatRadioModule, typeof i15.MatExpansionModule, typeof i16.MatDividerModule, typeof i17.AddressFormModule, typeof i18.MatSelectModule, typeof i4.PreventDoubleClickModule], [typeof i1.PatientAnagraphicFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PatientAnagraphicFormModule>;
}
