export * from './patient-anagraphic-form.module';
export * from './patient-anagraphic-form.component';
