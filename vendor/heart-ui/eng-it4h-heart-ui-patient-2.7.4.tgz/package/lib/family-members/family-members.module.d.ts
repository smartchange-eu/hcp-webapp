import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as i0 from "@angular/core";
import * as i1 from "./family-members.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/common/http";
import * as i4 from "@eng-it4h/heart-ui-utils";
import * as i5 from "@ngx-translate/core";
import * as i6 from "@angular/forms";
import * as i7 from "@angular/material/form-field";
import * as i8 from "@angular/material/input";
import * as i9 from "@angular/material/select";
import * as i10 from "@angular/material/datepicker";
import * as i11 from "@angular/material/button";
import * as i12 from "@angular/material/icon";
import * as i13 from "@angular/material/radio";
export declare function HttpLoaderFactoryFamilyMember(http: HttpClient): TranslateHttpLoader;
export declare class FamilyMembersModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FamilyMembersModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FamilyMembersModule, [typeof i1.FamilyMembersComponent], [typeof i2.CommonModule, typeof i3.HttpClientModule, typeof i4.SubTranslateModule, typeof i5.TranslateModule, typeof i6.FormsModule, typeof i6.ReactiveFormsModule, typeof i7.MatFormFieldModule, typeof i8.MatInputModule, typeof i9.MatSelectModule, typeof i10.MatDatepickerModule, typeof i11.MatButtonModule, typeof i12.MatIconModule, typeof i4.FormUtilsModule, typeof i13.MatRadioModule, typeof i4.PreventDoubleClickModule], [typeof i1.FamilyMembersComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FamilyMembersModule>;
}
