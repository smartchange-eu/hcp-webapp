export declare const en: {
    'dd/MM/yyyy': string;
    'family-member.age.label': string;
    'family-member.birthdate.label': string;
    'family-member.button.delete.label': string;
    'family-member.email.label': string;
    'family-member.email.pattern.error': string;
    'family-member.gender.label': string;
    'family-member.name.label': string;
    'family-member.required.error': string;
    'family-member.role.label': string;
    'family-member.surname.label': string;
    'MM/yyyy': string;
    yyyy: string;
};
