import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as i0 from "@angular/core";
import * as i1 from "./patient-stats.component";
import * as i2 from "@angular/common";
import * as i3 from "@swimlane/ngx-charts";
import * as i4 from "@eng-it4h/heart-ui-utils";
import * as i5 from "@ngx-translate/core";
export declare function HttpLoaderFactoryPatientStats(http: HttpClient): TranslateHttpLoader;
export declare class PatientStatsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PatientStatsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PatientStatsModule, [typeof i1.PatientStatsComponent], [typeof i2.CommonModule, typeof i3.BarChartModule, typeof i4.SubTranslateModule, typeof i5.TranslateModule], [typeof i1.PatientStatsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PatientStatsModule>;
}
