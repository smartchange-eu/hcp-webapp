export * from './patient-stats.module';
export * from './patient-stats.component';
