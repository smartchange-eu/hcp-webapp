export declare const it: {
    "patient.stats.total.patient.big": string;
    "patient.stats.average.age.patient.big": string;
    "patient.stats.stdev.age.patient.big": string;
    "patient.stats.male.perc.patient.big": string;
    "patient.stats.female.perc.patient.big": string;
};
