export declare const en: {
    "patient.mini-card.years.label": string;
};
