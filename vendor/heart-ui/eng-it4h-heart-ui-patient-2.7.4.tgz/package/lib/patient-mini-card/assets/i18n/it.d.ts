export declare const it: {
    "patient.mini-card.select-patient.button.label": string;
    "patient.mini-card.no-patient-selected.label": string;
    "patient.mini-card.switch-patient.button.label": string;
    "patient.mini-card.deselect-patient.button.tooltip": string;
    "patient.mini-card.years.label": string;
    "patient.mini-card.edit-patient.button.tooltip": string;
};
