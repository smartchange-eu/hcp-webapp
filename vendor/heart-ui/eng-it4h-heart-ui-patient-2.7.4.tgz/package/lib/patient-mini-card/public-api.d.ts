export * from './patient-mini-card.module';
export * from './patient-mini-card.component';
