import { EventEmitter, OnInit } from '@angular/core';
import { Patient } from '@eng-it4h/heart-ui-model';
import { SubTranslateService } from '@eng-it4h/heart-ui-utils';
import * as i0 from "@angular/core";
export declare class PatientMiniCardComponent implements OnInit {
    private _subTranslateService;
    lang?: string;
    patient?: Patient;
    hideSelect?: boolean;
    selectPatient: EventEmitter<any>;
    deselectPatient: EventEmitter<any>;
    editPatient: EventEmitter<any>;
    constructor(_subTranslateService: SubTranslateService);
    private createDictionary;
    ngOnInit(): void;
    click(): void;
    deselect(): void;
    edit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PatientMiniCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PatientMiniCardComponent, "heart-patient-mini-card", never, { "lang": "lang"; "patient": "patient"; "hideSelect": "hideSelect"; }, { "selectPatient": "selectPatient"; "deselectPatient": "deselectPatient"; "editPatient": "editPatient"; }, never, never, false, never>;
}
