import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as i0 from "@angular/core";
import * as i1 from "./patient-mini-card.component";
import * as i2 from "./age.pipe";
import * as i3 from "@angular/common";
import * as i4 from "@angular/material/icon";
import * as i5 from "@angular/material/button";
import * as i6 from "@angular/material/tooltip";
import * as i7 from "@eng-it4h/heart-ui-utils";
import * as i8 from "@ngx-translate/core";
export declare function HttpLoaderFactoryPatientMini(http: HttpClient): TranslateHttpLoader;
export declare class PatientMiniCardModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PatientMiniCardModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PatientMiniCardModule, [typeof i1.PatientMiniCardComponent, typeof i2.AgePipe], [typeof i3.CommonModule, typeof i4.MatIconModule, typeof i5.MatButtonModule, typeof i6.MatTooltipModule, typeof i7.SubTranslateModule, typeof i8.TranslateModule], [typeof i1.PatientMiniCardComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PatientMiniCardModule>;
}
