import { EventEmitter, OnInit } from '@angular/core';
import { CodedValue, Patient } from '@eng-it4h/heart-ui-model';
import { SubTranslateService } from '@eng-it4h/heart-ui-utils';
import * as i0 from "@angular/core";
export declare class PatientKinshipComponent implements OnInit {
    private _subTranslateService;
    patient: Patient;
    relative: Patient;
    kinships: CodedValue[];
    lang: string;
    localTranslate: boolean;
    saveKinship: EventEmitter<Patient>;
    protected selectedKinship: CodedValue;
    constructor(_subTranslateService: SubTranslateService);
    createDictionary(): void;
    ngOnInit(): void;
    private checkInputs;
    save(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PatientKinshipComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PatientKinshipComponent, "heart-patient-kinship", never, { "patient": "patient"; "relative": "relative"; "kinships": "kinships"; "lang": "lang"; }, { "saveKinship": "saveKinship"; }, never, never, false, never>;
}
