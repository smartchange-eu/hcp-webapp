export * from './patient-kinship.module';
export * from './patient-kinship.component';
