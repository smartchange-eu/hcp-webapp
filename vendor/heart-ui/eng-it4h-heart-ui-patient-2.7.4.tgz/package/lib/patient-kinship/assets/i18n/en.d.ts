export declare const en: {
    'http://terminology.hl7.org/CodeSystem/v3-RoleCode|NCHILD': string;
    'http://terminology.hl7.org/CodeSystem/v3-RoleCode|FTH': string;
    'http://terminology.hl7.org/CodeSystem/v3-RoleCode|MTH': string;
    'patient.kinship.select.label': string;
    'patient.kinship.select.float-label': string;
    'patient.kinship.is-the.label': string;
    'patient.kinship.of.label': string;
    'patient.kinship.save.label': string;
};
