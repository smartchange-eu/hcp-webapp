import { CodedValue } from '@eng-it4h/heart-ui-model';
export declare class KinshipConf {
    static baseKinships: CodedValue[];
}
