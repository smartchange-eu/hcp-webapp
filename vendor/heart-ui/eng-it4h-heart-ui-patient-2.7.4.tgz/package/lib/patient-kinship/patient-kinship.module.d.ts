import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as i0 from "@angular/core";
import * as i1 from "./patient-kinship.component";
import * as i2 from "./order-translate.pipe";
import * as i3 from "@angular/common";
import * as i4 from "@ngx-translate/core";
import * as i5 from "@angular/forms";
import * as i6 from "@eng-it4h/heart-ui-utils";
import * as i7 from "@angular/material/button";
import * as i8 from "@angular/material/select";
import * as i9 from "@angular/material/icon";
export declare function HttpLoaderFactoryKinship(http: HttpClient): TranslateHttpLoader;
export declare class PatientKinshipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PatientKinshipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PatientKinshipModule, [typeof i1.PatientKinshipComponent, typeof i2.OrderTranslatePipe], [typeof i3.CommonModule, typeof i4.TranslateModule, typeof i5.FormsModule, typeof i6.SubTranslateModule, typeof i6.PreventDoubleClickModule, typeof i7.MatButtonModule, typeof i8.MatSelectModule, typeof i9.MatIconModule], [typeof i1.PatientKinshipComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PatientKinshipModule>;
}
