export * from './patient-list.module';
export * from './patient-list.component';
