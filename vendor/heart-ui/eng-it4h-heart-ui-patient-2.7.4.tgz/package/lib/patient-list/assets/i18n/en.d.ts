export declare const en: {
    "patient.list.filter.label": string;
    "patient.list.filter.placeholder": string;
    "patient.list.button.refresh": string;
    "patient.list.table.header.id": string;
    "patient.list.table.header.age": string;
    "patient.list.table.header.birth-date": string;
    "patient.list.table.header.name": string;
    "patient.list.table.header.family": string;
    "patient.list.table.header.organization": string;
    "patient.list.table.header.email": string;
    "patient.list.table.header.gender": string;
    "patient.list.table.header.pseudo": string;
    "patient.list.table.no-data": string;
    "patient.list.table.paginator.label": string;
};
