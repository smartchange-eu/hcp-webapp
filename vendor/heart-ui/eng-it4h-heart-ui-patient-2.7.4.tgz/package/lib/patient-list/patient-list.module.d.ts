import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import * as i0 from "@angular/core";
import * as i1 from "./patient-list.component";
import * as i2 from "./analyses.pipe";
import * as i3 from "@angular/common";
import * as i4 from "@angular/material/table";
import * as i5 from "@angular/material/form-field";
import * as i6 from "@angular/material/paginator";
import * as i7 from "@angular/material/input";
import * as i8 from "@angular/material/sort";
import * as i9 from "@eng-it4h/heart-ui-utils";
import * as i10 from "@angular/material/button";
import * as i11 from "@angular/material/tooltip";
import * as i12 from "@angular/material/icon";
import * as i13 from "@angular/material/checkbox";
import * as i14 from "@ngx-translate/core";
export declare function HttpLoaderFactoryPatientList(http: HttpClient): TranslateHttpLoader;
export declare class PatientListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PatientListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PatientListModule, [typeof i1.PatientListComponent, typeof i2.AnalysesPipe], [typeof i3.CommonModule, typeof i4.MatTableModule, typeof i5.MatFormFieldModule, typeof i6.MatPaginatorModule, typeof i7.MatInputModule, typeof i8.MatSortModule, typeof i9.SubTranslateModule, typeof i10.MatButtonModule, typeof i11.MatTooltipModule, typeof i12.MatIconModule, typeof i13.MatCheckboxModule, typeof i14.TranslateModule], [typeof i1.PatientListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PatientListModule>;
}
