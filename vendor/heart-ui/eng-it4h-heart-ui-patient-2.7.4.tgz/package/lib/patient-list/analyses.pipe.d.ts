import { PipeTransform } from '@angular/core';
import { CodedValue } from '@eng-it4h/heart-ui-model';
import { TranslateService } from '@ngx-translate/core';
import * as i0 from "@angular/core";
export declare class AnalysesPipe implements PipeTransform {
    private _translationService;
    private separator;
    constructor(_translationService: TranslateService);
    transform(cvs: CodedValue[]): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnalysesPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<AnalysesPipe, "analyses", false>;
}
