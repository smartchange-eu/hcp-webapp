import { OnInit } from '@angular/core';
import { Patient } from '@eng-it4h/heart-ui-model';
import { SubTranslateService } from '@eng-it4h/heart-ui-utils';
import * as i0 from "@angular/core";
export declare class PatientExpandibleComponent implements OnInit {
    private _subTranslateService;
    lang: string;
    patient?: Patient;
    protected residence_line1?: string;
    protected residence_line2?: string;
    constructor(_subTranslateService: SubTranslateService);
    private createDictionary;
    ngOnInit(): void;
    initResidence(patient: Patient): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PatientExpandibleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PatientExpandibleComponent, "heart-patient-expandible", never, { "lang": "lang"; "patient": "patient"; }, {}, never, never, false, never>;
}
