import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class AgePipe implements PipeTransform {
    constructor();
    transform(value?: Date | string): number | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<AgePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<AgePipe, "age", false>;
}
