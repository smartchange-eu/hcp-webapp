import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient } from '@angular/common/http';
import * as i0 from "@angular/core";
import * as i1 from "./patient-expandible.component";
import * as i2 from "./age.pipe";
import * as i3 from "@angular/common";
import * as i4 from "@eng-it4h/heart-ui-utils";
import * as i5 from "@angular/material/icon";
import * as i6 from "@angular/material/expansion";
import * as i7 from "@ngx-translate/core";
export declare function HttpLoaderFactoryPatientExp(http: HttpClient): TranslateHttpLoader;
export declare class PatientExpandibleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PatientExpandibleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PatientExpandibleModule, [typeof i1.PatientExpandibleComponent, typeof i2.AgePipe], [typeof i3.CommonModule, typeof i4.SubTranslateModule, typeof i5.MatIconModule, typeof i6.MatExpansionModule, typeof i7.TranslateModule], [typeof i1.PatientExpandibleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PatientExpandibleModule>;
}
