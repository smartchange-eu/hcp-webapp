export declare const en: {
    'patient.expandible.years.label': string;
    'patient.expandible.name.label': string;
    'patient.expandible.surname.label': string;
    'patient.expandible.born-at.label': string;
    'patient.expandible.born-in.label': string;
    'patient.expandible.taxCode.label': string;
    'patient.expandible.gender.label': string;
    'patient.expandible.pseudonym.label': string;
    'patient.expandible.domicile.label': string;
    'patient.expandible.residence.label': string;
    'patient.expandible.regional-code.label': string;
    'patient.expandible.email.label': string;
    'patient.expandible.phone-number.label': string;
};
