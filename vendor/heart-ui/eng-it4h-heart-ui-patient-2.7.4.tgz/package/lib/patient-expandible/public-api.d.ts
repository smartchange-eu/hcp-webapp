export * from './patient-expandible.module';
export * from './patient-expandible.component';
