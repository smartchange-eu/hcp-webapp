import { EventEmitter, OnInit } from '@angular/core';
import { Patient } from '@eng-it4h/heart-ui-model';
import * as i0 from "@angular/core";
export declare class PatientCardComponent implements OnInit {
    patient: Patient;
    cancel: EventEmitter<Patient>;
    ok: EventEmitter<Patient>;
    toShow: any;
    constructor();
    ngOnInit(): void;
    cancelClicked(p: Patient): void;
    okClicked(p: Patient): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PatientCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PatientCardComponent, "heart-patient-card", never, { "patient": "patient"; }, { "cancel": "cancel"; "ok": "ok"; }, never, never, false, never>;
}
