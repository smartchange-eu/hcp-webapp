import * as i0 from "@angular/core";
import * as i1 from "./patient-card.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/material/card";
import * as i4 from "@angular/material/button";
import * as i5 from "@angular/material/icon";
export declare class PatientCardModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PatientCardModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PatientCardModule, [typeof i1.PatientCardComponent], [typeof i2.CommonModule, typeof i3.MatCardModule, typeof i4.MatButtonModule, typeof i5.MatIconModule], [typeof i1.PatientCardComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PatientCardModule>;
}
