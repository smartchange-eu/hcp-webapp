export * from './patient-card.module';
export * from './patient-card.component';
